"""项目目录树自动生成与文档定点写回工具。

职责
----
1. 扫描项目根目录（本脚本所在目录的上一级），按统一格式生成目录树：
   - 每层缩进 2 空格，连接符 ``├─`` / ``└─`` / ``│``；
   - 顶层分组（根文件组 / UI/ / lib/ / plugins/ / TAB/ / 系统v7.5/ / docs/）之间空一行；
   - 注释用 ``#``，并与最长条目对齐（最长条目 + 2 空格），至少保留 2 个空格；
   - 整棵树包在 ```text 代码块内。
2. 用哨兵 ``<!-- AUTO-TREE:START -->`` / ``<!-- AUTO-TREE:END -->`` 在文档内定点替换树块，
   绝不整份重写文档；只有内容真正变化时才落盘，因此连续运行第二次必然全部 UNCHANGED。
3. 支持两种块类型（由脚本顶部 ``BLOCK_SPECS`` 声明）：
   - ``full``：项目全量树（以「项目根目录」开头）；
   - ``lib`` ：仅 lib/ 子树（以「lib/」开头），用于 docs/dev.md 的 2.2 节。
4. 扫描仓库内**所有** ``.md`` 文件中的哨兵块：只要文档里加了哨兵，就被自动纳入托管，
   不局限于固定的三个文件。新增含树文档时，加哨兵即可；若该块不是全量树，需在
   ``BLOCK_SPECS`` 中登记其类型。

覆盖范围
--------
- 首次运行（文档中还没有哨兵）时，按 ``BLOCK_SPECS`` 自动定位并补标记：
  - ``README.md``「## 完整项目目录结构」下的 ```text 树块；
  - ``docs/jiego.md`` 整篇唯一的 ```text 树块；
  - ``docs/彩票预测系统-功能与设计说明.md`` 第十二章「项目文件结构对照表」的树块；
  - ``docs/dev.md`` 2.2 节的裸文本 lib/ 子树（补哨兵时同时补 ```text 代码块）。
- 之后每次运行都会扫描全部 .md：所有带哨兵的块逐块比对、逐块修正。
- 不带哨兵、也不在 ``BLOCK_SPECS`` 中的文档不会被改动，但会在输出中提示「未托管」。

用法
----
    python docs/生成目录树.py            # 扫描并写回有变化的文档
    python docs/生成目录树.py --check    # 只比对，不一致打印差异并以退出码 1 结束
    python docs/生成目录树.py --dry-run  # 只打印将写入的树，不落盘

技术约束
--------
- 仅使用标准库；所有文件以 UTF-8 读写，并保留原文件换行风格（LF/CRLF）；
- 注释字典 ``DESCRIPTIONS`` 的键是「相对项目根的路径」，根目录文件即文件名；
  这样同名文件（如 UI/__init__.py、lib/__init__.py）可以各有说明；
- 字典中没有的新条目自动写 ``# 待补充说明``，运行结束时统一列出提醒补写；
- 已有说明一律原样保留，脚本不会改写既有措辞。
"""

from __future__ import annotations  # 作用：让类型注解按字符串延迟求值，使 `str | None` 这类写法在 Python 3.9 及以下也能导入；缺它，文件头以下的联合类型标注会抛 TypeError

import argparse  # 作用：解析 --check / --dry-run 两个互斥开关并生成 --help 文本；缺它无法区分「比对 / 预演 / 写回」三种模式
import os  # 作用：os.walk 遍历仓库内所有 .md（需要就地剪枝排除 __pycache__/.git 等目录，Path.rglob 做不到边遍历边剪枝）
import re  # 作用：正则的备用导入；当前定位逻辑用字符串前缀与 startswith/endswith 完成，尚未调用 re，保留原样（删除属代码改动）
import unicodedata  # 作用：display_width 用它取东亚字符宽度（W/F 记 2 列），否则中文注释列会整体错位
from pathlib import Path  # 作用：跨平台路径拼接与 iterdir/relative_to；目录树全部路径都用它处理，避免手写分隔符

# 常量与配置

# 项目根目录：本脚本位于 docs/，上一级即项目根目录（不写死绝对路径）
ROOT = Path(__file__).resolve().parent.parent

# 哨兵标记：文档中成对出现，脚本只替换这对标记之间的内容
SENTINEL_START = "<!-- AUTO-TREE:START -->"
SENTINEL_END = "<!-- AUTO-TREE:END -->"

# 扫描时需要跳过的目录名（缓存、版本库、临时截图、打包与虚拟环境）
EXCLUDE_DIRS = {
    "__pycache__",
    ".git",
    ".venv",
    "venv",
    "env",
    "build",
    "dist",
    ".idea",
    ".vscode",
}

# 扫描时需要跳过的文件名（系统临时文件 + 数据库运行时 WAL/SHM 旁路文件）
# app_config.db-wal / -shm 由 SQLite 在连接打开期间自动生成，analysis.duckdb.wal 同理由 DuckDB
# 生成；程序退出后可能残留，不属于项目固定结构；若写入目录树会导致每次运行后 --check 失败。
# 「上次预测_号码预测.json」是号码预测页的运行时产物（v0.0.49 起生成），
# 存在与否取决于用户是否点过「生成七策略」；列入忽略名单可保证文件生成后 --check 仍为 0。
# 「崩溃日志.log」是 v0.0.62 起未捕获异常钩子的运行时产物，仅在真正崩溃时生成，
# 不属于项目固定结构；功能说明中以文字说明，目录树不建条目。
EXCLUDE_FILE_NAMES = {"Thumbs.db", ".DS_Store", "desktop.ini",
                      "app_config.db-shm", "app_config.db-wal",
                      "analysis.duckdb.wal", "analysis.duckdb.wal.tmp",
                      "上次预测_号码预测.json",
                      "崩溃日志.log",
                      # 文档脚本改造期间的临时备份（_tmp_ 前缀），不属于项目结构
                      "_tmp_index_old.py"}

# 扫描时需要跳过的后缀（字节码、编辑器临时文件）
EXCLUDE_FILE_SUFFIXES = {".pyc", ".pyo", ".tmp", ".bak", ".swp", ".swo", ".orig", ".rej"}

# 顶层目录的展示顺序：与 README 现有分组顺序保持一致，未登记目录排在最后
DIR_ORDER = ["UI", "lib", "plugins", "TAB", "系统v7.5", "docs"]

# 托管块声明：path 相对项目根；kind 为 full（全量树）或 lib（lib 子树）
# anchor 仅用于首次补哨兵时把搜索范围限定到对应章节
BLOCK_SPECS = [
    {"path": "README.md", "kind": "full", "anchor": "## 完整项目目录结构"},
    {"path": "docs/jiego.md", "kind": "full", "anchor": None},
    {
        "path": "docs/彩票预测系统-功能与设计说明.md",
        "kind": "full",
        "anchor": "## 十二",
    },
    {"path": "docs/dev.md", "kind": "lib", "anchor": "### 2.2"},
]

# 说明字典：键为相对项目根的路径（用 / 分隔），值为中文说明。
# 初值全部取自 README / 功能说明中已有的目录树注释，逐字保留原文；
# 运行中补齐的新文件也必须在这里登记，脚本不会凭空生成说明。
DESCRIPTIONS = {
    # 根目录文件组
    "run.py": "程序主入口：数据库初始化 + 直接创建主窗口 + 事件循环（核心保护文件）",
    "README.md": "项目说明、目录结构、功能总览、版本状态",
    "AI_RULES.md": "AI 硬性指令：代码变更后自动同步全部文档",
    "requirements.txt": "pip依赖清单，一键安装",
    ".gitignore": "Git忽略配置",
    # UI/
    "UI": "界面基础层（所有 PyQt6 控件统一导入）",
    "UI/__init__.py": "转发导出：from UI import * / from UI import (控件...)",
    "UI/UI.py": "全局 PyQt6 控件统一导入中心（核心保护文件）",
    "UI/control_picker.py": "控件拾取/查看器（开发调试工具）",
    # lib/
    "lib": "算法&工具纯逻辑层（禁止任何Qt界面代码）",
    "lib/__init__.py": "懒加载核心：线程环境变量 + 16个重型库加载器 + HAS_* 状态变量",
    "lib/data_process.py": "pandas：配置常量、数据工具、校验、预处理、报告导出",
    "lib/algorithms.py": "纯Python（无任何依赖）：23个预测算法的唯一注册表（编号/名称/方法/号码数/分类）+ 调度接口",
    "lib/math_algo.py": "numpy、scipy：数学工具、23种预测算法、统计分析、时间序列、大数据分析",
    "lib/plot_draw.py": "matplotlib、seaborn：绘图 + 绘图对象访问器",
    "lib/ml_model.py": "sklearn、statsmodels、optuna、torch：机器学习建模",
    "lib/db_helper.py": "SQLite + DuckDB封装类（DuckDB供[6]/[7]/[14]取数、CSV/Parquet直读；SQLite含storage_items索引镜像）",
    "lib/report_builder.py": "HTML报告构造：批量算法说明页模板 + 逐文件写盘（纯逻辑，无Qt）",
    # plugins/
    "plugins": "GUI界面层（主窗口）",
    "plugins/__init__.py": "包标记：使 run.py 能 from plugins.彩票预测 import LotteryPredictionWindow",
    "plugins/彩票预测.py": "主窗口 LotteryPredictionWindow：顶部工具栏 + 选项卡 + 样式 + 事件处理",
    # TAB/
    "TAB": "选项卡页面层：一个选项卡一个独立py文件",
    "TAB/__init__.py": "包说明 + iter_tab_pages()：自动发现声明了 TAB_INFO 的页面",
    "TAB/widgets.py": "共享控件（号码球/号码面板/统计图表/工作线程/角控件构建）",
    "TAB/data_import.py": "[1]  数据导入与格式转换",
    "TAB/history.py": "[2]  历史记录（含「在线开奖」页与增量对比提示）",
    "TAB/online_compare.py": "在线/本地三类差异提示与冲突手工处理（三向只读、默认零写入；不注册为独立选项卡）",
    "TAB/same_period_view.py": "在线开奖页第二视图（QStyledItemDelegate 整表自绘、年份下拉 + 期号区间筛选 300ms 防抖、一致/仅在线/仅本地/值不同四状态色、四种空态文案）",
    "TAB/prediction.py": "[3]  预测与抽取",
    "TAB/number_attributes.py": "[4]  号码属性（三页合并：属性矩阵 + 五行分布 + 选中详情）",
    "TAB/seventh_prediction.py": "[5]  第七位预判",
    "TAB/statistics_chart.py": "[6]  统计分析图表",
    "TAB/backtest.py": "[7]  回测分析",
    "TAB/prediction_history.py": "[8]  预测记录",
    "TAB/info.py": "[9]  公告说明",
    "TAB/favorites.py": "[10] 收藏",
    "TAB/number_sort.py": "[11] 数字排序",
    "TAB/number_tail.py": "[12] 数字选尾",
    "TAB/data_storage.py": "[13] 数据存储",
    "TAB/bigdata_analysis.py": "[14] 大数据分析（推荐7生肖+7数字+红绿蓝三色波+统计检验）",
    "TAB/number_selection.py": "已停用（三页合并；不再声明 TAB_INFO，不进入选项卡栏）",
    "TAB/zodiac.py": "已停用（三页合并；生肖管理入口已并入号码属性页）",
    "TAB/element.py": "已停用（三页合并；五行分布已并入号码属性页）",
    # 系统v7.5/
    "系统v7.5": "运行时数据目录（源码运行与exe打包行为一致）",
    "系统v7.5/app_config.db": "SQLite业务库（app_config / user_data / func_state / history_records / storage_items）",
    "系统v7.5/analysis.duckdb": "DuckDB分析库（history_detail 明细表，首次分析时生成）",
    "系统v7.5/彩票数据.json": "历史开奖数据",
    "系统v7.5/生肖绑定.json": "生肖-号码绑定（首次设置后生成）",
    "系统v7.5/上次预测.json": "最近一次预测结果（首次预测后生成）",
    "系统v7.5/上次预测_号码预测.json": "号码预测（七策略）上次生成结果（首次生成后生成；运行时产物，不参与目录树）",
    "系统v7.5/已保存预测.json": "已保存的预测集合（首次保存后生成）",
    "系统v7.5/预测记录.json": "预测记录选项卡的自动记录（v0.0.18 起持久化）",
    "系统v7.5/配置.ini": "界面与功能配置（丢失时自动从SQLite镜像恢复）",
    "系统v7.5/ml_models.pkl": "机器学习模型缓存（启用缓存时生成）",
    "系统v7.5/控件拾取器.json": "控件拾取器开关状态备份（首次使用控件拾取后生成）",
    "系统v7.5/数据存储": "数据存储选项卡的图片/笔记/文件",
    "系统v7.5/数据存储/index.json": "存储索引镜像（同内容另存SQLite storage_items）",
    "系统v7.5/数据存储/files": "数据存储的文件类条目",
    "系统v7.5/数据存储/images": "数据存储的图片类条目",
    "系统v7.5/数据存储/notes": "数据存储的笔记类条目",
    # docs/
    "docs": "开发规范、配置说明、目录速查、代码修改索引、UI规范、加载机制、功能说明、蓝图输出",
    "docs/dev.md": "开发规范、页面模板、Git、版本日志",
    "docs/config.md": "配置说明（INI现状 + 数据库使用清单 + config.json预留方案）",
    "docs/jiego.md": "项目目录结构速查",
    "docs/号码预测.md": "外部 AI 产出的单文件 demo（整合评估结论见文档内）",
    "docs/代码修改索引.md": "关键词 → 文件 → 行号 全量定位索引",
    "docs/生成索引.py": "工具：重新生成代码修改索引（不参与程序运行）",
    "docs/生成蓝图.py": "工具：真实平台渲染（WA_DontShowOnScreen）14 个启用选项卡页面截图（不参与程序运行）",
    "docs/生成目录树.py": "工具：扫描磁盘生成目录树并写回所有托管文档（不参与程序运行）",
    "docs/UI设计规范与记忆机制.md": "尺寸上限、默认值、分隔符、角控件组、记忆机制",
    "docs/UI设计提示词-大厂专业级.md": "可直接投喂 AI 的 UI 设计规范提示词（布局/颜色/尺寸/8态/五态/动效/验收）",
    "docs/大厂级前端UI-工作流提示词.md": "以大厂级前端做事顺序为主线的工作流提示词（第0～7步 + 反模式 + 迭代模板）",
    "docs/大厂级UI前端-完整提示词.md": "合并版：工作流主线内联设计规范，含 Flet 映射与速查/迭代附录（唯一复制块）",
    "docs/选项卡模块化与加载机制.md": "自动加载 / 手动注册、增删页面写法",
    "docs/Python控件和UI的设计说明提示词.md": "控件与UI设计说明的第一版生成提示词（其产出 HTML 已删除，现由 Flet 完整手册取代）",
    "docs/Python控件和UI的设计说明提示词2.md": "控件与 UI 设计说明的第二版生成提示词（产出 Python Flet 控件与UI开发完整手册.html）",
    "docs/Python Flet 控件与UI开发完整手册.html": "Flet 控件与 UI 开发完整手册单页 HTML（14 部分 / 90 控件，完全离线）",
    "docs/彩票预测系统-功能与设计说明.md": "功能/布局/设计/算法/数据结构全说明",
    "docs/蓝图": "蓝图输出",
    # 截图逐张列出（原来在树中合并写作 00.png–15.png）
    "docs/蓝图/00.png": "14 张启用选项卡页面截图",
    "docs/蓝图/01.png": "14 张启用选项卡页面截图",
    "docs/蓝图/02.png": "14 张启用选项卡页面截图",
    "docs/蓝图/03.png": "14 张启用选项卡页面截图",
    "docs/蓝图/04.png": "14 张启用选项卡页面截图",
    "docs/蓝图/05.png": "14 张启用选项卡页面截图",
    "docs/蓝图/06.png": "14 张启用选项卡页面截图",
    "docs/蓝图/07.png": "14 张启用选项卡页面截图",
    "docs/蓝图/08.png": "14 张启用选项卡页面截图",
    "docs/蓝图/09.png": "14 张启用选项卡页面截图",
    "docs/蓝图/10.png": "14 张启用选项卡页面截图",
    "docs/蓝图/11.png": "14 张启用选项卡页面截图",
    "docs/蓝图/12.png": "14 张启用选项卡页面截图",
    "docs/蓝图/13.png": "14 张启用选项卡页面截图",
    "docs/蓝图/14.png": "14 张启用选项卡页面截图",
    "docs/蓝图/15.png": "14 张启用选项卡页面截图",
    "docs/蓝图/index.html": "截图索引页",
    "docs/蓝图/系统蓝图.html": "完整系统蓝图",
    "docs/设计稿": "UI 设计稿输出（号码属性（合并版）、五行分布、历史号码球、同期对照、在线开奖、顶部菜单栏、生肖页统一版与实测截图）",
    "docs/设计稿/在线开奖/设计方案.md": "在线开奖方案说明（数据源、爬虫可行性、独立库口径与实测性能）",
    "docs/设计稿/生肖页统一版": "生肖页统一版设计稿（变体一/变体二、亮暗双主题与 2x 局部放大）",
    "docs/设计稿/生肖页统一版/变体一_亮色_1180x720.png": "变体一（卡内仅圆形号码 + 五行单字）亮色 1180×720 设计稿（已实现）",
    "docs/设计稿/生肖页统一版/变体一_亮色_1600x974.png": "变体一（卡内仅圆形号码 + 五行单字）亮色 1600×974 设计稿（已实现）",
    "docs/设计稿/生肖页统一版/变体一_暗色_1180x720.png": "变体一（卡内仅圆形号码 + 五行单字）暗色 1180×720 设计稿（已实现）",
    "docs/设计稿/生肖页统一版/变体二_亮色_1180x720.png": "变体二（卡内额外保留生肖小字）亮色 1180×720 设计稿（未采用，留档）",
    "docs/设计稿/生肖页统一版/变体二_暗色_1180x720.png": "变体二（卡内额外保留生肖小字）暗色 1180×720 设计稿（未采用，留档）",
    "docs/设计稿/生肖页统一版/局部放大_表头与两排_2x.png": "变体一表头与两排卡片的 2x 局部放大图（核对渐变、边框与圆径）",
    "docs/设计稿/生肖页统一版/设计方案.md": "生肖页统一版方案说明：表头参数、卡结构与两档几何、变体取舍、实测偏差",
    # 在线开奖与号码属性（三页合并）
    "lib/online_source.py": "在线开奖抓取：请求 / 解析 / 新期判断纯逻辑（select_newer / compare_with_local）",
    "lib/online_store.py": "在线开奖独立库读写（系统v7.5/在线开奖.db，禁止自动合并到本地数据）",
    "lib/same_period.py": "同期对照纯逻辑（按开奖日期对齐、同期号取来源期号、前缀年份不一致的记录拒收、build_year_rows / summarize_rows）",
    "lib/date_utils.py": "日期归一纯逻辑（ISO / 中文 / 斜杠 / 点号 → YYYY-MM-DD；非法日期抛 ValueError，不静默改写）",
    "lib/online_sites.py": "在线站点注册表（代码零内置，只读 系统v7.5/在线站点.json；load_registry / save_registry / enabled_sites / default_site / site_url / match_site / registry_source_type）",
    "系统v7.5/上次预测_随机抽取_本次.json": "随机抽取本次结果（运行时产物，不参与版本基线）",
    "系统v7.5/在线开奖.db": "在线开奖独立 SQLite 库（抓取结果单独存放）",
    "系统v7.5/在线开奖.db-shm": "在线开奖库 WAL 共享内存伴生文件（运行时生成）",
    "系统v7.5/在线开奖.db-wal": "在线开奖库预写日志伴生文件（运行时生成）",
    # 设计稿：五行分布
    "docs/设计稿/五行分布-层次感": "五行分布层次感选型（变体 A / B / C 与推荐稿）",
    "docs/设计稿/五行分布-层次感/变体A_1180_亮.png": "五行分布变体 A（层次感方案）亮色 1180 设计稿",
    "docs/设计稿/五行分布-层次感/变体B_1180_亮.png": "五行分布变体 B（层次感方案）亮色 1180 设计稿",
    "docs/设计稿/五行分布-层次感/变体C_1180_亮.png": "五行分布变体 C（层次感方案）亮色 1180 设计稿",
    "docs/设计稿/五行分布-层次感/推荐_1600_亮.png": "五行分布推荐稿亮色 1600 设计稿",
    "docs/设计稿/五行分布-层次感/设计方案.md": "五行分布层次感方案说明（三种变体对比与推荐理由）",
    # 设计稿：历史记录号码球
    "docs/设计稿/历史记录-号码球": "历史记录号码球渲染方案（纯绘制委托，亮暗双主题）",
    "docs/设计稿/历史记录-号码球/1180_亮色.png": "历史记录号码球方案亮色 1180 设计稿",
    "docs/设计稿/历史记录-号码球/1180_暗色.png": "历史记录号码球方案暗色 1180 设计稿",
    "docs/设计稿/历史记录-号码球/1600_亮色.png": "历史记录号码球方案亮色 1600 设计稿",
    "docs/设计稿/历史记录-号码球/设计方案.md": "历史记录号码球方案说明（球径、行高、字号两档与去抖）",
    # 设计稿：号码属性五行分布
    "docs/设计稿/号码属性-五行分布": "号码属性页五行分布设计稿（亮暗双主题）",
    "docs/设计稿/号码属性-五行分布/1180_亮色.png": "号码属性五行分布亮色 1180 设计稿",
    "docs/设计稿/号码属性-五行分布/1180_暗色.png": "号码属性五行分布暗色 1180 设计稿",
    "docs/设计稿/号码属性-五行分布/1600_亮色.png": "号码属性五行分布亮色 1600 设计稿",
    "docs/设计稿/号码属性-五行分布/设计方案.md": "号码属性五行分布方案说明（列宽、色条、小签与对比度）",
    # 设计稿：号码属性表合并版
    "docs/设计稿/号码属性表-合并版": "号码属性三页合并版设计稿（亮暗两档）",
    "docs/设计稿/号码属性表-合并版/号码属性表_合并版_亮色_1180x720.png": "号码属性表合并版亮色 1180×720 设计稿（已实现）",
    "docs/设计稿/号码属性表-合并版/号码属性表_合并版_亮色_1600x974.png": "号码属性表合并版亮色 1600×974 设计稿（已实现）",
    "docs/设计稿/号码属性表-合并版/号码属性表_合并版_暗色_1180x720.png": "号码属性表合并版暗色 1180×720 设计稿（已实现）",
    "docs/设计稿/号码属性表-合并版/设计方案.md": "号码属性表合并版方案说明（矩阵 + 五行 + 选中详情布局与取舍）",
    # 设计稿：同期对照
    "docs/设计稿/同期对照": "同期号码对照设计稿（亮暗双主题）",
    "docs/设计稿/同期对照/亮色_1180_同期号第100期.png": "同期号第 100 期对照亮色 1180 设计稿",
    "docs/设计稿/同期对照/亮色_1600_同期号第100期_12年.png": "同期号第 100 期 12 年跨度对照亮色 1600 设计稿",
    "docs/设计稿/同期对照/暗色_1180_同月日0101.png": "同月日 01-01 对照暗色 1180 设计稿",
    "docs/设计稿/同期对照/设计方案.md": "同期对照方案说明（数据口径、视图布局与已上线状态：在线开奖页第二视图，14 页签不变）",
    # 设计稿：在线开奖
    "docs/设计稿/在线开奖": "在线开奖视图设计稿",
    "docs/设计稿/在线开奖/渲染方式对比.png": "在线开奖视图两种渲染方式对比图",
    # 实测截图
    "docs/设计稿/实测截图": "实测截图（暗色抽查与修复后、125% 缩放对比、五行 / 历史 / 号码属性 / 顶栏实施后、显示设置抽屉与 DPI 三档、角控件组与面板尺寸弹窗）",
    "docs/设计稿/实测截图/125%缩放_历史_944逻辑.png": "125% 缩放（物理 1180×720 = 逻辑 944×576）历史记录实测",
    "docs/设计稿/实测截图/125%缩放_号码属性_944逻辑.png": "125% 缩放（物理 1180×720 = 逻辑 944×576）号码属性实测",
    "docs/设计稿/实测截图/五行分布_1180_亮_实施后.png": "五行分布改版实施后亮色 1180 实测",
    "docs/设计稿/实测截图/五行分布_1180_暗_实施后.png": "五行分布改版实施后暗色 1180 实测",
    "docs/设计稿/实测截图/历史记录_1180_亮.png": "历史记录页亮色 1180 实测",
    "docs/设计稿/实测截图/历史记录_1180_暗.png": "历史记录页暗色 1180 实测",
    "docs/设计稿/实测截图/历史记录_1600_亮.png": "历史记录页亮色 1600 实测",
    "docs/设计稿/实测截图/号码属性_1180_亮.png": "号码属性页亮色 1180 实测",
    "docs/设计稿/实测截图/号码属性_1180_暗.png": "号码属性页暗色 1180 实测",
    "docs/设计稿/实测截图/号码属性_1600_亮.png": "号码属性页亮色 1600 实测",
    "docs/设计稿/实测截图/基准_历史_1180.png": "基准（无缩放，物理/逻辑均 1180×720）历史记录实测",
    "docs/设计稿/实测截图/基准_号码属性_1180.png": "基准（无缩放，物理/逻辑均 1180×720）号码属性实测",
    "docs/设计稿/实测截图/暗色_修复后_公告_1180.png": "暗色漏配修复后公告说明页 1180 实测",
    "docs/设计稿/实测截图/暗色_修复后_分析_1180.png": "暗色漏配修复后分析页 1180 实测",
    "docs/设计稿/实测截图/暗色_修复后_历史_1180.png": "暗色漏配修复后历史记录页 1180 实测",
    "docs/设计稿/实测截图/暗色_修复后_预测_1180.png": "暗色漏配修复后预测页 1180 实测",
    "docs/设计稿/实测截图/暗色抽查_公告说明_1180.png": "暗色抽查（修复前）公告说明页 1180 实测",
    "docs/设计稿/实测截图/暗色抽查_分析_1180.png": "暗色抽查（修复前）分析页 1180 实测",
    "docs/设计稿/实测截图/暗色抽查_历史记录_1180.png": "暗色抽查（修复前）历史记录页 1180 实测",
    "docs/设计稿/实测截图/暗色抽查_预测_1180.png": "暗色抽查（修复前）预测页 1180 实测",
    "docs/设计稿/实测截图/顶部菜单栏_1180_亮_实施后.png": "顶部菜单栏改版实施后亮色 1180 实测",
    "docs/设计稿/实测截图/顶部菜单栏_1180_暗_实施后.png": "顶部菜单栏改版实施后暗色 1180 实测",
    "docs/设计稿/实测截图/显示设置_改后_1180.png": "显示设置抽屉改后（亮色）1180×720 整窗实测",
    "docs/设计稿/实测截图/显示设置_改后_1600.png": "显示设置抽屉改后（亮色）1600×974 整窗实测",
    "docs/设计稿/实测截图/显示设置_内边距_改后_1180.png": "抽屉四边留白 20px 改后 1180 实测（14:06 旧版 440×604；定稿 400 宽见 显示设置_最终_1180.png）",
    "docs/设计稿/实测截图/显示设置_内边距_改后_1600.png": "抽屉四边留白 20px 改后 1600 实测（14:06 旧版 440×604；定稿 400 宽见 显示设置_最终_1180.png）",
    "docs/设计稿/实测截图/显示设置_文字裁切_改后_1180.png": "抽屉文字零裁切改后 1180 整窗实测",
    "docs/设计稿/实测截图/显示设置_文字裁切_改后_1600.png": "抽屉文字零裁切改后 1600 整窗实测",
    "docs/设计稿/实测截图/显示设置_DPI_100.png": "显示设置抽屉 DPI 100%（1180×720）整窗实测",
    "docs/设计稿/实测截图/显示设置_DPI_125.png": "显示设置抽屉 DPI 125%（1475×900）整窗实测",
    "docs/设计稿/实测截图/显示设置_DPI_150.png": "显示设置抽屉 DPI 150%（1770×1080）整窗实测",
    "docs/设计稿/实测截图/显示设置抽屉_暗色_100.png": "暗色抽屉 DPI 100% 实测（14:06 旧版 440×604；定稿 400 宽见 显示设置_最终_1180.png）",
    "docs/设计稿/实测截图/显示设置抽屉_暗色_125.png": "暗色抽屉 DPI 125% 实测（14:06 旧版 550×755；定稿 400 宽）",
    "docs/设计稿/实测截图/显示设置抽屉_暗色_150.png": "暗色抽屉 DPI 150% 实测（14:06 旧版 660×906；定稿 400 宽）",
    "docs/设计稿/实测截图/面板尺寸弹窗_亮_100.png": "面板尺寸弹窗亮色 DPI 100% 实测（360×240）",
    "docs/设计稿/实测截图/面板尺寸弹窗_亮_125.png": "面板尺寸弹窗亮色 DPI 125% 实测（450×300）",
    "docs/设计稿/实测截图/面板尺寸弹窗_亮_150.png": "面板尺寸弹窗亮色 DPI 150% 实测（540×360）",
    "docs/设计稿/实测截图/面板尺寸弹窗_暗_100.png": "面板尺寸弹窗暗色 DPI 100% 实测（360×240）",
    "docs/设计稿/实测截图/面板尺寸弹窗_暗_125.png": "面板尺寸弹窗暗色 DPI 125% 实测（450×300）",
    "docs/设计稿/实测截图/面板尺寸弹窗_暗_150.png": "面板尺寸弹窗暗色 DPI 150% 实测（540×360）",
    "docs/设计稿/实测截图/角控件组_亮_100.png": "角控件组亮色 DPI 100% 实测（340×40）",
    "docs/设计稿/实测截图/角控件组_亮_125.png": "角控件组亮色 DPI 125% 实测（428×50）",
    "docs/设计稿/实测截图/角控件组_亮_150.png": "角控件组亮色 DPI 150% 实测（513×60）",
    "docs/设计稿/实测截图/角控件组_暗_100.png": "角控件组暗色 DPI 100% 实测（340×40）",
    "docs/设计稿/实测截图/角控件组_暗_125.png": "角控件组暗色 DPI 125% 实测（428×50）",
    "docs/设计稿/实测截图/角控件组_暗_150.png": "角控件组暗色 DPI 150% 实测（513×60）",
    "docs/设计稿/实测截图/显示设置_左扩_改后_1180.png": "抽屉左扩修复后 1180 整窗实测（400×616）",
    "docs/设计稿/实测截图/显示设置_左扩_改后_1600.png": "抽屉左扩修复后 1600 整窗实测（400×868）",
    "docs/设计稿/实测截图/显示设置_间距_改后_1180.png": "抽屉行间距统一后 1180 整窗实测（400×616）",
    "docs/设计稿/实测截图/显示设置_间距_改后_1600.png": "抽屉行间距统一后 1600 整窗实测（400×868）",
    "docs/设计稿/实测截图/显示设置_标签遮挡_改后_1180.png": "抽屉标签遮挡修复后 1180 整窗实测（400×616）",
    "docs/设计稿/实测截图/显示设置_标签遮挡_改后_1600.png": "抽屉标签遮挡修复后 1600 整窗实测（400×868）",
    "docs/设计稿/实测截图/显示设置_最终_1180.png": "抽屉三项修复定稿后 1180 整窗实测（底边净空 12px）",
    # 实测截图：同期对照（在线开奖页第二视图）
    "docs/设计稿/实测截图/同期对照_20261105": "同期对照视图实测截图（2026-11-05，在线开奖页第二视图）",
    "docs/设计稿/实测截图/同期对照_20261105/同期对照_四状态_亮色.png": "同期对照四状态（一致/仅在线/仅本地/值不同）亮色 1180 实测",
    "docs/设计稿/实测截图/同期对照_20261105/同期对照_四状态_暗色.png": "同期对照四状态暗色 1180 实测",
    "docs/设计稿/实测截图/同期对照_20261105/同期对照_四状态_1600宽.png": "同期对照四状态 1600 宽实测",
    "docs/设计稿/实测截图/同期对照_20261105/同期对照_值不同与仅本地_亮色.png": "同期对照「值不同」与「仅本地」状态亮色实测",
    "docs/设计稿/实测截图/同期对照_20261105/同期对照_空态_库不存在.png": "同期对照空态：在线库不存在（只读查询，不创建文件）",
    "docs/设计稿/实测截图/同期对照_20261105/同期对照_空态_库为空.png": "同期对照空态：在线库为空",
    "docs/设计稿/实测截图/同期对照_20261105/同期对照_空态_库损坏.png": "同期对照空态：在线库损坏",
    "docs/设计稿/实测截图/同期对照_20261105/任务1_完全一致.png": "在线增量对比：三类差异全为「一致」时的提示实测",
    "docs/设计稿/实测截图/同期对照_20261105/任务1_仅在线新增.png": "在线增量对比：仅「在线新增」时的提示实测",
    "docs/设计稿/实测截图/同期对照_20261105/任务1_仅冲突.png": "在线增量对比：仅「冲突」时的提示实测",
    "docs/设计稿/实测截图/同期对照_20261105/任务1_对比明细_冲突_亮色.png": "冲突明细弹窗亮色实测（默认不写入，需手动点选「采用在线」）",
    "docs/设计稿/实测截图/同期对照_20261105/任务1_对比明细_冲突_暗色.png": "冲突明细弹窗暗色实测（默认不写入，需手动点选「采用在线」）",
    # 实测截图：DPI 两种口径
    "docs/设计稿/实测截图/DPI_实测_基线100_历史记录页.png": "DPI 实测基线 100% 口径：历史记录页（1180×720）",
    "docs/设计稿/实测截图/DPI_实测_基线100_号码属性页.png": "DPI 实测基线 100% 口径：号码属性页（1180×720）",
    "docs/设计稿/实测截图/DPI_实测_基线100_显示设置抽屉.png": "DPI 实测基线 100% 口径：显示设置抽屉（400×616）",
    "docs/设计稿/实测截图/DPI_实测_屏幕因子125_历史记录页.png": "DPI 实测屏幕缩放因子 125% 口径：历史记录页（1475×900）",
    "docs/设计稿/实测截图/DPI_实测_屏幕因子125_号码属性页.png": "DPI 实测屏幕缩放因子 125% 口径：号码属性页（1475×900）",
    "docs/设计稿/实测截图/DPI_实测_屏幕因子125_显示设置抽屉.png": "DPI 实测屏幕缩放因子 125% 口径：显示设置抽屉（500×770）",
    "docs/设计稿/实测截图/DPI_实测_屏幕因子150_历史记录页.png": "DPI 实测屏幕缩放因子 150% 口径：历史记录页（1770×1080）",
    "docs/设计稿/实测截图/DPI_实测_屏幕因子150_号码属性页.png": "DPI 实测屏幕缩放因子 150% 口径：号码属性页（1770×1080）",
    "docs/设计稿/实测截图/DPI_实测_屏幕因子150_显示设置抽屉.png": "DPI 实测屏幕缩放因子 150% 口径：显示设置抽屉（600×924）",
    "docs/设计稿/实测截图/DPI_实测_逻辑125_历史记录页.png": "DPI 实测逻辑缩放 125% 口径：历史记录页（1475×900）",
    "docs/设计稿/实测截图/DPI_实测_逻辑125_号码属性页.png": "DPI 实测逻辑缩放 125% 口径：号码属性页（1475×900）",
    "docs/设计稿/实测截图/DPI_实测_逻辑125_显示设置抽屉.png": "DPI 实测逻辑缩放 125% 口径：显示设置抽屉（500×770）",
    "docs/设计稿/实测截图/DPI_实测_逻辑150_历史记录页.png": "DPI 实测逻辑缩放 150% 口径：历史记录页（1770×1080）",
    "docs/设计稿/实测截图/DPI_实测_逻辑150_号码属性页.png": "DPI 实测逻辑缩放 150% 口径：号码属性页（1770×1080）",
    "docs/设计稿/实测截图/DPI_实测_逻辑150_显示设置抽屉.png": "DPI 实测逻辑缩放 150% 口径：显示设置抽屉（600×924）",
    # 实测截图：评估对照
    "docs/设计稿/实测截图/五行页_现状_vs_矩阵.png": "五行页现状与属性矩阵方案并排对比图（P-U6 评估用）",
    "docs/设计稿/实测截图/对比度_红球_现状.png": "红球配色对比度现状截图（B4 评估用）",
    "docs/设计稿/实测截图/对比度_红球_改后预览.png": "红球配色对比度改后预览截图（B4 评估用）",
    "docs/设计稿/实测截图/对比度_暗色边框_现状.png": "暗色边框对比度现状截图（B4 评估用）",
    "docs/设计稿/实测截图/对比度_暗色边框_改后预览.png": "暗色边框对比度改后预览截图（B4 评估用）",
    "docs/设计稿/实测截图/特别码_暗色_现状.png": "暗色特别码 #FF6B6B 现状截图（对比度 5.91:1，B4 评估用）",
    "docs/设计稿/实测截图/紧凑档_944现状_vs_1180.png": "紧凑档 944 逻辑现状与 1180 并排对比图（P-U9 评估用）",
    "docs/设计稿/实测截图/风格_暗色_表格与分隔线_1180.png": "暗色主题表格与分隔线风格实测（1180）",
    # 实测截图：在线自动抓取
    "docs/设计稿/实测截图/在线自动抓取": "在线自动抓取实测截图（进页面即抓、可取消、失败只提示）",
    "docs/设计稿/实测截图/在线自动抓取/01_空配置启动引导.png": "空配置启动引导：无站点时提示新增（1600×1000）",
    "docs/设计稿/实测截图/在线自动抓取/02_自动抓取中.png": "自动抓取中（可取消，1600×1000）",
    "docs/设计稿/实测截图/在线自动抓取/03_抓取完成出表.png": "抓取完成出表（1600×1000）",
    "docs/设计稿/实测截图/在线自动抓取/04_断网提示保留旧数据.png": "断网时只提示并保留旧数据（1600×1000）",
    "docs/设计稿/实测截图/在线自动抓取/05_高级区站点清单.png": "高级区站点清单（1600×1000）",
    "docs/设计稿/实测截图/在线自动抓取/06_高级区站点编辑.png": "高级区站点编辑弹窗（980×560）",
    "docs/设计稿/实测截图/在线自动抓取/07_非注册站点提示.png": "非注册站点提示（1180×900）",
    "docs/设计稿/实测截图/在线自动抓取/mock_366期.json": "抓取验证用 366 期 mock 数据（测试夹具，非线上真实数据）",
    # 实测截图：导入修复复核
    "docs/设计稿/实测截图/导入修复": "导入期号修复四段链路取证截图（识别 / 解析 / 入库 / 历史页）",
    "docs/设计稿/实测截图/导入修复/2txt_修复前_期号为None.png": "修复前复现：历史页期号列显示 None（缺陷取证）",
    "docs/设计稿/实测截图/导入修复/2txt_导入前_历史页.png": "导入前历史记录页基线截图",
    "docs/设计稿/实测截图/导入修复/2txt_导入前_数据导入页.png": "导入前数据导入页基线截图",
    "docs/设计稿/实测截图/导入修复/2txt_文件导入后_历史页.png": "文件入口导入后历史页期号列有值截图",
    "docs/设计稿/实测截图/导入修复/2txt_粘贴导入后_历史页.png": "粘贴入口导入后历史页期号列有值截图",
    "docs/设计稿/实测截图/导入修复/2txt_转换结果.png": "转换结果按「日期-期号-6正码-特别码」归一化截图",
    # 实测截图：导入复核（20261105 真实窗口取证）
    "docs/设计稿/实测截图/导入复核": "20261105 导入修复真实窗口复核截图（识别面板 / 双入口 / 缺期号 / 补号 / 编码 / Parquet）",
    "docs/设计稿/实测截图/导入复核/01_竖排2txt_识别与转换.png": "2.txt 粘贴识别结果面板与归一化转换输出",
    "docs/设计稿/实测截图/导入复核/02_竖排2txt_历史页.png": "2.txt 粘贴入口入库后历史页（去重后 3 条，期号列有值）",
    "docs/设计稿/实测截图/导入复核/03_竖排2txt_文件入口_历史页.png": "2.txt 文件入口入库后历史页（与粘贴入口逐条一致）",
    "docs/设计稿/实测截图/导入复核/04_一行一期_识别与转换.png": "一行一期布局的识别结果与归一化转换输出",
    "docs/设计稿/实测截图/导入复核/05_纯号码_拒绝与行号清单.png": "纯号码导入被拒绝并列出缺期号行号",
    "docs/设计稿/实测截图/导入复核/06_跳过缺期号_继续导入.png": "点「跳过缺期号继续」后仅写入有效记录",
    "docs/设计稿/实测截图/导入复核/07_JSON空期号_整批拒绝.png": "JSON 全部空期号时整批拒绝文案",
    "docs/设计稿/实测截图/导入复核/08_期序加日期_补成2026116.png": "纯期序 116 + 日期年份补成 2026116",
    "docs/设计稿/实测截图/导入复核/09_JSON中文键_文件导入.png": "中文键 JSON 文件入口导入后历史页期号有值",
    "docs/设计稿/实测截图/导入复核/10_期序识别结果面板.png": "识别结果面板人话总结 + 转换输出期序 308（不带年份）",
    "docs/设计稿/实测截图/导入复核/11_历史页期号列显示308.png": "历史页「期号」列显示期序 308/307/306（非 2026308）",
    # 质检：导入解析回归语料与自检脚本
    "docs/质检": "质检资产（导入解析回归语料与无 UI 自检脚本）",
    "docs/质检/检查导入解析.py": "导入解析回归自检脚本（识别/解析/期号口径/去重/缺期号/编码/Parquet，退出码 0/1）",
    "docs/质检/导入用例": "导入解析脱敏回归语料（11 份写法样例 + 说明）",
    "docs/质检/导入用例/说明.md": "回归语料说明：清单、期望条数/期号、自检运行方式与维护约定",
    "docs/质检/导入用例/01_单行9段.txt": "语料：一行一期，空格分隔「期号 日期 6正码 特别码」",
    "docs/质检/导入用例/02_竖排多期.txt": "语料：期号行/日期行/号码行/生肖行竖排（取自 2.txt 结构）",
    "docs/质检/导入用例/03_日期在前.txt": "语料：日期在前，含中文/斜杠/横线三种日期写法",
    "docs/质检/导入用例/04_号码在前.txt": "语料：6 码+特码在前，日期与期号在后",
    "docs/质检/导入用例/05_混合写法.txt": "语料：六种字段顺序 + 括号日期 / 开奖时间 / 两位年 / 无日期 / 序号前缀",
    "docs/质检/导入用例/06_中文键.json": "语料：中文键 JSON（期号/日期/号码/特别码）",
    "docs/质检/导入用例/07_英文键.json": "语料：英文键 JSON（issue/nums/sp 等别名与 records 包装）",
    "docs/质检/导入用例/08_空期号.json": "语料：JSON 含空期号（1 条有效 + \"\" + null）",
    "docs/质检/导入用例/09_纯号码.txt": "语料：只有 7 个号码，无期号/期序/日期",
    "docs/质检/导入用例/10_分隔符变体.txt": "语料：竖线/全角分号/Tab/全角逗号/加号分隔",
    "docs/质检/导入用例/11_编码GBK.txt": "语料：GB18030 编码保存，验证编码自动识别",
    # 设计稿：顶部菜单栏
    "docs/设计稿/顶部菜单栏": "顶部菜单栏 / 抽屉设计稿（亮暗双主题，两档宽度）",
    "docs/设计稿/顶部菜单栏/1180_亮色.png": "顶部菜单栏亮色 1180 设计稿",
    "docs/设计稿/顶部菜单栏/1180_暗色.png": "顶部菜单栏暗色 1180 设计稿",
    "docs/设计稿/顶部菜单栏/1600_亮色.png": "顶部菜单栏亮色 1600 设计稿",
    "docs/设计稿/顶部菜单栏/1600_暗色.png": "顶部菜单栏暗色 1600 设计稿",
    "docs/设计稿/顶部菜单栏/设计方案.md": "顶部菜单栏方案说明（123→86px、六组菜单、抽屉尺寸）",
}

# 字典插入顺序即同层条目的展示顺序（保持与既有文档一致）
DESC_INDEX = {rel: idx for idx, rel in enumerate(DESCRIPTIONS)}

# 运行过程中收集「缺说明」的条目，最后统一打印
MISSING_DESCRIPTIONS: list[str] = []


# 通用工具函数


def read_text(path: Path) -> str:
    """功能：以 UTF-8 读取文本，保留原换行符（newline='' 不做任何转换）。

    参数:
        path: 待读取的文件路径（Path；open 也接受字符串）。
    返回:
        str: 文件全文，CRLF/LF 原样保留，供 detect_newline 判断并保证写回风格一致。
    异常:
        OSError / UnicodeDecodeError 直接向上抛。调用方都是「必须读到才能比对」的
        托管文档，若在此静默兜底，后续可能把文档写成空内容，风险更大。
    为什么 newline='':
        默认文本模式会把 CRLF 统一成 LF，写回时悄悄改变文档换行风格，
        导致「内容没变却被 git/编辑器显示为整篇改动」，也会让 --check 误报差异。
    """
    with open(path, "r", encoding="utf-8", newline="") as handle:
        return handle.read()


def write_text(path: Path, text: str) -> None:
    """功能：以 UTF-8 写回文本，newline='' 保证 text 中的换行符原样落盘。

    参数:
        path: 目标文件路径（必须已存在；本脚本只改托管文档，不新建文件）。
        text: 完整的新内容，其中已包含目标文件应使用的换行符。
    返回:
        None。
    异常:
        OSError（无权限/文件被占用）向上抛，避免「以为写成功其实没写」的静默失败。
    说明:
        只在内容确实不同时才被调用（调用方先做 `new_text != text` 比较），
        因此连续运行第二次不会触碰磁盘修改时间。
    """
    with open(path, "w", encoding="utf-8", newline="") as handle:
        handle.write(text)


def detect_newline(text: str) -> str:
    """功能：探测文件换行风格：出现过 CRLF 就按 CRLF 处理，否则按 LF。

    参数:
        text: 以 newline='' 读入的全文（保留原始换行符）。
    返回:
        str: "\r\n" 或 "\n"，用于拼接哨兵/代码块行时与原文保持一致。
    说明:
        只要全文任意一处出现 CRLF 即认定该文件为 CRLF。混合换行文件极少见，
        逐行统计多数派代价高且易在 Windows/Linux 切换时抖动，取「有即算」最稳。
    """
    return "\r\n" if "\r\n" in text else "\n"


def display_width(text: str) -> int:
    """功能：按终端显示宽度计算字符串长度：全角/宽字符记 2，半角记 1。

    参数:
        text: 待测量的树条目文本（如 "├─ run.py"）。
    返回:
        int: 等宽字体下的列数，用于 align_entries 计算补空格数量。
    注意：纯字符串计算，不读文件、不做真实字体度量；制表符与控制字符按 1 列计。
    为什么不用 len():
        目录树在等宽字体中展示，一个中文字符占两列；按字符数对齐会让 `#` 注释列
        随中文数量变化而错位，所以必须按显示宽度计算。
    """
    width = 0
    for char in text:
        # east_asian_width 的 W/F 表示宽字符（中文、全角标点等）
        width += 2 if unicodedata.east_asian_width(char) in ("W", "F") else 1
    return width


def is_temp_name(name: str) -> bool:
    """功能：判断是否是应排除的临时文件/目录名。

    参数:
        name: 文件或目录的最后一级名称（不含路径）。
    返回:
        bool: True 表示扫描时跳过该条目。
    注意：只看最后一级名称，不判断目录层级与父目录；命中即排除，不会因为
          目录里还有有效文件而保留。
    判定规则（任一命中即排除）:
        - 命中 EXCLUDE_FILE_NAMES（系统临时文件、数据库 WAL/SHM 旁路文件等）；
        - 命中 EXCLUDE_FILE_SUFFIXES（.pyc/.tmp/.bak 等编译与编辑器备份）；
        - Office 的 `~$xxx` 锁文件、以 `~` 结尾的编辑器备份。
    为什么独立成函数:
        目录与文件两条扫描分支都要用同一套规则，集中一处避免「目录排除了、文件漏排」。
    """
    if name in EXCLUDE_FILE_NAMES:
        return True
    # Office 临时文件 ~$xxx、编辑器备份 xxx~
    if name.startswith("~$") or name.endswith("~"):
        return True
    return Path(name).suffix.lower() in EXCLUDE_FILE_SUFFIXES


def relative_posix(path: Path) -> str:
    """功能：把绝对路径转换成相对项目根的 POSIX 风格字符串（字典键格式）。

    参数:
        path: 绝对路径（通常来自 iter_markdown_files）。
    返回:
        str: 形如 "docs/dev.md" 的相对路径，统一用 "/" 分隔。
    异常:
        ValueError: path 不在 ROOT 之下时抛出（说明遍历越界，属于真正的配置错误，
        应显式暴露而不是拼出错误键）。
    为什么统一 POSIX 风格:
        DESCRIPTIONS / BLOCK_SPECS 的键都写成 `/` 分隔；Windows 的反斜杠分隔符若混进来，
        字典永远命中不了，说明列会全变成「待补充说明」。
    """
    return path.relative_to(ROOT).as_posix()


# 目录扫描与树渲染


class Node:
    """目录树节点：只保存渲染所需的名称、相对路径、类型与子节点。

    设计说明:
        刻意用 __slots__ 而不是普通类：一次全量扫描会创建上百个节点，
        __slots__ 省掉每实例的 __dict__，并让「误加临时属性」在赋值时就报错，
        保证节点只承载渲染需要的四个字段。

    字段:
        name (str): 最后一级显示名（不含 `/`）。
        rel (str): 相对项目根的 POSIX 路径，同时是 DESCRIPTIONS 的键。
        is_dir (bool): 是否为目录（渲染时决定是否加 `/` 与递归子节点）。
        children (list[Node]): 子节点；文件固定为空列表。
    """

    __slots__ = ("name", "rel", "is_dir", "children")

    def __init__(self, name: str, rel: str, is_dir: bool, children: list) -> None:
        """功能：创建一个树节点。

        参数:
            name: 最后一级名称（显示用）。
            rel: 相对项目根的 POSIX 路径（说明字典的键、也是排序用的身份）。
            is_dir: 是否目录；文件传 False。
            children: 子节点列表；文件传空列表（不传 None，省去渲染时判空）。
        返回:
            None（构造函数）。
        """
        self.name = name
        self.rel = rel
        self.is_dir = is_dir
        self.children = children


def scan_tree(abs_dir: Path, rel_prefix: str) -> list[Node]:
    """功能：递归扫描目录，返回节点列表；排除缓存、版本库与临时文件，空目录保留。

    参数:
        abs_dir: 当前要扫描的绝对目录。
        rel_prefix: 该目录相对项目根的前缀（顶层传 ""，lib 子树传 "lib"），
                    用于拼出每个节点的 rel 键。
    返回:
        list[Node]: 未排序的节点列表（排序交给 order_nodes，便于两层复用同一函数）。
    异常/降级:
        OSError（目录不可读、权限不足、扫描中被删除）→ 当作空目录返回空列表，
        保证整棵树仍能生成，不会因一个子目录而整体失败。
    为什么保留空目录:
        空目录同样是项目结构的一部分（如 docs/蓝图 尚未产出截图时），
        删掉会让读者误判目录被遗漏，因此渲染时在说明后追加「（空目录）」。
    """
    nodes: list[Node] = []
    try:
        entries = sorted(abs_dir.iterdir(), key=lambda item: item.name)
    except OSError:
        # 目录不可读时按空目录处理，避免中断整棵树
        return nodes

    for entry in entries:
        name = entry.name
        rel = f"{rel_prefix}/{name}" if rel_prefix else name
        if entry.is_dir():
            if name in EXCLUDE_DIRS or is_temp_name(name):
                continue
            # 空目录同样保留：children 为空，渲染时会追加「（空目录）」标注
            nodes.append(Node(name, rel, True, scan_tree(entry, rel)))
        elif entry.is_file():
            if is_temp_name(name):
                continue
            nodes.append(Node(name, rel, False, []))
    return nodes


def order_nodes(nodes: list[Node], top_level: bool) -> list[Node]:
    """功能：排序规则：文件在前、目录在后；同组内优先按 DESCRIPTIONS 的顺序。

    参数:
        nodes: 某一层的节点列表（scan_tree 的原始产物）。
        top_level: 是否顶层（True 时目录额外按 DIR_ORDER 固定顺序）。
    返回:
        list[Node]: 可直接交给 render_node 的顺序列表。
    注意：只重排传入列表的返回值，不就地修改 nodes、不读写文档；
          排序口径一旦变化，--check 会立刻报出与文档的差异。
    排序口径（与既有文档保持一致，改排序等于改文档内容，--check 会立刻报差异）:
        - 文件键：(0, 字典序号, 0, "") 已登记 / (1, 0, 0, 名称casefold) 未登记；
        - 顶层目录：DIR_ORDER 中的按 UI/lib/plugins/TAB/系统v7.5/docs 排，
                   其余按字典序号，未登记按名称排在最后；
        - 非顶层目录（lib 子树）：按字典序号，未登记按名称排最后。
    为什么用 casefold 而不是 lower:
        比 lower 更彻底地折叠大小写（含 ß 等），跨平台文件系统排序更稳定。
    """

    def file_key(node: Node):
        """功能：计算文件条目的排序键（已登记按字典序号，未登记按名称排在后面）
        注意：只用 node.rel 查 DESC_INDEX，不改字典也不改节点；
              未登记条目统一排在已登记条目之后，保证新增文件的树位置稳定。
        参数:
            node: 待排序的文件节点（is_dir 为 False）
        返回:
            tuple: (0, 字典序号, 0, "") 或 (1, 0, 0, 名称 casefold)
        """
        index = DESC_INDEX.get(node.rel)
        # 已登记条目用字典顺序，未登记条目排在后面并按名称排序
        if index is not None:
            return (0, index, 0, "")
        return (1, 0, 0, node.name.casefold())

    def dir_key(node: Node):
        """功能：计算目录条目的排序键（顶层先按 DIR_ORDER，其余按字典序号）
        注意：只对 top_level 生效 DIR_ORDER 分支，非顶层目录（lib 子树）
              完全按字典序号与名称排；闭包读取外层 top_level，不修改它。
        参数:
            node: 待排序的目录节点（is_dir 为 True）
        返回:
            tuple: (0, DIR_ORDER 序号, 0, "")、(0, 0, 字典序号, "") 或 (1, 0, 0, 名称 casefold)
        """
        if top_level and node.name in DIR_ORDER:
            return (0, DIR_ORDER.index(node.name), 0, "")
        index = DESC_INDEX.get(node.rel)
        if index is not None:
            return (0, 0, index, "")
        return (1, 0, 0, node.name.casefold())

    files = sorted([n for n in nodes if not n.is_dir], key=file_key)
    dirs = sorted([n for n in nodes if n.is_dir], key=dir_key)
    return files + dirs


def node_description(node: Node) -> str:
    """功能：取节点说明：字典命中则原样返回，未命中标记待补充并登记。

    参数:
        node: 待取说明的节点。
    返回:
        str: 说明文本；空目录会追加「（空目录）」后缀。
    副作用:
        未命中 DESCRIPTIONS 时，把 node.rel 记入全局 MISSING_DESCRIPTIONS，
        运行结束由 report_missing() 统一提示补写（去重，避免同一路径刷多行）。
    为什么不在缺失时抛异常:
        新增文件应先出树、再补说明；抛异常会让整个脚本无法生成任何文档。
    """
    desc = DESCRIPTIONS.get(node.rel)
    if desc is None:
        if node.rel not in MISSING_DESCRIPTIONS:
            MISSING_DESCRIPTIONS.append(node.rel)
        desc = "待补充说明"
    if node.is_dir and not node.children:
        # 空目录必须保留，并在注释里明确标注，避免误以为被漏扫
        desc = f"{desc}（空目录）"
    return desc


def render_node(node: Node, prefix: str, is_last: bool, out: list) -> None:
    """功能：渲染单个节点及其子节点；prefix 是父层延续符（'│  ' 或 '   '）。

    参数:
        node: 当前节点。
        prefix: 父层已确定的延续前缀——祖先若还有后续兄弟，本层竖线继续画（'│  '），
                否则留空（'   '），保证树的竖线不断不错。
        is_last: 是否为父节点的最后一个子节点；决定用 '└─ ' 还是 '├─ '。
        out: 累积输出列表，元素为 (条目文本, 说明)；顶层分组之间用 ("", "") 表示空行。
    返回:
        None（结果写进 out，递归填充，避免层层拼接字符串）。
    """
    connector = "└─ " if is_last else "├─ "
    entry = f"{prefix}{connector}{node.name}{'/' if node.is_dir else ''}"
    out.append((entry, node_description(node)))
    if node.is_dir:
        child_prefix = prefix + ("   " if is_last else "│  ")
        children = order_nodes(node.children, top_level=False)
        for index, child in enumerate(children):
            render_node(child, child_prefix, index == len(children) - 1, out)


def align_entries(entries: list) -> str:
    """功能：把 (条目, 说明) 列表渲染成文本：'#' 统一对齐到「最长条目 + 2」列。

    参数:
        entries: [(条目文本, 说明文本)]；空元组 ("", "") 表示分组间空行。
    返回:
        str: 以 "\n" 连接的整块树文本（不含外层代码块与哨兵）。
    对齐口径:
        column = 最长条目的显示宽度 + 2，随后每条按 max(2, column - 自身宽度) 补空格。
        +2 是为了让 `#` 与最长条目之间至少留一列空隙，否则最长那行会紧贴注释；
        max(2, ...) 兜底超长条目（理论上不会出现，但可避免负宽度乘以 -1 的异常）。
    为什么按显示宽度:
        见 display_width：中文注释与 ASCII 混排时，按字符数对齐会让 `#` 列参差不齐。
    """
    widths = [display_width(entry) for entry, _ in entries if entry]
    column = max(widths) + 2 if widths else 0
    lines: list[str] = []
    for entry, desc in entries:
        if not entry:
            # 空字符串表示顶层分组之间的空行
            lines.append("")
        elif desc:
            padding = " " * max(2, column - display_width(entry))
            lines.append(f"{entry}{padding}# {desc}")
        else:
            lines.append(entry)
    return "\n".join(lines)


def build_full_tree() -> str:
    """功能：生成项目全量树（顶层分组之间空一行，根行「项目根目录」）。

    参数:
        无（根目录取全局 ROOT）。
    返回:
        str: 以「项目根目录」开头、各组之间空行的树文本。
    异常/降级:
        单个子目录读取失败由 scan_tree 吞掉（按空目录处理），本函数不抛出。
    为什么顶层每个目录前插空行:
        与既有 README/功能说明中的分组排版保持一致；一旦改排版，四个托管文档
        都会被判为 DIFF，--check 失败——排版属于「契约」，不是随手可调的样式。
    """
    root_nodes = scan_tree(ROOT, "")
    ordered = order_nodes(root_nodes, top_level=True)
    entries: list = []
    for index, node in enumerate(ordered):
        # 顶层每个目录自成一组，组前插入空行（根文件组与首个目录之间也空一行）
        if node.is_dir and index > 0:
            entries.append(("", ""))
        render_node(node, "", index == len(ordered) - 1, entries)
    return "项目根目录\n" + align_entries(entries)


def build_lib_tree() -> str:
    """功能：生成 lib/ 子树（供 docs/dev.md 2.2 使用，根行为「lib/」）。

    参数:
        无。
    返回:
        str: 以「lib/」开头的子树文本；目录不存在时返回 "lib/\n（目录不存在）"。
    异常/降级:
        lib 缺失不抛异常，而是返回占位文本——check 模式会因此报差异，
        这正是希望的效果：提醒维护者 lib 目录被误删/改名。
    """
    lib_dir = ROOT / "lib"
    if not lib_dir.is_dir():
        # lib 缺失时返回占位，check 模式会因此报差异，属预期提醒
        return "lib/\n（目录不存在）"
    nodes = scan_tree(lib_dir, "lib")
    ordered = order_nodes(nodes, top_level=False)
    entries: list = []
    for index, node in enumerate(ordered):
        render_node(node, "", index == len(ordered) - 1, entries)
    return "lib/\n" + align_entries(entries)


# 文档块定位、比对与写回


def find_fenced_blocks(lines: list[str]) -> list:
    """功能：返回所有 ```text 代码块的行区间（半开区间 [开始, 结束)）。

    参数:
        lines: 文档按行切分且 keepends=True 的结果（每行含换行符）。
    返回:
        list[tuple[int, int]]: 每个代码块的 (起始行下标, 结束行下标)。
        起始行是 ```text 那一行，结束行是收尾 ``` 的下一行，便于直接切片替换。
    异常/降级:
        没有收尾 ``` 的块被忽略（不返回），避免把文档剩余部分误当代码块改写。
    为什么要求 "```text":
        只认带语言标记的块，避免误匹配项目文档里大量普通 ``` 示例代码块。
    """
    blocks = []
    index = 0
    while index < len(lines):
        if lines[index].strip().startswith("```text"):
            end = index + 1
            while end < len(lines) and lines[end].strip() != "```":
                end += 1
            if end < len(lines):
                blocks.append((index, end + 1))
                index = end + 1
                continue
        index += 1
    return blocks


def find_sentinel_regions(lines: list[str]) -> list:
    """功能：返回所有哨兵块的行区间（包含 START 与 END 两行）。

    参数:
        lines: 文档按行切分且 keepends=True 的结果。
    返回:
        list[tuple[int, int]]: (START 行下标, END 行下标 + 1)。
    异常/降级:
        只有 START 没有 END 的块不返回；process_blocks 会据 regions 是否为空
        报「未闭合的哨兵」，属于人工误写，必须提醒。
    为什么用 strip() 比较:
        哨兵行首尾可能被编辑器补了空格/制表符，逐字符比较会漏识别。
    """
    regions = []
    index = 0
    while index < len(lines):
        if lines[index].strip() == SENTINEL_START:
            end = index + 1
            while end < len(lines) and lines[end].strip() != SENTINEL_END:
                end += 1
            if end < len(lines):
                regions.append((index, end + 1))
                index = end + 1
                continue
        index += 1
    return regions


def locate_full_block(lines: list[str], anchor: str | None) -> tuple | None:
    """功能：定位首个以「项目根目录」开头的 ```text 块（可限定在 anchor 章节之后）。

    参数:
        lines: 文档行列表（keepends=True）。
        anchor: 章节起始文本（如 "## 完整项目目录结构"）；None 表示全文搜索。
    返回:
        tuple[int, int, bool] | None: (起始行, 结束行, 是否为代码块)；
        找不到返回 None（bootstrap_blocks 会提示手工加哨兵）。
    注意：anchor 在文档中不存在时退化为全文搜索（start_at=0），不报错也不中断；
          返回的是行下标区间，不是字节偏移，配合 keepends 行列表使用。
    为什么按首行判定:
        全量树的首行固定是「项目根目录」，用它识别可避免把「lib/ 子树」或示例代码块
        误认为全量树；anchor 则把搜索范围限制到目标章节，防止改错别的同款代码块。
    """
    start_at = 0
    if anchor:
        for index, line in enumerate(lines):
            if line.strip().startswith(anchor.strip()):
                start_at = index
                break
    for start, end in find_fenced_blocks(lines):
        if start < start_at:
            continue
        content = [line.strip() for line in lines[start + 1 : end - 1] if line.strip()]
        if content and content[0] == "项目根目录":
            return (start, end, True)
    return None


def locate_lib_block(lines: list[str], anchor: str | None) -> tuple | None:
    """功能：定位 2.2 节的裸文本 lib/ 子树（从「lib/」行到首个空行）。

    参数:
        lines: 文档行列表（keepends=True）。
        anchor: 章节起始文本（如 "### 2.2"）；None 表示全文搜索。
    返回:
        tuple[int, int, bool] | None: (起始行, 结束行, False=裸文本块)。
        注意第三项恒为 False：这种块在首次迁移前没有 ```text 包裹，
        render_block 会把代码块一并补上。
    为什么靠「连接符」判断结束:
        裸文本块没有结束标记，只能以下一个空行或下一行不再是树连接符
        （├─ / └─ / │）为界；逐个字符判断列结构会过重且易误判。
    """
    start_at = 0
    if anchor:
        for index, line in enumerate(lines):
            if line.strip().startswith(anchor.strip()):
                start_at = index
                break
    for index in range(start_at, len(lines)):
        if lines[index].strip() != "lib/":
            continue
        end = index + 1
        while end < len(lines):
            stripped = lines[end].strip()
            if not stripped:
                break
            if not stripped.startswith(("├─", "└─", "│")):
                break
            end += 1
        if end > index + 1:
            return (index, end, False)
    return None


def render_block(tree_text: str, newline: str) -> list[str]:
    """功能：把树文本包装成「哨兵 + ```text 代码块 + 哨兵」的行列表（带换行符）。

    参数:
        tree_text: 纯树文本（build_full_tree / build_lib_tree 的返回值）。
        newline: 目标文档使用的换行符（由 detect_newline 探测）。
    返回:
        list[str]: 可直接替换进文档的整行列表，每行已自带换行符。
    注意：纯字符串拼装，不写盘；tree_text 末尾的空行会被 split 成额外元素，
          因此返回列表可能以「只有一个换行符」的行结尾。
    为什么每行手动拼 newline:
        写入用 newline=''，Python 不会替我们转换换行；只有显式拼接才能让
        LF 文档保持 LF、CRLF 文档保持 CRLF。
    """
    lines = [SENTINEL_START + newline, "```text" + newline]
    lines.extend(line + newline for line in tree_text.split("\n"))
    lines.extend(["```" + newline, SENTINEL_END + newline])
    return lines


def extract_block_tree(lines: list[str], start: int, end: int) -> str:
    """功能：从哨兵区间提取树文本（自动剥掉外层 ```text 代码块与首尾空行）。

    参数:
        lines: 文档行列表（keepends=True）。
        start: 哨兵 START 行下标。
        end: 哨兵 END 行下标 + 1。
    返回:
        str: 纯树文本（无代码块标记、无首尾空行），用于与磁盘树逐字符比较。
    注意：区间越界或块内全为空的返回空串；只做文本裁剪，不校验树是否合法，
          也不读写磁盘。
    兼容:
        块内若没有 ```text 包裹（首次迁移前的裸文本），直接取中间全部行；
        因此迁移前后都能正确比对。
    为什么先找非空首末行:
        哨兵与内容之间常被人工插入空行，直接取 [start+1:end-1] 会把空行算进差异；
        以「首个非空行 / 最后一个非空行」为界，比对只关心真正的树内容。
    """
    inner = lines[start + 1 : end - 1]
    nonempty = [index for index, line in enumerate(inner) if line.strip()]
    if not nonempty:
        return ""
    first, last = nonempty[0], nonempty[-1]
    if inner[first].strip().startswith("```text") and inner[last].strip() == "```":
        body = inner[first + 1 : last]
    else:
        # 兼容没有代码块的裸文本块（首次迁移前可能出现）
        body = inner
    body = [line.rstrip("\r\n") for line in body]
    while body and not body[0].strip():
        body.pop(0)
    while body and not body[-1].strip():
        body.pop()
    return "\n".join(body)


def block_kind(rel_path: str) -> str:
    """功能：查询文档块类型；未在 BLOCK_SPECS 登记但带哨兵的块默认按全量树处理。

    参数:
        rel_path: 文档相对项目根的 POSIX 路径。
    返回:
        str: "full"（全量树）或 "lib"（lib 子树）。
    注意：纯查表，不读写文档也不扫描磁盘；同一路径重复登记时取首个匹配。
    为什么默认 full:
        新增文档只要加哨兵就自动托管，绝大多数文档需要的是全量树；
        局部子树（如 dev.md 2.2）才需在 BLOCK_SPECS 显式登记。
    """
    for spec in BLOCK_SPECS:
        if spec["path"] == rel_path:
            return spec["kind"]
    return "full"


def diff_summary(doc_tree: str, disk_tree: str) -> str:
    """功能：生成简洁差异摘要：分别列出「文档多出」与「磁盘多出」的前几行。

    参数:
        doc_tree: 文档中现有的树文本。
        disk_tree: 按磁盘重新生成的树文本。
    返回:
        str: 多行摘要，每行以 "- 文档有、磁盘无" / "+ 磁盘有、文档无" 开头。
    注意：只做只读比较，不写盘；摘要按行文本集合计算，不体现行号位置，
          因此「顺序变了但内容相同」只会给出统一提示。
    为什么只取前 5 行:
        差异可能几十行（如整目录改名），全量打印会淹没终端；前 5 行已足以定位问题，
        需要完整内容时用 --dry-run 或直接查看文档。
    为什么行集合相同时也给提示:
        行内容一致但顺序/对齐不同也属于 DIFF（例如字典顺序调整），
        这时若不提示，使用者会困惑「看起来一样为什么失败」。
    """
    doc_lines = doc_tree.split("\n")
    disk_lines = disk_tree.split("\n")
    only_doc = [line for line in doc_lines if line and line not in disk_lines][:5]
    only_disk = [line for line in disk_lines if line and line not in doc_lines][:5]
    parts = []
    for line in only_doc:
        parts.append(f"  - 文档有、磁盘无：{line}")
    for line in only_disk:
        parts.append(f"  + 磁盘有、文档无：{line}")
    if not parts:
        # 行集合相同但顺序/对齐不同
        parts.append("  ~ 行内容相同但顺序或对齐列不同")
    return "\n".join(parts)


# 主流程


def iter_markdown_files() -> list[Path]:
    """功能：遍历项目内所有 .md 文件（排除缓存/版本库等目录），按路径排序保证稳定。

    参数:
        无（从全局 ROOT 开始）。
    返回:
        list[Path]: 全部 Markdown 文件绝对路径，已排序。
    注意：只遍历不读文件内容、不写盘；命中排除目录即整枝跳过，因此被排除目录
          下的 .md 不会被计入（也不会出现在树里）。
    为什么不直接用 Path.rglob("*.md"):
        rglob 无法在遍历时跳过 __pycache__/.git/venv 等大目录，会白扫成千上万个文件；
        os.walk 可以就地修改 dir_names 完成剪枝。
    为什么两处都排序:
        目录顺序与文件顺序都固定，保证输出与 diff 顺序可复现（跨平台一致）。
    """
    result: list[Path] = []
    for abs_dir, dir_names, file_names in os.walk(ROOT):
        dir_names[:] = sorted(
            name for name in dir_names if name not in EXCLUDE_DIRS
        )
        for name in sorted(file_names):
            if not name.lower().endswith(".md"):
                continue
            path = Path(abs_dir) / name
            result.append(path)
    return sorted(result)


def bootstrap_blocks(tree_full: str, tree_lib: str) -> list[str]:
    """功能：首次运行：给 BLOCK_SPECS 中尚无哨兵的文档补标记与代码块。

    参数:
        tree_full: 全量树文本。
        tree_lib: lib 子树文本。
    返回:
        list[str]: 本次被更新的文档路径（相对项目根，POSIX 风格），用于汇总输出。
    异常/降级:
        - 配置的文档不存在 → 打印 WARN 并跳过，不中断其它文档；
        - 定位不到可托管的树块 → 打印 WARN 提示手工加哨兵，继续下一份。
        两者都不抛出，保证「部分文档结构变化」不会让整个工具失效。
    为什么只处理尚无哨兵的文档:
        已有哨兵的文档走 process_blocks 的统一比对流程；这里若重复改写，
        会绕过 --check 的差异报告，掩盖真实改动。
    """
    updated: list[str] = []
    for spec in BLOCK_SPECS:
        path = ROOT / spec["path"]
        if not path.is_file():
            print(f"WARN: 配置的文档不存在，跳过：{spec['path']}")
            continue
        text = read_text(path)
        if SENTINEL_START in text:
            # 已有哨兵，交给后续统一比对流程
            continue
        lines = text.splitlines(keepends=True)
        newline = detect_newline(text)
        kind = spec["kind"]
        tree_text = tree_full if kind == "full" else tree_lib
        if kind == "lib":
            located = locate_lib_block(lines, spec["anchor"])
        else:
            located = locate_full_block(lines, spec["anchor"])
        if located is None:
            print(f"WARN: 未找到可托管的目录树块，需手工加哨兵：{spec['path']}")
            continue
        start, end, _fenced = located  # _fenced 仅表示「是否已有代码块」，插入时统一重建，故不使用
        new_text = "".join(lines[:start]) + "".join(render_block(tree_text, newline)) + "".join(lines[end:])
        if new_text != text:
            write_text(path, new_text)
            print(f"UPDATED: {spec['path']}（首次插入哨兵）")
            updated.append(spec["path"])
    return updated


def process_blocks(tree_full: str, tree_lib: str, mode: str) -> int:
    """功能：逐文档逐块比对；mode 为 write/check/dry-run，返回退出码。

    参数:
        tree_full: 全量树文本。
        tree_lib: lib 子树文本。
        mode: "write" 落盘修正 / "check" 只比对 / "dry-run" 打印将写入内容。
    返回:
        int: 0 = 全部一致（或已成功写回）；1 = 存在差异、未闭合哨兵或完全没有托管块。
    异常/降级:
        未在 BLOCK_SPECS 登记但带哨兵的文档按全量树处理（见 block_kind），
        保证「新增文档加哨兵即托管」，不需要改脚本。
    为什么倒序替换:
        从后往前替换区间，前面区间的下标不会因后面插入/删除的行而偏移；
        否则多个哨兵块时，第二个块的起始行会被第一个块的写回结果带偏。
    """
    problems = 0
    managed = 0
    for md_path in iter_markdown_files():
        rel_path = relative_posix(md_path)
        text = read_text(md_path)
        if SENTINEL_START not in text:
            continue
        lines = text.splitlines(keepends=True)
        regions = find_sentinel_regions(lines)
        if not regions:
            # 只有 START 没有 END，属于人工误写，必须报告
            print(f"DIFF {rel_path} [未闭合的哨兵]")
            problems += 1
            continue
        newline = detect_newline(text)
        kind = block_kind(rel_path)
        expected = tree_full if kind == "full" else tree_lib
        # 从后往前替换，避免前面的行号变化影响后面的区间
        for start, end in reversed(regions):
            managed += 1
            current = extract_block_tree(lines, start, end)
            same = current == expected
            if mode == "check":
                status = "OK  " if same else "DIFF"
                print(f"{status} {rel_path} [{kind}] 共 {len(current.split(chr(10)))} 行")
                if not same:
                    print(diff_summary(current, expected))
                    problems += 1
            elif mode == "dry-run":
                print(f"--- DRY-RUN {rel_path} [{kind}] {'无变化' if same else '将更新'} ---")
                if not same:
                    print(expected)
            else:
                if same:
                    print(f"UNCHANGED: {rel_path}")
                else:
                    replacement = render_block(expected, newline)
                    lines[start:end] = replacement
                    new_text = "".join(lines)
                    if new_text != text:
                        write_text(md_path, new_text)
                        text = new_text
                        print(f"UPDATED: {rel_path}")
                    else:
                        print(f"UNCHANGED: {rel_path}")
    if managed == 0:
        # 一个哨兵块都没有：多半是首次迁移未做，或哨兵被误删，不能静默返回 0
        print("WARN: 没有找到任何哨兵块，请先运行不带 --check 的正式模式完成首次迁移")
        problems += 1
    print(f"扫描完成：托管树块 {managed} 个，问题 {problems} 个")
    return 1 if problems else 0  # 有任一问题即返回 1，供 CI/批处理判断


def report_missing() -> None:
    """功能：列出缺少说明、已写入「待补充说明」的条目，提醒补进 DESCRIPTIONS。

    参数: 无（读取全局 MISSING_DESCRIPTIONS）。
    返回: None。没有缺失条目时不打印任何内容。
    为什么去重:
        同一个 rel 可能在全量树与 lib 子树中被各取一次说明；
        去重后每份文档列表只提示一行，避免刷屏。
    """
    unique = list(dict.fromkeys(MISSING_DESCRIPTIONS))
    if not unique:
        return
    print("以下条目缺少说明（已写 # 待补充说明），请补进 DESCRIPTIONS：")
    for rel in unique:
        print(f"  - {rel}")


def build_parser() -> argparse.ArgumentParser:
    """功能：构造命令行解析器，并在 --help 中说明覆盖范围。

    参数: 无。
    返回:
        argparse.ArgumentParser: 已注册 --check / --dry-run（互斥）的解析器。
    为什么把覆盖范围写进 epilog:
        使用者往往只看 --help；把「扫描全部 .md 的哨兵块」与 BLOCK_SPECS 列表
        印在帮助里，避免误以为只有固定三个文档受控。
    """
    coverage = "\n".join(
        f"  - {spec['path']} [{spec['kind']}]" for spec in BLOCK_SPECS
    )
    parser = argparse.ArgumentParser(
        description="扫描磁盘生成项目目录树，并定点写回所有带哨兵的 Markdown 文档。",
        epilog=(
            "覆盖范围：扫描仓库内全部 .md 中的哨兵块；首次运行按下列配置补标记。\n"
            f"{coverage}\n"
            "新增含树文档：加哨兵即可自动托管；若为局部子树，请在 BLOCK_SPECS 登记类型。"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    group = parser.add_mutually_exclusive_group()  # 互斥：两个开关同时给出会让模式含义不清
    group.add_argument(
        "--check",
        action="store_true",
        help="只比对文档中的树与磁盘，不一致时打印差异并以退出码 1 结束",
    )
    group.add_argument(
        "--dry-run",
        action="store_true",
        dest="dry_run",  # 属性名带连字符需映射为 dry_run 才能 args.dry_run 访问
        help="只打印将要写入的树，不修改任何文件",
    )
    return parser


def main() -> int:
    """功能：入口：先构造两种树，再按模式执行迁移/写回/比对。

    参数: 无（命令行参数由 build_parser 解析）。
    返回:
        int: 进程退出码。0 = 一致或写回成功；1 = 存在差异/问题（--check 下即「文档落后于磁盘」）。
    异常/降级:
        文档读取/写入失败（OSError）不在此捕获——此类错误应显式失败，
        避免「退出码 0 但文档其实没更新」的假通过。
    为什么先构造树再进入模式分支:
        构造树本身就是扫描磁盘；dry-run 与 check 都只需要这一份结果，
        写回模式也复用同两棵树，避免重复扫描造成前后不一致。
    """
    args = build_parser().parse_args()
    mode = "check" if args.check else ("dry-run" if args.dry_run else "write")

    # 先在完整树上登记缺说明条目；lib 子树复用同一套说明键
    tree_full = build_full_tree()
    tree_lib = build_lib_tree()
    report_missing()

    if mode == "dry-run":
        # 只打印将要写入的内容，不落盘、不插入哨兵
        print("=== 全量树（README / jiego / 功能说明） ===")
        print(tree_full)
        print("=== lib 子树（docs/dev.md 2.2） ===")
        print(tree_lib)
        for spec in BLOCK_SPECS:
            path = ROOT / spec["path"]
            has_sentinel = path.is_file() and SENTINEL_START in read_text(path)
            print(
                f"DRY-RUN: {spec['path']} [{spec['kind']}] "
                f"{'已托管' if has_sentinel else '首次运行将插入哨兵'}"
            )
        return 0  # 预演不代表失败，恒返回 0

    if mode == "write":
        bootstrap_blocks(tree_full, tree_lib)

    return process_blocks(tree_full, tree_lib, mode)


if __name__ == "__main__":
    raise SystemExit(main())
