# -*- coding: utf-8 -*-
"""工具脚本：生成 docs/代码修改索引.md（关键词 → 文件 → 行号 全量索引）

用法：在任意目录执行 `python docs/生成索引.py [输出路径]`
说明：代码改动导致行号偏移后，重新运行本脚本即可刷新索引；
      本脚本不参与程序运行，也不被 run.py 扫描加载。
      省略输出路径时写入默认文件；传入路径可写到临时文件做校验（不覆盖正式索引）。
"""
import os  # 作用：拼路径（ROOT/OUT/TAB 目录）、列目录（os.listdir）与建目录（makedirs）；缺它无法定位源码与输出
import re  # 作用：正则提取 TAB_INFO、class/def、控件赋值、界面字面量——索引的自动定位全靠它
import sys  # 作用：读取 sys.argv[1] 作为可选输出路径（写临时文件校验，不覆盖正式索引）

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'docs', '代码修改索引.md')
# 可选：用命令行参数指定输出路径（便于写到临时文件校验，避免覆盖正式索引）
if len(sys.argv) > 1:
    OUT = os.path.abspath(sys.argv[1])

# 文件职责表：(相对路径, 职责, 保护级别)
# 作用：第五章「文件清单」与附录十一的遍历来源，也是 LOC 定位的目标清单；
#      新增源文件必须登记在此，否则不会出现在行数表与符号附录里。
FILES = [
    ('run.py', '程序入口、直接创建主窗口 LotteryPredictionWindow（不再扫描插件）', '核心保护：无明确指令不修改'),
    ('UI/UI.py', 'PyQt6 控件统一导入中心（界面层唯一允许的 Qt 导入来源）', '核心保护：只增导入'),
    ('UI/__init__.py', 'UI 包转发：from UI import * / from UI import (控件...)', '包标记：不可删'),
    ('plugins/彩票预测.py', '彩票预测主窗口类 LotteryPredictionWindow（全部业务事件处理）', '核心保护：改动须走索引定位'),
    ('plugins/__init__.py', 'plugins 包初始化（界面层约束说明）', '包标记：不可删'),
    ('TAB/__init__.py', 'tabs 包初始化（选项卡构建契约 build(host) 说明）', '包标记：不可删'),
    ('lib/__init__.py', '纯逻辑层核心包：线程环境变量 + 全部重型库懒加载器与状态变量', '核心保护：不可删'),
    ('lib/data_process.py', '配置常量 LotteryConfig（窗口/字体/三色波/生肖五行）+ 数据读写', '逻辑层'),
    ('lib/math_algo.py', '23 种预测算法、MathUtils、PredictionAlgorithms、BigDataAnalyzer（含波色分析）', '逻辑层'),
    ('lib/ml_model.py', '机器学习模型训练/预测/模型缓存', '逻辑层'),
    ('lib/db_helper.py', '双嵌入式数据库 SQLite + DuckDB 读写封装，get_db() 单例', '逻辑层'),
    ('lib/plot_draw.py', 'matplotlib 图表绘制封装', '逻辑层'),
    ('lib/report_builder.py', 'HTML 报告构造：批量算法说明页模板 + 逐文件写盘（纯逻辑，无 Qt）', '逻辑层'),
    ('TAB/data_import.py', '[1] 数据导入与格式转换 页面', '界面层'),
    ('TAB/history.py', '[2] 历史记录 页面（分页/表格/详情）', '界面层'),
    ('TAB/prediction.py', '[3] 预测与抽取 页面（算法预测/计算规律/波色预测）', '界面层'),
    ('TAB/number_selection.py', '[4] 数字选择 页面', '界面层'),
    ('TAB/seventh_prediction.py', '[5] 第七位预判 页面', '界面层'),
    ('TAB/statistics_chart.py', '[6] 统计分析图表 页面', '界面层'),
    ('TAB/backtest.py', '[7] 回测分析 页面', '界面层'),
    ('TAB/prediction_history.py', '[8] 预测记录 页面', '界面层'),
    ('TAB/info.py', '[9] 公告说明 页面（版本号/功能清单/使用说明）', '界面层：改动须同步版本号'),
    ('TAB/zodiac.py', '[10] 数字与生肖 页面', '界面层'),
    ('TAB/element.py', '[11] 数字与五行 页面', '界面层'),
    ('TAB/favorites.py', '[12] 收藏 页面', '界面层'),
    ('TAB/number_sort.py', '[13] 数字排序 页面（含结果分隔符下拉框）', '界面层'),
    ('TAB/number_tail.py', '[14] 数字选尾 页面（含结果分隔符下拉框）', '界面层'),
    ('TAB/data_storage.py', '[15] 数据存储 页面（笔记/图片/标签）', '界面层'),
    ('TAB/bigdata_analysis.py', '[14] 大数据分析 页面（7 生肖 + 7 数字 + 红绿蓝三色波）', '界面层'),
    ('TAB/widgets.py', '通用控件库（号码球 NumberBallWithZodiac、字体工具 FontUtils 等）', '界面层公共库'),
    ('docs/生成索引.py', '工具脚本：重新生成本索引文档（不参与程序运行）', '工具：改动代码后可重新运行'),
]


def read_lines(rel):
    """功能：按相对路径读取源码的全部行（保留换行符，供逐行正则定位）。

    参数:
        rel: 相对项目根的路径，统一用 "/" 书写（如 'TAB/history.py'）。
    返回:
        list[str]: 每行文本（含行尾换行符），行下标从 0 开始（行号由 enumerate 从 1 计）。
    异常:
        OSError / UnicodeDecodeError 直接上抛——索引定位对象缺失属于必须暴露的配置错误；
        只有 loc() 做了兜底（返回 '-'），其余调用方均在 FILES/TAB 内，不应失败。
    为什么 replace('/', os.sep):
        FILES 与文档一律用 POSIX 风格书写，Windows 下拼路径需要转换分隔符，
        否则会得到 `UI/UI.py` 这种文件系统不认的组合路径。
    """
    p = os.path.join(ROOT, rel.replace('/', os.sep))
    with open(p, encoding='utf-8') as f:
        return f.readlines()


def loc(rel, needle):
    """功能：返回 needle 在指定文件首次出现的行号（1-based），找不到返回 '-'。
    用于让索引表中的函数/方法行号随源码自动刷新，避免硬编码漂移。

    参数:
        rel: 目标文件相对项目根路径（'/' 分隔）。
        needle: 定位用的原文片段（通常取 def/class/常量片段）。
    返回:
        int | str: 首次命中的行号；文件不存在或片段缺失时返回字符串 '-'。
    异常/降级:
        捕获 OSError（文件被删/改名）后返回 '-'，保证整份索引仍能生成；
        随后由 kw_row 把该条登记为「未解析」，结尾统一提示。
    为什么用子串匹配而不是 AST:
        索引需要定位任意片段（含字符串常量、QSS 行），AST 只能覆盖符号；
        子串首次命中与「搜索跳行」的使用习惯一致。
    """
    try:
        for i, line in enumerate(read_lines(rel), 1):
            if needle in line:
                return i
    except OSError:
        pass
    return '-'


# 定位条目统计与「未解析」收集
STATS = {'total': 0, 'resolved': 0}  # 作用：收口统计；total=调用 kw_row/kw_row_as 的条目数，resolved=实际写入索引的条数
UNRESOLVED = []  # 作用：未解析清单，结尾统一打印，便于一次性批量修符号

_MISS_REASON = '源码中未找到定位符号（可能已删除或改名）'  # 统一原因文案，避免每条各写一句导致输出杂乱


def kw_row(kw, rel, needle, note):
    """功能：构造一条关键词表条目；定位失败时登记未解析清单并返回 None（不写入索引）。

    参数:
        kw: 表格第一列的关键词（供人搜索）。
        rel: 目标文件相对路径。
        needle: 在源码中定位用的原文片段。
        note: 第三/四列的说明文字。
    返回:
        tuple[str, str, int, str] | None: (关键词, 文件, 行号, 说明)；
        定位失败返回 None，调用 emit_kw_table / emit_kw_ref 时会整行跳过。
    副作用:
        STATS['total'] 每调用一次 +1；定位失败时把 (kw, rel, needle, 原因) 记入 UNRESOLVED。
    说明：绝不让 '-' 参与 %d 格式化，缺失符号只跳过该条并在结尾汇总点名。
    为什么用 None 而不是让 '-' 混进元组:
        表格格式串是 `%d`，'-' 会直接抛 TypeError 中断整份索引；
        None 让「缺失」与「正常行号」在类型上就分开，调用端必须显式处理。
    """
    STATS['total'] += 1
    ln = loc(rel, needle)
    if ln == '-':
        UNRESOLVED.append((kw, rel, needle, _MISS_REASON))
        return None
    return (kw, rel, ln, note)


def kw_row_as(kw, rel, ln, note):
    """功能：构造一条「行号直写」的条目（如数据库表名等无对应符号的固定项）。

    参数:
        kw: 关键词。
        rel: 目标文件的相对路径。
        ln: 直接写入的行号（通常是 '-'）。
        note: 说明文字。
    返回:
        tuple[str, str, int | str, str]: 一定返回元组（不会返回 None）。
    说明：ln 为 '-' 时表示该项本就没有行号可定位，属于已解析条目，不算未解析。
    为什么与 kw_row 分开:
        「源码里找不到」是本该存在的符号缺失（需告警），而「本来就没有行号」
        是设计如此（例如表名、文档路径），混在一起会制造假告警。
    """
    STATS['total'] += 1
    return (kw, rel, ln, note)


def emit_kw_table(rows):
    """功能：输出关键词表行；None（未解析）整行跳过，已解析行计入统计。

    参数:
        rows: kw_row / kw_row_as 返回的元组列表（可含 None）。
    返回:
        None（结果通过 A() 追加到全局文档缓冲 L）。
    副作用:
        已解析行使 STATS['resolved'] +1。
    """
    for row in rows:
        if row is None:
            continue
        STATS['resolved'] += 1
        kw, rel, ln, note = row
        A('| %s | `%s` | %s | %s |' % (kw, rel, ln, note))


def emit_kw_ref(rows):
    """功能：输出「文件:行号」合写单元格的关键词表行（7.4 用），同样跳过未解析项。

    参数:
        rows: 与 emit_kw_table 相同的元组列表。
    返回:
        None（写入全局文档缓冲 L）。
    注意：会累加全局 STATS['resolved']，重复调用会重复计数；未解析行静默跳过。
    为什么单独一个函数:
        7.4 的表格只有三列，且文件名与行号写在同一单元格（`file:line`），
        与六章的 column 结构不同，复用会导致表头列数不匹配。
    """
    for row in rows:
        if row is None:
            continue
        STATS['resolved'] += 1
        kw, rel, ln, note = row
        A('| %s | `%s:%s` | %s |' % (kw, rel, ln, note))


def symbols(rel):
    """功能：提取 class / def 及其行号

    参数:
        rel: 目标源码的相对路径。
    返回:
        list[tuple[int, str, str, int]]: [(行号, 'class'|'def', 名称, 层级)]，
        层级 0=模块级、1=类方法、2=嵌套（供附录十一的「层级」列）。
    异常:
        OSError 不捕获：FILES 清单里的文件必须存在，缺失应让生成失败而不是输出残缺索引。
    层级口径（4 空格的 Python 缩进约定）:
        缩进 0 → 模块级；≤4 → 类方法/一级函数；>4 → 嵌套函数。
        没有解析真实作用域，只按缩进近似，足以满足「跳到该行」的定位需求。
    """
    rows = []
    pat = re.compile(r'^(\s*)(class|def)\s+([A-Za-z_]\w*)')  # 行首缩进 + class/def + 标识符；注释掉的 def 行不以 def 开头，不会误匹配
    for i, line in enumerate(read_lines(rel), 1):
        m = pat.match(line.rstrip('\n'))
        if m:
            indent = len(m.group(1))
            kind = m.group(2)
            name = m.group(3)
            level = 0 if indent == 0 else 1 if indent <= 4 else 2
            rows.append((i, kind, name, level))
    return rows


def main_window_regions():
    """功能：解析主窗口源码里的 `# 【区域N】标题` 注释，按区域汇总区域内的 def

    参数:
        无（固定读取模块常量 PLUGIN 指向的主窗口文件）。
    返回: list[tuple[str, int, list[tuple[str, int]]]]
        (区域标题, 区域起始行号, [(方法名, 行号)])
    说明：区域标题与方法清单全部来自源码，方法增删/移动后重新生成即可刷新。
    异常:
        _plugin_lines() 读取失败会抛 OSError（主窗口文件必需，属真实错误）。
    为什么区域边界取「下一个区域标记 - 1」:
        每个区域的结束就是下个区域的开始；最后一个区域延伸到文件末尾。
        这样方法归属完全由源码注释决定，索引不需要额外维护区块清单。
    """
    lines = _plugin_lines()
    marks = []
    pat = re.compile(r'^    #\s*【区域(\d+)】\s*(.*)$')  # 只认 4 空格缩进的类内注释，避免正文/文档字符串里的同名文字被误判
    for i, line in enumerate(lines, 1):
        m = pat.match(line)
        if m:
            marks.append((int(m.group(1)), m.group(2).strip(), i))
    result = []
    for idx, (no, title, start) in enumerate(marks):
        end = marks[idx + 1][2] - 1 if idx + 1 < len(marks) else len(lines)
        defs = []
        for i in range(start, end):
            dm = re.match(r'^    def (\w+)\(', lines[i])
            if dm:
                defs.append((dm.group(1), i + 1))
        result.append(('区域%d %s' % (no, title), start, defs))
    return result


def widgets(rel):
    """功能：提取控件定义：xxx.yyy = QXxx(  行号

    参数:
        rel: 目标源码相对路径。
    返回:
        list[tuple[str, str, int]]: [(“xxx.yyy”, 控件类名, 行号)]。
    注意：纯正则扫描，不导入目标模块、不实例化控件；只按行文本匹配，
          动态拼接的创建语句（如 exec、getattr 构造）不会被收录。
    匹配口径:
        只认「属性/变量.成员 = Q开头类名(」形式，因此能区分
        `self.btn = QPushButton(` 与 `btn = QPushButton(` 之外的普通赋值。
    为什么限定 Q 前缀:
        界面控件都来自 PyQt6（Q 开头），限定前缀可避免把业务对象的构造
        （如 Node(...)、Node(...)）混进「控件定义表」。
    """
    rows = []
    pat = re.compile(r'^\s*(\w+)\.(\w+)\s*=\s*(Q[A-Za-z0-9_]+)\s*\(')
    for i, line in enumerate(read_lines(rel), 1):
        m = pat.match(line)
        if m:
            rows.append((m.group(1) + '.' + m.group(2), m.group(3), i))
    return rows


def build_anchor(rel):
    """功能：定位页面构建入口 `def build(host)` 的行号。

    参数:
        rel: 页面文件相对路径。
    返回:
        int | str: 行号；未找到返回 '-'（该页面可能改为 install(host) 自包含）。
    注意：只返回首个匹配，行号从 1 开始；找不到时返回字符串 '-' 而非 0 或抛异常，
          调用方可直接写进表格。
    为什么单独抽函数:
        7.2/7.3 两张表都要「构建入口行号」，抽出来后找不到时的 '-' 处理只需一处。
    """
    for i, line in enumerate(read_lines(rel), 1):
        if re.match(r'^def build\(host\)', line):
            return i
    return '-'


def line_count(rel):
    """功能：统计文件行数（文件清单表与附录标题使用）。

    参数:
        rel: 目标源码相对路径。
    返回:
        int: 总行数（含空行与注释行，与编辑器显示一致）。
    异常:
        OSError 不捕获：FILES 中的文件缺失属于必须暴露的问题。
    """
    return len(read_lines(rel))


# 选项卡页面区域定位（按窗口布局逐页索引）
PLUGIN = 'plugins/彩票预测.py'


def _plugin_lines():
    """功能：读取主窗口源文件（plugins/彩票预测.py）的全部行。

    参数: 无（路径来自模块常量 PLUGIN）。
    返回:
        list[str]: 每行文本（含换行符）。
    异常:
        OSError 上抛——主窗口是索引的核心，缺失时不应生成一份空索引。
    为什么用函数而不是全局缓存:
        main_window_regions / toolbar_info 都要读；每次按需读取可避免「读到的是旧内容」
        这类缓存一致性问题，文件规模（万行级）重复读取开销可忽略。
    """
    return read_lines(PLUGIN)


def page_registry():
    """功能：自动发现 TAB/*.py 的 TAB_INFO，返回选项卡清单

    参数:
        无（扫描 ROOT/TAB 目录，不接收外部清单）。
    返回: list[dict]，字段 title / rel / order / info_line / build_line / addtab_line
        （另有 install_line，值为行号或 ''）。
    说明：标题与顺序全部从页面文件的 TAB_INFO 解析，不硬编码；
          新增页面后重新生成本索引即可自动收录（主窗口已改为自动加载）。
    异常/降级:
        - TAB 目录不可读 → os.listdir 抛 OSError（属真实错误，不吞）；
        - 单个页面没有 TAB_INFO → 跳过该文件（可能只是辅助模块，如 widgets.py）；
        - 页面声明 "enabled": False → 跳过（已停用的页面不应出现在索引里）。
    排序口径:
        先按 TAB_INFO["order"] 升序，再按标题；未声明 order 的按 999 排在最后。
        999 是「比任何真实序号都大」的哨兵值，不是业务顺序。
    """
    pages = []
    tab_dir = os.path.join(ROOT, 'TAB')
    addtab_line = loc(PLUGIN, 'for _order, title, module in iter_tab_pages()')
    for fn in sorted(os.listdir(tab_dir)):
        if not fn.endswith('.py'):
            continue
        name = fn[:-3]
        if name.startswith('_') or name == 'widgets':  # 下划线前缀=停用/调试文件；widgets=公共控件库，均不是选项卡
            continue
        rel = 'TAB/%s.py' % name
        text = ''.join(read_lines(rel))
        m = re.search(r'TAB_INFO\s*=\s*\{(.*?)\}', text, re.S)  # re.S 让 . 跨行匹配字典体
        if not m:
            continue
        block = m.group(1)
        if re.search(r'"enabled"\s*:\s*False', block):
            continue
        tm = re.search(r'"title"\s*:\s*"([^"]*)"', block)
        om = re.search(r'"order"\s*:\s*(\d+)', block)
        pages.append({
            'title': tm.group(1) if tm else name,  # 未声明 title 时退回文件名，保证表里不出现空标题
            'rel': rel,
            'order': int(om.group(1)) if om else 999,  # 999 = 未声明顺序，排到最后
            'info_line': loc(rel, 'TAB_INFO'),
            'build_line': build_anchor(rel),
            'install_line': (lambda v: '' if v == '-' else v)(loc(rel, 'def install(host)')),
            'addtab_line': addtab_line,
        })
    pages.sort(key=lambda p: (p['order'], p['title']))
    return pages


# 界面文本字面量：覆盖标签/按钮/分组框/占位符/提示/下拉选项，供「搜页面文字跳行」
# 作用：text_keywords 的唯一匹配源。第 2 组捕获引号类型（' 或 "），\2 反向引用保证
#      起止引号一致；(.+?) 非贪婪，避免把同一行多个字面量合并成一个。
# 为什么把 setText/addItem 也算进来：很多动态文案不在构造参数里，而是事后 setText 设置，
#      只匹配构造会漏掉大量可搜索文字。
_TEXT_CALLS = re.compile(
    r'(QLabel|QPushButton|QCheckBox|QRadioButton|QGroupBox|QToolButton|'
    r'setPlaceholderText|setText|setToolTip|setWindowTitle|addItem)'
    r'\s*\(\s*f?(["\'])(.+?)\2'
)


def text_keywords(rel, limit=120, start=1, end=None):
    """功能：提取页面内可直接搜索的界面文本（关键词, 行号）

    覆盖 QLabel / QPushButton / QGroupBox / setPlaceholderText / setText /
    setToolTip / setWindowTitle / addItem 的字面量首参；
    自动跳过样式表与含花括号的代码片段，重复文本只保留首次出现。
    start/end 用于只扫描某个方法区域（如顶部工具栏）。

    参数:
        rel: 页面文件相对路径。
        limit: 最多返回条数，默认 120——单页上千条文本会撑爆索引表，也超出「快速跳行」的用途。
        start / end: 只扫描的行号区间（含端点，1-based）；end=None 表示到文件末尾。
    返回:
        list[tuple[str, int]]: [(界面文字, 行号)]，按首次出现顺序，长度不超过 limit。
    异常/降级:
        文件不可读（OSError）→ 返回空列表，让该页继续生成其余小节，
        避免一个页面缺文件导致整份索引中断。

    过滤口径（为什么）:
        - 长度 < 2 的字面量（如 ":"、""）没有搜索价值，剔除；
        - 含 { } 或 font-size 的多为 QSS 样式模板，搜出来是噪音；
        - 超过 40 字的截断加 "…"，避免表格单元格过宽把页面撑出横向滚动条。
    """
    rows = []
    seen = set()  # 同一文字只保留首次出现，避免同一按钮文案在不同状态分支里重复刷表
    try:
        lines = read_lines(rel)
    except OSError:
        return rows
    if end is None or end > len(lines):
        end = len(lines)
    for i, line in enumerate(lines, 1):
        if i < start or i > end:
            continue
        for m in _TEXT_CALLS.finditer(line):
            value = m.group(3).strip()
            if len(value) < 2:
                continue
            if '{' in value or '}' in value or 'font-size' in value:
                continue
            value = value.replace('\\n', ' ').replace('\n', ' ')  # 换行符会破坏表格单元格，统一压成空格
            if len(value) > 40:
                value = value[:40] + '…'  # 40 字上限：再长就超出表格可读宽度
            if value in seen:
                continue
            seen.add(value)
            rows.append((value, i))
            if len(rows) >= limit:
                return rows
    return rows


_HOST_REF = re.compile(r'host\.(\w+)')


def host_assignments(rel):
    """功能：提取页面内 `host.xxx = ...` 赋值（首次出现行号），返回 {名称: 行号}

    参数:
        rel: 页面文件相对路径。
    返回:
        dict[str, int]: {host 属性名: 首次赋值行号}。
    异常/降级:
        OSError → 返回空字典，该页「来源」列会显示「本页与主窗口均未见赋值」，
        仍能生成索引而不是中断。
    为什么只记首次出现:
        同名属性可能在多个分支里重复赋值，索引只需要「第一个可跳转位置」。
    """
    result = {}
    try:
        lines = read_lines(rel)
    except OSError:
        return result
    for i, line in enumerate(lines, 1):
        m = re.match(r'^\s*host\.(\w+)\s*=', line)
        if m and m.group(1) not in result:
            result[m.group(1)] = i
    return result


def host_refs(rel):
    """功能：提取页面内 `host.xxx` 引用（按首次出现行号），返回 [(名称, 行号)]

    参数:
        rel: 页面文件相对路径。
    返回:
        list[tuple[str, int]]: [(host 属性名, 首次引用行号)]，按源码顺序。
    异常/降级:
        OSError → 返回空列表（该页无「事件方法 / 控件」两节内容，其余照常生成）。
    用途:
        7.3 用它反查「页面引用的 host 成员定义在主窗口哪一行」（host_member_line）。
    """
    rows = []
    seen = set()
    try:
        lines = read_lines(rel)
    except OSError:
        return rows
    for i, line in enumerate(lines, 1):
        for m in _HOST_REF.finditer(line):
            name = m.group(1)
            if name in seen:
                continue
            seen.add(name)
            rows.append((name, i))
    return rows


def host_member_line(name):
    """功能：在插件文件中定位 host 成员的定义行

    下划线开头视为方法，找 `def name(`；否则视为控件/共享数据，找 `self.name =`。

    参数:
        name: host 属性名（不含 `host.` 前缀）。
    返回:
        int | str: 定义行号；两处都找不到时返回 '-'（调用方据此把该属性归入
        「跨页共享数据或主窗口方法内动态创建」）。
    注意：只读主窗口源文件，不解析 AST、不执行代码；同名成员多处定义时取首个匹配。
    为什么分两种查找:
        下划线私有成员在源码里只会以方法形式出现；公开成员多为控件赋值，
        查 `self.name =` 更快也更准确。找不到赋值时再退回找同名方法，
        兼容「公开方法」这种少数情况。
    """
    if name.startswith('_'):
        return loc(PLUGIN, 'def %s(' % name)
    line = loc(PLUGIN, 'self.%s =' % name)
    if line == '-':
        line = loc(PLUGIN, 'def %s(' % name)
    return line


_TOP_DEF = re.compile(r'^(?:def|class)\s+(\w+)')


def page_defs(rel):
    """功能：提取页面内的顶层函数/类定义，返回 [(名称, 行号)]

    参数:
        rel: 页面文件相对路径。
    返回:
        list[tuple[str, int]]: [(名称, 行号)]，仅模块级（行首无缩进）。
    异常/降级:
        OSError → 返回空列表。
    为什么只认行首:
        页面文件只有 build/install 与少量顶层辅助函数，类内方法属于主窗口，
        不在此列；限定行首可避免把缩进方法混进「本页函数与类」表。
    """
    rows = []
    try:
        lines = read_lines(rel)
    except OSError:
        return rows
    for i, line in enumerate(lines, 1):
        m = _TOP_DEF.match(line)
        if m:
            rows.append((m.group(1), i))
    return rows


def page_imports(rel):
    """功能：提取页面内的模块导入语句，返回 [(语句, 行号)]

    参数:
        rel: 页面文件相对路径。
    返回:
        list[tuple[str, int]]: [(去除首尾空白的导入语句, 行号)]。
    异常/降级:
        OSError → 返回空列表。
    特殊标注:
        单文件调试引导块（`import os as _os_boot` / `import sys as _sys_boot`）追加
        「（单文件调试引导）」后缀——它们只为「直接运行本文件」服务，不是业务依赖，
        不标注会误导读者以为页面正常运行时也需要这两行。
    """
    rows = []
    try:
        lines = read_lines(rel)
    except OSError:
        return rows
    for i, line in enumerate(lines, 1):
        if re.match(r'(?:from\s+\S+\s+import|import\s)', line):
            text = line.strip()
            if text.startswith(('import os as _os_boot', 'import sys as _sys_boot')):
                text += '（单文件调试引导）'
            rows.append((text, i))
    return rows


def all_widgets(rel):
    """功能：提取页面内全部控件创建语句（含局部变量）

    返回: [(名称, 类型, 行号)]；挂主窗口的写作 `host.xxx` / `self.xxx`

    参数:
        rel: 页面文件相对路径。
    返回:
        list[tuple[str, str, int]]: [(控件名(可能带 host./self. 前缀), 类型, 行号)]。
    异常/降级:
        OSError → 返回空列表。
    为什么分两次匹配:
        先匹配带 `self.`/`host.` 前缀的（表里显示归属），再匹配纯局部变量；
        若只写一条正则，前缀会被当成变量名的一部分，表格里出现 `host.bd_start_btn`
        这种「像是在页面里定义、其实挂在主窗口」的歧义。
    """
    rows = []
    try:
        lines = read_lines(rel)
    except OSError:
        return rows
    for i, line in enumerate(lines, 1):
        m = re.match(r'\s*(self|host)\.(\w+)\s*=\s*(Q\w+)\s*\(', line)
        if m:
            rows.append(('%s.%s' % (m.group(1), m.group(2)), m.group(3), i))
            continue
        m = re.match(r'\s*(\w+)\s*=\s*(Q\w+)\s*\(', line)
        if m:
            rows.append((m.group(1), m.group(2), i))
    return rows


def toolbar_info():
    """功能：解析顶部工具栏区域（窗口第 1 排）

    范围：`_create_top_bar` 方法起始行 → `_create_tabs` 方法起始行之前。
    返回: dict(start, end, texts, widgets, methods) 或 None

    参数: 无（固定解析 PLUGIN 主窗口文件）。
    返回:
        dict | None: 键为 start（起行）、end（止行，含）、texts（文字关键词）、
        widgets（控件列表）、methods（事件方法列表）；两个方法名缺失时返回 None。
    异常/降级:
        找不到 `_create_top_bar` / `_create_tabs` 时返回 None，7.1 节改写为
        「未解析到 …，请检查方法名是否被改动」的提示，不影响后续章节生成。
    为什么以「下一个方法名」为边界:
        工具栏区域没有显式结束标记；`_create_tabs` 是紧邻的下一个构建方法，
        用它的定义行减 1 作为边界，方法增删后仍能自动跟随。
    """
    start = loc(PLUGIN, 'def _create_top_bar')
    end = loc(PLUGIN, 'def _create_tabs')
    if start == '-' or end == '-':
        return None
    start = int(start)
    end = int(end) - 1
    lines = _plugin_lines()

    texts = text_keywords(PLUGIN, start=start, end=end, limit=80)  # 工具栏按钮有限，80 条足够且避免异常多行文本撑表

    # 工具栏控件：self.xxx = QXxx(...) 或局部变量 xxx = QXxx(...)
    widgets = []
    for i in range(start, end + 1):
        m = re.match(r'\s*(?:self\.)?(\w+)\s*=\s*(Q\w+)\s*\(', lines[i - 1])
        if m:
            widgets.append((m.group(1), m.group(2), i))

    # 工具栏内引用的主窗口方法（按钮回调、辅助方法）
    methods = []
    seen = set()
    for i in range(start, end + 1):
        for m in re.finditer(r'self\.(\w+)', lines[i - 1]):
            name = m.group(1)
            if name in seen or name == '_create_top_bar':
                continue
            dline = loc(PLUGIN, 'def %s(' % name)
            if dline != '-':
                seen.add(name)
                methods.append((name, i, dline))
    return {'start': start, 'end': end, 'texts': texts,
            'widgets': widgets, 'methods': methods}


# 文档正文
L = []  # 作用：整份索引的行缓冲；先全部追加到内存，最后一次写盘，避免边算边写出现半成品文件
A = L.append  # 作用：简写追加器；下文上百处 A('...') 都指向同一列表

A('# 代码修改索引（关键词 → 文件 → 行号 → 修改）')
A('')
A('> 本文件是项目唯一的「全量定位索引」：先在这里搜索关键词，得到「文件 + 行号」，')
A('> 再打开对应文件跳到该行修改。行号依据生成时的源码统计，代码改动后需重新生成。')
A('>')
A('> 生成方式：`python docs/生成索引.py`（代码改动后重新运行即可刷新行号）。')
A('> 维护规则见 `AI_RULES.md`，版本记录见 `docs/dev.md`。')
A('')
A('## 一、使用方法')
A('')
A('1. 在本文档中搜索关键词（如 `分隔符`、`波色`、`自适应`、`懒加载`、`_analysis_records`）。')
A('2. 在「关键词定位表」中找到对应的 `文件相对路径 : 行号`。')
A('3. 打开该文件跳转到该行修改；不确定控件在哪个文件时，查「八、控件定义位置表」。')
A('4. 按界面区域找代码（最常用）：第七章按窗口布局分区——7.1 顶部工具栏（第 1 排），7.3 每个选项卡一块（第 2 排起）。')
A('   搜工具栏按钮文字（如「导入数据」）看 7.1；搜选项卡标题或页面文字（如「数字选尾」「未匹配的数字」）看 7.3。')
A('   每个区域都给出该区域的文件位置/行号、全部文字、控件、函数/类、导入依赖与事件方法。')
A('5. 修改界面层后：`python -m py_compile <文件>` 校验，再按 `AI_RULES.md` 同步')
A('   README / dev.md / 功能说明 / 公告说明 版本号。')
A('')
A('## 二、运行原理：程序是怎么跑起来的')
A('')
A('### 2.1 启动链路（按执行顺序，行号在 `run.py` 与 `plugins/彩票预测.py`）')
A('')
A('| 步骤 | 发生了什么 | 位置 |')
A('|---|---|---|')
A('| 1 | `python run.py` 触发 `if __name__ == "__main__": main()` | run.py:%s |' % loc('run.py', 'if __name__ == "__main__":'))
A('| 2 | 打印 `PyQt6窗口启动中...` | run.py:%s |' % loc('run.py', 'PyQt6窗口启动中'))
A('| 3 | 在 import 科学计算库之前设置 OMP/OPENBLAS/MKL 线程数=1（防 0xC0000409 栈溢出） | run.py:%s-23 |' % loc('run.py', "OMP_NUM_THREADS"))
A('| 4 | 检查 PyQt6 是否安装，缺失则退出 | run.py:%s 起 |' % loc('run.py', '错误: 缺少 PyQt6'))
A('| 5 | 主线程预加载 sklearn / scipy（C 扩展初始化必须发生在主线程） | run.py:%s 起 |' % loc('run.py', '_get_sklearn()'))
A('| 6 | `get_db()` 初始化 SQLite + DuckDB，自动建 `系统v7.5/` 目录 | run.py:%s / lib/db_helper.py:%s |' % (
    loc('run.py', 'get_db()'), loc('lib/db_helper.py', 'def get_db')))
A('| 7 | 创建 `QApplication`，应用名设为 `pyqt窗口 系统v7.5`（窗口标题仍取 `WINDOW_TITLE`=`系统v7.5`） | run.py:%s |' % loc('run.py', 'app.setApplicationName'))
A('| 8 | `LotteryPredictionWindow()`：直接创建主窗口（不再扫描插件） | run.py:%s / 彩票预测.py:%s |' % (
    loc('run.py', 'window = LotteryPredictionWindow'), loc('plugins/彩票预测.py', 'class LotteryPredictionWindow')))
A('| 9 | 主窗口构造函数内 `_init_ui()` 构建顶栏 + 14 个启用选项卡（三页合并停用）+ 状态栏 | 彩票预测.py:%s / %s |' % (
    loc('plugins/彩票预测.py', 'self._init_ui()'), loc('plugins/彩票预测.py', 'def _init_ui')))
A('| 10 | `_create_top_bar` 构建顶部工具栏（导入/导出/保存/字体，无标题文字） | 彩票预测.py:%s |' % loc('plugins/彩票预测.py', 'def _create_top_bar'))
A('| 11 | `_create_tabs` 遍历 `TAB.iter_tab_pages()`，按 `TAB_INFO["order"]` 自动调用 `install(host)`（缺失则 `build(host)`）并 `addTab` | 彩票预测.py:%s |' % loc('plugins/彩票预测.py', 'def _create_tabs'))
A('| 12 | `_wrap_tabs_in_scroll()` 给每个选项卡再包一层 QScrollArea（窗口缩小不重叠） | 彩票预测.py:%s / %s |' % (
    loc('plugins/彩票预测.py', 'self._wrap_tabs_in_scroll()'), loc('plugins/彩票预测.py', 'def _wrap_tabs_in_scroll')))
A('| 13 | `window.show()` + `app.exec()` 进入 Qt 事件循环 | run.py:%s / %s |' % (
    loc('run.py', 'window.show()'), loc('run.py', 'app.exec()')))
A('| 14 | 退出时清理 TF/Torch/sklearn 资源，最后 `os._exit(ret)` 由系统直接回收 | run.py:%s |' % loc('run.py', 'os._exit(ret)'))
A('')
A('### 2.2 三层架构')
A('')
A('```')
A('run.py            入口层：数据库初始化、直接创建主窗口、事件循环')
A('  ↓ from plugins.彩票预测 import LotteryPredictionWindow')
A('plugins/         界面层：彩票预测.py = 主窗口类；TAB/*.py = 各选项卡 build(host)')
A('  ↓ 只调用 lib 导出的函数')
A('lib/             逻辑层：算法、配置、数据库、机器学习、绘图（禁止任何 Qt 代码）')
A('  ↑ 控件全部来自')
A('UI/UI.py            控件总闸：唯一允许 from PyQt6 import 的地方')
A('```')
A('')
A('### 2.3 按钮点击如何到达业务代码')
A('')
A('```')
A('number_sort.py  build(host) 内：')
A('    sort_btn.clicked.connect(host._on_do_number_sort)')
A('        ↓')
A('TAB/number_sort.py:%s  on_do_number_sort(host)' % loc('TAB/number_sort.py', 'def on_do_number_sort'))
A('        ↓  读取输入 → 解析数字 → 计算 → 输出')
A('lib/math_algo.py   纯计算（不碰界面）')
A('```')
A('')
A('`host` 就是主窗口实例：界面层把控件挂到 `host.xxx` 上，主窗口方法再访问 `self.xxx`。')
A('')
A('## 三、`__init__.py` 是干什么用的')
A('')
A('`__init__.py` 把所在目录标记为 **Python 包**（package），使 `import lib` / `import TAB.xxx`')
A('这类导入能够成立。它在包第一次被导入时执行一次，可以放初始化代码。')
A('')
A('本项目共有 4 个 `__init__.py`，作用各不相同：')
A('')
A('| 文件 | 实际作用 | 删掉会怎样 |')
A('|---|---|---|')
A('| `lib/__init__.py` | **不是空文件**：① 在 import numpy 之前设置线程环境变量；② 定义全部懒加载器 `_get_mpl/_get_sklearn/_get_torch...` 与 `HAS_*` 状态变量 | `import lib` 失败，程序无法启动；线程变量失效，可能触发 0xC0000409 |')
A('| `UI/__init__.py` | 转发 `UI.UI` 导出的全部控件，使 `from UI import *` 成立 | 界面层全部 import 失败 |')
A('| `plugins/__init__.py` | 标记 `plugins` 为包，使 run.py 能 `from plugins.彩票预测 import LotteryPredictionWindow`；文件内只有约束说明注释，无代码 | `from plugins.彩票预测 import ...` 失败，程序无法启动 |')
A('| `TAB/__init__.py` | 标记 `TAB` 为包；注释说明各页面导出 `install(host)` / `build(host)` 契约 | `from TAB import number_sort` 失败 |')
A('')
A('## 四、还有哪些「看起来没用、实际在起作用」的隐式机制')
A('')
A('| 机制 | 位置 | 作用 | 误改/误删后果 |')
A('|---|---|---|---|')
A('| 线程数环境变量 | run.py:28-33、lib/__init__.py:23-28 | 限制 BLAS/OpenMP 线程数为 1，防 C 扩展栈溢出崩溃 | 随机闪退 0xC0000409 |')
A('| 懒加载器 `_get_*` + `HAS_*` | lib/__init__.py:52-357 | 启动时只导入 PyQt6，重型库首次用到才加载 | 启动慢 5-10 秒；退出时误触发加载会崩溃 |')
A('| 子模块 `import lib as _core` | lib 各子模块顶部 | 通过模块对象读懒加载后的最新全局值（`from lib import _x` 会拿到旧值 None） | 算法拿到 None 报错 |')
A('| 各 tab 顶部 sys.path 引导块 | 如 number_sort.py:17-28 | 允许「直接运行单个 tab 文件」调试，自动向上找到含 run.py 的根目录 | 单文件调试时 import UI 失败 |')
A('| `_wrap_tabs_in_scroll` | 彩票预测.py:%s | 运行时给每个选项卡套 QScrollArea，源码里看不到这些滚动容器 | 删除后小窗口控件重叠/截断 |' % loc('plugins/彩票预测.py', 'def _wrap_tabs_in_scroll'))
A('| `removeTab` 后再 `insertTab` 的顺序 | 彩票预测.py:%s 起 | 先移除再 setWidget，避免 QStackedWidget 自动删页导致选项卡减半 | 选项卡数量莫名少一半 |' % loc('plugins/彩票预测.py', 'self.tabs.removeTab'))
A('| INI ↔ SQLite `ui_ini` 镜像 | 彩票预测.py:%s / %s、lib/db_helper.py | 配置写 `配置.ini` 的同时镜像进数据库，INI 丢失时自动恢复 | 配置全部丢失 |' % (
    loc('plugins/彩票预测.py', 'def _load_ini_config'), loc('plugins/彩票预测.py', 'def _save_ini_config')))
A('| `host._ini_*` 隐藏状态 | 彩票预测.py:%s 起 | 把 INI 里的索引/尺寸暂存为下划线属性，供界面层 build 时恢复 | 分隔符/尺寸选择不记忆 |' % loc('plugins/彩票预测.py', 'def _load_ini_config'))
A('| QSplitter 尺寸记忆 | 彩票预测.py 配置读写 | 记住分割条位置、表格列宽、字号 | 每次启动布局复位 |')
A('| 三色波常量 | lib/data_process.py:%s 起 | `RED_NUMBERS / BLUE_NUMBERS / GREEN_NUMBERS` 号码分组，波色分析与配色都依赖 | 波色分析结果错乱 |' % loc('lib/data_process.py', 'RED_NUMBERS'))
A('| `_migrate_legacy_data` | 彩票预测.py:%s | 启动时把旧目录数据复制到 `系统v7.5/`，失败不中断 | 老用户数据找不到 |' % loc('plugins/彩票预测.py', 'def _migrate_legacy_data'))
A('')
A('## 五、文件清单（含行数与保护级别）')
A('')
A('| 文件 | 行数 | 职责 | 保护级别 |')
A('|---|---:|---|---|')
for rel, duty, guard in FILES:
    A('| `%s` | %d | %s | %s |' % (rel, line_count(rel), duty, guard))
A('')
A('## 六、关键词定位表（按功能分组）')
A('')
A('### 6.1 启动 / 框架 / 主窗口')
A('')
A('| 关键词 | 文件 | 行号 | 说明 |')
A('|---|---|---:|---|')
emit_kw_table([
    kw_row('程序入口 main()', 'run.py', 'def main():', '初始化应用、数据库、主窗口、事件循环'),
    kw_row('启动日志 PyQt6窗口启动中...', 'run.py', 'PyQt6窗口启动中', '启动首行输出'),
    kw_row('线程数环境变量', 'run.py', "OMP_NUM_THREADS", 'OMP/OPENBLAS/MKL 全部设为 1'),
    kw_row('导入主窗口 LotteryPredictionWindow', 'run.py', 'from plugins.彩票预测 import', '直接导入，不再扫描插件'),
    kw_row('应用名 pyqt窗口 系统v7.5', 'run.py', 'setApplicationName', 'app.setApplicationName（窗口标题另取 WINDOW_TITLE）'),
    kw_row('创建主窗口', 'run.py', 'window = LotteryPredictionWindow', 'window.show() 前'),
    kw_row('数据库初始化完成日志', 'run.py', 'SQLite + DuckDB 初始化完成', 'SQLite + DuckDB'),
    kw_row('事件循环 app.exec', 'run.py', 'app.exec()', 'try/finally 包裹'),
    kw_row('退出清理 os._exit', 'run.py', 'os._exit(ret)', '绕过 Python 模块清理'),
    kw_row('主窗口类 LotteryPredictionWindow', 'plugins/彩票预测.py', 'class LotteryPredictionWindow', '继承 QMainWindow'),
    kw_row('窗口标题常量', 'lib/data_process.py', 'WINDOW_TITLE', 'WINDOW_TITLE="系统v7.5"'),
])
A('')
A('### 6.2 主窗口 / 布局 / 自适应')
A('')
A('| 关键词 | 文件 | 行号 | 说明 |')
A('|---|---|---:|---|')
emit_kw_table([
    kw_row('主窗口类 LotteryPredictionWindow', 'plugins/彩票预测.py', 'class LotteryPredictionWindow', '继承 QMainWindow'),
    kw_row('主窗口 __init__', 'plugins/彩票预测.py', 'def __init__(self):', '窗口尺寸、路径、状态、加载配置'),
    kw_row('初始化完成日志', 'plugins/彩票预测.py', '初始化完成', '系统 v7.5 初始化完成'),
    kw_row('_init_ui 构建界面', 'plugins/彩票预测.py', 'def _init_ui', '顶栏 + 选项卡 + 状态栏'),
    kw_row('_create_top_bar 顶栏', 'plugins/彩票预测.py', 'def _create_top_bar', '导入/导出/保存/字体等按钮'),
    kw_row('_create_tabs 选项卡', 'plugins/彩票预测.py', 'def _create_tabs', '遍历 iter_tab_pages() 自动注册'),
    kw_row('_wrap_tabs_in_scroll 滚动容器', 'plugins/彩票预测.py', 'def _wrap_tabs_in_scroll', '每个页面套 QScrollArea'),
    kw_row('_create_status_bar 状态栏', 'plugins/彩票预测.py', 'def _create_status_bar', '历史记录条数'),
    kw_row('resizeEvent 窗口缩放', 'plugins/彩票预测.py', 'def resizeEvent', '触发字体自适应'),
    kw_row('_apply_autosize 字体自适应', 'plugins/彩票预测.py', 'def _apply_autosize', '0.85~1.15 倍区间'),
    kw_row('窗口最小尺寸常量', 'lib/data_process.py', 'WINDOW_MIN_WIDTH', 'WINDOW_MIN_WIDTH=1180'),
    kw_row('窗口标题常量', 'lib/data_process.py', 'WINDOW_TITLE', 'WINDOW_TITLE="系统v7.5"（全程序唯一标题来源）'),
    kw_row('_on_tab_changed 切换选项卡', 'plugins/彩票预测.py', 'def _on_tab_changed', '图表懒加载'),
])
A('')
A('### 6.3 数字排序 / 数字选尾 / 结果分隔符')
A('')
A('| 关键词 | 文件 | 行号 | 说明 |')
A('|---|---|---:|---|')
emit_kw_table([
    kw_row('数字排序页面 build', 'TAB/number_sort.py', 'def build(host)', '页面构建入口'),
    kw_row('排序分隔符下拉框 sort_sep_combo', 'TAB/number_sort.py', 'host.sort_sep_combo = QComboBox()', '遍历 LotteryConfig.RESULT_SEPARATORS（15 种）+ 自适应宽度'),
    kw_row('排序分隔符选项循环', 'TAB/number_sort.py', 'for sep_text, sep_value in LotteryConfig.RESULT_SEPARATORS', '统一取自 lib/data_process.py'),
    kw_row('排序分隔符保存/恢复', 'TAB/number_sort.py', '_ini_sort_sep_index', '读 host._ini_sort_sep_index'),
    kw_row('排序按钮 _on_do_number_sort', 'TAB/number_sort.py', 'def on_do_number_sort', '排序 + 次数 + 缺失数字'),
    kw_row('排序分隔符切换回调', 'TAB/number_sort.py', 'def on_sort_sep_changed', '即时刷新结果显示'),
    kw_row('数字解析 DataUtils.parse_numbers_text', 'lib/data_process.py', 'def parse_numbers_text', 'NFKC 归一化 + 提取数字串（原 _parse_numbers_from_text，v0.0.28 起迁移至 lib）'),
    kw_row('通用取分隔符 _get_result_separator', 'plugins/彩票预测.py', 'def _get_result_separator', '按下拉框索引取连接符'),
    kw_row('数字选尾页面 build', 'TAB/number_tail.py', 'def build(host)', '页面构建入口'),
    kw_row('选尾分隔符下拉框 tail_sep_combo', 'TAB/number_tail.py', 'host.tail_sep_combo = QComboBox()', '遍历 LotteryConfig.RESULT_SEPARATORS（15 种）+ 自适应宽度'),
    kw_row('选尾分隔符选项循环', 'TAB/number_tail.py', 'for sep_text, sep_value in LotteryConfig.RESULT_SEPARATORS', '与排序共用同一常量'),
    kw_row('选尾执行 _on_do_number_tail', 'TAB/number_tail.py', 'def on_do_number_tail', '按尾数筛选'),
    kw_row('选尾分隔符切换回调', 'TAB/number_tail.py', 'def on_tail_sep_changed', '即时刷新'),
])
A('')
A('### 6.4 大数据分析 / 红绿蓝波色')
A('')
A('| 关键词 | 文件 | 行号 | 说明 |')
A('|---|---|---:|---|')
emit_kw_table([
    kw_row('大数据分析页面 build', 'TAB/bigdata_analysis.py', 'def build(host)', '页面构建入口'),
    kw_row('顶部横幅 _build_banner', 'TAB/bigdata_analysis.py', 'def _build_banner', '标题 + 数据源徽标 + 操作按钮'),
    kw_row('指标参数单行卡 _build_status_row', 'TAB/bigdata_analysis.py', 'def _build_status_row', '参与期数/总记录数/最新期号/波色倾向 + 分析期数 + 三项权重（同一排 8 项）'),
    kw_row('紧凑 KPI 块 _kpi_card', 'TAB/bigdata_analysis.py', 'def _kpi_card', '固定 96×30px，标签与数值同行'),
    kw_row('参数框样式 _style_spin', 'TAB/bigdata_analysis.py', 'def _style_spin', '80×30px，显式覆盖全局 QSpinBox min-height'),
    kw_row('三段分隔条 bd_main_splitter', 'TAB/bigdata_analysis.py', '_apply_splitter_sizes(main_splitter', '默认 230,320,267；首帧后 QTimer 延迟恢复'),
    kw_row('分析按钮 bd_start_btn', 'TAB/bigdata_analysis.py', 'host.bd_start_btn = _action_button', '连接 _on_bigdata_analyze_clicked'),
    kw_row('结果分栏 bd_mid_splitter', 'TAB/bigdata_analysis.py', 'host.bd_mid_splitter = splitter', '生肖卡片 / 号码球矩阵，分隔条尺寸可记忆'),
    kw_row('波色分析卡 _build_wave_area', 'TAB/bigdata_analysis.py', 'def _build_wave_area', '红波/绿波/蓝波 + 分数进度条'),
    kw_row('评分明细卡 _build_detail_area', 'TAB/bigdata_analysis.py', 'def _build_detail_area', '17 行评分卡（一行一卡 + 组内名次）'),
    kw_row('评分卡行 _detail_row_widget', 'TAB/bigdata_analysis.py', 'def _detail_row_widget', '名次徽标 + 档位 + 综合分条 + 频/漏/转三条分项条'),
    kw_row('统计检验卡 _build_stats_area', 'TAB/bigdata_analysis.py', 'def _build_stats_area', 'numpy + scipy 统计结果'),
    kw_row('统计结果文本 bd_stats_label', 'TAB/bigdata_analysis.py', 'host.bd_stats_label = QLabel', '由 format_stats_text 填充'),
    kw_row('结果渲染 render_result', 'TAB/bigdata_analysis.py', 'def render_result', '生肖卡 + 号码球 + 波色卡 + 评分明细卡 + 统计'),
    kw_row('波色卡片样式 wave_style', 'TAB/bigdata_analysis.py', 'wave_style = {', '红#EF4444 绿#16A34A 蓝#2563EB（左侧 4px 粗边）'),
    kw_row('明细行模型 _detail_row_models', 'TAB/bigdata_analysis.py', 'def _detail_row_models', '数字/生肖/波色三类行模型，cells 与旧表 7 列逐格对应'),
    kw_row('BigDataAnalyzer 类', 'lib/math_algo.py', 'class BigDataAnalyzer', '三维加权 + 一阶马尔可夫 + 波色 + 统计'),
    kw_row('analyze 分析入口', 'lib/math_algo.py', 'def analyze(', '窗口/权重/生肖绑定参数'),
    kw_row('_compute_statistics 统计检验', 'lib/math_algo.py', 'def _compute_statistics', '和值/自相关/熵/卡方/CI/Z-score'),
    kw_row('format_stats_text 统计文本', 'lib/math_algo.py', 'def format_stats_text', '【统计检验与趋势】段'),
    kw_row('format_result_text 文本结果', 'lib/math_algo.py', 'def format_result_text', '含【波色分析】与【统计检验与趋势】段'),
    kw_row('三色波常量', 'lib/data_process.py', 'RED_NUMBERS', 'RED/BLUE/GREEN_NUMBERS'),
    kw_row('开始分析事件', 'TAB/bigdata_analysis.py', 'def on_bigdata_analyze_clicked', '调用 BigDataAnalyzer.analyze'),
    kw_row('复制结果事件', 'TAB/bigdata_analysis.py', 'def on_bigdata_copy_clicked', '剪贴板'),
    kw_row('导出结果事件', 'TAB/bigdata_analysis.py', 'def on_bigdata_export_clicked', '写文件'),
])
A('')
A('### 6.5 配置 / INI / 数据库 / 数据目录')
A('')
A('| 关键词 | 文件 | 行号 | 说明 |')
A('|---|---|---:|---|')
emit_kw_table([
    kw_row('配置类 LotteryConfig', 'lib/data_process.py', 'class LotteryConfig', '全部常量集中定义'),
    kw_row('字号选项 FONT_SIZES', 'lib/data_process.py', 'FONT_SIZES', '标准20…初号42'),
    kw_row('默认字号 DEFAULT_FONT_SIZE_KEY', 'lib/data_process.py', 'DEFAULT_FONT_SIZE_KEY', '标准=20'),
    kw_row('文字尺寸上限 TEXT_MAX_PX', 'lib/data_process.py', 'TEXT_MAX_PX', '150px，所有字体钳制'),
    kw_row('按钮尺寸上限 BUTTON_MAX_WIDTH', 'lib/data_process.py', 'BUTTON_MAX_WIDTH', '300×300px'),
    kw_row('按钮默认尺寸 BUTTON_DEFAULT_WIDTH', 'lib/data_process.py', 'BUTTON_DEFAULT_WIDTH', '80×60px'),
    kw_row('默认文字 TEXT_DEFAULT_PX', 'lib/data_process.py', 'TEXT_DEFAULT_PX', '20px'),
    kw_row('统一分隔符 RESULT_SEPARATORS', 'lib/data_process.py', 'RESULT_SEPARATORS', '15 种，排序/选尾共用'),
    kw_row('控件记忆 _save_widget_states', 'plugins/彩票预测.py', 'def _save_widget_states', '[WidgetState] 写入'),
    kw_row('控件恢复 _restore_widget_states', 'plugins/彩票预测.py', 'def _restore_widget_states', '_init_ui 之后恢复 + blockSignals'),
    kw_row('加载配置 _load_ini_config', 'plugins/彩票预测.py', 'def _load_ini_config', '读 系统v7.5/配置.ini + 隐藏状态'),
    kw_row('保存配置 _save_ini_config', 'plugins/彩票预测.py', 'def _save_ini_config', '写 INI + SQLite 镜像'),
    kw_row('程序目录 _get_app_dir', 'plugins/彩票预测.py', 'def _get_app_dir', '源码/exe 都取程序所在目录'),
    kw_row('旧数据迁移 _migrate_legacy_data', 'plugins/彩票预测.py', 'def _migrate_legacy_data', '复制到 系统v7.5/'),
    kw_row('数据库单例 get_db', 'lib/db_helper.py', 'def get_db', 'SQLite 系统v7.5/app_config.db + DuckDB'),
    kw_row('统一数据目录 DATA_DIR', 'lib/db_helper.py', 'DATA_DIR = BASE_DIR', '数据库与 JSON/INI/数据存储同目录'),
    kw_row('旧库迁移 _migrate_legacy_db_dir', 'lib/db_helper.py', 'def _migrate_legacy_db_dir', '启动时把旧 data/ 数据库移入 系统v7.5/'),
    kw_row('历史数据镜像 save_history', 'lib/db_helper.py', 'def save_history', 'history_records 全量覆盖'),
    kw_row('历史数据恢复 load_history', 'lib/db_helper.py', 'def load_history', 'JSON 丢失时兜底'),
    kw_row_as('SQLite 表 ui_ini', 'lib/db_helper.py', '-', '配置镜像（见 docs/config.md）'),
    kw_row_as('SQLite 表 saved_predictions', 'lib/db_helper.py', '-', '已保存预测'),
    kw_row_as('DuckDB 系统v7.5/analysis.duckdb', 'lib/db_helper.py', '-', '分析库（懒加载，按需生成）'),
])
A('')
A('### 6.6 字体 / 样式 / 公告版本号')
A('')
A('| 关键词 | 文件 | 行号 | 说明 |')
A('|---|---|---:|---|')
emit_kw_table([
    kw_row('全局样式表 _update_stylesheet', 'plugins/彩票预测.py', 'def _update_stylesheet', '按字号/主题生成 QSS'),
    kw_row('主题切换 _apply_stylesheet', 'plugins/彩票预测.py', 'def _apply_stylesheet', '清空后重建'),
    kw_row('字体创建 FontUtils', 'TAB/widgets.py', 'class FontUtils', 'QFontDatabase.families() 缓存'),
    kw_row('公告版本号', 'TAB/info.py', '程序版本：', 'search "程序版本："'),
    kw_row('公告功能清单 / 分隔符说明', 'TAB/info.py', '结果分隔符', '15 种分隔符条目'),
    kw_row('控件状态记忆段落', 'TAB/info.py', '控件记忆', '公告页记忆机制说明'),
    kw_row('号码球控件 NumberBallWithZodiac', 'TAB/widgets.py', 'class NumberBallWithZodiac', '数字+生肖+五行'),
])
A('')
A('### 6.7 在线开奖 / 在线增量 / 同期对照')
A('')
A('| 关键词 | 文件 | 行号 | 说明 |')
A('|---|---|---:|---|')
emit_kw_table([
    kw_row('日期归一 normalize_date', 'lib/date_utils.py', 'def normalize_date', 'ISO / 中文 / 斜杠 / 点号 → YYYY-MM-DD；非法日期抛 ValueError'),
    kw_row('站点表读取 load_registry', 'lib/online_sites.py', 'def load_registry', '代码零内置，只读 系统v7.5/在线站点.json'),
    kw_row('站点表保存 save_registry', 'lib/online_sites.py', 'def save_registry', '外部 JSON 写入；enabled_sites 过滤启用项'),
    kw_row('_same_period_loaded 复位点', 'TAB/history.py', '_same_period_loaded = False', '在线库刷新 / 切页时复位，避免读到旧缓存'),
    kw_row('号码校验 validate_numbers', 'lib/same_period.py', 'def validate_numbers', '1–49 不重不漏 + 特别号互斥（在线 / 同期共用）'),
    kw_row('同期年表 build_year_rows', 'lib/same_period.py', 'def build_year_rows', '按开奖日期对齐 + 前缀年份不一致拒收'),
    kw_row('同期汇总 summarize_rows', 'lib/same_period.py', 'def summarize_rows', '一致 / 仅在线 / 仅本地 / 值不同 四状态计数'),
    kw_row('refresh_online_compare 刷新对比', 'TAB/online_compare.py', 'def refresh_online_compare', '抓取后三向只读对比，默认零写入'),
    kw_row('apply_online_conflict 冲突写本地', 'TAB/online_compare.py', 'def apply_online_conflict', '仅手动点选「采用在线」才写盘'),
    kw_row('build_same_period_view 第二视图', 'TAB/same_period_view.py', 'def build_same_period_view', 'QStyledItemDelegate 整表自绘 + 年份 / 期号筛选'),
    kw_row('load_same_period 读取同期', 'TAB/same_period_view.py', 'def load_same_period', '从在线库一次性装载 + 前缀年份校验'),
    kw_row('_http_error 状态码分类', 'lib/online_source.py', 'def _http_error', '403 / 404 / 429 / 5xx → 分类文案'),
    kw_row('blocked_html 拦截识别', 'lib/online_source.py', '_blocked_html_error', 'JSON 接口返回 HTML / 非 JSON 正文时归类「被目标站拦截」'),
])
A('')
A('### 6.8 数据导入 / 期号解析（本轮新增符号）')
A('')
A('| 关键词 | 文件 | 行号 | 说明 |')
A('|---|---|---:|---|')
emit_kw_table([
    kw_row('期号拆分 split_period', 'lib/data_process.py', 'def split_period', '期号原值 → 期序 / 完整期号 / 年份 三字段（唯一口径入口）'),
    kw_row('逐记录特征识别 _parse_record_features', 'TAB/data_import.py', 'def _parse_record_features', '不依赖字段位置：识别日期 / 期号 / 7 个号码'),
    kw_row('期号字段 _period_fields', 'TAB/data_import.py', 'def _period_fields', '期序（展示）/ period_full / period_year（去重用）'),
    kw_row('完整期号 _record_full_period', 'TAB/data_import.py', 'def _record_full_period', '优先 period_full，兼容旧记录'),
    kw_row('入库前收口 _finalize_records', 'TAB/data_import.py', 'def _finalize_records', '缺期号拒绝 + 批内去重（保留最后一次）+ 库内冲突过滤'),
    kw_row('识别报告 _build_report', 'TAB/data_import.py', 'def _build_report', '缺期号 / 合并 / 冲突 / 首条样例 / 推定依据'),
    kw_row('期号自检 _period_is_valid', 'TAB/data_import.py', 'def _period_is_valid', '期序非空且完整期号能拆出年份 + 期序'),
    kw_row('标准输出 _format_normalized', 'TAB/data_import.py', 'def _format_normalized', '日期 - 期序 - 6 正码 - 特别码，两位补零'),
    kw_row('识别标签 _set_detect_label', 'TAB/data_import.py', 'def _set_detect_label', '顶部总结 + 写法分布 + 跳过明细 + 推定依据'),
])
A('')
# 第七章：按选项卡区域定位（按窗口布局逐页索引）
pages = page_registry()

A('## 七、按选项卡区域定位（按窗口布局，逐页索引）')
A('')
A('> 用法：直接搜选项卡标题（如「数字选尾」），或搜页面里的界面文字（如「筛选结果」「未匹配的数字」）。')
A('> 本章按主窗口的窗口布局分区：**7.1 顶部工具栏（第 1 排）、7.2 选项卡总览、7.3 每个选项卡一块（第 2 排起）**。')
A('> 每个区域都给出：文件位置与行号、全部界面文字、控件、函数/类、导入依赖、事件方法。行号由源码自动解析。')
A('')
toolbar = toolbar_info()
A('### 7.1 顶部工具栏区域（窗口第 1 排）')
A('')
if toolbar:
    A('| 定位项 | 位置 |')
    A('|---|---|')
    A('| 构建方法 | `%s:%d` `_create_top_bar` |' % (PLUGIN, toolbar['start']))
    A('| 区域范围 | `%s:%d-%d`（到 `_create_tabs` 之前，共 %d 行） |' % (
        PLUGIN, toolbar['start'], toolbar['end'], toolbar['end'] - toolbar['start'] + 1))
    A('| 调用位置 | `%s:%s` `_init_ui()` |' % (PLUGIN, loc(PLUGIN, 'def _init_ui')))
    A('| 状态栏区域 | `%s:%s` `_create_status_bar` |' % (
        PLUGIN, loc(PLUGIN, 'def _create_status_bar')))
    A('')
    A('**工具栏文字关键词（搜这些文字即可定位到按钮/标签）**')
    A('')
    if toolbar['texts']:
        A('| 关键词 | 文件:行号 |')
        A('|---|---|')
        for value, ln in toolbar['texts']:
            A('| %s | `%s:%d` |' % (value, PLUGIN, ln))
    else:
        A('（未在工具栏区域解析到字面量文本）')
    A('')
    A('**工具栏创建的全部控件（含局部变量，按出现顺序）**')
    A('')
    if toolbar['widgets']:
        A('| 控件 | 类型 | 文件:行号 |')
        A('|---|---|---|')
        for name, cls, ln in toolbar['widgets']:
            A('| `%s` | `%s` | `%s:%d` |' % (name, cls, PLUGIN, ln))
    else:
        A('（未在工具栏区域解析到控件赋值）')
    A('')
    A('**工具栏事件方法（按钮信号 → 方法定义）**')
    A('')
    if toolbar['methods']:
        A('| 方法 | 工具栏内引用行 | 方法定义 |')
        A('|---|---|---|')
        for name, ln, dline in toolbar['methods']:
            A('| `%s` | `%s:%d` | `%s:%s` |' % (name, PLUGIN, ln, PLUGIN, dline))
    else:
        A('（未在工具栏区域解析到方法引用）')
    A('')
else:
    A('（未解析到 `_create_top_bar`，请检查方法名是否被改动）')
    A('')
A('### 7.2 选项卡总览（顺序 = TAB_INFO["order"] 升序，自动加载）')
A('')
A('| 序号 | 选项卡标题 | 页面文件 | TAB_INFO 声明 | 构建入口 install(host) / build(host) | 自动注册位置 |')
A('|---|---|---|---|---|---|')
for idx, page in enumerate(pages, 1):
    # 自包含页面优先标注 install(host)，旧页面仅 build(host)
    entry_name = 'install(host)' if page.get('install_line') else 'build(host)'
    entry_line = page.get('install_line') or page['build_line']
    A('| [%d] | %s | `%s` | `%s:%s` | `%s:%s` `%s` | `%s:%s` 自动加载 |' % (
        idx, page['title'], page['rel'], page['rel'], page['info_line'],
        page['rel'], entry_line, entry_name, PLUGIN, page['addtab_line']))
A('')
if not pages:
    A('（未解析到选项卡：请在 TAB/*.py 顶部声明 `TAB_INFO = {"title": ..., "order": ...}`）')
    A('')

A('### 7.3 逐页索引（每个选项卡一块，按窗口布局顺序）')
A('')
for idx, page in enumerate(pages, 1):
    rel = page['rel']
    A('#### [%d] %s —— `%s`' % (idx, page['title'], rel))
    A('')
    A('| 定位项 | 位置 |')
    A('|---|---|')
    A('| 选项卡序号 / 标题 | `[%d] %s` |' % (idx, page['title']))
    if rel != '-':
        A('| 页面文件 | `%s`（%d 行） |' % (rel, line_count(rel)))
        A('| TAB_INFO 声明 | `%s:%s`（标题 / 顺序 / 启用开关） |' % (rel, page['info_line']))
        A('| 构建入口 | `%s:%s` `%s` |' % (
            rel, (page.get('install_line') or page['build_line']),
            'install(host)' if page.get('install_line') else 'build(host)'))
    A('| 自动注册 | `%s:%s` 遍历 `iter_tab_pages()` 后 `addTab` |' % (PLUGIN, page['addtab_line']))
    A('')

    if rel == '-':
        A('（页面模块未解析到，无法列出本页内容）')
        A('')
        continue

    # 本页函数/类与导入依赖（页面拥有的全部代码单元）
    defs = page_defs(rel)
    imports = page_imports(rel)
    A('**本页函数与类（`def` / `class`）**')
    A('')
    if defs:
        A('| 名称 | 文件:行号 |')
        A('|---|---|')
        for name, ln in defs:
            A('| `%s` | `%s:%d` |' % (name, rel, ln))
    else:
        A('（本页只有 build(host)，未解析到其他顶层函数/类）')
    A('')
    A('**本页导入依赖**')
    A('')
    if imports:
        A('| 导入语句 | 文件:行号 |')
        A('|---|---|')
        for text, ln in imports:
            A('| `%s` | `%s:%d` |' % (text, rel, ln))
    else:
        A('（本页没有模块级导入）')
    A('')

    # 本页文本关键词
    kws = text_keywords(rel)
    A('**本页文本关键词（搜这些界面文字即可跳到该行）**')
    A('')
    if kws:
        A('| 关键词 | 文件:行号 |')
        A('|---|---|')
        for value, ln in kws:
            A('| %s | `%s:%d` |' % (value, rel, ln))
        if len(kws) >= 120:
            A('')
            A('（已达 120 条上限，其余文本请在本页文件内直接搜索）')
    else:
        A('（本页没有可直接搜索的字面量文本）')
    A('')

    # 本页 host 引用：事件方法 / 控件与共享数据
    refs = host_refs(rel)
    methods = [(n, l, host_member_line(n)) for n, l in refs if host_member_line(n) != '-']
    others = [(n, l, host_member_line(n)) for n, l in refs if host_member_line(n) == '-']
    A('**本页事件方法（页面里连接的信号 → 主窗口定义位置）**')
    A('')
    if methods:
        A('| 页面内引用 | 页面行号 | 主窗口定义 |')
        A('|---|---|---|')
        for name, ln, dline in methods:
            A('| `host.%s` | `%s:%d` | `%s:%s` |' % (name, rel, ln, PLUGIN, dline))
    else:
        A('（本页没有连接主窗口事件方法）')
    A('')

    A('**本页控件与共享数据（host 属性）**')
    A('')
    page_widgets = {attr.split('.')[-1]: ln for attr, _cls, ln in widgets(rel)}
    page_assign = host_assignments(rel)
    if others:
        A('| 页面内引用 | 页面行号 | 来源 |')
        A('|---|---|---|')
        for name, ln, _ in others:
            if name in page_widgets:
                origin = '本页创建控件 `host.%s = QXxx()`（`%s:%d`）' % (name, rel, page_widgets[name])
            elif name in page_assign:
                origin = '本页赋值 `host.%s = ...`（`%s:%d`）' % (name, rel, page_assign[name])
            else:
                origin = '本页与主窗口均未见赋值（跨页共享数据或主窗口方法内动态创建）'
            A('| `host.%s` | `%s:%d` | %s |' % (name, rel, ln, origin))
    else:
        A('（本页没有挂载 host 控件/数据属性）')
    A('')

    # 本页创建的全部控件（含局部变量，便于按界面元素定位）
    created = all_widgets(rel)
    A('**本页创建的全部控件（含局部变量，按出现顺序）**')
    A('')
    if created:
        A('| 名称 | 类型 | 文件:行号 |')
        A('|---|---|---|')
        for name, cls, ln in created:
            A('| `%s` | `%s` | `%s:%d` |' % (name, cls, rel, ln))
    else:
        A('（本页未解析到控件创建语句）')
    A('')

A('### 7.4 全局 / 跨页关键词（不属于任何单页，但经常被搜索）')
A('')
A('| 关键词 | 文件:行号 | 说明 |')
A('|---|---|---|')
emit_kw_ref([
    kw_row('系统v7.5（窗口标题）', 'lib/data_process.py', 'WINDOW_TITLE',
           '`LotteryConfig.WINDOW_TITLE`，改窗口标题改这里'),
    kw_row('setWindowTitle 应用标题', PLUGIN, 'self.setWindowTitle',
           '主窗口构造时套用 WINDOW_TITLE（顶部工具栏不再显示标题文字）'),
    kw_row('系统v7.5（数据目录）', PLUGIN, 'self._data_dir = os.path.join',
           '统一运行时数据目录，JSON/INI/数据存储/数据库都在此'),
    kw_row('程序版本号', 'TAB/info.py', '程序版本：',
           '公告页版本行，版本升级必改此处'),
    kw_row('主窗口创建（run.py）', 'run.py', 'window = LotteryPredictionWindow',
           'run.py 直接实例化主窗口，不再扫描插件'),
    kw_row('数据库单例 get_db', 'lib/db_helper.py', 'def get_db',
           'SQLite + DuckDB 双库入口'),
    kw_row('SQLite 库文件 app_config.db', 'lib/db_helper.py', 'SQLITE_PATH',
           '业务库路径常量（系统v7.5/）'),
    kw_row('DuckDB 库文件 analysis.duckdb', 'lib/db_helper.py', 'DUCKDB_PATH',
           '分析库路径常量（系统v7.5/，懒加载按需生成）'),
    kw_row('配置镜像 ui_ini', PLUGIN, "'ui_ini'",
           'INI 全量 JSON 镜像写入 SQLite'),
    kw_row('结果分隔符 RESULT_SEPARATORS', 'lib/data_process.py', 'RESULT_SEPARATORS',
           '15 种分隔符，排序/选尾共用'),
    kw_row('页面契约 install(host) / build(host)', 'TAB/__init__.py', 'build(host)',
           '每个选项卡文件导出 install(host)（推荐）或 build(host)，均返回 QWidget'),
    kw_row('选项卡自动加载 _create_tabs', PLUGIN, 'def _create_tabs',
           '遍历 iter_tab_pages()，无需逐页登记'),
    kw_row_as('选项卡自动加载机制说明', 'docs/选项卡模块化与加载机制.md', '-',
              '自动发现、TAB_INFO 契约、增删/停用页面写法、模板代码'),
])
A('')
A('### 7.5 搜索示例（照着搜就能定位）')
A('')
A('| 搜索词 | 定位结果 |')
A('|---|---|')
A('| `数字选尾` | 7.2 总览表 `[14]` 行 → 7.3「[14] 数字选尾」块；页面文件 `TAB/number_tail.py` |')
A('| `未匹配的数字` | `TAB/number_tail.py:%s`（在 7.3「[14] 数字选尾」块的本页文本关键词表内） |' % loc('TAB/number_tail.py', '未匹配的数字'))
A('| `筛选结果` | `TAB/number_tail.py:%s`（同上，本页文本关键词表内） |' % loc('TAB/number_tail.py', '筛选结果'))
A('| `选择尾数` | `TAB/number_tail.py:%s` 提示文字 + 下方尾数按钮循环 `:%s` |' % (
    loc('TAB/number_tail.py', '选择尾数'), loc('TAB/number_tail.py', 'for i in range(10)'))
)
A('| `导入数据` / `导出数据` / `保存数据` / `A+` | 7.1 顶部工具栏区域：先在「工具栏文字关键词」表找按钮文字，再在「工具栏事件方法」表找回调 → `plugins/彩票预测.py:行号` |')
A('| `顶部工具栏` | 7.1 → `_create_top_bar`（`plugins/彩票预测.py:%s`，区域到 `_create_tabs` 之前） |' % loc(PLUGIN, 'def _create_top_bar'))
A('| `系统v7.5` | `lib/data_process.py:%s`（WINDOW_TITLE）、`plugins/彩票预测.py:%s`（setWindowTitle）、`plugins/彩票预测.py:%s`（数据目录） |' % (
    loc('lib/data_process.py', 'WINDOW_TITLE'), loc(PLUGIN, 'self.setWindowTitle'),
    loc(PLUGIN, 'self._data_dir = os.path.join')))
A('| `分隔符` | `lib/data_process.py:%s`（常量）→ 各页 `*_sep_combo` 控件表 |' % loc('lib/data_process.py', 'RESULT_SEPARATORS'))
A('')

A('### 7.6 主窗口方法分区表（按源码【区域N】注释自动分组）')
A('')
A('主窗口类内用 `# 【区域N】标题` 注释划分源码区块；下表按区块汇总其中 `def` 的位置。')
A('方法增删或移动后，重新运行 `python docs/生成索引.py` 即可刷新（无需手写行号）。')
A('')
A('| 区域 | 起始行 | 方法数 | 方法（行号） |')
A('|---|---|---|---|')
regions = main_window_regions()
if not regions:
    A('（未解析到区域注释：请确认源码中存在 `# 【区域N】标题` 形式的区块注释）')
for title, start, defs in regions:
    cells = '、'.join('`%s`(%d)' % (name, ln) for name, ln in defs) or '—'
    A('| %s | %d | %d | %s |' % (title, start, len(defs), cells))
A('')
if regions:
    A('> 区域标题与方法是源码的镜像：想定位某个方法，先在 7.6 找到它，或直接在搜索里输入方法名（附录十一有全量符号表）。')
    A('')

A('## 八、控件定义位置表（host.控件名 → 文件:行号）')
A('')
A('界面层全部控件都通过 `host.xxx = QXxx()` 挂载，本表由源码自动提取。')
A('')
A('| 控件属性 | 类型 | 文件:行号 |')
A('|---|---|---|')
for rel, _, _ in FILES:
    if not rel.endswith('.py'):
        continue
    if not (rel.startswith('TAB/') or rel == 'plugins/彩票预测.py'):
        continue
    for attr, cls, ln in widgets(rel):
        A('| `%s` | %s | `%s:%d` |' % (attr, cls, rel, ln))
A('')
A('## 九、常见修改场景速查')
A('')
A('| 想改什么 | 改哪里 |')
A('|---|---|')
A('| 增删分隔符选项 | `lib/data_process.py` 的 `LotteryConfig.RESULT_SEPARATORS`（排序与选尾共用，一处改完两页同步） |')
A('| 改分隔符默认值 | `plugins/彩票预测.py:%s` `_get_result_separator` 的默认索引 |' % loc('plugins/彩票预测.py', 'def _get_result_separator'))
A('| 改窗口标题 | `lib/data_process.py:%s` `LotteryConfig.WINDOW_TITLE`（当前「系统v7.5」，全程序唯一来源；顶部工具栏不放标题文字） |' % loc('lib/data_process.py', 'WINDOW_TITLE'))
A('| 改窗口初始大小 | `plugins/彩票预测.py:%s` `resize(1600, 1000)` |' % loc('plugins/彩票预测.py', 'self.resize(1600'))
A('| 改窗口最小尺寸 | `lib/data_process.py:%s` |' % loc('lib/data_process.py', 'WINDOW_MIN_WIDTH'))
A('| 改默认字号 | `lib/data_process.py:%s` `DEFAULT_FONT_SIZE_KEY` |' % loc('lib/data_process.py', 'DEFAULT_FONT_SIZE_KEY'))
A('| 改字号档位 | `lib/data_process.py:%s` `FONT_SIZES` |' % loc('lib/data_process.py', 'FONT_SIZES'))
A('| 改按钮/文字颜色 | `plugins/彩票预测.py:%s` `_update_stylesheet` |' % loc('plugins/彩票预测.py', 'def _update_stylesheet'))
A('| 改波色号码分组 | `lib/data_process.py:101-105` |')
A('| 改波色卡片配色 | `TAB/bigdata_analysis.py:%s` `wave_style` |' % loc('TAB/bigdata_analysis.py', 'wave_style'))
A('| 改分析权重默认值 | `TAB/bigdata_analysis.py:%s` 起三个 QSpinBox 的 setValue |' % loc('TAB/bigdata_analysis.py', 'bd_window_spin'))
A('| 新增一个选项卡 | 新建 `TAB/xxx.py`，导出 `install(host)`（内部先挂事件再 `build(host)`）并声明 `TAB_INFO = {"title": ..., "order": ..., "enabled": True}`，保存即自动出现在选项卡栏（主窗口无需改动）；机制见 `docs/选项卡模块化与加载机制.md` |')
A('| 临时停用某个选项卡 | 在页面 `TAB_INFO` 里把 `"enabled"` 改为 `False`，或文件名加下划线前缀 `_xxx.py`；无需改主窗口 |')
A('| 新增插件 | ~~已取消~~：run.py 直接创建主窗口，新增功能请加 `TAB/xxx.py` 选项卡 |')
A('| 查主窗口某个方法属于哪个区域 | 7.6 主窗口方法分区表（区域 → 方法 → 行号，由源码 `# 【区域N】` 注释自动生成）；方法名也可直接搜索附录十一全量符号表 |')
A('| 改公告版本号 | `TAB/info.py:%s` 中 `程序版本：` 行 |' % loc('TAB/info.py', '程序版本：'))
A('| 改启动日志文字 | run.py %s/%s/%s，彩票预测.py %s |' % (
    loc('run.py', 'PyQt6窗口启动中'), loc('run.py', '[数据库] SQLite'), loc('run.py', '已启动'),
    loc('plugins/彩票预测.py', '初始化完成')))
A('')
A('## 十、修复记录（v0.0.17 控件自适应 / v0.0.18 数据持久化 / v0.0.19 记忆与规范化 / v0.0.20 死代码清理 / v0.0.21 索引分区 / v0.0.24 取消插件机制 + 标题精简）')
A('')
A('### v0.0.24 取消插件机制与标题精简')
A('')
A('| 类型 | 变更 | 修改位置 |')
A('|---|---|---|')
A('| 删除 | `PluginLoader` 类（扫描 `plugins/*.py`、`importlib.util.spec_from_file_location` 动态导入）、`MainWindow` 类（QTabWidget 容器）、文件头 `importlib.util` / `BASE_DIR` / `PLUGINS_DIR` | `run.py` |')
A('| 变更 | 启动链路改为直接导入并实例化主窗口：`LotteryPredictionWindow()` → `window.show()` → `app.exec()`，不再有容器层 | `run.py:%s`（导入）、`run.py:%s`（实例化） |' % (
    loc('run.py', 'from plugins.彩票预测 import'), loc('run.py', 'window = LotteryPredictionWindow()')))
A('| 变更 | 应用名改为 `pyqt窗口 系统v7.5`（窗口标题仍由 `WINDOW_TITLE` 提供「系统v7.5」） | `run.py:%s` |' % loc('run.py', 'setApplicationName'))
A('| 删除 | 文件末尾 `plugin_info = {"name": ..., "cls": LotteryPredictionWindow}` 字典（`run.py` 不再读取） | `plugins/彩票预测.py` 文件末尾 |')
A('| 删除 | 顶部工具栏左侧大标题：「系统 v7.5」`QLabel` + `setObjectName("TitleLabel")` + `addWidget` 三行 | `plugins/彩票预测.py:%s` `_create_top_bar` |' % loc('plugins/彩票预测.py', 'def _create_top_bar'))
A('| 删除 | `#TitleLabel` QSS 规则（大字号 + 加粗 + accent 色），顶栏不再有标题控件 | `plugins/彩票预测.py:%s` `_update_stylesheet` |' % loc('plugins/彩票预测.py', 'def _update_stylesheet'))
A('| 变更 | 窗口标题常量「系统 v7.5」→「系统v7.5」，成为唯一标题来源（`setWindowTitle(WINDOW_TITLE)`） | `lib/data_process.py:%s`；`plugins/彩票预测.py:%s` |' % (
    loc('lib/data_process.py', 'WINDOW_TITLE'), loc('plugins/彩票预测.py', 'self.setWindowTitle')))
A('| 文档 | 2.1 启动链路改为 14 步主窗口直连、7.1 顶部工具栏删除标题控件、7.4 去插件化关键词；README / dev.md / config.md / jiego.md / 功能说明 / 公告说明同步 v0.0.24 | `docs/`、`TAB/info.py` |')
A('')
A('验证（离屏）：`window.windowTitle() == "系统v7.5"`、`tabs.count() == 16`、顶部标签列表无大标题；`python -m compileall -q lib plugins TAB run.py UI` 全通过。')
A('')
A('### v0.0.20 死代码清理')
A('')
A('| 类型 | 变更 | 修改位置 |')
A('|---|---|---|')
A('| 删除类 | `ReportExporter` / `DataValidator` / `DataPreprocessor` + 14 个 `COLOR_*` 常量 | `lib/data_process.py` |')
A('| 删除类 | `StatisticsAnalyzer` / `PatternMatcher` / `TimeSeriesAnalyzer`，`MathUtils` 的 `calculate_mean/median/std/poisson_probability/moving_average` | `lib/math_algo.py` |')
A('| 删除类 | `PredictionOptimizer` / `DeepLearningPredictor` / `EnsemblePredictor`，`save_training_data` / `train_neural_network` / `optimize_hyperparameters` | `lib/ml_model.py` |')
A('| 删除类 | `AdvancedVisualization`、`get_patches_module`、`get_sns_module` | `lib/plot_draw.py` |')
A('| 删除方法 | `delete_config` / `get_func_state` / `fetch_all` / `fetch_one` / `register_dataframe` / `read_csv` / `read_parquet` | `lib/db_helper.py` |')
A('| 删除类 | `ColorUtils` / `PredictWorker` / `MLPredictWorker`、`NumberPanel.highlight_numbers` | `TAB/widgets.py` |')
A('| 删除方法 | `_build_saved_predictions_panel`；`_on_predict_progress` / `_on_ml_predict_progress` | `TAB/prediction.py`、`plugins/彩票预测.py` |')
A('| 清理 | 未使用导入与死属性（`import os` / `pickle` 等真实依赖已核对保留） | 全项目 |')
A('')
A('死代码检测方法：AST 静态扫描（定义引用 / 导入使用 / `host`/`self` 属性）+ 人工复核 `getattr` 与字符串动态调用。')
A('')
A('检测方法：离屏渲染主窗口，遍历全部控件，比较「设定的固定/最大尺寸」与「内容所需 sizeHint」。')
A('')
A('| 问题 | 原因 | 修改位置 | 结果 |')
A('|---|---|---|---|')
A('| [16] 大数据分析页在 1600 宽窗口下仍出现横向滚动条 | 参数行 4 个 QSpinBox + 3 个按钮排成一行，大字体（二号 22pt）下最小宽 1628px | `TAB/bigdata_analysis.py` 改为 QGridLayout 两列 + 按钮独占一行 | 页面最小宽 1648 → 728，横滚消失 |')
A('| [13]/[14] 分隔符下拉框长选项（中文逗号/中文句号/英文句号）显示被截断 | `setFixedWidth(110)` 小于选项文字所需宽度 | `number_sort.py:144-146`、`number_tail.py:186-188` 改为 AdjustToContents + 最小宽 150 | 分隔符选项全部完整显示 |')
A('| 7 个字体 QSpinBox 固定 50px，只显示 1 位数 | 大字体下实际需要 139-147px | `prediction.py` 中 `setFixedWidth(50)` → `setMinimumWidth(50)`（7 处） | 完整显示「20px」 |')
A('| 7 个字体 QSpinBox 固定 80px，被截断 | 实际需要 171px | `prediction.py`/`element.py`/`zodiac.py`/`number_selection.py` 共 7 处改为 setMinimumWidth(80) | 完整显示「20 px」 |')
A('| 期数/排名/跳过 QSpinBox 固定 50-60px 被截断 | 实际需要 96-118px | `prediction.py` 4 处、`history.py` 页码框改为 setMinimumWidth | 数字完整显示 |')
A('| 复制/导出按钮固定高 26px，文字上下被切 | 大字体下按钮需要 46px | `prediction.py` 4 处 `setFixedHeight(26)` → `setMinimumHeight(26)` | 文字完整 |')
A('| 筛选下拉框固定 110px 截断「全部结果」 | 实际需要 130px | `prediction.py:879-880` 改为 AdjustToContents + 最小宽 110 | 完整显示 |')
A('| 数据存储排序框固定高 34px | 实际需要 42px | `data_storage.py:311` → `setMinimumHeight(34)` | 文字完整 |')
A('')
A('保留不动（设计上限，非缺陷）：数字排序/选尾/预测页的结果 QTextEdit 的 `setMaximumHeight`。')
A('其内容超出时由滚动条承载，不会丢字；如需随窗口变高，需同时调整布局 stretch 权重。')
A('')
A('验证：全部启用选项卡离屏渲染（当时 16 个，三页合并后为 14），1600×1000 下**全部页面横向滚动条消失**；')
A('1180×720（最小窗口）下仅 [3] 预测与抽取、[10] 数字与生肖 内容本身超宽，由滚动条承载。')
A('')
A('### v0.0.18 数据持久化与文档修正')
A('')
A('| 类型 | 问题 | 修改位置 |')
A('|---|---|---|')
A('| 文档失效 | 公告页「代码结构指南」仍描述旧的单文件 8008–26667 行结构（实际主文件约 1.26 万行，已拆 lib/ 与 tabs/） | `TAB/info.py` 的 structure_items / region_items / post_items / param_items / modify_items |')
A('| 数据丢失 | 预测记录只存内存，重启即丢 | `彩票预测.py` 新增 `_load_prediction_history` / `_save_prediction_history`，落盘 `系统v7.5/预测记录.json`；三处预测写入 + 清空 + 关窗均保存 |')
A('| 数据未入库 | 历史开奖数据只写 JSON，SQLite 的 user_data 表从未使用 | `lib/db_helper.py` 新增 `history_records` 表与 `save_history` / `load_history`；`_save_data` → `_sync_history_to_db`；`_load_data` 支持从库恢复并重建 JSON |')
A('| 死代码 | `_on_zodiac_combo_changed` / `_on_element_combo_changed` 引用从未初始化的 `self._zodiac_combos` | `彩票预测.py` 区域11 删除这两个方法，方法清单注释同步 |')
A('| 资源释放 | 退出时不关闭 SQLite 连接 | `closeEvent`：落盘预测记录 → 保存 INI → `self._db.close()` |')
A('| 数据位置错位 | INI `[Paths]` 原样回填绝对/相对路径，换目录/换启动目录后数据写到旧位置或当前工作目录 | `_apply_ini_config` 的 `[Paths]` 分支：忽略记录值，统一 `os.path.join(self._data_dir, basename)` 重定位 |')
A('| 无用功能 | 在线更新 / 数据源设置（本地离线场景不可用） | 删除 `_get_data_sources` / `_save_data_sources` / `_test_data_source` / `_on_data_source_setting_clicked` / `_add_data_source` / `_del_data_source` / `_test_selected_source` / `_move_source` / `_on_online_update_clicked`，以及「在线更新」「数据源设置」按钮和 `数据源.json` |')
A('')
A('### v0.0.19 控件记忆、尺寸规范与大数据统计能力')
A('')
A('| 类型 | 变更 | 修改位置 |')
A('|---|---|---|')
A('| 新增 | 通用控件记忆：`[WidgetState]` 前缀键（`c_`/`s_`/`v_`/`b_`/`t_`），启动恢复并阻塞信号 | `plugins/彩票预测.py` `_save_widget_states` / `_restore_widget_states`，`__init__` 在 `_init_ui` 后调用 |')
A('| 补齐 | 分隔条记忆新增 `bd_mid_splitter`（大数据页）与 `stats_splitter`（统计图表页） | `plugins/彩票预测.py` splitter 列表；`TAB/bigdata_analysis.py` / `TAB/statistics_chart.py` 挂 host |')
A('| 新增 | 尺寸规范常量：文字上限 150px、按钮上限 300×300、默认文字 20px、默认按钮 80×60 | `lib/data_process.py` `LotteryConfig`；`TAB/widgets.py` / 插件层全部改为引用常量 |')
A('| 新增 | 分隔符统一为 15 种（新增加号/反斜杠/波浪号/井号），前 11 项顺序不变 | `lib/data_process.py` `RESULT_SEPARATORS`；`TAB/number_sort.py` / `TAB/number_tail.py` |')
A('| 新增 | 大数据第 9 步统计检验（numpy 和值趋势/自相关/信息熵/Z-score/遗漏，scipy 卡方/二项 CI） | `lib/math_algo.py` `BigDataAnalyzer._compute_statistics` / `format_stats_text` / `format_result_text` |')
A('| 新增 | [16] 页面「统计检验与趋势」卡片 | `TAB/bigdata_analysis.py` `_build_stats_area` / `bd_stats_label` / `render_result` |')
A('| 删除 | 在线更新（按钮 + `_on_online_update_clicked` + `urllib`）与数据源设置 | `TAB/data_import.py`、`plugins/彩票预测.py` |')
A('| 重构 | 目录拆分 `UI/`（`UI.py` + `__init__.py`）与根级 `TAB/`（16 页） | 全项目 import 路径 |')
A('| 文档 | 新建 `docs/UI设计规范与记忆机制.md`；README / dev.md / jiego.md / 功能说明 / 公告同步 | `docs/`、`TAB/info.py` |')
A('')

A('## 十一、附录：全部符号索引（class / def）')
A('')
for rel, _, _ in FILES:
    syms = symbols(rel)
    if not syms:
        continue
    A('### %s（%d 行，%d 个符号）' % (rel, line_count(rel), len(syms)))
    A('')
    A('| 行号 | 类型 | 名称 | 层级 |')
    A('|---:|---|---|---|')
    for ln, kind, name, level in syms:
        lv = '模块级' if level == 0 else '类方法' if level == 1 else '嵌套'
        A('| %d | %s | `%s` | %s |' % (ln, kind, name, lv))
    A('')

os.makedirs(os.path.dirname(OUT), exist_ok=True)  # 作用：确保输出目录存在；exist_ok=True 使重复生成不报错（传临时路径到不存在的目录时也能自建）
with open(OUT, 'w', encoding='utf-8') as f:  # 作用：一次性覆盖写入；UTF-8 是索引内中文正常显示的前提，'w' 覆盖模式保证旧内容不会残留
    f.write('\n'.join(L))
print('已生成:', OUT, '行数:', len(L))  # 输出到终端，便于批处理确认写到了哪个路径

# 定位结果汇总（未解析条目不阻断生成，退出码保持 0）
_total = STATS['total']
_resolved = STATS['resolved']
_missing = len(UNRESOLVED)
print('[索引统计] 关键词定位条目 %d / 已解析 %d / 未解析 %d' % (_total, _resolved, _missing))
if UNRESOLVED:
    print('[未解析条目] 以下条目不写入索引，请核对目标符号是否已删除或改名：')
    for _kw, _rel, _needle, _why in UNRESOLVED:
        print('  - 关键词「%s」｜期望文件 %s｜定位文本 %s｜原因：%s' % (_kw, _rel, _needle, _why))
if _total and (_missing / _total) > 0.05:
    # 5% 是经验阈值：少量符号改名属正常迭代，一旦超过 5% 通常意味着整块源码被重构，
    # 此时关键词表已大面积失效，需集中排查而不是逐条修
    print('【警告】未解析条目占比 %.1f%%（超过 5%% 阈值），关键词表可能大面积失效，请集中排查。'
          % (_missing / _total * 100.0))

