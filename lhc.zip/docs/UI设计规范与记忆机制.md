# UI 设计规范与记忆机制（v0.0.19）

> 本文件是界面开发的强制规范：新增/修改任何控件、分隔条、表格、配置时都必须遵守。
> 常量集中定义在 `lib/data_process.py` 的 `LotteryConfig` 中，业务代码只引用常量，不再散落硬编码像素值。

## 一、像素尺寸规范

| 项目 | 常量 | 值 | 说明 |
|---|---|---|---|
| 文字最大字号 | `LotteryConfig.TEXT_MAX_PX` | 150 px | 任何字体输入框、字体设置的上限 |
| 按钮最大宽度 | `LotteryConfig.BUTTON_MAX_WIDTH` | 300 px | 面板尺寸对话框、按钮 clamp 的上限 |
| 按钮最大高度 | `LotteryConfig.BUTTON_MAX_HEIGHT` | 300 px | 同上 |
| 文字默认字号 | `LotteryConfig.TEXT_DEFAULT_PX` | 20 px | 初始默认文字大小 |
| 按钮默认宽度 | `LotteryConfig.BUTTON_DEFAULT_WIDTH` | 80 px | 初始默认按钮宽度 |
| 按钮默认高度 | `LotteryConfig.BUTTON_DEFAULT_HEIGHT` | 60 px | 初始默认按钮高度 |
| 全局默认字号键 | `LotteryConfig.DEFAULT_FONT_SIZE_KEY` | `'标准'` | 对应 `FONT_SIZES['标准'] = 20` |

### 执行位置

- `TAB/widgets.py`：`FontUtils.create_font`、`NumberPanel.set_button_size`、
  `ZodiacNumberPanel.set_font_size`、`AttributeMatrixPanel.set_font_size`、`ZodiacHighlightBar`
  均按上述上限做 `min()` 钳制，宽高按 `BUTTON_MAX_*` 钳制。
  五行页已改为「分组条 + 粘贴输入」布局，不再使用独立的五行号码面板。
  **生肖页自 v0.0.74 起改用 `AttributeMatrixPanel` + `ZodiacHighlightBar`；旧 7×7 `ZodiacNumberPanel` 已不再使用，但类完整保留，可一行切回做回滚，其 `set_font_size` 口径仍受本节约束。**
- `plugins/彩票预测.py`：`_update_stylesheet`（全局字号上限）、`_change_area_font_size`（各区域字号）、
  `_show_panel_settings_dialog`（宽/高/标签宽高的 `setRange` 全部改用常量）。
- `TAB/prediction.py` / `zodiac.py` / `element.py` / `number_selection.py`：
  字体 `QSpinBox` 的 `setRange(..., 150)` 表示 150px 上限；默认值 20。
- 新增按钮/文字控件时：字体上限写 `LotteryConfig.TEXT_MAX_PX`，
  按钮尺寸上限写 `LotteryConfig.BUTTON_MAX_WIDTH/HEIGHT`，默认值写 `BUTTON_DEFAULT_*`。

### 字体族 / 字重 / 颜色规范（v0.0.48）

| 项目 | 规范 | 落实位置 |
|---|---|---|
| 字体栈 | `Microsoft YaHei` → `SimHei` → `SimSun` → `Arial`，全部为 Windows 自带，禁止引入需下载的字体文件 | 全局 QSS `QWidget { font-family: "Microsoft YaHei", "SimHei", "SimSun", Arial, sans-serif; }`；`FontUtils.FONT_FAMILIES` / `create_font` |
| 正文字重 | 至少 Medium(500)，不能停在 Normal(400) | QSS `font-weight: 500` + `QFont.setWeight(QFont.Weight.Medium)`（Qt 与 QSS 两处都要设，只设一处会无效） |
| 强调字重 | 标题、号码、策略名、版本号、表头、选中 tab 用 Bold(700) | QSS `font-weight: 700/bold` + `QFont.Weight.Bold`；粗体时同时 `setBold(True)` |
| 非粗体注意 | 非粗体时不要调用 `QFont.setBold(False)`：它会把字重重置回 Normal(400)，抵消已设的 Medium | `FontUtils.create_font`、`_number_strategy_mono_font` 仅在 bold 分支调用 `setBold` |
| 亮色正文 | `#1A1A1A`（接近纯黑）；次要文字 `#444444`；白底对比度 17.40:1 / 9.74:1 | `_update_stylesheet`、`refresh_number_strategy_styles`、`_number_card_theme` |
| 暗色正文 | `#F5F5F5`（接近纯白）；次要 `#D0D0D8`；文本底 `#1E1E2E`、卡片底 `#313244`，对比度 15.04:1 / 8.20:1 | 同上；特别码暗色 `#FF6B6B`（对 `#1E1E2E` 5.91:1） |
| 字号下限 | 任何路径不得低于 15px，既有 `max(15, ...)` 逻辑保持 | 全项目 |

- 字体族探测结果由 `FontUtils._cached_font_family` 进程内缓存；运行中安装新字体需重启才生效。
- 等宽对齐区（号码预测文本列表）仍用 NSimSun 字符格式，不改 `font-family`，只按上述字重与颜色规范着色。

## 二、多格式分隔符

统一常量：`LotteryConfig.RESULT_SEPARATORS`（共 15 项，顺序稳定，兼容旧 INI 记忆索引）。

| 序号 | 显示名称 | 实际分隔符 |
|---:|---|---|
| 0 | 空格 | `" "` |
| 1 | 英文逗号（,） | `","` |
| 2 | 顿号（、） | `"、"` |
| 3 | 分号（;） | `";"` |
| 4 | 减号（-） | `"-"` |
| 5 | 正斜杠（/） | `"/"` |
| 6 | 竖线（\|） | `"\|"` |
| 7 | 换行（\n） | `"\n"` |
| 8 | 中文逗号（，） | `"，"` |
| 9 | 中文句号（。） | `"。"` |
| 10 | 英文句号（.） | `"."` |
| 11 | 加号（+） | `"+"` |
| 12 | 反斜杠（\\） | `"\\"` |
| 13 | 波浪号（~） | `"~"` |
| 14 | 井号（#） | `"#"` |

- 输出侧：`TAB/number_sort.py`（`sort_sep_combo`）、`TAB/number_tail.py`（`tail_sep_combo`）
  直接遍历 `RESULT_SEPARATORS` 生成下拉项；选中索引记入 `配置.ini` `[Display]` 的
  `sort_sep_index` / `tail_sep_index`，重启恢复。
- 输入侧：`_parse_numbers_from_text` 使用 `unicodedata.normalize('NFKC')` + `re.findall(r'\d+')`，
  上述分隔符、全角数字、引号括号等任意符号均可混合作为分隔。
- 新增分隔符只需在 `RESULT_SEPARATORS` 末尾追加，界面与记忆自动生效（勿插入中间，避免旧索引错位）。

## 三、记忆功能（控件 / 功能 / 分隔条 / 表格 / 配置）

### 3.1 通用控件状态：`配置.ini` → `[WidgetState]`

由 `LotteryPredictionWindow._save_widget_states` / `_restore_widget_states` 自动完成：

| 前缀 | 控件类型 | 记忆内容 | 示例 |
|---|---|---|---|
| `c_` | `QComboBox` | 当前索引 | `c_algorithm_combo=3` |
| `s_` | `QSpinBox` | 当前数值 | `s_bd_window_spin=100` |
| `v_` | `QSlider` | 当前数值 | `v_xxx=50` |
| `b_` | `QCheckBox` / `QRadioButton` | 勾选状态 `1/0` | `b_enhanced_mode_checkbox=1` |
| `t_` | `QTableWidget` | 各列宽度（逗号分隔） | `t_history_table=70,120,160,...` |

- 键名 = 主窗口属性名。只要控件挂在 `self` 上（如 `host.xxx = ...`），无需额外代码即可被记忆。
- 保存时机：每次 `_save_ini_config()`（拖动分隔条、切换下拉、调整数字框、关窗等）自动写入。
- 恢复时机：`__init__` 中 `_init_ui()` → `_apply_panel_sizes_to_ui()` → `_restore_widget_states()`。
  恢复时阻塞信号，避免触发副作用与重复写盘；随后手动同步复选框对应的内部开关
  （`enhanced_mode` / `deterministic_mode` / `_use_model_cache` / `_block_no_new_data`）与算法说明文字。
- 写盘门闩（v0.0.41）：`__init__` 在 `_init_ui()` 前置 `_ini_write_enabled = False`，`_restore_widget_states()` 后置 True。
  UI 构建期（如概率面板首次刷新）会调用 `_save_ini_config()`，此时控件还是默认值，若先于恢复写盘会把默认值覆盖回
  INI 与内存 `self._ini`，导致记忆值重启后丢失；门闩关闭期间 `_save_ini_config()` 直接返回 False。

### 3.2 分隔条

- 主窗口属性名统一登记在 `_save_ini_config` 的 `splitter_list` 与 `_apply_ini_config` 的 `splitter_names`：
  `data_import_splitter`、`pred_h_splitter`、`pred_left_v_splitter`、`history_h_splitter`、
  `history_left_v_splitter`、`history_right_v_splitter`、`seventh_pred_splitter`、
  `zodiac_h_splitter`、`element_h_splitter`、`element_v_splitter`、`bd_mid_splitter`、
  `bd_main_splitter`、`stats_splitter`、`storage_splitter`、`number_pred_splitter`（v0.0.41 新增）。
- 页面构建时必须 `host.xxx_splitter = splitter` 并调用 `host._apply_splitter_sizes(splitter, '名称')`，
  该方法恢复位置并连接 `splitterMoved` → 自动保存。
- 恢复校验（v0.0.30）：只要求「保存栏数 == 当前栏数」且每栏 ≥30px。不再限制「每栏 ≥ 总量 25%」——
  用户把分隔条拖到 3:1 甚至 4:1 都是合法操作，旧比例规则会把这类记忆值判为无效并强制回默认。
- 保存策略（v0.0.32）：`_save_ini_config` 先写入当前值，再回填旧 `[Display]` 中未显式写出的键，
  避免整份重写时丢掉分隔条记忆；页面不可见时（`splitter.isVisible()` 为 False）不写当前值，保留上次真实拖动结果。
- 首帧重排（v0.0.34）：QSplitter 在页面首次显示时会按子控件 sizeHint 重新分配，构建期调用的
  `setSizes()` 会被覆盖（实测 `230,320,267` 变成 `239,416,162`，评分明细被压到最小高度）。
  因此构建期 `setSizes()` 之后必须再延迟一帧恢复：`QTimer.singleShot(0, ...)`，且仅在
  `splitter.isVisible() and splitter.height() > 0` 时写入；同时监听 `host.tabs.currentChanged`，
  每次切回本页都恢复一次。不要用 `setStretchFactor` 代替，它会让首帧尺寸按 stretch 重算。
- 初始化期 `splitterMoved`：布局阶段也会触发该信号，必须用就绪标志（如 `_bd_ready`）过滤，
  只有延迟恢复成功后才开始记录用户拖动，否则会把中间态尺寸当成用户意图反复写回。
- 新增分隔条：挂到 `host` → 调用 `_apply_splitter_sizes` → 把名称加入上述两个列表。

### 3.3 表格

- 历史记录表：`[Display] history_col_0..8`；预测记录表：`[Display] prediction_col_0..3`。
- 其他表格：`[WidgetState] t_<属性名>`，恢复时校验列数与保存值一致才应用。
- 列宽上限不套用按钮 300px 规则（表格列可随内容更宽）。

### 3.4 配置

- 业务配置仍保存到 `配置.ini`（`[General]` / `[Paths]` / `[Display]` / `[Zodiac]` / `[Elements]` / `[Weights]` / `[WidgetState]`），
  并整体以 JSON 镜像写入 SQLite `app_config` 表的 `ui_ini` 键；INI 丢失时自动从数据库恢复。
- `[Paths]` 仅作旧版兼容：启动时忽略记录的绝对路径，统一重定位到 `程序目录/系统v7.5/`。

### 3.5 记忆项一览

| 类别 | 记忆内容 | 保存位置 |
|---|---|---|
| 窗口 | 宽高、位置 | `[General]` / `[Display] window_x/y` |
| 主题 / 字号 | `is_dark_mode`、`font_size_key` | `[General]` |
| 当前选项卡 | `current_tab_index` | `[Display]` |
| 面板尺寸 | 数字/生肖/五行/预测球宽高与字体 | `[Display]` |
| 区域字体缩放 | 8 个 `font_scale_*` | `[Display]` |
| 数字面板选中 | `selected_numbers` | `[Display]` |
| 分隔条 | 15 组 `*_sizes` | `[Display]` |
| 表格列宽 | 历史/预测记录 + 通用表格 | `[Display]` / `[WidgetState]` |
| 通用控件 | 下拉框、数字框、滑块、复选框 | `[WidgetState]` |
| 数据本身 | 开奖数据、生肖、预测记录 | JSON + SQLite 兜底 |

### 3.6 设置项与 INI 键体系（v0.0.41）

本节把「界面上能调的设置」与「`配置.ini` 里实际落盘的键」一次性对齐。新增控件或新页面时，
对照本节登记键名与保存/恢复时机，未登记即视为未完成。

#### 3.6.1 控件可配置项

| 类别 | 可配置内容 | 落实方式 | 约束 |
|---|---|---|---|
| 宽高 | 最小宽/高、内容自适应、必要的固定尺寸 | `setMinimumWidth/Height`、`AdjustToContents`、`setFixedSize` | 固定尺寸只用于角控件（40px 规范）与图标类按钮；普通控件优先「最小尺寸 + 自适应」，否则字号放大后被裁字 |
| 字体 px | 数字字号、文字字号、说明区字号 | 局部 QSS `font-size: Npx`；等宽文本列表用字符格式锁定 NSimSun | 全局硬性下限 15px，上限 `LotteryConfig.TEXT_MAX_PX = 150`；`setPointSize` 单位是 pt，不能与 px 混用 |
| 属性与样式 | 配色、边框、圆角、内边距、悬停态 | 局部 QSS + 全局主题 | 局部 QSS 不要写 `font-family` / `font-size` 去改写需要等宽对齐的区域，否则等宽字宽/制表位失效、列位错位 |
| 配置参数 | 枚举（算法/排序/分隔符）、阈值（期数/最小样本）、权重、开关 | 下拉 `c_`、数字框 `s_`、滑块 `v_`、复选 `b_` | 枚举只能在末尾追加，不能插入中间，保证旧索引仍指向同一项 |
| 尺寸参数 | 角控件 40px、按钮默认 80×60、面板宽高、行高 | `CORNER_*` 常量、`number_panel_*` / `pred_ball_*`、行高 = 尺寸高度 × 0.6 | 行高下限 `max(字号)+4`、上限 60px；1180×720 下不得出现横向滚动条 |

#### 3.6.2 控件类型 → 记忆前缀 → INI 键 → 保存/恢复时机

| 控件类型 | 记忆前缀 | INI 键命名 | 保存时机 | 恢复时机 |
|---|---|---|---|---|
| `QComboBox` | `c_` | `c_<属性名>`，值 = `currentIndex()` | 每次 `_save_ini_config()`（切换选项卡、拖动分隔条、关窗等） | `__init__` 中 `_restore_widget_states()`，阻塞信号后 `setCurrentIndex` |
| `QSpinBox` | `s_` | `s_<属性名>`，值 = `value()` | 同上 | 同上，`setValue` 前 `blockSignals(True)` |
| `QSlider` | `v_` | `v_<属性名>`，值 = `value()` | 同上 | 同上 |
| `QCheckBox` / `QRadioButton` | `b_` | `b_<属性名>`，值 `1/0` | 同上 | 同上，恢复后手动同步对应内部开关 |
| `QTableWidget` | `t_` | `t_<属性名>`，值 = 各列宽逗号分隔 | 同上 | 同上，列数与保存值一致才应用 |

其余非控件类设置（不走 `[WidgetState]` 自动扫描）：

| 设置项 | 键名规则 | 所在段 | 保存时机 | 恢复时机 |
|---|---|---|---|---|
| 窗口宽高 | `window_width` / `window_height` | `[General]` | 关窗 / `_save_ini_config()` | `__init__` → `_apply_ini_config()` |
| 窗口位置 | `window_x` / `window_y` | `[Display]` | 同上 | 同上 |
| 主题 | `is_dark_mode` | `[General]`（`[Display]` 保留镜像） | 切换主题 / 保存配置 | 同上 |
| 全局字号档位 | `font_size_key` | `[General]` | 顶部字号切换 | 同上 |
| 当前选项卡 | `current_tab_index` | `[Display]` | 切换选项卡 | `_init_ui` 之后 `setCurrentIndex` |
| 面板尺寸 | `number_panel_width/height/font`、`zodiac_panel_*`、`element_panel_*`、`pred_ball_*`、`legend_*`、`detail_label_*` | `[Display]` | 尺寸对话框确定 / `_apply_panel_sizes_to_ui` 后保存 | `_apply_ini_config()` → `_apply_panel_sizes_to_ui()` |
| 生肖页属性矩阵尺寸（v0.0.74） | `zodiac_panel_width` / `zodiac_panel_height` / `zodiac_panel_btn_font` / `zodiac_panel_label_font`；出厂= `90 / 98 / 28 / 15`（旧 7×7 为 `80 / 60 / 20 / 20`）；一次性迁移标记 `[Display] attr_matrix_v1=1` | `[Display]` | 尺寸对话框确定 / `_apply_panel_sizes_to_ui` 后保存 | `_apply_ini_config()` → `_apply_panel_sizes_to_ui()` → `migrate_attr_matrix_size()`（只在旧出厂组合上改写内存，不直接写盘） |
| 生肖页高亮条选中（v0.0.74） | 不落盘：`ZodiacHighlightBar.active_zodiac()` 仅会话内状态，不写 `[WidgetState]` / INI | — | — | 页面重建后回到未选中态 |
| 分隔条 | `<splitter 属性名>_sizes`（如 `pred_h_splitter_sizes`） | `[Display]` | `splitterMoved` / 每次保存；页面不可见时不写当前值 | `_apply_splitter_sizes()`（构建页面时） |
| 区域字体缩放 | 8 个 `font_scale_*`：`table` / `result` / `list` / `number_panel` / `zodiac_panel` / `element_panel` / `announcement` / `detail` | `[Display]` | 区域字号调整 | `_apply_ini_config()` |
| 表格列宽（专用） | `history_col_0..8`、`prediction_col_0..3` | `[Display]` | 列宽变化 / 保存配置 | `_apply_ini_config()` → 列宽应用方法 |

#### 3.6.3 新增功能必须同步登记

1. 新控件挂到 `host`（`host.xxx = ...`）——只有挂到主窗口实例才会被 `_save_widget_states` 自动扫描；
   键名就是属性名，不要手工另造一套 `[WidgetState]` 键。
2. 新分隔条挂到 `host` → 调用 `host._apply_splitter_sizes(splitter, '<名称>', 默认尺寸)`
   → 把名称同时加进 `_save_ini_config` 的 `splitter_list` 与 `_apply_ini_config` 的 `splitter_names`。
3. 新页面/新面板若改变布局比例，确认恢复时机在 `_init_ui()` 之后，并遵守「隐藏页不写当前值」策略。
4. 在本文档 3.6.2 / 3.6.4 / 3.6.5 登记实际键名，并在 `docs/彩票预测系统-功能与设计说明.md` 对应章节写一句指向本节。
5. 改完运行 `python docs/生成索引.py` 与 `python docs/生成目录树.py --check`，并做一次重启恢复实测。

#### 3.6.4 样板：号码预测（v0.0.39 新增，v0.0.41 补齐记忆与联动，v0.0.48 双视图记忆，v0.0.49 结果回填）

| 控件 / 设置 | 类型 | 键名 | 说明 |
|---|---|---|---|
| `number_pred_window_spin` | `QSpinBox` | `s_number_pred_window_spin` | 分析期数 30~500，默认 100 |
| `number_pred_view_combo` | `QComboBox` | `c_number_pred_view_combo` | **v0.0.48** 视图切换：0=文本列表（默认）、1=卡片视图；恢复后由 `_sync_number_strategy_view_state` 的 `singleShot(0)` 同步 `QStackedWidget` 页 |
| `number_pred_hide_labels_check` | `QCheckBox` | `b_number_pred_hide_labels_check` | **v0.0.48** 只显示号码：`0`=显示生肖五行标签（默认）、`1`=只显示号码；恢复后同步 `_number_strategy_hide_labels` |
| `number_pred_splitter` | `QSplitter` | `number_pred_splitter_sizes`（`[Display]`） | 上列表 / 下说明区，默认 `[310,300]`，隐藏页不写当前值；键名未随 v0.0.48 改动 |
| `pred_num_font_spin` | `QSpinBox`（角控件，页面共用） | `s_pred_num_font_spin` | 数字 px，控制正码与特别码 |
| `pred_text_font_spin` | `QSpinBox`（角控件，页面共用） | `s_pred_text_font_spin` | 文字 px，控制策略名、加号与说明区 |
| `number_pred_text` | `QTextEdit`（只读展示） | 不记忆 | 纯展示，不纳入 `[WidgetState]`；**v0.0.49** 内容随生成结果写入 `上次预测_号码预测.json`，启动按数据指纹回填 |
| `number_pred_detail` | `QTextEdit`（只读展示） | 不记忆 | 同上；选中行由回填的 `selected_index` 决定 |
| `number_pred_generate_btn` | `QPushButton` | 不记忆 | 动作按钮，不属五类可记忆控件 |
| `number_pred_copy_btn` | `QPushButton` | 不记忆 | **v0.0.48** 复制当前视图的等价文本 |
| `number_pred_status_label` | `QLabel` | 不记忆 | 只读状态提示，不属五类可记忆控件；**v0.0.49** 用于显示「已恢复上次生成结果」或「上次结果的数据已变化，需重新生成」 |
| `上次预测_号码预测.json` | 运行时 JSON | 不在 INI，单独文件 | **v0.0.49** 七策略结果 + `data_fingerprint` + `selected_index`；生成成功即写、chip/行切换只改选中项，重启由 `load_number_strategy_prediction` 回填 |

#### 3.6.5 生肖页属性矩阵尺寸键与迁移标记（v0.0.74 / v0.0.75）

| 项目 | 规范 |
|---|---|
| 尺寸键 | `[Display] zodiac_panel_width / zodiac_panel_height / zodiac_panel_btn_font / zodiac_panel_label_font`；出厂 `90 / 98 / 28 / 15` |
| 旧键兼容 | 旧 7×7 面板出厂 `80×60 / 20/20`（`label_font` 允许 15）在启动时一次性迁移为 `90×98 / 28/15`；只认旧出厂组合，用户自定义值不覆盖 |
| 迁移标记 | `[Display] attr_matrix_v1=1`；迁移只写内存，实际落盘走 `_save_ini_config` 的三触发 + 内容一致跳过闸门 |
| 运行时档位 | 紧凑档（1180 可用宽 882）：列距 **72**、卡 **66×96**、圆径 52、号码 28 / 五行 15 / 表头 15、表头 54；宽档（1600 可用宽 1026）：列距 85、卡 77×115、圆径 58、34 / 17 / 17、表头 64。卡宽由可用宽度反算，配置值只作上限 |
| 滚动条常量 | `_MATRIX_SCROLLBAR_W = 12`（`TAB/widgets.py`）固定预留 12px，与主窗口全局 QSS `QScrollBar:vertical { width: 12px; }` 一致；**改 QSS 滚动条宽度必须同步该常量**，否则会出现 1px 级列距残值（历史 65×96 / 71 即按 17px 预留所致） |
| 统计表字号（v0.0.76） | 右侧生肖统计表生肖列、号码列统一 `setPixelSize(15)`，行高固定 34；1180 档表格 251×289 / 视口 237 / 列宽 82·155，1600 档 382×563 / 视口 380 / 列宽 82·298；两档无横向滚动条，1180 档 12 行 × 34=408 > 视口 289，纵向滚动条 12px 属正常 |
| 回滚 | 7×7 `ZodiacNumberPanel` 类保留；把 `TAB/zodiac.py` build 内两段换回旧面板即可，尺寸键沿用同一组 |

#### 3.6.6 对话框局部控件的记忆合并 `_widget_state_extra`（v0.0.79）

**问题**：`_save_widget_states` 按 `self.__dict__` 前缀（`c_` / `t_` / `b_`）扫描主窗口属性来落盘。生肖「批量编辑」对话框是模态 `QDialog`，内部的 `QComboBox` / `QTableWidget` / `QCheckBox` 并不挂在主窗口上——若为了记忆而把对话框控件挂到 `host`，会带来三个副作用：

1. 对话框每次打开都重建，挂 `host` 会让旧对象滞留、泄漏；
2. 属性会进入自动扫描，导致**用户从未打开对话框**时也被写入默认值，甚至覆盖既有键；
3. 控件名与页面控件重名时，扫描顺序不确定，记忆值可能互相覆盖。

**机制**：页面模块在对话框关闭时把「键 → 字符串值」写入 `host._widget_state_extra`（`dict`，缺省不存在）；`plugins/彩票预测.py::_save_widget_states` 在扫描完 `self.__dict__` **之后**、`except` 兜底**之前**，把该字典逐键写进 `[WidgetState]`。4 行合并逻辑不改变既有键，`_widget_state_extra` 为空或不是 `dict` 时整段跳过。

**键与默认值**（生肖批量编辑对话框）：

| 键 | 段 | 默认 | 含义 |
| --- | --- | --- | --- |
| `c_zodiac_batch_preset` | `[WidgetState]` | `0` | 预填档位（0=当前绑定 / 1=清空），读取时钳制到 0–1 |
| `b_zodiac_batch_allow_nonstandard` | `[WidgetState]` | `0` | 「允许非标准数量」复选框，默认关闭；`1` 只放宽 `5+4×11`，覆盖性仍硬查 |
| `t_zodiac_batch_table` | `[WidgetState]` | `70,380,60,110` | 4 个列宽（逗号分隔），解析结果不是 4 个整数时回退默认 |
| `zodiac_batch_dialog_w` | `[Display]` | `700` | 对话框宽，读取时钳制 620–900 |
| `zodiac_batch_dialog_h` | `[Display]` | `660` | 对话框高，读取时钳制 560–700 |

**约束**：`_widget_state_extra` 只承载「不在 `host` 属性树上」的局部控件记忆；普通页面控件仍走 3.6 的「键名即属性名」规则，不得借此绕开自动扫描。对话框尺寸进 `[Display]`（与窗口几何同段），其余进 `[WidgetState]`；只有在用户实际操作过对话框后才写，纯打开关闭不产生新写盘点。

#### 3.7 号码预测两视图间距规范（v0.0.49）

| 区域 | 取值 | 依据 |
|---|---|---|
| 文本视图：号码与号码之间 | 4 个 U+2009 细空格（NSimSun 15px 下约 12px） | 原单个半角空格 8px 视觉过密；4 个细空格≈12px，既明显分隔又不超 1180 宽度 |
| 文本视图：号码与生肖五行标签之间 | 2 个细空格（约 6px） | 阻断 `03虎·木` 粘连，同时与下一个号码保留 12px，层级可辨 |
| 文本视图：24px 档 | 号内 1~2 个、号间 2~3 个细空格 | 24px 档整行最长；按可用宽度收窄，实测 doc 800px < viewport 802px，横向滚动 0 |
| 文本视图：制表位 / 补位 | `setTabStopDistance` 仍按「加粗策略名 + 2 半角空格」；补位用 `horizontalAdvance('\u2009')` | 禁止混排普通空格破坏等宽对齐；四列 x 偏差必须为 0 |
| 卡片视图：卡片块间距 | 24px（原 18px） | 7 张卡不再整屏塞满；1180×720 下允许纵向滚动，内容不贴边 |
| 卡片视图：卡片外边距 | 14px（原 12px） | 与块间距 24px 形成一致呼吸感，避免双重拥挤 |
| 卡片视图：分析卡内边距 / 行距 | 20×18px / 18px | 指标块与 analysis 文本不贴边框 |
| 卡片视图：指标块 / 网格 | 块高 62px、网格间距 16px | 指标两行文字 + 数值不挤压，8 块仍可两列排布 |
| 卡片视图：球区 / chip 行 | 球区最小高 120px、chip 行距 12px、chip 最小高 38px、特别码前 24px | 球与生肖五行说明完整显示，chip 点击区域够大，特别码与正码组有清晰分隔 |

- 卡片的纵向滚动是放宽间距的预期结果，但硬性红线仍是：横向滚动 = 0、控件重叠 = 0、无裁字，七张卡逐一可滚动到且内容完整。

#### 3.8 颜色图例字号与暗色配色（v0.0.59 收口）

**字号下限**（`TAB/prediction.py`）：

| 函数 / 入口 | 作用 | 取值范围 | 约束 |
|---|---|---|---|
| `apply_legend_font_size(host, text_px, num_px)` | 图例说明文字与号码数字两档字号 | 说明文字 `max(15, text_px)`，号码数字 `max(15, num_px)` | 历史 INI 中的 9px 及连续缩小都会被抬到 15px；两档仍各自独立，不合并 |
| `change_legend_font(host, delta)` | 图例 +/- 步进 | 说明文字 15~24px，号码数字 15~22px | 到边界后不再变化，避免越界后又被下限弹回造成「点了没反应/突跳」 |

**明暗主题图例颜色**（`apply_legend_theme_colors`，只改 QSS 的 `color`，不改字号与布局）：

| 语义 | 亮色 | 暗色 | 暗底 `#1E1E2E` 对比度 |
|---|---|---|---|
| 正码红 | `#FF0000` | `#FF6B6B` | 约 5.91:1 |
| 正码蓝 | `#0000FF` | `#89B4FA` | 约 7.79:1 |
| 正码绿 | `#008000` | `#A6E3A1` | 约 11.03:1 |

三组均 ≥ WCAG AA 的 4.5:1；红/蓝/绿波色语义不因主题切换而改变，特别码仍固定走其红色高亮路径。

**`[WidgetState]` 本轮登记键**（完整清单见 3.6.4）：

| 键 | 类型 | 说明 |
|---|---|---|
| `c_number_pred_view_combo` | `QComboBox` | 号码预测视图切换：0=文本列表、1=卡片视图；恢复后经 `singleShot(0)` 同步 `QStackedWidget` |
| `b_number_pred_hide_labels_check` | `QCheckBox` | 只显示号码开关；恢复后同步内部开关 |

新增记忆键仍遵守 3.6.3：控件必须挂到 `host`，键名即属性名，不另造键名。

#### 3.8.1 暗色主题令牌表

来源：`plugins/彩票预测.py` 的 `_update_stylesheet`（全局 QSS 变量）+ 页级暗色补丁（`TAB/number_attributes.py`、`TAB/history.py`、`TAB/prediction.py`）。以下均按现有代码实取，本轮不改代码。

| 语义 | 令牌值 | 使用位置 / 说明 |
|---|---|---|
| 页面底色 | `#1E1E2E` | `bg`：`QWidget` / `QTabWidget::pane` / `QTableWidget` / `QScrollArea` 背景 |
| 卡片 / 控件底 | `#313244` | `card` / `input_bg` / `header_bg`：按钮、输入框、表头、菜单底 |
| 主文字 | `#F5F5F5` | `fg`：正文、按钮、表格、标签；对 `#1E1E2E` 约 15.04:1 |
| 次要文字 | `#A6ADC8` | 占位符、提示、统计表次要列；对 `#313244` 约 5.65:1 |
| 通用边框 | `#45475A` | `border`：按钮（2px）、标签页、表格、菜单等 |
| 输入框边框 | `#7F849C` | `QLineEdit` / `QComboBox` / `QSpinBox` 的 1px 边框与下拉列表边框 |
| 主色 / 聚焦 | `#89B4FA` | `accent`：悬停边框、选中态、输入焦点 |
| 成功色 | `#A6E3A1` | `success`：成功提示、部分勾选指示 |
| 悬停底 | `#45475A` | `hover_bg`：按钮 / 下拉项悬停 |
| 按下底 | `#585B70` | `pressed_bg`：按钮按下 |
| 输入框箭头 | `#CDD6F4` | 数字框上下箭头、下拉框箭头（页级补丁） |
| 禁用态 | 待核对 | 全局 QSS 未单独定义暗色 `:disabled`；`TAB/history.py` / `TAB/prediction.py` 的 disabled 规则均为亮色专用，本轮不新增承诺 |

约束：页级补丁必须复用本表令牌，不得另造近似色；新增令牌先更新本表再接代码。

#### 3.8.2 字号安全上限（H53）

下表为实测得出的安全上限（再放大即出现掉行、裁字或横向滚动），是规范上限而非推荐默认值；默认值仍按各页既有出厂值。

| 页面 / 区域 | 窗口档 | 安全上限 | 触发上限后的现象 |
|---|---|---|---|
| 历史记录（全局字号） | 1180×720 | 不超过小二 18 | 超过即从 6 行掉行 |
| 历史记录（全局字号） | 1600×974 | 不超过一号 26 | 超过即挤压行高 |
| 号码属性（号码 px） | 1180×720 | ≤ 44 | 圆形指示器与卡高失配 |
| 号码属性（文字 px） | 1180×720 | ≤ 64 | 五行单字 / 说明裁切 |
| 号码属性（号码 px） | 1600×974 | ≤ 52 | 同上 |
| 号码属性（文字 px） | 1600×974 | ≤ 80 | 同上 |
| 号码属性（号码 px） | 1830 宽档 | ≤ 60 | 同上 |
| 号码属性（文字 px） | 1830 宽档 | ≤ 100 | 同上 |
| 预测与抽取（号码 px） | 全档 | ≤ 44 | 卡片 / 文本行溢出 |
| 预测与抽取（文字 px） | 全档 | ≤ 64 | 策略名与说明区裁切 |
| 大数据分析（全局字号） | 全档 | 不超过一号 26 | 评分明细挤压、出现滚动 |
| 顶部工具栏 / 字号抽屉 | 全档 | 固定 15px | 不随全局字号放大，维持 1180 档可用宽度 |

说明：本表只定义上限；小于上限的取值也不保证一定不溢出，实际仍以对应页面在 1180×720 / 1600×974 的真实字体引擎实测为准。

#### 3.9 启动只读不写配置与 `[WidgetState]` 记忆机制衔接（v0.0.63 收口）

**原则**：窗口启动阶段**只读** `配置.ini`，不因加载/恢复控件状态而回写磁盘；写盘只发生在用户确实产生新状态之后。

| 触发条件 | 代码路径 | 落盘内容 |
|---|---|---|
| 首次创建（INI 与 SQLite 镜像都不存在） | `_init_default_ini` → `_save_ini_config(force=True)` | 完整默认配置（含 `[Display]`、`[WidgetState]`、`[NumberColors]`） |
| 用户真正改动设置 | 各控件信号 → `_save_ini_config` | 当前完整配置 |
| 用户移动 / 缩放窗口 | `_enable_geometry_tracking` → `moveEvent` / `resizeEvent` 置 `_ini_dirty` → `closeEvent` 落盘 | `[Display]` 的窗口几何与分栏尺寸 |

**不写盘**：纯启动→关闭且 `_ini_dirty == False` 时，`closeEvent` 直接返回；即使进入保存，`_save_ini_config` 会逐字比较「待写文本」与磁盘内容，一致则跳过触盘（同时不写 SQLite 镜像）。

**与 `[WidgetState]` 的关系**：3.6 的记忆键恢复流程（`restore_widget_states`）只修改内存中的控件状态，**不得直接调用保存**；只有用户再次操作该控件时，信号才置 `_ini_dirty`。这样「上次退出时的列宽/视图模式」不会在每次启动时被重新写一遍，也不会覆盖用户手工编辑的 INI。

**缺失键**：`_ensure_ini_defaults` 只在内存 `ConfigParser` 补默认值，不写盘；下次真实保存时随整份配置一起写入。

**缩放也置脏（v0.0.64 修正）**：`resizeEvent` 曾在同名类中定义两次，后者覆盖前者，导致「字号会随窗口重算、但缩放不置 `_ini_dirty`」。v0.0.64 已合并为唯一实现（`super().resizeEvent` → `_apply_autosize()` → 首帧后置脏），**纯缩放与纯移动都会置脏并在关窗时保存新尺寸/位置**；首帧前（`_geometry_tracking == False`）仍不置脏、不写盘。两份原有行为（字号自适应 + 尺寸记忆）同时保留，不留同名桩。

**启动期只读（v0.0.65 扩展）**：除了 `配置.ini`，启动期对 SQLite `func_state` 也不再无谓重写。`_sync_data_state_to_db()` 先读旧行，只比较记录数 / 最新期号 / enabled 三项业务内容，一致则直接返回、不产生写事务；`updated_at` 不参与比较。该表当前无读取方，写库仅为留痕，因此跳过写入不影响任何界面状态恢复。

**新增记忆键仍须遵守**：控件挂到 `host`、键名即属性名、不另造键名；若新增键依赖启动恢复，默认值必须在 `_ensure_ini_defaults` 中登记，否则只存在于内存。

## 四、选项卡右上角控件组规范（数字 px / 文字 px / 尺寸 / 颜色设置）

### 4.1 共用实现（v0.0.36 起）

四个页面（[3] 预测与抽取、[4] 数字选择、[10] 数字与生肖、[11] 数字与五行）的右上角控件组
不再各写一份，统一调用 `TAB/widgets.py` 的共用构建区：

| 常量 / 函数 | 值 / 作用 |
|---|---|
| `CORNER_HEIGHT` | 40，控件统一高度（标签 / 数字框 / 按钮同高） |
| `CORNER_SPACING` | 6，组内相邻控件间距 |
| `CORNER_SECTION_GAP` | 12，「数字」组与「文字」组之间的额外留白 |
| `CORNER_RIGHT_MARGIN` | 8，控件组距选项卡右边缘的留白 |
| `CORNER_SPIN_WIDTH` | 80，数字框宽度（可显示「150 px」） |
| `CORNER_BUTTON_WIDTH` | 68，「尺寸」按钮宽度 |
| `CORNER_FONT_PX` | 15，控件组统一字号（不得低于全局最小字号） |
| `make_corner_container()` | 创建固定 40px 高、右侧留 8px、间距 6px 的容器 |
| `make_corner_label(text, color)` | 创建 40px 高、`AlignVCenter`、15px 加粗的「数字: / 文字:」标签 |
| `style_corner_spin(spin, border_color)` | 数字框固定 80×40、15px、`min/max-height:38px`（+上下 1px 边框 = 40px） |
| `make_corner_size_button(callback, tooltip)` | 「尺寸」按钮固定 68×40、紫色主题、逐属性注释 |
| `add_corner_widget(layout, widget)` | 统一以 `AlignVCenter` 加入容器，保证同一水平基线 |

### 4.2 对齐与内边距规则

- 同一行的控件必须等高：容器固定 40px，子控件也固定 40px，再用 `AlignVCenter` 加入，基线偏差应为 0。
- 标题行里的普通按钮（恢复默认 / 保存绑定 / 一键应用等）不能直接用全局 `QPushButton` 样式：
  全局 `padding:6px 16px` + 2px 边框会让它变成 46px 高，把整行撑高、令「尺寸」按钮看起来下沉 3~6px。
  正确做法是给该按钮加**仅尺寸**的局部样式（`min-height/max-height: 30px; padding: 3px 12px;`），配色与边框仍由全局主题控制。
- 数字框 / 按钮的 QSS `min-height` / `max-height` 是**内容盒高度**，实际高度 = 内容高 + 上下内边距 + 上下边框：
  1px 边框 → 内容 38px = 实际 40px；2px 边框 → 内容 36px = 实际 40px。写 `min-height: 0` 会被父级样式表压缩到 `sizeHint`，禁止使用。
- 内边距建议值：容器右侧 8px、组内 6px、组间 12px；标题行外层 `layout.setContentsMargins` 不小于左 10 / 上 8 / 右 10。
- 四个页面必须使用同一组常量，不要单独调某一页的数值，否则四页基线会不一致。

### 4.3 新增 / 修改控件步骤

1. 在页面 `build(host)` 的标题行调用 `make_corner_container()` 得到 `corner_box, corner_layout`；
2. 依次 `add_corner_widget(corner_layout, make_corner_label(...))`、设置 `spin.setRange(15, 150)` 后
   `style_corner_spin(spin, 主题色)`、`make_corner_size_button(...)`；
3. 需要第二组（文字）时，在两组之间 `corner_layout.addSpacing(CORNER_SECTION_GAP)`；
4. 最后 `top_row.addWidget(corner_box)`，前面保留 `addStretch(1)` 把它推到最右端；
5. 新增同类按钮（如 [4] 的「颜色设置」）时，固定为 `setFixedSize(96, CORNER_HEIGHT)`，
   QSS `min-height/max-height` 按 2px 边框写 36px，保证 40px；不要让它落到全局 46px。
6. 改完运行 `python docs/生成索引.py` 更新行号索引，并按 AI_RULES 同步文档。

### 4.4 颜色设置这类对话框

- 内容页 `setContentsMargins(16, 12, 16, 12)`、`setSpacing(12)`，网格 `hspacing=12` / `vspacing=10`；
- 输入框 / 按钮最小高 40px，同行按钮用 `min-height` 校准到同一实际高度，避免 1~2px 错位；
- 对话框优先 `setMinimumSize + resize`，不要 `setFixedSize`：字号抬升或系统字体变化时允许内容自适应。

### 4.5 字号下限（v0.0.36 硬性要求）

- 界面所有文字最小 15px：样式表写 `font-size: 15px`，`FONT_SIZES` 最小档为 15，`FontUtils.create_font`
  与全局 `_update_stylesheet` 均用 `max(15, …)` 兜底。
- Qt 的 `setPointSize(N)` 单位是 pt（15pt ≈ 20px，不会小于 15px）；样式表 `font-size: Npx` 是像素，两者不要混用。
- 字号调大后必须复测布局：优先拆行、滚动或调容器宽度，不要为了塞下而把字号压回 15px 以下。
- 双源配置不得分裂（v0.0.67）：同一字号若同时来自 `[Display]` 与 `[WidgetState]`（如五行标签 `element_panel_label_font` 与 `s_elem_text_font_spin`），两处默认值与恢复逻辑必须同值，且实际渲染方（面板字典）为准；`_restore_widget_states()` 只改显示值时，读取端必须 `max(15, 值)` 兜底，避免「控件显示 15、实际渲染 12」。

## 五、代码位置

| 内容 | 文件 | 方法/常量 |
|---|---|---|
| 尺寸与分隔符常量 | `lib/data_process.py` | `LotteryConfig.TEXT_MAX_PX` 等 |
| 控件状态保存 | `plugins/彩票预测.py` | `_save_widget_states` |
| 控件状态恢复 | `plugins/彩票预测.py` | `_restore_widget_states` |
| INI 读写 | `plugins/彩票预测.py` | `_load_ini_config` / `_apply_ini_config` / `_save_ini_config` |
| 分隔条记忆 | `plugins/彩票预测.py` | `_apply_splitter_sizes` + `splitter_list` |
| 分隔符下拉框 | `TAB/number_sort.py` / `TAB/number_tail.py` | `RESULT_SEPARATORS` |
| 输入解析 | `plugins/彩票预测.py` | `_parse_numbers_from_text` |
| 字体/按钮钳制 | `TAB/widgets.py` | `FontUtils` / `NumberPanel` 等 |

## 六、控件尺寸与间距标准（v0.0.81 起执行）

| 项 | 标准 | 当前实现 / 核对结果 |
| --- | --- | --- |
| 内容四周留白 | ≥ **16px** | 抽屉实测 20 / 20 / 18 / 22（左/上/右/下） |
| 分组内部间距 | ≥ **10px** | 抽屉分组内部 10px；**角控件组 `CORNER_SPACING=6` 低于本标准**，属既有限制，待后续统一 |
| 分组间距 | **12px** | 抽屉分组间距 12px；角控件 `CORNER_SECTION_GAP=12` |
| 控件高度 | ≥ `QFontMetrics.height() + 4px` | 默认 `SPIN_HEIGHT=40`；大数据参数框例外为 32px（见下） |
| `QSpinBox` 左右 padding | **8 / 24px**（右侧给箭头留 25px） | `SPIN_PADDING_LEFT=8`、`SPIN_PADDING_RIGHT=24` |
| 上下箭头 | **18×18px** | `SPIN_ARROW_WIDTH=18`、`SPIN_ARROW_HEIGHT=18` |
| 关键几何量 | 取 **4 的倍数**（1.25 / 1.5 缩放不产生半像素） | 40 / 44 / 80 / 440 等均为 4 的倍数；**18×18 箭头、46px 历史行高为已定稿例外** |
| 标签字号 | ≥ **15px** | 全局 `FONT_SIZES` 下限 15 |
| 分组标题 | **16–17px Bold** | 抽屉标签 16px、分组标题 17px Bold |

> 落地口径：块级尺寸（容器宽高、控件高、整块间距）优先取 4 的倍数；箭头 18×18 是按「两枚箭头合计 36px ≤ 内容净高 38px」定的，不参与 4 倍数规则。大数据参数框固定 **80×32**（`TAB/bigdata_analysis.py` L1099），是唯一低于 40px 的已定稿例外。

## 七、DPI 三档口径

- **宽度恒定、高度自适应**：显示设置抽屉固定宽 **400px**；高度按布局 `sizeHint`（满配 **618px**，1180 实测 616px、1600 实测 868px），不随 DPI 改变布局，只改变物理像素。
- **物理尺寸 = 逻辑 × DPR**（高度随窗口档位变化，下表给两档参考值）：

| 系统缩放 | DPR | 1180 档抽屉物理尺寸（400×616） | 1600 档抽屉物理尺寸（400×868） |
| --- | ---: | --- | --- |
| 100% | 1.00 | **400×616** | **400×868** |
| 125% | 1.25 | **500×770** | **500×1085** |
| 150% | 1.50 | **600×924** | **600×1302** |

- 字体统一用 `setPixelSize`，不使用 `setPointSize`；点值会随 DPI 二次换算，难以保证三档一致。
- 所有尺寸计算先取整再设置，禁止把浮点结果直接交给 Qt；半像素在 125% / 150% 下会表现为 1px 抖动或边框错位。
- 校验方法：`QWidget.width()` / `height()` 是**逻辑像素**，物理尺寸用 `grab()` 后的 `devicePixelRatio` 换算；三档分别截图核对。

## 八、暗色箭头取色规则

- **不使用 Qt 内置的黑色箭头 PNG**（内置资源在暗色下不可控）。统一用 `QPainter` 现画 **12×12** 三角，按主题色生成并缓存；实现为 `TAB/widgets.py` L209–252 的 `_spin_arrow_paths`（系统临时目录 + 颜色/尺寸键）。
- **实际取色（按代码核对，2026-11-05）**：

| 使用场景 | 亮色实际值 | 暗色实际值 | 依据 |
| --- | --- | --- | --- |
| 字号抽屉 / 全局 QSpinBox | `#1A1A1A` | `#F5F5F5` | `arrow_color=fg`，fg 取主题前景（`plugins/彩票预测.py` L1986–1995） |
| 角控件组数字框 | `#333333` | `#333333`（固定） | `make_corner_spin` 默认 `arrow_color='#333333'`（`TAB/widgets.py` L427） |
| 号码属性暗色输入框 | `#333333` | `#CDD6F4` | `TAB/number_attributes.py` L323 |

- **任务书里的 `#45475A` / `#A6ADC8` 与代码不符**：`#45475A` 是暗色边框/悬停底色，`#A6ADC8` 是暗色次要文字令牌，两者都未用于箭头；以本表实际值为准。
- 新增主题时先查 3.8.1 暗色令牌表，箭头颜色必须与所在输入框的前景/边框令牌一致；禁止硬编码纯黑或纯白。

## 九、数据导入默认口径（固定，不再向用户确认）

以下规则是导入解析的**默认行为**，后续同类问题直接按此执行，不再询问用户。

### 9.1 期号口径（H63）

- **展示**：转换输出 / 预览 / 历史页「期号」列一律显示**期序**，不带年份前缀。标准行示例：
  `2026-11-04 308 25 16 28 08 06 40 + 46`
- **存储**：`period` 存期序（`308`）；另存两个内部副字段：
  `period_full = 2026308`、`period_year = 2026`。年份优先取日期，日期缺失时取期号前缀。
- **去重 / 库内重复**：一律用 `period_full`，禁止用期序，避免 `2025/2026` 的同一期序互撞（H65）。
- **归一化行**：`YYYY-MM-DD` + 空格 + 期序（不定长、不补零）+ 空格 +
  6 正码（两位定宽补零）+ ` + ` + 特别码（两位补零）。
  严格正则：`^\d{4}-\d{2}-\d{2} \d+ (\d{2} ){6}\+ \d{2}$`。

### 9.2 缺期号 / 重复 / 识别

- **缺期号**：默认整批拒绝，列出行号清单；提供「跳过缺期号继续」按钮，用户不点则零写入。
- **批内重复**：保留最后一次并提示合并数；**与库内重复**：不覆盖，只提示（按完整期号判定）。
- **编码 / 分隔符 / 字段顺序**：全部自动识别，不要求用户选择。

### 9.3 宽容解析与可解释

- 同一期里的生肖、五行、`开奖时间:`、序号、括号、广告词、`====` 等一律当噪音丢弃，不算失败。
- 只在**不可逆歧义**时拒绝：两个候选日期、两个候选期号、号码不足 5 个、期号与日期年份冲突。
- 所有推定（特别码取第 7 个、年份取自日期、两位年补 `20xx`）都要在结果面板的「推定依据」区可见，
  同时写入识别标签的 tooltip，禁止静默处理。

### 9.4 结果面板文案

顶部固定一行总结：

`共 N 条 · 成功 X · 跳过 Y（原因分类）· 合并重复 K`

其下用「人话」说明写法分布、跳过原因与行号，例如：

- `识别到 期号在前、日期居中、号码在后（7 条）、日期在前（2 条）；全部解析成功。`
- `有 3 行只有号码、没有期号和日期，默认不导入：第 1、9、17 行。`
- `第 12 行两个期号候选，无法判定：…`

### 9.5 落点

- 代码：`TAB/data_import.py`（`_period_fields` / `_record_full_period` / `_format_normalized` / `_set_detect_label`）。
- 回归：`docs/质检/检查导入解析.py`（期序、完整期号、格式正则、跨年同序不合并）。
- 清单：助手工作台账（`C:\Users\win\.trae-cn\memory\projects\-c-py-lhc--p2-34c7f2c8ed8a44d0cb9e\工作台账.md`）H63 / H64 / H65。
