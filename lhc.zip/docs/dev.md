## 开发规范文档 & Git使用手册 & 版本记录

## 一、界面层开发规范
### 1.1 启动与主窗口
`run.py` 不再扫描插件，直接 `from plugins.彩票预测 import LotteryPredictionWindow` 创建主窗口：
- 主窗口类必须继承 `QMainWindow`、可无参构造，并在 `_init_ui()` 内完成顶栏 + 选项卡 + 状态栏
- 窗口标题取自 `LotteryConfig.WINDOW_TITLE`（当前「系统v7.5」），顶部工具栏不再放标题文字
- 不再需要 `plugin_info` 字典；新增功能一律通过 `TAB/` 选项卡扩展

### 1.2 标准选项卡模板
TAB/xxx.py（声明 TAB_INFO 即自动加载，无需改主窗口）：
```python
from UI import QWidget, QVBoxLayout, QLabel

# 选项卡声明：标题 / 顺序 / 是否启用
TAB_INFO = {
    "title": "示例功能",   # 顶部选项卡栏显示的文字
    "order": 99,          # 显示顺序，数字小的靠前
    "enabled": True,      # 改为 False 可临时隐藏本页
}

def install(host):
    """推荐入口：先绑定本页事件，再构建页面（v0.0.28 起）"""
    host._on_example = lambda: print("示例事件")
    return build(host)

def build(host):
    """构建选项卡页面，控件挂 host.xxx"""
    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.addWidget(QLabel("示例功能界面"))
    return widget
```

### 1.3 选项卡页面规范（TAB/）
- 一个选项卡一个文件，优先导出 `install(host) -> QWidget`（内部先挂事件再调用 `build(host)`）；兼容旧页面 `build(host) -> QWidget`
- 控件挂 `host.xxx`；本页事件优先写在模块内（模块函数 + `install` 里 `host._xxx = lambda ...` 绑定），主窗口同名方法只做 `from TAB.xxx import ...` 兼容转发
- **自动加载**：主窗口 `_create_tabs` 调用 `TAB.iter_tab_pages()`，按 `TAB_INFO["order"]` 排序后 `install(host)`（缺失则 `build(host)`）+ `addTab`；新增页面无需改主窗口
- 停用页面：`TAB_INFO["enabled"] = False`，或文件名加 `_` 前缀；`widgets.py` 与 `__init__.py` 不会被当作页面
- 机制说明、自包含页面模板 → 见 `docs/选项卡模块化与加载机制.md`
- 页面内可直接搜到的界面文字与事件方法行号 → 见 `docs/代码修改索引.md` 第七章

### 1.4 代码注释规范（强制执行）
- ✅ 类、函数顶部必须写文档字符串，说明用途、参数、返回值
- ✅ 界面控件初始化、信号绑定、核心业务逻辑处加行注释
- ✅ 变量命名见名知意，禁止大量无意义单字母变量
- ✅ 复杂逻辑分段，用空行+注释分隔不同功能块

### 1.5 文档生成脚本用法（命令口径）
- 目录树：`python docs/生成目录树.py`（**没有 `--write` 参数，默认运行即写回**）；只比对用 `--check`（有差异退出码 1），只预演用 `--dry-run`。
- 蓝图：`python docs/生成蓝图.py`（**没有任何命令行参数**，直接运行即生成 14 张 PNG 与 `index.html`）。
- 索引：`python docs/生成索引.py`（无参数，直接重写 `docs/代码修改索引.md`）。

## 二、lib 算法库开发规范（方案A：按功能拆分文件）
### 2.1 lib定位
lib/ 是纯逻辑层（library），只负责计算、数据处理、建模、生成绘图数据、数据库操作。
- ✅ 允许：numpy、pandas、scipy、torch、sklearn、optuna、sqlite3、duckdb导入、纯函数、文件读写、数值运算
- ❌ 禁止：任何 PyQt6、窗口、控件、界面交互代码

### 2.2 lib目录拆分
<!-- AUTO-TREE:START -->
```text
lib/
├─ __init__.py        # 懒加载核心：线程环境变量 + 16个重型库加载器 + HAS_* 状态变量
├─ data_process.py    # pandas：配置常量、数据工具、校验、预处理、报告导出
├─ algorithms.py      # 纯Python（无任何依赖）：23个预测算法的唯一注册表（编号/名称/方法/号码数/分类）+ 调度接口
├─ math_algo.py       # numpy、scipy：数学工具、23种预测算法、统计分析、时间序列、大数据分析
├─ plot_draw.py       # matplotlib、seaborn：绘图 + 绘图对象访问器
├─ ml_model.py        # sklearn、statsmodels、optuna、torch：机器学习建模
├─ db_helper.py       # SQLite + DuckDB封装类（DuckDB供[6]/[7]/[14]取数、CSV/Parquet直读；SQLite含storage_items索引镜像）
├─ report_builder.py  # HTML报告构造：批量算法说明页模板 + 逐文件写盘（纯逻辑，无Qt）
├─ online_source.py   # 在线开奖抓取：请求 / 解析 / 新期判断纯逻辑（select_newer / compare_with_local）
├─ online_store.py    # 在线开奖独立库读写（系统v7.5/在线开奖.db，禁止自动合并到本地数据）
├─ same_period.py     # 同期对照纯逻辑（按开奖日期对齐、同期号取来源期号、前缀年份不一致的记录拒收、build_year_rows / summarize_rows）
├─ date_utils.py      # 日期归一纯逻辑（ISO / 中文 / 斜杠 / 点号 → YYYY-MM-DD；非法日期抛 ValueError，不静默改写）
└─ online_sites.py    # 在线站点注册表（代码零内置，只读 系统v7.5/在线站点.json；load_registry / save_registry / enabled_sites / default_site / site_url / match_site / registry_source_type）
```
<!-- AUTO-TREE:END -->

规则：哪个文件需要哪个库，就在当前文件顶部import，不一次性全部加载，实现按需导入。

### 2.3 重型库导入禁令
下面库只允许写在lib内，plugins插件层禁止导入：
- NumPy
- Pandas
- Matplotlib
- Seaborn
- SciPy
- Statsmodels
- Scikit-learn
- Optuna
- Torch(PyTorch)
- duckdb
- sqlite3

### 2.4 分层职责
- ✅ lib层：接收参数 → 计算/数据库处理 → 返回数字、表格、图片等结果
- ✅ plugins层：接收用户输入、展示界面、调用lib函数、展示返回结果
- ✅ lib完全不知道GUI界面存在，和界面解耦

### 2.5 插件调用示例
from lib.data_process import read_csv, drop_null
from lib.math_algo import calc_mean
from lib.db_helper import sqlite_db, duck_db

### 2.6 lib代码注释规范（强制执行）
- ✅ 每个算法函数必须写完整文档字符串：功能、入参类型含义、返回值类型含义
- ✅ 复杂计算公式、统计方法、模型参数必须加注释说明
- ✅ 数据处理步骤分阶段注释，方便后续排查问题
- ✅ 可复用的通用逻辑抽成独立函数，不写大段重复代码

### 2.7 选项卡（页面）拆分规范（TAB/）
- ✅ 一个选项卡一个独立 py 文件，禁止把多个选项卡写进同一文件
- ✅ 每个 tab 模块必须导出入口函数 `install(host) -> QWidget`（先挂事件再构建；旧页可只写 `build(host)`）
- ✅ host 为主窗口实例；控件挂载写 `host.xxx = ...`，公共方法调用写 `host._xxx()`
- ✅ 同一选项卡内部的子面板，在模块内拆为私有函数 `_build_xxx_panel(host) -> QWidget`
- ✅ 自包含页面（全部 16 页，[1]-[16]）的布局、配置、事件绑定全部写在页面文件内；主窗口同名方法仅作兼容转发
- ✅ 共享控件（号码球、号码面板、统计图表、工作线程）统一放在 TAB/widgets.py
- ✅ 新增选项卡：新建 TAB/xxx.py（导出 `install(host)` + 声明 `TAB_INFO`），保存即自动加载
- ✅ 新增/修改代码后，必须按根目录 AI_RULES.md 自动同步目录树、README、dev.md 与 requirements.txt

## 三、数据库开发规范
### 3.1 数据库选型策略
- ✅ SQLite：业务配置、用户记录、插件状态、单条数据增删改查（OLTP）；**历史开奖记录、预测/收藏、INI 镜像都在这里**
- ✅ DuckDB：数据分析、聚合计算、大表查询、CSV/Parquet文件直接分析（OLAP）；**v0.0.23 起由 [6] 统计图表、[7] 回测/算法对比/命中趋势、HTML 报表导出与 [16] 大数据分析统一经 `_analysis_records()` 使用（`history_detail` 明细表 + 按窗口取数），[1] 导入可直读 CSV/Parquet**
- ✅ 分工红线：同一份数据不要两边都做业务写入；SQLite 是业务主存储（含 `storage_items` 索引镜像），DuckDB 只是分析数据集（可随时由内存重建）
- ✅ 各功能的归属清单（哪个选项卡用哪个库）见 `docs/config.md`「各功能数据库使用清单」

### 3.2 强制架构约束
- ✅ 所有数据库封装代码统一放在 lib/db_helper.py
- ✅ plugins插件层禁止直接import sqlite3 / duckdb，只能调用db_helper暴露的实例与函数
- ✅ 数据库文件统一存放于 系统v7.5/ 目录（SQLite `app_config.db` / DuckDB `analysis.duckdb`，v0.0.31 起）
- ✅ 新增数据表、表结构修改统一在db_helper内部实现，不要散落在插件代码

### 3.3 编码规范
- ✅ 所有SQL操作使用参数化，防止SQL注入
- ✅ 函数必须写文档字符串，入参、返回值注释完整
- ✅ 复杂SQL增加注释说明业务含义

## 四、依赖管理规范
根目录 requirements.txt 统一维护全部第三方依赖

### 4.1 安装依赖（清华源，国内高速）
标准安装：
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

单条命令安装全部依赖（不依赖 requirements.txt）：
pip install PyQt6 numpy pandas matplotlib seaborn scipy statsmodels scikit-learn optuna torch duckdb networkx threadpoolctl -i https://pypi.tuna.tsinghua.edu.cn/simple

SSL 证书不信任时的增强命令：
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host pypi.tuna.tsinghua.edu.cn

### 4.2 升级 pip（避免安装报错）
python -m pip install --upgrade pip -i https://pypi.tuna.tsinghua.edu.cn/simple --trusted-host pypi.tuna.tsinghua.edu.cn

### 4.3 依赖清单维护规则
- requirements.txt 只允许包名、版本约束与 `#` 注释；禁止写入说明文字或 pip 安装命令，否则 `pip install -r` 会报 Invalid requirement
- 新增包流程：
  - ✅ 添加包名到 requirements.txt
  - ✅ 更新 README 的依赖说明与快速部署命令
  - ✅ Git提交前缀使用 chore: 或者 docs:
- 重新生成清单（自动导出）：
  pip freeze > requirements.txt
  说明：pip freeze 会导出当前环境全部包（含与本项目无关的包），必须人工剔除无关项、恢复 `#` 注释与可选依赖段后再提交
- 安装清单校验：
  python -m pip install --dry-run --no-deps -r requirements.txt

> torch默认CPU版本，GPU版本需要单独替换安装命令

## 五、版本维护规则（AI自动更新使用）
版本格式 vX.Y.Z
- X：主版本号，架构重大改动升级
- Y：次版本号，新增大类模块、批量功能
- Z：补丁号，新增单个选项卡、算法函数、数据库改动、bug修复、文档优化

版本日志操作规范：
- ✅ 每次有效变更，在版本列表末尾追加记录，绝不删除旧记录
- ✅ 版本记录模板：
### v0.0.2
- ✅ 新增：xxx插件 / xxx算法函数 / 数据表
- ✅ 优化：xxx
- 🐛 修复：xxx问题

- ✅ 追加版本后，同步修改 README.md 的【版本状态】
- ✅ 架构重构才升级主/次版本号，普通新增选项卡、修复bug只升补丁号

## 六、Git 使用完整规范
### 6.1 首次初始化（仅执行一次）
git init
git add .
git commit -m "feat: 初始化项目完整框架"

### 6.2 日常开发流程
git add .
git commit -m "规范描述"
git push

### 6.3 提交前缀规范
- feat: 新增选项卡、新增算法、新增功能、新增文件、新增数据表
- fix: 修复bug、报错
- refactor: 代码重构，逻辑不变
- docs: 修改md文档、说明
- chore: 修改依赖清单、配置、杂项

### 6.4 常用命令
git status    # 查看改动
git log       # 查看提交记录
git pull      # 拉取远程更新

## 七、项目版本迭代记录
### v0.0.1
- ✅ 完成全自动插件加载架构 run.py
- ✅ UI/UI.py 全局控件统一导入
- ✅ lib采用方案A，按功能拆分为4个算法文件，按需导入库
- ✅ 新增 requirements.txt 一键依赖文件
- ✅ 全套三份标准化md文档
- ✅ 完整Git提交规范、版本自动维护规则
- ✅ plugins界面层 和 lib算法层彻底解耦
- ✅ 新增强制代码注释规范，覆盖插件与lib层
- ✅ 增加双数据库方案 SQLite + DuckDB，新增lib/db_helper.py

### v0.0.2
- ✅ 新增：彩票预测插件 plugins/彩票预测.py（彩票预测系统v7.5完整功能：23种预测算法、机器学习预测、第七位预判、统计分析图表）
- ✅ 新增：lib 层算法模块落地 math_algo.py（预测算法集/统计分析/时间序列）、ml_model.py（ML/DL建模）、data_process.py（配置与数据处理）、plot_draw.py（绘图访问器）
- ✅ 新增：lib/db_helper.py 双嵌入式数据库封装实现（SQLite业务存储 + DuckDB分析查询，CSV/Parquet直读）
- ✅ 新增：run.py 插件自动扫描加载核心、UI/UI.py 全局PyQt6控件导入中心落地
- ✅ 新增：networkx、threadpoolctl 依赖
- ✅ 重构：原单文件 v7.5 按分层架构拆分，Qt控件统一经 UI/UI.py 导入，重型库统一在 lib 内懒加载封装

### v0.0.3
- ✅ 重构：15 个选项卡全部按单文件拆分到 TAB/，每文件统一导出 build(host) -> QWidget
- ✅ 重构：「数据导入与格式转换」的内层面板构建（输入面板/结果面板）迁入 tabs/data_import.py
- ✅ 重构：「预测与抽取」的 10 个内层面板构建（左侧数据/算法面板，右侧结果/概率/规律/波色面板等）迁入 tabs/prediction.py
- ✅ 清理：主窗口移除已迁出方法与重复空桩函数，插件主文件 13885 行 → 12406 行
- ✅ 新增：docs/彩票预测系统-功能与设计说明.txt（功能、布局、设计、算法、数据结构、扩展规范全说明）
- ✅ 文档：README / dev.md 同步更新完整项目目录结构

### v0.0.4
- ✅ 新增：[16]「大数据分析」选项卡（TAB/bigdata_analysis.py），基于历史记录推荐 7 个互不重复的生肖与 7 个互不重复的数字
- ✅ 新增：lib/math_algo.py 算法类 BigDataAnalyzer（频率衰减 + 遗漏补偿 + 一阶马尔可夫转移 三维归一化加权评分，生肖分由成员号码综合分与生肖出现强度合成）
- ✅ 新增：主窗口事件处理 _on_bigdata_analyze_clicked / _on_bigdata_copy_clicked / _on_bigdata_export_clicked（分析、复制、导出 TXT）
- ✅ 新增：根目录 AI_RULES.md 硬性指令，要求代码修改、新增模块后自动同步目录树、README、dev.md 与 requirements.txt
- ✅ 优化：分析期数与三项特征权重（频率/遗漏/转移）可在界面实时调整，权重内部自动归一化
- ✅ 文档：README 目录树、选项卡清单、版本状态；本文件版本日志；功能说明文档同步至第 16 个选项卡
- ✅ 依赖：无新增第三方库（仅使用已登记的 numpy/pandas 间接能力），requirements.txt 清单维持不变

### v0.0.5
- ✅ 优化：选项卡页面统一套 QScrollArea（_wrap_tabs_in_scroll），窗口缩小时滚动查看，控件不再拥挤重叠
- ✅ 优化：字体自适应缩放限制 0.85~1.15 倍，窗口最小尺寸 900×600 → 1180×720，标题与 A-/A+ 按钮改为自适应尺寸
- ✅ 新增：数据库真正接入业务（INI 配置镜像 ui_ini、预测记录镜像 saved_predictions、数据概况 func_state），INI/JSON 丢失自动从 SQLite 恢复
- ✅ 新增：db_helper 与 ml_model 路径改为「程序目录」基准，exe 打包后数据随程序目录走；统一数据目录「系统v7.5」
- ✅ 新增：旧数据目录「彩票预测系统v7.5」启动自动迁移，INI 旧路径自动重定位；程序名统一为「系统 v7.5」
- ✅ 修复：数字选尾改为尾数多选（移除单选互斥逻辑）
- ✅ 修复：数字排序/数字选尾多分隔符自动识别，覆盖中英文逗号句号、顿号、分号、冒号、空格、正反斜杠、横线、加号、下划线、等号、井号、竖线、波浪号，可混用
- ✅ 新增：数字排序/数字选尾「结果分隔符」下拉框（空格/逗号/减号），切换即时刷新
- ✅ 修复：滚动容器导致拖拽/粘贴到「数据存储」失效（_is_storage_tab_active 统一判断）
- ✅ 修复：滚动容器包装顺序错误导致选项卡数量减半（先 removeTab 再 setWidget，避免 QStackedWidget 自动移除页面）
- ✅ 修复：SQLite 在虚拟共享目录/网络盘不支持 WAL 时自动回退 DELETE 日志模式重试建表，数据库不再降级失效
- ✅ 优化：全局字体改由 FontUtils.create_font 创建（自动匹配系统可用字体族），字号仍按 0.85~1.15 缩放
- ✅ 新增：补全未接线控件 — 在线更新、数据源设置、计算规律复制/导出、波色结果复制/导出、号码球入场动画、存储统计、预测表格列宽
- ✅ 清理：删除废弃方法 _populate_zodiac_table、_format_file_size_v1_deprecated；修复 _load_zodiac_binding 覆盖 INI 绑定问题并接入启动流程
- ✅ 新增：数据源.json 迁入统一数据目录；数据存储目录改为 系统v7.5/数据存储/；旧版根目录「数据存储」启动时自动迁移
- ✅ 文档：README、本文档、功能说明、公告说明选项卡同步至 v0.0.5

### v0.0.6
- ✅ 文档：重写 docs/jiego.md 项目目录结构速查，由 v0.0.1 旧树（仅 功能一.py）同步至 v0.0.5 现状（lib 5 个模块、plugins/tabs 16 个选项卡、data 双库、系统v7.5 运行时数据目录）
- ✅ 文档：重写 docs/config.md 配置说明，由「无外部配置文件」更正为「配置.ini + SQLite ui_ini 镜像自动恢复」，并按实际 INI 登记 [General]/[Paths]/[Zodiac]/[Elements]/[Weights]/[Display] 全部配置项
- ✅ 文档：README 目录树、文档导航、功能说明第十二章目录对照表补充 jiego.md 条目，config.md 描述同步更新
- ✅ 文档：公告说明选项卡（TAB/info.py）版本号同步至 v0.0.6
- ✅ 无新增第三方依赖，requirements.txt 维持不变

### v0.0.7
- ✅ 新增：数字排序/数字选尾「结果分隔符」下拉框由 3 种扩展为 8 种（空格 / 逗号 / 顿号 / 分号 / 减号 / 斜杠 / 竖线 / 换行），保留默认空格
- ✅ 新增：分隔符选择持久化到 配置.ini 的 [Display] sort_sep_index / tail_sep_index，启动时由选项卡构建函数自动恢复
- ✅ 优化：分隔符索引恢复放在信号连接之前，避免启动时触发无意义的重复计算
- ✅ 文档：README 版本状态、功能说明 [13][14] 能力说明、config.md [Display] 配置清单、公告说明版本号同步至 v0.0.7
- ✅ 无新增第三方依赖，requirements.txt 维持不变

### v0.0.8
- 🐛 修复：requirements.txt 混入说明文字与 `pip install tensorflow` 命令行，导致 `pip install -r requirements.txt` 报 `Invalid requirement`；现改为纯依赖清单，说明统一用 `#` 注释，tensorflow 作为可选依赖以注释形式保留
- ✅ 优化：依赖清单可直接被 pip 解析，安装校验由 `packaging.requirements.Requirement` 解析通过（13 条）
- ✅ 文档：README 版本状态、公告说明版本号同步至 v0.0.8；依赖本身无增删

### v0.0.9
- 🐛 修复：PyQt6 6.x 中 QFontDatabase 不能实例化，启动时 resizeEvent → _apply_autosize → FontUtils.create_font → `QFontDatabase()` 抛 TypeError，程序无窗口退出（0xC0000409）；改用静态方法 `QFontDatabase.families()`
- ✅ 优化：字体族检测结果加入类级缓存，避免窗口缩放时重复查询系统字体库
- ✅ 文档：README 版本状态、公告说明版本号同步至 v0.0.9

### v0.0.10
- 📄 文档：README「环境依赖」新增清华源一键安装命令（标准版 + SSL 证书不信任增强版）与 pip 升级命令
- 📄 文档：dev.md「四、依赖管理规范」拆分为 4.1 清华源安装、4.2 升级 pip、4.3 依赖清单维护规则（含 `pip freeze > requirements.txt` 自动导出与人工筛选说明、`--dry-run` 校验）
- 📄 文档：AI_RULES.md 补充约束新增第 6-8 条（依赖三处同步、requirements.txt 书写约束、pip freeze 仅作参考）
- ✅ 无代码改动，无第三方依赖增删

### v0.0.11
- 📄 文档：docs/彩票预测系统-功能与设计说明.txt 转为 Markdown（.md），标题层级、表格、代码块重排，内容与 v0.0.10 一致
- 📄 文档：同步更新 README、docs/jiego.md、AI_RULES.md 中的文档路径引用；jiego.md 目录树标注更新为 v0.0.11 现状
- ✅ 删除旧 .txt，仅保留 .md 单一文档源，无代码改动、无依赖增删

### v0.0.12
- 📄 文档：README「环境依赖」与 dev.md「4.1 安装依赖」新增单条命令安装全部依赖（13 个包 + 清华源），作为 requirements.txt 之外的等价安装方式
- ✅ 无代码改动、无依赖增删

### v0.0.13
- ✨ 新增：`BigDataAnalyzer.WAVE_GROUPS` 与波色特征计算（红波/绿波/蓝波），analyze() 返回值新增 `waves` 与 `meta.top_wave`
- ✨ 新增：[16] 大数据分析页波色分析区（三张彩色卡片）、评分明细表扩为 17 行（7 生肖 + 7 数字 + 3 波色）、状态栏显示波色倾向
- ✨ 新增：format_result_text 输出【波色分析】段，复制/导出自动包含
- 🐛 修复：明细表用 `'zodiac' in item` 判断生肖，导致数字行被误判并取 `count` 报 KeyError；改为按 `'number'` 键区分三类
- ✅ 文档：功能说明 [16] 章节、README/jiego 目录树注释、公告说明同步；无依赖增删

### v0.0.14
- ✨ 优化：`_parse_numbers_from_text` 改为 NFKC 归一化 + `re.findall(r'\d+')`，支持中英文标点（，。、；：等）、全角数字与任意符号分隔，排序与选尾共用
- ✨ 优化：数字排序/数字选尾结果分隔符由 8 种扩展为 10 种，新增中文逗号（，）与中文句号（。），下拉框宽度 90→110，旧索引 0-7 仍有效
- ✅ 验证：混合标点、全角数字、中文句号输入解析正确；下拉框 10 项与索引记忆恢复正常
- ✅ 文档：功能说明 [13]/[14]、README、config.md、公告说明同步；无依赖增删

### v0.0.15
- ✨ 调整：run.py 启动首行 `PyQt6 插件化工具箱启动中...` → `PyQt6窗口启动中...`
- ✨ 调整：`plugins/彩票预测.py` 的 `plugin_info["name"]` 由「彩票预测系统」改为「系统」，顶层选项卡标题同步；run.py 加载日志格式 `[插件加载] {name}` → `[插件加载]{name}`
- ✅ 实测：完整启动输出顺序与目标一致（7 行）
- ✅ 文档：功能说明「二、启动流程」新增启动控制台输出表（7 条，含输出位置行号）；无功能逻辑变更、无依赖增删

### v0.0.16
- ✨ 优化：数字排序/数字选尾结果分隔符由 10 种扩展为 11 种，新增「英文句号（.）」，索引 10；旧索引 0-9 不变
- ✅ 验证：两个下拉框均为 11 项，索引 10 恢复为「.」，拼接结果形如 `05.12.23`
- ✅ 文档：功能说明 [13]/[14]、README、config.md、公告说明同步；无依赖增删

### v0.0.17
- 🐛 修复：控件不自适应（默认字号「二号」22pt 下大量控件文字被截断）
- ✨ 优化：[16] 大数据分析参数区由单行 QHBoxLayout 改为 QGridLayout 两列 + 按钮独占一行，页面最小宽度 1648 → 728，1600 宽窗口横向滚动条消失
- ✨ 优化：`TAB/prediction.py` 7 个字体 QSpinBox 由 `setFixedWidth(50)` → `setMinimumWidth(50)`；`element.py` / `zodiac.py` / `number_selection.py` 6 个字体框由 `setFixedWidth(80)` → `setMinimumWidth(80)`
- ✨ 优化：`prediction.py` 期数/排名/跳过框、`history.py` 页码框由固定宽度改最小宽度；4 个复制/导出按钮 `setFixedHeight(26)` → `setMinimumHeight(26)`；筛选下拉框改为 AdjustToContents
- ✨ 优化：`number_sort.py` / `number_tail.py` 结果分隔符下拉框由固定 110px 改为 AdjustToContents + 最小宽 150，11 项长选项完整显示
- ✅ 验证：离屏渲染 16 个选项卡，1600×1000 下全部页面无横向滚动条；最小窗口 1180×720 仅 [3]/[10] 内容本身超宽由滚动条承载
- 📄 文档：新增 `docs/代码修改索引.md`（全量符号/控件行号、关键词定位表、运行原理、`__init__.py` 作用、隐式机制清单）及配套 `docs/生成索引.py`；功能说明新增第十五章（控件自适应检查结果、索引用法、run 调用链、`__init__.py` 与隐式机制）；README、jiego.md、公告说明同步；目录树中 3 个 `__init__.py` 补齐职责注释；无依赖增删

### v0.0.81
- ✨ 蓝图真生成：`docs/生成蓝图.py` 移除 `QT_QPA_PLATFORM=offscreen`，改真实 Windows QPA + `WA_DontShowOnScreen`（真实字库），全部落盘函数 monkeypatch 为空；输出 14 张 1600×1000 页面截图与 `docs/蓝图/index.html`
- 🐛 目录树 / 索引 16→14：`docs/生成目录树.py`（TAB 清单、生成蓝图说明、蓝图截图说明）与 `docs/生成索引.py`（主窗口区域、大数据分析编号）全部改 14；`DESCRIPTIONS` 补齐 64 条，`--check` 退出 0 后用默认模式（脚本无 `--write`，默认即写回）重生成
- 📄 版本：`README.md` / `docs/dev.md` / 功能说明 / 公告页同步 v0.0.81

### v0.0.80
- 📄 文档整合：新增 `docs/大厂级UI前端-完整提示词.md`，以「需求解码→立系统→信息架构→骨架→组件内容→状态→动效→验收」为主线，把 Token 表、颜色/尺寸/圆角/字号标准、8 态矩阵、页面五态、动效硬线与验收清单内联到对应步骤；对外仅保留 1 个可直接复制的主提示词块，Flet 常量映射、速查表与迭代模板置于附录 A–C
- 📄 口径统一：间距 7 档 4/8/12/16/24/32/48（单页 ≤6）、圆角 4/8/12/16、字号 12–40、控件高度 32/36/40/48、微交互 120–160ms、页面级 220–450ms、进入曲线 `cubic-bezier(0.22,1,0.36,1)`、同屏 1 处主动画、对比度硬门槛 4.5:1（目标 7:1）、断点 320/768/1200/2560；冲突项取值及理由见该文附录 D 前的「合并口径说明」
- 📄 同步：`docs/生成目录树.py` 补充 3 份 UI 提示词文档说明（含既有两份），目录树 `jiego.md` 与本文件由脚本重生成；README 文档导航与版本状态更新为 v0.0.80
- ✅ 验证：仅为文档与目录树说明改动，未触碰程序代码与 `系统v7.5` 数据；`生成目录树.py --check` 退出码 0、4 个托管树块一致；历史遗留的 48 个条目（在线开奖 db、lib 新文件、设计稿截图）仍标「待补充说明」，非本次改动引入

### v0.0.79
- ✨ 生肖绑定校验下沉为三个纯函数（`lib/data_process.py`，无 Qt / 无文件 I/O）：`zodiac_binding_groups()` 号码→生肖反向聚合；`validate_zodiac_groups(groups, allow_nonstandard_counts=False)` 全量校验——生肖名合法、12 生肖齐全、1–49 不重不漏为**永远硬查**，`5+4×11` 仅在 `allow_nonstandard_counts=False` 时检查；`binding_from_groups()` 按 `ZODIAC_CLOCKWISE` 顺序展开回 1–49
- ✨ 生肖页统一提交入口（`TAB/zodiac.py::_commit_binding`）：所有全量改绑入口（一键应用 `on_apply_start` / 恢复默认 `on_reset` / 保存绑定 `on_save` / 单条立即应用 `set_immediately`）统一走「校验 → 改内存 → 刷新面板/统计/高亮/完整性标签 → 更新 `NUMBER_NAMES` → 最后落盘」，任一校验失败直接返回 False、不做任何修改；全程不触碰 `zodiac_elements`
- ✨ 只读「完整性自检」标签 `host.zodiac_integrity_label`（提示行下方、15px、WordWrap）：覆盖不通过=红（缺失/重复/越界/空生肖）、覆盖通过但数量非 5+4×11=橙（标注「已按实际绑定保存」）、全部通过=绿（显示 49/49 与 5 个号码的生肖）；完整问题清单放在 tooltip，避免撑高页面
- ✨ 批量编辑对话框（12 行 × 4 列：生肖只读 / 号码文本 / 个数 / 行内状态；行高 32、字号 15）：工具栏「当前绑定 / 清空」两档预填；右侧「允许非标准数量」复选框**默认不勾**，勾选且数量非标时摘要区变橙并在二次确认中追加警示；「批量编辑」按钮位于「保存绑定」右侧；`on_reset` 仅重置生肖、下拉回「龙」、五行绑定不动
- ✨ 对话框记忆键：`[WidgetState]` 的 `c_zodiac_batch_preset` / `t_zodiac_batch_table` / `b_zodiac_batch_allow_nonstandard`，`[Display]` 的 `zodiac_batch_dialog_w` / `zodiac_batch_dialog_h`（默认 700 / 660）
- ✨ `plugins/彩票预测.py::_save_widget_states` 扫描 `self.__dict__` 之后、`except` 之前新增 `_widget_state_extra` 合并（4 行）：对话框等局部控件不在主窗口实例上，由页面模块写入该字典后统一落盘；缺省不写、不改变既有键
- ✅ 验证：真实 49 条绑定校验通过；重号 / 缺号 / 数量非标各报对应问题；对话框四条断言通过；启动零写入通过；`tabs.count()==16`；`系统v7.5` 11 文件 SHA256 逐字节一致（文档改动不写数据）
- 📄 同步：功能说明第二十六章（批量编辑 / 校验规则 / 放宽开关 / 三态自检 / 统一提交）；UI 规范 3.6.6（`_widget_state_extra` 与对话框记忆键）；README / 公告页；目录树与索引重生成

### v0.0.78
- ✨ 历史记录生肖快照：6 个记录创建点统一写入 `record['zodiacs']`（与 `numbers` 下标一一对应）与 `record['special_zodiac']`；不改 SQLite schema
- ✨ 创建点覆盖：顶栏「添加数据」、导入页单条、导入页批量、历史页批量（严格 TXT / 原始格式 / CSV 三分支）、历史页导入记录；DB 镜像恢复与示例数据走 `ensure_zodiac_snapshots()` 幂等补写
- ✨ 详情读取：`LotteryConfig.resolve_record_zodiacs()` 优先返回快照，`from_snapshot=True`；无快照旧记录回退实时推算并标注来源（历史详情新增「生肖来源」绿 / 橙两态）
- ✨ 幂等回填：新增「🧷 回填快照」按钮（快捷操作第 7 项），批量补写缺失字段并弹窗统计 `filled` / `skipped_existing`
- ✅ 验收：改绑后往期读 `from_snapshot=True` 且值不变（对照组由蛇 → 鼠，缺陷可复现）；100 条旧记录全走回退并标注橙色来源；回填两次 `filled=100` / `filled=0, skipped_existing=100`；100 期除新增字段外逐值差异 0；`py_compile` 4 文件 0；`tabs.count()==16`
- ⚠️ 局限（必须如实记录）：
  1. 快照 = **写入时刻的当前绑定**，不是开奖日期所属农历年的当年映射；已解决「改绑不改写历史」，**未解决**「历史应按当年规则显示」
  2. DB 镜像不存快照，从 DB 恢复时按**恢复时刻**的绑定补写
  3. 真实 `系统v7.5/彩票数据.json` 当前仍无快照，需用户点「🧷 回填快照」
- 📄 同步：功能说明第二十五章 25.3；UI 规范历史详情来源色板；目录树与索引重生成；README / 公告页

### v0.0.77
- ✨ 评分明细标签字号：`TAB/bigdata_analysis.py::_render_number_cell` 的 `NumberBallWithZodiac` `font_size` 14→15；球径 52×52 不联动、无需抬
- ✅ 验收：行高 46 未变；1180 / 1600 两档横向滚动条 `maximum()` 均为 0；17 行完整、裁切 0；球控件 56×106 → 56×108
- ⚠️ 已知连带：1600 档「推荐数字」卡内容高 252 > 视口 249，出现 **3px 纵向滚动**（标签行高 +2px 所致），记为遗留项，本轮不改布局
- 📄 同步：功能说明 25.2；UI 规范字号下限说明；README / 公告页

### v0.0.76
- ✨ 字号与几何口径修正（`TAB/zodiac.py`）：右侧生肖统计表生肖列 `QFont("Arial", 13, Bold)` → `setPixelSize(15)`，号码列 `QFont("Arial", 11)` → `setPixelSize(15)`，行高固定 34
- ✨ `TAB/widgets.py` 矩阵滚动条口径：由 `QStyle.PM_ScrollBarExtent`（本机 17px）改为固定 `_MATRIX_SCROLLBAR_W = 12`，与主窗口全局 QSS `QScrollBar:vertical { width: 12px; }` 一致；QSS 改宽需同步该常量
- 📐 统计表实测：1180 档表格 251×289、视口 237、列宽 82 / 155；1600 档 382×563、视口 380、列宽 82 / 298；两档字号 15 / 15、行高 34、行内墨迹高 12、**无横向滚动条**；最长号码串 advance 112px（含内缩 122px）→ 不裁切
- 📐 矩阵实测：口径固定 12px 后，1180 档列距 **72** / 卡 **66×96** / 圆 52，表头与卡区列轴 **0.00px**（12 列全 0）；重复「1180 → 1600 → 1180」仍稳定 72 / 66
- 🧮 正确整数解（原 65×96 / 71 的来源与修正）：1180 档面板宽 882，`(882 - 4 - 12) // 12 = 72`（列距），卡宽 `72 - 6 = 66`，表宽 880（左右各余 1px）。旧值 71 / 65 是按 `PM_ScrollBarExtent=17px`（比真实滚动条多 5px）预留的错误残值
- ⚠️ 已知连带：1180 档统计表 12 行 × 34px = 408px > 视口 289px，会出现 12px **纵向**滚动条（正常，不是横向溢出）
- 📄 同步：功能说明 25.1 + 24.2 数字更正；UI 规范 3.6.5；v0.0.75 历史条目就地更正并注明；README / 公告页

### v0.0.75
- ✨ 生肖页「变体一」改造收尾：卡内去掉生肖胶囊，改为「圆形号码在上 + 五行单字在下」；生肖信息全部由上方固定 12 格高亮条承担
- ✨ 表头固定 12 格：135° 渐变 `#5566D6 → #764BA2`、白字 Bold、2px `#5A67D8` 单元格边框、首末列 10px 圆角、固定不随卡区滚动；选中态实心 `#4A3391` + 2px `#A5B4FC` 描边
- ✨ 卡区改为内部纵向滚动、表头固定；卡高严格对称，不压扁圆、不牺牲卡内留白
- 📐 实测 1180×720：左栏面板宽 882、列距 **72**、卡 **66×96**、圆径 52、号码 28 / 五行 15 / 表头 15、表头高 54、卡上下留白 8+8、左右内缩 3（原记 65×96 / 列距 71，系按 `PM_ScrollBarExtent=17px` 预留的残值；v0.0.76 按 QSS 实际 12px 修正为 66×96 / 72）
- 📐 实测 1600×974：面板宽 1026、列距 85、卡 77×115、圆径 58、34 / 17 / 17、表头 64、卡上下留白 12+12
- ✅ 对齐与裁切：表头第 N 格中心与第 N 列卡中心 **12 列全 0.00px**；号码墨迹居中 −0.5px、五行 0.0px；文字裁切 0；最小字号 15
- 🎨 对比度：五行亮色 5.35–6.79、暗色 7.09–10.03；表头白字 4.93、渐变结束 6.37、选中 9.66；空槽 5.24 / 5.40；淡出五行 4.91 / 6.72
- ⚠️ 偏差一（圆径公式）：设计稿 §4.4 / §4.9 的 D=44 / 60 与 §4.8 的 `D=max(1.2×字号, 0.6×卡宽)` 自相矛盾（0.6×56=33.6、0.6×80=48，都算不出 44 / 60）；实现按参考图实际比例 0.786 / 0.75，仍受 ≤0.8×卡宽上限约束
- ⚠️ 偏差二（1180 只显示约 3.7 排）：主窗口工具栏 / 选项卡栏 / 状态栏占去高度，选项卡视口 557px、表格需 578px，故改为表头固定 + 卡区内部滚动（最大滚动 155），滚到底 `header_y` 仍为 2
- ⚠️ 偏差三（暗色遗留）：暗色下顶部旧控件与右侧统计表仍为亮色样式（既有控件，本次未越界重做），个别标签对比度偏低，属已知限制
- 📄 同步：功能说明 [10] 布局改写 + 第二十四章 24.2；UI 规范 3.6.2 登记矩阵尺寸键；目录树与索引重生成；README / 公告页版本号

### v0.0.74
- ✨ 生肖页正文由 7×7 `ZodiacNumberPanel` 接入 `AttributeMatrixPanel`（12 列 × 5 排），上方新增 `ZodiacHighlightBar`（高 44、12 格、可点、再点取消）
- ✨ 点「马」→ 01 / 13 / 25 / 37 / 49 五张卡强调、其余 44 张淡出；再次点击同一条恢复默认（淡出号码对比 3.6:1，达 3:1 大字号档）
- ✨ 旧 INI 出厂尺寸 `80×60 / 20/20` 一次性迁移为 `90×98 / 28/15`，写 `[Display] attr_matrix_v1=1` 标记；迁移只改内存、不直接写盘，由既有 `_save_ini_config` 闸门决定落盘
- ✨ 号码点击仍走 `number_clicked(int)` → 主窗口十二生肖菜单，语义与旧面板一致；右侧统计概览、`zodiac_h_splitter`、顶部控件全部保留
- ✅ 验证：接入当时实测 1180 下卡 66×98、1600 下 77×98，两档 0 文字裁切、最小字号 15；1180 需整页纵向滚动（第 5 排）。v0.0.75 变体一改造后卡几何更新为 **66×96 / 77×115**（1180 档的 66 为 v0.0.76 按 QSS 实际 12px 修正后的正确整数解）
- 🔁 回滚：`TAB/zodiac.py` 的 build 里换回 `ZodiacNumberPanel` 即可，旧控件类完整保留
- 📄 同步：功能说明 [10] 与第二十四章 24.1；UI 规范 3.6.2 与「旧 7×7 面板已替换、类保留」标注；目录树与索引重生成

### v0.0.73
- 🧹 注释补全「四路全批」（只改注释 / docstring，不动任何语句）：`plugins/彩票预测.py` 35/35 import、61/61 函数；`UI/control_picker.py` 8/8 import、40/40 函数；`docs/生成目录树.py` 30/30、`docs/生成索引.py` 21/21、`docs/生成蓝图.py` 4/4 import + 2/2 函数；`TAB/`（除 `prediction.py`）111/111 import、360/360 函数、净增 1196 行、AST 逐文件全等；`TAB/prediction.py` 31/31、131/131、净增 83 行；`lib/` 8 文件 122/122、302/302、净增 846 行、AST 8/8 一致
- 🔍 独立复核：`on_predict_finished` 异常分支完整（`traceback.print_exc()` 在 6109、`QMessageBox.warning` 在 6110，同在 `except` 内且中间无缺失语句）；AST 扫描「代码被吞进 docstring」零命中；六文件 `py_compile` 全部 0
- 🧹 `TAB/data_storage.py` 死导入清理：`on_storage_backup` 内第 2011 行零引用的 `import shutil` 已删，`zipfile` 保留（有真实调用）；AST 仅少 1 个 Import 节点、其余全等
- 📝 `lib/ml_model.py` 顺带修正 3 处与代码矛盾的旧注释（指纹、模型加载、特征准备的时间序说明），不改逻辑
- 📝 A7 文档口径（不单独占版本号，随本条记录）：`README.md`、`docs/号码预测.md`、功能说明中的「Python 3.10+」统一改为「代码未使用 3.10 之后的新语法，但仅在 3.14.7 实测通过；3.10 / 3.11 未实测」，并与任务清单 C2 互相引用；`requirements.txt` 仅同步注释口径，版本约束与包数量不变
- ✅ 验证：`python -m compileall -q .` 退出码 0；离屏 `tabs.count()==16`；目录树 `--check` 退出码 0；索引未解析 0
- 📄 同步：功能说明第二十四章 24.3；README 版本状态与对照表；公告页版本号

### v0.0.72
- ✨ 新增 `TAB/widgets.py::AttributeMatrixPanel`（方案 B2 属性矩阵）：12 列 × 5 排，号码在上、生肖 + 五行胶囊在下；49 张号码卡按行优先填充（01–12 / 13–24 / 25–36 / 37–48 / 49），末排 49 之后 11 个虚线空槽不补位、不可点、不参与 Tab 焦点
- ✨ 尺寸两档（按可用宽度切换）：宽 <1500 紧凑档卡 90×98、号码 28px / 属性 15px、列距 / 行距 6 / 10、页边距 16；宽 ≥1500 宽档卡 121×139、号码 34px / 属性 17px、列距 / 行距 8 / 12、页边距 24；宽档卡宽由可用宽度反算并 clamp 到 121，1500–1600 之间也不横向溢出
- ✨ 数据源：生肖默认 `LotteryConfig.generate_zodiac_binding(start_zodiac)`（构造参数可传 `host.zodiac_binding`），五行默认 `NUMBER_ELEMENTS`（复制后持有，避免外部原地改动），号码色默认 `LotteryConfig.get_number_color(num)`；未写死任何假数据
- ✨ 交互：单击号码只发出 `number_clicked(int)` 信号；不读写文件 / 数据库 / `[WidgetState]`，不弹窗
- ⚠️ 接入状态：**控件已就绪、尚未接入任何选项卡**。不声明 `TAB_INFO`、不提供 `install/build`，`TAB.iter_tab_pages()` 不会把它识别为页面
- ✅ 验证：离屏构造 1180×720 与 1600×974（亮 / 暗四组）尺寸与字号符合上述两档；`tabs.count()==16` 不受影响；`python -m compileall -q .` 通过
- 📄 同步：功能说明新增第二十三章（23.1–23.5）；`docs/设计稿` 全部 PNG / JSON / 方案说明补写目录树 DESCRIPTIONS；README 版本状态与对照表、公告页版本号同步

### v0.0.71
- ✨ 清理 `plugins/彩票预测.py` 死代码：删除顶层未使用的 `import re`、`__init__` 内重复的 `import copy`、`_safe_cleanup_thread` 内重复的 `import sys`
- 🔍 方法保留：全仓检索（含 `getattr` / 字符串反射）确认 61 个方法全部有调用方，**一个未删**
- ✅ 验证：`python -m compileall -q .` 退出码 0；离屏 `tabs.count()==16`；导入链无 `NameError`（`re` / `copy` / `sys` 在使用点均已从模块级导入解析）
- 📄 同步：功能说明 23.4；`requirements.txt` 无依赖增删，保持不变

### v0.0.70
- ✨ `TAB/bigdata_analysis.py` 评分明细由 7 列 `QTableWidget` 改为评分卡列表：一行一卡，左侧圆形名次徽标（组内排名，Top3 金 / 银 / 铜）+ 名称 + 等级档位，中部综合分进度条 + 右侧频率 / 遗漏 / 转移三条分项迷你进度条
- ✨ 分组与顺序：数字 7 行 → 生肖 7 行 → 波色 3 行（共 17 行），组间分组标题带本组条数；组内顺序沿用 `analyze()` 综合分降序，名次组内独立计算
- ✨ 取数唯一入口 `_detail_row_models()`：直接读 `analyze()` 结果，另生成 `cells`（旧表 7 列逐格文本）用于回归比对；空状态显示占位说明，不再出现「只有表头、下方空白」
- ✨ 布局：`QScrollArea` 横向滚动恒关闭，进度条吸收多余宽度；明细卡固定浅色表面 + 显式文字色，亮 / 暗主题均可读
- ✅ 验证：17/17 行与旧表逐格一致（`cells` 逐值比对 0 差异）；1180×720 无新增横向滚动条；`py_compile` 通过、`tabs.count()==16`
- 📄 同步：功能说明第六章 [16] 第 6 项重写（评分卡结构 / 分组 / 取数 / 空状态 / 主题）；索引关键词表旧明细表控件名行替换为 `_detail_row_widget` / `_detail_row_models`；UI 规范 `t_` 示例改用 `t_history_table`

### v0.0.69
- 🐛 修复（号码预测卡片视图）：七策略卡未全部显示、末卡被容器高度估算截断；现七卡全显并可滚动到
- ✨ 号码字号默认 20px；跨卡片列位对齐（不同长度策略名后的正码列 x 坐标一致）；特别码保持红色高亮，暗色主题对比度 4.98:1
- 🐛 修复（既有 Bug）：`scores` 写入 JSON 后键由 `int` 变为 `str`（`'3'`），旧代码只按整数键取值导致指标全部显示「—」；现同时兼容 `int` 与 `str` 键
- ✅ 验证：七卡内容完整、1180×720 无横向滚动条；指标数值恢复显示；`py_compile` 通过、`tabs.count()==16`
- 📄 同步：功能说明 23.2；`docs/号码预测.md` 口径不变（格式与特别码高亮要求仍成立）

### v0.0.68
- 🐛 修复（启动 storage 空写）：`TAB/data_storage.py::sync_storage_files()` 原在扫描结束后无条件保存，`lib/db_helper.py::save_storage_items()` 也不做内容比对，导致每次启动都产生约 8KB `app_config.db-wal` 帧并刷新 `数据存储/index.json` 的 mtime
- ✨ 条件保存：`sync_storage_files()` 仅在「本次扫描新增条目 / `index.json` 不存在 / `index.json` 损坏无效」三种场景落盘，其余只更新内存视图；改动处附详细注释说明判定条件
- ✨ 写前比对：`save_storage_items()` 读出表中现有行，与待写入行逐字段比对，完全一致时直接返回、不开启写事务
- ✅ 效果与回归：离屏启动 `app_config.db-wal` 由 8KB 降为 0 帧；新增文件后启动仍正常落盘（反向回归）；损坏 `index.json` 能兜底重建；`python -m compileall -q .` 通过、`tabs.count()==16`
- 📄 同步：功能说明 23.1；`requirements.txt` 无依赖增删，保持不变

### v0.0.67
- 🐛 修复（五行页「控件显示 15 / 实际渲染 12」）：`[Display] element_panel_label_font` 与 `self._element_panel_size['label_font']` 代码默认值均为 12，而 `[WidgetState] s_elem_text_font_spin` 为 15。启动顺序 `_apply_panel_sizes_to_ui()`（按 12 渲染）→ `_restore_widget_states()`（`blockSignals` 只改控件显示值）导致角控件显示 15px、五行分组条实际渲染 12px；宫格面板因 `ElementGridPanel.set_font_size()` 已有 `max(15, …)` 钳制，实际为 15，只有分组条五行字是 12
- ✨ 统一默认值（全链 12→15）：`plugins/彩票预测.py` 构造期 `_element_panel_size` 字典、`_reset_all_fonts()` 的重置字典与 `set_font_size(label_font=…)`、`_apply_panel_sizes_to_ui()` 的角控件赋值与 `_save_ini_config()` 的 `element_panel_label_font` 默认值；`TAB/element.py` 的 `refresh_stats()` 渲染取值与 `install()` 宫格面板初始化
- ✨ 读取钳制：`_apply_ini_config()` 读取 `element_panel_label_font` 改为 `max(15, int(...))`，只改内存、不写盘；旧 INI 残留 12 时也不会再出现「显示 15、渲染 12」
- ✨ 顺带统一：`TAB/widgets.py::NumberBallWithZodiac` 的 `font_size` 默认由 11 抬到 15（所有现有调用方都显式传值，运行时行为不变）；`ElementGridPanel` 文档与两处样式注释里的「默认 12px」纠正为 15px；`TAB/element.py` 详情字号回退值 13 改为 20（与 `_detail_label_size` 实际默认一致）
- ✅ 复现（修复前同口径复测）：1180×720 / 1600×974 下 `_element_panel_size['label_font']=12`、`elem_text_font_spin=15`；分组条「金/木/水/火/土」五行字 QSS `font-size:12px`、FontMetrics 高度 12；宫格标签 QSS `15px`、高度 15（对照 15px 参照标签高度 15、12px 参照高度 12）
- ✅ 修复后：两种尺寸均 `label_font=15 / spin=15 / grid=15`，分组条与宫格标签 QSS `15px`、FontMetrics 高度 15；同进程二次构建（等价重启，重新读 INI）仍 15/15；分组条行宽 640、最小所需宽度 ≤94，1180 与 1600 下均无横向滚动条；抽样 数字选择 20px、生肖标签 15px、预测球标签默认 20px、图例 20px、详情 20px、历史表 16px、预测记录表 16px、大数据明细/来源 15px，均未变小
- ✅ INI 落盘现状：`[Display] element_panel_label_font = 15`、`[WidgetState] s_elem_text_font_spin = 15`；开工时存在的 `python run.py`（PID 2040）在验证前退出，未发生抢写。只读复测（构造期与关闭期写盘全部屏蔽）读回 15/15、实际渲染 15px。**副作用（需记录）**：离屏验证窗口关闭时触发 `closeEvent` 的 `save_prediction_history()` 与 `_save_ini_config()`，导致 `配置.ini` 的窗口几何（`window_width/height=1180/720`）与各页分隔条尺寸、`app_config.db` 的 `ui_ini` 镜像、`预测记录.json`（3 条记录内容不变）被重写；核心数据文件 `彩票数据.json`、`生肖绑定.json`、`上次预测_号码预测.json` 与 `history_records` / `func_state` 未变。本次未先做 `系统v7.5` 备份，几何/镜像旧值不可逐字节还原，建议用户按常用尺寸重开一次窗口后关闭，由程序重新落盘
- ⚠️ 已发现未改（超出本次允许范围）：`TAB/bigdata_analysis.py:1793` 号码球标签 `font_size=14`（<15，文字类）；`TAB/zodiac.py:469/588/878`、`TAB/number_selection.py:383/393` 的 `label_font` / 详情回退值 10 / 12 / 13（键始终存在，仅代码兜底）；`TAB/history.py:473` 历史表正码/特别码数字 `13 × table_scale`（默认 1.0 → 13px，表格正文已知例外）；`docs/生成蓝图.py` 的 HTML CSS `12px/14px`（文档生成器，非应用界面）；matplotlib 刻度未显式设字号时沿用库默认 10（图表刻度，已知例外）；`TAB/data_storage.py` 与 `TAB/number_sort.py` / `TAB/number_tail.py` 注释写「字号 13/14px」而实际已是 15px（陈旧注释）
- ✅ 验证：`py_compile`（三个改动文件）通过、离屏 `tabs.count()==16`、`docs\生成目录树.py --check` 退出码 0、索引重生成未解析 0；`requirements.txt` 无依赖增删，保持不变

### v0.0.66
- ✨ SciPy 插值加成改为时间口径：`lib/math_algo.py::_scipy_interp_bonus` 原为横截面插值（x=号码序号 1..49、y=各号码当前遗漏），样条穿过全部整数节点，`|missing - interp(num)|` 恒为 0，49 个号码加成全部为 10 分（唯一值 1 个，实际不参与排序）。现改为复用 `_predict_next_missing_by_spline`，对每个号码取自身逐期遗漏序列做三次样条外推，得到「下一期」估值后再按原公式 `max(0, 10 - |当前遗漏 - 下一期估值| * 0.5)` 转成加成；衰减系数 0.5、归一化区间 0~10、乘数 25/30 均未变，无随机性，仅调用综合推荐（增强 / 经典）两条路径
- ✨ 四处口径统一：`interp_missing`（逐号码样条）、sklearn 前缀特征、逐号码时间回归、SciPy 加成现在都按「旧 → 新」时间为轴；同一份 100 期数据下 49 个号码各有一个独立估值
- ✨ 降级保持：完整模式 SciPy 缺失 → `scipy_interp_func=None` → 加成 `{}`（与改动前一致）；轻量 / `_init_defaults` 的默认 lambda 路径外推结果为空时回退原横截面公式；两路径均不抛异常、不阻断综合推荐
- ✨ `requirements.txt` 补 `>=x,<y`：下界取当前实测通过版本（Python 3.14.7），上界取下一个可能破坏兼容的大版本；保持单一文件、13 个包、逐项 `#` 用途注释，`tensorflow` 继续注释，最小启动集 PyQt6 + numpy
- ✅ 实测（100 期真实数据）：加成数组改动前唯一值 1 / min 10 / max 10；改动后唯一值 22 / min 0 / max 10。综合推荐增强 Top6 `2,9,21,22,23,30` → `6,9,21,22,23,30`（仅 #2→#6：#2 加成 9.5、扣 25×0.5=12.5 分，#6 仍为 10 分）；经典路径 Top6 `30,22,2,21,6,23` 不变；反向路径 `28,41,44,46,47,48` → `5,9,21,27,47,49`（4 个号变化；原恒定 10 分加成改为逐号码差异后，低分端排序重排，最大变化为 #49 由 10 分降到 0 分、扣 250 分）。连续两次完整模式重跑，受影响路径结果逐值一致
- ✅ 实测（不受影响算法）：编号 1/2/3/4/5/6/7/16/17/21/22 共 11 个算法 Top6 改动前后逐值不变；界面七策略普通码与特别码全量不变
- ✅ 实测（缺库降级）：`MetaPathFinder` 屏蔽 scipy 后完整模式综合推荐 / SciPy 优化仍出号且无异常，`_scipy_interp_bonus` 返回 `{}`；轻量默认值路径返回 49 项加成（min 0/max 9.5）并正常出号；屏蔽 seaborn 后 `_get_sns()` 为 None、热力图与和值图走 matplotlib 分支，axes 数 2/1，图已落盘
- ✅ 实测（依赖与启动）：`python -m pip install --dry-run -r requirements.txt` 退出码 0，13 个包全部「Requirement already satisfied」，无「Would install」；`python -m py_compile lib\math_algo.py` 与 `python -m compileall -q lib plugins TAB UI run.py` 退出码均 0；离屏 `tabs.count()==16` 且 16 个标题齐全
- ✅ 数据还原：离屏启动会创建 `app_config.db-wal`（8272 B）/ `-shm`，主库 `app_config.db` 字节哈希前后均为 `377BBFC3…732B`；测后在无运行实例时删除两个 WAL 文件，主库哈希不变。`彩票数据.json`（`BC7288D8…71FB1`）、`配置.ini`（`3F52B41A…341E`）、`analysis.duckdb`（`1875EA3E…99A7D`）、`ml_models.pkl`、`上次预测_号码预测.json` 在测试前后哈希一致；`预测记录.json` 内容未变（3 条、最新 `2026-11-03 03:11:56`、SHA256 `2924483E…F25E`），离屏启动只刷新了 mtime
- ⚠️ 已发现未改（运行实例并行写入）：最终复核时本机已有一个 `python run.py` 实例（PID 9940，23:18:55 启动）在运行，它正常刷新了 `配置.ini`、`app_config.db-wal` 与 `数据存储/index.json`；这不是本批测试留下的改动，未干预该实例、也未删除其 WAL。本批自身未改写 `配置.ini` 与会话键
- ⚠️ 已发现未改（启动仍产生 WAL 帧）：本次离屏启动拉起的 `app_config.db-wal` 为 8272 B，说明启动期仍有一次写入（主库未 checkpoint），与 v0.0.65「func_state 内容一致不写」不矛盾（可能来自 `ui_ini` 镜像或其它启动期落库）；本批未改连接/写入路径，仅清理 WAL
- ⚠️ 已发现未改（旧记录口径）：`预测记录.json` 与 `上次预测_号码预测.json` 只存算法名称 / 号码 / 特别码，不存 `scipy_bonus` 中间量，`_scipy_interp_bonus` 的结果也不落盘，故历史记录**无需迁移**，仅新预测按新口径计算

### v0.0.65
- ✨ 启动期 `func_state` 写库收口：`_sync_data_state_to_db()` 改为先读后写，只比较 `record_count` / `latest_period` / `enabled` 三项业务内容，一致则直接返回、不产生写事务；`updated_at`（列与 `state_json` 内字段）不参与比较，否则每次启动都会误判为变化
- ✨ 新增只读接口：`lib/db_helper.py` → `DBHelper.get_func_state(plugin_name)`（单连接 + 锁内 SELECT，不 commit、不追加 WAL 帧），供写前比对使用
- 🔍 消费方核查：全仓库检索 `func_state` / `get_func_state` / `set_func_state`，除写入点外**无任何读取方**；`updated_at` 未被用于最后同步时间、新鲜度判断或缓存失效，故跳过写入无业务依赖风险
- 📄 文档（第七章算法单表）：功能说明原四张分表（统计与规则类 / 图论类 / 科学计算与机器学习类 / 特别码专项）合并为一张 `编号 | 算法 | 类别 | 说明` 单表，01–23 自上而下连续；删除 NetworkX（21）排到 17–20 之前造成的断序，同一编号不再出现两处
- ✅ 实测（启动不写）：连续两次离屏启动，`func_state` 的 `state_json.updated_at` 保持 `2026-11-03 22:33:44` 不变；`配置.ini` SHA256 前后均为 `86E8FF10…3844`。还原数据后的第一次启动（库内 101 / 文件 100）确实写入（`updated_at` → `22:42:10`），紧接着第二次启动内容一致，`updated_at` 保持 `22:42:10`，两个分支均按预期工作
- ✅ 实测（真实写入）：改一次设置（`ball_label_font_size` 20→21）+ 加一条记录（期号 101）后落盘成功，重启读回 `count=101 / first_period=101 / font=21`；测后用备份逐字节还原 `彩票数据.json`（SHA256 `BC7288D8…71FB1`）与 `配置.ini`，并把 `history_records` 镜像按当前 JSON 重同步回 100 条（max period=100）
- ✅ WAL 事实：正常启动→关闭过程中会创建并在退出时删除 `app_config.db-wal` / `app_config.db-shm`；主库 mtime 会被 close/checkpoint 刷新，但字节哈希不变。副本实验证明 `mode=ro` 打开同样创建 `-wal`/`-shm`，`mode=ro&immutable=1` 可不创建但存在读到过期 WAL 的风险；**决定只做「不写」，不改连接模式**
- ✅ 验证：`py_compile` 通过（`plugins/彩票预测.py`、`lib/db_helper.py`）；离屏 `tabs.count()==16` 且 16 个标题齐全；目录树 `--check` 退出码 0；索引重生成未解析 0；`requirements.txt` 不动
- ⚠️ 已发现未改（完整关窗路径）：本次启动测量采用「启动后直接退出事件循环、不触发 closeEvent」；离屏校验进程在解释器退出时仍走了关窗路径，`_ini_dirty` 因界面自动布局值（`current_tab_index`、`element_v_splitter_sizes`、`t_backtest_table` 列宽与已废弃的评分明细表列宽键）与磁盘不同而置真，重写了一次 `配置.ini` 与 `ui_ini` 镜像。本批未改该边界，测后已用备份还原 `配置.ini`（SHA256 回到 `86E8FF10…3844`）
- ⚠️ 已发现未改（基线不一致）：任务给出的 `配置.ini` 基线 `302D7ED2…32D2`、`analysis.duckdb` 基线 `ADA78F5E…0808` 在开工前就与磁盘现状（`86E8FF10…3844` / `1875EA3E…99A7D`，mtime 2026-11-03 22:31–22:32）不一致，疑为交接前最后一次真实运行/分析所致；本批未触碰这两个文件，未自行改写基线

### v0.0.64
- 🐛 修复（纯缩放不保存窗口尺寸，回归自 v0.0.63）：`plugins/彩票预测.py` 的 `resizeEvent` 原被定义两次，后段（字号重算）覆盖前段（首帧后置脏），运行时缩放不置 `_ini_dirty`；现合并为唯一实现：`super().resizeEvent` → `_apply_autosize()` → 首帧后置脏，两份原有行为全部保留，无同名桩
- 🐛 修复（顶栏「添加数据」多行只收第一条）：`QInputDialog.getMultiLineText` 的整段文本曾直接传给约定「一行一条」的 `DataUtils.parse_txt_line`，其余行被静默丢弃；现先按 CRLF/LF 拆行、逐行委托同一函数，空行忽略、无效行计入跳过，结束时提示「成功 N 条 / 跳过 M 条」，全无效时不写盘
- 📄 文档（算法编号 17–21 校正）：核实 `TAB/prediction.py` / `TAB/backtest.py` 均以 `QComboBox.currentIndex()` 直接作编号、下拉顺序来自注册表，`预测记录.json` 只存算法中文名称无编号；结论为注册表口径正确，只改功能说明第七章表（17 NumPy / 18 SciPy / 19 sklearn / 20 PyTorch / 21 NetworkX），注册表不动
- 📄 文档纠错：v0.0.59 条目「功能说明新增 17.9」改为真实章号 17.5
- ✅ 实测：纯缩放 `_ini_dirty` False→True，关窗后 `配置.ini` 写入 `window_width=1500/window_height=940`，重启读回 1500×940；纯移动置脏并保存 `window_x=120/window_y=90`；不缩放不移动连续启停 2 次 INI SHA256 恒为 `302D7ED2…32D2`；构造期 `_ini_write_enabled == False`、构造后为 True（构造期非法放盘 0 次）；3 行有效 + 1 行 8 段无效 → 新增 3 / 跳过 1，全无效时记录数变化 0；`py_compile` 通过、`tabs.count()==16`
- 📄 同步：README 升 v0.0.64 并追加对照表一行；功能说明新增第十九章（19.1–19.3）、18.4 缺陷标注改为已修；UI 规范 3.9 补「缩放也会置脏」；公告页版本号同步；目录树正式写回 + `--check` 退出码 0；索引重生成未解析 0；`requirements.txt` 不动
- 🧪 测试数据还原：`彩票数据.json` / `预测记录.json` / `analysis.duckdb` / `配置.ini` 按备份逐字节还原，SHA256 与基线一致

### v0.0.63
- 🐛 修复（启动无意义重写 `配置.ini`）：`_ini_write_enabled` 构造期关闭、`closeEvent` 按 `_ini_dirty` 保存、`moveEvent`/`resizeEvent` 首帧后置脏、`_save_ini_config` 增加「内容与磁盘逐字一致则跳过」兜底、缺失键只经 `_ensure_ini_defaults` 补到内存
- 🐛 修复（首次启动大数据页 `AttributeError`）：`_init_default_ini` 补调 `_apply_ini_config`，确保 `_splitter_sizes` / `_history_col_widths` 等容器先初始化；首次创建 INI 仍走 `force=True`
- ✨ 示例修正：`TAB/history.py` 批量添加示例改为 9 段 `117 2026-04-27 05 12 23 34 45 06 08`，避免示例本身缺特别码被拒
- ✅ 验证：还原测试残留后连续离屏启动两次，`配置.ini` SHA256 前后一致（`302D7ED2…32D2`）；`py_compile` 通过、`tabs.count()==16`；首启路径代码核对：`_init_default_ini` 已补调 `_apply_ini_config`，首次创建仍走 `force=True`
- ⚠️ 已发现未改（本批禁改业务代码）：`plugins/彩票预测.py` 的 `resizeEvent` 定义两次（289 行的 `moveEvent` 之后 298 行一份、1214 行一份），后者覆盖前者，窗口缩放不会置 `_ini_dirty`（仅移动会）；详见交付报告「发现但未改的问题」
- 📄 同步：README 升 v0.0.63；功能说明新增第十八章 18.4；UI 规范新增 3.9；公告页版本号同步；索引重生成；`docs/生成目录树.py` 排除 `崩溃日志.log`

### v0.0.62
- ✨ 新增全局异常钩子（`run.py`）：`main()` 在依赖检查之后、C 扩展预加载/建库/创建 QApplication 之前安装 `sys.excepthook` 与 `threading.excepthook`
- ✨ 落盘格式（`系统v7.5/崩溃日志.log`，追加写）：时间 / 来源（主线程或后台线程名）/ 异常类型 / 异常消息 / Python 版本 / 完整 traceback；同时保留 stderr 堆栈
- ✨ 降级：写盘失败（目录只读、磁盘满、文件占用）只向 stderr 提示目标路径与原因，绝不二次抛出；QThread 异常不经过该钩子（走 Qt 自身异常路径）
- ✅ 验证：直接调用 `_log_unhandled_exception`，日志六项字段齐全（时间/来源/类型/消息/Python 版本/traceback）；正常启动顺序与 `os._exit` 语义不变；测试产物已删除，`系统v7.5` 无 `崩溃日志.log`
- 📄 同步：功能说明 18.3；README「项目特点」补崩溃日志；`崩溃日志.log` 加入目录树排除名单（运行时产物，不建树条目）；索引重生成

### v0.0.61
- 🐛 修复（回测特别码口径）：编号 21/22 原先按正码对照、分母按 6 计算，命中数恒为 0、命中率被双重压低；现改为对照当期实际特别码、分母 = 期数 × 1
- ✨ `lib/data_process.py` 新增 `get_backtest_reference(actual_record, algo_index)`；`compute_hits` / `summarize_backtest` / `compute_cumulative_rates` 按算法编号从注册表推导对照集合与分母，页面不再写特判
- ✨ `TAB/backtest.py`：表格「实际号码」列与命中口径一致（特别码算法只显示当期特别码）；保存 `_last_backtest_algo_index` 供趋势图按同口径取分母；常规 21 个算法逐值不变
- ✅ 实测：合成记录 `numbers=[5,12,23,34,45,6]`、`special=8` 下，算法 0 对照 6 正码/分母 6、算法 21/22 对照 `{8}`/分母 1；`[3,2,4]` 汇总 9/18=50%，`[1,0,1]` 汇总 2/3=66.67%
- 📄 同步：功能说明 [7] 与 18.2；README「项目特点」补回测口径；索引重生成

### v0.0.60
- ✨ TXT 行解析收敛：`lib/data_process.py` 的 `DataUtils.parse_txt_line` 成为全系统唯一实现；`TAB/data_import.py` 的 TXT 文件导入、`TAB/history.py` 的批量添加、`plugins/彩票预测.py` 顶栏「添加数据」三处统一委托
- 🐛 删除插件内联 `len>=8 / parts[7]`（真实 bug：`parts[7]` 是第 6 个正码，导致特别码与正码重复）；8 段缺特别码、空行、`#` 表头、非数字乱码一律返回 `None` 并由各入口跳过
- ✅ 实测：9 段（空格/制表符/多空格）解析结果一致，`(117,'2026-04-27',[5,12,23,34,45,6],8)`；8 段/空行/表头/乱码均为 `None`；10 段多余段忽略、仍取 `parts[8]`
- 📄 同步：功能说明 [1] 与 18.1；README「项目特点」补统一解析口径；索引重生成

### v0.0.59
- ✨ 字号收口（`TAB/prediction.py`）：`apply_legend_font_size` 对「说明文字 / 号码数字」两档统一 `max(15, ...)`，`change_legend_font` 的范围改为说明文字 15~24px、号码数字 15~22px；历史 INI 里的 9px 与连续缩小不再把图例压到不可读
- ✨ 暗色图例配色：新增 `apply_legend_theme_colors`，只替换 QSS 的 `color` 声明、不动字号与布局；亮色保持 `#FF0000 / #0000FF / #008000`，暗色改用 `#FF6B6B / #89B4FA / #A6E3A1`（暗底 `#1E1E2E` 下约 5.91 / 7.79 / 11.03:1，均 ≥ 4.5:1，红/蓝/绿波色语义不变）
- ✅ 验证：两档图例最小值均为 15px；明暗主题切换后三组标签/号码颜色按上表变化；`python -m py_compile` 通过；`tabs.count()==16`；目录树 `--check` 退出码 0
- 📄 同步：README 升 v0.0.59；功能说明新增 17.5；`docs/UI设计规范与记忆机制.md` 新增 3.8；公告页版本号同步；`docs/代码修改索引.md` 重新生成

### v0.0.58
- 📝 注释补齐（仅注释，无逻辑改动）：`run.py`（启动顺序与 0xC0000409 防护、降级边界）、`UI/UI.py`、`UI/__init__.py`、`docs/生成目录树.py`、`docs/生成索引.py`、`TAB/prediction.py`（双视图渲染、图例、持久化）
- 📝 每个 `import` 补写「作用说明」：说明该库在本文件中负责什么、缺它会怎样；统一 `# 作用：...` 行尾注释，不改变导入顺序与惰性加载边界
- ✅ 验证：改动文件 `python -m py_compile` 通过；离屏启动 `tabs.count()==16`；无任何业务逻辑、控件、依赖变化
- 📄 同步：README 结构说明补注释口径；`docs/代码修改索引.md` 重新生成（行号随注释增加而整体下移，属正常）

### v0.0.57
- 🐛 修复（TXT 导入特别码错位）：`TAB/data_import.py` 的空格/TXT 9 段格式取特别码时由 `parts[7]` 改为 `parts[8]`；原先 `parts[7]` 取到第 6 个正码，导致特别码与正码重复
- ✨ 口径统一：与 `TAB/history.py` 批量添加的 9 段解析完全一致（`>=9` 段、`parts[8]` 为特别码），并在两处补写「为什么不能取 parts[7]」的注释
- ✅ 验证：9 段样例（期号 日期 6 正码 特别码）导入后正码 6 个、特别码为第 9 段；不足 9 段仍按原有提示拒绝；`py_compile` 通过
- 📄 同步：功能说明 [1] 补 TXT 解析口径；README 功能说明补一句；公告页版本号同步；索引重生成

### v0.0.56
- ✨ seaborn 接入（`TAB/widgets.py`）：共现热力图 `plot_correlation_heatmap` 改走 `sns.heatmap`，和值分布 `plot_sum_distribution` 改走 `sns.histplot`；矩阵数据、`YlOrRd` 色阶、颜色条 0.8、20 分箱与 `density=True` 口径保持不变；不调用 `sns.set_theme/set_style`，避免覆盖全局中文字体与白底画布
- ✨ 缺库降级：统一经 `lib/plot_draw.get_seaborn_module()` 取模块；返回 `None`（未安装/导入失败）时走原 matplotlib 分支，两种分支共用同一套刻度、标题、颜色条与 15px 字号设置
- 🐛 修复（图表中文全是方框）：matplotlib 此前从未设置中文字体栈；`lib/__init__.py` 懒加载 matplotlib 时补设 `rcParams['font.family']='sans-serif'` 与 `font.sans-serif = Microsoft YaHei → SimHei → SimSun → Arial → DejaVu Sans`
- ✅ 验证：有 seaborn 与用 `MetaPathFinder` 屏蔽 seaborn 两种情况下热力图/和值图均正常出图；图内中文正常显示、无方框；`py_compile` 通过；`tabs.count()==16`
- ⚠️ 依赖口径：seaborn 属**可选增强**，缺失时自动回退，不影响启动；`requirements.txt` 保持单一文件，并在每个可选包上方用 `#` 注释标注「可选/缺失时降级」
- 📄 同步：功能说明 [6] 与 README 环境依赖补 seaborn 可选口径；UI 规范补图表字体栈；公告页版本号同步；索引重生成

### v0.0.55
- ✨ 后台线程（`TAB/bigdata_analysis.py`）：新增 `_BigDataAnalyzeWorker(QObject)` 与 `_BigDataPageController`，把 `BigDataAnalyzer.analyze` 及统计检验放到 QThread 执行，结果经信号回填 GUI；点击「开始分析」后 1.14ms 返回，界面不再卡死
- ✨ 生命周期：控制器持有 `QThread` / Worker 引用防止 GC 提前析构；正常完成、取消、页面销毁三条路径均 `quit()+wait()`，避免 `QThread: Destroyed while thread is still running`
- ✨ 取消与降级：`isInterruptionRequested()` 在长循环中轮询；缺 numpy/scipy 时仍由原有降级提示接管，线程侧不吞异常
- ✅ 验证：同一数据后台版结果文本与同步版 md5 一致；分析期间 UI 可响应；`tabs.count()==16`；`py_compile` 通过
- 📄 同步：功能说明 [16] 补线程模型；README 项目管理特点补后台化说明；公告页版本号同步；索引重生成

### v0.0.54
- ✨ 纯函数下沉（`lib/data_process.py`）：24 个公开统计/整理函数从 TAB 层迁入 lib（另含 2 个内部规范化辅助 `_numbers_of` / `_valid_special`），统一接收 `records` 列表并返回纯 Python 结构，包括
  - D1 图表统计：`compute_frequency` / `compute_missing` / `compute_odd_even_distribution` / `compute_size_distribution` / `compute_color_distribution` / `compute_range_distribution` / `compute_tail_distribution` / `build_trend_data` / `build_cooccurrence_matrix` / `cooccurrence_to_matrix` / `build_interval_data` / `select_top_interval_samples` / `compute_consecutive_probability` / `compute_sum_values`
  - D2 第七位预判：`build_special_frequency` / `build_special_trend` / `compute_special_correlation` / `compute_seventh_size` / `compute_seventh_odd_even` / `compute_seventh_tail` / `compute_seventh_all`
  - D3 回测命中率：`compute_hits` / `summarize_backtest` / `compute_cumulative_rates`
  - D4 内部辅助：`_numbers_of` / `_valid_special` 作为内部规范化辅助
- ✨ 归属：`TAB/statistics_chart.py`、`TAB/seventh_prediction.py`、`TAB/backtest.py`、`TAB/bigdata_analysis.py` 改为调用 lib 函数，不再各自复制统计循环；界面层只保留取数与渲染
- ✅ 验证：同一 100 期数据下沉前后各统计结果逐值一致（频率/遗漏/奇偶/大小/波色/区间/尾数/走势/共现/第七位/回测命中率）；`tabs.count()==16`；`py_compile` 通过
- 📄 同步：功能说明 [5]/[6]/[7]/[16] 补函数归属；README 结构说明补「统计下沉」；公告页版本号同步；索引重生成

### v0.0.53
- ♻️ 行为保持迁移（`plugins/彩票预测.py` 3405 行，较迁移前 3846 行减少 441 行）：
  - `_parse_import_file` → `TAB/data_import.parse_import_file(host, file_path)`
  - `_show_panel_settings_dialog` 四个分支 → `TAB/prediction.py`、`TAB/number_selection.py`、`TAB/zodiac.py`、`TAB/element.py` 各自的 `show_panel_settings_dialog(host)`
  - `_apply_custom_number_colors` → `TAB/number_selection.apply_custom_number_colors(host)`
  - `_load_zodiac_binding` → `TAB/zodiac.load_binding(host)`
  - `_get_latest_period` → `lib/data_process.get_latest_period(historical_data)`
  - `_get_favorites_list` → `TAB/favorites.get_favorites_list(host)`
  - `_format_tails` → `lib/data_process.format_tails(tails)`
- ✨ 兼容：主窗口同名属性仍以 `install(host)` 绑定转发，外部调用点零改动；纯逻辑方法无 Qt 依赖，可在后台线程调用
- ✅ 验证：导入（JSON/CSV/TXT）、四个页面面板设置、自定义颜色、生肖绑定加载、最新期号、收藏列表、尾数格式化逐项与迁移前一致；`tabs.count()==16`；`py_compile` 8 个文件通过
- 📄 同步：功能说明 16.8 迁移清单补 B 组；README 结构说明补「主窗口只留装配」；公告页版本号同步；索引重生成

### v0.0.52
- ♻️ 重构（行为保持）：`_update_history_table` 整体迁入 `TAB/history.update_history_table(host)`，删除主窗口内 155 行旧实现；主窗口保留同名转发壳，18 个调用点改为统一入口
- ✨ 首屏时序：迁移后仍由主窗口 `load_data → _update_history_table` 的顺序触发，`_init_ui` 完成前不提前渲染；分页、排序、列宽记忆、期号详情入口全部保留
- ✅ 验证：100 条历史记录首屏、翻页、跳页、列排序、列宽恢复、双击期号详情与迁移前一致；`tabs.count()==16`；`py_compile` 通过
- 📄 同步：功能说明 [2] 补归属；README 结构说明补「历史渲染归位」；公告页版本号同步；索引重生成

### v0.0.51
- ✨ 新增 `lib/algorithms.py`：23 条不可变 `AlgorithmDef`（编号 0–22、稳定 key、中文名称、描述、`PredictionAlgorithms` 方法名、正码数、分类、是否用模型、是否特别码、是否需 enhanced/reverse），纯标准库实现、无 Qt、可并发只读
- ✨ 统一接口：`get_algorithm` / `iter_algorithms` / `run_algorithm` / `ALGORITHM_COUNT` / `is_special_algorithm` / `get_output_count`；主窗口、[3] 预测页、[7] 回测页三处收敛为同一份定义，`LotteryConfig.ALGORITHMS` 由注册表派生
- 🔒 编号兼容：编号 0–22 与历史下拉顺序逐项一致，名称逐字沿用旧文案；旧预测记录/回测结果/INI 中的算法名称或编号无需映射即可回读；新增算法只能追加到末尾（编号 23 起）
- ✅ 验证：三处取用的编号、名称、描述、正码数、输出号码 0 差异；未知编号按 `DEFAULT_ALGORITHM_INDEX` 兜底；`tabs.count()==16`；`py_compile` 通过
- 📄 同步：功能说明 3.1/第七章补注册表；README 补「新增算法只改一处」；公告页版本号同步；索引重生成

### v0.0.50
- 🐛 修复（缺 pandas 时整条预测准备链中断）：`lib/math_algo.py` 的 `_build_dataframe` 原先在方法内直接 `from pandas import DataFrame`，未安装 pandas 时 `ImportError` 冒泡到 `_prepare_data` 的整体 `except`，触发 `_init_defaults`，`frequency` 变为空、预测退化为近似随机且界面无任何提示。现改为方法内只捕获 pandas 的 `ImportError`：置 `self.df=None`、登记降级提示后 `return`，`_prepare_data` 继续执行 SciPy / sklearn / statsmodels 回退 / NumPy / 时序等后续步骤
- ✨ 降级可读：新增 `_record_degradation(missing_lib, failed_items)` 与只读 `get_degradation_notices()`；提示写入 `self.degradation_notices` 并打印「[降级] 未安装 pandas，以下分析已降级…」+ 逐项失效清单，不弹窗（预测在后台线程执行）。`_prepare_data` 每次完整准备开始时清空旧提示
- ✨ 降级边界：失效项 = DataFrame 结构化特征（和值/均值/标准差/奇偶/大小/跨度/区间/尾数）、`range_distribution_algorithm` 的 DataFrame 趋势分支（改走纯 Python 计数，口径对“期数不足 6 个号码的记录”略有差异）、statsmodels（自身依赖 pandas，`HAS_STATSMODELS=False`，自相关改走 NumPy 基础算法，下游依赖自相关的少量得分可能小幅变化）；仍可用 = SciPy 检验/拟合/平滑/插值、sklearn 特征与 GBDT、NumPy 矩阵、PyTorch（若安装）、NetworkX、基础频率/遗漏/移动平均
- ✨ 代码配套：`range_distribution_algorithm` 的 Series 兜底路径在缺 pandas 时改用纯列表并按 `hasattr` 选择 `sum()/iloc` 或内建 `sum/下标`；`poisson_distribution` 的移动平均趋势门控改为仅“df 为空”时回落 0.1，df=None（缺 pandas）仍读取 `moving_avg`；两处均有 pandas 时数值不变
- ✅ 实测（100 期真实数据、种子 20261103，`系统v7.5/彩票数据.json`）：改动前记录 27 组基线（综合/区间/泊松/NumPy/SciPy/sklearn/PyTorch/NetworkX 的 `get_prediction_scores` Top6 与得分，以及 8 个算法方法与 8 个原始得分字典），改动后逐值比对差异 0；`rangedistribution` / `poisson` 原始结果亦未变
- ✅ 实测（`MetaPathFinder` 屏蔽 pandas，按“find_spec 返回 spec、exec_module 抛 ImportError”模拟真实缺库，避免误伤 torch 的 find_spec 探测）：离屏 `QApplication` 启动成功、`tabs.count()==16`；`PredictionAlgorithms` 构造成功，`frequency` 长度 48（非 0）、`df is None`、未出现「数据准备警告」/未回退 `_init_defaults`；综合 Top6 `[5,3,26,27,24,37]`、sklearn Top6 `[49,44,47,48,16,18]`、PyTorch Top6 `[27,20,5,24,3,28]` 等有效，已测算法 Top6/得分仍与基线逐值一致；stdout 捕获到 `[降级]` 文案与 3 条失效项；屏蔽期间 scipy=True、sklearn=True、torch=True、duckdb=True、pandas=False、statsmodels=False（仅因自身依赖 pandas）
- ✅ 校验：`python -m py_compile lib\math_algo.py` 通过；`python docs\生成目录树.py --check` 退出码 0；未改 `TAB/prediction.py`、`TAB/history.py`、`plugins/彩票预测.py`、`run.py`、`UI/UI.py`
- 📄 同步：README 升 v0.0.50；功能说明新增 16.9「缺 pandas 的降级边界」；`docs/代码修改索引.md` 重新生成；`requirements.txt` 无依赖增删，保持不变（pandas 本就已声明）

### v0.0.49
- ✨ 文本视图间距（`TAB/prediction.py`）：新增 `_number_strategy_gap_text(number_px, text_px)`，号码之间由单空格改为 4 个 U+2009 细空格（NSimSun 15px 下约 12px），号码与生肖五行标签之间 2 个细空格（约 6px），特别码段同样处理；24px 档按可用宽度收窄为「2+3」或「1+2」细空格，避免横向滚动。标签补位改用 `QFontMetrics.horizontalAdvance('\u2009')`，制表位仍按「加粗策略名 + 2 个半角空格」重算，四列 x 坐标 max-min=0
- ✨ 卡片视图间距（`TAB/prediction.py`）：卡片块间距 18→24px、卡片外边距 12→14px、分析卡内边距 16→20/18px、指标网格 12→16px、指标块高 58→62px、球区最小高 112→120px、特别码与正码之间 24px；1180×720 允许纵向滚动（实测最大 81px），无横向滚动、无控件重叠、无裁字，七张卡均可滚动到且内容完整
- ✨ 结果持久化：`render_number_strategy_results` 成功后调用 `save_number_strategy_result`，写入 `系统v7.5/上次预测_号码预测.json`。字段：`generated_at`、`data_fingerprint`、`window`、`used_records`、`latest_period`、`selected_index`、`strategies`（`key/label/numbers/special/scores/principle/analysis/error`）；统一走 `host._safe_write_json`（重试 + 原子替换），仅在 `ok` 且有策略条目时写入，避免覆盖上一次可用结果
- ✨ 启动回填：`plugins/彩票预测.py` 在 `load_last_prediction` 之后调用 `load_number_strategy_prediction`；该函数只读 JSON 并复用既有渲染函数，恢复文本 + 卡片 + 上次 chip 与说明区，不调用 `predict_all`。指纹一致提示「已恢复上次生成结果」；指纹不一致保留旧结果并在提示标签红字标注「上次结果的数据已变化，需重新生成（旧结果已过期）」；文件不存在时静默返回，页面保持空状态
- ✨ 选中策略记忆：chip/文本行切换调用 `_persist_number_strategy_selection`，只更新已落盘文件的 `selected_index`，不改号码、不重算；`[WidgetState]` 既有三条键名（`c_number_pred_view_combo` / `b_number_pred_hide_labels_check` / `number_pred_splitter_sizes`）不变
- ✅ 实测（真实 Windows 窗口）：1180×720 与 1600×1000、浅色/暗色共 8 张截图；15/20/24px 三档 doc 759/787/800（视口 802）、横向滚动=0、四列 x 偏差=0；卡片 1180 滚动区 viewport 808×603、body 808×658、横向滚动=0、纵向最大 81px、七张卡 y 间隔 24px、球/分析卡重叠 0；跨进程「生成→正常 closeEvent→新进程启动」文本与卡片逐值一致、chip 恢复为上次索引、`predict_all` 调用 0 次；修改历史数据后启动出现「已变化/过期」提示且 `predict_all`=0；删除结果文件后页面为空无报错
- ✅ 约束：未改 `lib/math_algo.py`、`run.py`、`UI/UI.py`；未改七策略计算与特别码规则；无新增第三方依赖；`docs/生成目录树.py` 的 `DESCRIPTIONS` 新增该运行时文件并加入忽略名单，文件未生成时 `--check` 仍为 0
- 📄 同步：README 升 v0.0.49；功能说明补间距与持久化口径；UI 规范补间距数值与结果文件；公告页版本号同步；`docs/代码修改索引.md` 重新生成

### v0.0.48
- ✨ 新增「号码预测」卡片视图（`TAB/prediction.py`）：面板顶部新增「视图」下拉（`c_number_pred_view_combo`，0=文本列表 / 1=卡片视图，默认 0），主体改 `QStackedWidget`；卡片页含 7 个策略 chip（热门/冷门/综合/均衡/走势/马尔科夫/机器学习，选中项按策略主题色高亮）、6 个正码球一排 + 16px 间隔 + 1 个 `#D32F2F` 红底特别码、球下 `生肖·五行` 说明、底部「指标 + 数值」分析卡（策略/正码均分/最高得分/最低得分/特别码/分析窗口/参与期数/最新期号 8 项 + 现有 analysis 文本）
- ✨ 双视图共用一次计算：`host._number_strategy_results` 为唯一数据源；点「生成七策略」只调用一次 `NumberStrategyPredictor.predict_all`，切换视图或 chip 只重排显示，不重算；复制按钮在卡片视图下输出与文本视图等价的七行文本
- ✨ 文本视图补生肖五行：每个号码后跟 `03虎·木`（`%02d` 两位补零 + 生肖 + `·` + 五行），正码段与特别码段都带；标签用 `QFontMetrics` 按当前绑定里最长「生肖+五行」组合定宽并补半角空格，数字按「数字 px」粗体、标签固定 15px，制表位按加粗策略名 + 2 空格动态换算，七行四列 x 坐标恒定
- ✨ 生肖/五行实时读取：`_number_strategy_bindings` 每次渲染都读 `系统v7.5/生肖绑定.json` 的 `names`（存在时覆盖）+ `host.zodiac_binding`，五行读 `LotteryConfig.NUMBER_ELEMENTS` + `host.zodiac_elements`；无 `(num-1)%12` 硬编码、无导入期快照
- ✨ 新增「只显示号码」复选框（`b_number_pred_hide_labels_check`，默认 0=显示标签）：1180 宽下带标签仍余 77px，勾选后隐藏标签；恢复由 `_sync_number_strategy_view_state` 在 `[WidgetState]` 恢复后 `singleShot(0)` 同步 stack 页与内部开关
- ✨ 全局字体（`plugins/彩票预测.py` + `TAB/widgets.py`）：字体栈 `Microsoft YaHei → SimHei → SimSun → Arial`（全部 Windows 自带，无字体文件）；全局 QSS 正文 `font-weight: 500`，标题/表头/tab 选中/版本号/号码/策略名为 700；`FontUtils.create_font` 非粗体只设 `QFont.Weight.Medium`（不再调用 `setBold(False)`，避免重置回 Normal 400），粗体设 Bold + `setBold(True)`；亮色正文 `#1A1A1A`、暗色 `#F5F5F5`，次要文字亮 `#444444` / 暗 `#D0D0D8`；15px 下限与 `max(15, ...)` 逻辑保持不变
- 🐛 修复：文本/说明区与卡片样式随主题切换（暗色深底浅字 `#1E1E2E`，亮色白底）；状态栏新增 `_set_number_pred_status` 按 ok/error/info 主题化着色（暗色对比 ≥ 8.2:1）
- ✅ 验证（真实 Windows 窗口）：1180×720 文本 viewport 802×296、doc 725×268、hscroll/vscroll=0；字号改 24 后 doc 787/802、hscroll=0、四列 x max-min=0；1180 卡片页 820×603、hscroll/vscroll=0、chip 末项右边界 616、7 球无重叠；改 03 生肖后标签 `03虎·木 → 03鼠·木`；重启恢复 `c_number_pred_view_combo=1` / `b_number_pred_hide_labels_check=1`；顶栏 6+ 按钮 `sizeHint == 实际宽` 不裁字；大数据状态排 1180 折 4+4（one_row_need=1125/实际 1144）、1600 单行（1576）
- ✅ 约束：未改 `lib/math_algo.py`、`run.py`、`UI/UI.py`；未改七策略计算、特别码排除规则与 `number_pred_splitter_sizes` 记忆键；无新增第三方依赖
- 📄 同步：README 升 v0.0.48；功能说明补卡片视图/双视图切换/生肖五行标签口径；`docs/UI设计规范与记忆机制.md` 补字体栈、字重、颜色与两个新记忆键；公告页版本号同步；`docs/代码修改索引.md` 重新生成；`docs/生成目录树.py --check` 退出码 0

### v0.0.47
- 📄 文档：新增 `docs/Python Flet 控件与UI开发完整手册.html` —— 按第二版提示词重做的自包含单文件 Flet 手册（14 部分：开篇/名词/语法/90 控件画廊/设计规范/定位/交互动画/页面栈/Overlay 三大下拉/调试/12 练习/选型/进阶/附录）
- ✅ 覆盖面：90 个控件卡片，九大类 22+8+14+9+13+9+4+2+9；311 段 Flet 代码；Dropdown / PopupMenuButton / Popover 与 Overlay 为重点（含 6 类 Dropdown 场景、四向定位 + 居中/XY/长内容/嵌套、AlertDialog、三级对比表、定位调试与排错清单）
- ✅ 交互：明暗主题、Header 滚动虚化、滚动进度条、113 项目录与右侧锚点同步、实时搜索高亮跳转、目录分组折叠（记忆状态）、代码复制 + 3 秒可关闭 Toast、四色提示块、卡片折叠动画、视口入场动画、焦点环、移动抽屉、预览弹窗
- ✅ 离线自检：933 KB，无 `http(s)://` 外链 / `@import` / `<script src>` / `<img>`；14 个 section、190 个 h3、275 个 id 无重复，目录锚点全部命中；内联 JS `node --check` 通过；浏览器实测搜索「级联」16 条结果并跳转高亮、主题切换、目录折叠展开、卡片展开、进度条与 Header 虚化通过
- 📄 同步：README 升 v0.0.47；`docs/生成目录树.py` 的 `DESCRIPTIONS` 新增本文件，`--check` 退出码 0；`requirements.txt` 无新增依赖，保持不变
- ✅ 约束：未改动 `run.py`、`UI/UI.py`、`TAB/`、`lib/`

### v0.0.46
- ♻️ 重构（迁移批次 B1，行为保持）：`plugins/彩票预测.py` 7 项残留页面实现归位，主窗口 4355 → 4046 行（-309）
  - A5/A6：顶栏「导入/导出」改为 `lambda: _tab_history.on_import_history(self)` / `on_export_history(self)`，删除窗口内 `_on_import_clicked`（16 行）、`_on_export_clicked`（50 行）
  - A7：删除窗口 `_json_default`；`_safe_write_json` 与 `TAB/prediction.py` 的 `compute_data_fingerprint` 统一引用 `MLPredictionModel._json_default_handler`，全项目仅一份
  - A4：`_validate_record` / `_show_validation_results` 迁入 `TAB/data_import.py`（模块函数 `validate_record(host, record, is_batch=False)` / `show_validation_results(host, all_issues)`），`install()` 同名绑定；`install` 文档与注释由「4 个回调」改为 6 个，并更正「供多页调用」为仅本页两处
  - A10：删除死代码 `_update_legend_display`（2 行实现 + 唯一调用点 `_apply_custom_number_colors` 内 3 行 if 块）
  - A3：`_on_export_report`（109 行）迁入 `TAB/prediction.py` 的 `on_export_report(host)`，窗口仅保留 `install()` 绑定；HTML 模板、样式、最近 5 期、统计口径逐字保留
  - A8：新建 `lib/report_builder.py`（理由：lib 下无报告构造函数，且与 [3] 分析报告模板不同，避免混成第三份模板），提供 `build_algorithm_report_html` / `write_algorithm_reports`；窗口 `_on_batch_export_reports` 仅保留确认、选目录、状态栏与提示
  - A9：新增 `lib/data_process.DataUtils.validate_number_combo(numbers)` 纯函数（数量/去重/范围校验 + 和值/单双/大小/三色统计），窗口 `_on_validate_number_combo` 仅保留输入解析与弹窗，提示文案逐字不变
- ⚠️ 行为差异（已核对，按 history.py 版为准）：
  - 顶栏导出：默认文件名 `彩票数据导出.json` → `彩票历史记录导出.json`；对话框标题 `导出数据` → `导出历史记录`；成功提示 `已导出 N 条数据（X格式）` → `已导出 N 条历史记录（X格式）`；空数据提示 `没有可导出的数据` → `没有可导出的历史记录`
  - 顶栏导入：对话框标题 `导入数据` → `导入历史记录`；文件过滤器去掉 Parquet（`*.json *.csv *.txt`）；成功提示 `已导入 N 条记录` → `已导入 N 条历史记录`；页面按钮行为不变（本来就是这份实现）
  - 其余导出分隔符、UTF-8-SIG 编码、两位补零、导入解析规则均一致
- ✅ 验证（实测）：
  - `python -m py_compile` 插件 / `TAB/prediction.py` / `TAB/data_import.py` / `TAB/history.py` / `lib/data_process.py` / `lib/report_builder.py` 全部通过
  - 非 offscreen 真实主窗口启动成功，16 个选项卡标题全部加载
  - 顶栏真实按钮 click：导出 JSON 成功且与迁移前数据逐值一致；CSV 表头 `期号,日期,正码1...特别码` 一致；导入 1 行 CSV 后历史记录 +1
  - [3]「导出报告」真实按钮 click：迁移前后 HTML 去掉「生成时间」后逐字一致（1652 vs 1652 字符）
  - 顶栏「批量导出报告」QAction 触发：22 个文件名与内容（去掉生成时间）与迁移前一致（1 个算法名含非法字符被跳过，属迁移前既有行为）
  - 号码组合：合法 `1,2,3,4,5,6` 提示「红2 蓝2 绿2 / 和值21 / 单双3:3 / 大小0:6」；非法（少于6个/重复/超范围/非数字）四类提示逐字一致
  - `data_import` 校验：合法记录返回 `[]`；期号 999 重复返回 `('error','期号重复: 第999期已存在')`；空问题返回 True；仅警告返回 True 且提示文案一致
  - `_update_legend_display` 删除后 `hasattr` 为 False，`_apply_custom_number_colors()` 正常无 NameError
  - JSON 处理器：numpy int/float/array 写入成功（`7` / `1.5` / `[1,2]`），数据指纹正常
- 🛠️ 索引脚本修正：`docs/生成索引.py` 实测 8 处过期 needle（排序相关 3 处：`_on_do_number_sort` 两处、`_on_sort_sep_changed`；选尾 2 处：`_on_do_number_tail`、`_on_tail_sep_changed`；大数据 3 处：`_on_bigdata_analyze_clicked`、`_on_bigdata_copy`、`_on_bigdata_export`），已改为 `TAB/number_sort.py` / `TAB/number_tail.py` / `TAB/bigdata_analysis.py` 的实际函数；`2.3` 调用链示例同步改为 `on_do_number_sort(host)`；`FILES` 新增 `lib/report_builder.py`；索引重生成 4283 行
- 📄 同步：README 升 v0.0.46 并将 v0.0.45 转历史；本文件追加日志；功能说明新增 16.8；公告页版本号同步；`docs/生成目录树.py` 的 `DESCRIPTIONS` 新增 `lib/report_builder.py`，`--check` 退出码 0；`requirements.txt` 无新增依赖，保持不变（新增代码仅用标准库 os/datetime/collections）
- ✅ 约束：未改 `lib/math_algo.py`、`run.py`、`UI/UI.py`；`_save_data` / `_analysis_records` / `_parse_numbers_from_text` 等跨页共用方法保持不动

### v0.0.45
- 🐛 修复（逐号码插值遗漏）：`lib/math_algo.py::scipy_optimization_algorithm` 的 `interp_missing` 原以「号码序号」为 x、以 1..30 号遗漏为 y 拟合样条，循环内又固定 `get(1)`，49 个号码共用同一个外推值；改为新增 `_predict_next_missing_by_spline`，对 1..49 每个号码用自己的旧→新遗漏序列做 `splrep(k=3, s=N)` 并在 x=N 外推下一期，再用可行性约束剪到 `[0, 当前遗漏+1]`。100 期实测：键 3→49、不同值 1→32，冷算 0.104s、热缓存 0.00006s
- 🐛 修复（sklearn 特征前缀化）：`_build_sklearn_feature_vector(idx)` 原忽略 idx、读取全量 `frequency/missing/moving_avg/autocorrelation`，所有期生成同一向量；改为新增 `_build_prefix_feature_table`，按「只用第 idx 期及更旧历史」前缀累积计算 49×7 特征（频率、遗漏/50、MA5/10/20、一阶自相关、zscore/5），冷算 21.7ms、热缓存 0.00009ms。四个调用点（`_gb_predict_probs`、`_nb_missing_probs`、`_mlp_adjacent_probs`、`sklearn_ensemble_algorithm`）标签改为紧邻特征窗口的未来期（1 期或 2 期），推理统一改用第 0 期（全部历史）特征，窗口与标签不重叠、无未来泄漏
- 🐛 修复（NumPy 时间回归）：`_np_linear_regression_trend` 原以 `np.arange(20)`（号码序号）为 x 对 `missing(1..20)` 做横截面回归，外推得到的是「第 21 个号码」的遗漏；改为对 1..49 每个号码的逐期遗漏序列以「期序」为 x 做 `lstsq` 直线拟合并外推 x=N（同样按 `[0, 当前遗漏+1]` 约束剪裁），写入 `np_predicted_missing_by_num`；`_np_regression_bonus` 改为 `max(0, 10 - max(0, p_n)*0.5)`，预测下一期遗漏越短加成越高，实测 34 种不同值
- ✅ 验证（100 期真实数据前后对照）：`interp_missing` 1 种常量→32 种（49 键）；特征 idx=0/50/99 唯一向量 1→3；回归加成 34 种值、`np_predicted_missing_by_num` 由空→49 键；scipy Top6 前后均为 `49,44,47,48,18,16`；GBDT Top6 `5,27,28,21,3,6`→`30,22,23,2,21,29`；集成 Top6 `5,3,26,27,6,21`→`22,30,21,23,2,6`；综合 Top6 `2,3,4,5,7,12`→`2,9,21,22,23,30`
- ⏱️ 耗时（100 期）：构造 14.16→13.40s；scipy 0.245→0.248s（+1.2%）；GBDT 3.734→13.730s（3.7 倍，特征由常量变真实序列后树真正分裂，单次后台计算可接受）；sklearn 集成 33.143→31.851s；综合 22.493→31.255s（1.39 倍）；49×100 逐号码样条冷算 0.104s、热缓存 0.00006s
- 🔁 确定性/缓存：固定 seed 下重复调用与跨实例输出逐值一致；`_data_signature()`（期数 + 全量期号/号码哈希）作为 `_series_cache` / `_sklearn_feature_table_cache` / `_interp_missing_cache` 的键，追加上一期后特征表自动重建；泄漏测试「特征 idx=1 与插入新期后的 idx=2 同一历史窗口」逐值一致
- 📄 同步：README 升 v0.0.45 并将 v0.0.44 转历史；本文件追加日志；功能说明新增 16.7；公告页版本号同步；`docs/代码修改索引.md` 重新生成；`python -m py_compile lib/math_algo.py` 通过；`python docs/生成目录树.py --check` 退出码 0；`requirements.txt` 无新增依赖，保持不变（仅使用已登记的 numpy/scipy/sklearn）
- ✅ 约束：生产代码仅改 `lib/math_algo.py`；未触碰 `TAB/prediction.py`、`plugins/彩票预测.py`、`lib/ml_model.py`。文档侧另补 `docs/生成目录树.py` 的 DESCRIPTIONS 一行（外部任务新增 `Python控件和UI的设计说明提示词2.md` 未登记，导致 `--check` 失败）

### v0.0.44
- 🗑️ 现状：`docs/Python控件和UI的设计说明.html` 已从 `docs/` 删除（无备份、无版本库历史、无可恢复来源），同类内容现由 `docs/Python Flet 控件与UI开发完整手册.html` 提供；以下为该版本当时的记录
- 📄 文档：新增 `docs/Python控件和UI的设计说明.html`（已删除；按同名提示词生成的自包含单文件 Flet 教程：15 章：开篇/前言/语法四大块/九大类控件画廊/设计规范/定位/交互动画/页面栈/Overlay/调试/12 练习/选型/进阶/附录/自检）
- ✅ 控件覆盖（当时，数据仅存档）：布局 22 + 导航 8 + 信息 14 + 按钮 10 + 输入 13 + 浮层 9 + 图表 4 + 动画 2 + 工具 9 = 91 个卡片，每卡固定 8 段结构并带纯 CSS 外观预览
- ✅ 离线验证（当时，数据仅存档）：`http://` / `https://` / `@import` / `<script src>` 均为 0；255 个 id 无重复；34 个目录锚点全部命中；`node --check` 通过，浏览器控制台无报错
- ✅ 交互验证（当时，数据仅存档）：汉堡抽屉、目录点击滚动与高亮、浅/暗主题切换、复制按钮、回到顶部、预览弹窗均可用；双主题截图 `.screenshots/flet_doc_light.png` / `flet_doc_dark.png`
- 📄 同步：README 升 v0.0.44；`docs/生成目录树.py` 的 `DESCRIPTIONS` 补「Python 控件与 UI 设计说明单页 HTML（Flet 教程）」（该条目已随文件删除而移除）；`--check` 退出码 0；`requirements.txt` 无新增依赖，保持不变
- ✅ 约束：未改动 `run.py`、`UI/UI.py`、`TAB/`、`lib/`

### v0.0.43
- ✨ 版式：`TAB/prediction.py` 号码预测的策略名与正码之间由「补位空格」改为**真正的制表符** `\t`（`text = label + '\t' + numbers + '   +   ' + special`）。`toPlainText()` 与剪贴板 `copy()` 实测七行均保留 `\t`，仍无任何下划线字符；六正码与特别码继续 `%02d` 两位补零
- ✨ 对齐：`host.number_pred_text` 新增 `setTabChangesFocus(False)`（Tab 不被焦点链吞掉）；`_apply_number_strategy_formats` 内按「文字 px」动态设置 `setTabStopDistance(最长策略名宽 + 2 个半角空格余量)`，字号变化时制表位随之换算，不写死像素。四档字号实测七行四列起点：

  | 文字 px | tabStop | nameX | numX | plusX | specialX |
  |---|---|---|---|---|---|
  | 15 | 80.0 | 8 | 88 | 282 | 314 |
  | 20 | 100.0 | 8 | 108 | 308 | 348 |
  | 22 | 110.0 | 8 | 118 | 321 | 365 |
  | 24 | 120.0 | 8 | 128 | 334 | 382 |

  每档 `max-min = 0`（name/num/plus/special 四项全部为 0）；正码段字符数恒为 17（6×2 位 + 5 个分隔空格），因此 `plusX` 只由正码段宽度决定，与策略名长短无关
- ✅ 不变项：特别码红色加粗、行高随「尺寸」（高度×0.6，下限字号+4、上限 60px）、「数字 px / 文字 px / 尺寸」联动、说明区与七策略计算逻辑、`[WidgetState]` / `number_pred_splitter_sizes` 记忆均未改动
- ✅ 验证：真实窗口 1180×720，viewport 802×306、内容高 268px，横/纵滚动条最大值均为 0；截图 `.screenshots/号码预测_v0042_1180x720.png`；`py_compile` 通过；`docs/生成目录树.py --check` 退出码 0
- 📝 备注：制表符方案在等宽字体（NSimSun 字符格式锁定）下稳定，未启用回退；复制到记事本按 Tab 跳位显示、粘贴到 Excel 会按 `\t` 自动拆成「策略名 / 正码 / + / 特别码」多列（本机未安装 Excel，未做实际粘贴实测，按剪贴板内容推断）

### v0.0.42
- ✨ 字号下限收尾（R1）：`TAB/info.py` 正文基准 14→15，缩放后三档字号统一 `max(15, ...)`；`TAB/number_sort.py` / `TAB/number_tail.py` 初始基准 14→15；`TAB/number_selection.py` 图例缺省值 14/13→15/15；`TAB/widgets.py` `_label_font` 12→15、`_current_label_font` 10→15、`base_label_font` 10→15，五行标签行高 16→21；`TAB/history.py` 详情标题/分组/号码/表格/小字/微字统一钳制 15px，尾数分布与连号两行由写死 18px 改为 `table_size`
- ✅ 验证（R1）：离屏真实窗口 1180×720 与 1600×1000 截图 `.screenshots/v0041_数字排序_*.png` 等；数字排序/数字选尾结果框、公告 QLabel、五行/生肖 QLabel 实测 `font().pixelSize()` 最小 15，无 0 值；五行面板 680×493，大字号下由滚动区承载，标签文字未见裁切
- 🐛 修复（R2 存储一致性）：`TAB/data_storage.py` 新增 `make_unique_storage_identity`（微秒时间戳 + 冲突序号），笔记/图片/文件/粘贴图 ID 不再秒级撞车，图片与文件标题改为落盘文件名；`save_storage_index` 返回 `bool`，新增 `notify_if_index_save_failed` 在失败时弹窗且调用方不再提示成功；批量删除失败项保留索引并汇总提示；`import_image_file` / `import_data_file` / `save_new_note` / `import_text_file_as_note` 返回成功标志，`handle_dropped_files` 按真实成功计数；`update_note` 未找到 note_id 时提示并跳过标签/索引写入，且先写磁盘再改内存；重命名同步重命名图片/文件（同名目标报错、失败不改索引）；备份 zip 跳过目标文件自身；文件信息由 `information` 改 `question`
- ✅ 验证（R2）：脚本冻结时间戳连续生成 3 个 ID 得到 `img_..._123456`、`_1`、`_2`（含既有索引时为 `_3`）；不可写路径 `save_storage_index` 返回 `False`，正常路径返回 `True` 且 `index.json` 条目数一致；`import_image_file` 返回 `True` 且 `title == basename(file_path)`
- 🐛 修复（R3 单双方向）：`lib/math_algo.py` `odd_even_algorithm` 的 LR 分支先 `odd_seq[::-1]` 转为「旧→新」再训练，预测输入改 `odd_chrono[-1]`；复现显示原实现预测输入取最旧一期（100 期数据：旧输入 3=最旧、新输入 2=最新），该数据下 Top 结果未变但语义修正
- 🐛 修复（R4 特征泄漏/聚类）：`pytorch_deep_learning_algorithm` 改为一次性前缀累积（`occ`/`cum_occ`/`pcum`/`last_seen`）生成每期 5 维特征，只用当期及之前历史，替换全局 `frequency/moving_avg/autocorrelation`；对比 100 期数据：样本 idx=5 号码 1 的旧特征 `[0.15, 0.16, 0.0, 0.1, 0.0688]` 使用全部 100 期，新特征 `[0.3333, 0.02, 0.2, 0.3333, -0.4082]` 仅用 6 期，方法耗时 2.31s→2.17s，Top6 输出未变（`[5,3,35,18,24,27]`）；`sklearn_ensemble_algorithm` 的 KMeans 改用 `n_clusters=min(5, n_samples)` 并对每簇取出现率最高 7 码，打印样本数/簇数，异常时显式退化全局中性；社区兜底 `_nx_community_fallback` 将 KMeans 簇号×5 改为按簇内平均频率降序映射 20/15/10/5/0，删除未使用的 `latest_nums`；20 期对比：修复前全码常数 +10（等价无聚类）得到 `[5, 26, 3, 9, 22, 25]`，修复后 `[5, 26, 3, 22, 25, 4]`，聚类加成真正生效
- 🐛 修复（R6）：`TAB/backtest.py` `on_start_backtest` 增加 `_backtest_running` 重入保护、每 5 期 `QApplication.processEvents()` 与进度状态栏；离屏实测 5 期回测 `rows=5`、结束后标记恢复 `False`、状态栏「回测完成」；`TAB/seventh_prediction.py` 四个预判统一先过滤 1~49 有效特别码，缺失 2 条记录时样本由 12→10、双号 9→7、小尾 11→9；`TAB/bigdata_analysis.py` 同步长任务仅登记 QThread 方案未改
- ✅ 验证（编译）：`py_compile` 覆盖 `data_storage/widgets/info/number_sort/number_tail/number_selection/history/backtest/seventh_prediction/bigdata_analysis/math_algo` 全通过
- 📄 文档：README 升 v0.0.42；功能说明新增 16.6；公告页版本号同步；`requirements.txt` 无新增依赖，保持不变；`docs/代码修改索引.md` 已重生成（并发任务 01:20 最后刷新，4484 行，覆盖 `prediction.py` 最新改动）；`python docs\生成目录树.py --check` 退出码 0
- ⏳ 待跟进：`TAB/prediction.py` 中图例号码行下限仍为 9px（并发任务占用，本轮未改），需在 v0.0.43 抬到 15px

### v0.0.41
- ✨ 版式：`TAB/prediction.py` 号码预测面板由三列 `QTableWidget`（策略 110 固定 / 正码 Stretch / 特别码 90 固定）改为只读 `QTextEdit` 逐行纯文本；每行为 `策略名 + 补位空格 + 3 空格 + 6 正码 + 3 空格 + "+" + 3 空格 + 特别码`，不含 `___` / `__+__` 等下划线字符。策略名用 `QFontMetrics(NSimSun)` 按最长「机器学习」补 ASCII 空格到同一像素列宽，七行正码列实测统一从 x=118 起
- ✨ 字号/尺寸联动：新增 `_number_strategy_mono_font` / `_number_strategy_fonts` / `_number_strategy_line_rows` / `_apply_number_strategy_formats` / `_apply_number_strategy_detail_font` / `_render_number_strategy_text` / `refresh_number_strategy_styles`。数字 px（`_prediction_ball_size['font']`）→ 正码与特别码；文字 px（`ball_label_font_size`）→ 策略名、加号、说明区；尺寸高度 `×0.6` → 固定行高（下限 `max(字号)+4`、上限 60px）。`on_pred_num_font_changed`、`on_pred_text_font_changed`、`apply_prediction_ball_size` 三个既有回调末尾调用 `refresh_number_strategy_styles`，复用同一套状态，未新增字号变量
- ✨ 记忆：`number_pred_splitter` 加入 `_save_ini_config` 的 `splitter_list` 与 `_apply_ini_config` 的 `splitter_names`，新增 `[Display] number_pred_splitter_sizes`（隐藏页仍不写当前值）；分析期数 `s_number_pred_window_spin`、角控件 `s_pred_num_font_spin` / `s_pred_text_font_spin` 继续走既有 `[WidgetState]` 自动扫描，键名不变
- 🐛 修复（记忆）：UI 构建期 `_update_probability_panel` 等刷新会调用 `_save_ini_config()`，此时控件仍是默认值，且该函数会 `self._ini = ini` 覆盖内存配置，导致 `_restore_widget_states()` 读到已被覆盖的默认值（实测：`s_number_pred_window_spin` 存 60，重启后控件与 INI 均为 100）。`__init__` 增加 `_ini_write_enabled` 门闩：`_init_ui()` 前置 False、`_restore_widget_states()` 后置 True，禁用期间 `_save_ini_config()` 直接返回 False
- ✅ 验证（版式）：真实窗口 1180×720，七行 `numX=118`、`plusX=318`、`specialX=358` 全部一致；行高 36px（内容高 268px、视口 306px），无纵向、无横向滚动条。复制文本：`热门       03 05 06 22 26 30   +   40` … `机器学习   03 08 22 27 35 38   +   40`
- ✅ 验证（联动）：数字 px 15/24 → 正码字号 15/24、`plusX` 284/352；文字 px 15/22 → 策略名与说明区 15/22、`numX` 96/129；尺寸高度 30/60/120 → 行高 24/36/60、内容高 184/268/436（120 时出现纵向滚动，属预期）
- ✅ 验证（记忆）：phase1 写入 60 / `[420,180]`，关闭后 INI 为 `s_number_pred_window_spin=60`、`number_pred_splitter_sizes=435,186`；phase2 新进程启动恢复 60 / `[435,186]`，与退出前一致；随后已还原用户原值 100 / `[316,305]`
- 📄 文档：`docs/UI设计规范与记忆机制.md` 新增 3.6「设置项与 INI 键体系」（五类前缀对照表 + 窗口/主题/字号/选项卡/15 组分隔条/8 个 `font_scale_*` 键名规则 + 新增功能登记要求 + 号码预测样板）；功能说明 [3] 展示格式更新并指向该节；README 升 v0.0.41；公告页同步；`docs/代码修改索引.md` 重新生成；`requirements.txt` 无新增依赖，保持不变

### v0.0.40
- 🐛 修复（P0）：`TAB/data_storage.py` `init_storage_data` 无条件重置分类/排序/折叠，覆盖 `_load_ini_config` 已恢复的 INI 记忆；改为 `getattr` 仅在属性缺失时取默认值
- 🐛 修复（P0）：`lib/data_process.py` 新增 `LotteryConfig.DEFAULT_NUMBER_ELEMENTS` 只读出厂副本；`TAB/element.py` / `TAB/zodiac.py` 的「恢复默认」改用副本，避免 `NUMBER_ELEMENTS.update()` 原地改写后取不到出厂表
- 🐛 修复（P0）：`TAB/history.py` `refresh_latest_display` 原只写 `host.latest_display`，历史页控件 `host.history_latest_display` 不更新；现两个控件同时刷新并补空数据提示；`plugins/彩票预测.py` 删除 `_update_history_table` 中用 `data_to_show[0]` 的重复覆盖，筛选时也显示真正最新一期
- 🐛 修复（P0）：`TAB/history.py` `on_batch_modify` 未选中行时被空 `selected_rows` 覆盖，导致「全部数据」分支失效；现仅在选中时换算分页偏移
- 🐛 修复（P1）：`TAB/history.py` TXT 空格格式按 9 段解析，特别码取 `parts[8]`，不再重复第 6 个正码
- 🐛 修复（P1）：`TAB/prediction_history.py` 删除函数开头无赋值裸字符串，保留单一 docstring
- 🐛 修复（P1）：`TAB/number_selection.py` 三色图例号码改为按当前 `LotteryConfig` 分组动态生成
- 🐛 修复（P1）：`TAB/widgets.py` `plot_correlation_heatmap` 补 `figure/canvas` 判空，matplotlib 缺失时静默降级
- 🐛 修复（P1）：`lib/ml_model.py` `load_models` 比对文件 `fingerprint` 与当前数据指纹，不一致返回 `None` 重新训练
- 🐛 修复（P1）：`lib/ml_model.py` 四个模型训练/缓存分支改用局部 `model_probs` 累加，循环中途异常时整块丢弃，`model_count` 不再偏小
- 🐛 修复（P1）：`lib/db_helper.py` `_get_duckdb`、`query_analysis`、`_init_duckdb_tables` 统一持 `_duckdb_lock`，并发首连只建一次连接
- 🐛 修复（P2）：`lib/math_algo.py` 移动平均 `series[-window:]`→`series[:window]`；遗漏遍历由 `reversed(self.data)` 改为 `self.data`；轮盘标签 `data[-1]`→`data[0]`
- 🐛 修复（P2）：`lib/math_algo.py` 马尔可夫转移改为「较旧→较新」，最新状态取 `odd_seq[0]`，回退取最近 5 期
- 🐛 修复（P2）：`lib/math_algo.py` `_prepare_tensorflow_model` / `_prepare_pytorch_model` / `pytorch_deep_learning_algorithm` 改为「旧→新」滑窗，标签取窗口后一期，预测窗口改为最新 5/10 期
- 🐛 修复（P2）：`lib/math_algo.py` `_nx_community_fallback` 将 ndarray KMeans 标签转字典；异常兜底号码只 `randint` 一次；报告标题「推荐 N 生肖/数字」按实际条数
- 🔍 暂不修：`_build_sklearn_feature_vector` 忽略 `idx`（全样本特征相同）需要重排标签与特征工程，无法在不重构前提下安全修正；插值遗漏 `.get(1)` 按“未来期”口径而非号码口径；线性回归自变量为号码序号属既有设计，均只记录
- ✅ 验证：`python -m py_compile` 覆盖 13 个改动文件通过；真实 `系统v7.5/彩票数据.json` 100 期探针对比；UI 离屏窗口 1180×720 截图 `.screenshots/v0040_历史页_1180x720.png`（标签几何 719×67，窗口坐标 16,220）
- 📄 文档：README 升 v0.0.40（v0.0.39 转历史版本）；config.md 分隔符 15 项/在线更新已移除；功能说明工具栏标题行删除并补修复索引；公告页版本号同步；`docs/代码修改索引.md` 重新生成；`requirements.txt` tensorflow 恢复为可选注释

### v0.0.39
- ✨ 新增：`TAB/prediction.py` 在 `_build_right_prediction_panel` 中新增第五个子选项卡「号码预测」（索引 1，紧随「预测结果」）。`_build_number_prediction_panel` 构建标题行（`number_pred_window_spin` 分析期数 30~500、默认 100；`number_pred_generate_btn`）、状态标签 `number_pred_status_label`、`number_pred_splitter`、三列表格 `number_pred_table`（策略 110px 固定 / 正码 Stretch / 特别码 90px 固定）与只读说明区 `number_pred_detail`；表格选中行变化调用 `on_number_strategy_selected`，按钮点击调用 `on_number_strategy_predict`
- ✨ 算法：`lib/math_algo.py` 新增 `NumberStrategyPredictor`（7 策略常量、七条公式文案、特码口径）+ 特征提取 `_compute_features`（全窗口频率、整数次数、近 5/10/20 期、前 10 期、遗漏、平均间隔、超期比、特码频率、20 期 0/1 序列斜率、最新状态后继转移强度）+ 归一化 `_minmax/_zscore` + `_build_score_maps` + `_ml_scores` + `_balance_penalty/_select_balanced` + `_select_special` + `_analysis_text` + `predict_all`
- ✨ 七策略公式（与代码逐项一致）：热门 `0.65·F_all + 0.35·F_10`；冷门 `0.55·Gap + 0.30·Overdue + 0.15·(1-F_all)`；综合 `0.40·Hot* + 0.25·Cold* + 0.35·Trend*`（Hot*/Cold*/Trend* 为三基础分再 min-max）；均衡 `0.30·M_freq + 0.25·M_gap + 0.25·F_10 + 0.20·Trans`（M=1-min(1,|Z|/2)）+ 奇偶 3:3 / 大小 3:3 / 尾数 / 波色 / 生肖分散贪心惩罚；走势 `0.45·F_5 + 0.30·Slope_20 + 0.25·max(0,F_10-F_prev10)`；马尔科夫 `0.70·Trans + 0.20·F_10 + 0.10·(1-Gap)`；机器学习取 `MLPredictionModel.predict_with_all_models` 四类模型概率算术平均
- 🐛 规避：`historical_data` 为 `insert(0)` 倒序，`_order_records` 显式按 `period` 降序重排后再取最新 N 期，避免照抄 `docs/号码预测.md` 的升序假设；特别码在非正码候选池中按特码历史频率择优，确保 7 号互不重复且结果确定性可复现；生肖使用调用方传入的 `host.zodiac_binding`，未传时才回退 `LotteryConfig.NUMBER_NAMES`；少于 30 期时 `predict_all` 返回 `ok=False` 与逐行错误，界面红字 + 弹窗，不静默出号
- ✅ 验证：`python -m py_compile lib\math_algo.py TAB\prediction.py` 通过；真实 `系统v7.5/彩票数据.json` 100 期实测七策略输出 7 组不同号码（热门 `03 05 06 22 26 30 +40`、冷门 `11 16 17 18 24 35 +47`、综合 `05 06 21 22 26 30 +40`、均衡 `03 22 25 30 38 47 +48`、走势 `06 09 21 22 26 30 +48`、马尔科夫 `03 05 06 22 30 40 +39`、机器学习 `03 08 22 27 35 38 +40`）；特别码均不在正码内；数据不足 20 期测试返回 7 行明确错误
- ✅ 布局：1180×720 实际窗口截图 `.screenshots/号码预测_1180x720.png`、面板 `.screenshots/号码预测_面板.png`；三列宽度 `110 / 618 / 90 = 818px`，无横向滚动条；七行行高 38px，说明区可滚动
- 📄 文档：README【版本状态】升 v0.0.39（v0.0.38 转历史版本）；功能说明 [3] 补「号码预测」子选项卡与七策略公式；公告页版本号同步 v0.0.39；`docs/代码修改索引.md` 重新生成；目录树刷新；`requirements.txt` 无新增依赖，保持不变
- 🔧 工具：`docs/生成目录树.py` 的 `EXCLUDE_FILE_NAMES` 增加 `app_config.db-shm` / `app_config.db-wal` —— 二者为 SQLite 连接期间的运行时旁路文件，程序退出后可能残留，若写入目录树会导致每次运行后 `--check` 失败；`python docs/生成目录树.py --check` 现为 0

### v0.0.38
- ✨ 注释：`TAB/` 17 个页面与公共控件文件补全中文注释，只增注释、不改任何逻辑。净增 4784 行（文件总行数 16539→21323）：A 批 +1664（`__init__.py` 51→84、`data_import.py` 336→534、`info.py` 795→967、`favorites.py` 253→295、`prediction_history.py` 206→348、`number_sort.py` 414→566、`number_tail.py` 447→619、`widgets.py` 1289→2042）；B 批 +1816（`history.py` 1149→1470、`statistics_chart.py` 472→772、`backtest.py` 460→623、`zodiac.py` 544→813、`element.py` 567→868、`number_selection.py` 500→727、`seventh_prediction.py` 548→783）；C 批 +1304（`data_storage.py` 2323→3039、`bigdata_analysis.py` 902→1490）
- ✨ 规范：模块 docstring 写页面职责、`TAB_INFO`（title / order / enabled）、依赖的 lib 能力、页面在整体数据流中的位置；函数 / 方法 docstring 写功能、参数（类型与含义）、返回值、副作用；`install(host)` / `build(host)` 与事件回调写清由谁调用、host 上挂载的属性与回调；行内注释只解释「为什么」（40px 角控件、min/max-height 校准、信号阻断时机、`QTimer.singleShot(0)` 延迟恢复、splitter 尺寸恢复校验条件、字号 15px 下限）
- ✨ 样式表：已有 v0.0.36 逐属性注释保持原样、未重写未重复；缺失处按同范式补齐（`/* 属性：中文说明，真实数值 */` 或样式块上方逐属性说明），数值与代码一致
- ⏸️ 暂缓：`TAB/prediction.py`（批次 D，5283 行 / 83 个函数）按调度暂停，文件已从任务前备份完整还原（SHA256 一致），待「号码预测」子选项卡新功能落地后另行补注释
- 🔍 记录：注释中发现约 30 处疑似问题（`history.py` 的 `latest_display` 属性名不一致、TXT 导出特别码错位、全量修改分支被 `selected_rows` 覆盖、`element.py` 五行恢复默认失效、`data_storage.py` 秒级 ID 撞车与删除失败吞异常、`statistics_chart.py` / `widgets.py` matplotlib 缺失未判空、`backtest.py` / `bigdata_analysis.py` 长任务阻塞 UI 线程等），仅在注释标 `TODO(修复)` / `TODO(待确认)`，未修改代码
- ✅ 验证：17 个改动文件 `python -m py_compile` 全通过；与任务前备份做 AST 等价比对（先摘除 docstring、样式表 `/* */` 注释并折叠空白），17 个文件全部输出 `AST_SAME=True`，非 docstring 字符串语义零变化；`prediction.py` 与备份哈希一致
- ✅ 覆盖率：函数 / 方法 docstring 251/251 = 100%（A 批 83/83、B 批 84/84、C 批 84/84）
- 📄 文档：README【版本状态】升 v0.0.38（v0.0.37 转历史版本）；功能说明新增 3.6「TAB 层注释规范」；公告页版本号同步 v0.0.38；`docs/代码修改索引.md` 因 `prediction.py` 正由其它任务修改而暂缓重生成，待新功能落地后统一刷新；`requirements.txt` 无新增依赖，保持不变

### v0.0.37
- ✨ 注释：`lib/` 6 个模块补全中文注释，只增注释、不改任何逻辑。净增 3587 行（`__init__.py` 357→541、`data_process.py` 434→618、`plot_draw.py` 58→89、`db_helper.py` 682→830、`ml_model.py` 621→789、`math_algo.py` 5585→8457）
- ✨ 规范：模块 docstring 写职责 / 依赖 / 架构位置 / 主要导出；类 docstring 写职责 / 关键属性 / 生命周期与线程约束；函数 docstring 写参数（类型与含义）/ 返回值 / 异常 / 副作用；行内注释只解释「为什么」（阈值来源、时间窗口方向、NaN 处理、单位换算、懒加载顺序）
- ✨ 重点：`math_algo.py` 的 23 种算法逐个说明数学含义、参数与适用场景，`BigDataAnalyzer` 说明频率 / 遗漏 / 一阶马尔可夫三维加权、时间衰减与统计检验；`db_helper.py` 说明 SQLite WAL / `ON CONFLICT` upsert / `threading.Lock` 与 DuckDB 分析链路；`ml_model.py` 说明 10 期 × 58 维 = 580 维特征、49 个号码独立二分类与 pickle 指纹缓存
- 📄 规范：CSS / 样式表字符串逐属性加中文行内注释，数值与代码真实值一致（`FONT_SIZES` 最小值 15px、角控件 40px 等），不照抄示例
- 🔍 记录：注释中发现约 35 处疑似逻辑问题（时间窗口取反、区间特征标签泄漏、`_build_sklearn_feature_vector` 忽略 idx、DuckDB 查询未持锁、模型指纹未复核等），仅在注释标 `TODO(修复)` 并在交付报告列出，未修改代码
- ✅ 验证：`python -m py_compile lib\__init__.py lib\data_process.py lib\plot_draw.py lib\db_helper.py lib\ml_model.py lib\math_algo.py` 全通过；`db_helper.py` / `ml_model.py` / `math_algo.py` 与原始备份做 AST 等价比对（删除 docstring 节点后 `ast.dump()` 一致），三份均输出 `AST_SAME`
- ✅ 覆盖率：函数 / 方法 docstring 230/230 = 100%（`__init__.py` 16/16、`data_process.py` 16/16、`plot_draw.py` 4/4、`db_helper.py` 23/23、`ml_model.py` 15/15、`math_algo.py` 156/156）
- 📄 文档：README【版本状态】升 v0.0.37；功能说明新增 3.5「代码注释规范」；`docs/代码修改索引.md` 重新生成（lib 行号整体偏移）；`requirements.txt` 无新增依赖，保持不变
- 📄 文档：项目目录结构统一刷新 —— README.md、docs/jiego.md、docs/彩票预测系统-功能与设计说明.md 第十二章、docs/dev.md 2.2 共用同一份目录树（每层 2 空格缩进、仅用 `├─` / `└─` / `│`、`#` 注释对齐同一列）；补录 `UI/control_picker.py`、`系统v7.5/数据存储/files/`、`images/`、`notes/` 及首次生成文件；重新运行 `docs/生成索引.py`，无代码变更、行号无漂移；`requirements.txt` 与实际 import 一致，无变化

### v0.0.36
- ✨ 新增：`TAB/widgets.py` 增加右上角控件组共用构建区 —— 常量 `CORNER_HEIGHT=40`、`CORNER_SPACING=6`、`CORNER_SECTION_GAP=12`、`CORNER_RIGHT_MARGIN=8`、`CORNER_SPIN_WIDTH=80`、`CORNER_BUTTON_WIDTH=68`、`CORNER_FONT_PX=15`；函数 `make_corner_container()` / `make_corner_label()` / `style_corner_spin()` / `make_corner_size_button()` / `add_corner_widget()`，[3][4][10][11] 四页统一调用，不再各写一份
- 🐛 修复：四页「尺寸」按钮比同排控件低 3~6px —— 标题行其他按钮沿用全局 `padding:6px 16px` + 2px 边框，实际高 46px 撑高整行；现 [10] 恢复默认/保存绑定、[11] 应用/恢复默认/保存设置加仅尺寸局部样式（内容 30px + 上下 3px，实际 40px），实测四页基线中心 spread=0.0px
- ✨ 优化：[4] 颜色设置对话框内边距与间距 —— 页面 margins `16/14px`、spacing 12px、网格 hspacing 12px / vspacing 10px、输入框最小高 40px；「应用 / 恢复默认」经 `min-height` 校准后同为 40px 高；对话框 `setFixedSize(760,380)` → `setMinimumSize(760,340)` + `resize(820,380)`，并加弹性留白避免提示文字被纵向拉满
- ✨ 优化：全局最小字号 15px —— `lib/data_process.py` `FONT_SIZES` 最小档「小四」12→15；`_update_stylesheet` 的 `font_size` / `small_font_size`、`_apply_autosize`、`_change_area_font_size`、`FontUtils.create_font` 统一加 `max(15, …)`
- ✨ 优化：16 个文件 298 处 <15px 的字号抬到 15px（prediction 81、widgets 38、data_storage 32、info 28、bigdata_analysis 16、element 15、zodiac 13、number_sort 11、plugins 10、backtest 10、number_tail 10、favorites 9、seventh_prediction 7、history 6、number_selection 6、statistics_chart 6）；matplotlib `fontsize` 统一 15；未引入字体库
- 🐛 修复：字号抬升后顶栏在 1180px 下「添加数据 / 删除数据」裁字 —— 左块最小宽 674px > 实际 604px；现按钮组容器级 `QPushButton { padding:6px 10px; }`、组内间距 8→6px，左块最小宽降至 556px；「A- / A+」`setFixedSize(48,34)` 并显式覆盖全局 padding / `min-height`，右块 544px；左右合计 1100px + 边距 30px + 块间距 10px < 1180px
- 🐛 修复：字号抬升后 [16] 大数据分析状态排在 1180px 下重新溢出 —— 新增 `_ResponsiveStatusRow`（`EXTRA_SLACK=24`），以 `max(minimumSizeHint().width(), minimumWidth())` 计算单行阈值 1125+24=1149px，宽度不足时自动折为「4 KPI 一行 + 4 参数一行」并隐藏分隔线
- ✨ 备注：本次批量抬字号后，原注释中的旧值（11/12/13/14px）同步改写为真实值 15px，覆盖 history / number_selection / number_sort / number_tail / prediction 共 28 处
- 📄 文档：README【版本状态】升 v0.0.36；`docs/UI设计规范与记忆机制.md` 第四章改写为角控件组规范并新增 4.5 字号下限；功能说明 [3][4][10][11] 与第十章同步；公告说明版本号同步；`docs/代码修改索引.md` 重新生成；`requirements.txt` 无新增依赖，保持不变
- ✅ 验证：真实 Windows 窗口 1180×800 / 1600×1000 截图（`C:\Users\win\AppData\Local\Temp\lhc_shots\v036`）—— 四页角控件高 40px、基线 spread=0.0px、组内间距 6px、组间 18px；颜色设置对话框按钮等高 40px；全局可见文字 ≥15px；窗口 `minimumSizeHint` 1140×219（1180×720 最小窗口可正常缩到 1180×720）

### v0.0.35
- 🐛 修复：[3] 预测与抽取「预测结果」溢出窗口 —— 「出现概率」页 `prob_stats_label` / `zodiac_prob_stats_label` 未换行，长统计文本 `sizeHint=1058px`，把概率页最小宽顶到 1142px、右栏 1156px、预测页最小宽 1508px，超过 1180px 最小窗口；现两个统计标签统一 `setWordWrap(True)`
- 🐛 修复：`NumberBallWithZodiac` 默认 `Preferred` 尺寸策略被网格拉伸，入场动画结束时 `widget.setFixedSize(target_width, target_height)` 又把拉伸后的尺寸锁死（实测单个球格 143~347px、行高 270px），窗口缩小时内容无法回缩造成溢出；现控件改为 `Fixed` 尺寸策略，球体保持「尺寸设置」中的自然大小（约 88×120px），多余宽度由 `prediction_number_layout` 第 9 列吸收
- 🐛 修复：`PredictionScroll` 原 `ScrollBarAlwaysOff`，号码球或置信度超宽时被直接裁切；现改为 `ScrollBarAsNeeded`；置信度标签（三处创建分支）与特别码提示补 `setWordWrap(True)`
- 🐛 修复：[16] 大数据分析「分析期数 / 频率权重 / 遗漏权重 / 转移权重」被截断 —— `_group` 在构建期用 `label.setFixedWidth(label.sizeHint().width())` 量得 48px，随后全局样式表把字号提升到 20px，实际文字宽 80px，固定 48px 直接裁字；现标签改为水平 `Fixed` 尺寸策略，宽度随当前字体 `sizeHint` 变化
- ✨ 优化：`_kpi_card` 由固定 96px 改为最小 96px（`Preferred` 水平策略），数值变长（如最新期号）时自动加宽，避免裁字（AI_RULES 第 9 条）
- ✅ 验证：真实 Windows 窗口 1600×1000 / 1180×800 截图对比 —— 预测结果区 780px（`minimumSizeHint` 713px）、号码球 6 正码 +「+」+ 特别码单行完整显示、横向溢出判定 False；大数据状态排 13 个直接子控件横向重叠计数 0，四个标签 x=434/606/778/950 宽 80px、文字宽 80px，与右侧 80px 输入框整齐相邻
- 📄 文档：README / 功能说明 [3][16] / 本文件 / 代码修改索引同步；无新增配置项与第三方依赖（仅新增 `UI/UI.py` 已导出的 `QSizePolicy`）

### v0.0.34
- ✨ 优化：[16] 顶部 KPI 与参数合并为同一排，顺序为「参与期数 / 总记录数 / 最新期号 / 波色倾向 / 分析期数 / 频率权重 / 遗漏权重 / 转移权重」，由 `_build_status_row` 统一构建
- ✨ 优化：KPI 块固定宽 96px（原各占 1/4 宽约 380px），标签 10px + 数值 16px 同行显示；参数输入框固定 80px、高 30px，标签宽度按文字宽度锁定，组内间距 6px
- 🐛 修复：全局样式表 `QSpinBox { min-height:45px }` 会把局部 `setFixedHeight(30)` 抬高到 51px；`_style_spin` 显式覆盖 `min-height:22px` 与上下按钮 16px
- 🐛 修复：`splitter.setSizes()` 在页面首次布局时会被 QSplitter 按 sizeHint 重排（实测 `[230,320,267] → [239,416,162]`，评分明细被压到 160px）；现用 `QTimer.singleShot(0)` 在首次显示/切回本页时恢复，并用 `_bd_ready` 区分初始化布局与用户拖动，用户拖动位置可跨选项卡保持
- 📄 文档：README / config.md / 功能说明 [16] / UI设计规范 3.2 / 公告说明 / 代码修改索引同步；无新增配置项与依赖
- ✅ 验证：1600×1000 与 1180×800 下 8 项单行无溢出；`bd_main_sizes=[230,320,267]`、明细表可视 7 行

### v0.0.33
- 🐛 修复：`PredictionAlgorithms._calculate_autocorrelation` 对常量序列（某号码长期未出/期期出现，方差为 0）直接调用 `statsmodels.tsa.acf`，触发 `RuntimeWarning: invalid value encountered in divide` 并返回 NaN；现方差 ≤0 时直接记 0，且 acf 结果非有限值时归零
- 🐛 修复：NaN 自相关传入 `_prepare_numpy_advanced` 的 `int()` 转换抛 `cannot convert float NaN to integer`，被 `_prepare_data` 外层 `except` 捕获后执行 `_init_defaults()`，导致频率/遗漏/MA/Z-score/聚类等全部特征回退默认值；现新增 `_to_int` 做 NaN/inf 安全转换，异常不再中断整段数据准备
- 🐛 修复：KMeans 告警 —— `_prepare_sklearn_features` 按 `np.unique(..., axis=0)` 的实际不同点数限制簇数，少于 2 类跳过；`_tail_kmeans_bonus` 在 10 个尾数频率完全相同时直接返回空加成
- 🐛 修复：`_np_correlation_coefficients` 的 `np.corrcoef` 对常量特征列产生 0/0 除法告警，改用 `np.errstate(invalid, divide)` 包裹 + `nan_to_num`
- 📄 文档：README / config.md / 公告说明 / 代码修改索引同步；无配置项、表结构与依赖变化
- ✅ 验证：真实 100 期 + 10 期 + 20 期全重复样本，`PredictionAlgorithms` 构造 0 告警、`autocorrelation` 无 NaN、`kmeans_labels` 正常

### v0.0.32
- ✨ 优化：[16] 大数据分析改为三段式布局 —— `bd_main_splitter` 分隔「顶部（横幅 + KPI + 参数卡/统计卡并排）/ 中部（推荐生肖 + 推荐数字 + 波色）/ 底部（评分明细）」，三条分隔条宽度 6px、颜色 #9FB4D2，拖动位置记忆到 `配置.ini`
- ✨ 优化：参数卡由全宽 `QGridLayout` 改为紧凑单行 `QHBoxLayout`，四个 `QSpinBox` 固定宽 80px（原约 160px），标签与输入框间距 6px；统计检验卡移到参数右侧并排，固定高 78px，内容超出时内部滚动
- ✨ 优化：推荐生肖由单列改为双列 `QGridLayout`（7 项一屏显示）；推荐数字两行完整显示；评分明细行内边距 3→2px，可视行数 5→7 行
- ✨ 优化：横幅 / KPI（64→56px）/ 波色卡压缩高度；删除 `bd_status_label` 底部状态条，分析摘要复用横幅副标题 `bd_banner_subtitle`
- 🐛 修复：`_save_ini_config` 中 `ini['Display'] = {...}` 覆盖了旧键复制结果，导致未显式写出的分隔条尺寸（`zodiac_h_splitter`、`pred_h_splitter`、`bd_main_splitter` 等）每次保存即丢失；现改为写入当前值后回填旧键
- 📄 文档：README / config.md / 功能说明 [16] / UI设计规范 3.2 / 公告说明 / 代码修改索引同步；无新增配置项与依赖
- ✅ 验证：`compileall` 全通过；离屏预览 1600×1000 —— `bd_main_sizes=[230,320,267]`、生肖 7 项双列、数字 7 项两行、明细表 218px（7 行）、输入框 80px

### v0.0.31
- 🐛 修复：数据库目录与业务数据目录分离 —— SQLite / DuckDB 原放在 `程序目录/data/`，用户在 `系统v7.5/` 里看不到数据库，打包或拷贝时也容易漏；现统一为 `程序目录/系统v7.5/app_config.db` 与 `系统v7.5/analysis.duckdb`
- ✨ 迁移：`lib/db_helper.py` 新增 `_migrate_legacy_db_dir()`，启动时把旧版 `data/` 内的数据库文件移动到 `系统v7.5/`，目录清空后自动删除 `data/`；仓库内现有数据库已手工迁移完成
- 🔍 核查：其余运行时路径本就统一 —— `lib/ml_model.py` 的 `ml_models.pkl` / `training_data.json`、`TAB/data_storage.py` 的 `数据存储/` 均以 `系统v7.5/` 为准；`.gitignore` 同步改为忽略 `系统v7.5/*.db` / `*.duckdb`
- 📄 文档：README 目录树与数据目录说明、config.md 数据库路径、jiego.md 目录树、功能说明 9.2 与目录树、公告说明、代码修改索引同步
- ✅ 验证：`compileall` 全通过；`get_db()` 在 `系统v7.5/` 创建/复用数据库，`data/` 不再生成

### v0.0.30
- 🗑️ 清理：`plugins/彩票预测.py` 删除模块级无用导入（`random`、`traceback`、`defaultdict`、`PredictionAlgorithms`、`BigDataAnalyzer`、`MLPredictionModel`、整个 `lib.plot_draw` 导入块、`NumberBallWithZodiac`、`PreserveColorDelegate`），以及零引用方法 `_show_number_color_dialog`（339 行）、无用局部变量 6 处、过时「已拆分」标记注释 7 处、`_show_panel_settings_dialog` 内不可达 `pass` 1 处
- ✨ 新增：选项卡位置记忆 —— `[Display] current_tab_index` 重启恢复；修复 `_apply_ini_config` 早于 `_init_ui` 执行导致 `self.tabs` 不存在而跳过恢复的问题（改为暂存 `_ini_start_tab_index`，UI 建好并连接 `currentChanged` 后恢复）
- 🐛 修复：[10] 数字与生肖竖向分隔条 `zodiac_h_splitter` 拖动记忆失效 —— `_apply_splitter_sizes` 旧规则要求每栏 ≥ 总量 25%，用户向右拖动到 3:1 / 4:1 时被判无效并回退默认；现只校验栏数一致且每栏 ≥30px
- ✨ 增强：[1] 数据导入原始数据多格式识别 —— 支持「日期在前」「时间在前」「年月日-期数-号码」「期数-年月日-号码」「第X期」「X期」「独立期号」「+特别码」「无期号」等写法，统一处理全角/半角、网页富文本与开奖时间；`DataUtils._normalize_period` 把 `2026129` 归一为 `129`；多行混合格式按记录起始行分组（`TAB/data_import._split_periods`）
- 🔍 核查：数据库确在使用 —— SQLite `app_config` / `func_state` / `history_records`(103) / `ui_ini`；DuckDB `history_detail`(721 = 103×7) 无重复；运行时 JSON / INI / 数据存储均在 `程序目录/系统v7.5/`，数据库在 `程序目录/data/`，无散落根目录文件
- 📄 文档：README / dev.md / config.md / 功能说明 / UI设计规范 / 公告说明 / 代码修改索引同步
- ✅ 验证：`compileall` 全通过；离屏回归（选项卡恢复=9、生肖分隔条 `[1247,326]` 精确恢复、六种格式解析、混合 3 行拆分 3 条）全 PASS

### v0.0.29
- ✨ 变更：[4] 数字选择「颜色设置」对话框文字统一为 20px（标签/输入框/状态文字/按钮），对话框尺寸放大到 760×380
- 🐛 修复：`[NumberColors]` 原仅在 `_save_custom_number_colors` 单独写盘，后续 `_save_ini_config` 重建整份 INI 时会丢失；现已在 `_save_ini_config` 中一并写入 49 个 `num_*` 与红/蓝/绿分组
- ✨ 新增：[15] 数据存储新增左右分隔条 `storage_splitter`（左侧导航 150-360px 可拖动，默认 190px）
- ✨ 新增：[16] 大数据分析新增上下分隔条 `bd_main_splitter`（上半区横幅/KPI/参数/结果/波色，下半区明细/统计/状态）
- 🐛 修复：核对全部既有分隔条（数据导入、预测×2、历史×3、第七位、生肖、五行×2、大数据左右、统计图表）均已调用 `_apply_splitter_sizes`；两组新分隔条同步登记 `splitter_list` / `splitter_names`
- 📄 文档：`docs/UI设计规范与记忆机制.md` 新增「标题行控件位置调整」章节（数字 px / 文字 px / 面板尺寸设置如何左右移动）；README / config.md / 功能说明 / 公告说明 / 代码修改索引同步
- ✅ 验证：离屏启动 16 页正常；`_save_ini_config` 重写后 `[NumberColors]` 仍存在；`compileall` 全通过

### v0.0.28
- ✨ 新增：选项卡 `install(host)` 迁移范式 —— 页面模块内实现全部业务逻辑（模块函数 + install 在 build 前绑定实例属性），主窗口只保留兼容转发 shim；本版完成全部 16 页（[1]-[16]）迁移，其中 [15] 数据存储 47 个方法、[16] 大数据分析 3 个方法
- 🗑️ 删除：顶部工具栏「布局设置」两个标签页（控件尺寸 / 控件位置）与 `TAB/topbar_tools.py`；标题行控件组位置固定为原默认值（数字选择偏右、生肖贴左）
- ✨ 变更：[4] 颜色设置改为点击按钮弹窗；[11] 五行分组条改用独立标签渲染修复 `<span>` 原文显示；[16] 大数据分析改为仪表盘式布局（横幅 / KPI / 卡片 / 进度条）
- ✨ 新增：网页内容识别 —— `DataUtils.strip_html()` 统一把网页源码/富文本/表格转纯文本，[1] 数据导入与 [4][10][11] 的号码解析全部接入
- ✨ 新增：`docs/生成蓝图.py` 与 `docs/蓝图/`（16 张页面截图 + `index.html` 蓝图索引）
- ✨ 变更：[11] 数字与五行恢复下方面板（按钮上方数字、下方五行文字，7×7 共 49 个号码），上下加竖向分隔条可拖动；粘贴输入框高度压缩；「应用」移到「恢复默认」左侧；选中行改浅底 + 五行色边框，避免「木」字发白看不清
- ✨ 变更：[10] 数字与生肖 px/尺寸控件整体左移约 300px 并与标题留白；[11] px/尺寸控件居中留距
- 🐛 修复：五行面板一屏显示不全（压缩行距 + 分隔条 1:2 比例 + 最小高度）、颜色设置页内容被裁切
- 📄 文档：README / dev.md / config.md / 功能说明 / 公告说明 / 代码修改索引（重生成）同步；无新增第三方依赖
- ✅ 验证：离屏启动 16 页正常；点号码即时改生肖、粘贴 HTML 片段解析出号码；`compileall` 全通过（测试期间已屏蔽 INI/JSON 落盘）

### v0.0.27
- ✨ 变更：[10] 数字与生肖 —— 取消多选号码 + 生肖按钮的两步绑定，改为点击号码弹出十二生肖菜单（QMenu），选中立即写入并自动保存；`ZodiacNumberPanel` 新增 `number_clicked(int)` 信号
- ✨ 新增：主窗口 `_on_zodiac_number_clicked` / `_set_zodiac_immediately` / `_persist_bindings`（静默写 JSON + INI，不提示重启）
- ✨ 变更：[11] 数字与五行 —— 删除「确定」按钮与下方数字面板；「应用」一次完成解析 → 写入 → 保存；五行分组条改富文本渲染（五行字 + 号码 + 数量，选中行高亮）
- ✨ 变更：两个页面的数字 px / 文字 px / 尺寸统一放到标题行；五行 px 同时控制分组条字号与行高
- 🐛 修复：`_apply_splitter_sizes` 新增 `default_sizes` 参数，旧配置把某一栏压成 0（或占比不足 1/4）时按 3:2 回退，生肖统计表不再被隐藏
- 🗑️ 清理：`_on_element_input_confirm`、`_on_element_panel_selection_changed`、`_on_batch_set_element`、`_on_zodiac_panel_selection_changed`、`_on_batch_set_zodiac`、`_populate_element_panel`
- 📄 文档：README / dev.md / config.md / 功能说明 / 公告说明 / 代码修改索引同步
- ✅ 验证：离屏应用粘贴数字写入「水」14 个号码；生肖即时写入「鼠」；`compileall` 全通过

### v0.0.26
- ✨ 重设计：[11] 数字与五行页 —— 上部左侧五行分组条（金/木/水/火/土，每行显示已分配号码与数量，点击选中写入目标），上部右侧粘贴输入框（自动识别多种分隔符）+「确定」解析 +「应用」写入，下部全宽数字面板（按钮上数字、下五行文字）
- ✨ 新增：主窗口 `_on_element_row_selected` / `_on_element_input_confirm` / `_on_element_input_apply` 三个事件；`_refresh_element_stats` 改为刷新分组条，移除五行统计表格
- ✨ 变更：`TAB/element.py` 重写布局；五行说明提示改为“选中一行 → 粘贴 → 确定 → 应用 → 保存设置”
- 📄 文档：README / dev.md / config.md / jiego.md / 功能说明 / 公告说明同步；代码修改索引重新生成
- ✅ 验证：离屏粘贴 `01 02、03-04\n05，6` 解析出 6 个数字，应用写入「水」后分组条同步为 14 个号码；`compileall` 全通过

### v0.0.25
- ✨ 新增：选项卡自动发现 —— `TAB/__init__.py` 新增 `iter_tab_pages()`，扫描 TAB 包内模块，读取 `TAB_INFO` 后按 `order` 排序返回
- ✨ 新增：16 个页面统一声明 `TAB_INFO = {"title": ..., "order": ..., "enabled": True}`，标题与顺序集中在页面文件内
- ✨ 变更：`_create_tabs` 改为遍历 `iter_tab_pages()` 自动 `build(host)` + `addTab`；删除 16 个别名导入与 16 个 `_create_xxx_tab` 薄包装方法
- ✨ 变更：停用页面只改 `TAB_INFO["enabled"] = False`（或文件名加 `_` 前缀），不再改主窗口
- 📄 文档：README / dev.md / config.md / jiego.md / 功能说明 / 公告说明 / 选项卡加载机制同步；索引生成器 7.2/7.3 改为解析 `TAB_INFO`
- ✅ 验证：离屏启动 16 个页面标题与顺序不变，`compileall` 全通过

### v0.0.24
- ✨ 变更：取消「插件自动扫描」机制 —— 删除 `run.py` 的 `PluginLoader`、`MainWindow` 类与 `plugin_info` 约定；改为直接 `from plugins.彩票预测 import LotteryPredictionWindow` 创建主窗口，16 个选项卡仍由 `TAB/*.py` 的 `build(host)` 构建
- ✨ 变更：窗口标题统一为 **系统v7.5**（`LotteryConfig.WINDOW_TITLE`，`run.py` 的 `setApplicationName` 同步），不再出现「PyQt6 窗口系统」「系统 v7.5」两种写法
- 🗑️ 删除：顶部工具栏左侧的大标题「系统 v7.5」（`title_label` / `#TitleLabel` 控件及对应 QSS 规则）；顶部工具栏只保留功能按钮
- 📄 文档：README / dev.md / config.md / jiego.md / 功能说明 / 公告说明 / 代码修改索引（重生成）同步；无依赖增删
- ✅ 验证：`py_compile` 与 `compileall` 全通过；离屏启动窗口标题为「系统v7.5」、选项卡 16 个、顶部标签列表无大标题

### v0.0.23
- ✨ 新增：DuckDB 覆盖 [6] 统计分析图表、[7] 回测/算法对比/命中趋势与 HTML 报表导出 —— 新增统一定位方法 `_analysis_records(window=None)`（`plugins/彩票预测.py`），按 `_compute_data_fingerprint()` 判断数据是否变化，变化时才 `sync_history_to_duckdb`，取数失败自动回退内存 `historical_data`，返回数据源标识
- ✨ 新增：`_draw_chart` / `_show_number_trend_chart` / `_on_compare_all_algorithms` / `_on_start_backtest` / `_on_export_report` 全部改走 `_analysis_records()`
- ✨ 新增：[1] 数据导入支持 DuckDB 直读 CSV / Parquet —— `lib/db_helper.py` 新增 `read_table_file()`，CSV 走 `read_csv_auto(..., sample_size=-1)`，Parquet 走 `read_parquet()`；新增 `_records_from_table` 兼容 期号/date/号码/特别码 与 n1..n6 / 位置兜底，中文表头可解析；导入过滤器新增 `*.parquet`
- ✨ 新增：[15] 数据存储索引入库 —— SQLite 新增 `storage_items` 表（`id/type/title/content/file_path/tags/created_at/updated_at/size/synced_at`），`save_storage_items()` 全量覆盖写入、`load_storage_items()` 读回；`_save_storage_index` 写盘成功后镜像，`_load_storage_index` 在 JSON 为空时从库恢复
- ✨ 增强：`docs/生成索引.py` 新增 7.1「顶部工具栏区域」（构建方法/区域范围/调用位置/状态栏 + 工具栏文字关键词 + 全部控件含局部变量 + 事件方法）、每页「本页函数与类 / 本页导入依赖 / 本页创建的全部控件（含局部变量）」；索引由 2727 行扩为 3396 行
- 🐛 修复：`TAB/widgets.py` 的 `plot_correlation_heatmap` 与 `plot_sum_distribution` 使用未定义的 `np`（`name 'np' is not defined`），改为从 `lib.math_algo.get_numpy()` 取 numpy
- 🐛 修复：`lib/math_algo.py` 的 `_build_dataframe` 与 `_calculate_range_distribution` 使用未导入的 `DataFrame` / `Series`，异常被吞导致 DataFrame 特征与预测算法降级；改为函数内延迟导入 pandas
- 📄 文档：README / dev.md / config.md / jiego.md / 功能说明 / 公告说明 / 索引（重生成）同步；无依赖增删
- ✅ 验证：`_analysis_records()` 返回 `('DuckDB', 100 条)`；13 种图表（含热力图、和值分布）绘制无异常；5 期回测完成；中文表头 CSV 与 Parquet 直读各解析出 2 条记录；`storage_items` 写入/读回与标签正确；`compileall` 全通过

### v0.0.22
- ✨ 新增：DuckDB 接入 [16] 大数据分析 —— `lib/db_helper.py` 新增 `history_detail` 明细表（`period/date/seq/number/is_special`，每期每号码一行）、`sync_history_to_duckdb(records)` 整表覆盖同步、`load_history_for_analysis(window)` 按最近 N 期 SQL 取数并重组记录；DuckDB 连接加线程锁
- ✨ 新增：`_on_bigdata_analyze_clicked` 优先走 DuckDB，异常/为空时回退内存 `historical_data`；分析结果 `meta.source` 标注数据源
- ✨ 新增：界面状态行显示「数据源 DuckDB / 内存」，复制/导出报告新增「数据源」行
- 🐛 修复：`BigDataAnalyzer._compute_statistics` 使用未导入的 `pd`（`name 'pd' is not defined`），异常吞掉后续计算，导致和值/熵/卡方/Z-score/遗漏概率全部为空；改用 numpy 逐点迭代实现 EMA5（等价 `pandas.ewm(span=5, adjust=False)`），统计段恢复输出
- 📄 文档：`docs/config.md` 新增「各功能数据库使用清单」（16 个选项卡 + 非选项卡功能逐项归属），并更新职责分工、DuckDB 接入环节与后续可选接入项
- 📄 文档：README / dev.md / config.md / jiego.md / 功能说明 / 公告说明 / 索引（重生成）同步；duckdb 已在 requirements.txt，无依赖增删
- ✅ 验证：DuckDB 同步 700 行 / 窗口 30 取回 30 期 / 全量 100 期结构正确；离屏启动 16 个选项卡，点击「开始分析」显示「数据源 DuckDB / 参与 100 期」，统计检验完整输出

### v0.0.21
- ✨ 新增：`docs/代码修改索引.md` 第七章「按选项卡区域定位」—— 从 `_create_tabs` 自动解析 16 个页面的标题/顺序/构建行/注册行，每页输出「界面文本关键词、host 控件、事件方法 → 文件:行号」，搜「数字选尾」「未匹配的数字」即可定位整页
- ✨ 新增：索引 7.3「全局/跨页关键词」与 7.4「搜索示例」，覆盖 `系统v7.5`（WINDOW_TITLE / setWindowTitle / 数据目录 / 公告版本号）、`plugin_info`、`get_db`、`RESULT_SEPARATORS` 等跨页关键词
- ✨ 增强：`docs/生成索引.py` 新增 `page_registry / text_keywords / host_refs / host_member_line`，全部行号由源码实时解析；章节由六章扩为七章，后续章节顺延（控件表→八、速查→九、修复记录→十、附录→十一）
- ✨ 新增：`docs/选项卡模块化与加载机制.md` —— 现状加载链路、方案 A（自动扫描 `TAB/*.py`，含可直接粘贴的 `_load_tab_pages` 与改造后的 `_create_tabs`、`PAGE_INFO` 契约、错误隔离）、方案 B（手动注册）、两种方案对比、新增/删除/临时停用步骤、标准页与自包含页模板、业务逻辑迁入 Tab 的可行性与渐进路线、验证清单与 FAQ
- ✨ 文档：`docs/config.md` 新增「数据库选型分析」—— 依据（历史 100 期/JSON 16 KB、`analysis.duckdb` 未生成、`query_analysis()` 零调用、[16] 用内存 numpy/scipy）得出「SQLite 必留、DuckDB 预留不接入」，并给出 A/B/C 三种处理方案
- 🐛 修复：README / jiego.md / 功能说明目录树仍写 `plugins/tabs/`，已改为根级 `TAB/` + `UI/`；docs 清单补齐 7 份文档
- 📄 文档：README / dev.md / config.md / jiego.md / 功能说明 / 公告说明 / 索引（重生成）同步；无代码逻辑变更、无依赖增删

### v0.0.20
- 🗑️ 清理：删除确认无引用的冗余类与方法（共约 1400 行）
  - `lib/data_process.py`：`ReportExporter` / `DataValidator` / `DataPreprocessor`，14 个 `COLOR_*` 常量
  - `lib/math_algo.py`：`StatisticsAnalyzer` / `PatternMatcher` / `TimeSeriesAnalyzer`，`MathUtils` 的 5 个未用方法，`self.analysis_results` / `self._is_light_mode` / `self.adjacent_stats`
  - `lib/ml_model.py`：`PredictionOptimizer` / `DeepLearningPredictor` / `EnsemblePredictor`，`save_training_data` / `train_neural_network` / `optimize_hyperparameters`，`self.models` / `self.scalers`
  - `lib/plot_draw.py`：`AdvancedVisualization`、`get_patches_module`、`get_sns_module`
  - `lib/db_helper.py`：`delete_config` / `get_func_state` / `fetch_all` / `fetch_one` / `register_dataframe` / `read_csv` / `read_parquet`
  - `TAB/widgets.py`：`ColorUtils` / `PredictWorker` / `MLPredictWorker`、`NumberPanel.highlight_numbers`、`self.is_special`
  - `TAB/prediction.py`：`_build_saved_predictions_panel`
  - `plugins/彩票预测.py`：`_on_predict_progress` / `_on_ml_predict_progress`
- 🗑️ 清理：未使用导入（`run.py` 的 `Qt`、`data_process.py` 的 `csv/json/numpy`、`ml_model.py` 的 12 个未用懒加载器与 `MathUtils`、`plot_draw.py` 的 `numpy/LotteryConfig/MathUtils`、插件层的 4 个面板控件与 `_get_scipy_stats`、`TAB/info.py` 的 `json/os/random`、`TAB/widgets.py` 的 `QObject/PredictionAlgorithms/MLPredictionModel`、`TAB/data_storage.py` 与 `TAB/zodiac.py` 的 `QAbstractItemView`）
- 🐛 修复：清理脚本误删 `ml_model.py` 的 `import os` / `import pickle`（类体与函数体内使用未被静态扫描识别），已恢复并做运行时导入验证
- ✅ 验证：`python -m compileall` 全通过；离屏启动 16 个选项卡、100 条历史记录、15 种分隔符、控件状态恢复 7 项正常；`lib` 全部模块可导入
- 📄 文档：README / dev.md / 功能说明 / 公告说明 / 代码修改索引（重生成）同步；无依赖增删

### v0.0.19
- 🗑️ 移除：在线更新 / 数据源设置（程序本地离线运行，含 9 个处理方法 277 行、2 个入口按钮、`import urllib.request`、区域注释及全部文档条目）
- ✨ 重构：新增 `UI/` 目录（`UI.py` 移入 + `__init__.py` 转发导出），新增 `TAB/` 目录（16 个选项卡页面 + `widgets.py` + `__init__.py`），原 `plugins/tabs/` 删除；全项目 import 改为 `from UI import ...` / `from TAB import ...`，全量 py_compile 与离屏启动验证通过
- ✨ 新增：通用控件记忆 —— `_save_widget_states` / `_restore_widget_states`，INI 新增 `[WidgetState]`：
  `c_` 下拉框索引、`s_` 数字框数值、`v_` 滑块、`b_` 复选框、`t_` 表格列宽；保存随 `_save_ini_config` 自动执行，恢复在 `_init_ui` 之后执行（阻塞信号，恢复后同步内部开关与算法说明）
- ✨ 新增：分隔条记忆补齐 —— `bd_mid_splitter`（大数据分析）、`stats_splitter`（统计分析图表）登记进 `splitter_list` / `splitter_names`，页面调用 `_apply_splitter_sizes`
- ✨ 规范：`LotteryConfig` 新增 `TEXT_MAX_PX=150`、`BUTTON_MAX_WIDTH/HEIGHT=300`、`BUTTON_DEFAULT_WIDTH/HEIGHT=80/60`、`TEXT_DEFAULT_PX=20`；`FONT_SIZES` 新增「标准=20」并设为默认字号
- ✨ 规范：`TAB/widgets.py` 字体与按钮尺寸钳制改用上述常量（原按钮 120、数字面板字体 36、生肖/五行按钮字体 28 的上限放宽到 150/300）
- ✨ 规范：`LotteryConfig.RESULT_SEPARATORS` 统一 15 种分隔符，`TAB/number_sort.py` / `TAB/number_tail.py` 下拉框改为遍历该常量；新增加号、反斜杠、波浪号、井号（前 11 项顺序不变，旧 INI 索引兼容）
- ✨ 新增：`BigDataAnalyzer._compute_statistics` + `format_stats_text` —— 和值 MA5/EMA5/斜率与趋势、一阶自相关、Shannon 信息熵、卡方均匀性检验、二项分布 95% 置信区间、Z-score 热冷号、推荐号码遗漏未出概率；`analyze()` 返回新增 `stats`，`format_result_text` 增加统计段
- ✨ 新增：[16] 大数据分析页面新增「统计检验与趋势（numpy + scipy）」卡片 `bd_stats_label`，`render_result` 渲染统计报告
- ✅ 验证：`BigDataAnalyzer.analyze`（60 期样例）输出 7 数字/7 生肖/3 波色 + 9 项统计；离屏启动 16 选项卡正常，`[WidgetState]` 写入 49 项，分隔符下拉 15 项，控件状态恢复 7 项
- 📄 文档：新增 `docs/UI设计规范与记忆机制.md`；README / dev.md / jiego.md / 功能说明 / 公告说明 / 代码修改索引（重生成）同步；无依赖增删

### v0.0.18
- 🐛 修复：公告页「代码结构与可调参数指南」整段失效 —— 仍描述旧的单文件 8008–26667 行结构，实际主文件约 1.26 万行且代码已拆到 `lib/` 与 `TAB/`；现改为分层结构 + 16 区域名称（去掉易漂移的绝对行号），可调参数位置改为指向 `lib/data_process.py` 的实际常量名
- ✨ 新增：预测记录持久化 —— 新增 `系统v7.5/预测记录.json`，`_load_prediction_history` / `_save_prediction_history`；随机抽取、算法预测、机器学习预测三处写入后保存，清空记录与关窗时也保存，重启不再丢失
- ✨ 新增：历史开奖数据镜像入库 —— `lib/db_helper.py` 新建 `history_records` 表（period 主键 + date + numbers JSON + special），新增 `save_history` / `load_history`；`_save_data` 调用 `_sync_history_to_db` 全量覆盖写入，`_load_data` 在 JSON 缺失时优先从数据库恢复并重建 JSON
- 🐛 修复：数据路径错位 —— `配置.ini` 的 `[Paths]` 曾被原样回填为绝对/相对路径，换程序目录或换启动目录后 `彩票数据.json` 会写到旧位置甚至当前工作目录；现 `_apply_ini_config` 忽略记录值，统一用 `os.basename` 重定位到 `self._data_dir`（实测：修复前数据写到 `c:\py\系统v7.5`，修复后固定为 `程序目录\系统v7.5`）
- 🐛 修复：删除 `_on_zodiac_combo_changed` / `_on_element_combo_changed`（引用从未初始化的 `self._zodiac_combos`，且无任何信号连接）；区域11 的方法清单注释同步清理
- ✨ 优化：关窗时先落盘预测记录、再保存配置、最后关闭数据库连接
- 🗑️ 移除：在线更新 / 数据源设置（含 `_get_data_sources` / `_save_data_sources` / `_test_data_source` / `_on_data_source_setting_clicked` / `_add_data_source` / `_del_data_source` / `_test_selected_source` / `_move_source` / `_on_online_update_clicked` 共 277 行，及「在线更新」「数据源设置」两个按钮和 `数据源.json`）；程序为本地离线使用，该功能无实际价值
- ✨ 调整：`is_dark_mode` 注释由「暂未完全实现」更正为实际状态（切换主题可用、状态存入 INI [General]）
- ✅ 验证：离屏启动 16 个选项卡无异常；`history_records` 写入 100 条；删除 `彩票数据.json` 后自动从数据库恢复 100 条并重建 JSON；预测记录保存后重新加载条数一致；关窗无异常
- 📄 文档：README / dev.md / 功能说明 / 公告说明 / 代码修改索引（重生成）同步；无依赖增删

## 文档工具与规则补充（不涉及版本号）
- ✨ 新增：`docs/生成目录树.py` —— 扫描项目根目录生成统一格式目录树，并以哨兵标记定点写回所有托管文档（README、`docs/jiego.md`、功能说明第十二章、本节 2.2 的 lib 子树）；支持 `--check` 逐块比对（不一致退出码 1）与 `--dry-run` 预览，连续运行幂等。
- 📄 规则：写完代码、修复或修改代码后必须自动核对项目结构并更新所有含目录树的文档；目录树由脚本生成，禁止手工誊写，脚本报「待补充说明」的条目须先在 `DESCRIPTIONS` 字典补写。
- 📄 规则（2026-11-03 生效）：`AI_RULES.md` 新增「依赖自带规则」——功能改动中 import 的第三方包必须在同一次改动写入 `requirements.txt`（只写包名、版本约束与 `#` 用途注释）；新增库须在功能说明写明「负责什么计算/能力」「缺失时如何降级」「是否可选」；`requirements.txt` 中声明但代码无任何 import 的包必须删除，可选库（如 tensorflow）保持注释状态。执行清单新增第 7 项「依赖双向对账」（`python -c` 扫描 import → 对账 → 「用了没声明 / 声明没用」两类差异必须为空）；补充约束新增第 12 条（新库致启动失败或体积暴增须在改动说明标注并给出降级路径）。本次仅改文档，无代码改动、无版本号变更。
