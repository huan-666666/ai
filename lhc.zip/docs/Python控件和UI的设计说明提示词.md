请生成一份完整独立单页HTML网页，网页标题：Python控件和UI的设计说明。
定位：面向Flet Python UI开发零基础小白，完整学习路线：看懂控件外观、理解控件作用、掌握标准语法写法（创建控件）、学会运行时修改控件属性、添加/删除控件、UI布局设计、控件交互与动画、把控件放到指定位置、带动画移动控件、页面栈导航（Stack Navigation / Push Pop路由）、强层浮层组件（弹窗、悬浮提示、鼠标悬浮信息、下拉选择、下拉菜单、自定义下拉面板、点外部收回的Overlay组件）、处理耗时异步、调试排错；文档优先通俗化讲解，配套模板、注释代码、仿写练习，降低新手门槛；开头标注适配Flet稳定版，提醒版本差异问题。

【网页UI规范｜大厂产品级技术文档标准，严格执行】
整体风格：对标成熟组件库文档站（Ant Design / MUI 文档风格），专业干净、层次清晰、阅读友好，浅色/暗色双主题一键切换；所有交互反馈、动画效果统一规范；动画统一使用弹性贝塞尔曲线，时长控制在220–450ms，柔和不刺眼，不干扰正文阅读；所有资源全部内嵌，输出单文件，保存后直接用浏览器打开，不依赖本地文件、无需额外安装包。
色彩系统（产品级色板）：
- 主色：#2563eb（蓝色主色，用于高亮、链接、按钮、激活态）
- 辅助成功色：#10b981；警告色：#f59e0b；危险色：#ef4444
- 中性色阶（浅色模式）：#ffffff 背景、#f8fafc 次级背景、#e2e8f0 分割线、#94a3b8 次要文字、#64748b 正文、#1e293b 标题
- 中性色阶（暗色模式）：#0f172a 主背景、#1e293b 卡片/区块背景、#334155 分割线、#94a3b8 次要文字、#cbd5e1 正文、#f1f5f9 标题
排版系统：
- 字体：系统无衬线字体栈 - Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif
- 字号阶梯：一级标题 28px、二级标题 22px、三级标题 18px、正文 15px、小字备注 13px、代码字体 14px（等宽字体 JetBrains Mono / Consolas）
- 行高：标题 1.25，正文 1.6，代码块 1.4
- 间距系统：全局统一 4px 基数，间距刻度 4/8/12/16/20/24/32/40/48px
布局架构（三栏布局，PC端；移动端自动降级）：
- 左侧固定侧边目录栏（宽260px，可折叠收起）
- 中间主文档阅读区（最大阅读宽度 860px，自动居中，防止文字过长阅读疲劳）
- 右侧悬浮锚点目录（页面内小标题快速跳转，PC可见，移动端隐藏）
页面头部 Header（替代简易AppBar）：
- 高度 64px，固定置顶，滚动时增加阴影与背景虚化
- 左侧：Logo + 文档标题；中间：搜索框（本地页面内搜索，实时高亮匹配文字、跳转）；右侧：主题切换按钮 + 回到顶部快捷按钮
滚动行为：
- 顶部进度条，跟随页面滚动；平滑锚点跳转；滚动时左侧目录自动高亮当前章节；右侧锚点同步高亮
卡片、区块组件规范：
1. 文档段落区块：白色/深色卡片，圆角12px，内边距20px，外边距16px；卡片hover轻微抬升阴影
2. 提示块（Info/Warning/Error/Success）：四种样式，左侧彩色竖线，内边距16px；Info蓝色、Warning黄色、Error红色、Success绿色
3. 代码块：圆角10px，内边距16px，语法高亮，右上角固定复制按钮；hover轻微提亮；复制后弹出成功toast提示；长代码自动横向滚动
4. 控件画廊卡片：网格布局，卡片圆角14px；内部预览区、标题、描述、标签；hover上浮+阴影放大+边框主色高亮；点击卡片展开详情面板
5. 表格：带表头底色、隔行浅色区分、边框柔和，深色模式自动适配；单元格内边距12px
交互与动画规范：
- 全局动画曲线：cubic-bezier(0.22, 1, 0.36, 1)；时长220~450ms
- 左侧侧边栏：收起/展开弹性动画；遮罩层淡入；目录项依次入场；当前章节高亮背景呼吸微动
- 折叠面板（ExpansionPanel）：高度平滑展开收起，箭头旋转过渡
- 所有可点击元素：hover态、active按压态、focus焦点环（无障碍）；按钮点击波纹反馈
- 预览弹窗（图片/演示弹窗）：淡入+缩放弹出，ESC、点击蒙层关闭，关闭反向动画
- Toast消息：右下角滑入滑出，3s自动消失
- 搜索：输入实时过滤，关键词高亮；无结果提示
无障碍规范：
- 焦点可见、键盘可遍历、合理aria标签、足够文字对比度
响应式断点：
- ≥1280px：完整三栏（左目录+中间文档+右锚点）
- 768px ~1279px：两栏（左目录可收起，中间文档，隐藏右侧锚点）
- <768px（手机）：左侧目录改为抽屉弹出式；隐藏右侧锚点；控件画廊自动从多列改为单列；代码块适配窄屏
页面整体结构：
【顶部Header导航栏】
- 页面标题：Python控件和UI的设计说明
- 页面内实时搜索框，支持全文检索，关键词高亮、跳转匹配位置
- 亮色/暗色主题切换按钮；回到顶部悬浮按钮（滚动超过300px显示）
- Header滚动渐变动画：页面向下滚动时，背景透明度、阴影平滑过渡变化

【左侧固定侧边目录（可折叠抽屉）】
- 侧边栏固定在左侧，PC默认展开，可点击收起；移动端点击汉堡按钮滑出抽屉
- 抽屉横向弹性滑入、滑出动画；遮罩层淡入淡出；目录列表项依次延迟入场动画；页面滚动时，当前所在章节的目录链接自动高亮标记，高亮底色增加缓慢呼吸微动效果
【右侧锚点导航（PC大屏专属）】
- 抓取当前章节下二级、三级小标题，生成快速跳转链接，跟随滚动高亮

目录锚点章节列表：
1. 开篇：推荐学习顺序 + Flet版本提醒
    告诉小白阅读顺序，不要乱翻文档；说明本文档适配Flet稳定版，讲解查看版本、升级Flet命令；重点提醒：Flet不同版本控件名称、参数会改动，复制老旧网上代码容易报错。
2. 前言：Flet快速入门，基础名词小词典（通俗解释）
    通俗讲解：什么是控件、父容器、子控件、页面(page)、组件实例、属性、参数、布局约束、坐标系、重绘刷新、状态state；区分根对象page（窗口本身）和普通UI控件；附带Flet完整运行流程：安装Flet→导入库→配置窗口→编写控件→挂载添加→运行程序；附带最小可运行基础模板，小白先跑通第一个窗口；增加窗口基础设置讲解：窗口标题、窗口宽高、是否允许缩放、窗口关闭回调on_close（关闭前确认、保存数据）。
3. Flet通用语法、统一书写写法总规则（独立重点小节）
    分成四大块：【①创建控件怎么写】、【②程序运行后怎么修改控件】、【③删除/清空控件写法】、【④事件传参与循环控件引用】
    【①创建控件】：讲解所有控件通用固定书写模板，区分单行简写、多行规范写法；讲解控件首字母大写规则、属性=值写法、on_xxx事件规则、Python缩进规范、逗号书写规范；讲解变量接收控件两种写法：先定义再add / add内直接创建；样式复用：TextStyle、ButtonStyle写法，一套样式给多个控件；颜色多种写法：命名色、十六进制、rgb、rgba透明度写法；枚举常量说明（对齐、方向、动画曲线等枚举从ft直接调用，不要手写字符串）。
    【②运行时修改控件（小白重点）】：独立子章节，专门讲解修改逻辑
    - 修改核心公式：`控件变量.属性 = 新值`
    - 举例示范：修改文字text、颜色color、大小width/height、可见性visible、禁用disabled、只读read_only、位置offset、背景色bgcolor、透明度opacity、旋转角度、缩放比例
    - 重点区分：哪些修改自动刷新、哪些修改必须调用 `.update()`
    - 两种刷新写法：`控件.update()`（只刷新这一个控件）、`page.update()`（刷新整个页面），讲清楚各自适用场景、不要滥用page.update()；补充坑：频繁page.update会丢失输入框光标、打断用户输入。
    - 事件里面修改控件完整模板（点击按钮修改别的控件）
    - 批量循环修改多个控件写法模板
    - 修改属性支持动画：修改时配合 animate_xxx 实现平滑过渡
    - 修改时高频报错：控件没有保存变量（无法修改！重点坑：直接add里面创建控件，没有变量接收，后面改不了）
    【③删除、清空控件】：`page.controls.remove(控件变量)` 删除单个控件；`page.controls.clear()` 清空页面所有控件；删除后记得update刷新。
    【④事件传参与循环控件引用（超高频坑）】
    - lambda循环捕获变量陷阱，两种安全传参方案示例
    - 循环批量生成控件：用列表保存每一个控件对象，避免变量覆盖，实现单独修改某一个循环生成的控件
    - 基础数据管理，普通变量、列表保存业务数据，做到UI和数据分离；不要把业务数据硬写在控件参数里；点击事件修改数据，再同步更新UI。
    - 焦点控制：输入框自动聚焦、按钮触发焦点跳转示例。
4. 第1部分：Flet全套UI控件画廊【重点升级：Flet原生全部控件完整展示，不是只放常用几个，全部做成卡片】
    控件画廊采用网格卡片布局，每个控件独立卡片，卡片固定顺序：①控件预览占位效果图（直观看到长什么样）②控件名称 ③控件作用、适用场景、不适合场景（避免控件乱用，重点标注：Column不适合放成千上万条长列表，长列表优先ListView）④【创建语法骨架模板】（创建的时候怎么写）⑤完整示例代码，代码每一行添加中文逐行注释 ⑥控件添加方式 ⑦折叠面板存放常用属性、参数默认值说明、【可修改属性清单】、【交互事件清单】、【动画支持说明】；标注该控件支持哪些on_xxx交互事件、支持哪些animate_xxx动画；⑧布局摆放提示、搭配什么容器、定位注意事项；补充图片圆角：Container.border_radius 和 ClipRRect 的区别说明。
    控件完整分类清单（全部展示）：
    📦布局容器类
    Row、Column、Stack、Wrap、GridView、ListView、Container、Card、ExpansionPanel、ExpansionPanelList、SafeArea、GestureDetector、VerticalDivider、Divider、ResponsiveRow、Padding、Align、Center、AspectRatio、ConstrainedBox、ClipRRect、AnimatedSwitcher
    🧭导航类
    AppBar、NavigationBar、NavigationRail、Tabs、Tab、View、NavigationDrawer、BottomAppBar
    ℹ️信息展示类
    Text、RichText、Image、CircleAvatar、Icon、ProgressBar、ProgressRing、Tooltip、Badge、Markdown、DataTable、DataColumn、DataRow、ListTile
    🔘按钮类
    ElevatedButton、TextButton、OutlinedButton、IconButton、FloatingActionButton、SpeedDial、SpeedDialChild、Button、MenuButton、SubmenuButton
    📝输入与选择类
    TextField、Dropdown、Option、Checkbox、Switch、Radio、RadioGroup、Slider、RangeSlider、DatePicker、TimePicker、ColorPicker、FilePicker
    🪟弹窗、浮层、面板类（强层Overlay组件）
    AlertDialog、BottomSheet、Popover、PopupMenuButton、PopupMenuItem、SnackBar、Banner、FullScreenDialog、Dismissible
    📊图表类
    LineChart、BarChart、PieChart、ScatterChart
    ✨动画组件
    Animation、Transform
    🧰工具/杂项控件
    WebView、Audio、Video、Canvas、Shapes、Clipboard、Focus、Draggable、DragTarget
5. 第2部分：UI设计思路与规范 + 资源路径说明
    页面骨架搭建顺序、统一间距刻度4/8/16/24/32px、配色、字号规范；响应式适配电脑/手机；视觉层级、留白分组；交互设计思路；单位说明：Flet尺寸单位px；专门小节：本地图片、音频资源路径踩坑，Windows/Mac相对路径、绝对路径写法，图片加载失败排查。
6. 第3部分：把控件放到指定位置、动态移动控件（重点章节，附带专属写法模板）
    先区分两种定位场景：①静态指定位置（页面加载完成就固定在该位置）②运行时动态移动（触发事件之后再修改坐标挪动控件）
    通俗讲解Flet坐标系：左上角为原点，X向右增大，Y向下增大，配套示意图；
    每个布局容器单独讲解专属写法模板：
    - Row横向布局：主轴对齐、交叉轴对齐、space_between/space_around/space_evenly枚举写法
    - Column纵向布局：垂直、水平对齐写法
    - Stack层叠布局：left、top、right、bottom固定坐标定位写法，offset偏移定位写法，z-index层级控制写法；重点坑：Stack如果没有设置宽高，子控件定位经常不生效；
    - Container容器：margin外边距、padding内边距示意图+写法，alignment容器内对齐写法，区分margin和padding
    - Wrap流式自动换行布局写法
    - GridView网格布局写法
    - ListView长列表优化：item_extent属性，大量数据场景提升渲染性能
    尺寸约束：min_width、max_width、min_height、max_height、expand填充属性写法，expand使用限制、expand和max_width冲突案例；
    移动控件 = 修改offset/left/top属性：联动前面修改控件知识点，说明本质就是修改定位属性；
    动态移动控件写法：瞬时修改坐标写法、带动画平滑移动控件写法模板animate_offset、跟随鼠标移动控件、拖拽控件（Draggable+DragTarget基础示例）、点击一键移动到预设位置（居中、右上角、左下角）；
    溢出4种处理方案：滚动、折叠、文字截断、分页；
    附带布局选择决策树（图文示意）：想要横向排列选Row，纵向少量内容选Column，大量条目滚动选ListView，叠放自由XY定位选Stack；
7. 第4部分：控件交互、手势、动画效果（独立重点章节）
    7.1 基础手势交互（GestureDetector）
    讲解：on_tap单击、on_double_tap双击、on_long_press长按、on_hover鼠标移入/移出；示例：鼠标悬浮改变控件颜色。
    7.2 输入实时交互
    TextField on_change：边输入边触发、实时字数统计、实时搜索示例；回车提交on_submit。
    7.3 通用属性动画 animate_*（所有控件通用）
    统一说明：animate_opacity淡入淡出、animate_scale缩放、animate_rotation旋转、animate_offset位移；动画时长、AnimationCurve动画曲线（线性、弹性、弹跳等）设置方法；关闭动画设置animate=None。
    7.4 AnimatedSwitcher控件切换动画
    用法示例：切换两个控件，自动淡入淡出过渡效果。
    7.5 弹出层交互动画
    AlertDialog、Popover、BottomSheet弹出和关闭过渡动画；SnackBar消息弹出动画。
    7.6 ExpansionPanel折叠展开自带动画
    7.7 拖拽交互 Draggable + DragTarget 完整简单示例
    7.8 加载动画：ProgressBar、ProgressRing动态更新进度
8. 第4.5小节：页面栈导航（Stack Navigation / Push Pop路由，Flet page.views导航栈）
    8.5.1 概念：Flet页面栈本质是 page.views 列表，后进先出的导航栈；Push=压入整页新页面，Pop=返回上一页；页面栈是页面级路由，和Overlay浮层不是一类东西。
    8.5.2 基础操作语法：
        - Push（压入新页面，保留历史，可以返回）：page.views.append(View(...))
        - Pop（返回上一页，弹出栈顶）：page.views.pop()
        - 替换当前页面（不保留上一页）：page.views[-1] = View(...)
        - 清空整个导航栈，只保留首页：page.views.clear() 再追加首页View
    8.5.3 返回事件 on_view_pop：拦截返回、自定义返回逻辑、返回前保存数据。
    8.5.4 页面切换动画：View切换入场/退场动画设置。
    8.5.5 跨页面传参：压入页面时携带参数、上一页和下一页互相传递数据写法示例。
    8.5.6 导航栈高频坑：忘记更新page、栈越界pop、多次重复push、返回后数据丢失、AppBar返回按钮绑定栈pop。
    8.5.7 对比区分：普通page.controls切换页面（无历史、不能返回） VS page.views导航栈（页面栈、支持返回） VS Overlay强层浮层（弹窗、悬浮提示，不替换当前页面，点外部关闭）
9. 第4.6小节：强层浮层组件（Overlay）——弹窗、悬浮提示、鼠标悬浮信息、下拉组件专项深度讲解【重点升级：下拉全量细化】
    9.6.1 概念区分（非常重要）
        - 页面栈page.views：压入完整页面，覆盖旧页面，用来做页面跳转、返回上一页；
        - Overlay强层浮层：不替换当前页面，浮在页面最顶层；点控件弹出，点击空白外部/关闭按钮自动收回；和侧边抽屉、BottomSheet互补；包含：Tooltip、Popover、AlertDialog、PopupMenuButton、Dropdown下拉选择器。
    9.6.2 五大浮层组件清单与适用场景（重点拆分三类下拉）
        - Tooltip：鼠标悬浮在控件上自动弹出简短提示文字，鼠标移开自动消失；用于小字说明、提示信息；不承载操作。
        - Dropdown【表单下拉选择框｜深度细化】：表单专用选择控件，自带输入框载体、选中值回显、label提示文字、Option选项列表；底层Overlay弹出下拉面板；适合筛选、表单单选；
            ✅ 详细参数说明：label、value、options、hint_text、disabled、width、max_width、alignment、border、text_style；
            ✅ 边界避让规则：自动检测屏幕边缘，下拉面板向上/向下翻转；
            ✅ 长选项处理：下拉面板自带滚动；
            ✅ 高频坑：宽度自适应溢出、下拉被其它浮层遮挡、on_change重复触发、选项文字过长截断、弹窗层级冲突；
            ✅ 完整注释代码示例；
        - PopupMenuButton【命令下拉菜单｜深度细化】：按钮触发的操作菜单，一般无回显；PopupMenuItem放操作命令（新增、编辑、删除）；适合AppBar更多按钮、列表行操作、右键菜单；
            ✅ 参数：items、icon、on_open/on_close、menu_position；
            ✅ 对齐方式：在按钮上方/下方弹出；
            ✅ 坑：菜单跑出屏幕、菜单项点击不自动关闭、和Dropdown层级冲突；
            ✅ 完整注释代码示例；
        - Popover【自定义万能下拉面板｜深度细化】：完全自由的浮层容器，内部可以放任意控件（TextField、ListView、Grid、多组输入、组合筛选面板），用来造自定义下拉、复杂选择面板；没有内置样式，全部自己布局；
            ✅ 触发方式：绑定target控件；对齐锚点设置；offset微调；
            ✅ 边界避让开关；max_width、max_height滚动限制；
            ✅ 坑：忘记设置最大宽高导致溢出、点击内部控件时意外关闭、多层Popover嵌套；
            ✅ 完整注释代码示例；
        - AlertDialog：弹窗对话框，确认/取消，带遮罩；阻断下层交互，强确认场景；
    9.6.3 浮层添加方式、挂载位置原理：浮层挂载在page的overlay，脱离普通controls布局流，不受父容器约束，层级最高；讲解overlay渲染顺序、z层级优先级（从低到高：普通页面 → Drawer/BottomSheet → Dropdown → PopupMenuButton → Popover → AlertDialog）
    9.6.4 浮层位置控制、摆放、移动到指定位置（重点）
        4种定位模式，逐个讲解代码模板：
        ① 跟随目标控件（推荐，整齐不拥挤）：浮层绑定触发按钮/控件，自动在控件上方、下方、左侧、右侧弹出；offset偏移微调；Dropdown/PopupMenu默认就是这套模式；
        ② 跟随鼠标坐标：点击/悬浮时读取鼠标XY，浮层移动到鼠标位置；适合右键菜单；
        ③ 屏幕居中（弹窗常用）：居中对齐，固定宽高；AlertDialog默认居中；
        ④ 自定义XY绝对坐标：left/top指定屏幕坐标，动态修改offset移动浮层；适合自由悬浮面板；
        统一对齐枚举：对齐方向（上方、下方、左、右）、锚点设置。
    9.6.5 UI组件库统一设计规范（保证整齐、不溢出、不拥挤，下拉组件专项规范）
        - 统一外边距、内边距：浮层内部padding=16px；浮层和触发控件之间间距8px；浮层距离屏幕边缘最小安全边距16px；
        - 最大宽度限制max_width：所有下拉/浮层必须设置合理max_width；文字自动换行；Dropdown建议max_width=320px；Popover自定义面板建议max_width=480px；
        - 边界自动避让（防溢出核心）：开启边界检测；如果浮层放在下方会超出屏幕底部，自动切换到上方；靠右放不下自动换到左边；避免被屏幕截断；Dropdown原生自带，Popover需要手动配置；
        - 内容排版：内部用Column/Row布局，控件之间间距8px；不要堆太多内容；长内容内部套ListView滚动；下拉选项高度统一（40px/项）；
        - 层级顺序规范（由低到高）：普通页面 → 抽屉/BottomSheet → Dropdown → PopupMenuButton → Popover → AlertDialog（最高）；
        - 遮罩：Dialog带深色遮罩，阻断下层点击；Popover/Tooltip/Dropdown/PopupMenu默认无遮罩，可以手动设置遮罩；
    9.6.6 交互规则：点击外部关闭、ESC关闭、关闭按钮关闭；弹出状态变量控制visible；弹出/关闭动画；下拉类组件特殊交互：Dropdown选中自动收起菜单、PopupMenuItem点击自动关闭菜单、Popover内部操作是否自动关闭可配置；
    9.6.7 浮层调试方法（专门调试定位、溢出、拥挤问题，增加下拉专属调试）
        - 调试技巧1：给浮层加临时彩色边框+背景，看实际渲染范围；
        - 调试技巧2：打印浮层坐标、鼠标坐标、目标控件坐标；
        - 调试技巧3：打开边界溢出可视化，看哪边超出屏幕；
        - 调试技巧4：分步测试：先居中，再跟随控件，再微调offset；
        - 常见问题排查清单：浮层跑出屏幕、和控件重叠拥挤、触发多次弹出、点外部关不掉、位置跟随错位、缩放窗口后位置错乱、下拉菜单被别的浮层盖住、下拉宽度不受控、长选项被截断；
    9.6.8 对比表格：Tooltip、Dropdown、PopupMenuButton、Popover、AlertDialog、Drawer、BottomSheet 选型对比（用途、是否回显、是否自带样式、适合场景、关闭规则）
10. 第5部分：完整调试方案（重点章节，小白按优先级顺序排查）
    Flet热重载调试开启方法；彩色容器边界可视化调试法；
    优先级排查清单：
    1. 是否执行add添加控件
    2. 是否用变量接收控件（无变量无法修改）
    3. visible可见性、disabled禁用、opacity透明度
    4. 控件宽高是否为0
    5. 父容器布局约束是否冲突
    6. 修改属性后是否正确调用update
    7. 动画参数、animate属性是否配置正确，动画不生效排查
    8. 资源图片、音频路径是否正确
    9. 控制台报错阅读，高频报错翻译解释
    10. 导航栈page.views相关报错：pop越界、页面没有加入views、on_view_pop不触发
    11. 浮层&下拉定位排查：溢出屏幕、跟随错位、点击外部无法关闭、层级不对、重复弹出、下拉被遮挡、下拉宽度失控
    print调试：打印坐标、属性值；最小复现调试法；界面刷新冲突、动画卡顿排查；语法错误排查。
    补充：异步阻塞问题：耗时循环、文件读取、网络请求会卡死界面；page.run_async异步用法示例。
11. 第6部分：阶梯仿写小练习（难度递进，配套目标、模板、完整注释代码、预期效果、排错提示）
    练习1：创建窗口，配置窗口标题大小，添加Text文字，运行程序（创建控件）
    练习2：添加按钮，点击修改文字、切换按钮禁用状态（创建+修改控件）
    练习3：Row横向摆放多个按钮，设置对齐方式，复用ButtonStyle统一样式
    练习4：Stack容器内放置控件，点击按钮带动画移动到指定位置（animate_offset）
    练习5：弹出确认弹窗AlertDialog，获取用户选择结果
    练习6：GridView制作网格卡片布局
    练习7：DataTable展示表格，动态修改内容、删除单行
    练习8：表单：多个输入框收集数据，回车提交、实时字数统计（on_change交互）
    练习9：交互动画练习：点击按钮实现控件淡入淡出、放大缩小（animate_opacity、animate_scale）
    练习10：AnimatedSwitcher切换两个界面，自带过渡动画
    练习11：页面栈导航练习：首页点击按钮Push压入二级页面，二级页面按钮Pop返回首页，跨页面传参
    练习12：Overlay浮层&下拉专项练习【新增3个子练习】：
        练习12-1：Dropdown表单下拉；设置label、hint、多个选项、on_change读取选中值；测试边界避让，放在屏幕底部时自动向上弹出下拉面板；限制max_width防止溢出
        练习12-2：PopupMenuButton操作菜单；三个点按钮，弹出编辑/复制/删除菜单项，点击执行对应逻辑
        练习12-3：Popover自定义下拉面板；点击按钮弹出带输入框+列表的自定义筛选面板，开启边界避让，屏幕底部放不下自动换到上方；控制间距，不拥挤不溢出；自定义浮层坐标，带动画弹出
        练习12-4：给按钮增加Tooltip悬浮提示（鼠标悬浮显示信息）
    要求每个练习附带仿写任务，自行修改颜色、大小、动画参数；重点练习：修改控件、删除控件、交互事件、动画效果、页面栈路由、浮层弹窗悬浮提示、三类下拉组件、浮层定位防溢出。
12. 第7部分：选型对比与新手误区避坑指南
    Flet / PyQt / Streamlit 对比表格；高频坑汇总：
    - 创建控件没有保存变量，后续无法修改
    - Stack没有设置宽高，定位不生效
    - margin和padding混淆
    - Column放上万条内容造成卡顿，忘记ListView
    - lambda循环捕获变量错误
    - 频繁调用page.update()，输入框光标丢失、动画卡顿
    - 资源路径写错，图片加载失败
    - 混淆page根对象和普通控件，尝试add(page)
    - 动画不生效：忘记写animate_xxx属性、动画曲线参数错误
    - 导航栈坑：重复push页面、pop空栈报错、on_view_pop不触发、切换页面忘记page.update()
    - 浮层&下拉Overlay坑：浮层跑出屏幕、没有设置max_width导致太宽、和触发控件贴太紧拥挤、边界避让没开启、点外部无法关闭、层级被别的组件盖住、窗口大小变化后位置错乱、Dropdown下拉被上层浮层遮挡、下拉宽度自适应撑破布局
13. 第8部分：进阶拓展板块
    代码组织规范（拆分函数，不要全部堆在主函数）、拖拽交互、SplitView分割面板、Skeleton骨架屏、水印、全局主题切换、自定义封装控件、无障碍适配、弹簧动画、蒙版裁剪、表单校验、页面路由栈、JSON本地持久存储、音视频播放、Canvas绘图、文件选择；补充：打包EXE发给其他人简要指引、全局快捷键监听示例。
14. 附录速查表
    名词术语对照表、Flet官方文档链接；【全部控件创建模板速查表】、【可动态修改属性速查表】、【交互事件on_xxx清单】、【动画animate_xxx属性速查表】、对齐枚举、动画曲线枚举、颜色参考、page窗口常用属性清单；
    额外增加：【page.views页面栈导航API速查表】（Push、Pop、替换、清空栈、on_view_pop）；【Overlay浮层+三类下拉组件速查表】Tooltip / Dropdown / PopupMenuButton / Popover / AlertDialog 定位参数、对齐、边界避让、关闭方式、适用场景速查。

【全部交互反馈 + 动画规则，全部启用】
▌全局动画
1. 页面顶部滚动进度条跟随滚动平滑变化；锚点跳转平滑滚动；切换明暗主题时页面所有元素颜色、背景平滑过渡。
2. 页面区块、卡片、表格、提示块进入视口：淡入 + 轻微上移入场动画；离开不做反向动画。

▌侧边抽屉动画
3. 抽屉横向弹性滑入滑出，遮罩淡入淡出；目录项依次延迟出现；当前章节高亮底色缓慢呼吸脉动。

▌折叠面板
4. ExpansionPanel展开收起自带高度平滑动画；箭头同步旋转过渡；hover背景柔和变色。

▌卡片&控件hover交互
5. 画廊卡片hover上浮、阴影放大、边框高亮、轻微缩放；所有按钮hover提亮，点击按压缩小回弹+波纹反馈；IconButton悬浮变色。

▌Tooltip悬浮提示
6. Tooltip鼠标移入淡入上浮，移出淡出消失；自动避开屏幕边界，不会溢出。

▌图片预览弹窗
7. 点击占位预览图，蒙层淡入，图片放大弹出；关闭时缩小淡出；ESC和点击蒙层关闭弹窗。

▌回到顶部悬浮按钮
8. 滚动超过阈值渐显，滚动到顶部渐隐；点击回弹动画。

▌代码块交互
9. 代码块hover微光；复制按钮hover微动；点击复制成功弹出短暂淡入淡出toast提示。

▌演示区块动画
10. 演示区域：修改控件、删除控件、动画演示区块，点击按钮实时展示效果（移动、变色、淡入淡出、缩放）；溢出演示、坐标系演示、margin/padding演示、层级演示全部带过渡动画；浮层&下拉演示区：Dropdown表单下拉、PopupMenu菜单、Popover自定义面板、跟随控件弹出、自定义坐标弹出、边界避让演示。

▌弹窗、浮层、下拉、页面栈切换动画
11. AlertDialog、Popover、BottomSheet、Dropdown下拉面板、PopupMenu弹出淡入缩放，关闭反向过渡；SnackBar消息从底部滑入滑出；page.views页面栈Push/Pop自带页面切换过渡动画；所有Overlay浮层弹出关闭动画统一柔和。

▌通用约束
12. 所有光标可点击元素鼠标自动切换pointer；动画曲线统一弹性柔和，时长220~450ms，不刺眼、不抖动；美化滚动条；文字选中柔和背景高亮；链接hover下划线生长动画。

▌排版约束
- 图片使用占位标签，alt写清楚用途，标注后续替换截图位置
- 表格自动适配深色浅色模式
- 页面横向不溢出，PC、手机自适应布局
- 预览图点击唤起全屏预览弹窗
- 代码块带一键复制、语法高亮
- 重点内容标记：【新手重点】【不要踩坑】【快速记住】
- 增加提示区块：Info / Warning / Error / Success 四种提示框，穿插文档重点提醒
