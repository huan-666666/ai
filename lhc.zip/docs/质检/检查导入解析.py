# -*- coding: utf-8 -*-
"""导入解析回归自检（无 UI 依赖，不启动 Qt）

用途:
    对 docs/质检/导入用例/ 下的脱敏语料逐份执行：
        识别 → 解析 → 期号口径 → 批内去重 → 缺期号拒绝
    并把结果与每份文件头声明的期望值逐条比对，输出 ✅/❌ 与统计。
    全部通过退出码 0，任一失败退出码 1，可直接并入收口回归项。

设计:
    TAB/data_import.py 顶部 import 了 UI 控件，但解析函数本身不触碰 Qt；
    本脚本在导入前注入一个轻量 UI 桩模块，因此不会加载 PyQt6、不创建 QApplication。
    解析引擎只使用 lib/ 与标准库，语料与脚本都是工程资产，不依赖临时文件。

运行:
    python docs\质检\检查导入解析.py
"""

import importlib.util
import os
import re
import sys
import types
from collections import Counter

# 定位项目根：向上查找含 run.py 的目录
ROOT = os.path.dirname(os.path.abspath(__file__))
while not os.path.exists(os.path.join(ROOT, 'run.py')):
    parent = os.path.dirname(ROOT)
    if parent == ROOT:
        break
    ROOT = parent
CORPUS_DIR = os.path.join(ROOT, 'docs', '质检', '导入用例')


def load_engine():
    """加载 TAB/data_import.py 的解析引擎（注入 UI 桩，避免依赖 PyQt6）"""
    sys.path.insert(0, ROOT)
    ui = types.ModuleType('UI')
    for name in ('QFileDialog', 'QHBoxLayout', 'QLabel', 'QMessageBox', 'QPushButton',
                 'QSplitter', 'QTextEdit', 'QVBoxLayout', 'QWidget', 'Qt'):
        setattr(ui, name, type(name, (), {}))
    sys.modules['UI'] = ui
    spec = importlib.util.spec_from_file_location(
        'lhc_data_import_engine', os.path.join(ROOT, 'TAB', 'data_import.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class FakeHost:
    """只提供解析引擎需要的空历史库（不写盘）"""
    historical_data = []


CHECKS = []
FAILS = []


def check(name, condition, detail=''):
    """记录一条断言并即时输出 ✅/❌"""
    if condition:
        CHECKS.append(name)
        print('  ✅ %s%s' % (name, (' | ' + detail) if detail else ''))
    else:
        FAILS.append(name)
        print('  ❌ %s%s' % (name, (' | ' + detail) if detail else ''))


# 每份语料的期望：文件、解析条数、去重丢弃条数、缺期号条数、无法判定条数、
# 期序列表、完整期号列表、编码
CASES = [
    ('01_单行9段.txt', 3, 0, 0, 0, [1, 2, 3], [2026001, 2026002, 2026003], 'UTF-8'),
    ('02_竖排多期.txt', 2, 0, 0, 0, [101, 102], [2026101, 2026102], 'UTF-8'),
    ('03_日期在前.txt', 3, 0, 0, 0, [201, 202, 203], [2026201, 2026202, 2026203], 'UTF-8'),
    ('04_号码在前.txt', 2, 0, 0, 0, [251, 252], [2026251, 2026252], 'UTF-8'),
    ('05_混合写法.txt', 7, 0, 0, 0,
     [301, 302, 303, 304, 305, 306, 307],
     [2026301, 2026302, 2026303, 2026304, 2026305, 2026306, 2026307], 'UTF-8'),
    ('06_中文键.json', 2, 0, 0, 0, [1, 2], [2026001, 2026002], 'UTF-8'),
    ('07_英文键.json', 2, 0, 0, 0, [3, 4], [2026003, 2026004], 'UTF-8'),
    ('08_空期号.json', 1, 0, 2, 0, [5], [2026005], 'UTF-8'),
    ('09_纯号码.txt', 0, 0, 3, 0, [], [], 'UTF-8'),
    ('10_分隔符变体.txt', 4, 0, 0, 0, [401, 402, 403, 404],
     [2026401, 2026402, 2026403, 2026404], 'UTF-8'),
    ('11_编码GBK.txt', 2, 0, 0, 0, [501, 502], [2026501, 2026502], 'GB18030'),
]

# 归一化行严格格式：YYYY-MM-DD + 空格 + 期序（不补零、不带年份）+ 空格 +
# 6 正码（两位定宽补零）+ 空格 + "+" + 空格 + 特别码（两位补零）
NORMALIZED_PATTERN = r'^\d{4}-\d{2}-\d{2} \d+ (\d{2} ){6}\+ \d{2}$'


def run_cases(engine):
    """逐份语料执行解析并比对期望"""
    print('=' * 70)
    print('一、语料断言（%d 份）' % len(CASES))
    host = FakeHost()
    for filename, parsed, merged, missing, undetermined, periods, fulls, encoding in CASES:
        path = os.path.join(CORPUS_DIR, filename)
        print('-' * 70)
        print('文件：%s' % filename)
        if not os.path.exists(path):
            check(filename + ' 存在', False, '缺少语料文件')
            continue
        with open(path, 'rb') as handle:
            raw = handle.read()
        text, used_encoding = engine._decode_text(raw)
        check('编码 = %s' % encoding, used_encoding == encoding, '实际 %s' % used_encoding)
        if text is None:
            check(filename + ' 可解码', False)
            continue
        report = engine._auto_parse_text(host, text, used_encoding or '未知', filter_library=False)
        actual_periods = sorted(record.get('period') for record in report['records'])
        actual_fulls = sorted(record.get('period_full') for record in report['records'])
        check('解析条数 = %d' % parsed, report['parsed'] == parsed,
              '实际 %d' % report['parsed'])
        check('批内去重丢弃 = %d' % merged, report['merged'] == merged,
              '实际 %d' % report['merged'])
        check('缺期号 = %d' % missing, len(report['missing']) == missing,
              '实际 %d' % len(report['missing']))
        check('无法判定 = %d' % undetermined, len(report['errors']) == undetermined,
              '实际 %d' % len(report['errors']))
        check('期序列表一致', actual_periods == sorted(periods), '实际 %s' % actual_periods)
        check('完整期号列表一致', actual_fulls == sorted(fulls), '实际 %s' % actual_fulls)
        # 逐条归一化格式断言：有日期的记录必须严格匹配；
        # 无日期记录已明确标为「日期未知」，单列一条断言，不伪装成完整日期。
        dated = [record for record in report['records']
                 if engine._normalize_date_text(record.get('date'))]
        bad_lines = [engine._format_normalized(record) for record in dated
                     if not re.match(NORMALIZED_PATTERN, engine._format_normalized(record))]
        check('归一化格式 %d 条（有日期）逐条匹配' % len(dated), not bad_lines,
              ('反例 %s' % bad_lines[:2]) if bad_lines else '')
        undated = [record for record in report['records']
                   if not engine._normalize_date_text(record.get('date'))]
        if undated:
            check('无日期记录标记「日期未知」',
                  all(engine._format_normalized(record).startswith('日期未知 ')
                      for record in undated),
                  '实际 %s' % [engine._format_normalized(record) for record in undated])


def run_period_checks(engine, DataUtils):
    """期号口径：完整期号、期序拆分、纯期序补号、0/空视为缺期号"""
    print('=' * 70)
    print('二、期号口径断言')
    cases = [
        ('2026001', None, 2026001),
        ('第2026116期', None, 2026116),
        ('第20260116期', None, 2026116),
        ('第202600116期', None, 2026116),
        ('116', '2026-04-26', 2026116),
        ('116', None, None),
        ('0', '2026-01-01', None),
        ('-1', '2026-01-01', None),
        ('', '2026-01-01', None),
        (None, '2026-01-01', None),
    ]
    for raw, date_text, expected in cases:
        actual = DataUtils.normalize_period(raw, date_text)
        check('期号 %r + 日期 %r → 完整号 %s' % (raw, date_text, expected), actual == expected,
              '实际 %r' % (actual,))
    # 新口径：同一原值必须同时拆出「期序 / 完整期号 / 年份」三字段
    field_cases = [
        ('2026001', None, (1, 2026001, 2026)),
        ('308', '2026-11-04', (308, 2026308, 2026)),
        ('116', '2026-04-26', (116, 2026116, 2026)),
        ('116', None, (None, None, None)),
        ('0', '2026-11-04', (None, None, None)),
        (None, '2026-11-04', (None, None, None)),
    ]
    for raw, date_text, expected in field_cases:
        actual = engine._period_fields(raw, date_text)
        check('期序拆分 %r + %r → %s' % (raw, date_text, expected), actual == expected,
              '实际 %r' % (actual,))


def run_semantic_checks(engine, host):
    """去重保留最后一次 / 缺期号拒绝 / 交错一致性 / 归一化顺序"""
    print('=' * 70)
    print('三、导入语义断言（去重 / 缺期号 / 交错 / 归一化）')

    # 1) 批内去重：保留最后一次
    dup_text = ('2026001 2026-01-01 01 02 03 04 05 06 + 07\n'
                '2026001 2026-01-01 08 09 10 11 12 13 + 14\n')
    report = engine._auto_parse_text(host, dup_text, '粘贴文本', filter_library=False)
    check('批内去重保留最后一次（条数 1 / 丢弃 1）',
          report['parsed'] == 2 and len(report['records']) == 1 and report['merged'] == 1,
          'parsed=%d records=%d merged=%d' % (report['parsed'], len(report['records']),
                                              report['merged']))
    kept = report['records'][0]['numbers'] if report['records'] else []
    check('保留的是后一条号码', kept == [8, 9, 10, 11, 12, 13], '实际 %s' % kept)

    # 2) 缺期号：有效 1 条 + 纯号码 1 条
    mixed_text = ('2026002 2026-01-02 01 02 03 04 05 06 + 07\n'
                  '11 12 13 14 15 16 + 17\n')
    report = engine._auto_parse_text(host, mixed_text, '粘贴文本', filter_library=False)
    check('缺期号拒绝并保留可写记录（缺 1 / 写 1）',
          len(report['missing']) == 1 and len(report['records']) == 1,
          'missing=%d records=%d' % (len(report['missing']), len(report['records'])))
    check('缺期号行号定位', report['missing'][0][0] == '第2行', '实际 %s' % report['missing'][0][0])

    # 3) 交错一致性：同一批记录换顺序，结果按期为键必须一致
    style_a = ['2026年10月0%d日 第20266%02d期 01 02 03 04 05 06 + 07' % (i, i) for i in (1, 2, 3)]
    style_b = ['08 09 10 11 12 13 + 14 2026-10-0%d 第20266%02d期' % (i, i) for i in (4, 5, 6)]
    plain = '\n'.join(style_a + style_b)
    interlaced = '\n'.join([style_a[0], style_b[0], style_a[1], style_b[1], style_a[2], style_b[2]])
    report_plain = engine._auto_parse_text(host, plain, '粘贴文本', filter_library=False)
    report_mix = engine._auto_parse_text(host, interlaced, '粘贴文本', filter_library=False)
    map_plain = {(r['period_full'], r['date'], tuple(r['numbers']), r['special'])
                 for r in report_plain['records']}
    map_mix = {(r['period_full'], r['date'], tuple(r['numbers']), r['special'])
               for r in report_mix['records']}
    check('交错与非交错：条数一致',
          len(report_plain['records']) == len(report_mix['records']) == 6,
          'plain=%d mix=%d' % (len(report_plain['records']), len(report_mix['records'])))
    check('交错与非交错：记录内容逐条一致', map_plain == map_mix,
          '差异 %s' % (map_plain ^ map_mix))

    # 3.1) 跨年同序不互撞：2025 的 308 与 2026 的 308 必须各保留 1 条
    cross_year = ('2025308 2025-11-04 01 02 03 04 05 06 + 07\n'
                  '2026308 2026-11-04 08 09 10 11 12 13 + 14\n')
    report = engine._auto_parse_text(host, cross_year, '粘贴文本', filter_library=False)
    check('跨年同期序不合并（保留 2 条 / 丢弃 0）',
          len(report['records']) == 2 and report['merged'] == 0,
          'records=%d merged=%d' % (len(report['records']), report['merged']))
    check('跨年同期序的期序都为 308、完整号互不相同',
          sorted(r['period'] for r in report['records']) == [308, 308]
          and sorted(r['period_full'] for r in report['records']) == [2025308, 2026308],
          '实际 %s' % [(r['period'], r['period_full']) for r in report['records']])

    # 4) 归一化展示顺序：日期 - 期序 - 6 正码（两位补零） - 特别码（两位补零）
    record = report_plain['records'][0]
    text = engine._format_normalized(record)
    check('归一化顺序 YYYY-MM-DD 期序 6码 + 特码', bool(re.match(NORMALIZED_PATTERN, text)), text)


def run_parquet_probe(engine):
    """Parquet 实测：用 DuckDB 生成临时 parquet，再走 DBHelper.read_table_file 直读"""
    import shutil
    import tempfile
    print('=' * 70)
    print('四、Parquet 实测')
    try:
        import duckdb
    except Exception as exc:
        check('DuckDB 可用（Parquet 直读）', False, '不可用：%s' % exc)
        return
    temp_dir = tempfile.mkdtemp(prefix='lhc_pq_probe_')
    parquet_path = os.path.join(temp_dir, 'probe.parquet')
    try:
        conn = duckdb.connect()
        conn.execute('CREATE TABLE t(period BIGINT, date VARCHAR, numbers VARCHAR, special INTEGER)')
        conn.execute("INSERT INTO t VALUES (2026001, '2026-01-01', '01 02 03 04 05 06', 7),"
                     " (2026002, '2026-01-02', '08 09 10 11 12 13', 14)")
        conn.execute("COPY t TO '%s' (FORMAT PARQUET)" % parquet_path.replace("'", "''"))
        conn.close()
        from lib.db_helper import DBHelper
        database = DBHelper(temp_dir)
        try:
            records = database.read_table_file(parquet_path)
        finally:
            database.close()
        check('Parquet 直读条数 = 2', len(records) == 2, 'DuckDB %s，实际 %d 条'
              % (duckdb.__version__, len(records)))
        check('Parquet 期号口径 = 2026001/2026002',
              [record['period'] for record in records] == [2026001, 2026002],
              '实际 %s' % [record['period'] for record in records])
    except Exception as exc:
        check('Parquet 直读可用', False, '失败：%s' % exc)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def main():
    print('导入解析回归自检')
    print('语料目录：%s' % CORPUS_DIR)
    engine = load_engine()
    DataUtils = engine.DataUtils
    run_cases(engine)
    run_period_checks(engine, DataUtils)
    run_semantic_checks(engine, FakeHost())
    run_parquet_probe(engine)
    print('=' * 70)
    print('断言 %d 条：通过 %d / 失败 %d' % (len(CHECKS) + len(FAILS), len(CHECKS), len(FAILS)))
    if FAILS:
        print('失败项：')
        for name in FAILS:
            print('  - ' + name)
        return 1
    print('结果：全部通过')
    return 0


if __name__ == '__main__':
    sys.exit(main())
