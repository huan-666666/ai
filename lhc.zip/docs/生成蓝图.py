# -*- coding: utf-8 -*-
"""
===========================================================================
docs/生成蓝图.py - 生成程序「蓝图」：每个选项卡一扇窗口截图 + 索引页
===========================================================================
用法：
    python docs/生成蓝图.py

输出：
    docs/蓝图/00.png ... 每页一张窗口截图（按选项卡顺序 00–13）
    docs/蓝图/index.html   带缩略图导航的索引页

说明：
    1) 用真实平台后台渲染主窗口（WA_DontShowOnScreen，不弹窗），截图即「有画面的窗口蓝图」
    2) 生成过程会把保存配置/绑定写入动作屏蔽，不会改动 系统v7.5 下的配置与数据
===========================================================================
"""

import os  # 作用说明：拼接项目根与 docs/蓝图 输出目录、创建目录并写文件；同时清理可能残留的离屏平台变量
import sys  # 作用说明：把项目根目录插入 sys.path，使脚本能导入 UI 与 plugins 下的主窗口模块
import time  # 作用说明：每页切换后等待去抖/布局稳定，保证截图是最终画面

# 真实平台：offscreen 平台没有字库，截图会缺字；改用真实 Windows QPA + WA_DontShowOnScreen
os.environ.pop('QT_QPA_PLATFORM', None)

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from UI import QApplication, Qt  # 作用说明：从界面层唯一导入中心取 QApplication 与 Qt 枚举（用于 WA_DontShowOnScreen）
from plugins.彩票预测 import LotteryPredictionWindow  # 作用说明：导入主窗口类以便实例化并逐页截图（本脚本不启动 run.py）


def _safe_name(text):
    """功能：把选项卡标题转成安全的英文文件名
    注意：只做「固定对照表 + 兜底哈希」的字符串映射，不写盘、不改标题；
          未命中对照表时用 hash 取模生成 tab_xxx，同一进程内可复现，
          但不同进程的 hash 随机化会导致文件名变化（仅影响兜底分支）。
    参数:
        text: 选项卡标题（如「数字与五行」）
    返回:
        str 仅含 ASCII 字母数字与下划线的文件名片段（不带扩展名）
    """
    table = {
        '数字选择': 'number_selection', '数字与生肖': 'zodiac', '数字与五行': 'element',
        '预测': 'prediction', '历史': 'history', '统计': 'stats', '大数据': 'bigdata',
        '公告': 'notice', '收藏': 'favorites', '概率': 'probability',
    }
    for key, value in table.items():
        if key in text:
            return value
    return 'tab_' + str(abs(hash(text)) % 100000)


def main():
    """功能：后台创建主窗口，逐选项卡截图并生成 docs/蓝图/index.html 索引页
    注意：会写盘 docs/蓝图/ 下的 png 与 index.html（覆盖同名旧文件）；
          为防改动用户数据，先把全部保存/落盘函数替换为空实现（进程内 monkeypatch，
          不改源码）；窗口设置 WA_DontShowOnScreen（真实平台渲染，字库完整），
          不弹窗、不进事件循环，只靠 processEvents 刷新画面。
    参数: 无
    返回: 无（成功返回 None；截图或写文件失败时由 OSError 直接抛出）
    """
    app = QApplication([])
    # 屏蔽落盘，避免生成蓝图时改动用户配置与数据（全部保存入口都置空）
    for _name in ('_save_ini_config', '_persist_bindings', '_save_widget_states',
                  '_sync_data_state_to_db', '_sync_history_to_db', 'save_prediction_history'):
        setattr(LotteryPredictionWindow, _name, lambda self, *a, **k: None)
    LotteryPredictionWindow.closeEvent = lambda self, e: None

    window = LotteryPredictionWindow()
    # 真实平台渲染但不真正上屏：字库完整，且不会弹窗
    window.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
    window.resize(1600, 1000)
    window.show()
    app.processEvents()
    time.sleep(0.4)

    out_dir = os.path.join(_ROOT, 'docs', '蓝图')
    os.makedirs(out_dir, exist_ok=True)

    pages = []
    for index in range(window.tabs.count()):
        window.tabs.setCurrentIndex(index)
        app.processEvents()
        time.sleep(0.3)  # 等待布局与 200ms 去抖后的最终画面
        app.processEvents()
        title = window.tabs.tabText(index)
        file_name = '%02d.png' % index
        window.grab().save(os.path.join(out_dir, file_name))
        pages.append((title, file_name))
        print('已生成: ' + file_name + '  (' + title + ')')

    cards = []
    for title, file_name in pages:
        cards.append(
            '<article class="card">'
            '<h2>' + title + '</h2>'
            '<img src="' + file_name + '" alt="' + title + '">'
            '<p><a href="' + file_name + '" target="_blank">查看原图</a></p>'
            '</article>'
        )

    html = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>彩票预测系统 - 程序蓝图</title>
<style>
    body { margin: 0; background: #0f172a; color: #e2e8f0; font-family: "Microsoft YaHei", sans-serif; }
    header { padding: 28px 36px 10px; }
    header h1 { margin: 0 0 6px; font-size: 26px; color: #7dd3fc; }
    header p { margin: 0; color: #94a3b8; font-size: 14px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(460px, 1fr));
            gap: 18px; padding: 22px 36px 40px; }
    .card { background: #1e293b; border: 1px solid #334155; border-radius: 10px;
            padding: 12px; box-shadow: 0 6px 18px rgba(0,0,0,.35); }
    .card h2 { font-size: 15px; margin: 2px 0 10px; color: #fbbf24; }
    .card img { width: 100%; border-radius: 6px; border: 1px solid #475569; display: block; }
    .card p { margin: 8px 0 2px; font-size: 12px; }
    .card a { color: #7dd3fc; text-decoration: none; }
    .card a:hover { text-decoration: underline; }
</style>
</head>
<body>
<header>
    <h1>彩票预测系统 · 程序蓝图</h1>
    <p>每个选项卡一扇真实窗口画面（真实平台渲染 + WA_DontShowOnScreen，1600 × 1000）· 共 ''' + str(len(pages)) + ''' 页</p>
</header>
<div class="grid">
''' + '\n'.join(cards) + '''
</div>
</body>
</html>
'''
    index_path = os.path.join(out_dir, 'index.html')
    with open(index_path, 'w', encoding='utf-8') as handle:
        handle.write(html)
    print('索引页: ' + index_path)


if __name__ == '__main__':
    main()
