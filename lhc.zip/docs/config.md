## 项目配置说明文档

## 文档作用
记录项目当前已使用的全部配置项、持久化位置、恢复机制，以及后续 config.json 扩展方案。
新增配置项必须同步更新本文档。

## 当前版本配置状态（v0.0.34）
- ✅ 已启用外部配置：`程序目录/系统v7.5/配置.ini`（由主窗口读写，程序退出与关键操作时保存）
- ✅ INI 丢失自动恢复：全部配置以 JSON 镜像写入 SQLite `系统v7.5/app_config.db` 的 `app_config` 表（key = `ui_ini`）
- ✅ 业务数据兜底（v0.0.18）：历史开奖数据镜像写入 `history_records` 表，预测记录写入 `系统v7.5/预测记录.json`
- ✅ DuckDB 接入（v0.0.22 起）：[16] 大数据分析从 `系统v7.5/analysis.duckdb` 的 `history_detail` 表按窗口取数
- ✅ DuckDB 扩展（v0.0.23）：[6] 统计分析图表、[7] 回测/算法对比/命中趋势、HTML 报表导出统一经 `_analysis_records()` 取数；[1] 导入支持 DuckDB 直读 CSV / Parquet
- ✅ 存储索引入库（v0.0.23）：[15] 数据存储的 `index.json` 镜像到 SQLite `storage_items` 表，JSON 丢失可恢复
- ✅ 入口与界面（v0.0.24）：取消插件扫描、窗口标题统一「系统v7.5」，配置项与存储结构无变化
- ✅ 选项卡加载（v0.0.25）：页面标题/顺序改由各页 `TAB_INFO` 声明并自动加载，配置项与存储结构无变化
- ✅ 五行页重设计（v0.0.26）：界面布局调整，五行绑定仍存 `配置.ini` 与 JSON，配置项与存储结构无变化
- ✅ 生肖/五行即时生效（v0.0.27）：点击号码选生肖、粘贴数字点「应用」都会自动写 JSON + INI（静默保存），配置项与存储结构无变化
- ✅ 页面自包含迁移（v0.0.28）：全部 16 页（[1]-[16]）的业务逻辑迁入各自 `TAB/*.py` 的 `install(host)`，新增 `[NumberColors]` 分组记忆与五行纵向分隔条记忆，其余配置项与存储结构无变化
- ✅ 交互细节修复（v0.0.29）：`[NumberColors]` 随每次 `_save_ini_config` 一并写入（不再被整份 INI 覆盖丢失）；新增 `storage_splitter` / `bd_main_splitter` 两组分隔条记忆，配置项与存储结构无变化
- ✅ 清理与记忆完善（v0.0.30）：`[Display] current_tab_index` 启动恢复（`_ini_start_tab_index` 暂存后于 `_init_ui` 应用）；分隔条校验取消「每栏 ≥25%」比例限制，仅保留栏数一致 + 30px 下限，`zodiac_h_splitter` 等大幅拖动可记忆；[1] 数据导入支持多顺序多写法原始文本；数据库 `app_config.db` / `analysis.duckdb` 确认在用，存储结构无变化
- ✅ 数据目录统一（v0.0.31）：SQLite / DuckDB 从 `程序目录/data/` 迁入 `程序目录/系统v7.5/`，与 JSON、INI、数据存储同目录；启动时自动迁移旧 `data/` 文件并删除空目录，配置项与表结构无变化
- ✅ 大数据布局优化（v0.0.32）：`bd_main_splitter` 默认 `230,320,267`，`bd_mid_splitter` 记忆值保留；`[Display]` 保存改为「写入当前值 + 回填旧键」，未显式写出的分隔条键（如 `zodiac_h_splitter`）不再被整份重写丢失；隐藏页面的分隔条不写当前值，保留上次拖动结果。无新增配置项与表结构变化
- ✅ 数值稳定修复（v0.0.33）：仅修复自相关 NaN、NaN→int 转换与 KMeans/corrcoef 告警，配置项、INI 结构与数据库表均无变化
- ✅ 指标参数同行（v0.0.34）：`[Display] bd_main_splitter_sizes` 仍默认 `230,320,267`；切换选项卡时延迟恢复该值（首帧 QSplitter 会按 sizeHint 重排，不能直接依赖构建期 `setSizes`）。无新增配置项与表结构变化
- ✅ 配置与业务数据同目录，exe 打包后以 exe 所在目录为基准，整体拷贝即可迁移
- ✅ 旧版目录「彩票预测系统v7.5」启动时自动迁移到「系统v7.5」，INI 内旧路径自动重定位
- ❌ 尚未启用 `config.json`（仅预留方案，见下文）

## 数据库选型与接入情况（v0.0.23）

> 结论：**两者都要，但不是重复存一份**。SQLite 管业务状态与历史记录，DuckDB 负责分析计算数据集与文件直读。

### 职责分工

| 数据库 | 存什么 | 谁在用 | 不存什么 |
|---|---|---|---|
| SQLite `系统v7.5/app_config.db` | 程序配置、INI 镜像（`ui_ini`）、已保存预测（`saved_predictions`）、功能状态（`func_state`）、历史开奖镜像（`history_records`）、存储索引镜像（`storage_items`） | 主窗口 `_db`；历史记录页、预测/收藏、公告页状态、[15] 数据存储 | 万级明细展开、统计中间结果 |
| DuckDB `系统v7.5/analysis.duckdb` | 历史明细展开表 `history_detail(period, date, seq, number, is_special)`，100 期 = 700 行；另可直接读 CSV / Parquet 文件（不入库） | [6] 统计分析图表、[7] 回测/算法对比/命中趋势、[16] 大数据分析、HTML 报表导出（统一 `_analysis_records()`）；[1] 导入 `read_csv_auto` / `read_parquet` | 界面配置、单条增删改（这些用 SQLite 更稳） |

### 历史记录为什么仍放 SQLite

| 维度 | 实际情况 |
|---|---|
| 写入形态 | 单条/少量：导入一条、删除一行、修改期号；保存时全量覆盖镜像 |
| 读取形态 | 按主键/区间取少量：当前页 100 条、单条详情、按 `period` 排序 |
| 恢复能力 | JSON 损坏时用 `load_history()` 逐行还原，SQLite 自带事务与 WAL |
| 数据量 | 100 期 16 KB；即使 1 万期也只有约 1.6 MB，SQLite 毫无压力 |

### 大数据分析为什么走 DuckDB（v0.0.22 已接入）

| 环节 | 实现 | 位置 |
|---|---|---|
| 同步 | 内存历史记录整体展开写入 DuckDB（覆盖写） | `lib/db_helper.py` `sync_history_to_duckdb` |
| 取数 | SQL 按 `period` 倒序取最近 N 期（`DISTINCT period ... LIMIT`），再组装成记录 | `lib/db_helper.py` `load_history_for_analysis` |
| 计算 | 频率 / 遗漏 / 转移三维评分、波色分析、统计检验 | `lib/math_algo.py` `BigDataAnalyzer` |
| 回退 | DuckDB 未安装或查询失败 → 自动用内存 `historical_data`，功能不中断 | `plugins/彩票预测.py` `_on_bigdata_analyze_clicked` |
| 可见性 | 界面状态行与复制/导出报告显示「数据源 DuckDB / 内存」 | `TAB/bigdata_analysis.py`、`BigDataAnalyzer.format_result_text` |

### 统计 / 回测 / 报表为什么也走 DuckDB（v0.0.23 已接入）

统一入口 `plugins/彩票预测.py` `_analysis_records(window=None)`：

| 调用方 | 用途 | DuckDB 承担的部分 |
|---|---|---|
| `_draw_chart`（[6] 统计分析图表） | 13 种分布图 | 按窗口取最近 N 期明细 |
| `_show_number_trend_chart`（[6] 命中/号码趋势） | 最近 20 期走势 | 倒序窗口取数 |
| `_on_compare_all_algorithms`（[7] 算法对比） | 批量滑窗训练 | 一次取够 N 期，Python 只做算法 |
| `_on_start_backtest`（[7] 回测） | 逐期回测 | 一次取够 N 期 |
| `_on_export_report`（HTML 报表导出） | 最近 5 期 + 热门/冷门 + 单双大小 | 一次取全量统计 |
| `_on_bigdata_analyze_clicked`（[16]） | 三维评分 | 同 v0.0.22 |

同步策略：`_compute_data_fingerprint()` 计算数据指纹，只有历史数据变化时才 `sync_history_to_duckdb`，
避免每次点按钮都整表覆盖。失败或 DuckDB 不可用 → 自动回退内存 `historical_data`，返回值第二项标明 `DuckDB` / `内存`。

### CSV / Parquet 直读（v0.0.23）

[1] 数据导入选择 `*.csv` / `*.parquet` 时，优先交给 DuckDB 解析，不落库、不进 JSON：

| 环节 | 实现 | 位置 |
|---|---|---|
| 文件过滤 | 支持 `*.csv` / `*.parquet` / `*.txt` / `*.json` | `plugins/彩票预测.py` `_on_import_clicked` |
| 直读 | `SELECT * FROM read_csv_auto(..., sample_size=-1)` / `read_parquet(...)` | `lib/db_helper.py` `read_table_file` |
| 表头兼容 | 期号/date/号码/特别码，或 n1..n6、前 9 列兜底；中文表头亦可 | `lib/db_helper.py` `_records_from_table` |
| 回退 | DuckDB 不可用时退回内置 CSV 解析；Parquet 无内置解析则报错提示 | `plugins/彩票预测.py` `_parse_import_file` |

### 存储索引入库（v0.0.23）

[15] 数据存储的文件本体仍放磁盘（`系统v7.5/数据存储/`），只把 `index.json` 镜像进 SQLite：

| 环节 | 实现 | 位置 |
|---|---|---|
| 建表 | `storage_items(id, type, title, content, file_path, tags, created_at, updated_at, size, synced_at)` | `lib/db_helper.py` `_init_tables` |
| 写 | `save_storage_items(items, tags)` 全量覆盖，`tags` 存 JSON | `lib/db_helper.py` |
| 读 | `load_storage_items()` → `(items, tags)` | `lib/db_helper.py` |
| 触发 | `_save_storage_index` 写盘成功后镜像；`_load_storage_index` 在 JSON 为空时从库恢复 | `plugins/彩票预测.py` |

> 分工口径：DuckDB 负责「按窗口切片 + 明细存储 + 文件直读」，Python 负责评分模型本身；
> 不把评分算法写成 SQL，避免算法与数据库耦合过深。SQLite 负责「配置 + 业务状态 + 索引镜像」。

### 各功能数据库使用清单（14 个启用选项卡；另有 3 页合并停用）

| 选项卡 | 数据从哪来 / 存到哪 | 归属 | 说明 |
|---|---|---|---|
| [1] 数据导入与格式转换 | 解析后追加到内存，保存时写 JSON + SQLite 镜像；CSV/Parquet 由 DuckDB 直读 | **SQLite + DuckDB** | 写入走 SQLite，文件直读走 DuckDB |
| [2] 历史记录 | 内存 `historical_data` 分页；JSON 丢失时从 SQLite 恢复 | **SQLite** | 按页读取，典型 OLTP 查询 |
| [3] 预测与抽取 | 读历史内存数据；预测结果写 JSON + `saved_predictions` 镜像 | **SQLite** | 业务结果保存 |
| [4] 数字选择 | 用户输入即时计算，不落库 | 不需要库 | 无持久化需求 |
| [5] 第七位预判 | 读历史内存数据 + 算法计算 | 不需要库（数据在内存） | 无写库动作 |
| [6] 统计分析图表 | `_analysis_records()` → DuckDB `history_detail` 按窗口取数 | **DuckDB（已接入）** | 纯聚合查询，数据量大时转 SQL 收益明显 |
| [7] 回测分析 / 算法对比 / 命中趋势 | `_analysis_records()` → DuckDB 批量取数，Python 做滑窗算法 | **DuckDB（已接入）** | 期数 × 算法批量计算，取数交给 DuckDB |
| [8] 预测记录 | `系统v7.5/预测记录.json` 读写、导出 CSV | 文件（未入库） | 行数少，JSON 足够；如需检索再入 SQLite |
| [9] 公告说明 | 静态文案，只显示功能状态 | 不需要库 | 无数据 |
| [10] 数字与生肖 | 生肖绑定常量 + INI 记忆 | **SQLite**（INI 镜像） | 配置类 |
| [11] 数字与五行 | 五行绑定常量 + INI 记忆 | **SQLite**（INI 镜像） | 配置类 |
| [12] 收藏 | `已保存预测.json` + `saved_predictions` 镜像 | **SQLite** | 收藏条目需跨启动保留 |
| [13] 数字排序 | 用户输入即时计算，不落库 | 不需要库 | 无持久化 |
| [14] 数字选尾 | 用户输入即时计算，不落库 | 不需要库 | 无持久化 |
| [15] 数据存储 | 文件本体 `系统v7.5/数据存储/` + `index.json`；索引镜像 `storage_items` | **SQLite（索引镜像）** | 图片/文档本体放磁盘，元数据入库便于恢复与检索 |
| [16] 大数据分析 | DuckDB 窗口取数 → `BigDataAnalyzer` 评分 | **DuckDB（已接入）** | 见「大数据分析为什么走 DuckDB」 |

> 补充：`系统v7.5/在线开奖.db` 为在线开奖抓取的独立 SQLite 库，与 `app_config.db` 分离；当前 `online_records` 366 行、`online_meta` 8 行，正常关闭时 `-wal` 常规为 0 字节。

### 其他功能（非选项卡）

| 功能 | 数据位置 | 归属 |
|---|---|---|
| 顶部工具栏 导入 / 导出 / 保存 | JSON 文件 + SQLite 镜像 | SQLite |
| 字体缩放、分隔符、列宽、分页等界面记忆 | `配置.ini` + `app_config.ui_ini` | SQLite |
| HTML 分析报告导出（`_on_export_report`） | `_analysis_records()` 取数后生成 HTML | **DuckDB（已接入）** |
| 数据概况（记录数 / 最新期号） | `func_state` | SQLite |
| 机器学习模型缓存 | `lib/ml_model.py` 模型文件 | 文件（与数据库无关） |

### 后续可选扩展（按需）

当前已完成「分析取数 DuckDB + 文件直读 + 存储索引镜像」，后续按需再做：

- 统计/回测真正下推成 SQL 聚合（当前仍在 Python 计算，SQL 只负责按窗口取数）；
- [8] 预测记录入库检索（行数增大时）；
- 存储图片生成缩略图缓存（当前只存元数据）。

## 配置文件位置
- 源码运行：`项目根目录/系统v7.5/配置.ini`
- PyInstaller 打包：`exe所在目录/系统v7.5/配置.ini`
- 数据库：`程序目录/系统v7.5/app_config.db`（SQLite）
- 删除 `配置.ini` 不会导致崩溃：先尝试从 SQLite 镜像恢复，再退回默认值

## 配置项清单（配置.ini）
### [General] 通用界面状态
| 键 | 含义 |
| --- | --- |
| window_width / window_height | 上次窗口宽高 |
| font_size_key | 全局字号档位（如 二号） |
| start_zodiac | 生肖轮转基准生肖 |
| is_dark_mode | 是否深色主题（与 [Display] 中同名键保持一致） |

### [Paths] 数据文件路径
| 键 | 含义 |
| --- | --- |
| data_file | 历史开奖数据 JSON 路径 |
| zodiac_file | 生肖绑定 JSON 路径 |
| last_prediction_file | 上次预测结果 JSON 路径 |

### [Zodiac] 号码-生肖绑定
- 键为号码 1-49，值为生肖名称；由「数字与生肖」选项卡维护，可切换基准生肖批量生成。

### [Elements] 号码-五行绑定
- 键为号码 1-49，值为五行（金木水火土）；由「数字与五行」选项卡维护。

### [NumberColors] 号码颜色分组（v0.0.28）
| 键 | 含义 |
| --- | --- |
| num_01 … num_49 | 单个号码的文字颜色（如 `#FF0000` / `#0000FF` / `#008000`） |
| red_numbers / blue_numbers / green_numbers | 红/蓝/绿三组的号码清单（逗号分隔），由 [4] 数字选择「颜色设置」标签页写入 |

- 应用规则：三组输入框留空的号码沿用 `num_xx` 原颜色自动补齐 1-49，应用后立即刷新全部页面，无需重启。

### [Weights] 算法权重（预留）
- 当前为空，权重调节结果暂存于界面控件；后续需要持久化时在此按算法名写入。

### [Display] 显示与运行参数
- 布局：history_page_size、ball_label_font_size、margin_top/bottom/left/right、spacing
- 运行开关：enhanced_mode（增强模式）、reverse_mode（反向模式）、deterministic_mode（确定性模式）、use_model_cache（模型缓存）
- 字体缩放：font_scale_table / result / list / number_panel / zodiac_panel / element_panel / announcement / detail
- 控件尺寸：number_panel_*、zodiac_panel_*、element_panel_*（默认 54×38、数字 16px / 文字 12px）、pred_ball_*、legend_*、detail_*
- 各选项卡状态：current_tab_index、prediction_algorithm_index、prediction_type、backtest_*、history_current_page
- 结果分隔符记忆：sort_sep_index / tail_sep_index（数字排序 / 数字选尾，0-14 对应 `RESULT_SEPARATORS` 的 15 项：空格/英文逗号/顿号/分号/减号/正斜杠/竖线/换行/中文逗号/中文句号/英文句号/加号/反斜杠/波浪号/井号）
- 计算规律/波色子页：calc_*、wave_* 系列参数与字号
- 数据存储：storage_sort_mode、storage_category、storage_tag_collapsed、storage_category_collapsed
- 列宽记忆：history_col_0~8、prediction_col_0~3
- 分栏记忆：*_splitter_sizes（数据导入、预测、历史记录、第七位预判、生肖、五行、统计分析图表、大数据分析上下/左右、数据存储）
- 窗口位置：window_x、window_y

## 配置开发规则
- ✅ 配置读写逻辑集中在框架/主窗口层，不侵入插件业务代码
- ✅ 插件禁止单独读取配置文件，统一经由主窗口或 lib 暴露的接口
- ✅ 新增配置项必须：写入默认值 → 在本文件登记 → 缺失时使用默认值且不崩溃
- ✅ 配置键名使用小写下划线命名，按功能归入对应 section
- ✅ 配置结构变更需保证旧 INI 可兼容读取（缺失键走默认值）

## 未来扩展规划（config.json，尚未实现）
### 窗口配置
- 窗口位置与尺寸记忆（当前已由 INI 的 window_x / window_y / window_width / window_height 实现）
- 界面主题配色自定义

### 插件配置
- 插件自定义显示顺序
- 插件启用/禁用黑名单（当前仅支持文件名前加下划线临时禁用）

### lib 算法配置
- 数据输出默认文件夹
- 模型缓存路径

### 数据库配置
- SQLite 数据库文件路径
- DuckDB 数据库文件路径

## 预留 config.json 模板（未启用，仅作扩展参考）
```json
{
    "window": {
        "width": 1600,
        "height": 1000
    },
    "plugins": {
        "sort": ["彩票预测"],
        "disable": []
    },
    "lib": {
        "output_path": "./output",
        "cache_path": "./cache"
    },
    "database": {
        "sqlite_path": "./系统v7.5/app_config.db",
        "duckdb_path": "./系统v7.5/analysis.duckdb"
    }
}
```

> 说明：启用 config.json 时须与现有 配置.ini 明确分工（建议 JSON 管结构化配置，INI 继续管界面状态），
> 并在迁移逻辑中保证旧用户配置不丢失。
