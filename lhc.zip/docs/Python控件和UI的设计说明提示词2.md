请生成一份完整独立单页HTML网页，网页标题：Python Flet 控件与UI开发完整手册；所有样式、JavaScript、文档内容全部内嵌在这一个HTML文件内，不引入任何外部资源、CDN、图片链接，保存到本地后直接用浏览器打开即可正常运行全部交互功能。
文档定位：零基础小白系统学习Flet的中文专业手册，同时作为开发查阅手册；讲解通俗易懂，不跳步骤、不省略前置知识，拒绝模糊简略表述；每一个知识点统一结构：概念通俗解释、适用场景、不适用场景、底层原理说明、参数明细（参数类型、默认值、可选枚举、入参约束）、交互事件清单、正向可运行示例代码（逐行中文注释）、❌反面错误示例代码 + 错误现象 + 报错根因 + ✅修复后的正确代码、高频踩坑清单、Flet版本兼容备注（区分0.22 / 0.23 / 0.24版本新增、改名、废弃API）。文档最高优先级重点：Dropdown、PopupMenuButton、Popover三大下拉与Overlay浮层组件；重点强化卡片UI体系：Card、ListTile、ExpansionPanel、ExpansionPanelList、GridView卡片网格、卡片hover动画、自定义Container卡片，卡片相关案例、正反坑、业务场景全部补齐。

【网页UI规范｜大厂产品级技术文档标准，严格执行，不可修改】
整体风格：对标 Ant Design / MUI 官方组件文档，干净专业、阅读优先；全局动画统一曲线 cubic-bezier(0.22, 1, 0.36, 1)，动画时长区间220–450ms，柔和不干扰阅读。
色彩系统（明暗两套自动适配）：
主色：#2563eb；成功辅助色：#10b981；警告色：#f59e0b；危险色：#ef4444；次要辅助色：#8b5cf6
浅色模式中性色：背景#ffffff、次级卡片背景#f8fafc、分割线#e2e8f0、次要说明文字#94a3b8、正文文字#64748b、标题文字#1e293b
暗色模式中性色：主背景#0f172a、卡片区块背景#1e293b、分割线#334155、次要文字#94a3b8、正文文字#cbd5e1、标题文字#f1f5f9
排版系统：
字体栈：Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, system-ui, sans-serif；代码字体：JetBrains Mono, Consolas, Monaco, monospace
字号阶梯：一级标题28px、二级标题22px、三级标题18px、正文15px、备注小字13px、代码字体14px
行高：标题行高1.25，正文行高1.6，代码块行高1.4
间距基准：固定4px，所有间距仅使用4的倍数：4/8/12/16/20/24/32/40/48px

✅【新增：控件画廊卡片预览示图规范】
控件画廊每一张卡片顶部内置纯CSS绘制预览示图（SVG/Div绘制，无外部图片），模拟Flet原生控件外观，明暗主题自动变色：
- 预览区域高度 110px，圆角 8px，柔和背景，细边框，浅阴影
- 每个控件独立手绘示意：
  Dropdown：输入框+向下箭头，展开后下拉选项列表示意
  PopupMenuButton：三点按钮 + 悬浮菜单面板
  Popover：触发按钮 + 带箭头浮层面板
  TextField：单行输入框、带hint占位文字
  Button：填充按钮/边框按钮样式
  Row/Column：横向、纵向方块排布示意
  Stack：多层重叠方块示意
  ListView：多条列表项+滚动条示意
  DataTable：表格行列示意
  AlertDialog：居中弹窗+遮罩示意
  Tooltip：悬浮气泡提示示意
  Card：Material卡片，圆角+阴影，内部文字示意
  ListTile：卡片内单行条目，左侧图标、标题、右侧更多按钮示意
  ExpansionPanel：折叠卡片，标题栏、展开后的内容区示意
  GridView：多列卡片网格布局示意
- 预览示图只做外观示意，静态展示，不需要交互；hover卡片时预览区域轻微放大提亮；
- 严格区分：【CSS预览示意图 = 外观示意】≠ 可运行demo；代码块才是可直接运行的Python代码。

响应式页面布局架构：
大屏 ≥1280px：三栏布局，左侧固定可折叠目录栏（宽260px），中间主阅读区，最大阅读宽度860px居中；右侧悬浮锚点导航栏，自动提取二级、三级标题快速跳转
中屏 768px ~1279px：两栏布局，左侧目录可点击收起，隐藏右侧锚点导航
移动端 ＜768px：左侧目录改为顶部汉堡抽屉弹窗，默认收起；隐藏右侧锚点；控件画廊网格自动降级单列；代码块自适应横向滚动
页面顶部Header（高度64px，固定置顶）：
左侧：简易Logo标识 + 文档主标题；中间：本地全文实时搜索框，输入即时过滤全文、关键词高亮、点击结果自动跳转对应章节、无匹配内容友好提示；右侧：亮色/暗色主题切换按钮、回到顶部快捷按钮
Header滚动效果：页面向下滚动超过80px时，增加半透明背景+柔和阴影、背景虚化；回到顶部恢复干净样式
全局滚动行为：页面顶部全局滚动进度条；所有锚点跳转平滑滚动；滚动监听自动同步：左侧目录高亮当前阅读章节、右侧锚点同步高亮对应小标题；
文档内置区块组件规范：
1. 普通内容卡片：圆角12px，内边距20px，外边距16px；hover轻微抬升+阴影加深
2. 四种提示提醒块（Info / Warning / Error / Success）：左侧彩色竖标识线，内边距16px；Info蓝色、Warning黄色、Error红色、Success绿色；重点标记【新手重点】【禁止踩坑】放在提示块内
3. 代码块：圆角10px，内边距16px，语法高亮区分关键字、注释、字符串；右上角常驻复制按钮，hover微动；复制成功右下角弹出Toast提示；超长代码横向滚动；代码块左上角标签区分【✅正确示例】【❌错误示例】
4. 控件画廊卡片网格：卡片圆角14px；顶部是CSS绘制预览示图区，下面是组件名称、简短描述、分类标签；hover上浮、阴影放大、边框主色高亮；点击卡片展开折叠面板，展示完整参数与案例
5. 数据表格：表头底色区分、隔行底色柔和区分、单元格内边距12px；暗色主题自动适配样式，边框柔和；专门制作组件选型对比表
交互与动画规范：
1. 全局滚动进度条、平滑锚点跳转、主题切换全局颜色过渡动画
2. 内容区块进入视口动画：淡入 + Y轴轻微上移；离开视口无反向动画
3. 左侧侧边栏抽屉展开收起弹性动画、遮罩淡入淡出；目录子项依次延迟入场；当前激活目录项背景缓慢呼吸动画
4. 文档内所有折叠面板（参数列表、案例面板）：高度平滑过渡展开收起，箭头同步旋转
5. 所有可点击元素：hover态、active按压缩小反馈、键盘focus焦点环（满足WCAG无障碍）；按钮内置点击波纹反馈；图标按钮hover底色变化
6. 预览弹窗：淡入+缩放弹出动画，ESC按键、点击蒙层关闭，关闭反向退场动画
7. Toast消息：右下角滑入滑出，3秒自动消失，支持手动关闭；用于复制成功、提示信息
8. 搜索匹配高亮：搜索命中文字底色高亮
无障碍规范：所有交互元素添加aria标签、键盘Tab可遍历、焦点可见、文字对比度符合WCAG标准

【文档正文完整目录与内容细则，严格按顺序编写，全部极致细化，不得缺项；卡片相关内容全部扩充增强】
1. 开篇：推荐学习顺序 + Flet版本提醒
    1.1 阅读顺序指引，新手禁止跳读说明
    1.2 Flet版本说明：本文档适配稳定版，明确0.22 / 0.23 / 0.24版本新增、改名、废弃API；说明旧代码报错根源
    1.3 环境安装命令、pip换源安装、安装校验命令
    1.4 运行第一个Flet程序，最小demo逐行讲解
2. 前言：Flet快速入门 + 基础名词词典（通俗化）
    2.1 核心概念：控件、父容器、子控件、page页面、控件实例、属性、事件、布局约束、坐标系、重绘刷新、state状态
    2.2 区分page根对象 和 普通控件的本质差别，重点标注新手极易混淆
    2.3 Flet程序完整生命周期：初始化 → 创建控件 → 添加到页面 → 事件触发 → 更新重绘 → 页面关闭
    2.4 最简基础模板详解，每个参数作用说明
    2.5 窗口基础配置：窗口标题、宽高、是否可缩放、置顶、关闭事件on_close；附带关闭前弹窗确认、保存数据场景示例
3. Flet通用语法、统一书写规范（独立重点章节）
    3.1 创建控件两种写法：行内直接创建、先定义变量再add；优缺点对比、适用场景
    3.2 控件命名规范、Python缩进、逗号规范、枚举常量使用规则，解释禁止手写字符串枚举值的原因
    3.3 样式复用方案：TextStyle、ButtonStyle统一封装，全局样式对象复用示例
    3.4 颜色全部写法：颜色名称、十六进制、rgb、rgba透明色示例
    3.5 控件动态修改（新手最高频难点）
        3.5.1 核心公式：控件实例.属性 = 新值
        3.5.2 区分：自动刷新控件、必须调用update()才会刷新的控件
        3.5.3 两种update：控件.update()（局部刷新，推荐）、page.update()（全局刷新，慎用）
        3.5.4 ❌反面案例：滥用page.update()导致输入框光标丢失、页面闪烁、输入卡顿；现象、原理、修复方案
        3.5.5 事件回调内修改控件完整注释示例；批量循环修改控件示例
    3.6 控件添加、删除、清空
        page.controls.append() / insert() / remove() / clear() 全部示例；删除控件后内存注意事项
    3.7 事件传参、循环lambda经典捕获变量坑（重中之重）
        3.7.1 错误写法、现象、原理
        3.7.2 两种可靠修复方案：lambda默认参数捕获、functools.partial，两套完整可运行代码
        3.7.3 批量生成按钮、下拉选项、批量生成卡片场景实战
    3.8 控件焦点控制：自动聚焦、代码触发焦点、失去焦点示例
4. 第1部分：Flet全套原生控件画廊（全部控件独立卡片，信息完整，卡片顶部带CSS预览示图；Card、ListTile、ExpansionPanel、ExpansionPanelList重点扩充）
    控件卡片统一结构：①【CSS预览示图区】②控件名称 ③简介、适用场景、不适合场景 ④基础骨架代码 ⑤完整可运行注释示例 ⑥折叠面板：全部属性清单（类型、默认值、说明）、事件清单、支持动画属性 ⑦布局搭配建议、注意事项、踩坑点
    控件分类清单：
    📦布局容器类
    Row、Column、Stack、Wrap、GridView、ListView、Container、Card、ExpansionPanel、ExpansionPanelList、SafeArea、GestureDetector、VerticalDivider、Divider、ResponsiveRow、Padding、Align、Center、AspectRatio、ConstrainedBox、ClipRRect、AnimatedSwitcher
    ✅【重点扩充卡片UI专项】
    ✅Card（原生Material卡片）
        概念说明：Flet官方Material卡片控件，自带elevation阴影、圆角；仅支持单个child，多内容嵌套Column/Row
        参数全表：content、margin、elevation、surface_tint_color、color、shadow_color
        基础示例：基础信息卡片
        进阶示例1：Card + ListTile 信息条目卡片（头像+标题+副标题+右侧操作按钮）
        进阶示例2：卡片hover抬升动画（AnimatedContainer或者animate属性，鼠标悬浮提高阴影、向上偏移）
        进阶示例3：禁用卡片、自定义卡片底色
        ❌反面案例合集：
        案例1：直接塞多个控件到Card，忘记套Column，布局错乱；现象、原因、修复
        案例2：elevation设置过大，阴影过重不协调；规范建议值区间
        案例3：Card内图片圆角不生效，忘记嵌套ClipRRect；修复方案
        踩坑清单、版本备注
    ✅ListTile（卡片内单行条目组件）
        概念：专门用于卡片/列表里的一行，内置leading头部、title标题、subtitle副标题、trailing尾部操作
        参数：leading、title、subtitle、trailing、on_click、selected、dense
        示例：可点击ListTile、带图标、带开关、带右侧三点菜单
        搭配Card、ListView使用实战
        ❌错误案例：布局挤压、文字溢出、点击区域异常
    ✅ExpansionPanel + ExpansionPanelList（可折叠展开卡片）
        概念：折叠卡片面板组，点击标题展开收起内容，常用于设置面板、详情面板
        参数清单：ExpansionPanel(header、content、expanded、can_tap_header)；ExpansionPanelList控件
        示例：单折叠卡片、多组互斥折叠卡片（打开一个自动关闭其他）
        ❌反面案例：多面板同时展开、状态不同步、expanded修改后不刷新
    ✅GridView网格布局（卡片网格核心容器）
        概念：多列网格，批量渲染卡片列表，自动换行，做商品卡片、功能卡片墙首选
        参数：runs_count、max_extent、spacing、run_spacing、padding
        基础示例：固定列数卡片网格
        响应式示例：max_extent自适应列数，大屏多列、移动端自动变成单列卡片
        进阶：循环批量生成Card卡片放入GridView（循环+lambda避坑完整代码）
        ❌反面案例：卡片尺寸挤压、间距错乱、大量卡片卡顿（对比ListView）
    ✅专项补充：Container.border_radius 和 ClipRRect 的圆角区别、图片圆角踩坑；Container自制自定义卡片（不用Card，完全自定义阴影、边框、渐变卡片），示例：渐变卡片、边框卡片、悬浮动画卡片
    🧭导航类
    AppBar、NavigationBar、NavigationRail、Tabs、Tab、View、Drawer、BottomAppBar
    ℹ️信息展示类
    Text、RichText、Image、CircleAvatar、Icon、ProgressBar、ProgressRing、Tooltip、Badge、Markdown、DataTable、DataColumn、DataRow、ListTile
    🔘按钮类
    ElevatedButton、TextButton、OutlinedButton、IconButton、FloatingActionButton、SpeedDial、SpeedDialChild、MenuButton、SubmenuButton
    📝输入选择类
    TextField、Dropdown、Option、Checkbox、Switch、Radio、RadioGroup、Slider、RangeSlider、DatePicker、TimePicker、ColorPicker、FilePicker
    🪟弹窗浮层Overlay类
    AlertDialog、BottomSheet、Popover、PopupMenuButton、PopupMenuItem、SnackBar、Banner、FullScreenDialog、Dismissible
    📊图表类
    LineChart、BarChart、PieChart、ScatterChart
    ✨动画组件
    Animation、Transform
    🛠️工具杂项
    WebView、Audio、Video、Canvas、Shapes、Clipboard、Focus、Draggable、DragTarget
5. 第2部分：Flet UI设计规范 + 资源路径说明
    5.1 Flet程序内统一间距、字号、配色设计规范（区分承载文档的网页UI）；卡片UI设计规范：卡片margin外边距、内部padding、推荐elevation档位、圆角推荐值、hover动画参数标准
    5.2 Flet单位说明：全部为px，DPI适配说明
    5.3 本地静态资源（图片、音频）路径：Windows写法、Mac/Linux写法、相对路径、绝对路径
    5.4 资源找不到报错排查步骤、打包exe后资源路径坑、完整解决方案
6. 第3部分：控件定位、布局、动态移动（重点章节，附带文字图解）
    6.1 Flet坐标系文字图解描述：页面左上角原点，X向右、Y向下
    6.2 Row主轴、交叉轴对齐，MainAxisAlignment、CrossAxisAlignment全部枚举示例；space_between / space_around / space_evenly效果说明
    6.3 Column对齐用法，和Row区别
    6.4 Stack层叠布局专项
        left / top / right / bottom 定位；offset偏移定位；z-index层级控制
        ❌高频大坑：Stack不设置宽高，子控件定位失效；错误示例、修复方案
    6.5 Container margin外边距、padding内边距文字图解，直观区分内外边距（卡片开发高频，卡片外边距margin、内部内边距padding）
    6.6 Wrap流式自动换行布局，对比GridView卡片网格适用场景
    6.7 GridView网格布局、间距、行列设置，卡片墙实战
    6.8 ListView长列表性能优化：item_extent、预渲染，上万条数据场景方案；解释为什么不要用Column放大量卡片数据
    6.9 尺寸约束：min_width、max_width、min_height、max_height、expand填充规则；卡片固定宽度、卡片最大宽度限制场景示例；expand和max_width冲突场景示例
    6.10 动态移动控件原理：修改offset / left / top属性 + animate_*动画属性
        瞬时移动示例、带动画平滑移动示例、跟随鼠标移动示例、拖拽Draggable拖拽移动卡片示例
    6.11 内容溢出四种处理方案：滚动、截断文字、折叠、分页；卡片内部文字溢出处理
    6.12 布局选型决策树（文字流程图描述）：
        横向排列选Row、纵向排列选Column、少量静态内容；大量纵向卡片列表用ListView；卡片网格墙选GridView；自动少量换行Wrap；需要叠加悬浮控件Stack；需要折叠详情选ExpansionPanelList
7. 第4部分：手势、交互、动画系统
    7.1 GestureDetector手势：on_tap单击、on_double_tap双击、on_long_press长按、on_hover悬浮进入离开；卡片hover变色、抬升完整示例
    7.2 TextField输入实时事件on_change、on_submit回车提交；字数统计、输入过滤示例
    7.3 全局通用animate_xxx动画属性：animate_opacity、animate_scale、animate_rotation、animate_offset；卡片悬浮动画全套参数示例
    7.4 AnimatedSwitcher切换动画，页面/卡片替换过渡效果
    7.5 ExpansionPanel折叠动画
    7.6 SnackBar轻提示、Banner横幅提示使用示例；卡片点击弹出提示
    7.7 ProgressBar / ProgressRing加载动画；卡片内加载状态
8. 第4.5小节：页面栈路由 page.views（View页面导航，页面级路由，和浮层严格区分）
    8.1 page.views原理：是列表，后进先出，浏览器/APP返回键自动绑定pop
    8.2 基础操作：
        Push入栈打开新页面：page.views.append(View(...))
        Pop返回上一页：page.views.pop()
        替换当前页面：page.views[-1] = View(...)
        清空栈回到首页：page.views.clear() + append首页View
    8.3 on_view_pop拦截返回事件：拦截返回、弹窗确认、保存卡片表单数据再退出
    8.4 View页面切换动画配置
    8.5 页面之间传参：全局变量、封装状态对象两种方案；正反示例；卡片数据跨页面传递示例
    8.6 踩坑清单：忘记调用page.update、重复push相同页面造成返回栈冗余、页面销毁后卡片控件引用失效
    8.7 对比区分（反复强化）
        page.controls = 直接替换内容：无返回历史、不能返回；
        page.views页面栈：有历史、支持返回；
        Overlay浮层（Dropdown/Popover/Dialog）：悬浮在当前页面上方，不切换页面、不入栈
9. 第4.6小节：Overlay浮层专项｜下拉组件极致深度详解（最高优先级重点）
    9.6.1 Overlay底层原理：所有浮层挂载在page.overlay，脱离普通controls布局流，永远置顶渲染；渲染层级优先级从低到高固定顺序：
普通页面内容 < Drawer侧边抽屉 / BottomSheet底部面板 < Dropdown表单下拉 < PopupMenuButton操作菜单 < Popover自定义浮层面板 < AlertDialog强遮罩弹窗
    9.6.2 五大浮层组件完整拆解，三大下拉组件做到业务全覆盖，每个组件包含：概念、参数全表、基础示例、进阶业务示例、错误反面案例、踩坑清单、边界避让说明
    ---
    ① Tooltip悬浮提示
    用途、参数、自定义文字、延迟显示；明确不承载点击操作，仅文字提示；卡片内Tooltip示例
    ---
    ② Dropdown【表单选择下拉框｜极致详细】
    ✅基础说明：表单原生选择器，自带输入框载体、选中值回显、label标签、hint占位提示；单选专用
    ✅全部参数明细：label、hint_text、value、options、disabled、width、max_width、alignment、border、text_style、color、bgcolor、on_change、on_focus、on_blur
    ✅基础示例：普通单选下拉，读取选中值，on_change回调
    ✅进阶场景全部补齐：
    场景1：禁用状态下拉
    场景2：限制max_width，防止下拉撑开页面布局
    场景3：【级联联动下拉】一级下拉选中，动态刷新二级下拉选项（省市联动经典案例，完整可运行代码）
    场景4：分组下拉选项（Option分组标题，不可选中分组头）
    场景5：选项带Icon图标自定义Option渲染
    场景6：可搜索筛选Dropdown（TextField+Popover+ListView封装搜索下拉，原生Dropdown无搜索，给出封装完整代码）
    ✅原生边界避让机制：Dropdown自动检测视口剩余空间；下方空间不足自动翻转向上弹出面板；面板内容过长自带滚动条
    ✅❌反面错误案例合集：
    案例1：不设置max_width，长选项撑爆页面布局；现象、原因、修复
    案例2：on_change重复触发、无限递归刷新；现象、原因、防抖修复方案
    案例3：Dropdown被上层Popover/Dialog遮挡（层级冲突）；原理、规避方案
    案例4：动态修改options后界面不刷新；忘记控件update()
    ✅踩坑清单、版本差异备注
    ---
    ③ PopupMenuButton【三点操作菜单｜命令下拉菜单】
    ✅基础说明：按钮触发，无选中回显，用于操作命令：新增、编辑、删除、复制；适合AppBar、列表卡片行更多按钮、右键菜单
    ✅参数明细：items、icon、icon_size、menu_position、on_open、on_close、tooltip
    ✅基础示例：编辑/删除菜单
    ✅进阶场景：卡片列表行右键菜单（GestureDetector+PopupMenuButton）
    ✅菜单项PopupMenuItem参数：text、icon、on_click、disabled
    ✅交互规则：点击菜单项默认自动关闭菜单，演示如何配置点击后不关闭菜单
    ✅❌反面案例：菜单超出屏幕边界、菜单和Dropdown层级冲突、多次重复打开菜单
    ✅边界避让说明、适配方案
    ---
    ④ Popover【万能自定义浮层面板｜自定义下拉容器】
    ✅基础说明：无内置UI，自由放入任意控件（TextField、ListView、Grid、表单、小卡片）；用来造任意自定义下拉、筛选面板、组合弹窗
    ✅核心参数：target（绑定触发控件）、content、anchor、offset、open、on_open、on_close、enable_arrow（箭头指示器）、arrow_color、max_width、max_height、dismiss_on_click_outside（点击外部关闭开关）、dismiss_on_click_inside（点击内部是否关闭开关）
    ✅四种定位模式完整代码模板：
    模式1：跟随目标控件（最常用，做自定义下拉）
    模式2：跟随鼠标坐标（右键面板）
    模式3：屏幕居中
    模式4：自定义XY绝对坐标
    ✅进阶场景：
    场景1：带箭头的自定义筛选下拉面板
    场景2：Popover嵌套Popover多级子菜单（嵌套限制、避坑）
    场景3：面板内部放卡片表单，输入时点击面板内不关闭Popover（关闭开关配置）
    场景4：长内容Popover，设置max_height自带滚动ListView
    ✅边界避让：原生Popover不会自动翻转，手动判断视口位置、动态切换anchor方向完整代码
    ✅❌反面案例：
    案例1：不设置max_width，内容无限撑开溢出屏幕
    案例2：点击Popover内部输入框直接关闭面板（dismiss_on_click_inside配置错误）
    案例3：多层Popover嵌套导致事件冒泡错乱
    ✅踩坑清单
    ---
    ⑤ AlertDialog强遮罩弹窗
    带遮罩、阻断下层交互，强确认场景；参数、确认取消回调、弹窗内放卡片表单示例；点击遮罩关闭开关
    ---
    9.6.3 五大浮层选型对比大表格（Tooltip / Dropdown / PopupMenuButton / Popover / AlertDialog）
    对比维度：用途、是否回显选中值、是否自带样式、是否带遮罩、默认关闭规则、层级、最佳适用场景
    9.6.4 浮层调试手段：打印坐标、临时边框标记浮层范围、视口判断
    9.6.5 浮层通用排查清单：溢出、错位、遮挡、点击外部关不掉、重复打开
10. 第5部分：全维度调试排错手册（按排查优先级排序；增加卡片专属排错项）
    10.1 第一步排查：控件有没有执行add加入页面
    10.2 第二步排查：是否保存控件实例变量（匿名创建卡片无法修改、动态更新）
    10.3 第三步：visible、disabled、opacity属性状态（卡片隐藏、禁用）
    10.4 第四步：尺寸约束、宽高是否为0、容器挤压卡片，卡片被压缩看不见
    10.5 第五步：刷新问题：局部update / page.update滥用；动态新增卡片后不刷新
    10.6 第六步：动画animate参数配置错误；卡片hover动画不生效
    10.7 第七步：资源路径、图片音频加载失败；卡片内图片不显示
    10.8 第八步：页面栈view相关报错；跨页面传递卡片数据异常
    10.9 第九步：Overlay浮层&下拉专项排查：溢出、层级遮挡、定位错位、关闭异常、下拉选项刷新失效；卡片上弹出菜单被遮挡
    10.10 控制台报错解读，高频报错翻译、原因、修复思路
    10.11 异步阻塞问题：耗时循环、文件读写、网络请求卡住界面；page.run_async后台任务示例；异步加载卡片列表
11. 第6部分：阶梯仿写实战练习（由易到难，每个练习：目标、需求、完整注释代码、运行效果说明、拓展仿写任务、排错提示；新增大量卡片UI练习）
    练习1：基础窗口+文本展示
    练习2：按钮点击修改文本、切换禁用状态
    练习3：Row多按钮布局、统一ButtonStyle样式复用
    练习4：Stack+带动画移动控件
    练习5：AlertDialog确认弹窗
    练习6：GridView卡片网格布局（功能卡片墙，循环生成Card卡片）
    练习7：DataTable表格、动态增删行
    练习8：表单综合：TextField输入、字数统计、回车提交
    练习9：动画切换AnimatedSwitcher
    练习10：page.views页面跳转、返回传参
    练习11：Overlay下拉专项练习（4个子练习）
        练习11-1：Dropdown基础单选 + hint提示 + on_change取值；测试底部自动向上翻转
        练习11-2：级联联动Dropdown（省市二级联动）
        练习11-3：PopupMenuButton三点操作菜单（编辑复制删除）
        练习11-4：Popover自定义搜索下拉面板（带输入框筛选列表）
    练习12：卡片UI综合练习
        练习12-1：基础Card卡片 + ListTile信息卡片
        练习12-2：可折叠ExpansionPanel卡片组（多面板互斥展开）
        练习12-3：卡片hover抬升动画（GestureDetector+animate）
        练习12-4：卡片列表（ListView放Card卡片，每一行卡片带右侧PopupMenuButton菜单）
    练习13：综合实战：完整筛选表单页面（TextField + 级联Dropdown + Popover高级筛选面板 + GridView卡片结果墙 + 底部提交按钮）
12. 第7部分：选型对比 & 新手高频误区汇总（新增卡片选型对比）
    12.1 Flet / PyQt / Tkinter / Streamlit 对比表格，各自优势、适合项目
    12.2 卡片UI选型对比：原生Card vs Container自制卡片 vs ExpansionPanel折叠卡片；什么时候用GridView、什么时候用ListView放卡片
    12.3 高频误区汇总
    - 不保存控件变量，后面无法修改卡片
    - Card直接放多个子控件，忘记套Column
    - Stack不设置宽高定位失效
    - Column放上万条卡片数据卡顿，不用ListView
    - lambda循环捕获变量经典错误（批量生成卡片最容易踩坑）
    - 疯狂page.update()全局刷新，光标丢失、输入卡顿
    - 混淆page.controls替换 和 page.views页面栈
    - 混淆Dropdown、PopupMenu、Popover，业务场景选错组件
    - 浮层层级搞反，下拉菜单被卡片盖住
    - 打包exe之后资源路径失效，卡片图片空白
    - 卡片margin/padding分不清，布局间距混乱
13. 第8部分：进阶拓展专题
    代码模块化拆分（把页面、卡片组件封装成函数/类，大型项目结构）、SplitView左右分栏、Skeleton骨架加载（卡片骨架占位）、水印绘制、表单校验、本地JSON数据持久化、音视频播放、Canvas绘图、拖拽Draggable拖拽排序卡片、全局快捷键监听、打包exe（pyinstaller）命令、打包图标、打包后资源处理方案
14. 附录速查表（方便快速查阅；新增卡片控件速查）
    14.1 基础名词速查
    14.2 全部控件属性、动画属性速查（Card、ExpansionPanel、ListTile、GridView）
    14.3 事件on_xxx清单速查
    14.4 对齐、方向、动画曲线枚举常量速查
    14.5 page.views页面栈API速查表
    14.6 Overlay五大浮层+三类下拉组件速查表：参数、定位、关闭逻辑、适用场景
    14.7 卡片UI速查表：Card / Container卡片 / ExpansionPanel / GridView / ListView适用场景、推荐参数

【强制约束，必须遵守，不可违背】
1. 所有Flet代码必须是完整可运行代码，导入flet as ft齐全，禁止片段残缺；注释为中文，通俗易懂
2. 正反案例成对出现，❌错误案例写明现象、出错原理，紧跟✅修复后的正确代码；卡片相关正反案例完整齐全
3. 所有图解只用精准文字描述，控件画廊卡片预览示图除外（预览示图使用内嵌CSS Div绘制），不引入外部图片，读者仅凭文字就能脑补布局/坐标系/层级关系
4. 严格区分【承载文档的网页UI样式】和【Flet程序内的UI代码】，绝不混淆
5. 全文用词统一，术语前后一致；重点内容放入提示块，【新手重点】【禁止踩坑】醒目标记
6. 生成完成后的HTML，所有交互功能必须正常工作：搜索、主题切换、目录折叠、锚点跳转、代码复制、Toast提示、折叠面板动画全部可用；CSS预览示图明暗模式自动适配
7. 下拉、浮层、卡片UI全部需求完整落地，无遗漏、无简化
