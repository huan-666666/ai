# -*- coding: utf-8 -*-
"""
plugins 包 - GUI界面层（主窗口）

约束：
    - 禁止直接 from PyQt6 import xxx，统一 from UI import *
    - 禁止直接 import numpy/pandas/torch/duckdb/sqlite3 等库，只调用 lib 导出函数
    - 彩票预测.py 是 run.py 直接创建的主窗口，标签页内容在 TAB/*.py
"""
