# -*- coding: utf-8 -*-
"""
===========================================================================
plugins/彩票预测.py - 彩票预测系统主窗口（GUI界面层）
===========================================================================
功能说明：
    香港六合彩（Mark Six）预测与分析平台：数据导入、格式转换、
    12+种预测算法调用、第七位预判、统计分析图表等。

架构约束（必须遵守）：
    - Qt控件统一 `from UI import *`，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/torch/matplotlib 等重型库，
      算法、数据、绘图、数据库逻辑全部调用 lib 封装函数
    - 本文件是 run.py 直接创建的主窗口，标签页内容在 TAB/*.py
===========================================================================
"""

import sys  # 作用说明：与解释器交互，取平台/异常钩子信息，并在调试入口写标准错误流
import os  # 作用说明：拼数据目录与文件路径、建目录、判断文件是否存在、原子替换落盘
import json  # 作用说明：读写彩票数据/预测缓存/配置镜像等 JSON 文件与数据库 state_json
import csv  # 作用说明：批量导入导出历史开奖数据时按行拼接与解析 CSV
import datetime  # 作用说明：生成数据状态时间戳、写入预测记录与报告的时间字段
import logging  # 作用说明：写盘重试失败时记录 WARNING 日志（含目标路径与异常类型）
import copy  # 作用说明：深拷贝 LotteryConfig 的五行绑定默认值，避免共享可变字典
import warnings  # 作用说明：屏蔽第三方库的 FutureWarning/DeprecationWarning，保持控制台干净

warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)

# Qt控件：统一从UI/UI.py导入（全局唯一导入中心，禁止直接from PyQt6 import）
from UI import *  # 作用说明：星号导入界面层唯一导出中心，提供 QMainWindow/QWidget/QPushButton 等全部 Qt 控件与枚举

# 算法与数据逻辑：全部经由 lib 封装层获取
from lib.data_process import (  # 作用说明：从数据处理层取全局配置、数据工具与期号取值三类纯逻辑
    LotteryConfig,      # 全局配置与常量
    DataUtils,          # 数据工具
    get_latest_period,  # 最新期号取值（跨页纯逻辑，原主窗口方法已下沉）
)
from lib.db_helper import get_db  # 双嵌入式数据库单例（SQLite + DuckDB）
from lib.algorithms import run_algorithm  # 算法注册表：编号→计算方法的唯一定义来源
from lib.ml_model import MLPredictionModel  # JSON 序列化默认处理器（全项目唯一实现）
from lib.report_builder import write_algorithm_reports  # 批量导出报告的 HTML 生成

# --- 选项卡页面：自动发现（TAB/*.py 声明 TAB_INFO 即可被加载）---
from TAB import iter_tab_pages  # 作用说明：按 TAB_INFO 的 order 惰性遍历并导入全部选项卡页面模块

# --- 选项卡共享UI组件 ---
from TAB.widgets import FontUtils, spin_style_qss  # 作用说明：按字号档位创建跨平台可用字体的共享工具；spin_style_qss 提供全项目统一的数字框样式（内边距/高度/箭头定位）

# --- 选项卡页面实现函数：主窗口直接调用（已移除主窗口转发壳子）---
from TAB import data_storage as _tab_data_storage  # 作用说明：数据存储页的页面构建与配置应用函数（含拖放事件实现）
from TAB import bigdata_analysis as _tab_bigdata  # 作用说明：大数据分析页的构建与「运行/复制/导出」入口
from TAB import backtest as _tab_backtest  # 作用说明：回测分析页的「回测/对比/命中率趋势」入口
from TAB import element as _tab_element  # 作用说明：五行绑定页的页面构建与统计刷新函数
from TAB import history as _tab_history  # 作用说明：历史记录页的表格刷新、导入导出与期号详情
from TAB import info as _tab_info  # 作用说明：信息/公告页的构建与公告字号更新
from TAB import prediction as _tab_prediction  # 作用说明：预测与抽取页的算法调度、缓存读写、七策略渲染与各类面板配置
from TAB import prediction_history as _tab_prediction_history  # 作用说明：预测记录页的加载、落盘与表格刷新
from TAB import number_attributes as _tab_attr  # 作用说明：三页合并后的「号码属性表」页（矩阵 + 五行分布 + 选中详情 + 两个弹窗）


# 主窗口类 LotteryPredictionWindow 由 run.py 直接导入并实例化

# 合并版里四个旧分区都落到同一块矩阵面板；每个分区的缩放键再拆成
# 「文字」「号码」两个维度，互不影响（共 4 区域 × 2 = 8 个键）。
_MATRIX_SCALE_AREAS = ('number_panel', 'zodiac_panel', 'element_panel', 'attr_panel')


def _pt_to_px_96(point_size):
    """功能：把历史 point 口径字号换算成 96dpi 下视觉等价的 pixel 字号

    说明：Qt 在 96dpi 下 1pt=96/72px，原 setPointSize(n) 的实际像素高度约为
          n*4/3；直接改成 setPixelSize(n) 会让字体缩小约 25%。这里按 4/3 换算，
          保证换 API 前后字体度量（QFontMetrics.height/宽度）不变。
    参数：point_size (int|float) point 字号。
    返回：int 像素字号（最小 1）。
    """
    return max(1, int(round(float(point_size) * 96.0 / 72.0)))


class _DisplayDrawer(QFrame):
    """字号抽屉浮层容器（Qt.Popup 无边框窗口）

    说明:
        只承载布局，不实现业务；hideEvent 统一通知主窗口把「显示设置」
        入口按钮取消勾选，避免点击浮层外部关闭后按钮仍停留在展开态。
    """

    def __init__(self, parent, on_hide=None):
        super().__init__(parent, Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self._on_hide = on_hide

    def hideEvent(self, event):
        try:
            if self._on_hide is not None:
                self._on_hide()
        except Exception:
            pass
        super().hideEvent(event)


class LotteryPredictionWindow(QMainWindow):
    """功能：彩票预测系统主窗口"""

    # [全局配置] 初始化、变量定义、默认值（窗口设置、数据路径、面板尺寸、字体配置、预测模式）

    def __init__(self):
        """功能：初始化主窗口（数据目录/数据库/绑定/配置/UI/缓存/写盘闸门）
        注意：会创建 系统v7.5 目录、初始化双数据库、读取 INI、加载数据与预测缓存，
              属于重副作用构造；全程处于「只读不写」窗口（_ini_write_enabled=False），
              末尾才打开写盘闸门，并对首帧 resizeEvent 做豁免（_geometry_tracking）。
        参数:
            无
        返回:
            无（构造函数）
        """
        super().__init__()
        # 窗口状态标志
        self._window_closing = False  # 窗口关闭标志，防止信号处理函数访问已销毁的控件
        # INI 写盘闸门（启动只读不写）
        # _ini_write_enabled：启动阶段为 False，所有 _save_ini_config() 调用都被拦截，
        #   只读 INI 与写内存，不碰磁盘；构造流程末尾才置 True。
        # _ini_dirty：是否发生过「真正的用户改动」。关闭窗口时只有它为 True 才落盘，
        #   避免每次启动→关闭都把文件重写一遍（重写会把界面自动算出的分隔条/列宽
        #   覆盖回 INI，导致哈希无意义变化）。
        # _geometry_tracking：是否开始记录窗口移动/缩放。它在 show() 处理完首帧
        #   尺寸事件后才打开，防止启动时的布局事件被当成用户改动。
        self._ini_write_enabled = False
        self._ini_dirty = False
        self._geometry_tracking = False
        # 选项卡拖动顺序记忆：重排期间禁止保存；_ini_start_tab_title 用于顺序变化后按标题找回上次停留页
        self._restoring_tab_order = False
        self._ini_start_tab_title = ''
        # 窗口基本设置
        self.setWindowTitle(LotteryConfig.WINDOW_TITLE)  # 窗口标题（来自配置类）
        self.setMinimumSize(LotteryConfig.WINDOW_MIN_WIDTH, LotteryConfig.WINDOW_MIN_HEIGHT)  # 最小窗口尺寸
        self.resize(1600, 1000)  # 【可改】初始窗口大小（宽×高）
        self.font_size_key = LotteryConfig.DEFAULT_FONT_SIZE_KEY  # 全局字体大小配置键
        
        # 数据相关
        self.historical_data = []       # 历史开奖数据列表
        self._data_degraded = False     # 数据降级模式：JSON 损坏时置真，禁止以空列表覆盖数据库镜像
        self._data_fingerprint_at_last_predict = None  # 上次算法预测时的数据指纹
        self._data_fingerprint_at_last_ml_predict = None  # 上次机器学习预测时的数据指纹
        self.current_algorithm_index = 0  # 当前选中的算法索引
        self.collected_predictions = []  # 收集的预测结果列表
        self.prediction_history = []    # 预测历史记录
        self.custom_weights = {}        # 自定义权重
        
        # 显示模式
        self.is_dark_mode = False  # 【可改】是否深色模式（顶部「切换主题」可开关，状态记忆在 INI [General]）
        
        # 布局边距和间距
        self.margin_top = 10     # 【可改】顶部边距
        self.margin_bottom = 10  # 【可改】底部边距
        self.margin_left = 10    # 【可改】左边距
        self.margin_right = 10   # 【可改】右边距
        self.spacing = 10        # 【可改】元素间距
        
        # 数据文件路径（统一放在程序目录/系统v7.5 下，exe打包后随程序目录走）
        # 【可改】数据目录名，所有数据文件、数据库、配置均集中在此目录
        self._app_dir = self._get_app_dir()                 # 程序基准目录
        self._data_dir = os.path.join(self._app_dir, "系统v7.5")  # 统一数据目录
        self._migrate_legacy_data()                         # 旧版数据目录自动迁移
        self.data_file = os.path.join(self._data_dir, "彩票数据.json")            # 历史开奖数据
        self.zodiac_file = os.path.join(self._data_dir, "生肖绑定.json")           # 生肖绑定数据
        self.last_prediction_file = os.path.join(self._data_dir, "上次预测.json")  # 上次预测结果
        self.saved_predictions_file = os.path.join(self._data_dir, "已保存预测.json")  # 已保存的预测
        self.prediction_history_file = os.path.join(self._data_dir, "预测记录.json")   # 预测记录持久化
        self.config_file = os.path.join(self._data_dir, "配置.ini")               # 配置文件
        self._ml_data_dir = self._data_dir                                        # 模型和数据存储目录
        # 确保统一数据目录存在（首次运行或exe打包后自动创建）
        try:
            os.makedirs(self._data_dir, exist_ok=True)
        except Exception as e:
            print("创建数据目录失败: " + str(e))

        # 双嵌入式数据库（SQLite业务库 + DuckDB分析库）
        self._db = None                # 数据库单例（初始化失败时降级为纯文件模式）
        try:
            self._db = get_db()
        except Exception as e:
            print("数据库初始化失败（已降级为纯文件模式）: " + str(e))
        
        # 生肖五行绑定
        self.zodiac_binding = LotteryConfig.generate_zodiac_binding("龙")  # 生肖-号码绑定
        self.zodiac_elements = copy.deepcopy(LotteryConfig.NUMBER_ELEMENTS)  # 五行-号码绑定
        
        # 性能优化：分页
        self.history_page = 1           # 当前历史记录页码
        self.history_page_size = 100    # 【可改】每页显示的历史记录数量
        
        # 字体大小配置
        self.ball_label_font_size = 20  # 【可改】号码球生肖/五行标签字体大小，默认20px
        
        # 预测模式
        self.enhanced_mode = True    # 【可改】是否启用增强模式（动态权重+模式识别），默认开启
        self.reverse_mode = False    # 【可改】是否反向模式（True=追求高错误率，选最不可能的号码）
        self.deterministic_mode = True  # 【可改】确定性预测模式（相同数据+算法=相同结果，可复现）
        self._use_model_cache = True  # 【可改】是否使用模型训练文件（ml_models.pkl），False=每次重新训练
        
        # 详情字体缩放
        self.detail_font_scale = 1.0  # 详情区域字体缩放比例
        self._current_detail_row = -1  # 当前选中的详情行
        
        # 各区域独立字体缩放
        # 【可改】各区域字体缩放比例，可单独调整不同区域的文字大小
        self._area_font_scales = {
            'table': 1.0,      # 历史记录表格（含正码特别码）
            'result': 1.0,     # 预测结果区域
            'list': 1.0,       # 列表项（收藏、概率等）
            # 矩阵面板四区域拆成「文字 / 号码」两类独立键（共 8 个）；
            # 合并版里四区域都落在同一块矩阵面板，但文字键只改五行字号、
            # 号码键只改号码字号，二者互不影响。
            'number_panel_text': 1.0,  # 数字区·文字
            'number_panel_num': 1.0,   # 数字区·号码
            'zodiac_panel_text': 1.0,  # 生肖区·文字
            'zodiac_panel_num': 1.0,   # 生肖区·号码
            'element_panel_text': 1.0, # 五行区·文字
            'element_panel_num': 1.0,  # 五行区·号码
            'attr_panel_text': 1.0,    # 号码属性区·文字
            'attr_panel_num': 1.0,     # 号码属性区·号码
            'announcement': 1.0,  # 公告说明
            'detail': 1.0,        # 期号详情弹窗
        }
        
        # 号码属性表面板尺寸（三页合并版；旧 [Display] zodiac_panel_* 保留只读）
        # fonts_custom：用户是否在「数字/文字 PX」里显式改过字号。
        # False 时字号跟随档位默认（1180 档 28/15、1600 档 34/17）；
        # True 时严格按 btn_font/label_font 渲染，保证 15–150 双向可调。
        self._attr_panel_size = {'width': 90, 'height': 98, 'btn_font': 28, 'label_font': 15,
                                 'fonts_custom': False}
        
        # 面板尺寸设置
        self._number_panel_size_scale = 1.0  # 【可改】数字面板整体大小缩放比例
        
        # 【可改】数字选择面板按钮尺寸（宽×高，单位px）——默认宽80px高50px文字20px
        self._number_panel_size = {'width': 80, 'height': 60, 'font': 20}  # 默认宽80高60文字20
        
        # 【可改】生肖面板尺寸——默认宽80px高50px数字文字20px标签文字20px
        self._zodiac_panel_size = {'width': 80, 'height': 60, 'btn_font': 20, 'label_font': 20}  # 默认宽80高60文字20
        
        # 【可改】五行面板尺寸——默认宽54px高38px数字文字16px标签文字15px（紧凑，49个号码尽量一屏显示）
        # v0.0.67：标签文字由 12 抬到 15（全项目文字最小 15px），消除「角控件显示 15、实际渲染 12」的缺陷
        self._element_panel_size = {'width': 54, 'height': 38, 'btn_font': 16, 'label_font': 15}  # 默认宽54高38
        
        # 【可改】预测结果号码球尺寸（正码+特别码）
        # label_width/label_height: 生肖/五行标签背景的宽高（0=自适应不固定）
        self._prediction_ball_size = {'width': 80, 'height': 60, 'font': 20, 'label_font': 20, 'label_width': 0, 'label_height': 0}  # 预测球默认宽80高60文字20
        
        # 【可改】颜色图例文字大小
        self._legend_font_size = {'label': 20, 'nums': 20}  # 图例字体默认20px
        
        # 【可改】详情标签（生肖/五行详情）字体和内边距
        self._detail_label_size = {'font': 20, 'padding': 8}  # 详情标签字体默认20px
        
        # 加载配置（会覆盖上面的默认值）
        self._load_ini_config()

        # 加载生肖绑定（INI优先，缺失时回退生肖绑定.json）
        _tab_attr.load_binding(self)
        
        # 加载自定义号码颜色（覆盖默认波色配置）
        self._load_custom_number_colors()
        
        # 图表懒加载
        self._chart_initialized = False  # 图表是否已初始化
        
        # 预测异步执行
        self._is_predicting = False   # 是否正在预测中（防止重复点击）
        self._predict_thread = None   # 预测线程
        self._predict_worker = None   # 预测工作对象
        self._block_no_new_data = True  # 【可改】是否启用"无新数据无法预测"锁定，True=锁定，False=允许重复预测
        
        # 初始化流程
        self._load_data()         # 加载历史数据
        # 本次改动：整个构造流程都处于「只读不写」窗口。除了 UI 构建期会刷新概率面板
        # 等控件（此时还是默认值），启动末尾还会做三件会触发 _save_ini_config() 的事：
        #   ① load_last_prediction → on_prediction_type_changed；
        #   ② setCurrentIndex 恢复上次选项卡 → _on_tab_changed；
        #   ③ 页面显示后 Qt 自动重算分隔条/表格列宽。
        # 若不禁写，这些「界面自己算出来的值」会盖掉 INI 里真正持久化的布局，
        # 于是每次启动哈希都变、却又没有任何用户改动。写盘闸门统一在末尾打开。
        self._init_ui()           # 初始化UI界面
        _tab_prediction_history.load_prediction_history(self)  # 加载已落盘的预测记录（重启不丢失）
        self._apply_panel_sizes_to_ui()  # 应用面板尺寸设置
        self._restore_widget_states()    # 恢复通用控件状态（下拉框/数字框/复选框/表格列宽）
        self._apply_stylesheet()  # 应用样式表
        # 预测记录表格列宽必须在样式表应用后再算：构建期表格还是 Qt 默认 12px 字号，
        # 反算出的时间列最小宽度（150）在全局 15px 字号下会裁掉时间戳两端（实际需 166）。
        # 同时该表已从通用 t_ 恢复中排除，这里设置后不会再被上一窗口绝对宽度覆盖。
        _tab_prediction.apply_prediction_col_widths(self)
        _tab_prediction.load_last_prediction(self)  # 【缓存机制】加载上次预测结果（已有JSON文件直接使用，无需重新计算）
        # v0.0.49：号码预测（七策略）结果跨重启回填。文件不存在时保持空页面；
        # 指纹一致才提示“已恢复”，指纹变化只保留旧结果并标注过期，不自动重算。
        _tab_prediction.load_number_strategy_prediction(self)
        self._setup_shortcuts()   # 设置快捷键
        
        # 标签页切换事件（用于图表懒加载 + 记忆当前选项卡）
        if hasattr(self, 'tabs'):
            self.tabs.currentChanged.connect(self._on_tab_changed)
            # 恢复上次停留的选项卡：必须在选项卡建好并连接信号之后执行。
            # 顺序被拖动记忆重排后索引会变，优先按标题找回同一页，避免“停在哪页”被顺序打乱。
            start_index = getattr(self, '_ini_start_tab_index', 0)
            title_idx = self._tab_index_by_title(getattr(self, '_ini_start_tab_title', ''))
            if title_idx >= 0:
                start_index = title_idx
            if 0 <= start_index < self.tabs.count():
                self.tabs.setCurrentIndex(start_index)

        # 启动流程结束：打开写盘闸门
        # 此后所有 _save_ini_config() 调用都来自用户真实操作（下拉框/数字框/表格列宽/
        # 分隔条/工具栏按钮等信号），允许写盘；启动期累积的自动布局值全部丢弃。
        self._ini_write_enabled = True
        self._ini_dirty = False
        # 首帧之后才开始记录窗口移动/缩放：show() 会先发一轮 resize/move，
        # 那属于启动布局，不是用户改动，必须排除在 _ini_dirty 之外。
        QTimer.singleShot(0, self._enable_geometry_tracking)

        # 降级模式必须常驻可见：UI 构建期多处 showMessage 会覆盖 _load_data 的提示，
        # 这里在构造末尾重新写入，直到用户确认恢复前都明确告知当前状态
        if getattr(self, '_data_degraded', False):
            self.statusBar().showMessage(
                '降级模式：数据文件损坏，已从数据库恢复 ' + str(len(self.historical_data)) +
                ' 条，暂禁止写入空数据')
            btn = getattr(self, 'degraded_confirm_btn', None)
            if btn is not None:
                btn.setVisible(True)

        print("系统 v7.5 初始化完成")

    def _enable_geometry_tracking(self):
        """功能：启动首帧渲染完成后，开启窗口几何变化追踪
        说明：
            只有用户移动/缩放窗口才算「真正的改动」，才允许关窗时落盘窗口位置与尺寸。
            之所以延迟到 QTimer.singleShot(0)，是因为 show() 与首次布局会触发
            resize/move 事件；若提前开启，每次启动都会被误判为用户改动，
            关窗又会重写 INI，回到「无意义写盘」的老问题。
        参数: 无
        返回: 无
        """
        if getattr(self, '_window_closing', False):
            return
        self._geometry_tracking = True

    def moveEvent(self, event):
        """功能：窗口移动事件——用户拖动窗口时标记 INI 需要保存
        说明：仅当 _geometry_tracking 为 True（启动首帧已过去）才置脏，
              closeEvent 会据此决定是否把新的 window_x/window_y 落盘。
        注意：本方法只置 _ini_dirty 标志，不写盘；窗口关闭中（_window_closing）
              也会跳过，避免销毁阶段访问已释放的属性。
        参数:
            event: QMoveEvent（透传给父类，本方法不读取其坐标）
        返回:
            无
        """
        super().moveEvent(event)
        if getattr(self, '_geometry_tracking', False) and not getattr(self, '_window_closing', False):
            self._ini_dirty = True

    def resizeEvent(self, event):
        """功能：窗口缩放事件——按新尺寸重算自适应字号，并把「用户缩放」标记为 INI 需要保存

        说明（为什么合并成一份）：
            v0.0.63 及更早版本本类存在两份同名 resizeEvent：本处这份负责「首帧后置
            _ini_dirty」，文件后段 _apply_autosize() 之前那份负责「按新窗口尺寸重算
            全局字号」。Python 同名方法后者覆盖前者，实际运行时只剩字体重算生效，
            只缩放窗口不会置脏，于是 v0.0.63「关窗仅在 _ini_dirty 时保存」后新尺寸
            永远写不进 INI。现在合并为唯一实现：先 super()，再重算字号，最后置脏，
            两份原有行为全部保留，不再留同名桩。
        说明（为什么首帧之后才置脏）：
            show() 与首次布局会自发触发 resize/move，那属于启动布局而非用户改动；
            _geometry_tracking 由 QTimer.singleShot(0) 在首帧渲染完成后才置 True，
            因此启动期间既不置脏也不写盘，避免每次启动都重写 INI。
        注意：本方法在超级用户级别频繁触发，内部做了「重算字号 + 只置标志」两件事，
              两者都不写盘；字号受 _apply_autosize 的 0.85~1.15 倍与 15px 下限约束。
        参数:
            event: QResizeEvent（透传给父类，不直接读取其尺寸）
        返回:
            无
        """
        super().resizeEvent(event)
        # 原有行为①：字号随窗口尺寸重算（原后段那份 resizeEvent 的唯一职责）
        self._apply_autosize()
        # 原有行为②：首帧后的真实用户缩放才置脏，closeEvent 据此把新宽高落盘
        if getattr(self, '_geometry_tracking', False) and not getattr(self, '_window_closing', False):
            self._ini_dirty = True

    # [基础设施] 程序目录、旧数据迁移、数据库同步、结果分隔符

    @staticmethod
    def _get_app_dir():
        """功能：获取程序基准目录
        说明：源码运行时为项目根目录；PyInstaller 打包成 exe 后为 exe 所在目录，
              保证数据库、INI、JSON 等数据统一生成在程序目录下，便于整体迁移。
        参数: 无
        返回: str 目录绝对路径
        """
        if getattr(sys, 'frozen', False):
            return os.path.dirname(os.path.abspath(sys.executable))
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def _migrate_legacy_data(self):
        """功能：把旧版数据目录自动迁移到统一目录「系统v7.5」
        说明：
            1) 旧业务目录「彩票预测系统v7.5」→「系统v7.5」
            2) 旧版放在程序根目录的「数据存储」→「系统v7.5/数据存储」
            均采用复制方式（源目录保留），失败不中断启动。
        参数: 无
        返回: 无
        """
        import shutil  # 作用说明：旧数据目录整体迁移时复制/移动目录树（仅在源目录存在且目标缺失时执行）
        legacy_dir = os.path.join(self._app_dir, "彩票预测系统v7.5")
        # 1) 旧业务目录整体迁移（仅当新目录尚未建立时）
        if os.path.isdir(legacy_dir) and not os.path.isdir(self._data_dir):
            try:
                os.makedirs(self._data_dir, exist_ok=True)
                for name in os.listdir(legacy_dir):
                    src = os.path.join(legacy_dir, name)
                    dst = os.path.join(self._data_dir, name)
                    if os.path.exists(dst):
                        continue
                    if os.path.isdir(src):
                        shutil.copytree(src, dst)
                    else:
                        shutil.copy2(src, dst)
                print("旧数据目录已迁移: " + legacy_dir + " → " + self._data_dir)
            except Exception as e:
                print("旧数据目录迁移失败（不影响启动）: " + str(e))

        # 2) 旧版根目录下的「数据存储」迁移进统一数据目录
        legacy_store = os.path.join(self._app_dir, "数据存储")
        new_store = os.path.join(self._data_dir, "数据存储")
        if os.path.isdir(legacy_store) and not os.path.isdir(new_store):
            try:
                os.makedirs(self._data_dir, exist_ok=True)
                shutil.copytree(legacy_store, new_store)
                print("旧数据存储目录已迁移: " + legacy_store + " → " + new_store)
            except Exception as e:
                print("旧数据存储目录迁移失败（不影响启动）: " + str(e))

    def _sync_data_state_to_db(self):
        """功能：把历史数据概况同步写入 SQLite 功能状态表（func_state）

        写前比对（v0.0.65）：
            func_state 目前只写不读（全仓库无消费方，见功能说明第二十章），
            updated_at 也不参与任何新鲜度/缓存判断，所以内容没变时写库纯属
            无意义 I/O（会追加 WAL 帧并改写 -wal/-shm）。现在先读旧行，
            只比较 record_count / latest_period / enabled 三项业务内容：
            一致则直接返回；任一变化才按原逻辑覆盖写。
            注意：state_json 内的 updated_at 不参与比较，否则每次启动都会
            「内容不同」，永远无法跳过。

        参数: 无
        返回: 无（异常只打印，不影响启动）
        """
        if self._db is None:
            return
        try:
            state = {
                'record_count': len(self.historical_data),
                'latest_period': str(get_latest_period(self.historical_data)) if self.historical_data else '',
                'updated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            }
            # 读旧状态做写前比对；旧 state_json 损坏时按「有变化」处理并覆盖修正
            try:
                previous = self._db.get_func_state('彩票预测')
                if previous is not None:
                    previous_state = json.loads(previous.get('state_json') or '{}')
                    if (int(previous.get('enabled', 1) or 0) == 1
                            and previous_state.get('record_count') == state['record_count']
                            and previous_state.get('latest_period') == state['latest_period']):
                        return  # 业务内容一致：不写库，WAL 保持不动
            except (TypeError, ValueError):
                pass
            self._db.set_func_state('彩票预测', True, json.dumps(state, ensure_ascii=False))
        except Exception as e:
            print("同步数据状态到数据库失败: " + str(e))

    def _sync_history_to_db(self):
        """功能：把历史开奖数据整体镜像写入 SQLite（history_records 表）
        说明：JSON 文件是主数据源，数据库仅作兜底；写入失败不影响 JSON 流程
        注意：会直接覆盖写库（产生 WAL 帧），只在 _save_data 写盘成功后调用；
              降级模式（JSON 损坏且内存为空）下拒绝覆盖，避免空列表清空镜像；
              _db 为 None（数据库降级）时静默返回，异常只打印不抛出。
        参数:
            无（数据取 self.historical_data）
        返回:
            无
        """
        if self._db is None:
            return
        if self._data_degraded and not self.historical_data:
            logging.warning('降级模式下拒绝以空列表覆盖数据库历史镜像: %s', self.data_file)
            try:
                self.statusBar().showMessage('降级模式：已阻止空数据覆盖数据库，请先确认数据恢复')
            except Exception:
                pass
            return
        try:
            self._db.save_history(self.historical_data)
        except Exception as e:
            print("同步历史数据到数据库失败: " + str(e))

    def _on_confirm_degraded_overwrite(self):
        """功能：降级模式确认入口——用户显式确认后真实保存当前数据并解除降级

        说明：只在 JSON 损坏进入降级模式后由状态栏按钮触发。
              内存历史为空时，保存会把空列表写入数据库（DELETE 全部），
              因此先弹二次确认（默认「取消」），文案明确会清空数据库历史记录；
              非空历史保持一键保存，不打断。
              保存期间保持 _data_degraded，让 _sync_history_to_db 的空列表护栏
              继续生效；JSON 写盘成功后才清降级标志，空数据再按用户确认补写库，
              保证数据库条数与内存一致；失败则保持降级、按钮保留并如实报错。
        参数：无。
        返回：无。
        """
        if not getattr(self, '_data_degraded', False):
            return
        btn = getattr(self, 'degraded_confirm_btn', None)
        is_empty = not self.historical_data
        if is_empty:
            reply = QMessageBox.question(
                self, "确认解除降级",
                "当前内存中的历史记录为空。继续将把空列表写入磁盘，并清空数据库中的历史记录"
                "（可被空列表覆盖）。\n\n确定执行吗？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if reply != QMessageBox.StandardButton.Yes:
                self.statusBar().showMessage('已取消：仍处于降级模式，未写入任何数据')
                return
        if self._save_data():
            # 保存成功后才清降级标志（保存期间保持降级，空列表护栏继续生效）
            self._data_degraded = False
            if is_empty:
                # 空历史已获用户显式确认：补写数据库，使镜像条数与内存一致（0 条）
                self._sync_history_to_db()
            if btn is not None:
                btn.setVisible(False)
            self.statusBar().showMessage('已解除降级并保存')
        else:
            self._data_degraded = True
            if btn is not None:
                btn.setVisible(True)
            self.statusBar().showMessage('保存失败，仍处于降级模式：本次修改未写入磁盘')

    def _analysis_records(self, window=None):
        """功能：统计/图表/回测/报表共用的历史数据：优先走 DuckDB，失败回退内存
        注意：首次或指纹变化时会先 sync_history_to_duckdb（写分析库，较慢），
              之后按指纹缓存跳过；DuckDB 为空或异常时回退内存列表，始终返回副本
              （内存分支用 list() 复制，调用方改列表不会污染 historical_data）。
        参数:
            window: 取最近 N 期；None 表示全部
        返回:
            (records, source) —— source 为 'DuckDB' 或 '内存'
        """
        if not self.historical_data:
            return [], '内存'
        if self._db is not None:
            try:
                fingerprint = _tab_prediction.compute_data_fingerprint(self)
                if getattr(self, '_duckdb_synced_fingerprint', None) != fingerprint:
                    self._db.sync_history_to_duckdb(self.historical_data)
                    self._duckdb_synced_fingerprint = fingerprint
                records = self._db.load_history_for_analysis(window)
                if records:
                    return records, 'DuckDB'
            except Exception as e:
                print("DuckDB 取数失败，回退内存数据: " + str(e))
        records = self.historical_data
        if window and window > 0:
            records = records[:window]
        return list(records), '内存'

    def _restore_ini_from_db(self):
        """功能：从 SQLite 读取配置镜像，重建 ConfigParser 对象（INI 文件丢失时兜底）
        注意：只重建内存 self._ini，不写盘；镜像缺失或 JSON 损坏时返回 False，
              调用方据此决定是否走默认配置；异常只打印不抛出。
        参数:
            无（镜像键为 ui_ini）
        返回:
            bool 是否恢复成功
        """
        if self._db is None:
            return False
        try:
            raw = self._db.get_config('ui_ini')
            if not raw:
                return False
            snapshot = json.loads(raw)
            import configparser  # 作用说明：按节/键重建 ConfigParser，还原数据库里的配置镜像
            ini = configparser.ConfigParser()
            for section, kv in snapshot.items():
                ini[section] = {k: str(v) for k, v in kv.items()}
            self._ini = ini
            return True
        except Exception as e:
            print("从数据库恢复配置失败: " + str(e))
            return False

    def _get_result_separator(self, combo_attr):
        """功能：读取「结果分隔符」下拉框当前分隔符
        注意：纯读取，不改控件；属性不存在或 currentData 为 None 时统一返回一个
              半角空格，保证拼接结果不出现空串粘连。
        参数:
            combo_attr: 下拉框属性名，如 'sort_sep_combo' / 'tail_sep_combo'
        返回:
            str 分隔符（默认一个空格）
        """
        combo = getattr(self, combo_attr, None)
        if combo is None:
            return " "
        sep = combo.currentData()
        return sep if sep is not None else " "
    

    # [全局快捷键] 快捷键设置

    def _setup_shortcuts(self):
        """功能：注册主窗口快捷键（切页/预测/保存/随机抽取）
        注意：QShortcut 的父对象是 self，作用域限于本窗口；Ctrl+1~9 映射到
              选项卡 1~9，Ctrl+0 → 第 10 页，Ctrl+Shift+1 → 第 11 页；
              lambda 用默认参数 idx=i-1 避免闭包late-binding；只连信号不写盘。
        参数:
            无
        返回:
            无
        """
        # Ctrl+1~9 切换标签页1-9，Ctrl+0 切换标签页10，Ctrl+Shift+1 切换标签页11
        for i in range(1, 10):
            shortcut = QShortcut(QKeySequence("Ctrl+" + str(i)), self)
            # 快捷键信号连接：切换标签页（索引偏移-1）
            shortcut.activated.connect(lambda idx=i-1: self._switch_tab(idx))
        # Ctrl+0快捷键：切换标签页10
        QShortcut(QKeySequence("Ctrl+0"), self).activated.connect(lambda: self._switch_tab(9))
        # Ctrl+Shift+1快捷键：切换标签页11
        QShortcut(QKeySequence("Ctrl+Shift+1"), self).activated.connect(lambda: self._switch_tab(10))
        # Ctrl+P / Ctrl+S / Ctrl+D 已迁移为「预测」菜单里的 QAction 快捷键，
        # 这里不再保留 QShortcut，避免同一按键被触发两次。
    
    def _safe_cleanup_thread(self, thread_attr, worker_attr):
        """功能：安全清理预测线程和 worker，防止堆内存损坏
        
        核心原则：
        1. 先断开所有信号连接（包括thread和worker的）
        2. 请求线程退出并等待（不使用terminate，避免堆内存损坏）
        3. 断开thread信号后再置空引用
        4. 不使用deleteLater跨线程删除，让Python GC管理
        注意：最多阻塞 UI 线程 5 秒等待退出；绝不调用 terminate（会导致 C 运行时
              堆损坏 0xC0000374）；所有 disconnect 都吞 RuntimeError/TypeError
              （C++ 对象可能已被销毁）；最后无条件置空 thread/worker 引用。
        参数:
            thread_attr: 线程属性名（如 '_predict_thread'）
            worker_attr: worker 属性名（如 '_predict_worker'）
        返回:
            无
        """
        thread = getattr(self, thread_attr, None)
        worker = getattr(self, worker_attr, None)
        
        if thread is None and worker is None:
            return
        
        # 第1步：断开worker的所有信号连接
        if worker is not None:
            try:
                worker.finished.disconnect()
            except (RuntimeError, TypeError):
                pass
            try:
                worker.error.disconnect()
            except (RuntimeError, TypeError):
                pass
            try:
                worker.progress.disconnect()
            except (RuntimeError, TypeError):
                pass
        
        # 第2步：断开thread的所有信号连接（防止thread.finished触发已断开的worker.deleteLater）
        if thread is not None:
            try:
                thread.started.disconnect()
            except (RuntimeError, TypeError):
                pass
            try:
                thread.finished.disconnect()
            except (RuntimeError, TypeError):
                pass
        
        # 第3步：请求线程退出并等待（绝不调用terminate，它会导致堆内存损坏）
        if thread is not None:
            try:
                if thread.isRunning():
                    thread.quit()
                    if not thread.wait(5000):
                        # 线程拒绝退出，只能放弃等待，但绝不调用terminate
                        # terminate会破坏C运行时堆，导致0xC0000374
                        print("[警告] 线程未能在5秒内退出，放弃等待", file=sys.stderr)
            except RuntimeError:
                pass  # C/C++对象已被删除
            except Exception:
                pass
        
        # 第4步：置空引用
        setattr(self, thread_attr, None)
        setattr(self, worker_attr, None)
    
    def _detach_worker(self, thread_attr, worker_attr):
        """功能：轻量清理——断开信号、置空引用，安全清理已结束的 thread
        
        用于信号处理函数中，避免在信号处理函数中wait线程导致死锁/堆损坏。
        线程会通过 worker.finished → thread.quit 连接自动退出。
        完整的线程清理由下次预测开始时的 _safe_cleanup_thread 处理。
        注意：本方法不调用 wait/quit，绝不阻塞信号处理函数（否则可能与 worker
              互等死锁）；thread/worker 引用必须同时置空，只置空 worker 会留下
              已释放的 C++ 线程对象，下次清理时访问野指针触发堆损坏。
        参数:
            thread_attr: 线程属性名（如 '_predict_thread'）
            worker_attr: worker 属性名（如 '_predict_worker'）
        返回:
            无
        """
        worker = getattr(self, worker_attr, None)
        thread = getattr(self, thread_attr, None)
        
        # 断开worker的信号连接
        if worker is not None:
            try:
                worker.finished.disconnect()
            except (RuntimeError, TypeError):
                pass
            try:
                worker.error.disconnect()
            except (RuntimeError, TypeError):
                pass
            try:
                worker.progress.disconnect()
            except (RuntimeError, TypeError):
                pass
        
        # 【修复0xC0000374】同时置空thread引用
        # 若只置空worker不置null thread，下次预测时 _safe_cleanup_thread
        # 会操作已结束的thread对象（其C++对象已被Qt事件循环deleteLater删除），
        # 导致访问已释放的C++内存，触发STATUS_HEAP_CORRUPTION
        if thread is not None:
            try:
                thread.started.disconnect()
            except (RuntimeError, TypeError):
                pass
            try:
                thread.finished.disconnect()
            except (RuntimeError, TypeError):
                pass
        
        setattr(self, thread_attr, None)
        setattr(self, worker_attr, None)
    
    def closeEvent(self, event):
        """功能：窗口关闭时保存 INI 配置，并安全清理所有后台线程，防止堆内存损坏导致闪退
        注意：先置 _window_closing 阻断后续信号回调；依次停线程 → 释放预测器 →
              落盘预测记录 → 仅在 _ini_dirty 为 True 时写 INI → 关数据库；
              「纯启动→关闭」不写 INI，保证文件哈希不变；预测记录落盘不受
              写盘闸门约束（由 TAB 页自行处理）。
        参数:
            event: QCloseEvent（最后透传给父类，由其决定接受/忽略关闭）
        返回:
            无
        """
        # 标记窗口正在关闭，阻止信号处理函数访问已销毁的控件
        self._window_closing = True
        
        # 安全停止所有预测线程（不使用terminate，避免堆内存损坏）
        self._safe_cleanup_thread('_predict_thread', '_predict_worker')
        self._safe_cleanup_thread('_ml_predict_thread', '_ml_predict_worker')
        
        # 清理当前predictor实例持有的TF/PyTorch模型引用
        if hasattr(self, '_current_predictor') and self._current_predictor is not None:
            try:
                self._current_predictor.cleanup()
            except Exception:
                pass
            self._current_predictor = None
        
        # 关窗前落盘预测记录，避免仅存内存导致重启丢失
        _tab_prediction_history.save_prediction_history(self)
        # INI 只在「确实发生过用户改动」时才写：
        #   用户改控件 → 对应信号已调用 _save_ini_config()，_ini_dirty 为 True；
        #   用户移动/缩放窗口 → moveEvent/resizeEvent 置脏；
        #   什么都没改（纯启动→关闭）→ 不写，保证连续启动的文件哈希完全不变。
        if getattr(self, '_ini_dirty', False):
            self._save_ini_config()
        # 关闭数据库连接（配置已写入后执行，避免提前关闭导致配置镜像写不进去）
        if self._db is not None:
            try:
                self._db.close()
            except Exception:
                pass
        super().closeEvent(event)
    
    def _switch_tab(self, index):
        """功能：切换到指定索引的选项卡（快捷键槽）
        注意：越界索引静默忽略，不抛异常；切页会触发 _on_tab_changed，
              该槽在索引变化时才写 INI（受写盘闸门控制）。
        参数:
            index: 选项卡索引（0 起）
        返回:
            无
        """
        if 0 <= index < self.tabs.count():
            self.tabs.setCurrentIndex(index)
    
    def _init_ui(self):
        """功能：初始化 UI 界面（中央容器 → 顶栏 → 选项卡 → 状态栏 → 首屏刷新）
        注意：会创建全部页面（经 TAB.iter_tab_pages 的 install/build），属于重副作用；
              会刷新历史表、回填数字面板选中态并应用预测记录列宽；
              本方法在写盘闸门打开前执行，内部触发的保存调用都会被拦截。
        参数:
            无
        返回:
            无
        """
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        self._create_top_bar(main_layout)
        self._create_tabs(main_layout)
        self._create_status_bar()
        # 抽屉内的页面字号控件在选项卡创建后才存在，因此这里再建浮层
        self._build_display_drawer()
        # 加载数据后刷新界面
        _tab_history.update_history_table(self)
        # 恢复数字选择面板的选中状态
        if hasattr(self, '_pending_selected_numbers') and self._pending_selected_numbers:
            if hasattr(self, 'number_panel') and hasattr(self.number_panel, 'select_numbers'):
                self.number_panel.select_numbers(self._pending_selected_numbers)
            self._pending_selected_numbers = []
        # 预测记录表格列宽改到 _apply_stylesheet 之后统一应用（构建期字号尚未生效，
        # 此时反算的时间列最小宽度会偏小），见 __init__ 中的调用点。
    

    # [全局布局] UI初始化、顶部栏、选项卡、状态栏

    def _create_top_bar(self, parent_layout):
        """功能：创建顶栏
        注意：只搭界面并连接信号（导入/导出/保存/增删清空/快捷菜单/字号/边距/主题），
              不直接读写数据库；lambda 槽要等点击时才回调主窗口方法。
              按钮尺寸与 QSS 在此固定，改窗口宽度时不要指望布局自动重排。
        参数:
            parent_layout: 主窗口垂直布局，顶栏挂在其末尾
        返回:
            无（顶栏控件由布局托管，引用保存到 self.font_combo 等处）
        """
        top_bar = QWidget()
        top_bar.setObjectName("TopBar")
        # 单行顶栏：46px = 上下 6px 外边距 + 34px 内容行；菜单栏与工具按钮同排，
        # 不再额外占一行，1180 下历史表格才能守住 5 整行
        top_bar.setFixedHeight(46)
        # 纯 QWidget 需要 WA_StyledBackground 才会绘制 QSS 背景色（否则暗色下仍是系统浅色底）
        top_bar.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._top_bar = top_bar
        top_bar_layout = QHBoxLayout(top_bar)
        top_bar_layout.setSpacing(8)
        top_bar_layout.setContentsMargins(15, 6, 15, 6)

        # ---- 左侧：嵌入式 QMenuBar（不调用 QMainWindow.setMenuBar）----
        self.menu_bar = QMenuBar(top_bar)
        self.menu_bar.setObjectName("TopMenuBar")
        self.menu_bar.setFixedHeight(34)
        self.menu_bar.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        top_bar_layout.addWidget(self.menu_bar, 0)
        self._create_menus()
        
        button_group = QWidget()
        button_layout = QHBoxLayout(button_group)
        # 只保留高频按钮：导入 / 导出 / 保存 / 快捷▾ / 主题，其余动作全部进菜单
        button_layout.setSpacing(6)
        button_layout.setContentsMargins(0, 0, 0, 0)
        # 字号/内边距由全局 QSS 的 #TopBar QPushButton 规则统一固定为 15px，
        # 这里不再挂局部样式表，避免覆盖暗色主题的卡片背景令牌。
        
        import_btn = QPushButton("导入")
        # 导入按钮点击信号：委托历史记录页的 on_import_history（与页面按钮同一实现）
        import_btn.clicked.connect(lambda: _tab_history.on_import_history(self))
        button_layout.addWidget(import_btn)
        
        export_btn = QPushButton("导出")
        # 导出按钮点击信号：委托历史记录页的 on_export_history（与页面按钮同一实现）
        export_btn.clicked.connect(lambda: _tab_history.on_export_history(self))
        button_layout.addWidget(export_btn)
        
        save_btn = QPushButton("保存")
        # 保存按钮点击信号：连接保存数据处理函数
        save_btn.clicked.connect(self._on_save_clicked)
        button_layout.addWidget(save_btn)
        
        # 功能10：快捷操作面板
        quick_btn = QPushButton("快捷 ▾")
        quick_btn.setObjectName("QuickBtn")
        quick_menu = QMenu(self)
        
        # 清空所有收藏
        clear_fav_action = quick_menu.addAction("清空所有收藏")
        # 触发信号连接：清空所有收藏
        clear_fav_action.triggered.connect(lambda: _tab_prediction.on_clear_collected(self))
        
        # 清空预测记录
        clear_ph_action = quick_menu.addAction("清空预测记录")
        # 触发信号连接：清空预测记录
        clear_ph_action.triggered.connect(lambda: _tab_prediction_history.on_clear_prediction_history(self))
        
        quick_menu.addSeparator()
        
        # 批量导出报告
        batch_export_action = quick_menu.addAction("批量导出报告")
        # 触发信号连接：批量导出报告
        batch_export_action.triggered.connect(self._on_batch_export_reports)
        
        # 验证号码组合
        validate_action = quick_menu.addAction("验证号码组合")
        # 触发信号连接：验证号码组合
        validate_action.triggered.connect(self._on_validate_number_combo)
        
        quick_menu.addSeparator()
        
        # 一键复制预测结果
        copy_action = quick_menu.addAction("一键复制预测结果")
        # 触发信号连接：一键复制预测结果
        copy_action.triggered.connect(self._on_copy_latest_prediction)
        
        quick_btn.setMenu(quick_menu)
        button_layout.addWidget(quick_btn)

        # 主题切换保持为顶栏快捷按钮（高频操作），下拉菜单里也有同一入口
        theme_btn = QPushButton("主题")
        theme_btn.setObjectName("ThemeToggleBtn")
        theme_btn.setToolTip("切换亮色 / 暗色主题")
        theme_btn.clicked.connect(self._on_toggle_theme)
        button_layout.addWidget(theme_btn)

        # 顶栏按钮统一 34px 高，保证 46px 单行内上下各留 6px；宽度按 15px 中文两字核定
        for _btn in (import_btn, export_btn, save_btn):
            _btn.setFixedSize(52, 34)
        quick_btn.setFixedSize(58, 34)
        theme_btn.setFixedSize(58, 34)
        
        top_bar_layout.addSpacing(4)
        top_bar_layout.addWidget(button_group, 0)
        top_bar_layout.addStretch(1)
        
        # 右侧：字号抽屉唯一入口「显示设置 · 当前档位 ▾」
        right_control = QWidget()
        right_layout = QHBoxLayout(right_control)
        right_layout.setSpacing(5)
        right_layout.setContentsMargins(0, 0, 0, 0)

        self.display_drawer_btn = QPushButton("显示设置 · " + str(self.font_size_key) + " ▾")
        self.display_drawer_btn.setObjectName("DisplayDrawerBtn")
        self.display_drawer_btn.setFixedSize(148, 34)
        self.display_drawer_btn.setCheckable(True)
        self.display_drawer_btn.setToolTip("打开字号与显示设置浮层（不占页面高度）")
        # 点击信号：展开 / 收起字号抽屉
        self.display_drawer_btn.clicked.connect(self._toggle_display_drawer)
        right_layout.addWidget(self.display_drawer_btn)

        top_bar_layout.addWidget(right_control, 0)
        parent_layout.addWidget(top_bar)

        # 抽屉内的「数字 px / 文字 px / 尺寸」需要页面控件已存在，
        # 因此抽屉本身在 _init_ui 里 _create_tabs 之后再构建，这里只占位。
        self.display_drawer = None

    # 菜单栏：六组真实动作（每项都接现有函数，不放空壳）
    def _create_menus(self):
        """功能：构建六组菜单并挂到嵌入式 QMenuBar
        注意：只接现有真实函数；Ctrl+P/S/D 迁移到 QAction 后由主窗口接收快捷键
              （未调用 setMenuBar，所以额外 self.addAction 把动作注册到窗口）。
        参数: 无
        返回: 无
        """
        # ---------------- 数据 ----------------
        data_menu = self.menu_bar.addMenu("数据")
        self._add_menu_action(data_menu, "导入历史", lambda: _tab_history.on_import_history(self))
        self._add_menu_action(data_menu, "导出历史", lambda: _tab_history.on_export_history(self))
        self._add_menu_action(data_menu, "保存", self._on_save_clicked, "Ctrl+S")
        data_menu.addSeparator()
        self._add_menu_action(data_menu, "添加记录", self._on_add_data_clicked)
        self._add_menu_action(data_menu, "删除选中", self._on_delete_data_clicked)
        self._add_menu_action(data_menu, "清空历史", self._on_clear_data_clicked)
        data_menu.addSeparator()
        self._add_menu_action(data_menu, "批量添加", lambda: _tab_history.on_batch_add(self))
        self._add_menu_action(data_menu, "批量删除", lambda: _tab_history.on_batch_delete(self))
        self._add_menu_action(data_menu, "批量修改", lambda: _tab_history.on_batch_modify(self))
        data_menu.addSeparator()
        self._add_menu_action(data_menu, "回填生肖快照",
                              lambda: _tab_history.backfill_zodiac_snapshots(self, True, True))
        self._add_menu_action(data_menu, "一键备份数据存储", lambda: _tab_data_storage.on_storage_backup(self))

        # ---------------- 预测 ----------------
        pred_menu = self.menu_bar.addMenu("预测")
        self._add_menu_action(pred_menu, "执行算法预测",
                              lambda: _tab_prediction.on_predict_clicked(self), "Ctrl+P")
        self._add_menu_action(pred_menu, "随机抽取",
                              lambda: _tab_prediction.on_random_draw_clicked(self), "Ctrl+D")
        self._add_menu_action(pred_menu, "机器学习预测",
                              lambda: _tab_prediction.on_ml_predict_clicked(self))
        pred_menu.addSeparator()
        self._add_menu_action(pred_menu, "验证号码组合", self._on_validate_number_combo)
        self._add_menu_action(pred_menu, "一键复制预测结果", self._on_copy_latest_prediction)
        pred_menu.addSeparator()
        self._add_menu_action(pred_menu, "清空所有收藏", lambda: _tab_prediction.on_clear_collected(self))
        self._add_menu_action(pred_menu, "清空预测记录",
                              lambda: _tab_prediction_history.on_clear_prediction_history(self))
        self._add_menu_action(pred_menu, "导出预测记录 CSV",
                              lambda: _tab_prediction_history.on_export_prediction_history_csv(self))

        # ---------------- 在线 ----------------
        online_menu = self.menu_bar.addMenu("在线")
        self._add_menu_action(online_menu, "打开在线视图", self._open_online_view)
        online_menu.addSeparator()
        self._add_menu_action(online_menu, "抓取", lambda: _tab_history.start_online_fetch(self))
        self._add_menu_action(online_menu, "取消抓取", lambda: _tab_history.cancel_online_fetch(self))
        online_menu.addSeparator()
        self._add_menu_action(online_menu, "清空在线数据", lambda: _tab_history.clear_online_data(self))

        # ---------------- 分析 ----------------
        analysis_menu = self.menu_bar.addMenu("分析")
        self._add_menu_action(analysis_menu, "运行大数据分析",
                              lambda: _tab_bigdata.on_bigdata_analyze_clicked(self))
        self._add_menu_action(analysis_menu, "复制分析结果",
                              lambda: _tab_bigdata.on_bigdata_copy_clicked(self))
        self._add_menu_action(analysis_menu, "导出分析结果",
                              lambda: _tab_bigdata.on_bigdata_export_clicked(self))
        analysis_menu.addSeparator()
        self._add_menu_action(analysis_menu, "批量导出算法报告", self._on_batch_export_reports)
        self._add_menu_action(analysis_menu, "算法回测", lambda: _tab_backtest.on_start_backtest(self))
        self._add_menu_action(analysis_menu, "对比所有算法", lambda: _tab_backtest.on_compare_all_algorithms(self))
        self._add_menu_action(analysis_menu, "命中率趋势", lambda: _tab_backtest.on_show_hit_trend(self))

        # ---------------- 视图 ----------------
        view_menu = self.menu_bar.addMenu("视图")
        self._add_menu_action(view_menu, "显示设置", self._open_display_drawer)
        view_menu.addSeparator()
        self._add_menu_action(view_menu, "切换主题", self._on_toggle_theme)
        self._add_menu_action(view_menu, "字号放大", self._increase_font_size)
        self._add_menu_action(view_menu, "字号缩小", self._decrease_font_size)
        view_menu.addSeparator()
        self._add_menu_action(view_menu, "重置所有字体", self._reset_all_font_sizes)
        self._add_menu_action(view_menu, "边距设置", self._show_margin_dialog)
        area_menu = view_menu.addMenu("分区字体")
        for _label, _area in (("表格字体", "table"), ("预测结果字体", "result"),
                              ("列表字体", "list"), ("公告说明字体", "announcement")):
            _sub = area_menu.addMenu(_label)
            self._add_menu_action(_sub, "放大", lambda a=_area: self._change_area_font_size(a, 1))
            self._add_menu_action(_sub, "缩小", lambda a=_area: self._change_area_font_size(a, -1))

        # ---------------- 帮助 ----------------
        help_menu = self.menu_bar.addMenu("帮助")
        self._add_menu_action(help_menu, "使用说明",
                              lambda: self._goto_tab_by_title("公告说明", "已跳转：使用说明"))
        self._add_menu_action(help_menu, "版本信息",
                              lambda: self._goto_tab_by_title("公告说明", "已跳转：版本信息"))
        self._add_menu_action(help_menu, "快捷键",
                              lambda: self._goto_tab_by_title("公告说明", "已跳转：快捷键"))

    def _add_menu_action(self, menu, text, handler, shortcut=None):
        """功能：向菜单追加一个动作（可选快捷键）
        注意：未调用 setMenuBar 时，QAction 的 WindowShortcut 需要额外注册到主窗口，
              否则快捷键不会生效；同一快捷键不得再保留旧 QShortcut，避免双触发。
        参数:
            menu: 目标 QMenu
            text: 菜单项文字
            handler: 触发回调
            shortcut: 形如 'Ctrl+P' 的快捷键字符串，None 表示无
        返回:
            QAction（便于后续复用/测试）
        """
        action = QAction(text, self)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
            self.addAction(action)
        action.triggered.connect(handler)
        menu.addAction(action)
        return action

    def _goto_tab_by_title(self, title, message=None):
        """功能：按选项卡标题跳转（帮助菜单使用）
        注意：遍历现有 14 个选项卡，按标题精确匹配；找不到时只提示不报错。
        参数:
            title: 选项卡标题，如 '公告说明'
            message: 跳转后写入状态栏的提示文字
        返回:
            bool 是否找到并跳转
        """
        if not hasattr(self, 'tabs'):
            return False
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == title:
                self._switch_tab(i)
                if message:
                    self.statusBar().showMessage(message)
                return True
        return False

    def _open_online_view(self):
        """功能：切到「历史记录」页的在线视图（菜单「在线·打开在线视图」）
        注意：必须走 online_view_combo.setCurrentIndex(1)，只调 switch_history_view
              会让下拉框仍显示「本地记录」；已在在线视图时再直接同步一次。
        参数: 无
        返回: 无
        """
        self._goto_tab_by_title("历史记录")
        combo = getattr(self, 'online_view_combo', None)
        if combo is None:
            return
        if combo.currentIndex() != 1:
            combo.setCurrentIndex(1)
        else:
            _tab_history.switch_history_view(self, 1)
        self.statusBar().showMessage("已切换到在线开奖视图")

    # 字号抽屉：Qt.Popup 浮层（不占页面高度）
    def _build_display_drawer(self):
        """功能：构建「显示设置」浮层（按内容自适应，Qt.Popup 无边框）
        说明:
            - 抽屉文字 16px，分组标题 17px 加粗；行内相邻控件净空 12px；
            - 分区字体「单列纵向」：单键区域每块一行，矩阵区域名为一行前缀、
              文字/号码两个维度块上下排列，保证 1180 档窄抽屉内也不重叠；
            - 内容放进纵向滚动区：窄窗口高度不足时滚动，不压缩控件或字号；
            - 全局字号下拉 / A± / 分区字体 / 重置 / 边距沿用现有真实方法；
            - 「当前页」的号码 px / 文字 px 用镜像数字框绑定到页面现有 spin，
              页面角控件隐藏但不销毁，避免改受保护页面文件；
            - 尺寸由内容 sizeHint 决定，_place_display_drawer 再按窗口与历史表夹紧；
            - 不新增任何 [WidgetState] 记忆键，打开/关闭也不写 INI。
        参数: 无
        返回: 无
        """
        self.display_drawer = _DisplayDrawer(self._top_bar, self._on_drawer_hidden)
        self.display_drawer.setObjectName("DisplayDrawerFrame")
        self.display_drawer.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

        # 内容放进纵向滚动区：1180×720 下抽屉左缘必须让开历史表（表右缘约 761），
        # 可用宽度只有约 400；行内间距提到 12px 后各行必须换行，总高超过窗口，
        # 因此用滚动而不是压缩控件或字号来换取空间。
        outer_layout = QVBoxLayout(self.display_drawer)
        outer_layout.setContentsMargins(18, 18, 18, 18)  # 四边留白：含 2px 边框后内容内缩 16px
        outer_layout.setSpacing(0)
        self._drawer_scroll = QScrollArea()
        self._drawer_scroll.setObjectName("DrawerScroll")
        self._drawer_scroll.setWidgetResizable(True)
        self._drawer_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._drawer_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._drawer_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._drawer_scroll.viewport().setAutoFillBackground(False)
        drawer_content = QWidget()
        drawer_content.setObjectName("DrawerContent")
        drawer_content.setAutoFillBackground(False)
        self._drawer_scroll.setWidget(drawer_content)
        outer_layout.addWidget(self._drawer_scroll)

        drawer_layout = QVBoxLayout(drawer_content)
        drawer_layout.setContentsMargins(0, 0, 0, 0)
        drawer_layout.setSpacing(0)

        # ---- 标题行 ----
        title_row = QHBoxLayout()
        title_row.setSpacing(8)
        title_label = QLabel("显示设置")
        title_label.setObjectName("DrawerTitle")
        title_row.addWidget(title_label)
        title_row.addStretch(1)
        close_btn = QPushButton("×")
        close_btn.setFixedSize(36, 36)
        close_btn.setToolTip("收起显示设置")
        close_btn.clicked.connect(self.display_drawer.hide)
        title_row.addWidget(close_btn)
        drawer_layout.addLayout(title_row)
        drawer_layout.addSpacing(12)

        # ---- 全局字号 ----
        global_row = QHBoxLayout()
        global_row.setSpacing(12)
        global_label = QLabel("全局字号")
        global_label.setObjectName("DrawerGroup")
        global_label.setMinimumWidth(72)  # 比文本宽 4px，避免左右零余量在 125% 下被裁
        global_row.addWidget(global_label)

        self.font_combo = QComboBox()
        self.font_combo.setObjectName("FontSizeCombo")
        for size_key in LotteryConfig.FONT_SIZES.keys():
            self.font_combo.addItem(size_key)
        default_index = list(LotteryConfig.FONT_SIZES.keys()).index(self.font_size_key)
        self.font_combo.setCurrentIndex(default_index)
        self.font_combo.setFixedHeight(40)
        self.font_combo.setFixedWidth(144)
        # 全局字号切换信号：沿用原有 _on_font_size_changed（含样式重建与落盘闸门）
        self.font_combo.currentTextChanged.connect(self._on_font_size_changed)
        global_row.addWidget(self.font_combo)

        font_minus_btn = QPushButton("A-")
        font_minus_btn.setFixedSize(48, 38)
        font_minus_btn.setToolTip("全局字号减小一档（Ctrl+滚轮以外的唯一入口）")
        # 全局字号缩小：沿用原有 _decrease_font_size
        font_minus_btn.clicked.connect(self._decrease_font_size)
        global_row.addWidget(font_minus_btn)

        font_plus_btn = QPushButton("A+")
        font_plus_btn.setFixedSize(48, 38)
        font_plus_btn.setToolTip("全局字号放大一档")
        # 全局字号放大：沿用原有 _increase_font_size
        font_plus_btn.clicked.connect(self._increase_font_size)
        global_row.addWidget(font_plus_btn)
        global_row.addStretch(1)
        drawer_layout.addLayout(global_row)
        drawer_layout.addSpacing(12)

        # ---- 当前页 ----
        self.drawer_scope_label = QLabel("当前页：")
        self.drawer_scope_label.setObjectName("DrawerSection")
        drawer_layout.addWidget(self.drawer_scope_label)
        drawer_layout.addSpacing(12)

        page_row = QHBoxLayout()
        # 行内相邻控件净空 12px：32+12+96+12+30+12+96 = 278，窄抽屉也放得下；
        # 「尺寸」放第二行，避免为了塞进一行而压缩按钮或字号。
        page_row.setSpacing(12)
        self._drawer_num_label = QLabel("数字")
        self._drawer_num_label.setMinimumWidth(32)
        self._drawer_num_spin = QSpinBox()
        self._drawer_num_spin.setRange(15, 150)
        self._drawer_num_spin.setSingleStep(1)
        self._drawer_num_spin.setButtonSymbols(QSpinBox.ButtonSymbols.UpDownArrows)
        self._drawer_num_spin.setSuffix(" px")
        self._drawer_num_spin.setFixedWidth(96)
        self._drawer_num_spin.setToolTip("号码字号：下限 15px、上限 150px；可键入后回车，或点上下箭头 ±1")
        self._drawer_text_label = QLabel("文字")
        self._drawer_text_label.setMinimumWidth(30)
        self._drawer_text_spin = QSpinBox()
        self._drawer_text_spin.setRange(15, 150)
        self._drawer_text_spin.setSingleStep(1)
        self._drawer_text_spin.setButtonSymbols(QSpinBox.ButtonSymbols.UpDownArrows)
        self._drawer_text_spin.setSuffix(" px")
        self._drawer_text_spin.setFixedWidth(96)
        self._drawer_text_spin.setToolTip("文字字号：下限 15px（不可破）、上限 150px；可键入后回车，或点上下箭头 ±1")
        self._drawer_size_btn = QPushButton("尺寸")
        self._drawer_size_btn.setFixedSize(76, 38)
        self._drawer_size_btn.setToolTip("打开当前页的面板尺寸设置")
        self._drawer_empty_label = QLabel("本页无独立号码/文字字号")
        for _w in (self._drawer_num_label, self._drawer_num_spin,
                   self._drawer_text_label, self._drawer_text_spin):
            page_row.addWidget(_w)
        page_row.addStretch(1)
        drawer_layout.addLayout(page_row)
        size_row = QHBoxLayout()
        size_row.setSpacing(12)
        size_row.addWidget(self._drawer_size_btn)
        size_row.addWidget(self._drawer_empty_label)
        size_row.addStretch(1)
        drawer_layout.addLayout(size_row)
        drawer_layout.addSpacing(12)

        # 镜像数字框 → 页面真实 spin（真实 spin 的信号会驱动页面重绘）
        self._drawer_sync_flag = False
        self._drawer_num_target = None
        self._drawer_text_target = None
        self._drawer_size_handler = None
        self._drawer_num_spin.valueChanged.connect(self._on_drawer_num_changed)
        self._drawer_text_spin.valueChanged.connect(self._on_drawer_text_changed)
        self._drawer_size_btn.clicked.connect(self._on_drawer_size_clicked)

        drawer_layout.addWidget(self._drawer_separator())
        drawer_layout.addSpacing(12)

        # ---- 分区字体（单列纵向：每区域一行，文字/号码横向并排） ----
        area_title = QLabel("分区字体")
        area_title.setObjectName("DrawerGroup")
        drawer_layout.addWidget(area_title)
        drawer_layout.addSpacing(12)
        self._drawer_area_pct = {}
        areas_col = QVBoxLayout()
        areas_col.setSpacing(8)
        # 单键区域每块一行（行内间距 12px）；并排两块需要 444px，会超出窄抽屉。
        for _label, _area in (("表格", "table"), ("预测", "result"),
                              ("列表", "list"), ("公告", "announcement")):
            _pair_row = QHBoxLayout()
            _pair_row.setSpacing(12)
            self._drawer_area_block(_pair_row, _label, _area)
            _pair_row.addStretch(1)
            areas_col.addLayout(_pair_row)
        for _label, _text_area, _num_area in (
                ("数字", "number_panel_text", "number_panel_num"),
                ("生肖", "zodiac_panel_text", "zodiac_panel_num"),
                ("五行", "element_panel_text", "element_panel_num"),
                ("属性", "attr_panel_text", "attr_panel_num")):
            self._drawer_region_row(areas_col, _label, _text_area, _num_area)
        drawer_layout.addLayout(areas_col)

        drawer_layout.addSpacing(12)
        drawer_layout.addWidget(self._drawer_separator())
        drawer_layout.addSpacing(12)

        # ---- 底部操作 ----
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(12)
        reset_btn = QPushButton("重置所有字体")
        reset_btn.setFixedSize(148, 36)
        # 重置所有字体：沿用原有 _reset_all_font_sizes
        reset_btn.clicked.connect(self._on_drawer_reset_fonts)
        bottom_row.addWidget(reset_btn)
        margin_btn = QPushButton("边距设置")
        margin_btn.setFixedSize(112, 36)
        # 边距设置：沿用原有 _show_margin_dialog
        margin_btn.clicked.connect(self._show_margin_dialog)
        bottom_row.addWidget(margin_btn)
        bottom_row.addStretch(1)
        drawer_layout.addLayout(bottom_row)
        # 两个按钮（148+112）+ 12px 净空已占 272px，提示文字再同一行会挤掉右侧留白；
        # 提示单独一行右对齐，按钮行只保留两个固定宽度按钮。
        hint = QLabel("浮层 · 不占高度")
        hint.setObjectName("DrawerHint")
        drawer_layout.addWidget(hint, 0, Qt.AlignmentFlag.AlignRight)

        drawer_layout.addStretch(1)
        self._refresh_drawer_area_labels()
        # 页面右上角原有字号角控件收进抽屉：只隐藏，不销毁、不改对象名
        self._hide_page_corner_font_controls()

    def _drawer_separator(self):
        """功能：抽屉内 1px 分隔线（沿用主题 border 令牌）
        参数: 无
        返回: QFrame（高 1px）
        """
        line = QFrame()
        line.setObjectName("DrawerSeparator")
        line.setFrameShape(QFrame.Shape.NoFrame)
        line.setFixedHeight(1)
        return line

    def _drawer_area_block(self, layout, label, area):
        """功能：单键区域块「名称 A- 百分比 A+」（行高 36px、相邻净空 12px）
        参数:
            layout: 承载块的水平布局
            label: 区域短名（表格/预测/列表/公告）
            area: _area_font_scales 的键
        返回: 无
        """
        name = QLabel(label)
        name.setObjectName("DrawerAreaName")
        name.setMinimumWidth(52)
        minus = QPushButton("A-")
        minus.setFixedSize(40, 32)
        minus.setToolTip(label + "字体缩小一档")
        pct = QLabel("100%")
        pct.setFixedWidth(50)
        pct.setAlignment(Qt.AlignmentFlag.AlignCenter)
        plus = QPushButton("A+")
        plus.setFixedSize(40, 32)
        plus.setToolTip(label + "字体放大一档")
        layout.addWidget(name)
        # 与下方区域行共用同一列宽：名称 52 + 维度列 52 + A- 40 + 读数列 + A+ 40，
        # 列间距 12；单键行没有维度列，用 52px 空标签占位（spacer 不会产生两侧
        # 12px 间距，会让 A- 比区域行左移 12px，故这里用空标签）。
        gap = QLabel("")
        gap.setFixedWidth(52)
        layout.addWidget(gap)
        layout.addWidget(minus)
        layout.addWidget(pct)
        # 读数与 A+ 之间至少留 12px，避免像素读数被按钮压住
        layout.addSpacing(12)
        layout.addWidget(plus)
        minus.clicked.connect(lambda: self._on_drawer_area_font(area, -1))
        plus.clicked.connect(lambda: self._on_drawer_area_font(area, 1))
        self._drawer_area_pct[area] = pct

    def _drawer_region_row(self, layout, label, text_area, num_area):
        """功能：矩阵区域行「区域名 | 文字 A- % A+ | 号码 A- % A+」（行高 30px）
        参数:
            layout: 竖向布局（每区域占一行）
            label: 区域中文名（数字/生肖/五行/属性）
            text_area: 文字缩放键
            num_area: 号码缩放键
        返回: 无
        """
        row = QHBoxLayout()
        # 每维度块：维度列 52 + A- 40 + 读数 50 + A+ 40，列间距 12；与单键行完全对齐。
        row.setSpacing(12)
        name = QLabel(label)
        name.setObjectName("DrawerAreaName")
        name.setMinimumWidth(52)
        row.addWidget(name)
        dim_col = QVBoxLayout()
        dim_col.setSpacing(8)
        for _dim, _area in (("文字", text_area), ("号码", num_area)):
            dim_line = QHBoxLayout()
            dim_line.setSpacing(12)
            self._drawer_dim_block(dim_line, _dim, _area)
            dim_line.addStretch(1)
            dim_col.addLayout(dim_line)
        row.addLayout(dim_col)
        row.addStretch(1)
        layout.addLayout(row)

    def _drawer_dim_block(self, row, dim_label, area):
        """功能：矩阵区域的单维度块「文/号 标注 + A- + 百分比 + A+」
        参数:
            row: 该区域行的水平布局
            dim_label: 「文字」或「号码」
            area: _area_font_scales 的键
        返回: 无
        """
        tag = QLabel(dim_label)
        tag.setObjectName("DrawerAreaName")
        tag.setMinimumWidth(52)
        tag.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        minus = QPushButton("A-")
        minus.setFixedSize(40, 32)
        minus.setToolTip(dim_label + "字号缩小一档")
        pct = QLabel("100%")
        # 读数固定列宽：按最宽读数（150px / 150%）字体度量 + 12px 净空，由
        # _fit_drawer_label_widths 在字体生效后统一校准，上下两组一致。
        pct.setFixedWidth(50)
        pct.setAlignment(Qt.AlignmentFlag.AlignCenter)
        plus = QPushButton("A+")
        plus.setFixedSize(40, 32)
        plus.setToolTip(dim_label + "字号放大一档")
        row.addWidget(tag)
        row.addWidget(minus)
        row.addWidget(pct)
        # 读数与 A+ 之间至少留 12px，避免「18px/34px」被按钮压住
        row.addSpacing(12)
        row.addWidget(plus)
        minus.clicked.connect(lambda: self._on_drawer_area_font(area, -1))
        plus.clicked.connect(lambda: self._on_drawer_area_font(area, 1))
        self._drawer_area_pct[area] = pct

    def _refresh_drawer_area_labels(self):
        """功能：把分区字体百分比标签同步为当前缩放值
        参数: 无
        返回: 无
        """
        if not hasattr(self, '_drawer_area_pct'):
            return
        size = getattr(self, '_attr_panel_size', None) or {}
        for area, label in self._drawer_area_pct.items():
            # 矩阵 8 键以 PX 为权威，标签直接显示真实像素，避免 >2 倍时百分比失真
            if area.endswith('_text'):
                label.setText('%dpx' % int(size.get('label_font', 15)))
            elif area.endswith('_num'):
                label.setText('%dpx' % int(size.get('btn_font', 28)))
            else:
                scale = self._area_font_scales.get(area, 1.0)
                label.setText(str(int(round(scale * 100))) + "%")

    def _on_drawer_area_font(self, area, direction):
        """功能：抽屉内分区字体 A± 的槽（调用现有 _change_area_font_size 后刷新标签）
        参数:
            area: 分区名
            direction: 1 放大 / -1 缩小
        返回: 无
        """
        self._change_area_font_size(area, direction)
        self._refresh_drawer_area_labels()

    def _on_drawer_reset_fonts(self):
        """功能：抽屉内「重置所有字体」的槽（调用现有重置方法后刷新标签）
        参数: 无
        返回: 无
        """
        self._reset_all_font_sizes()
        self._refresh_drawer_area_labels()

    def _on_drawer_num_changed(self, value):
        """功能：抽屉数字 px 镜像框变化 → 写回当前页真实 spin
        参数:
            value: 新字号（px）
        返回: 无
        """
        if self._drawer_sync_flag or self._drawer_num_target is None:
            return
        self._drawer_num_target.setValue(value)

    def _on_drawer_text_changed(self, value):
        """功能：抽屉文字 px 镜像框变化 → 写回当前页真实 spin
        参数:
            value: 新字号（px）
        返回: 无
        """
        if self._drawer_sync_flag or self._drawer_text_target is None:
            return
        self._drawer_text_target.setValue(value)

    def _on_drawer_size_clicked(self):
        """功能：抽屉「尺寸」按钮 → 当前页的面板尺寸弹窗
        参数: 无
        返回: 无
        """
        if self._drawer_size_handler is not None:
            self._drawer_size_handler()

    def _mirror_drawer_spin(self, value):
        """功能：页面真实 spin 变化 → 同步抽屉镜像框（阻塞信号防回环）
        参数:
            value: 新字号（px）
        返回: 无
        """
        sender = self.sender()
        proxy = None
        if sender is self._drawer_num_target:
            proxy = self._drawer_num_spin
        elif sender is self._drawer_text_target:
            proxy = self._drawer_text_spin
        if proxy is None:
            return
        self._drawer_sync_flag = True
        proxy.blockSignals(True)
        proxy.setValue(value)
        proxy.blockSignals(False)
        self._drawer_sync_flag = False

    def _show_drawer_page_controls(self, num_spin, text_spin, size_handler):
        """功能：绑定当前页字号控件并显示镜像行（无控件页显示提示文字）
        参数:
            num_spin: 页面号码字号 spin（可为 None）
            text_spin: 页面文字字号 spin（可为 None）
            size_handler: 「尺寸」按钮回调（可为 None）
        返回: 无
        """
        # 先断开旧目标的镜像连接，避免旧页面继续回写同一个镜像框
        for _spin in (self._drawer_num_target, self._drawer_text_target):
            if _spin is not None:
                try:
                    _spin.valueChanged.disconnect(self._mirror_drawer_spin)
                except (TypeError, RuntimeError):
                    pass
        self._drawer_num_target = num_spin
        self._drawer_text_target = text_spin
        self._drawer_size_handler = size_handler
        if num_spin is not None:
            num_spin.valueChanged.connect(self._mirror_drawer_spin)
        if text_spin is not None:
            text_spin.valueChanged.connect(self._mirror_drawer_spin)
        has_controls = num_spin is not None and text_spin is not None
        for _w in (self._drawer_num_label, self._drawer_num_spin,
                   self._drawer_text_label, self._drawer_text_spin,
                   self._drawer_size_btn):
            _w.setVisible(has_controls)
        self._drawer_empty_label.setVisible(not has_controls)
        if has_controls:
            self._drawer_sync_flag = True
            self._drawer_num_spin.blockSignals(True)
            self._drawer_num_spin.setValue(num_spin.value())
            self._drawer_num_spin.blockSignals(False)
            self._drawer_text_spin.blockSignals(True)
            self._drawer_text_spin.setValue(text_spin.value())
            self._drawer_text_spin.blockSignals(False)
            self._drawer_sync_flag = False

    def _hide_page_corner_font_controls(self):
        """功能：隐藏页面右上角原有的「数字/文字/尺寸」控件组（控件保留、只隐藏）
        说明:
            预测页角控件通过 QTabWidget.setCornerWidget 设置，属性页是标题行里的
            40px 容器；这里只 hide，不销毁、不改对象名，抽屉里的镜像框仍可双向同步。
        参数: 无
        返回: 无
        """
        tabs = getattr(self, 'pred_right_tabs', None)
        if tabs is not None:
            corner = tabs.cornerWidget(Qt.Corner.TopRightCorner)
            if corner is not None:
                corner.hide()
        spin = getattr(self, 'attr_num_font_spin', None)
        if spin is not None:
            box = spin.parentWidget()
            if box is not None and box is not getattr(self, 'tabs', None):
                try:
                    box.hide()
                except Exception:
                    pass

    def _sync_display_drawer_page(self):
        """功能：按当前选项卡刷新抽屉「当前页」控件绑定
        参数: 无
        返回: 无
        """
        if self.display_drawer is None or not hasattr(self, 'tabs'):
            return
        index = self.tabs.currentIndex()
        title = self.tabs.tabText(index) if 0 <= index < self.tabs.count() else ""
        self.drawer_scope_label.setText("当前页：" + (title or "未知"))
        if title == "预测与抽取":
            self._show_drawer_page_controls(
                getattr(self, 'pred_num_font_spin', None),
                getattr(self, 'pred_text_font_spin', None),
                lambda: _tab_prediction.show_panel_settings_dialog(self))
        elif title == "号码属性":
            self._show_drawer_page_controls(
                getattr(self, 'attr_num_font_spin', None),
                getattr(self, 'attr_text_font_spin', None),
                lambda: _tab_attr.show_panel_settings_dialog(self))
        else:
            self._show_drawer_page_controls(None, None, None)

    def _fit_drawer_label_widths(self):
        """功能：字体生效后校准抽屉标签与读数列宽（像素级，不靠布局间距猜）
        说明:
            标签分配宽必须 ≥ 文字需宽，并被 A− 左边界撑开；读数列按最宽读数
            （100% / 117% / 150% / 150px）的字体度量 + 12px 统一固定，
            让单键行与区域行的 A− / 读数 / A+ 三列严格对齐且不截断。
        参数: 无
        返回: 无
        """
        drawer = self.display_drawer
        if drawer is None:
            return
        labels = [x for x in drawer.findChildren(QLabel)
                  if x.objectName() == 'DrawerAreaName']
        pcts = [x for x in getattr(self, '_drawer_area_pct', {}).values() if x is not None]
        for lab in labels + pcts:
            lab.ensurePolished()
        if pcts:
            fm = QFontMetrics(pcts[0].font())
            need = max(fm.horizontalAdvance(t)
                       for t in ('100%', '117%', '150%', '150px')) + 12
            for lab in pcts:
                lab.setFixedWidth(max(50, need))
        for lab in labels:
            fm = QFontMetrics(lab.font())
            need = fm.horizontalAdvance(lab.text()) + 12
            if lab.minimumWidth() < need:
                lab.setMinimumWidth(need)

    def _place_display_drawer(self):
        """功能：按内容自适应抽屉尺寸，右缘锚定、向左生长并按窗口/历史表夹紧
        说明:
            宽度取内容布局最小宽与 sizeHint 的较大值，右缘固定在窗口右侧 4px；
            若当前页历史表可见，左缘至少离开表右缘 8px，避免遮住表首行。
            高度取内容 sizeHint，y 固定 92（选项卡栏底 85 + 7）；超过窗口可用
            高度时收窄高度并让内容纵向滚动，不压缩控件或字号。
            宽/高/x/y 一律向下对齐到 4 的倍数：100% 整数，125%/150% 也不落半像素。
        参数: 无
        返回: 无
        """
        drawer = self.display_drawer
        if drawer is None:
            return
        self._fit_drawer_label_widths()
        scroll = getattr(self, '_drawer_scroll', None)
        content = scroll.widget() if scroll is not None else None
        hint_w, hint_h = 400, 600
        if content is not None and content.layout() is not None:
            content.layout().activate()
            hint_w = max(int(content.layout().minimumSize().width()),
                         int(content.sizeHint().width()))
            hint_h = max(int(content.sizeHint().height()),
                         int(content.layout().minimumSize().height()))
        outer = drawer.layout()
        margins = outer.contentsMargins() if outer is not None else None
        pad_x = (margins.left() + margins.right()) if margins is not None else 36
        pad_y = (margins.top() + margins.bottom()) if margins is not None else 36
        right_edge = self.width() - 4
        left_limit = max(8, int(getattr(self, 'margin_left', 8)))
        max_h = max(240, self.height() - 92 - 12)
        # 内容高于可用高度时会出现纵向滚动条，宽度要为滚动条留出位置
        sb_w = 0
        if scroll is not None and hint_h + pad_y > max_h:
            sb_w = int(scroll.verticalScrollBar().sizeHint().width())
            if sb_w <= 0:
                sb_w = 16
        width = int(hint_w + pad_x + sb_w + 4)
        # 不遮挡当前页的历史表首行：左缘至少离开表右缘 8px
        table = getattr(self, 'history_table', None)
        if table is not None and table.isVisible():
            try:
                table_right = table.mapTo(self, QPoint(0, 0)).x() + table.viewport().width()
            except Exception:
                table_right = 0
            if table_right > 0:
                limit_x = int(table_right) + 8
                if right_edge - limit_x >= 280:
                    width = min(width, right_edge - limit_x)
        width = min(width, max(280, right_edge - left_limit))
        height = min(int(hint_h + pad_y), int(max_h))
        height = max(240, height)
        # 触到可用高度时向下取整，保证 y + h ≤ 窗口高 − 12
        height = (height // 4) * 4
        width = max(280, width)
        width = width - width % 4
        x_window = right_edge - width
        y_window = 92
        if x_window + width > self.width() - 4:
            x_window = max(4, self.width() - 4 - width)
        if y_window + height > self.height() - 12:
            y_window = max(8, self.height() - 12 - height)
        x_window = int(x_window) - int(x_window) % 4
        y_window = int(y_window) - int(y_window) % 4
        drawer.setFixedSize(int(width), int(height))
        drawer.move(self.mapToGlobal(QPoint(int(x_window), int(y_window))))

    def _open_display_drawer(self):
        """功能：打开字号抽屉（菜单「视图·显示设置」与顶栏入口共用）
        参数: 无
        返回: 无
        """
        if self.display_drawer is None:
            return
        self._sync_display_drawer_page()
        self._place_display_drawer()
        if hasattr(self, 'display_drawer_btn') and not self.display_drawer_btn.isChecked():
            self.display_drawer_btn.setChecked(True)
        self.display_drawer.show()
        # 样式表字体在 show/polish 后才生效，需按真实字体度量再校准一次列宽
        self._fit_drawer_label_widths()
        self._place_display_drawer()

    def _toggle_display_drawer(self, checked):
        """功能：顶栏「显示设置」按钮点击槽（展开 / 收起）
        参数:
            checked: 按钮当前是否勾选
        返回: 无
        """
        if checked:
            self._open_display_drawer()
        elif self.display_drawer is not None:
            self.display_drawer.hide()

    def _on_drawer_hidden(self):
        """功能：抽屉被外部点击/Esc/切页关闭后，把入口按钮复位为非展开态
        参数: 无
        返回: 无
        """
        btn = getattr(self, 'display_drawer_btn', None)
        if btn is not None and btn.isChecked():
            btn.blockSignals(True)
            btn.setChecked(False)
            btn.blockSignals(False)

    def _update_display_drawer_btn_text(self):
        """功能：让顶栏入口文字跟随当前全局字号档位（如「标准」→「二号」）
        参数: 无
        返回: 无
        """
        btn = getattr(self, 'display_drawer_btn', None)
        if btn is not None:
            btn.setText("显示设置 · " + str(self.font_size_key) + " ▾")
    
    # 功能10：快捷操作面板 - 操作方法
    def _on_batch_export_reports(self):
        """功能：批量导出报告（窗口只负责触发与提示，HTML 生成由 lib.report_builder 负责）
        注意：先弹确认框再弹目录选择框（均为阻塞式模态），用户任一步取消都不会产生文件；
              写盘由 write_algorithm_reports 逐文件完成，单个算法失败被跳过、不影响其余。
        参数:
            无
        返回:
            无（结果以消息框与状态栏提示呈现）
        """
        reply = QMessageBox.question(self, "确认", "确定要导出所有21个算法的HTML报告吗？",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        
        dir_path = QFileDialog.getExistingDirectory(self, "选择导出目录")
        if not dir_path:
            return
        
        self.statusBar().showMessage("正在生成报告...")
        # 报告模板与逐文件写盘下沉到 lib；单个文件失败仍跳过，不影响其余算法
        write_algorithm_reports(dir_path, LotteryConfig.ALGORITHMS)
        
        QMessageBox.information(self, "导出完成", "已导出" + str(len(LotteryConfig.ALGORITHMS)) + "个算法的HTML报告到:\n" + dir_path)
        self.statusBar().showMessage("批量导出完成")
    
    def _on_validate_number_combo(self):
        """功能：验证号码组合（校验规则由 lib.data_process.DataUtils 提供，窗口只负责触发与提示）
        注意：模态输入框；非数字输入只提示不抛异常；纯校验，不写数据库、不改历史记录。
        参数:
            无（号码由用户在对话框中输入）
        返回:
            无（校验结果以消息框呈现）
        """
        dialog = QInputDialog(self)
        dialog.setWindowTitle("验证号码组合")
        dialog.setLabelText("请输入6个号码（逗号分隔）:")
        dialog.setTextValue("")
        if dialog.exec() == QDialog.DialogCode.Accepted:
            input_text = dialog.textValue().strip()
            try:
                numbers = [int(n.strip()) for n in input_text.split(',')]
            except ValueError:
                QMessageBox.warning(self, "验证失败", "请输入有效的数字，用逗号分隔")
                return
            
            error, stats = DataUtils.validate_number_combo(numbers)
            if error:
                QMessageBox.warning(self, "验证失败", error)
                return
            
            result = "号码组合验证通过！\n\n"
            result += "号码: " + ' '.join(str(n).zfill(2) for n in stats['numbers']) + "\n"
            result += "和值: " + str(stats['sum']) + "\n"
            result += "单双比: " + str(stats['odd']) + ":" + str(stats['even']) + "\n"
            result += "大小比: " + str(stats['big']) + ":" + str(stats['small']) + "\n"
            result += "颜色分布: 红" + str(stats['red']) + " 蓝" + str(stats['blue']) + " 绿" + str(stats['green'])
            
            QMessageBox.information(self, "验证成功", result)

    
    def _on_copy_latest_prediction(self):
        """功能：一键复制预测结果
        注意：直接覆盖系统剪贴板；无预测历史或无号码时只弹提示，不写剪贴板；
              取的是 self.prediction_history 的最后一条（不区分算法与期号）。
        参数:
            无
        返回:
            无
        """
        if not self.prediction_history:
            QMessageBox.information(self, "提示", "没有可复制的预测结果")
            return
        
        latest = self.prediction_history[-1]
        numbers = latest.get('numbers', [])
        if not numbers:
            QMessageBox.information(self, "提示", "没有可复制的预测结果")
            return
        
        text = ' '.join(str(n).zfill(2) for n in sorted(numbers))
        clipboard = QApplication.clipboard()
        clipboard.setText(text)
        QMessageBox.information(self, "复制成功", "预测结果已复制到剪贴板:\n" + text)
    
    def _show_margin_dialog(self):
        """功能：显示边距设置对话框
        注意：模态对话框，点「确定」才把五个数值写回 self.margin_* / self.spacing
              并立刻重建样式表（只改内存，落盘交给统一保存流程）；取消不改任何值。
        参数:
            无（初值取自 self.margin_top/margin_bottom/margin_left/margin_right/spacing）
        返回:
            无
        """
        dialog = QDialog(self)
        dialog.setWindowTitle("边距和间距设置")
        dialog.setFixedSize(400, 300)
        layout = QVBoxLayout(dialog)
        
        top_layout = QHBoxLayout()
        top_layout.addWidget(QLabel("上边距:"))
        top_spin = QSpinBox()
        top_spin.setRange(0, 50)
        top_spin.setValue(self.margin_top)
        top_layout.addWidget(top_spin)
        layout.addLayout(top_layout)
        
        bottom_layout = QHBoxLayout()
        bottom_layout.addWidget(QLabel("下边距:"))
        bottom_spin = QSpinBox()
        bottom_spin.setRange(0, 50)
        bottom_spin.setValue(self.margin_bottom)
        bottom_layout.addWidget(bottom_spin)
        layout.addLayout(bottom_layout)
        
        left_layout = QHBoxLayout()
        left_layout.addWidget(QLabel("左边距:"))
        left_spin = QSpinBox()
        left_spin.setRange(0, 50)
        left_spin.setValue(self.margin_left)
        left_layout.addWidget(left_spin)
        layout.addLayout(left_layout)
        
        right_layout = QHBoxLayout()
        right_layout.addWidget(QLabel("右边距:"))
        right_spin = QSpinBox()
        right_spin.setRange(0, 50)
        right_spin.setValue(self.margin_right)
        right_layout.addWidget(right_spin)
        layout.addLayout(right_layout)
        
        spacing_layout = QHBoxLayout()
        spacing_layout.addWidget(QLabel("区块间距:"))
        spacing_spin = QSpinBox()
        spacing_spin.setRange(0, 50)
        spacing_spin.setValue(self.spacing)
        spacing_layout.addWidget(spacing_spin)
        layout.addLayout(spacing_layout)
        
        layout.addStretch()
        
        btn_layout = QHBoxLayout()
        ok_btn = QPushButton("确定")
        # 确定按钮点击信号：接受对话框并应用边距设置
        ok_btn.clicked.connect(dialog.accept)
        cancel_btn = QPushButton("取消")
        # 取消按钮点击信号：拒绝对话框，不保存更改
        cancel_btn.clicked.connect(dialog.reject)
        btn_layout.addWidget(ok_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.margin_top = top_spin.value()
            self.margin_bottom = bottom_spin.value()
            self.margin_left = left_spin.value()
            self.margin_right = right_spin.value()
            self.spacing = spacing_spin.value()
            self._update_stylesheet()
            QMessageBox.information(self, "成功", "边距设置已更新")
    
    def _create_tabs(self, parent_layout):
        """功能：创建标签页
        说明：页面由 TAB 包自动发现——TAB/xxx.py 声明 TAB_INFO（title/order/enabled）
              并导出 build(host)，即自动出现在选项卡栏，本文件无需再逐页登记。
        参数: parent_layout - 主窗口布局容器
        返回: 无
        """
        self.tabs = QTabWidget()
        self.tabs.setObjectName("MainTabs")
        self.tabs.setMovable(True)
        self.tabs.setDocumentMode(True)
        self.tabs.setUsesScrollButtons(True)

        # 按 TAB_INFO["order"] 升序加载全部页面（新增/停用页面均不改本文件）
        for _order, title, module in iter_tab_pages():
            # v0.0.28 起优先调用 install(host)：页面自带布局与事件绑定
            builder = getattr(module, 'install', None) or module.build
            page = builder(self)
            self.tabs.addTab(page, title)

        # 【自适应布局】为每个选项卡页面套滚动容器：窗口缩小时可滚动，控件不重叠
        self._wrap_tabs_in_scroll()

        # 【选项卡顺序记忆】默认顺序仍由 TAB_INFO["order"] 决定；[Display] tab_order
        # 存在（用户真实拖动过）时记忆优先。恢复过程只重排内存顺序，不写盘。
        self._restore_tab_order_from_ini()
        self.tabs.tabBar().tabMoved.connect(self._on_tab_moved)

        parent_layout.addWidget(self.tabs)

    def _wrap_tabs_in_scroll(self):
        """功能：为所有选项卡页面套一层滚动容器
        说明：页面内容的最小尺寸大于可视区域时自动出现滚动条，避免控件互相挤压、
              文字截断或重叠；本身已是 QScrollArea 的页面不重复包装。
        参数: 无
        返回: 无
        """
        for i in range(self.tabs.count()):
            page = self.tabs.widget(i)
            if page is None or isinstance(page, QScrollArea):
                continue
            title = self.tabs.tabText(i)
            # 必须先从选项卡移除页面，再交给滚动容器：
            # 否则 setWidget 重设父级时 QStackedWidget 会自动移除该页面所属选项卡，
            # 随后 removeTab 又会误删下一个选项卡，最终选项卡数量减半
            self.tabs.removeTab(i)
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QScrollArea.Shape.NoFrame)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
            scroll.setWidget(page)
            self.tabs.insertTab(i, scroll, title)

    def _tab_titles(self):
        """功能：按显示顺序返回当前全部选项卡标题
        参数: 无
        返回: list[str]，长度等于 tabs.count()
        """
        return [self.tabs.tabText(i) for i in range(self.tabs.count())]

    def _tab_index_by_title(self, title):
        """功能：按标题查找选项卡索引（顺序变化后用它找回同一页）
        参数: title - 选项卡标题；空标题返回 -1
        返回: int，找不到时为 -1
        """
        if not title:
            return -1
        for i in range(self.tabs.count()):
            if self.tabs.tabText(i) == title:
                return i
        return -1

    def _restore_tab_order_from_ini(self):
        """功能：按 [Display] tab_order 恢复用户拖动过的选项卡顺序（启动期只读）
        规则：
            - 默认顺序仍由 TAB_INFO["order"] 决定；有记忆时记忆优先；
            - 记忆里多出的标题（页面已删/改名）直接忽略，不报错；
            - 记忆里缺失的页（新增页）按默认顺序追加到末尾；
            - 恢复只重排内存，构造期 _ini_write_enabled 仍为 False，不写盘。
        参数: 无
        返回: 无
        """
        raw = ''
        if hasattr(self, '_ini') and self._ini.has_section('Display'):
            raw = str(self._ini['Display'].get('tab_order', '') or '').strip()
        saved = [t.strip() for t in raw.split('|') if t.strip()] if raw else []
        current = self._tab_titles()
        # 先记住「上次停在哪一页」的标题：current_tab_index 保存时对应的是“记忆顺序”，
        # 所以优先从 tab_order 的同位标题取；无记忆时才按默认顺序取标题。
        self._ini_start_tab_title = ''
        start_index = getattr(self, '_ini_start_tab_index', 0)
        if 0 <= start_index < len(saved) and saved[start_index] in current:
            self._ini_start_tab_title = saved[start_index]
        elif 0 <= start_index < len(current):
            self._ini_start_tab_title = current[start_index]
        if not saved:
            return
        ordered = [t for t in saved if t in current]
        ordered += [t for t in current if t not in ordered]
        if len(ordered) != len(current) or ordered == current:
            return
        pages = {t: self.tabs.widget(i) for i, t in enumerate(current)}
        active = self.tabs.currentWidget()
        self._restoring_tab_order = True
        try:
            # 用 removeTab/insertTab 重排：tabBar().moveTab 只动标签条，页面栈不会跟着换位
            for _ in range(self.tabs.count()):
                self.tabs.removeTab(0)
            for i, title in enumerate(ordered):
                self.tabs.insertTab(i, pages[title], title)
        finally:
            self._restoring_tab_order = False
        if active is not None:
            idx = self.tabs.indexOf(active)
            if idx >= 0:
                self.tabs.setCurrentIndex(idx)
        print("选项卡顺序已恢复: " + " | ".join(ordered))

    def _on_tab_moved(self, from_index, to_index):
        """功能：用户拖动选项卡后保存标题序列（标题而非索引，避免增删页后错位）
        说明：只在写盘闸门打开后（真实拖动）落盘；恢复重排期间与启动期一律跳过。
        参数: from_index/to_index - Qt tabMoved 信号参数，仅用于状态提示
        返回: 无
        """
        if getattr(self, '_restoring_tab_order', False):
            return
        if not getattr(self, '_ini_write_enabled', False):
            return
        if not hasattr(self, '_ini') or not self._ini.has_section('Display'):
            return
        self._ini['Display']['tab_order'] = '|'.join(self._tab_titles())
        self._save_ini_config()
        try:
            self.statusBar().showMessage("选项卡顺序已保存（%d→%d）" % (from_index + 1, to_index + 1))
        except Exception:
            pass
    

    # [全局样式] 主题样式表、亮色/暗色模式

    def _create_status_bar(self):
        """功能：创建状态栏
        注意：状态栏本体由 QMainWindow.statusBar() 懒创建；data_count_label 作为
              永久部件常驻右侧，文字由 _load_data 等流程刷新，本方法只置初值。
        参数:
            无
        返回:
            无
        """
        self.statusBar().showMessage("就绪 | 准备预测...")
        self.data_count_label = QLabel("历史记录: 0 条")
        self.statusBar().addPermanentWidget(self.data_count_label)
        # 降级模式确认入口：默认隐藏，JSON 损坏进入降级模式后常驻状态栏，
        # 不用弹窗打断启动；点击后解除降级标志并立即真实保存。
        self.degraded_confirm_btn = QPushButton("我已确认，可用当前数据覆盖")
        self.degraded_confirm_btn.setObjectName("DegradedConfirmBtn")
        self.degraded_confirm_btn.setToolTip(
            "仅在数据文件损坏的降级模式下出现；点击表示确认用当前内存数据覆盖磁盘与数据库")
        self.degraded_confirm_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.degraded_confirm_btn.setVisible(False)
        self.degraded_confirm_btn.clicked.connect(self._on_confirm_degraded_overwrite)
        self.statusBar().addPermanentWidget(self.degraded_confirm_btn)
    
    def _apply_stylesheet(self):
        """功能：清空当前样式表后整体重建（主题/字号变更后调用）
        注意：必须先 setStyleSheet("") 再重建，否则旧规则会与新规则叠加导致
              颜色/边框残留；只作用于主窗口这一层，不覆盖子控件自带的样式表。
        参数:
            无
        返回:
            无
        """
        # 先清空当前样式表，再重新构建并应用（确保主题切换时旧样式不残留）
        self.setStyleSheet("")
        self._update_stylesheet()
    

    def _update_stylesheet(self):
        """功能：按当前主题与字号拼接并应用全局样式表
        注意：会整体替换主窗口 QSS（含全局字号、表格、滚动条、状态栏等规则），
              并把同一套小字号样式回写到三个预测类型按钮；字号硬下限 15px；
              只改内存，不写 INI，也不触发写盘闸门。
        参数:
            无（取 self.is_dark_mode 与 self.font_size_key）
        返回:
            无
        """
        font_size = min(LotteryConfig.FONT_SIZES.get(self.font_size_key, LotteryConfig.TEXT_DEFAULT_PX),
                        LotteryConfig.TEXT_MAX_PX)
        # v0.0.36 硬性下限：全局字号与派生小字号都不得低于 15px，防止文字过小看不清
        font_size = max(15, font_size)
        small_font_size = max(15, font_size - 4)
        large_font_size = min(LotteryConfig.TEXT_MAX_PX, font_size + 4)
        if self.is_dark_mode:
            bg = "#1E1E2E"
            # v0.0.48：暗色正文接近纯白（原 #CDD6F4 偏灰），提升对比度
            fg = "#F5F5F5"
            card = "#313244"
            accent = "#89B4FA"
            success = "#A6E3A1"
            border = "#45475A"
            hover_bg = "#45475A"
            pressed_bg = "#585B70"
            header_bg = "#313244"
            input_bg = "#313244"
        else:
            bg = "#FFFFFF"
            # v0.0.48：亮色正文改为接近纯黑（原 #000000 纯黑，统一到 #1A1A1A）
            fg = "#1A1A1A"
            card = "#FFFFFF"
            accent = "#3498DB"
            success = "#2ECC71"
            border = "#DDDDDD"
            hover_bg = "#F8F9FA"
            pressed_bg = "#E8E8E8"
            header_bg = "#F8F9FA"
            input_bg = "#FFFFFF"
        # 全局样式表构建 - 根据当前主题（亮色/暗色）和字号动态拼接CSS
        # 各选择器说明：
        #   QWidget {}                  全局基础样式：背景色、文字色、字号、字体族
        #   #TopBar {}                  顶部工具栏：背景色 + 底部分隔线
        #   QPushButton {}              按钮常态：卡片背景 + 边框 + 圆角 + 内边距
        #   QPushButton:hover {}        按钮悬停：高亮背景 + 主题色边框
        #   QPushButton:pressed {}      按钮按下：深色背景
        #   QTabWidget::pane {}         标签页容器：边框 + 背景
        #   QTabBar::tab {}             标签页常态：卡片背景 + 边框 + 内边距
        #   QTabBar::tab:selected {}    标签页选中：主题色背景 + 白字
        #   QTabBar::tab:hover {}       标签页悬停：高亮背景
        #   QTextEdit, QLineEdit {}     文本输入框：输入背景 + 边框 + 圆角
        #   QTextEdit:focus {}          输入框聚焦：主题色边框
        #   QComboBox {}                下拉框：卡片背景 + 边框 + 圆角
        #   QComboBox:hover {}          下拉框悬停：主题色边框
        #   #PanelTitle {}              面板标题：主题色 + 粗体 + 底部分隔线
        #   QTableWidget {}             表格整体：背景 + 边框 + 圆角
        #   QTableWidget::item {}       表格单元格：内边距
        #   QTableWidget::item:selected{} 表格选中行：主题色背景
        #   QTableWidget::header::section{} 表头：背景 + 粗体 + 边框
        #   QScrollBar:vertical {}      垂直滚动条轨道：背景 + 宽度
        #   QScrollBar::handle:vertical{}  滚动条滑块：圆角 + 最小高度
        #   QScrollBar::handle:vertical:hover{} 滑块悬停：主题色
        #   QScrollBar:horizontal {}    水平滚动条轨道：背景 + 高度
        #   QScrollBar::handle:horizontal{} 水平滑块：圆角 + 最小宽度
        #   QSplitter::handle {}        分割条：背景色
        #   QSplitter::handle:hover {}  分割条悬停：主题色
        #   QScrollArea {}              滚动区域：背景 + 边框 + 圆角
        #   #PredictionDisplay {}       预测结果显示区：大字号 + 成功色边框
        #   #LatestDisplay {}           最新开奖显示区：主题色边框
        #   #SelectedNumbersLabel {}    已选号码标签：成功色 + 粗体
        #   QStatusBar {}               状态栏：背景 + 顶部边框 + 小字号
        #   #InfoLabel {}               信息标签：小字号 + 边框 + 背景
        #   QSpinBox                    数字输入框样式由 spin_style_qss() 生成
        #   QSlider::groove:horizontal {} 滑块轨道：背景色 + 高度 + 圆角
        #   QSlider::handle:horizontal {} 滑块手柄：主题色 + 宽度 + 圆角
        stylesheet = (
            "QWidget { background-color: " + bg + "; color: " + fg + "; font-size: " + str(font_size) + "px; font-family: \"Microsoft YaHei\", \"SimHei\", \"SimSun\", Arial, sans-serif; font-weight: 500; }"
            " #TopBar { background-color: " + bg + "; border-bottom: 2px solid " + border + "; }"
            " QPushButton { background-color: " + card + "; color: " + fg + "; border: 2px solid " + border + "; border-radius: 6px; padding: 6px 16px; font-size: " + str(small_font_size) + "px; font-weight: 500; min-height: 30px; }"
            " QPushButton:hover { background-color: " + hover_bg + "; border-color: " + accent + "; }"
            " QPushButton:pressed { background-color: " + pressed_bg + "; }"
            " QTabWidget::pane { border: 1px solid " + border + "; background-color: " + bg + "; }"
            " QTabBar::tab { background-color: " + card + "; color: " + fg + "; border: 1px solid " + border + "; padding: 6px 18px; margin-right: 2px; font-size: " + str(small_font_size) + "px; font-weight: 500; }"
            " QTabBar::tab:selected { background-color: " + accent + "; color: white; border-color: " + accent + "; font-weight: bold; }"
            " QTabBar::tab:hover { background-color: " + hover_bg + "; }"
            " QTextEdit, QLineEdit { background-color: " + input_bg + "; color: " + fg + "; border: 2px solid " + border + "; border-radius: 4px; padding: 8px; font-size: " + str(font_size) + "px; font-weight: 500; }"
            " QTextEdit:focus, QLineEdit:focus { border-color: " + accent + "; }"
            " QComboBox { background-color: " + card + "; color: " + fg + "; border: 2px solid " + border + "; border-radius: 4px; padding: 6px 12px; font-size: " + str(small_font_size) + "px; font-weight: 500; min-height: 28px; }"
            " QComboBox:hover { border-color: " + accent + "; }"
            " #PanelTitle { font-size: " + str(font_size) + "px; font-weight: bold; color: " + accent + "; padding: 5px; border-bottom: 1px solid " + border + "; }"
            " QTableWidget { background-color: " + bg + "; color: " + fg + "; border: 1px solid " + border + "; border-radius: 4px; font-size: " + str(small_font_size) + "px; font-weight: 500; }"
            " QTableWidget::item { padding: 5px; }"
            " QTableWidget::item:selected { background-color: " + accent + "; }"
            " QTableWidget::header::section { background-color: " + header_bg + "; color: " + fg + "; padding: 5px; border: 1px solid " + border + "; font-weight: bold; }"
            " QScrollBar:vertical { background-color: " + bg + "; width: 12px; margin: 0px; }"
            " QScrollBar::handle:vertical { background-color: " + border + "; border-radius: 6px; min-height: 30px; }"
            " QScrollBar::handle:vertical:hover { background-color: " + accent + "; }"
            " QScrollBar:horizontal { background-color: " + bg + "; height: 12px; margin: 0px; }"
            " QScrollBar::handle:horizontal { background-color: " + border + "; border-radius: 6px; min-width: 30px; }"
            " QScrollBar::handle:horizontal:hover { background-color: " + accent + "; }"
            " QSplitter::handle { background-color: " + border + "; }"
            " QSplitter::handle:hover { background-color: " + accent + "; }"
            " QScrollArea { background-color: " + bg + "; border: 1px solid " + border + "; border-radius: 4px; }"
            " #PredictionDisplay { font-size: " + str(large_font_size) + "px; font-weight: bold; color: " + success + "; padding: 15px; background-color: " + card + "; border: 2px solid " + success + "; border-radius: 8px; }"
            " #LatestDisplay { font-size: " + str(font_size) + "px; padding: 10px; background-color: " + card + "; border: 2px solid " + accent + "; border-radius: 6px; }"
            " #SelectedNumbersLabel { color: " + success + "; font-weight: bold; }"
            " QStatusBar { background-color: " + bg + "; color: " + fg + "; border-top: 1px solid " + border + "; font-size: " + str(small_font_size) + "px; font-weight: 500; }"
            " #InfoLabel { font-size: " + str(small_font_size) + "px; color: " + fg + "; font-weight: 500; padding: 8px; background-color: " + card + "; border: 1px solid " + border + "; border-radius: 4px; }"
            # 全局数字框统一走 TAB/widgets.spin_style_qss：56px 高（56→125% 为 70、
            # 150% 为 84，不落半像素）、左内边距 8px、右侧 24px 给上下箭头留位；
            # 上下按钮分别定位，替代原来只写 25×25 导致叠置的两条规则。
            + spin_style_qss('QSpinBox', border_color=border, bg=card, fg=fg,
                             height=56, font_px=18, arrow_color=fg) +
            " QSlider::groove:horizontal { background-color: " + border + "; height: 6px; border-radius: 3px; }"
            " QSlider::handle:horizontal { background-color: " + accent + "; width: 16px; margin: -5px 0; border-radius: 8px; }"
            # ---- 顶栏（固定 15px，不跟随全局字号） ----
            " #TopBar QPushButton { font-size: 15px; padding: 4px 8px; min-height: 0px; }"
            " #TopBar QComboBox, #TopBar QSpinBox { font-size: 15px; min-height: 0px; }"
            " #DisplayDrawerBtn { font-size: 15px; padding: 2px 8px; min-height: 0px; }"
            " #DisplayDrawerBtn:checked { background-color: " + accent + "; color: #FFFFFF; border-color: " + accent + "; }"
            # ---- 菜单栏 / 菜单（沿用主题令牌，不另造颜色） ----
            " QMenuBar { background-color: transparent; color: " + fg + "; border: none; padding: 0px; font-size: 15px; }"
            " QMenuBar::item { background: transparent; color: " + fg + "; padding: 5px 8px; border-radius: 4px; }"
            " QMenuBar::item:selected { background-color: " + accent + "; color: #FFFFFF; }"
            " QMenuBar::item:pressed { background-color: " + pressed_bg + "; color: " + fg + "; }"
            " QMenu { background-color: " + card + "; color: " + fg + "; border: 1px solid " + border + "; padding: 4px; font-size: 15px; }"
            " QMenu::item { padding: 6px 22px 6px 14px; border-radius: 4px; }"
            " QMenu::item:selected { background-color: " + accent + "; color: #FFFFFF; }"
            " QMenu::separator { height: 1px; background-color: " + border + "; margin: 4px 8px; }"
            # ---- 字号抽屉（浮层，正文 16px、分组标题 17px Bold） ----
            " #DisplayDrawerFrame { background-color: " + card + "; border: 2px solid " + accent + "; border-radius: 10px; }"
            " #DrawerScroll { background: transparent; border: none; border-radius: 0px; }"
            " #DrawerScroll > QWidget > QWidget { background: transparent; }"
            " #DisplayDrawerFrame QLabel { font-size: 16px; min-height: 28px; background: transparent; }"
            " #DisplayDrawerFrame QPushButton { font-size: 16px; padding: 0px 6px;"
            " min-height: 32px; max-height: 40px; }"
            " #DisplayDrawerFrame QComboBox { font-size: 16px; min-height: 0px; padding: 2px 8px; }"
            # 数字框统一走 TAB/widgets.spin_style_qss（全项目唯一来源）：
            # 40px 高（40→125% 为 50、150% 为 60，不落半像素）、左内边距 8px、
            # 右侧 24px 给上下箭头留位、上下按钮分别定位，不会再叠在同一矩形。
            + spin_style_qss('#DisplayDrawerFrame QSpinBox', border_color=border,
                             bg='transparent', fg=fg, height=40, font_px=16,
                             arrow_color=fg) +
            " #DisplayDrawerFrame #DrawerTitle, #DisplayDrawerFrame #DrawerGroup"
            " { font-size: 17px; font-weight: bold; color: " + fg + "; min-height: 28px; }"
            " #DrawerSection { font-weight: bold; }"
            " #DrawerAreaName { color: " + fg + "; }"
            " #DrawerSeparator { background-color: " + border + "; border: none; }"
        )
        # 将构建好的完整样式表应用到整个主窗口，覆盖所有控件的默认外观
        self.setStyleSheet(stylesheet)
        
        # 动态更新预测类型切换按钮的字体大小（跟随全局字号调整）
        if hasattr(self, 'type_btn_algorithm'):
            type_button_style = """
                QPushButton {
                    background-color: #F0F0F0;
                    color: #666666;
                    border: 1px solid #CCCCCC;
                    border-radius: 4px;
                    padding: 6px 12px;
                    font-size: """ + str(small_font_size) + """px;
                }
                QPushButton:hover {
                    background-color: #E8E8E8;
                }
                QPushButton:checked {
                    background-color: #3498DB;
                    color: white;
                    border-color: #2980B9;
                }
            """
            # 动态更新预测类型切换按钮的样式表（跟随全局字号调整）
            self.type_btn_algorithm.setStyleSheet(type_button_style)
            self.type_btn_random.setStyleSheet(type_button_style)
            self.type_btn_ml.setStyleSheet(type_button_style)
        # 顶栏入口文字随当前档位刷新（启动恢复档位后也会走到这里）
        self._update_display_drawer_btn_text()
    
    def _apply_autosize(self):
        """功能：应用自动大小
        说明：字体随窗口缩放，但限制在 0.85~1.15 倍区间，避免窗口缩小时
              文字过小看不清、窗口放大时文字过大导致控件拥挤重叠。
        注意：以 1600×1000 为基准，字号下限 15px；通过 QApplication.setFont 改
              应用级默认字体，会影响所有已存在的控件（不仅是主窗口）；不写盘。
        参数:
            无（取当前窗口尺寸 self.size() 与 self.font_size_key）
        返回:
            无
        """
        window_size = self.size()
        window_width = window_size.width()
        window_height = window_size.height()
        base_width = 1600
        base_height = 1000
        scale_x = window_width / base_width
        scale_y = window_height / base_height
        scale = min(scale_x, scale_y)
        # 【可改】字体自适应缩放上下限，防止极端窗口尺寸下文字过小或过大
        scale = max(0.85, min(1.15, scale))
        base_font_size = LotteryConfig.FONT_SIZES.get(self.font_size_key, 16)
        # v0.0.36 硬性下限 15px：窗口缩放不再把字体压到 15px 以下
        new_font_size = max(15, int(base_font_size * scale))
        # 使用 FontUtils 统一创建字体（自动选择系统可用字体族），再覆盖缩放后的字号
        font = FontUtils.create_font(self.font_size_key)
        font.setPixelSize(_pt_to_px_96(new_font_size))
        QApplication.instance().setFont(font)
    
    def _on_font_size_changed(self, size_key):
        """功能：字体大小切换事件处理
        注意：QComboBox.currentTextChanged 信号槽；会重建样式表 + 应用缩放 +
              立即写 INI（经写盘闸门 _save_ini_config）；键值非法时会退回默认字号。
        参数:
            size_key: 字号档位键（LotteryConfig.FONT_SIZES 的键，如「中」）
        返回:
            无
        """
        self.font_size_key = size_key
        self._update_stylesheet()
        self._apply_autosize()
        # 全局字号变化后表格字号随之改变，时间列最小宽度需按新字号重算，
        # 否则切到更大字号档位时时间戳两端会被裁掉。
        _tab_prediction.apply_prediction_col_widths(self)
        # 顶栏入口文字随档位变化（显示设置 · 标准 / 二号 …）
        self._update_display_drawer_btn_text()
        # 保存字号选择
        self._save_ini_config()
    
    def _increase_font_size(self):
        """功能：增大字体大小（按档位表上移一级）
        注意：不直接改字号，而是改下拉框当前项（由 currentTextChanged 统一处理）；
              已在最大档时什么都不做，不触发放大重复。
        参数:
            无
        返回:
            无
        """
        keys = list(LotteryConfig.FONT_SIZES.keys())
        current_index = keys.index(self.font_size_key) if self.font_size_key in keys else 3
        if current_index < len(keys) - 1:
            new_key = keys[current_index + 1]
            self.font_combo.setCurrentText(new_key)
    
    def _decrease_font_size(self):
        """功能：减小字体大小（按档位表下移一级）
        注意：同样委托下拉框信号处理；已在最小档时不做任何事；当前键不在档位表
              时按索引 3 作为起点。
        参数:
            无
        返回:
            无
        """
        keys = list(LotteryConfig.FONT_SIZES.keys())
        current_index = keys.index(self.font_size_key) if self.font_size_key in keys else 3
        if current_index > 0:
            new_key = keys[current_index - 1]
            self.font_combo.setCurrentText(new_key)
    
    def _matrix_scale_flags(self):
        """功能：判断矩阵面板「号码 / 文字」两个维度是否仍有非 1.0 缩放
        说明：四个区域键共用同一面板，任一区域号码键非 1.0 即号码维度定制，
              任一区域文字键非 1.0 即文字维度定制；1.0 的维度交回档位默认字号。
        参数:
            无
        返回:
            tuple[bool, bool]: (号码维度是否定制, 文字维度是否定制)
        """
        num_custom = any(
            abs(float(self._area_font_scales.get(area + '_num', 1.0)) - 1.0) > 1e-9
            for area in _MATRIX_SCALE_AREAS)
        text_custom = any(
            abs(float(self._area_font_scales.get(area + '_text', 1.0)) - 1.0) > 1e-9
            for area in _MATRIX_SCALE_AREAS)
        return num_custom, text_custom

    def _effective_matrix_scale(self, dimension):
        """功能：取矩阵面板某维度（text/num）的生效缩放值
        说明：四个区域共用同一面板，按 attr→zodiac→element→number 的优先级取
              第一个非 1.0 值；全部为 1.0 时返回 1.0。仅用于「PX 键缺失」时的
              旧值迁移回填，正常情况下 PX 才是权威值。
        参数:
            dimension (str): 'text' 或 'num'
        返回:
            float: 生效缩放比例
        """
        for area in ('attr_panel', 'zodiac_panel', 'element_panel', 'number_panel'):
            value = float(self._area_font_scales.get(f'{area}_{dimension}', 1.0))
            if abs(value - 1.0) > 1e-9:
                return value
        return 1.0

    def _change_area_font_size(self, area, direction):
        """功能：按区域微调字体（表格/预测结果/列表/数字/生肖/五行/号码属性/公告/详情）
        注意：数字/生肖/五行/号码属性均拆成「文字」「号码」两个独立键，各自只改一个维度；
              改动立即重排对应面板（表格行高、按钮字号）并写状态栏提示，最后调用
              _save_ini_config 落盘（受写盘闸门控制）；未知 area 直接返回；
              缩放范围 0.5~2.0，字号硬下限 15px；回写 spin 时用 blockSignals
              防信号回环。
        参数:
            area: 区域名，'table'|'result'|'list'|'announcement'|'detail'
                  |'number_panel_text'|'number_panel_num'|'zodiac_panel_text'
                  |'zodiac_panel_num'|'element_panel_text'|'element_panel_num'
                  |'attr_panel_text'|'attr_panel_num'
            direction: 1=放大，-1=缩小
        返回:
            无
        """
        if area not in self._area_font_scales:
            return

        # 矩阵四区域的文字/号码维度：以 PX 为权威做 ±10%（至少 1px）步进。
        # 不能再用 scale×基准 28/15 重算——PX 一旦超过基准的 2 倍（文字 >30px、
        # 号码 >56px），一次 A± 会把字号从 40 直接拉回 30，正是用户实测的「跳变」。
        if area.endswith('_text') or area.endswith('_num'):
            _dim = 'text' if area.endswith('_text') else 'num'
            _key = 'label_font' if _dim == 'text' else 'btn_font'
            _size = self._attr_panel_size
            _current = int(_size.get(_key, 15 if _dim == 'text' else 28))
            if direction > 0:
                # 放大 +10%；缩小时按 ÷1.1 取整回到原值，避免「+3 后 -4」的棘轮式漂移
                _new_px = _current + max(1, int(round(_current * 0.1)))
            else:
                _new_px = int(round(_current / 1.1))
            _new_px = max(15, min(150, _new_px))
            _size[_key] = _new_px
            _size['fonts_custom'] = True
            _spin = (self.attr_text_font_spin if _dim == 'text' else self.attr_num_font_spin)
            _spin.blockSignals(True)
            _spin.setValue(_new_px)
            _spin.blockSignals(False)
            _tab_attr._apply_panel_fonts(self)
            _scale = round(min(2.0, max(0.5, _new_px / (15.0 if _dim == 'text' else 28.0))), 3)
            for _mate in _MATRIX_SCALE_AREAS:
                self._area_font_scales[_mate + '_' + _dim] = _scale
            self._refresh_drawer_area_labels()
            self._save_ini_config()
            return

        step = 0.1
        new_scale = self._area_font_scales[area] + direction * step
        # 限制范围：0.5 - 2.0
        new_scale = max(0.5, min(2.0, new_scale))
        self._area_font_scales[area] = new_scale
        # 四个区域共用同一块矩阵面板：同一维度的 4 个键必须同值，
        # 否则下次按其它区域键时会用旧比例重算，造成字号跳变。
        if area.endswith('_text') or area.endswith('_num'):
            _dim_suffix = '_text' if area.endswith('_text') else '_num'
            for _mate in _MATRIX_SCALE_AREAS:
                self._area_font_scales[_mate + _dim_suffix] = new_scale
        
        # 应用到对应区域
        base_font_size = LotteryConfig.FONT_SIZES.get(self.font_size_key, 16)
        # v0.0.36 硬性下限 15px：区域缩小（scale 0.5）也不允许低于 15px
        target_size = max(15, int(base_font_size * new_scale))
        
        if area == 'table':
            if hasattr(self, 'history_table'):
                font = self.history_table.font()
                font.setPixelSize(_pt_to_px_96(target_size))
                self.history_table.setFont(font)
                # 调整行高
                self.history_table.verticalHeader().setDefaultSectionSize(target_size + 10)
                # 刷新表格（重新渲染正码数字字体）
                _tab_history.update_history_table(self)
            self.statusBar().showMessage(f"表格字体已调整为 {target_size}px")
            
        elif area == 'result':
            # 预测结果区域字体
            if hasattr(self, 'prediction_display'):
                font = self.prediction_display.font()
                font.setPixelSize(_pt_to_px_96(target_size))
                self.prediction_display.setFont(font)
            if hasattr(self, 'prediction_number_layout'):
                # 调整预测数字按钮的字体
                for i in range(self.prediction_number_layout.count()):
                    item = self.prediction_number_layout.itemAt(i)
                    if item and item.widget():
                        btn_font = item.widget().font()
                        btn_font.setPixelSize(_pt_to_px_96(target_size + 2))
                        item.widget().setFont(btn_font)
            self.statusBar().showMessage(f"预测结果字体已调整为 {target_size}px")
            
        elif area == 'list':
            # 列表类控件字体
            for list_name in ['saved_predictions_list', 'favorites_list', 
                              'probability_list', 'prediction_history_list']:
                if hasattr(self, list_name):
                    list_widget = getattr(self, list_name)
                    font = list_widget.font()
                    font.setPixelSize(_pt_to_px_96(target_size))
                    list_widget.setFont(font)
            self.statusBar().showMessage(f"列表字体已调整为 {target_size}px")
        
        elif ((area.endswith('_text') and area[:-5] in _MATRIX_SCALE_AREAS) or
              (area.endswith('_num') and area[:-4] in _MATRIX_SCALE_AREAS)):
            # 拆键后的矩阵分区：文字键只改五行字号，号码键只改号码字号。
            # 四区域在合并版里共用同一块矩阵面板，因此维度是唯一分界：
            # 文字↔label_font，号码↔btn_font，互不联动。
            dimension = 'text' if area.endswith('_text') else 'num'
            if hasattr(self, 'zodiac_panel'):
                if not isinstance(getattr(self, '_attr_panel_size', None), dict):
                    self._attr_panel_size = {'width': 90, 'height': 98, 'btn_font': 28, 'label_font': 15,
                                             'fonts_custom': False}
                new_btn_font = int(self._attr_panel_size.get('btn_font', 28))
                new_label_font = int(self._attr_panel_size.get('label_font', 15))
                if dimension == 'num':
                    new_btn_font = max(15, min(LotteryConfig.TEXT_MAX_PX, int(28 * new_scale)))
                else:
                    new_label_font = max(15, min(LotteryConfig.TEXT_MAX_PX, int(15 * new_scale)))
                self._attr_panel_size['btn_font'] = new_btn_font
                self._attr_panel_size['label_font'] = new_label_font
                # 分维度定制标记：本次操作的维度以当前比例为准确认
                # （1.0 时该维度立即回到档位默认字号，不受其它区域别名键影响）；
                # 另一维度沿用其自身是否仍有非 1.0 键。
                num_custom_any, text_custom_any = self._matrix_scale_flags()
                if dimension == 'num':
                    num_custom = abs(float(new_scale) - 1.0) > 1e-9
                    text_custom = text_custom_any
                else:
                    text_custom = abs(float(new_scale) - 1.0) > 1e-9
                    num_custom = num_custom_any
                self._attr_panel_size['fonts_custom'] = num_custom or text_custom
                self.zodiac_panel.set_font_size(
                    width=None,
                    height=self._attr_panel_size.get('height', 98),
                    btn_font=new_btn_font,
                    label_font=new_label_font,
                    custom_fonts=self._attr_panel_size['fonts_custom'],
                    num_custom=num_custom,
                    attr_custom=text_custom,
                    auto_width=True
                )
                spin_name = ('attr_num_font_spin' if dimension == 'num'
                             else 'attr_text_font_spin')
                spin_value = new_btn_font if dimension == 'num' else new_label_font
                spin = getattr(self, spin_name, None)
                if spin is not None:
                    spin.blockSignals(True)
                    spin.setValue(spin_value)
                    spin.blockSignals(False)
            _dim_name = '文字' if dimension == 'text' else '号码'
            self.statusBar().showMessage(
                f"号码属性{_dim_name}字体已调整为 {int(new_scale * 100)}%")
        
        elif area == 'announcement':
            # 公告说明
            _tab_info.update_announcement_font(self, new_scale)
            self.statusBar().showMessage(f"公告说明字体已调整为 {int(new_scale*100)}%")
        
        elif area == 'detail':
            # 期号详情
            if self._current_detail_row >= 0:
                _tab_history.on_show_period_detail(self)  # 重新渲染，会使用当前scale
            self.statusBar().showMessage(f"期号详情字体已调整为 {int(new_scale*100)}%")
        
        # 持久化保存
        self._save_ini_config()
    



    def _reset_all_font_sizes(self):
        """功能：重置所有区域的字体大小为默认值（缩放系数统一回 1.0）
        注意：会就地改动 self._area_font_scales 字典并重排各面板；末尾写 INI
              （经写盘闸门）；detail 区仅在已选中期号时才重绘。
        参数:
            无
        返回:
            无
        """
        for key in self._area_font_scales:
            self._area_font_scales[key] = 1.0
        
        base_font_size = LotteryConfig.FONT_SIZES.get(self.font_size_key, 16)
        
        # 重置表格
        if hasattr(self, 'history_table'):
            font = self.history_table.font()
            font.setPixelSize(_pt_to_px_96(base_font_size))
            self.history_table.setFont(font)
            self.history_table.verticalHeader().setDefaultSectionSize(base_font_size + 10)
        
        # 重置预测结果
        if hasattr(self, 'prediction_display'):
            font = self.prediction_display.font()
            font.setPixelSize(_pt_to_px_96(base_font_size))
            self.prediction_display.setFont(font)
        
        # 重置列表
        for list_name in ['saved_predictions_list', 'favorites_list', 
                          'probability_list', 'prediction_history_list']:
            if hasattr(self, list_name):
                list_widget = getattr(self, list_name)
                font = list_widget.font()
                font.setPixelSize(_pt_to_px_96(base_font_size))
                list_widget.setFont(font)
        
        # 重置数字选择面板（仅旧页启用时存在 num_panel_font_spin；合并后已并入矩阵）
        if hasattr(self, 'num_panel_font_spin') and hasattr(self, 'number_panel'):
            self._number_panel_size = {'width': 80, 'height': 60, 'font': 20}
            self.number_panel.set_button_size(
                width=80, height=60, font_size=20
            )
        if hasattr(self, 'num_panel_font_spin'):
            self.num_panel_font_spin.blockSignals(True)
            self.num_panel_font_spin.setValue(20)
            self.num_panel_font_spin.blockSignals(False)
        
        # 重置号码属性表矩阵面板（合并页默认 90×98 / 28px / 15px）
        if hasattr(self, 'zodiac_panel'):
            self._attr_panel_size = {'width': 90, 'height': 98, 'btn_font': 28, 'label_font': 15,
                                     'fonts_custom': False}
            self.zodiac_panel.set_font_size(width=None, height=98, btn_font=28, label_font=15,
                                            custom_fonts=False, auto_width=True)
            # 控件回显用「重置后实际渲染值」：宽档默认是 34/17，直接写 28/15 会
            # 出现「框里 28/15、画面上 34/17」的假回显（与原 bug 同源的显示不一致）
            reset_num = int(getattr(self.zodiac_panel, '_num_font', 28))
            reset_text = int(getattr(self.zodiac_panel, '_attr_font', 15))
            for spin_name, value in (('attr_num_font_spin', reset_num),
                                     ('attr_text_font_spin', reset_text)):
                spin = getattr(self, spin_name, None)
                if spin is not None:
                    spin.blockSignals(True)
                    spin.setValue(value)
                    spin.blockSignals(False)
        
        # 重置五行分组条与下部号码面板
        if hasattr(self, 'elem_num_font_spin'):
            self._element_panel_size = {'width': 54, 'height': 38, 'btn_font': 16, 'label_font': 15}
            self.elem_num_font_spin.blockSignals(True)
            self.elem_num_font_spin.setValue(16)
            self.elem_num_font_spin.blockSignals(False)
            if hasattr(self, 'elem_text_font_spin'):
                self.elem_text_font_spin.blockSignals(True)
                self.elem_text_font_spin.setValue(15)
                self.elem_text_font_spin.blockSignals(False)
            if hasattr(self, 'element_grid_panel') and self.element_grid_panel:
                self.element_grid_panel.set_font_size(
                    width=54, height=38, btn_font=16, label_font=15)
            _tab_element.refresh_stats(self)
        
        # 重置公告说明
        if hasattr(self, 'notice_container'):
            _tab_info.update_announcement_font(self, 1.0)
        
        # 重置期号详情
        if hasattr(self, '_current_detail_row') and self._current_detail_row >= 0:
            _tab_history.on_show_period_detail(self)
        
        # 重置详情字体缩放
        self.detail_font_scale = 1.0
        
        # 保存重置后的配置
        self._save_ini_config()
        self.statusBar().showMessage("所有区域字体已重置")
    
    def _apply_panel_sizes_to_ui(self):
        """功能：把内存里存储的面板尺寸/字号配置应用到实际控件
        注意：只读 self._number_panel_size / _zodiac_panel_size / _element_panel_size /
              _prediction_ball_size 等字典，不回写；回填 spin 时统一 blockSignals
              防止「设值→信号→再设值」回环；缺控件的分支用 hasattr 保护；
              element 分支会触发 refresh_stats 重绘五行分组条。
        参数:
            无
        返回:
            无
        """
        # 数字选择面板（仅旧页启用时存在 num_panel_font_spin；合并后矩阵面板走下方 attr 分支）
        if hasattr(self, 'num_panel_font_spin') and hasattr(self, 'number_panel') and self.number_panel:
            self.number_panel.set_button_size(
                width=self._number_panel_size.get('width', 80),
                height=self._number_panel_size.get('height', 60),
                font_size=self._number_panel_size.get('font', 20)
            )
        if hasattr(self, 'num_panel_font_spin'):
            self.num_panel_font_spin.blockSignals(True)
            self.num_panel_font_spin.setValue(self._number_panel_size.get('font', 20))  # 默认20px
            self.num_panel_font_spin.blockSignals(False)
        
        # 号码属性表矩阵面板（三页合并后 zodiac_panel 即属性矩阵，尺寸/字号读 _attr_panel_size）
        if hasattr(self, 'zodiac_panel') and self.zodiac_panel:
            attr_size = getattr(self, '_attr_panel_size', None) or {
                'width': 90, 'height': 98, 'btn_font': 28, 'label_font': 15,
                'fonts_custom': False}
            # 拆键后按维度传入定制标记：旧 px 直接编辑（fonts_custom）视为双维度定制；
            # 只有某一维度缩放键非 1.0 时，另一维度回到档位默认字号。
            scale_num_custom, scale_text_custom = self._matrix_scale_flags()
            overall_custom = bool(attr_size.get('fonts_custom', False))
            num_custom = overall_custom or scale_num_custom
            text_custom = overall_custom or scale_text_custom
            self.zodiac_panel.set_font_size(
                width=None,
                height=attr_size.get('height', 98),
                btn_font=attr_size.get('btn_font', 28),
                label_font=attr_size.get('label_font', 15),
                custom_fonts=bool(attr_size.get('fonts_custom', False)),
                num_custom=num_custom,
                attr_custom=text_custom,
                auto_width=True
            )
            for spin_name, size_key in (('attr_num_font_spin', 'btn_font'), ('attr_text_font_spin', 'label_font')):
                spin = getattr(self, spin_name, None)
                if spin is not None:
                    spin.blockSignals(True)
                    spin.setValue(attr_size.get(size_key, 28 if size_key == 'btn_font' else 15))
                    spin.blockSignals(False)
        
        # 五行分组条与下部号码面板（字号/行高由标题行 px 控件控制，重新渲染即可）
        if hasattr(self, 'elem_num_font_spin'):
            self.elem_num_font_spin.blockSignals(True)
            self.elem_num_font_spin.setValue(self._element_panel_size.get('btn_font', 16))
            self.elem_num_font_spin.blockSignals(False)
            if hasattr(self, 'elem_text_font_spin'):
                self.elem_text_font_spin.blockSignals(True)
                self.elem_text_font_spin.setValue(self._element_panel_size.get('label_font', 15))
                self.elem_text_font_spin.blockSignals(False)
            if hasattr(self, 'element_grid_panel') and self.element_grid_panel:
                self.element_grid_panel.set_font_size(
                    width=self._element_panel_size.get('width', 54),
                    height=self._element_panel_size.get('height', 38))
            _tab_element.refresh_stats(self)
        
        # 预测结果号码球
        _tab_prediction.apply_prediction_ball_size(self)
        if hasattr(self, 'pred_num_font_spin'):
            self.pred_num_font_spin.blockSignals(True)
            self.pred_num_font_spin.setValue(self._prediction_ball_size.get('font', 20))  # 默认20px
            self.pred_num_font_spin.blockSignals(False)
        if hasattr(self, 'pred_text_font_spin'):
            self.pred_text_font_spin.blockSignals(True)
            self.pred_text_font_spin.setValue(self.ball_label_font_size)  # 默认20px
            self.pred_text_font_spin.blockSignals(False)
        # 颜色图例
        _tab_prediction.apply_legend_font_size(self)
        # 详情标签
        _tab_prediction.apply_detail_label_size(self)
        # 概率面板配置
        _tab_prediction.apply_probability_config(self)
        # 计算规律面板配置
        _tab_prediction.apply_calc_panel_config(self)
        # 波色预测面板配置
        _tab_prediction.apply_wave_panel_config(self)
        # 存储面板配置
        _tab_data_storage.apply_storage_config(self)



    def _save_custom_number_colors(self):
        """功能：保存自定义号码颜色到 INI 配置
        注意：会直接 open(self.config_file,'w') 覆盖写盘，不经过写盘闸门
              （这是颜色面板自己的落盘路径，与 _save_ini_config 不同）；
              未初始化 self._ini 时静默返回；写失败只打印，不向上抛。
        参数:
            无（颜色取自 LotteryConfig.get_number_color 与三大波色常量）
        返回:
            无
        """
        if not hasattr(self, '_ini'):
            return
        try:
            if not self._ini.has_section('NumberColors'):
                self._ini.add_section('NumberColors')
            for num in range(1, 50):
                colors = LotteryConfig.get_number_color(num)
                self._ini.set('NumberColors', f'num_{num}', colors.get('text', '#000000'))
            # 保存波色分组
            self._ini.set('NumberColors', 'red_numbers', ','.join(str(n) for n in LotteryConfig.RED_NUMBERS))
            self._ini.set('NumberColors', 'blue_numbers', ','.join(str(n) for n in LotteryConfig.BLUE_NUMBERS))
            self._ini.set('NumberColors', 'green_numbers', ','.join(str(n) for n in LotteryConfig.GREEN_NUMBERS))
            with open(self.config_file, 'w', encoding='utf-8') as f:
                self._ini.write(f)
        except Exception as e:
            print(f"保存号码颜色失败: {e}")

    def _load_custom_number_colors(self):
        """功能：从 INI 配置加载自定义号码颜色
        注意：会就地改写 LotteryConfig 的类属性（RED_NUMBERS / BLUE_NUMBERS /
              GREEN_NUMBERS / NUMBER_COLORS），属于模块级全局副作用，影响所有页面；
              INI 缺段或缺项时保留默认值；只读配置，不写盘。
        参数:
            无（读取 self._ini 的 NumberColors 段）
        返回:
            无
        """
        if not hasattr(self, '_ini') or not self._ini.has_section('NumberColors'):
            return
        try:
            # 加载波色分组
            if self._ini.has_option('NumberColors', 'red_numbers'):
                red_str = self._ini.get('NumberColors', 'red_numbers')
                LotteryConfig.RED_NUMBERS = [int(n) for n in red_str.split(',') if n.strip()]
            if self._ini.has_option('NumberColors', 'blue_numbers'):
                blue_str = self._ini.get('NumberColors', 'blue_numbers')
                LotteryConfig.BLUE_NUMBERS = [int(n) for n in blue_str.split(',') if n.strip()]
            if self._ini.has_option('NumberColors', 'green_numbers'):
                green_str = self._ini.get('NumberColors', 'green_numbers')
                LotteryConfig.GREEN_NUMBERS = [int(n) for n in green_str.split(',') if n.strip()]

            # 重建颜色映射
            LotteryConfig.NUMBER_COLORS = {}
            for num in LotteryConfig.RED_NUMBERS:
                LotteryConfig.NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": "#FF0000", "border": "#FF0000"}
            for num in LotteryConfig.BLUE_NUMBERS:
                LotteryConfig.NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": "#0000FF", "border": "#0000FF"}
            for num in LotteryConfig.GREEN_NUMBERS:
                LotteryConfig.NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": "#008000", "border": "#008000"}

            # 加载自定义颜色（覆盖分组颜色）
            for num in range(1, 50):
                key = f'num_{num}'
                if self._ini.has_option('NumberColors', key):
                    color = self._ini.get('NumberColors', key)
                    # 检查是否与默认波色不同
                    default_color = None
                    if num in LotteryConfig.RED_NUMBERS:
                        default_color = '#FF0000'
                    elif num in LotteryConfig.BLUE_NUMBERS:
                        default_color = '#0000FF'
                    elif num in LotteryConfig.GREEN_NUMBERS:
                        default_color = '#008000'
                    if color != default_color:
                        LotteryConfig.NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": color, "border": color}
        except Exception as e:
            print(f"加载号码颜色失败: {e}")

    def _load_ini_config(self):
        """功能：从 INI 文件加载配置（启动阶段只读，绝不回写）

        写盘策略（为什么启动不写、什么条件下才写）：
            1) 文件存在：只读 + 应用到内存，缺失的键用默认值补进内存 _ini，
               **不落盘**。启动期界面会自行重算分隔条/列宽、恢复选项卡等，
               这些自动值不是用户设置，写回去只会让文件哈希无意义变化。
            2) 文件不存在（首次运行/被删除）：允许创建——先试 SQLite 配置镜像，
               恢复成功则只在内存生效（不重建文件）；镜像也没有时才生成默认 INI 并写盘。
            3) 文件存在但读取失败：只在内存退回默认值，不覆盖用户文件
               （避免一次解析异常就把可修复的配置抹掉）。
        注意：启动期唯一的写盘点是「文件不存在且 SQLite 无镜像」的首次创建；
              其余分支都只改内存 self._ini，绝不触发写盘闸门。
        参数:
            无（路径来自 self.config_file，缺失键默认值来自 _build_default_ini）
        返回:
            无（结果写入 self._ini 与各 UI 属性）
        """
        import configparser  # 作用说明：解析「配置.ini」为 ConfigParser 对象（启动期只读，不写回）
        self._ini = configparser.ConfigParser()
        if os.path.exists(self.config_file):
            try:
                self._ini.read(self.config_file, encoding='utf-8')
                self._apply_ini_config()
                # 缺失键补默认值到内存：运行期行为与旧版一致（有默认值可用），
                # 但这里只改内存 _ini，不触盘，文件内容保持原样。
                self._ensure_ini_defaults()
                print("INI配置加载成功")
            except Exception as e:
                print("INI配置加载失败: " + str(e))
                if self._restore_ini_from_db():
                    self._apply_ini_config()
                    self._ensure_ini_defaults()
                else:
                    # 文件存在但损坏且无镜像可恢复：内存退回默认，保留原文件不动
                    self._init_default_ini(write_file=False)
        else:
            # INI文件不存在：允许首次创建。优先从 SQLite 恢复配置镜像，再退回默认配置
            if self._restore_ini_from_db():
                self._apply_ini_config()
                self._ensure_ini_defaults()
                print("INI文件缺失，已从数据库恢复配置镜像（内存生效，待用户改动时才落盘）")
            else:
                self._init_default_ini(write_file=True)

    def _build_default_ini(self):
        """功能：构造一份默认配置（内存对象，不写盘）
        说明：
            只包含启动默认值，供两条路径复用：
              ① 首次创建 INI（写盘由调用方决定）；
              ② 已有 INI 缺键时补进内存（_ensure_ini_defaults）。
        参数: 无
        返回: configparser.ConfigParser 默认配置对象
        """
        import configparser  # 作用说明：构建默认配置对象（内存态，是否写盘由调用方决定）
        ini = configparser.ConfigParser()

        # [General] 通用设置
        ini['General'] = {
            'window_width': '1600',
            'window_height': '1000',
            'font_size_key': LotteryConfig.DEFAULT_FONT_SIZE_KEY,
            'start_zodiac': '龙',
            'is_dark_mode': 'False',  # 主题记忆：_apply_ini_config 实际从 [General] 读取
        }

        # [Paths] 文件路径
        ini['Paths'] = {
            'data_file': self.data_file,
            'zodiac_file': self.zodiac_file,
            'last_prediction_file': self.last_prediction_file,
        }

        # [Zodiac] 生肖绑定
        ini['Zodiac'] = {}
        for num in range(1, 50):
            zodiac = self.zodiac_binding.get(num, '')
            ini['Zodiac'][str(num)] = zodiac

        # [Elements] 五行绑定
        ini['Elements'] = {}
        for num in range(1, 50):
            element = self.zodiac_elements.get(num, '')
            ini['Elements'][str(num)] = element

        # [Display] 显示设置
        ini['Display'] = {
            'history_page_size': '100',
            'is_dark_mode': 'False',  # 主题模式记忆
            'margin_top': '10',       # 布局边距记忆
            'margin_bottom': '10',
            'margin_left': '10',
            'margin_right': '10',
            'spacing': '10',
        }

        # 历史记录表列宽默认值（9列）
        default_col_widths = [70, 120, 160, 70, 60, 65, 65, 110, 60]
        for i, w in enumerate(default_col_widths):
            ini['Display']['history_col_' + str(i)] = str(w)
        return ini

    def _ensure_ini_defaults(self):
        """功能：把 INI 中缺失的键用默认值补到内存（绝不写盘）
        说明：
            只在内存 ConfigParser 上 setdefault：
              - 已有值一律保留，不被默认值覆盖；
              - 缺失键在运行期有默认值可用，用户下次真正改设置时才会随整份配置落盘；
              - 不触碰磁盘，满足「删掉一个键后启动，文件仍不被重写」的要求。
        参数: 无
        返回: 无
        """
        defaults = self._build_default_ini()
        for section in defaults.sections():
            if not self._ini.has_section(section):
                self._ini.add_section(section)
            for key, val in defaults[section].items():
                if not self._ini.has_option(section, key):
                    self._ini.set(section, key, str(val))

    def _init_default_ini(self, write_file=False):
        """功能：初始化默认INI配置
        注意：无论是否写盘都会先执行 _apply_ini_config，因为界面构建依赖它初始化的
              _splitter_sizes / _history_col_widths 等容器（缺了会 AttributeError）；
              write_file=True 时以 force=True 绕过启动期写盘闸门，仅在文件确实不存在时使用。
        参数:
            write_file: True=首次创建时写盘（仅 INI 文件不存在时使用）；
                        False=只建内存默认对象，不落盘（文件损坏时的兜底）
        返回:
            无
        """
        self._ini = self._build_default_ini()
        # 默认配置也必须走一遍「应用到内存属性」：_apply_ini_config 会初始化
        # _splitter_sizes / _history_col_widths 等界面构建依赖的容器。
        # 旧实现首次运行（INI 不存在且无数据库镜像）时跳过这一步，
        # 大数据分析页读取 _splitter_sizes 会直接 AttributeError 导致启动崩溃。
        self._apply_ini_config()
        if write_file:
            # force=True：首次创建必须绕过启动期写盘闸门（此时 _ini_write_enabled=False）
            self._save_ini_config(force=True)
    
    def _apply_ini_config(self):
        """功能：把 INI 内存配置应用到当前窗口（窗口尺寸/字号/主题/生肖五行/列宽等）
        注意：只读 self._ini、只改内存属性，不写盘；会就地改写模块级 LotteryConfig
              （NUMBER_NAMES / NUMBER_ELEMENTS），影响全部页面；主题变化时会重建样式表；
              [Paths] 一律重定位到 程序目录/系统v7.5/，不信任文件里的旧路径；
              数值非法（ValueError）时跳过该项、保留原值。
        参数:
            无
        返回:
            无
        """
        try:
            # [General]
            if self._ini.has_section('General'):
                gen = self._ini['General']
                if 'window_width' in gen and 'window_height' in gen:
                    try:
                        w = int(gen['window_width'])
                        h = int(gen['window_height'])
                        if w >= LotteryConfig.WINDOW_MIN_WIDTH and h >= LotteryConfig.WINDOW_MIN_HEIGHT:
                            self.resize(w, h)
                    except ValueError:
                        pass
                if 'font_size_key' in gen:
                    key = gen['font_size_key']
                    if key in LotteryConfig.FONT_SIZES:
                        self.font_size_key = key
                if 'start_zodiac' in gen:
                    self._ini_start_zodiac = gen['start_zodiac']
                else:
                    self._ini_start_zodiac = '龙'
                if 'is_dark_mode' in gen:  # 主题模式记忆恢复
                    val = gen['is_dark_mode'].lower() == 'true'
                    if val != self.is_dark_mode:
                        self.is_dark_mode = val
                        self._update_stylesheet()
            
            # [Paths] 仅作旧版兼容：无论 INI 里记的是绝对路径、相对路径还是旧目录名，
            # 一律重定位到统一的「程序目录/系统v7.5/」，避免换机/换盘符/换启动目录后
            # 数据被写到旧位置或当前工作目录（v0.0.18 修复）
            if self._ini.has_section('Paths'):
                paths = self._ini['Paths']
                for attr, default_name in (
                        ('data_file', '彩票数据.json'),
                        ('zodiac_file', '生肖绑定.json'),
                        ('last_prediction_file', '上次预测.json')):
                    p = paths.get(attr, '')
                    name = os.path.basename(p) if p else default_name
                    setattr(self, attr, os.path.join(self._data_dir, name))
            
            # [Zodiac] - 覆盖默认绑定
            if self._ini.has_section('Zodiac'):
                for num in range(1, 50):
                    key = str(num)
                    if key in self._ini['Zodiac']:
                        self.zodiac_binding[num] = self._ini['Zodiac'][key]
                # 同步到 LotteryConfig
                LotteryConfig.NUMBER_NAMES.update(self.zodiac_binding)
            
            # [Elements] - 覆盖默认绑定
            if self._ini.has_section('Elements'):
                for num in range(1, 50):
                    key = str(num)
                    if key in self._ini['Elements']:
                        self.zodiac_elements[num] = self._ini['Elements'][key]
                LotteryConfig.NUMBER_ELEMENTS.update(self.zodiac_elements)
            
            # [Weights] - 加载自定义算法权重
            if self._ini.has_section('Weights'):
                for name in self._ini['Weights']:
                    try:
                        self.custom_weights[name] = int(self._ini['Weights'][name])
                    except ValueError:
                        pass
            
            # [Display]
            if self._ini.has_section('Display'):
                disp = self._ini['Display']
                if 'history_page_size' in disp:
                    try:
                        self.history_page_size = int(disp['history_page_size'])
                    except ValueError:
                        pass
                # 布局边距记忆恢复（上限50px）
                for key in ['margin_top', 'margin_bottom', 'margin_left', 'margin_right', 'spacing']:
                    if key in disp:
                        try:
                            val = int(disp[key])
                            setattr(self, key, max(0, min(50, val)))
                        except ValueError:
                            pass
                if 'ball_label_font_size' in disp:
                    try:
                        self.ball_label_font_size = int(disp['ball_label_font_size'])
                    except ValueError:
                        pass
                if 'enhanced_mode' in disp:
                    try:
                        self.enhanced_mode = disp['enhanced_mode'].lower() in ('true', '1', 'yes', '是')
                    except ValueError:
                        pass
                if 'reverse_mode' in disp:
                    try:
                        self.reverse_mode = disp['reverse_mode'].lower() in ('true', '1', 'yes', '是')
                        # 同步更新UI
                        if hasattr(self, 'strategy_combo'):
                            index = 1 if self.reverse_mode else 0
                            self.strategy_combo.setCurrentIndex(index)
                    except ValueError:
                        pass
                if 'deterministic_mode' in disp:
                    try:
                        self.deterministic_mode = disp['deterministic_mode'].lower() in ('true', '1', 'yes', '是')
                        # 同步更新UI
                        if hasattr(self, 'deterministic_checkbox'):
                            self.deterministic_checkbox.setChecked(self.deterministic_mode)
                    except ValueError:
                        pass
                if 'use_model_cache' in disp:
                    try:
                        self._use_model_cache = disp['use_model_cache'].lower() in ('true', '1', 'yes', '是')
                        # 同步更新UI复选框
                        if hasattr(self, 'model_cache_check'):
                            self.model_cache_check.setChecked(self._use_model_cache)
                    except ValueError:
                        pass
                
                # 加载历史记录表列宽
                self._history_col_widths = []
                for i in range(9):
                    key = 'history_col_' + str(i)
                    if key in disp:
                        try:
                            self._history_col_widths.append(int(disp[key]))
                        except ValueError:
                            self._history_col_widths.append(None)
                    else:
                        self._history_col_widths.append(None)
                
                # 加载各区域字体缩放比例
                # 非矩阵区域：单键不变
                for ini_key, area_key in (
                        ('font_scale_table', 'table'),
                        ('font_scale_result', 'result'),
                        ('font_scale_list', 'list'),
                        ('font_scale_announcement', 'announcement'),
                        ('font_scale_detail', 'detail')):
                    if ini_key in disp:
                        try:
                            self._area_font_scales[area_key] = float(disp[ini_key])
                        except ValueError:
                            pass

                # 矩阵四区域拆键：先读 [WidgetState] 的 f_ 浮层记忆（最高优先），
                # 再读 [Display] 新键，最后读旧 4 键（只迁移为 *_text，绝不联动 *_num）。
                explicit_scale_keys = set()
                if self._ini.has_section('WidgetState'):
                    ws = self._ini['WidgetState']
                    for area_key in _MATRIX_SCALE_AREAS:
                        for dim in ('text', 'num'):
                            state_key = f'f_{area_key}_{dim}'
                            target_key = f'{area_key}_{dim}'
                            if state_key in ws:
                                try:
                                    self._area_font_scales[target_key] = float(ws[state_key])
                                    explicit_scale_keys.add(target_key)
                                except ValueError:
                                    pass
                for area_key in _MATRIX_SCALE_AREAS:
                    for dim in ('text', 'num'):
                        ini_key = f'font_scale_{area_key}_{dim}'
                        target_key = f'{area_key}_{dim}'
                        if ini_key in disp and target_key not in explicit_scale_keys:
                            try:
                                self._area_font_scales[target_key] = float(disp[ini_key])
                                explicit_scale_keys.add(target_key)
                            except ValueError:
                                pass
                for ini_key, target_key in (
                        ('font_scale_number_panel', 'number_panel_text'),
                        ('font_scale_zodiac_panel', 'zodiac_panel_text'),
                        ('font_scale_element_panel', 'element_panel_text'),
                        ('font_scale_attr_panel', 'attr_panel_text')):
                    if ini_key in disp and target_key not in explicit_scale_keys:
                        try:
                            # 旧键语义迁移：历史值只作用于文字，号码维度保持默认 1.0
                            self._area_font_scales[target_key] = float(disp[ini_key])
                        except ValueError:
                            pass
                
                # 加载数字面板缩放比例
                if 'number_panel_size_scale' in disp:
                    try:
                        self._number_panel_size_scale = float(disp['number_panel_size_scale'])
                    except ValueError:
                        pass
                
                # 加载面板尺寸设置
                # 数字选择面板
                if 'number_panel_width' in disp:
                    try:
                        self._number_panel_size['width'] = int(disp['number_panel_width'])
                    except ValueError:
                        pass
                if 'number_panel_height' in disp:
                    try:
                        self._number_panel_size['height'] = int(disp['number_panel_height'])
                    except ValueError:
                        pass
                if 'number_panel_font' in disp:
                    try:
                        self._number_panel_size['font'] = int(disp['number_panel_font'])
                    except ValueError:
                        pass
                
                # 生肖面板
                if 'zodiac_panel_width' in disp:
                    try:
                        self._zodiac_panel_size['width'] = int(disp['zodiac_panel_width'])
                    except ValueError:
                        pass
                if 'zodiac_panel_height' in disp:
                    try:
                        self._zodiac_panel_size['height'] = int(disp['zodiac_panel_height'])
                    except ValueError:
                        pass
                if 'zodiac_panel_btn_font' in disp:
                    try:
                        self._zodiac_panel_size['btn_font'] = int(disp['zodiac_panel_btn_font'])
                    except ValueError:
                        pass
                if 'zodiac_panel_label_font' in disp:
                    try:
                        self._zodiac_panel_size['label_font'] = int(disp['zodiac_panel_label_font'])
                    except ValueError:
                        pass
                
                # 五行面板
                if 'element_panel_width' in disp:
                    try:
                        self._element_panel_size['width'] = int(disp['element_panel_width'])
                    except ValueError:
                        pass
                if 'element_panel_height' in disp:
                    try:
                        self._element_panel_size['height'] = int(disp['element_panel_height'])
                    except ValueError:
                        pass
                if 'element_panel_btn_font' in disp:
                    try:
                        self._element_panel_size['btn_font'] = int(disp['element_panel_btn_font'])
                    except ValueError:
                        pass
                if 'element_panel_label_font' in disp:
                    try:
                        # v0.0.67：读取即钳制到全局文字下限 15px。旧版 INI 里可能残留 12，
                        # 而 [WidgetState] 的角控件显示值是独立恢复的，若不钳制就会出现
                        # 「控件显示 15、实际渲染 12」；钳制只改内存，不抢写磁盘。
                        self._element_panel_size['label_font'] = max(
                            15, int(disp['element_panel_label_font']))
                    except ValueError:
                        pass
                
                # 号码属性表矩阵面板（三页合并后的唯一面板；v0.0.75 起按 key 读回，
                # 之前只写不读，导致字号重启后丢失并被档位默认 34/17 顶替）
                if not isinstance(getattr(self, '_attr_panel_size', None), dict):
                    self._attr_panel_size = {'width': 90, 'height': 98, 'btn_font': 28,
                                             'label_font': 15, 'fonts_custom': False}
                if 'attr_panel_width' in disp:
                    try:
                        self._attr_panel_size['width'] = int(disp['attr_panel_width'])
                    except ValueError:
                        pass
                if 'attr_panel_height' in disp:
                    try:
                        self._attr_panel_size['height'] = int(disp['attr_panel_height'])
                    except ValueError:
                        pass
                if 'attr_panel_btn_font' in disp:
                    try:
                        self._attr_panel_size['btn_font'] = max(15, int(disp['attr_panel_btn_font']))
                    except ValueError:
                        pass
                if 'attr_panel_label_font' in disp:
                    try:
                        self._attr_panel_size['label_font'] = max(15, int(disp['attr_panel_label_font']))
                    except ValueError:
                        pass
                if 'attr_panel_fonts_custom' in disp:
                    self._attr_panel_size['fonts_custom'] = (
                        str(disp['attr_panel_fonts_custom']).strip() not in ('', '0', 'false', 'False'))

                # 旧值迁移兜底：仅当对应 PX 键完全缺失时，才用缩放键回填字号，
                # 避免覆盖用户已保存的 PX。旧 4 键迁移只作用于文字，号码保持默认。
                if 'attr_panel_label_font' not in disp:
                    self._attr_panel_size['label_font'] = max(
                        15, min(LotteryConfig.TEXT_MAX_PX,
                                int(15 * self._effective_matrix_scale('text'))))
                if 'attr_panel_btn_font' not in disp:
                    self._attr_panel_size['btn_font'] = max(
                        15, min(LotteryConfig.TEXT_MAX_PX,
                                int(28 * self._effective_matrix_scale('num'))))
                if ('attr_panel_fonts_custom' not in disp
                        and any(self._matrix_scale_flags())):
                    self._attr_panel_size['fonts_custom'] = True
                
                # 预测结果号码球尺寸
                if 'pred_ball_width' in disp:
                    try:
                        self._prediction_ball_size['width'] = int(disp['pred_ball_width'])
                    except ValueError:
                        pass
                if 'pred_ball_height' in disp:
                    try:
                        self._prediction_ball_size['height'] = int(disp['pred_ball_height'])
                    except ValueError:
                        pass
                if 'pred_ball_font' in disp:
                    try:
                        self._prediction_ball_size['font'] = int(disp['pred_ball_font'])
                    except ValueError:
                        pass
                if 'pred_ball_label_font' in disp:
                    try:
                        self._prediction_ball_size['label_font'] = int(disp['pred_ball_label_font'])
                    except ValueError:
                        pass
                if 'pred_ball_label_width' in disp:
                    try:
                        self._prediction_ball_size['label_width'] = int(disp['pred_ball_label_width'])
                    except ValueError:
                        pass
                if 'pred_ball_label_height' in disp:
                    try:
                        self._prediction_ball_size['label_height'] = int(disp['pred_ball_label_height'])
                    except ValueError:
                        pass
                if 'pred_ball_plus_size' in disp:
                    try:
                        self._prediction_ball_size['plus_size'] = int(disp['pred_ball_plus_size'])
                    except ValueError:
                        pass
                
                # 概率面板配置
                if 'prob_period' in disp:
                    try:
                        val = int(disp['prob_period'])
                        # 先保存到配置变量，UI创建后再应用
                        if not hasattr(self, '_prob_config'):
                            self._prob_config = {}
                        self._prob_config['period'] = val
                        # 如果控件已创建则直接应用
                        if hasattr(self, 'prob_period_spin') and self.prob_period_spin:
                            # 阻塞信号避免重复触发
                            self.prob_period_spin.blockSignals(True)
                            self.prob_period_spin.setValue(val)
                            self.prob_period_spin.blockSignals(False)
                    except ValueError:
                        pass
                if 'prob_sort_mode' in disp:
                    try:
                        val = int(disp['prob_sort_mode'])
                        # 先保存到配置变量
                        if not hasattr(self, '_prob_config'):
                            self._prob_config = {}
                        self._prob_config['sort_mode'] = val
                        # 如果控件已创建则直接应用
                        if hasattr(self, 'prob_sort_combo') and self.prob_sort_combo:
                            self.prob_sort_combo.blockSignals(True)
                            self.prob_sort_combo.setCurrentIndex(val)
                            self.prob_sort_combo.blockSignals(False)
                    except ValueError:
                        pass
                
                # 颜色图例文字大小
                if 'legend_label_font' in disp:
                    try:
                        self._legend_font_size['label'] = int(disp['legend_label_font'])
                    except ValueError:
                        pass
                if 'legend_nums_font' in disp:
                    try:
                        self._legend_font_size['nums'] = int(disp['legend_nums_font'])
                    except ValueError:
                        pass
                
                # 详情标签字体和内边距
                if 'detail_label_font' in disp:
                    try:
                        self._detail_label_size['font'] = int(disp['detail_label_font'])
                    except ValueError:
                        pass
                if 'detail_label_padding' in disp:
                    try:
                        self._detail_label_size['padding'] = int(disp['detail_label_padding'])
                    except ValueError:
                        pass
                
                # 加载预测记录表格列宽
                self._prediction_col_widths = []
                for i in range(4):
                    key = 'prediction_col_' + str(i)
                    if key in disp:
                        try:
                            self._prediction_col_widths.append(int(disp[key]))
                        except ValueError:
                            self._prediction_col_widths.append(None)
                    else:
                        self._prediction_col_widths.append(None)
                
                # 加载各Splitter分隔条位置
                self._splitter_sizes = {}
                splitter_names = [
                    'data_import_splitter', 'pred_h_splitter', 'pred_left_v_splitter',
                    'history_h_splitter', 'history_left_v_splitter',
                    'history_right_v_splitter', 'seventh_pred_splitter',
                    'zodiac_h_splitter', 'element_h_splitter', 'element_v_splitter',
                    'attr_h_splitter',
                    'bd_mid_splitter', 'bd_main_splitter', 'stats_splitter',
                    'storage_splitter', 'number_pred_splitter'
                ]
                for name in splitter_names:
                    key = name + '_sizes'
                    if key in disp:
                        try:
                            sizes = [int(s) for s in disp[key].split(',') if s.strip()]
                            self._splitter_sizes[name] = sizes
                        except ValueError:
                            pass
                
                # 窗口位置
                if 'window_x' in disp and 'window_y' in disp:
                    try:
                        x = int(disp['window_x'])
                        y = int(disp['window_y'])
                        self.move(x, y)
                    except ValueError:
                        pass
                
                # 当前标签页：此时 UI 尚未创建，先暂存，等 _init_ui 完成后再恢复
                if 'current_tab_index' in disp:
                    try:
                        idx = int(disp['current_tab_index'])
                        # 三页合并（16→14）后的索引换算：旧 9/10 → 3，旧 11~15 → 减 2。
                        # 仅在尚未写入 attr_merge_v1 标记时执行一次，避免新索引被反复减 2。
                        if str(disp.get('attr_merge_v1', '')).strip() != '1':
                            if idx >= 11:
                                idx -= 2
                            elif idx in (9, 10):
                                idx = 3
                        self._ini_start_tab_index = max(0, idx)
                    except ValueError:
                        self._ini_start_tab_index = 0
                else:
                    self._ini_start_tab_index = 0
                
                # 预测算法选择
                if 'prediction_algorithm_index' in disp:
                    try:
                        idx = int(disp['prediction_algorithm_index'])
                        if hasattr(self, 'algorithm_combo') and 0 <= idx < self.algorithm_combo.count():
                            self.algorithm_combo.setCurrentIndex(idx)
                    except ValueError:
                        pass
                
                # 预测类型
                if 'prediction_type' in disp:
                    try:
                        pred_type = disp['prediction_type']
                        if pred_type in ('algorithm', 'random', 'ml'):
                            self._prediction_type = pred_type
                            if hasattr(self, 'type_btn_algorithm'):
                                self.type_btn_algorithm.setChecked(pred_type == 'algorithm')
                            if hasattr(self, 'type_btn_random'):
                                self.type_btn_random.setChecked(pred_type == 'random')
                            if hasattr(self, 'type_btn_ml'):
                                self.type_btn_ml.setChecked(pred_type == 'ml')
                    except ValueError:
                        pass
                
                # 回测算法选择
                if 'backtest_algorithm_index' in disp:
                    try:
                        idx = int(disp['backtest_algorithm_index'])
                        if hasattr(self, 'backtest_algo_combo') and 0 <= idx < self.backtest_algo_combo.count():
                            self.backtest_algo_combo.setCurrentIndex(idx)
                    except ValueError:
                        pass
                
                # 回测期数
                if 'backtest_period' in disp:
                    try:
                        period = int(disp['backtest_period'])
                        if hasattr(self, 'backtest_period_spin'):
                            self.backtest_period_spin.setValue(period)
                    except ValueError:
                        pass
                
                # 历史记录当前页码
                if 'history_current_page' in disp:
                    try:
                        self.history_page = int(disp['history_current_page'])
                    except ValueError:
                        pass
                
                # 期号详情字体缩放
                if 'detail_font_scale' in disp:
                    try:
                        self.detail_font_scale = float(disp['detail_font_scale'])
                    except ValueError:
                        pass
                
                # 数字排序/数字选尾「结果分隔符」选择记忆（由选项卡构建时应用）
                if 'sort_sep_index' in disp:
                    try:
                        self._ini_sort_sep_index = int(disp['sort_sep_index'])
                    except ValueError:
                        pass
                if 'tail_sep_index' in disp:
                    try:
                        self._ini_tail_sep_index = int(disp['tail_sep_index'])
                    except ValueError:
                        pass
                
                # 计算规律面板配置
                if not hasattr(self, '_calc_config'):
                    self._calc_config = {}
                if 'calc_skip' in disp:
                    try:
                        self._calc_config['skip'] = int(disp['calc_skip'])
                    except ValueError:
                        pass
                if 'calc_op' in disp:
                    try:
                        self._calc_config['op'] = int(disp['calc_op'])
                    except ValueError:
                        pass
                if 'calc_custom_period' in disp:
                    try:
                        self._calc_config['custom_period'] = int(disp['calc_custom_period'])
                    except ValueError:
                        pass
                if 'calc_filter' in disp:
                    try:
                        self._calc_config['filter'] = int(disp['calc_filter'])
                    except ValueError:
                        pass
                if 'calc_topn' in disp:
                    try:
                        self._calc_config['topn'] = int(disp['calc_topn'])
                    except ValueError:
                        pass
                if 'calc_font_size' in disp:
                    try:
                        self._calc_config['font_size'] = int(disp['calc_font_size'])
                    except ValueError:
                        pass
                if 'calc_result_font' in disp:
                    try:
                        self._calc_config['result_font'] = int(disp['calc_result_font'])
                    except ValueError:
                        pass
                if 'calc_rec_font' in disp:
                    try:
                        self._calc_config['rec_font'] = int(disp['calc_rec_font'])
                    except ValueError:
                        pass
                if 'calc_comp_font' in disp:
                    try:
                        self._calc_config['comp_font'] = int(disp['calc_comp_font'])
                    except ValueError:
                        pass
                if 'calc_detail_font' in disp:
                    try:
                        self._calc_config['detail_font'] = int(disp['calc_detail_font'])
                    except ValueError:
                        pass
                if 'calc_width' in disp:
                    try:
                        self._calc_config['width'] = int(disp['calc_width'])
                    except ValueError:
                        pass
                if 'calc_height' in disp:
                    try:
                        self._calc_config['height'] = int(disp['calc_height'])
                    except ValueError:
                        pass
                
                # 波色预测面板配置
                if not hasattr(self, '_wave_config'):
                    self._wave_config = {}
                if 'wave_period' in disp:
                    try:
                        self._wave_config['period'] = int(disp['wave_period'])
                    except ValueError:
                        pass
                if 'wave_custom_period' in disp:
                    try:
                        self._wave_config['custom_period'] = int(disp['wave_custom_period'])
                    except ValueError:
                        pass
                if 'wave_mode' in disp:
                    try:
                        self._wave_config['mode'] = int(disp['wave_mode'])
                    except ValueError:
                        pass
                if 'wave_trend' in disp:
                    try:
                        self._wave_config['trend'] = int(disp['wave_trend'])
                    except ValueError:
                        pass
                if 'wave_font_size' in disp:
                    try:
                        self._wave_config['font_size'] = int(disp['wave_font_size'])
                    except ValueError:
                        pass
                if 'wave_result_font' in disp:
                    try:
                        self._wave_config['result_font'] = int(disp['wave_result_font'])
                    except ValueError:
                        pass
                if 'wave_trend_font' in disp:
                    try:
                        self._wave_config['trend_font'] = int(disp['wave_trend_font'])
                    except ValueError:
                        pass
                if 'wave_trans_font' in disp:
                    try:
                        self._wave_config['trans_font'] = int(disp['wave_trans_font'])
                    except ValueError:
                        pass
                if 'wave_width' in disp:
                    try:
                        self._wave_config['width'] = int(disp['wave_width'])
                    except ValueError:
                        pass
                if 'wave_height' in disp:
                    try:
                        self._wave_config['height'] = int(disp['wave_height'])
                    except ValueError:
                        pass
                
                # 存储面板配置
                if 'storage_sort_mode' in disp:
                    try:
                        self._storage_sort_mode = disp['storage_sort_mode']
                    except Exception:
                        pass
                if 'storage_category' in disp:
                    try:
                        self._current_storage_category = disp['storage_category']
                    except Exception:
                        pass
                if 'storage_category_collapsed' in disp:
                    try:
                        self._category_collapsed = disp['storage_category_collapsed'].lower() in ('true', '1', 'yes', '是')
                    except Exception:
                        pass
                if 'storage_tag_collapsed' in disp:
                    try:
                        self._tag_collapsed = disp['storage_tag_collapsed'].lower() in ('true', '1', 'yes', '是')
                    except Exception:
                        pass
                # 数字选择面板选中状态记忆恢复
                if 'selected_numbers' in disp:
                    selected_str = disp['selected_numbers']
                    if selected_str != 'none':
                        try:
                            self._pending_selected_numbers = [int(n) for n in selected_str.split(',') if n.strip().isdigit()]
                        except ValueError:
                            self._pending_selected_numbers = []
                    else:
                        self._pending_selected_numbers = []
                        
        except Exception as e:
            print("应用INI配置出错: " + str(e))
    

    def _save_ini_config(self, force=False):
        """功能：保存当前配置到 INI 文件

        写盘条件（为什么启动不写、什么条件下才写）：
            - 启动期（_ini_write_enabled=False）：直接返回 False，只把值留在内存；
              例外是 force=True —— 仅用于「INI 文件不存在」的首次创建场景。
            - 运行期（_ini_write_enabled=True）：只有用户真正操作控件/分隔条/字体等
              才会走到这里（对应信号里调用本方法）。
            - 最后还有一道「内容一致就不落盘」的兜底：把要写的内容与磁盘现有内容
              比较，完全一致则跳过写盘和 SQLite 镜像同步，避免重复 I/O。
        注意：本方法是主窗口唯一的 INI 落盘点（_save_custom_number_colors 除外），
              会写盘 + 同步 SQLite 镜像两处；任何异常只打印并返回 False，不向
              信号槽抛出；配置内容取自当前控件实时状态，而非 INI 内存副本。
        参数:
            force: True=绕过启动期闸门（仅首次创建 INI 时由 _init_default_ini /
                   _load_ini_config 使用）；False=常规用户改动保存
        返回:
            bool 是否成功（被闸门拦截也返回 False）
        """
        import configparser  # 作用说明：以文本 IO 写回 ConfigParser 内容，保留节顺序与中文值
        import io  # 作用说明：StringIO 在内存拼出 INI 全文，由 open(...,'w') 直写；原子写只在 _safe_write_file
        # 启动期一律不写盘（见 __init__ 中 _ini_write_enabled 的说明），
        # 避免 UI 构建/恢复阶段用默认值或界面自动布局值覆盖用户已保存的记忆。
        if not force and not getattr(self, '_ini_write_enabled', True):
            return False
        try:
            ini = configparser.ConfigParser()
            
            # [General]
            ini['General'] = {
                'window_width': str(self.width()),
                'window_height': str(self.height()),
                'font_size_key': self.font_size_key,
                'start_zodiac': self.start_zodiac_combo.currentText() if hasattr(self, 'start_zodiac_combo') else self.__dict__.get('_ini_start_zodiac', '龙'),
                'is_dark_mode': str(self.is_dark_mode),  # 主题模式记忆
            }
            
            # [Paths]
            ini['Paths'] = {
                'data_file': self.data_file,
                'zodiac_file': self.zodiac_file,
                'last_prediction_file': self.last_prediction_file,
            }
            
            # [Zodiac] - 从当前绑定读取
            ini['Zodiac'] = {}
            for num in range(1, 50):
                ini['Zodiac'][str(num)] = self.zodiac_binding.get(num, '')
            
            # [Elements]
            ini['Elements'] = {}
            for num in range(1, 50):
                ini['Elements'][str(num)] = self.zodiac_elements.get(num, '')
            
            # [NumberColors] - 号码颜色与红/蓝/绿分组
            # 必须随每次保存一并写入，否则关窗/改字号时会被整份 INI 覆盖丢失
            ini['NumberColors'] = {}
            for num in range(1, 50):
                ini['NumberColors']['num_%d' % num] = LotteryConfig.get_number_color(num).get('text', '#000000')
            ini['NumberColors']['red_numbers'] = ','.join(str(n) for n in LotteryConfig.RED_NUMBERS)
            ini['NumberColors']['blue_numbers'] = ','.join(str(n) for n in LotteryConfig.BLUE_NUMBERS)
            ini['NumberColors']['green_numbers'] = ','.join(str(n) for n in LotteryConfig.GREEN_NUMBERS)
            
            # [Weights] - 自定义算法权重
            ini['Weights'] = {}
            if hasattr(self, 'custom_weights') and self.custom_weights:
                for name, val in self.custom_weights.items():
                    ini['Weights'][name] = str(val)
            
            # [Display]
            ini['Display'] = {
                'history_page_size': str(self.history_page_size),
                'ball_label_font_size': str(self.ball_label_font_size),
                'is_dark_mode': str(self.is_dark_mode),  # 主题模式
                'margin_top': str(self.margin_top),      # 布局边距
                'margin_bottom': str(self.margin_bottom),
                'margin_left': str(self.margin_left),
                'margin_right': str(self.margin_right),
                'spacing': str(self.spacing),
                'enhanced_mode': str(self.enhanced_mode),
                'reverse_mode': str(self.reverse_mode),
                'deterministic_mode': str(self.deterministic_mode),
                'use_model_cache': str(self._use_model_cache),
                'font_scale_table': str(self._area_font_scales.get('table', 1.0)),
                'font_scale_result': str(self._area_font_scales.get('result', 1.0)),
                'font_scale_list': str(self._area_font_scales.get('list', 1.0)),
                # 矩阵分区拆键：文字 / 号码各自独立（共 8 个）
                'font_scale_number_panel_text': str(self._area_font_scales.get('number_panel_text', 1.0)),
                'font_scale_number_panel_num': str(self._area_font_scales.get('number_panel_num', 1.0)),
                'font_scale_zodiac_panel_text': str(self._area_font_scales.get('zodiac_panel_text', 1.0)),
                'font_scale_zodiac_panel_num': str(self._area_font_scales.get('zodiac_panel_num', 1.0)),
                'font_scale_element_panel_text': str(self._area_font_scales.get('element_panel_text', 1.0)),
                'font_scale_element_panel_num': str(self._area_font_scales.get('element_panel_num', 1.0)),
                'font_scale_attr_panel_text': str(self._area_font_scales.get('attr_panel_text', 1.0)),
                'font_scale_attr_panel_num': str(self._area_font_scales.get('attr_panel_num', 1.0)),
                # 旧 4 键继续写出（值取各自文字键），仅作旧版本回滚兼容；
                # 旧键在新版读取时只迁移为文字键，绝不联动号码。
                'font_scale_number_panel': str(self._area_font_scales.get('number_panel_text', 1.0)),
                'font_scale_zodiac_panel': str(self._area_font_scales.get('zodiac_panel_text', 1.0)),
                'font_scale_element_panel': str(self._area_font_scales.get('element_panel_text', 1.0)),
                'font_scale_attr_panel': str(self._area_font_scales.get('attr_panel_text', 1.0)),
                'font_scale_announcement': str(self._area_font_scales.get('announcement', 1.0)),
                'font_scale_detail': str(self._area_font_scales.get('detail', 1.0)),
                'number_panel_size_scale': str(getattr(self, '_number_panel_size_scale', 1.0)),
                # 面板尺寸设置
                'number_panel_width': str(self._number_panel_size.get('width', 80)),
                'number_panel_height': str(self._number_panel_size.get('height', 60)),
                'number_panel_font': str(self._number_panel_size.get('font', 20)),
                'zodiac_panel_width': str(self._zodiac_panel_size.get('width', 80)),
                'zodiac_panel_height': str(self._zodiac_panel_size.get('height', 60)),
                'zodiac_panel_btn_font': str(self._zodiac_panel_size.get('btn_font', 20)),
                'zodiac_panel_label_font': str(self._zodiac_panel_size.get('label_font', 20)),
                # 号码属性表（三页合并）：新键；旧 zodiac_panel_* 继续写出，保证旧页可回滚
                'attr_panel_width': str(getattr(self, '_attr_panel_size', {}).get('width', 90)),
                'attr_panel_height': str(getattr(self, '_attr_panel_size', {}).get('height', 98)),
                'attr_panel_btn_font': str(getattr(self, '_attr_panel_size', {}).get('btn_font', 28)),
                'attr_panel_label_font': str(getattr(self, '_attr_panel_size', {}).get('label_font', 15)),
                'attr_panel_fonts_custom': '1' if getattr(self, '_attr_panel_size', {}).get('fonts_custom') else '0',
                'attr_merge_v1': '1',
                'element_panel_width': str(self._element_panel_size.get('width', 54)),
                'element_panel_height': str(self._element_panel_size.get('height', 38)),
                'element_panel_btn_font': str(self._element_panel_size.get('btn_font', 16)),
                'element_panel_label_font': str(self._element_panel_size.get('label_font', 15)),
                # 预测结果号码球尺寸
                'pred_ball_width': str(self._prediction_ball_size.get('width', 80)),
                'pred_ball_height': str(self._prediction_ball_size.get('height', 60)),
                'pred_ball_font': str(self._prediction_ball_size.get('font', 20)),
                'pred_ball_label_font': str(self._prediction_ball_size.get('label_font', 20)),
                'pred_ball_label_width': str(self._prediction_ball_size.get('label_width', 0)),
                'pred_ball_label_height': str(self._prediction_ball_size.get('label_height', 0)),
                'pred_ball_plus_size': str(self._prediction_ball_size.get('plus_size', 24)),
                # 概率面板配置
                'prob_period': str(self.prob_period_spin.value()) if hasattr(self, 'prob_period_spin') and self.prob_period_spin else '30',
                'prob_sort_mode': str(self.prob_sort_combo.currentIndex()) if hasattr(self, 'prob_sort_combo') and self.prob_sort_combo else '0',
                # 颜色图例文字大小
                'legend_label_font': str(self._legend_font_size.get('label', 20)),
                'legend_nums_font': str(self._legend_font_size.get('nums', 20)),
                # 详情标签字体和内边距
                'detail_label_font': str(self._detail_label_size.get('font', 20)),
                'detail_label_padding': str(self._detail_label_size.get('padding', 8)),
                # 窗口位置
                'window_x': str(self.x()),
                'window_y': str(self.y()),
                # 当前标签页
                'current_tab_index': str(self.tabs.currentIndex()) if hasattr(self, 'tabs') else '0',
                # 选项卡拖动顺序记忆（标题序列；默认顺序仍由 TAB_INFO["order"] 决定）
                'tab_order': '|'.join(self._tab_titles()) if hasattr(self, 'tabs') else '',
                # 预测算法选择
                'prediction_algorithm_index': str(self.algorithm_combo.currentIndex()) if hasattr(self, 'algorithm_combo') else '0',
                # 预测类型
                'prediction_type': getattr(self, '_prediction_type', 'algorithm'),
                # 回测算法选择
                'backtest_algorithm_index': str(self.backtest_algo_combo.currentIndex()) if hasattr(self, 'backtest_algo_combo') else '0',
                # 回测期数
                'backtest_period': str(self.backtest_period_spin.value()) if hasattr(self, 'backtest_period_spin') else '10',
                # 历史记录当前页码
                # 【修复属性名bug】_current_page从未定义，实际属性是history_page
                'history_current_page': str(getattr(self, 'history_page', 1)),
                # 数字排序/数字选尾「结果分隔符」选择记忆（多格式：空格/逗号/顿号/分号/减号/斜杠/竖线/换行）
                'sort_sep_index': str(self.sort_sep_combo.currentIndex()) if hasattr(self, 'sort_sep_combo') and self.sort_sep_combo else '0',
                'tail_sep_index': str(self.tail_sep_combo.currentIndex()) if hasattr(self, 'tail_sep_combo') and self.tail_sep_combo else '0',
                # 期号详情字体缩放
                'detail_font_scale': str(getattr(self, 'detail_font_scale', 1.0)),
                # 计算规律面板配置
                'calc_skip': str(self.calc_skip_spin.value()) if hasattr(self, 'calc_skip_spin') and self.calc_skip_spin else '0',
                'calc_op': str(self.calc_op_combo.currentIndex()) if hasattr(self, 'calc_op_combo') and self.calc_op_combo else '0',
                'calc_custom_period': '0',
                'calc_filter': str(self.calc_filter_combo.currentIndex()) if hasattr(self, 'calc_filter_combo') and self.calc_filter_combo else '0',
                'calc_topn': str(self.calc_topn_spin.value()) if hasattr(self, 'calc_topn_spin') and self.calc_topn_spin else '5',
                'calc_font_size': '20',
                'calc_result_font': str(self.calc_result_font_spin.value()) if hasattr(self, 'calc_result_font_spin') and self.calc_result_font_spin else '20',
                'calc_rec_font': str(self.calc_rec_font_spin.value()) if hasattr(self, 'calc_rec_font_spin') and self.calc_rec_font_spin else '20',
                'calc_comp_font': str(self.calc_comp_font_spin.value()) if hasattr(self, 'calc_comp_font_spin') and self.calc_comp_font_spin else '20',
                'calc_detail_font': str(self.calc_detail_font_spin.value()) if hasattr(self, 'calc_detail_font_spin') and self.calc_detail_font_spin else '20',
                'calc_width': '0',
                'calc_height': '0',
                # 波色预测面板配置
                'wave_period': str(self.wave_period_spin.value()) if hasattr(self, 'wave_period_spin') and self.wave_period_spin else '30',
                'wave_custom_period': '0',
                'wave_mode': str(self.wave_mode_combo.currentIndex()) if hasattr(self, 'wave_mode_combo') and self.wave_mode_combo else '0',
                'wave_trend': str(self.wave_trend_spin.value()) if hasattr(self, 'wave_trend_spin') and self.wave_trend_spin else '20',
                'wave_font_size': '20',
                'wave_result_font': str(self.wave_result_font_spin.value()) if hasattr(self, 'wave_result_font_spin') and self.wave_result_font_spin else '20',
                'wave_trend_font': str(self.wave_trend_font_spin.value()) if hasattr(self, 'wave_trend_font_spin') and self.wave_trend_font_spin else '20',
                'wave_trans_font': str(self.wave_trans_font_spin.value()) if hasattr(self, 'wave_trans_font_spin') and self.wave_trans_font_spin else '20',
                'wave_width': '0',
                'wave_height': '0',
                # 存储面板配置
                'storage_sort_mode': str(getattr(self, '_storage_sort_mode', 'time_desc')),
                'storage_category': str(getattr(self, '_current_storage_category', 'all')),
                'storage_category_collapsed': str(getattr(self, '_category_collapsed', False)),
                'storage_tag_collapsed': str(getattr(self, '_tag_collapsed', False)),
            }
            # 回填旧 [Display] 键：本次未显式写出的键（如各页面分隔条尺寸）必须保留，
            # 否则保存时会整份覆盖丢失用户拖过的分隔条位置
            if hasattr(self, '_ini') and self._ini.has_section('Display'):
                for _key, _val in self._ini['Display'].items():
                    ini['Display'].setdefault(_key, _val)
            
            # 保存历史记录表列宽
            if hasattr(self, 'history_table'):
                for i in range(self.history_table.columnCount()):
                    ini['Display']['history_col_' + str(i)] = str(self.history_table.columnWidth(i))
            elif hasattr(self, '_history_col_widths'):
                # 表格还没创建时用保存的值
                default_cols = [70, 120, 160, 70, 60, 65, 65, 110, 60]
                for i in range(9):
                    w = self._history_col_widths[i] if i < len(self._history_col_widths) and self._history_col_widths[i] else default_cols[i]
                    ini['Display']['history_col_' + str(i)] = str(w)
            
            # 保存预测记录表格列宽（末列由 stretchLastSection 自动占满视口，
            # 写进去的是当次视口算出的绝对宽度、回灌又显式跳过，属于永不生效的噪声，故不保存）
            if hasattr(self, 'prediction_history_table'):
                _pred_table = self.prediction_history_table
                _pred_cols = _pred_table.columnCount()
                _pred_limit = _pred_cols - 1 if _pred_table.horizontalHeader().stretchLastSection() else _pred_cols
                for i in range(_pred_limit):
                    ini['Display']['prediction_col_' + str(i)] = str(_pred_table.columnWidth(i))
            
            # 数字选择面板选中状态记忆保存
            if hasattr(self, 'number_panel') and hasattr(self.number_panel, 'get_selected_numbers'):
                selected = self.number_panel.get_selected_numbers()
                ini['Display']['selected_numbers'] = ','.join(str(n) for n in selected) if selected else 'none'
            
            # 保存各Splitter分隔条位置
            splitter_list = [
                ('data_import_splitter', self.data_import_splitter if hasattr(self, 'data_import_splitter') else None),
                ('pred_h_splitter', self.pred_h_splitter if hasattr(self, 'pred_h_splitter') else None),
                ('pred_left_v_splitter', self.pred_left_v_splitter if hasattr(self, 'pred_left_v_splitter') else None),
                ('history_h_splitter', self.history_h_splitter if hasattr(self, 'history_h_splitter') else None),
                ('history_left_v_splitter', self.history_left_v_splitter if hasattr(self, 'history_left_v_splitter') else None),
                ('history_right_v_splitter', self.history_right_v_splitter if hasattr(self, 'history_right_v_splitter') else None),
                ('seventh_pred_splitter', self.seventh_pred_splitter if hasattr(self, 'seventh_pred_splitter') else None),
                ('zodiac_h_splitter', self.zodiac_h_splitter if hasattr(self, 'zodiac_h_splitter') else None),
                ('element_h_splitter', self.element_h_splitter if hasattr(self, 'element_h_splitter') else None),
                ('element_v_splitter', self.element_v_splitter if hasattr(self, 'element_v_splitter') else None),
                ('attr_h_splitter', self.attr_h_splitter if hasattr(self, 'attr_h_splitter') else None),
                ('bd_mid_splitter', self.bd_mid_splitter if hasattr(self, 'bd_mid_splitter') else None),
                ('bd_main_splitter', self.bd_main_splitter if hasattr(self, 'bd_main_splitter') else None),
                ('stats_splitter', self.stats_splitter if hasattr(self, 'stats_splitter') else None),
                ('storage_splitter', self.storage_splitter if hasattr(self, 'storage_splitter') else None),
                ('number_pred_splitter', self.number_pred_splitter if hasattr(self, 'number_pred_splitter') else None),
            ]
            for name, splitter in splitter_list:
                if splitter is not None:
                    sizes = splitter.sizes()
                    if not sizes or sum(sizes) <= 0:
                        continue
                    key = name + '_sizes'
                    if splitter.isVisible():
                        ini['Display'][key] = ','.join(str(s) for s in sizes)
                    else:
                        # 隐藏页面不写当前布局值，保留 INI 中上次真正拖动保存的位置，
                        # 避免切换选项卡时把用户拖过的分隔条覆盖成默认比例
                        prev = self._ini['Display'].get(key, '') if hasattr(self, '_ini') else ''
                        if prev:
                            ini['Display'][key] = prev
            
            # 保存通用控件状态（下拉框索引/数字框数值/复选框/表格列宽，v0.0.19 记忆机制）
            self._save_widget_states(ini)
            
            # 确保目录存在
            config_dir = os.path.dirname(self.config_file)
            if config_dir and not os.path.exists(config_dir):
                os.makedirs(config_dir, exist_ok=True)
            
            # 内容一致就不写：把待写内容序列化后与磁盘现有内容比较。
            # 这样即使某个信号在「值没变」的情况下调用了本方法（如重复选中同一项），
            # 也不会制造一次无意义的写盘与哈希变化。
            buffer = io.StringIO()
            ini.write(buffer)
            new_text = buffer.getvalue()
            old_text = None
            if not force and os.path.exists(self.config_file):
                try:
                    with open(self.config_file, 'r', encoding='utf-8') as f:
                        old_text = f.read()
                except Exception:
                    old_text = None
            
            if old_text == new_text:
                # 磁盘内容与本次计算结果完全一致：只更新内存对象，不触盘、不写镜像
                self._ini = ini
                return True

            # 只有内容确实变化才会走到这里：直接覆盖写配置，避免无意义的磁盘写入
            with open(self.config_file, 'w', encoding='utf-8') as f:
                ini.write(f)
            
            self._ini = ini
            if not force:
                # 标记「确实发生过用户改动」：关窗时据此决定是否再落盘一次
                self._ini_dirty = True

            # 【数据库同步】把全部配置以 JSON 镜像写入 SQLite（app_config 表 ui_ini）
            if self._db is not None:
                try:
                    snapshot = {sec: dict(ini[sec]) for sec in ini.sections()}
                    self._db.set_config('ui_ini', json.dumps(snapshot, ensure_ascii=False))
                except Exception as db_err:
                    print("配置镜像写入数据库失败: " + str(db_err))
            return True
        except Exception as e:
            print("保存INI配置失败: " + str(e))
            return False

    def _save_widget_states(self, ini):
        """功能：把可交互控件的状态写入 INI [WidgetState]（通用记忆，v0.0.19）
        说明：自动扫描主窗口属性，保存下拉框索引、数字框数值、滑块值、
              复选框状态、表格列宽；控件名称即记忆键，新增控件无需再写专用代码。
        参数:
            ini: configparser.ConfigParser 实例
        返回: 无
        """
        try:
            section = 'WidgetState'
            if not ini.has_section(section):
                ini.add_section(section)
            for name, widget in list(self.__dict__.items()):
                if name.startswith('__') or widget is None:
                    continue
                try:
                    if isinstance(widget, QComboBox):
                        ini[section]['c_' + name] = str(widget.currentIndex())
                    elif isinstance(widget, QSpinBox):
                        ini[section]['s_' + name] = str(widget.value())
                    elif isinstance(widget, QSlider):
                        ini[section]['v_' + name] = str(widget.value())
                    elif isinstance(widget, (QCheckBox, QRadioButton)):
                        ini[section]['b_' + name] = '1' if widget.isChecked() else '0'
                    elif isinstance(widget, QTableWidget):
                        if widget.columnCount() > 0:
                            # 「预测记录」表末列为 stretchLastSection 拉伸列（该表 t_ 回灌整体跳过），不写噪声宽度
                            _t_cols = widget.columnCount()
                            _t_limit = _t_cols
                            if (name == 'prediction_history_table'
                                    and widget.horizontalHeader().stretchLastSection()):
                                _t_limit = _t_cols - 1
                            ini[section]['t_' + name] = ','.join(
                                str(widget.columnWidth(i)) for i in range(_t_limit))
                except Exception:
                    continue  # 单个控件异常不影响整体保存
            # 对话框等局部控件不在 self.__dict__ 中，额外状态由页面模块写入
            # _widget_state_extra（c_/s_/v_/b_/t_ 前缀键），在此统一合并落盘
            extra = getattr(self, '_widget_state_extra', None)
            if not isinstance(extra, dict):
                extra = {}
                self._widget_state_extra = extra
            # 字号抽屉的分区缩放键是浮层内的纯状态（没有主窗口控件可被上面的属性扫描命中），
            # 因此并入 _widget_state_extra，与对话框控件走同一条 [WidgetState] 落盘路径。
            for area in _MATRIX_SCALE_AREAS:
                for dim in ('text', 'num'):
                    extra[f'f_{area}_{dim}'] = round(
                        float(self._area_font_scales.get(f'{area}_{dim}', 1.0)), 2)
            for key, value in extra.items():
                ini[section][str(key)] = str(value)
        except Exception as e:
            print("保存控件状态失败: " + str(e))

    def _restore_widget_states(self):
        """功能：从 INI [WidgetState] 恢复控件状态（必须在 _init_ui() 之后调用）
        说明：恢复时阻塞信号，避免恢复过程触发大量副作用与重复写盘；
              恢复完成后同步复选框对应的内部开关与算法说明文字。
        参数: 无
        返回: 无
        """
        if not hasattr(self, '_ini') or not self._ini.has_section('WidgetState'):
            return
        restored = 0
        try:
            for key, raw in self._ini['WidgetState'].items():
                if len(key) < 3:
                    continue
                prefix, name = key[:2], key[2:]
                widget = getattr(self, name, None)
                if widget is None:
                    continue
                try:
                    if prefix == 'c_' and isinstance(widget, QComboBox):
                        idx = int(raw)
                        if 0 <= idx < widget.count() and idx != widget.currentIndex():
                            widget.blockSignals(True)
                            widget.setCurrentIndex(idx)
                            widget.blockSignals(False)
                            restored += 1
                    elif prefix == 's_' and isinstance(widget, QSpinBox):
                        val = int(raw)
                        if val != widget.value():
                            widget.blockSignals(True)
                            widget.setValue(val)
                            widget.blockSignals(False)
                            restored += 1
                    elif prefix == 'v_' and isinstance(widget, QSlider):
                        val = int(raw)
                        if val != widget.value():
                            widget.blockSignals(True)
                            widget.setValue(val)
                            widget.blockSignals(False)
                            restored += 1
                    elif prefix == 'b_' and isinstance(widget, (QCheckBox, QRadioButton)):
                        checked = raw.strip() == '1'
                        if checked != widget.isChecked():
                            widget.blockSignals(True)
                            widget.setChecked(checked)
                            widget.blockSignals(False)
                            restored += 1
                    elif prefix == 't_' and isinstance(widget, QTableWidget):
                        # 「预测记录」表列宽由 Display.prediction_col_* 专用通道管理：
                        # 末列是 setStretchLastSection 负责的拉伸列，通用 t_ 里存的是
                        # 上一窗口“占满后的绝对宽度”，回灌会覆盖专用通道的修正
                        # （时间列最小宽度被改回 150、1180 档被 1104 撑出横向滚动条）。
                        if name == 'prediction_history_table':
                            continue
                        widths = [int(x) for x in raw.split(',') if x.strip()]
                        if len(widths) == widget.columnCount():
                            for i, w in enumerate(widths):
                                if w > 0:
                                    widget.setColumnWidth(i, w)
                            restored += 1
                except Exception:
                    continue
            # 复选框恢复后同步内部开关（信号被阻塞，这里手动补齐状态）
            for attr, flag in (
                    ('enhanced_mode_checkbox', 'enhanced_mode'),
                    ('deterministic_checkbox', 'deterministic_mode'),
                    ('model_cache_check', '_use_model_cache'),
                    ('lock_predict_check', '_block_no_new_data')):
                widget = getattr(self, attr, None)
                if widget is not None:
                    setattr(self, flag, widget.isChecked())
            # 算法下拉框恢复后同步说明文字
            if hasattr(self, 'algorithm_combo'):
                idx = self.algorithm_combo.currentIndex()
                self.current_algorithm_index = idx
                if 0 <= idx < len(LotteryConfig.ALGORITHMS) and hasattr(self, 'algorithm_desc_label'):
                    self.algorithm_desc_label.setText(LotteryConfig.ALGORITHMS[idx][1])
            if restored:
                print("控件状态恢复: %d 项" % restored)
        except Exception as e:
            print("恢复控件状态失败: " + str(e))

    def _apply_splitter_sizes(self, splitter, name, default_sizes=None):
        """功能：应用保存的 Splitter 分隔条位置，并连接拖动保存信号
        注意：会连接 splitterMoved → _save_ini_config（拖动即落盘，受写盘闸门控制）；
              旧尺寸只在「栏数不符或某栏 < 30px」时判为无效并回退 default_sizes，
              不限制用户把分隔条拖成 3:1/4:1；异常吞掉不回退。
        参数:
            splitter: 目标分隔器
            name: INI 中记录的键名（如 'zodiac_h_splitter'）
            default_sizes: 没有可用保存值时的默认尺寸（按比例分配，如 [600, 400]）
        返回:
            无
        """
        applied = False
        if hasattr(self, '_splitter_sizes') and name in self._splitter_sizes:
            sizes = self._splitter_sizes[name]
            # 只拦截真正无效的旧配置：栏数不符或某一栏被压到 30px 以下。
            # 不再限制「每栏至少占 1/4」——用户把分隔条拖到 3:1 甚至 4:1 都是合法操作，
            # 旧的比例校验会把这类记忆值判为无效并强制回退默认值。
            valid = bool(sizes) and len(sizes) == splitter.count() and all(s >= 30 for s in sizes)
            if valid:
                try:
                    splitter.setSizes(sizes)
                    applied = True
                except Exception:
                    pass
        if not applied and default_sizes and len(default_sizes) == splitter.count():
            splitter.setSizes(default_sizes)
        # 连接拖动信号，实时保存
        splitter.splitterMoved.connect(lambda pos, index: self._save_ini_config())
    


    # [全局主题] 主题切换、选项卡切换

    def _on_toggle_theme(self):
        """功能：切换深色/浅色主题
        注意：只改内存开关并重建样式表，再让历史表/预测记录表/七策略文本按新主题
              重绘（不重算预测结果）；不写盘——主题要等下次 _save_ini_config 才落盘。
        参数:
            无
        返回:
            无
        """
        self.is_dark_mode = not self.is_dark_mode
        self._update_stylesheet()
        _tab_history.update_history_table(self)
        _tab_prediction_history.refresh_prediction_history_table(self)
        # v0.0.48：号码预测的文本/卡片有自定义主题色，切换主题后同步重绘（不重算）
        if hasattr(self, 'number_pred_text'):
            _tab_prediction.refresh_number_strategy_styles(self)
        theme_name = "深色模式" if self.is_dark_mode else "浅色模式"
        self.statusBar().showMessage("已切换到" + theme_name)
    
    # 功能10：数据校验提示
    def _on_tab_changed(self, index):
        """功能：标签页切换时按需初始化/刷新（QTabWidget.currentChanged 槽）
        注意：仅当索引真正变化时才调用 _save_ini_config（防拖动切换时频繁写盘）；
              切到「预测与抽取」页会重读生肖/五行绑定并刷新标签，但不重算七策略、
              不改动已生成结果；图表页只置初始化标记。
        参数:
            index: 新选项卡索引（0 起）
        返回:
            无
        """
        # 【Bug修复】仅标签页实际变化时保存配置，避免频繁I/O
        if not hasattr(self, '_last_tab_index'):
            self._last_tab_index = -1
        if index != self._last_tab_index:
            self._last_tab_index = index
            self._save_ini_config()
        # 切换选项卡不保留抽屉打开状态；关闭后立即按新页重建绑定
        if getattr(self, 'display_drawer', None) is not None:
            if self.display_drawer.isVisible():
                self.display_drawer.hide()
            self._sync_display_drawer_page()
        # 检查是否切换到统计图表标签页（索引5）
        if index == 5 and not self._chart_initialized:
            self._chart_initialized = True
            # 图表控件已在_create_statistics_chart_tab中创建，无需额外初始化
            self.statusBar().showMessage("图表控件已初始化")
        # v0.0.48：生肖/五行绑定在号码属性页（三页合并后）随时修改；切回预测页时
        # 重读最新绑定并刷新标签（不重新计算七策略，不改变已生成结果）
        if getattr(self, 'tabs', None) is not None and self.tabs.tabText(index) == '预测与抽取' \
                and hasattr(self, 'number_pred_text'):
            _tab_prediction.refresh_number_strategy_styles(self)
    
    # 【区域2】数据导入与格式转换：页面构建、批量导入/导出、格式转换在
    # TAB/data_import.py、TAB/history.py；本文件保留 _load_data/_save_data、
    # _safe_write_file/_safe_write_csv/_safe_write_json 与手动增删改入口。
    # 入口：TAB/data_import.py 的 build(host)（自动加载）
    def _safe_write_file(self, filepath, content, max_retries=3, retry_delay=2):
        """功能：【Bug修复】安全写入文件，使用临时文件+原子重命名防止写入中断导致文件损坏

        先写入临时文件（.tmp_前缀），写入成功后通过os.replace原子替换目标文件。
        os.replace在Windows上也是原子操作，确保目标文件始终完整。
        重试间隔 2 秒、最多尝试 3 次（最坏阻塞约 4 秒），避免UI长时间无响应。
        注意：重试期间会用 time.sleep 阻塞 UI 线程（属已知代价）；反馈只写状态栏，
              不弹模态框（启动期 _load_data 路径同样安全）；每次失败记一条 WARNING 日志；
              失败一律 return False，不抛异常；会按需创建父目录。
        参数:
            filepath: 目标文件绝对路径
            content: 完整文本内容（调用方负责编码前的序列化）
            max_retries: 最大尝试次数（含首次）
            retry_delay: 每次失败后的等待秒数
        返回:
            bool True=已成功落盘；False=重试耗尽或写失败
        """
        import tempfile  # 作用说明：创建 .tmp_ 临时文件，配合 os.replace 实现原子落盘
        for attempt in range(max_retries):
            try:
                # 确保目录存在
                dir_path = os.path.dirname(filepath) if os.path.dirname(filepath) else '.'
                os.makedirs(dir_path, exist_ok=True)
                # 原子写入：先写临时文件，再原子替换
                tmp_fd, tmp_path = tempfile.mkstemp(
                    dir=dir_path,
                    prefix='.tmp_' + os.path.basename(filepath))
                try:
                    with os.fdopen(tmp_fd, 'w', encoding='utf-8') as f:
                        f.write(content)
                    os.replace(tmp_path, filepath)  # Windows原子操作
                except Exception:
                    # 清理临时文件
                    try:
                        os.unlink(tmp_path)
                    except OSError:
                        pass
                    raise
                return True
            except Exception as e:
                logging.warning('写入文件失败（第%d/%d次）: %s [%s]',
                                attempt + 1, max_retries, filepath, type(e).__name__)
                if attempt < max_retries - 1:
                    try:
                        self.statusBar().showMessage(
                            '写入失败，' + str(retry_delay) + ' 秒后重试 (' +
                            str(attempt + 1) + '/' + str(max_retries) + ')：' +
                            os.path.basename(filepath))
                    except Exception:
                        pass
                    import time  # 作用说明：写盘重试之间做 sleep 退避（会阻塞 UI 线程，属已知代价）
                    time.sleep(retry_delay)
                else:
                    try:
                        self.statusBar().showMessage(
                            '保存失败，本次修改未写入磁盘：' + os.path.basename(filepath))
                    except Exception:
                        pass
                    return False
        return False
    
    def _safe_write_csv(self, filepath, rows, max_retries=3, retry_delay=2):
        """功能：【需求3-新增】安全写入CSV文件
        注意：先在内存 StringIO 拼完整内容再委托 _safe_write_file 原子落盘；
              序列化失败只弹警告并返回 False，不抛异常、不产生半截文件。
        参数:
            filepath: 目标文件绝对路径
            rows: 二维列表，每行是一个列表
            max_retries: 最大尝试次数（透传给 _safe_write_file）
            retry_delay: 每次失败后的等待秒数（透传给 _safe_write_file）
        返回:
            bool True=写入成功；False=生成或写入失败
        """
        import io  # 作用说明：StringIO 在内存拼出 CSV 全文，避免边写边出错留下半截文件
        try:
            # 先在内存中生成CSV内容
            output = io.StringIO()
            writer = csv.writer(output)
            for row in rows:
                writer.writerow(row)
            csv_content = output.getvalue()
            return self._safe_write_file(filepath, csv_content, max_retries, retry_delay)
        except Exception as e:
            QMessageBox.warning(self, 'CSV生成失败', 'CSV内容生成失败: ' + str(e))
            return False
    
    def _safe_write_json(self, filepath, data, max_retries=3, retry_delay=2):
        """功能：【需求3-新增】安全写入JSON文件
        注意：序列化用 lib.ml_model.MLPredictionModel._json_default_handler
              兜底（全项目唯一的 JSON 默认处理器），中文不转义；失败只弹警告返回 False。
        参数:
            filepath: 目标文件绝对路径
            data: 任意可序列化对象（含 datetime 等由 default handler 处理）
            max_retries: 最大尝试次数（透传）
            retry_delay: 每次失败后的等待秒数（透传）
        返回:
            bool True=写入成功；False=序列化或写入失败
        """
        try:
            json_content = json.dumps(data, ensure_ascii=False, indent=2, default=MLPredictionModel._json_default_handler)
            return self._safe_write_file(filepath, json_content, max_retries, retry_delay)
        except Exception as e:
            QMessageBox.warning(self, 'JSON转换失败', 'JSON序列化失败: ' + str(e))
            return False
    
    def _load_data(self):
        """功能：加载彩票数据
        优先级：彩票数据.json → SQLite 镜像（history_records）→ 生成100条示例数据
        注意：走数据库回退或生成示例数据时会主动调用 _save_data 落盘（重建 JSON），
              即启动阶段存在「数据文件缺失」这一种合法写盘场景；只改
              self.historical_data，不触发界面重绘（由调用方负责）。
              JSON 损坏时保留 .bad-<时间戳> 副本、优先从 SQLite 恢复，并置
              _data_degraded=True；此时内存为空也不得覆盖数据库镜像。
        参数:
            无（数据路径取 self.data_file，数据库取 self._db）
        返回:
            无
        """
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    self.historical_data = json.load(f)
                print("已加载 " + str(len(self.historical_data)) + " 条历史记录")
            else:
                # JSON 丢失时先从数据库镜像恢复，避免历史开奖数据整体丢失
                db_rows = []
                if self._db is not None:
                    try:
                        db_rows = self._db.load_history()
                    except Exception as db_err:
                        print("从数据库恢复历史数据失败: " + str(db_err))
                if db_rows:
                    # 数据库镜像不存生肖快照：恢复时按当前绑定补齐（已有快照的记录不会被覆盖）
                    LotteryConfig.ensure_zodiac_snapshots(db_rows, self.zodiac_binding)
                    self.historical_data = db_rows
                    print("已从数据库恢复 " + str(len(db_rows)) + " 条历史记录")
                    self._save_data()  # 重建 JSON 文件，恢复后仍以 JSON 为主
                else:
                    self.historical_data = DataUtils.generate_sample_data(100)
                    # 示例数据同样在写入时刻固化生肖快照，保证详情展示口径一致
                    LotteryConfig.ensure_zodiac_snapshots(self.historical_data, self.zodiac_binding)
                    print("已生成100条示例数据")
                    # 首次生成的示例数据立即落盘，避免用户未点「保存」就丢失；
                    # 落盘后文件存在，后续启动不会再重复生成
                    self._save_data()
        except Exception as e:
            print("加载数据失败: " + str(e))
            logging.warning('加载数据失败，进入降级模式: %s [%s]', self.data_file, type(e).__name__)
            # ① 保留损坏证据：复制为 .bad-<时间戳>，绝不删除原文件
            bad_path = self.data_file + '.bad-' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            try:
                import shutil  # 作用说明：复制损坏的 JSON 作为证据副本，避免原文件被后续保存覆盖
                if os.path.exists(self.data_file):
                    shutil.copy2(self.data_file, bad_path)
                    print("损坏数据已保留副本: " + bad_path)
            except Exception as copy_err:
                logging.warning('保留损坏数据副本失败: %s [%s]', bad_path, type(copy_err).__name__)
            # ② 立刻尝试从 SQLite 镜像恢复
            db_rows = []
            if self._db is not None:
                try:
                    db_rows = self._db.load_history()
                except Exception as db_err:
                    print("从数据库恢复历史数据失败: " + str(db_err))
                    logging.warning('从数据库恢复历史数据失败: [%s]', type(db_err).__name__)
            if db_rows:
                # 数据库镜像不存生肖快照：恢复时按当前绑定补齐（已有快照的记录不会被覆盖）
                LotteryConfig.ensure_zodiac_snapshots(db_rows, self.zodiac_binding)
                self.historical_data = db_rows
                print("已从数据库恢复 " + str(len(db_rows)) + " 条历史记录")
            else:
                # ③ 只有数据库也为空时才允许置空，避免误判
                self.historical_data = []
            # ④ 进入降级模式：在用户显式确认前，禁止以空列表覆盖数据库历史镜像
            self._data_degraded = True
            try:
                self.statusBar().showMessage(
                    '数据文件损坏，已进入降级模式：从数据库恢复 ' + str(len(self.historical_data)) +
                    ' 条，暂禁止写入空数据')
            except Exception:
                pass
        # 加载完成后把数据概况同步到数据库
        self._sync_data_state_to_db()
    
    def _save_data(self):
        """功能：【需求3-更新】把历史数据安全落盘，并同步数据库镜像与概况
        注意：写 JSON 成功后依次触发 _sync_history_to_db（历史镜像）与
              _sync_data_state_to_db（记录数/最新期号），共三处写库/写盘副作用；
              写盘失败只返回 False，不抛异常。
        参数:
            无（数据取 self.historical_data，路径取 self.data_file）
        返回:
            bool True=JSON 写入成功；False=写入失败（数据库同步不会执行）
        """
        if self._safe_write_json(self.data_file, self.historical_data):
            print("数据保存成功")
            if self._data_degraded and self.historical_data:
                # 已有非空数据并成功落盘，视为用户侧恢复完成，解除降级保护
                self._data_degraded = False
            self._sync_history_to_db()     # 历史数据镜像写入 SQLite（JSON 丢失时兜底）
            self._sync_data_state_to_db()  # 同步记录数/最新期号到数据库
            return True
        else:
            print("保存数据失败")
            return False
    
    
    def _on_save_clicked(self):
        """功能：保存按钮点击处理（落盘历史数据并提示结果）
        注意：会写 JSON + 同步 SQLite 镜像；成功/失败都以模态消息框提示，
              用户点确定后才返回。
        参数:
            无
        返回:
            无
        """
        if self._save_data():
            QMessageBox.information(self, "成功", "数据保存成功")
        else:
            QMessageBox.warning(self, "错误", "数据保存失败")
    
    def _on_add_data_clicked(self):
        """功能：添加数据按钮点击处理（多行输入按行逐条添加）
        注意：模态多行输入框；逐行委托 DataUtils.parse_txt_line（9 段口径），
              空行忽略、无效行计入跳过数；全部无效时不改内存也不写盘；
              有效则依次 insert(0) 后写盘并刷新历史表，最后提示成功/跳过条数。
        参数:
            无（数据来自对话框文本）
        返回:
            无
        """
        # 提示文案必须给足 7 个号码（6 正码 + 1 特别码），否则示例本身只有 8 段，
        # 会被 parse_txt_line 按「缺特别码」拒绝
        text, ok = QInputDialog.getMultiLineText(self, "添加数据", "请输入开奖数据（格式：期号 日期 6个正码 特别码，共 9 段，可一次粘贴多行）:\n例如：117 2026-04-27 05 12 23 34 45 06 08")
        if ok and text.strip():
            try:
                # TXT 行解析统一由 DataUtils.parse_txt_line 负责（9 段口径：
                # 第 1 段期号、第 2 段日期、第 3~8 段 6 个正码、第 9 段特别码）。
                # 原内联实现用 len>=8 + parts[7] 会把第 6 个正码当成特别码，已删除。
                # parse_txt_line 的约定是「一行一条」，整段传入只会解析第一行、
                # 其余行被静默丢弃，因此这里只做换行拆分，逐行委托同一函数，
                # 不复制任何解析规则。
                lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
                records = []
                skipped = 0
                for line in lines:
                    # 空行不算「格式错误」，直接忽略，避免末尾换行被计入跳过数
                    if not line.strip():
                        continue
                    parsed = DataUtils.parse_txt_line(line)
                    if parsed:
                        # 解析函数返回不可变元组，按固定顺序解包，避免下标再次散落
                        period, date, numbers, special = parsed
                        # 期号统一口径：存储期序 + 完整期号/年份副字段，展示用期序
                        period_seq, period_full, period_year = DataUtils.split_period(
                            period, date)
                        records.append({
                            'period': period_seq, 'period_full': period_full,
                            'period_year': period_year, 'date': date,
                            'numbers': numbers, 'special': special,
                        })
                    else:
                        # # 表头、8 段缺特别码、非数字乱码等都在这里计入跳过
                        skipped += 1
                # 写入时刻固化生肖快照：之后改绑号码生肖，本期历史展示不会被追溯改写
                for record in records:
                    LotteryConfig.attach_zodiac_snapshot(record, self.zodiac_binding)
                if not records:
                    # 全无效：不写盘、不改内存，只提示格式不正确
                    QMessageBox.warning(self, "错误", "数据格式不正确")
                    return
                # 逐条插入到最前面，与单行添加时的顺序语义一致（单行即插入 1 条）
                before_data = list(self.historical_data)  # 操作前浅拷贝切片，保存失败时原样回滚
                for record in records:
                    self.historical_data.insert(0, record)
                if not self._save_data():
                    self.historical_data[:] = before_data
                    try:
                        _tab_history.update_history_table(self)
                    except Exception as rollback_err:
                        QMessageBox.warning(self, "错误", "内存与磁盘不一致：回滚界面失败 " + str(rollback_err))
                        return
                    self.statusBar().showMessage("保存失败，本次修改未写入磁盘")
                    QMessageBox.warning(self, "保存失败", "保存失败，本次修改未写入磁盘")
                    return
                _tab_history.update_history_table(self)
                QMessageBox.information(
                    self, "成功",
                    "数据添加成功：成功 " + str(len(records)) + " 条 / 跳过 " + str(skipped) + " 条")
            except Exception as e:
                QMessageBox.warning(self, "错误", "添加失败: " + str(e))
    
    def _on_delete_data_clicked(self):
        """功能：删除数据按钮点击处理（删除表格当前选中行）
        注意：需先选行，否则只提示不动作；二次确认后才删；表格行号是页内相对索引，
              必须加分页偏移 (history_page-1)*history_page_size 才能定位真实记录；
              删除后立即写盘并刷新历史表。
        参数:
            无（目标行来自 self.history_table.currentRow()）
        返回:
            无
        """
        if self.history_table.currentRow() < 0:
            QMessageBox.information(self, "提示", "请先选择要删除的记录")
            return
        reply = QMessageBox.question(self, "确认删除", "确定要删除选中的记录吗？", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            # 【修复分页索引bug】表格行号是页内相对索引，需加上分页偏移量转为绝对索引
            page_offset = (self.history_page - 1) * self.history_page_size
            row = self.history_table.currentRow() + page_offset
            if 0 <= row < len(self.historical_data):
                before_data = list(self.historical_data)  # 操作前浅拷贝切片，保存失败时原样回滚
                del self.historical_data[row]
                if not self._save_data():
                    self.historical_data[:] = before_data
                    try:
                        _tab_history.update_history_table(self)
                    except Exception as rollback_err:
                        QMessageBox.warning(self, "错误", "内存与磁盘不一致：回滚界面失败 " + str(rollback_err))
                        return
                    self.statusBar().showMessage("保存失败，本次修改未写入磁盘")
                    QMessageBox.warning(self, "保存失败", "保存失败，本次修改未写入磁盘")
                    return
                _tab_history.update_history_table(self)
                QMessageBox.information(self, "成功", "删除成功")
    
    def _on_clear_data_clicked(self):
        """功能：清空按钮点击处理（清空全部历史记录）
        注意：不可恢复操作，必须先经二次确认；确认后就地 clear self.historical_data，
              立即写盘并刷新历史表；取消则不改任何数据。
        参数:
            无
        返回:
            无
        """
        reply = QMessageBox.question(self, "确认清空", "确定要清空所有历史记录吗？此操作不可恢复！", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            before_data = list(self.historical_data)  # 操作前浅拷贝切片，保存失败时原样回滚
            self.historical_data.clear()
            if not self._save_data():
                self.historical_data[:] = before_data
                try:
                    _tab_history.update_history_table(self)
                except Exception as rollback_err:
                    QMessageBox.warning(self, "错误", "内存与磁盘不一致：回滚界面失败 " + str(rollback_err))
                    return
                self.statusBar().showMessage("保存失败，本次修改未写入磁盘")
                QMessageBox.warning(self, "保存失败", "保存失败，本次修改未写入磁盘")
                return
            _tab_history.update_history_table(self)
            QMessageBox.information(self, "成功", "历史记录已清空")
    # 算法预测：策略计算与界面在 TAB/prediction.py；本文件仅保留
    # _get_prediction_by_index（lib/algorithms.py 注册表调度）。
    def _get_prediction_by_index(self, predictor, algo_index):
        """功能：根据算法编号获取预测结果（正码数量/计算方法全部来自 lib/algorithms.py 注册表）

        原实现为 23 条 if/elif 手写调度并把数量写死为 6/1，已与预测页的
        lambda 字典分叉；现统一走注册表，新增算法只需改注册表一处。
        注意：本方法只计算不落盘；未知编号回退到综合推荐；
              enhanced / reverse 取自当前窗口开关，回测时需自行传入对应 predictor。

        参数:
            predictor: PredictionAlgorithms 实例（回测时为轻量模式实例）
            algo_index: 算法编号（0..22，未知编号回退到综合推荐）
        返回:
            list[int]: 预测号码（常规算法 6 个，特别码算法 1 个）
        """
        return run_algorithm(predictor, algo_index,
                             enhanced=self.enhanced_mode, reverse=self.reverse_mode)

    def _persist_bindings(self):
        """功能：静默保存生肖/五行绑定到 JSON 与 INI（即时生效场景用，不弹窗、不提示重启）
        注意：会写 生肖绑定.json（经 _safe_write_json 原子落盘），随后调用
              _save_ini_config（受写盘闸门控制）；start_zodiac 控件不存在时退回「龙」；
              任何异常都被吞掉，保证绑定操作不会因保存失败而打断界面。
        参数:
            无（数据取 self.zodiac_binding / self.zodiac_elements）
        返回:
            无
        """
        try:
            data = {
                'names': {str(k): v for k, v in self.zodiac_binding.items()},
                'elements': {str(k): v for k, v in self.zodiac_elements.items()},
                'start_zodiac': self.start_zodiac_combo.currentText() if hasattr(self, 'start_zodiac_combo') else '龙'
            }
            self._safe_write_json(self.zodiac_file, data)
            self._save_ini_config()
        except Exception:
            pass



    def dragEnterEvent(self, event):
        """功能：拖入文件时接受拖放（v0.0.28 起实现已迁移到 TAB/data_storage.py 的 drag_enter_event）
        注意：本方法只是转发壳，函数内 import 以避免模块循环依赖；
              实际行为（是否 acceptProposedAction）由 TAB 页决定，此处不写盘。
        参数:
            event: QDragEnterEvent
        返回:
            被转发函数的返回值（通常为 None）
        """
        from TAB.data_storage import drag_enter_event  # 作用说明：取数据存储页的拖入处理实现（函数内导入，避免模块级循环依赖）
        return drag_enter_event(self, event)

    def dragLeaveEvent(self, event):
        """功能：拖出控件时复位高亮（v0.0.28 起实现已迁移到 TAB/data_storage.py 的 drag_leave_event）
        注意：转发壳，函数内 import 避免循环依赖；只改界面高亮，不读写磁盘。
        参数:
            event: QDragLeaveEvent
        返回:
            被转发函数的返回值（通常为 None）
        """
        from TAB.data_storage import drag_leave_event  # 作用说明：取数据存储页的拖出处理实现（函数内导入，避免模块级循环依赖）
        return drag_leave_event(self, event)

    def dropEvent(self, event):
        """功能：处理文件拖放导入（v0.0.28 起实现已迁移到 TAB/data_storage.py 的 drop_event）
        注意：转发壳，函数内 import 避免循环依赖；真正的导入与写盘发生在 TAB 层，
              本方法不直接改 self.historical_data。
        参数:
            event: QDropEvent（含文件 URL 列表）
        返回:
            被转发函数的返回值（通常为 None）
        """
        from TAB.data_storage import drop_event  # 作用说明：取数据存储页的拖放导入实现（函数内导入，避免模块级循环依赖）
        return drop_event(self, event)

