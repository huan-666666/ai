# -*- coding: utf-8 -*-
"""
============================================================================
run.py - 程序主入口、主窗口启动核心
============================================================================
功能说明：
    1. 初始化双嵌入式数据库（SQLite + DuckDB，见 lib/db_helper.py）
    2. 直接创建主窗口 LotteryPredictionWindow（标签页由 TAB/*.py 构建）
    3. 进入 Qt 事件循环，退出时清理科学计算库资源

执行顺序（顺序本身是修复的一部分，不要随手调换）：
    设置线程数环境变量 → 导入 Qt 与主窗口 → 主线程预加载 C 扩展
    → 初始化数据库 → 创建 QApplication 与主窗口 → 进入事件循环
    → finally 中清理资源并用 os._exit 直接结束进程。
    - 线程数必须早于 numpy/BLAS 首次初始化，否则设置无效；
    - C 扩展（sklearn/scipy）必须在主线程完成初始化，放到 QThread 里首次导入
      会与 Qt 事件循环抢占初始化，触发 0xC0000409（栈缓冲区溢出）；
    - 清理与 os._exit 必须在事件循环结束之后、解释器模块清理之前完成。

异常与降级策略（本文件的容错边界都在 main() 内）：
    - 缺 PyQt6：打印安装提示，直接以退出码 1 结束进程（此时无资源可清，走 os._exit 最快）；
    - 缺 sklearn / scipy：预加载失败被静默忽略，对应功能使用时由 lib 懒加载器降级
      （相关页面给出「库不可用」提示或改用 matplotlib 等回退路径）；
    - 数据库初始化失败：只打印警告，界面照常启动（历史数据由 JSON 主存储兜底）；
    - 事件循环内异常：traceback 打印到标准错误，退出码改为 1，但仍保证 finally 执行；
    - 未捕获异常（主线程或后台 Python 线程）：由 main() 安装的钩子追加写入
      系统v7.5/崩溃日志.log，同时保留 stderr 堆栈；落盘失败只提示、不二次抛出，
      原有退出行为（退出码、os._exit 清理）完全不变。
============================================================================
"""

# ============================================================================
# 【彻底修复0xC0000409】在import任何科学计算库之前设置环境变量，
# 限制BLAS/OpenMP/MKL线程数为1，防止多线程C栈溢出。
# 必须在 import numpy 之前设置才能生效（lib/__init__.py 中也有同样设置）。
# ============================================================================
import os as _os  # 作用：只在本段用来写进程环境变量；别名 _os 以示「早于其它 import 的引导代码」
_os.environ['OMP_NUM_THREADS'] = '1'  # 作用：OpenMP 线程数=1；多线程并行区会放大栈占用，Windows 下易触发 0xC0000409
_os.environ['OPENBLAS_NUM_THREADS'] = '1'  # 作用：OpenBLAS 线程数=1；numpy 矩阵运算内部线程池同理
_os.environ['MKL_NUM_THREADS'] = '1'  # 作用：MKL（Intel 数学库）线程数=1；scikit-learn 依赖它
_os.environ['NUMEXPR_NUM_THREADS'] = '1'  # 作用：numexpr 线程数=1；pandas 的 eval/query 会用到它
_os.environ['VECLIB_MAXIMUM_THREADS'] = '1'  # 作用：macOS Accelerate 框架线程数=1；跨平台保持一致行为

import sys  # 作用：取 sys.argv 交给 QApplication；退出前 flush sys.stdout/sys.stderr，避免日志丢失
import traceback  # 作用：把未处理异常格式化成完整堆栈（_global_exception_handler 与 main 的异常分支使用）

# Qt控件统一从UI/UI.py导入（全局唯一导入中心）
from UI import QApplication  # 作用：创建 Qt 应用对象；不直接从 PyQt6 导入是为了守住「控件只在 UI/UI.py 导入」的唯一入口约束；缺它则窗口无法创建

# lib核心：懒加载器（import lib 时已完成线程数环境变量设置）
import lib as _core  # 作用：以「模块对象」读取懒加载后的 HAS_TF/HAS_TORCH/_tf_module 等当前值；若写 from lib import HAS_TF 会固化导入瞬间的旧值
from lib import _get_sklearn, _get_scipy_stats  # 作用：主线程预加载两个 C 扩展（sklearn、scipy.stats）；缺库时抛异常，由下方 try/except 静默降级
from lib.db_helper import get_db  # 作用：初始化 SQLite+DuckDB 单例；数据库不可用时抛异常，由 main 捕获后仅界面启动

# 主窗口（内含 14 个启用标签页，3 页合并停用；页面代码在 TAB/*.py）
from plugins.彩票预测 import LotteryPredictionWindow  # 作用：主窗口类（顶栏 + 14 个启用选项卡 + 状态栏）；导入失败等同于程序无法启动


# ============================================================================
# 全局异常处理与资源清理（继承自v7.5的0xC0000409防护策略）
# ============================================================================

def _log_unhandled_exception(source, exc_type, exc_value, exc_tb):
    """把一次未处理异常落盘到 系统v7.5/崩溃日志.log，并回显到 stderr。

    作用:
        sys.excepthook 与 threading.excepthook 共用同一套记录逻辑，
        保证主线程崩溃与后台线程崩溃的日志格式一致、都能定位到现场。

    参数:
        source: 来源标记（"主线程" 或 "后台线程 <name>"），用于区分崩溃发生在哪条线程。
        exc_type: 异常类型（如 ValueError 的类对象）。
        exc_value: 异常实例；异常消息与自定义属性都在这里。
        exc_tb: traceback 对象，用于 format_exception 还原完整调用栈。

    返回:
        None。只记录，不改变异常本身，也不改变进程退出行为。

    日志路径约定（为什么放 系统v7.5/）:
        项目运行时数据、配置与数据库都落在 系统v7.5/ 下（见 lib/db_helper.py 初始化），
        崩溃日志与数据同目录，用户反馈问题时只需打包一个目录；
        文件名固定为「崩溃日志.log」并以追加方式写入，多次崩溃可累积对比。

    异常/降级行为（为什么必须吞掉写盘失败）:
        目录被设为只读、磁盘满、文件被其它进程占用时，open() 会抛 OSError。
        钩子运行在解释器即将退出的阶段，此处再抛异常会打印
        「Error in sys.excepthook」并可能触发二次崩溃，把真正的原始错误淹没；
        因此这里捕获全部异常，只把失败原因 print 到 stderr 后返回。
    """
    details = ''.join(traceback.format_exception(exc_type, exc_value, exc_tb))
    type_name = getattr(exc_type, '__name__', str(exc_type))

    # 1) 终端仍要看到现场：默认钩子会把堆栈写到 stderr，被替换后必须自行输出，
    #    否则在「日志文件也写不进去」的极端场景会彻底静默
    try:
        print(f"\n[全局异常捕获] {type_name}: {exc_value}", file=sys.stderr)
        print(details, file=sys.stderr)
    except Exception:
        # stderr 已不可写（如 pythonw 无控制台、输出流被关闭）时忽略
        pass

    # 2) 落盘：时间 / 来源 / 异常类型 / 消息 / Python 版本 / 完整 traceback
    try:
        import datetime  # 作用：取本地时间戳；函数内导入，避免改动文件顶部既有的导入顺序
        import os  # 作用：拼接日志路径、创建目录；同样局部导入以保持顶部导入段不变

        log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '系统v7.5')
        log_path = os.path.join(log_dir, '崩溃日志.log')
        os.makedirs(log_dir, exist_ok=True)  # 首次运行尚未建库时目录可能不存在，就地创建
        entry = (
            '=' * 78 + '\n'
            + f'时间: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n'
            + f'来源: {source}\n'
            + f'异常类型: {type_name}\n'
            + f'异常消息: {exc_value}\n'
            + f'Python 版本: {sys.version.replace(chr(10), " ")}\n'
            + 'Traceback:\n'
            + details
            + '\n'
        )
        with open(log_path, 'a', encoding='utf-8') as handle:
            # 'a' 追加：保留历次崩溃现场，单次崩溃不会覆盖上一次；UTF-8 与项目其余文本一致
            handle.write(entry)
    except Exception as log_error:
        # 写盘失败绝不二次抛出（原因见 docstring），只提示目标路径与具体原因
        try:
            print(f'[崩溃日志] 写入失败（系统v7.5/崩溃日志.log）: {log_error}', file=sys.stderr)
        except Exception:
            pass


def _global_exception_handler(exc_type, exc_value, exc_tb):
    """sys.excepthook 实现：主线程未捕获异常的兜底记录

    作用:
        由 main() 在创建 QApplication 之前安装，把主线程未处理异常追加写入
        系统v7.5/崩溃日志.log，并在 stderr 保留完整堆栈。

    参数:
        exc_type / exc_value / exc_tb: 与 sys.excepthook 协议一致的三参数
        （异常类型、异常实例、traceback 对象）。

    返回:
        None。返回值被解释器忽略；进程仍按原有规则以非 0 退出码结束。

    异常/降级行为与「为什么」:
        刻意不弹 QMessageBox、不访问任何 Qt 对象：异常可能发生在 QApplication
        创建之前、事件循环退出阶段，或由非 GUI 线程触发，此时触碰 Qt 极易引发
        二次崩溃（0xC0000409 一类栈损坏）。只做「落盘 + stderr」最安全。
    """
    _log_unhandled_exception('主线程', exc_type, exc_value, exc_tb)


def _thread_exception_handler(args):
    """threading.excepthook 实现：后台 Python 线程未捕获异常的兜底记录

    作用:
        与主线程钩子共用落盘逻辑，避免后台线程崩溃「无声消失」。

    参数:
        args: threading.ExceptHookArgs，含 exc_type / exc_value / exc_traceback / thread；
              该对象由解释器构造，不能按普通异常三参数直接调用。

    返回:
        None。线程仍然终止（与未安装钩子时的行为一致），但会留下日志。

    为什么安装它（评估结论）:
        当前代码库没有直接使用 threading.Thread（后台计算走 QThread），
        但第三方库/未来的线程池可能自建 Python 线程；该钩子只在「线程因未捕获异常
        而终止」时触发，不影响正常线程行为，成本一行、收益是同类崩溃可追踪。
        边界要说清：QThread 崩溃不经过这里（由 Qt/PyQt 自身的异常路径处理），
        本钩子不会改变其行为。
    """
    _log_unhandled_exception(
        '后台线程 %s' % getattr(getattr(args, 'thread', None), 'name', '?'),
        args.exc_type, args.exc_value, args.exc_traceback,
    )


# 全局标记，防止清理函数重复执行
_ml_cleanup_done = False


def _cleanup_ml_resources():
    """【彻底修复0xC0000409】安全清理C扩展资源

    作用:
        在事件循环结束后、进程结束前，释放 TensorFlow / PyTorch / sklearn
        持有的 C 侧资源（计算图、CUDA 缓存、OpenMP 线程池），减少退出阶段崩溃。

    参数:
        无（读取 lib 模块上的 HAS_TF / HAS_TORCH / _tf_module / _torch_module 状态）。

    返回:
        None。本函数不抛出异常，任何一步失败都就地吞掉。

    关键修复与「为什么」:
        只用 HAS_TF / HAS_TORCH 全局变量判断「是否已加载」，绝不调用
        _get_tf() / _get_torch()——在退出阶段触发懒加载会重新走 C 扩展初始化，
        正是栈溢出的诱因。未加载的库直接跳过。
    """
    global _ml_cleanup_done
    if _ml_cleanup_done:
        # 重复调用直接返回：清理是幂等的，但重复跑会延长退出时间
        return
    _ml_cleanup_done = True

    import gc  # 作用：强制垃圾回收，让 Python 侧的包装对象先释放，再交给 C 侧清理

    # 1. 清理TensorFlow：仅在已加载时清理，不触发懒加载
    try:
        if _core.HAS_TF is True and _core._tf_module is not None:
            # 双重判断：HAS_TF 只是「导入成功」标志，_tf_module 才是真实模块对象
            try:
                _core._tf_module.keras.backend.clear_session()
            except Exception:
                # 清空默认图；老版本 TF 无此 API 时忽略
                pass
            try:
                _core._tf_module.compat.v1.reset_default_graph()
            except Exception:
                # TF2 有 compat.v1；若被裁剪则忽略，不影响进程退出
                pass
    except Exception:
        # 连模块属性访问都失败（如用户手工删了 lib 属性）也不影响退出
        pass

    # 2. 清理PyTorch：仅在已加载时清理，不触发懒加载
    try:
        if _core.HAS_TORCH is True and _core._torch_module is not None:
            try:
                if _core._torch_module.cuda.is_available():
                    _core._torch_module.cuda.empty_cache()  # 释放显存缓存块
                    _core._torch_module.cuda.synchronize()  # 等待 GPU 队列排空，避免进程退出时异步操作报错
            except Exception:
                # 无 CUDA / 驱动不匹配时忽略：CPU 版 torch 没有 cuda 属性
                pass
    except Exception:
        pass

    # 3. 清理sklearn：OpenMP线程池（仅在已加载时）
    try:
        import threadpoolctl  # 作用：threadpoolctl 控制 BLAS/OpenMP 线程池；sklearn 依赖它收敛线程
        # 【修复0xC0000409】使用with语句正确管理threadpool_limits上下文
        with threadpoolctl.threadpool_limits(limits=1):
            # limits=1 与文件头环境变量一致；with 结束即恢复原限制，避免残留状态
            pass
    except Exception:
        # 未安装 threadpoolctl 时忽略：它本身是可选的运行时依赖
        pass

    # 4. 强制垃圾回收
    for _ in range(3):
        # 连续 3 轮：第 1 轮回收循环垃圾，后续轮次回收被第 1 轮释放对象所引用的对象
        gc.collect()


# ============================================================================
# 程序入口
# ============================================================================

def main():
    """程序入口：初始化应用、数据库，创建主窗口，进入事件循环

    参数:
        无（命令行参数经 sys.argv 原样交给 QApplication）。

    返回:
        None。本函数永不正常返回：结束时统一走 os._exit(ret)，交给操作系统回收资源。

    异常/降级行为:
        - 缺 PyQt6 → 打印 pip 安装提示，os._exit(1)；
        - sklearn / scipy 预加载失败 → 静默忽略（功能层面由 lib 懒加载器降级）；
        - 数据库初始化失败 → 打印警告，界面继续启动；
        - app.exec() 抛异常 → 打印堆栈，ret=1，仍执行 finally（资源清理 + 退出）。
    """
    print("PyQt6窗口启动中...")

    # 【彻底修复0xC0000409】移除faulthandler，保留 try/finally 保证 os._exit 总被调用
    # faulthandler 会注册 Windows 信号处理器，可能与某些 C 扩展冲突导致栈损坏
    # 注意：下方新安装的 excepthook 只做「落盘 + stderr」，全程不触碰 QApplication，
    # 因此不会重现历史上「退出阶段访问 Qt 对象导致二次崩溃」的问题

    # 只检查核心依赖（PyQt6），其他库采用懒加载策略
    try:
        import PyQt6  # 作用：仅做存在性探测（真正用到的控件已由 UI 导入）；缺它后续必然失败
    except ImportError:
        print("错误: 缺少 PyQt6，请运行: pip install PyQt6")
        import os  # 作用：此处才导入 os，避免与文件头的 _os 混淆；只需要 _exit
        os._exit(1)  # 退出码 1：依赖缺失属启动失败；绕过解释器清理，因为此时没有任何 C 扩展被加载

    # 安装全局异常钩子（时机：依赖检查之后、C 扩展预加载/建库/创建 QApplication 之前）
    # 为什么必须在这里：
    # 1) 早于 QApplication 与主窗口，后续任何初始化失败、槽函数异常都能落盘，而不是随窗口闪退丢失；
    # 2) 钩子本身不创建任何 Qt 对象，因此不会在退出阶段触碰 QApplication 引发二次崩溃；
    # 3) 启动顺序未变：仍先查依赖、再预加载 C 扩展、再建库、最后创建窗口。
    sys.excepthook = _global_exception_handler
    import threading  # 作用：访问 threading.excepthook；局部导入以保持文件顶部导入段与启动顺序不变
    threading.excepthook = _thread_exception_handler  # 后台 Python 线程未捕获异常同样落盘（QThread 不在其覆盖范围，见函数 docstring）

    # 【彻底修复0xC0000409】在主线程中预加载sklearn和scipy，
    # 避免在QThread中首次导入C扩展导致栈缓冲区溢出
    # C扩展的运行时初始化（OpenMP/BLAS）必须在主线程完成，
    # 在QThread中首次初始化会与Qt事件循环冲突导致0xC0000409
    try:
        _get_sklearn()
    except Exception:
        # 缺 sklearn 或初始化失败：不阻断启动，预测页在使用时自行降级
        pass
    try:
        _get_scipy_stats()
    except Exception:
        # 缺 scipy：统计检验卡片会提示库不可用，界面仍可运行
        pass

    # 初始化双嵌入式数据库（SQLite + DuckDB），自动创建 系统v7.5/ 目录
    try:
        get_db()
        print("[数据库] SQLite + DuckDB 初始化完成")
    except Exception as e:
        # 数据库失败不阻断界面：历史数据仍可由 系统v7.5/彩票数据.json 等 JSON 兜底
        print(f"[数据库] 初始化失败（不影响界面启动）: {e}")

    app = QApplication(sys.argv)  # 作用：创建唯一的 Qt 应用对象；必须在任何 QWidget 之前
    app.setApplicationName("pyqt窗口 系统v7.5")  # 作用：任务管理器/系统级应用名；窗口标题另由 LotteryConfig.WINDOW_TITLE 提供

    window = LotteryPredictionWindow()  # 作用：构建主窗口；内部构造函数里已完成顶栏、14 个启用选项卡（3 页合并停用）与状态栏
    window.show()

    print("系统v7.5 已启动！")

    # 【彻底修复0xC0000409】用try/finally包裹app.exec()
    # 确保无论发生什么（异常、崩溃、用户关闭），最终都调用os._exit
    # os._exit让操作系统直接回收所有资源，跳过Python的模块清理阶段
    ret = 0  # 默认退出码 0；异常分支改为 1
    try:
        ret = app.exec()
    except Exception as e:
        traceback.print_exc()
        print(f"[异常捕获] {e}")
        ret = 1  # 事件循环层异常：记为失败退出码，便于外部脚本判断
    finally:
        _cleanup_ml_resources()
        try:
            sys.stdout.flush()  # 强制刷出缓冲：os._exit 不执行解释器清理，不 flush 会丢日志
            sys.stderr.flush()
        except Exception:
            # 输出流已被关闭（如以 pythonw 运行）时忽略
            pass
        import os
        os._exit(ret)  # 作用：跳过 Python 模块清理（正是该阶段易触发 C 扩展崩溃），由操作系统回收全部资源


if __name__ == "__main__":
    main()
