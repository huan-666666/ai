# -*- coding: utf-8 -*-
"""
============================================================================
lib/online_sites.py - 在线开奖站点注册表（纯逻辑层，禁止 Qt）
============================================================================
设计原则：
    1. 代码中不预置任何站点、域名或完整网址；站点只来自配置文件
       系统v7.5/在线站点.json。
    2. 文件不存在 / 为空 / 损坏时，注册表为空，由界面提示「新增站点」。
    3. 本模块不 import Qt，不主动写文件；save_registry() 只在用户点保存时调用。

配置字段（JSON）：
    default_id  string   默认站点 id
    sites[]    id / name / lottery / draw_time / url_template / enabled /
               note / source_type
    url_template 必须含 {year} 占位（如 https://host/path/{year}）。

对外函数：
    load_registry()          —— 只读加载（不写盘）
    save_registry()          —— 用户显式保存
    enabled_sites()          —— 启用站点
    default_site()           —— 默认启用站点
    site_url()               —— 模板 + 年份 → 实际 URL
    match_site()             —— 按注册表 host 匹配（取代硬编码域名）
    registry_source_type()   —— 命中的解析器类型
============================================================================
"""

import json
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_DIR = BASE_DIR / '系统v7.5'
CONFIG_PATH = CONFIG_DIR / '在线站点.json'


def _empty_payload(source, load_error=''):
    """空注册表（文件缺失/为空/损坏时的统一形态）"""
    return {'default_id': '', 'sites': [], 'source': source, 'load_error': load_error}


def _normalize_site(raw):
    """字段收敛：缺失字段补空值，enabled 转 bool，避免界面/抓取被脏配置打断"""
    return {
        'id': str(raw.get('id') or '').strip(),
        'name': str(raw.get('name') or '').strip(),
        'lottery': str(raw.get('lottery') or '').strip(),
        'draw_time': str(raw.get('draw_time') or '').strip(),
        'url_template': str(raw.get('url_template') or '').strip(),
        'enabled': bool(raw.get('enabled', True)),
        'note': str(raw.get('note') or '').strip(),
        'source_type': str(raw.get('source_type') or 'generic_json').strip(),
    }


def load_registry():
    """读取站点注册表（只读）

    返回:
        dict: {'default_id', 'sites', 'source'('file'|'missing'|'empty'|'broken'),
               'load_error'}
        文件缺失/为空/损坏时 sites 为空，绝不回填内置站点。
    """
    if not CONFIG_PATH.is_file():
        return _empty_payload('missing')
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        return _empty_payload('broken', '读取站点配置失败：%s' % exc)
    raw_sites = data.get('sites') if isinstance(data, dict) else None
    if not isinstance(raw_sites, list) or not raw_sites:
        return _empty_payload('empty')
    sites = []
    for raw in raw_sites:
        if not isinstance(raw, dict) or not str(raw.get('id') or '').strip():
            continue
        sites.append(_normalize_site(raw))
    if not sites:
        return _empty_payload('empty')
    default_id = str(data.get('default_id') or '')
    if not any(site['id'] == default_id for site in sites):
        default_id = sites[0]['id']
    return {'default_id': default_id, 'sites': sites, 'source': 'file', 'load_error': ''}


def save_registry(registry):
    """把注册表写回 系统v7.5/在线站点.json（仅由用户「保存」动作调用）

    异常:
        OSError / ValueError：写盘失败，交由界面提示。
    """
    sites = []
    for site in registry.get('sites') or []:
        sites.append({key: site.get(key) for key in
                      ('id', 'name', 'lottery', 'draw_time', 'url_template',
                       'enabled', 'note', 'source_type')})
    data = {'default_id': registry.get('default_id') or (sites[0]['id'] if sites else ''),
            'sites': sites}
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n',
                           encoding='utf-8')
    return data


def enabled_sites(registry):
    """启用中的站点（保持配置顺序）"""
    return [site for site in registry.get('sites') or [] if site.get('enabled')]


def default_site(registry):
    """默认启用站点：default_id 优先；否则首个启用站点；都没有返回 None"""
    sites = registry.get('sites') or []
    for site in sites:
        if site.get('id') == registry.get('default_id') and site.get('enabled'):
            return site
    for site in sites:
        if site.get('enabled'):
            return site
    return None


def site_url(site, year=None):
    """按模板生成实际抓取 URL（{year} 缺省为当前年）"""
    if not site:
        return ''
    return str(site.get('url_template') or '').format(year=year or datetime.now().year)


def match_site(url):
    """按注册表 host 匹配站点（返回 host 最长匹配项）；无注册表/未命中返回 None"""
    host = (urlparse(str(url or '')).netloc or '').lower()
    if not host:
        return None
    matched = None
    matched_len = 0
    for site in (load_registry().get('sites') or []):
        template_host = (urlparse(str(site.get('url_template') or '')).netloc or '').lower()
        if template_host and template_host in host and len(template_host) > matched_len:
            matched = site
            matched_len = len(template_host)
    return matched


def registry_source_type(url):
    """返回注册表命中的解析器类型；未命中返回 None"""
    site = match_site(url)
    return (site or {}).get('source_type') or None
