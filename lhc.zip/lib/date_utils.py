# -*- coding: utf-8 -*-
"""
============================================================================
lib/date_utils.py - 日期归一（纯逻辑层，禁止 Qt、零新依赖）
============================================================================
职责：
    normalize_date() —— 把常见日期写法统一成 ISO（YYYY-MM-DD）

支持：
    - ISO：2026-11-04
    - 中文：2026年11月04日（年月日）
    - 斜杠：2026/11/04
    - 点号：2026.11.04（录入链历史口径）
    月/日允许一位或两位（2026-1-4 → 2026-01-04）。

约束：
    本模块只依赖标准库 datetime，不 import Qt、不读写文件；
    识别不了或日期本身不存在（如 2026-02-30）时抛 ValueError，由调用方
    决定是隔离、告警还是展示，绝不静默改写。
============================================================================
"""

import re
from datetime import date as _date

_INVISIBLE = '\u200b\u200c\u200d\u200e\u200f\u2060\ufeff\u00ad'
_FULLWIDTH = str.maketrans({'：': ':', '／': '/', '．': '.', '－': '-', '　': ' '})


def normalize_date(value):
    """把日期文本归一化为 ISO 字符串

    参数:
        value (str|int|None): 原始日期，如 2026-11-04 / 2026年11月04日 /
            2026/11/04 / 2026.11.04。

    返回:
        str: 'YYYY-MM-DD'。

    异常:
        ValueError：空值、格式无法识别或日期不存在（如 2 月 30 日）。
    """
    text = str(value or '')
    for char in _INVISIBLE:
        text = text.replace(char, '')
    text = text.translate(_FULLWIDTH).strip()
    if not text:
        raise ValueError('日期为空: %r' % value)
    text = text.replace('年', '-').replace('月', '-')
    if text.endswith('日'):
        text = text[:-1]
    text = text.replace('/', '-').replace('.', '-')
    parts = [part.strip() for part in text.split('-')]
    if len(parts) != 3:
        raise ValueError('日期格式非法: %r' % value)
    year, month, day = parts
    if not (re.fullmatch(r'\d{4}', year) and re.fullmatch(r'\d{1,2}', month)
            and re.fullmatch(r'\d{1,2}', day)):
        raise ValueError('日期格式非法: %r' % value)
    try:
        return _date(int(year), int(month), int(day)).isoformat()
    except ValueError:
        raise ValueError('日期不存在: %r' % value)
