# -*- coding: utf-8 -*-
"""
===========================================================================
lib/plot_draw.py - matplotlib、seaborn：绘图与可视化
===========================================================================
模块职责：
    为插件层提供 matplotlib 绘图对象的统一访问入口，本身不实现任何业务绘图逻辑。

在架构中的位置：
    位于 lib/ 纯逻辑层，依赖 lib/__init__.py 的懒加载器 _get_mpl()；
    plugins/ 的绘图插件只能通过本模块的 get_xxx() 获取 Figure/Canvas/pyplot，
    禁止直接 `import matplotlib`，以便：
        1) 全程复用 lib 包中已初始化好的 QtAgg 后端；
        2) matplotlib 缺失时只在本模块返回 None，调用方统一降级处理。

包含：
    get_xxx 访问器：向插件层导出matplotlib绘图对象（Figure/Canvas/pyplot等）与
                   seaborn 模块，插件层禁止直接 import matplotlib/seaborn，
                   统一经由此模块获取

约束：禁止任何 Qt 界面代码；matplotlib/seaborn 懒加载。
===========================================================================
"""

import warnings  # 作用说明：在加载绘图库前过滤第三方库的 FutureWarning/DeprecationWarning 噪音

warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)

import lib as _core  # 作用说明：访问 lib/__init__.py 持有的懒加载器与缓存全局变量（_figure_module/_canvas_class/_pyplot_module/_sns_module）
from lib import _get_mpl, _get_sns  # 作用说明：_get_mpl 触发 matplotlib 懒加载（QtAgg 后端）；_get_sns 触发 seaborn 懒加载


# ============================================================================
# matplotlib / seaborn 懒加载访问器（供插件层使用，屏蔽重型库直接导入）
# ============================================================================
def get_figure_module():
    """获取matplotlib Figure类（触发懒加载）

    功能：
        调用 _get_mpl() 确保 matplotlib 已加载，返回 lib 包中缓存的 Figure 类。
    参数：
        无。
    返回：
        type | None: matplotlib.figure.Figure 类；matplotlib 未安装时返回 None。
    注意：
        副作用：首次调用会触发 _get_mpl()，即导入 matplotlib 并切换 QtAgg 后端；
        已加载后仅读取缓存全局变量，无额外导入开销。
    """
    _get_mpl()
    return _core._figure_module


def get_canvas_class():
    """获取matplotlib Qt画布类 FigureCanvasQTAgg（触发懒加载）

    功能：
        调用 _get_mpl() 确保 matplotlib 已加载，返回 lib 包中缓存的 Qt 画布类。
    参数：
        无。
    返回：
        type | None: FigureCanvasQTAgg 类（可嵌入 Qt 布局的画布控件）；
            matplotlib 或 Qt 绑定不可用时返回 None。
    注意：
        副作用：首次调用会触发 _get_mpl() 导入 matplotlib；已加载后仅读取缓存。
    """
    _get_mpl()
    return _core._canvas_class


def get_pyplot_module():
    """获取matplotlib.pyplot模块（触发懒加载）

    功能：
        调用 _get_mpl() 确保 matplotlib 已加载，返回 lib 包中缓存的 pyplot 模块。
    参数：
        无。
    返回：
        module | None: pyplot 模块；matplotlib 未安装时返回 None。
    注意：
        副作用：首次调用会触发 _get_mpl() 导入 matplotlib；已加载后仅读取缓存。
    """
    _get_mpl()
    return _core._pyplot_module


def get_line2d_class():
    """获取matplotlib.lines.Line2D类（用于自定义图例）

    功能：
        调用 _get_mpl() 后从 matplotlib.lines 子模块导入 Line2D 并返回。
    参数：
        无。
    返回：
        type | None: Line2D 类；matplotlib 未安装时返回 None。
    注意：
        副作用：首次调用会触发 _get_mpl()；随后每次调用都会重新执行一次
        `from matplotlib.lines import Line2D`（该子模块导入有缓存，开销很小）；
        子模块缺失等异常被吞掉并返回 None，让调用方跳过自定义图例而不是中断绘图。
    """
    _get_mpl()
    try:
        from matplotlib.lines import Line2D  # 作用说明：取 Line2D 类供插件自定义图例，子模块缺失时返回 None
        return Line2D
    except Exception:
        # Line2D 属于 matplotlib 内部子模块，极小概率在裁剪版发行包中缺失，
        # 返回 None 让调用方跳过自定义图例而不是中断绘图
        return None


def get_seaborn_module():
    """获取 seaborn 模块（触发懒加载）

    功能：
        调用 _get_sns() 触发 seaborn 懒加载，返回 lib 包中缓存的模块对象。
    参数：
        无。
    返回：
        module | None: seaborn 模块；seaborn 未安装或导入失败时返回 None。
    注意：
        副作用：首次调用触发 _get_sns()，并把结果同步写入 lib.HAS_SNS
        （None=未尝试，True=可用，False=不可用）；导入失败不抛异常。
        说明：与 matplotlib 访问器保持同一风格：界面层不直接 `import seaborn`；
        返回 None 而不是抛异常，调用方据此回退原 matplotlib 绘图路径。
    """
    _get_sns()
    return _core._sns_module
