# -*- coding: utf-8 -*-
"""
===========================================================================
lib/__init__.py - 算法&工具纯逻辑层核心包
===========================================================================
模块职责：
    1. 在任何科学计算库导入之前设置线程数环境变量（防0xC0000409栈溢出）
    2. 集中持有全部重型库的懒加载器（_get_xxx）与状态全局变量，
       供 lib 各子模块按需调用，实现"重型计算库按需加载"

在架构中的位置：
    UI/ 与 TAB/ 为界面层，plugins/ 为插件层，lib/ 为纯逻辑层（无界面）。
    本文件是 lib 包的导入入口与共享状态中心：lib 各子模块统一以
    `import lib as _core` 引用它，从而共享同一份懒加载结果与模块对象。

依赖：
    - 导入期只使用标准库（os、warnings）
    - numpy、matplotlib、scipy、sklearn、tensorflow、statsmodels、optuna、
      torch、networkx 均延迟到首次调用对应 _get_xxx() 时才真正导入，
      以缩短程序启动时间并避免可选依赖缺失导致启动失败

主要导出对象（下划线前缀表示包内私有，仅供 lib 子模块使用）：
    _get_mpl()                -> matplotlib 模块，并填充 Figure/Canvas/pyplot/patches 变量，
                                 同时设置中文字体栈（rcParams font.family/font.sans-serif）
    _get_sns()                -> seaborn 模块，并写入三态标记 HAS_SNS
    _get_scipy_stats()        -> scipy.stats
    _get_scipy_optimize()     -> scipy.optimize
    _get_scipy_signal()       -> scipy.signal
    _get_scipy_interpolate()  -> scipy.interpolate
    _get_scipy_ks()           -> scipy.stats.ks_2samp 函数
    _get_sklearn()            -> None（副作用：填充各 sklearn 组件全局变量）
    _get_tf()                 -> tensorflow 模块
    _get_sm()                 -> statsmodels.api
    _get_optuna()             -> optuna 模块
    _get_torch()              -> torch 模块
    _get_nn()                 -> torch.nn
    _get_optim()              -> torch.optim
    _get_nx()                 -> networkx 模块

懒加载状态变量的三态约定：
    HAS_XXX = None  —— 尚未尝试导入（缓存未命中，下次调用会真正尝试）
    HAS_XXX = True  —— 导入成功
    HAS_XXX = False —— 导入失败（库未安装或初始化报错）
    因为 None 也是“未尝试”的标记，判断“是否尝试过”必须写 `is not None`，
    不能写真假值判断（None 与 False 在 if 中同为假，会重复触发导入）。

约束：
    - 本文件禁止任何 Qt 界面代码
    - 子模块通过 `import lib as _core` 访问懒加载状态变量，
      保证读取到的是懒加载器赋值后的最新值
    - 本文件只做环境变量设置与懒加载，不承载任何业务算法
===========================================================================
"""

# ============================================================================
# 【彻底修复0xC0000409】在import numpy之前设置环境变量，
# 限制BLAS/OpenMP/MKL线程数为1，防止多线程C栈溢出
# 必须在import numpy之前设置才能生效
# ============================================================================
import os as _os  # 作用说明：设置 BLAS/OpenMP/MKL 线程数环境变量，防止多线程 C 栈溢出（0xC0000409）
# 限制 OpenMP 线程数为 1：numpy/sklearn 的并行区在 GUI 线程叠加 Qt 事件循环时易触发 C 栈溢出
_os.environ['OMP_NUM_THREADS'] = '1'
# 限制 OpenBLAS 线程数为 1：矩阵乘法内部线程池与 OpenMP 线程池叠加会放大栈占用
_os.environ['OPENBLAS_NUM_THREADS'] = '1'
# 限制 Intel MKL 线程数为 1：Windows 下 MKL + 多线程最常见的崩溃来源
_os.environ['MKL_NUM_THREADS'] = '1'
# 限制 numexpr（pandas 的表达式求值后端）线程数为 1
_os.environ['NUMEXPR_NUM_THREADS'] = '1'
# 限制 macOS Accelerate 框架最大线程数为 1（跨平台保持同一套线程约束）
_os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
# 注意：以上变量必须在本文件任何 numpy 导入之前赋值，否则 BLAS 会在初始化时
# 读取默认线程数并锁定，之后再改环境变量不生效。

# ---- 标准库导入（仅保留本文件实际使用的 warnings）----
import warnings                  # 作用说明：警告过滤器：屏蔽第三方库的升级/过期提示

# 第三方库的 FutureWarning/DeprecationWarning 数量多且对业务无意义，
# 在控制台输出会淹没真正的错误信息，因此在包入口统一屏蔽。
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)

# matplotlib延迟导入 - 启动时不加载
# 这些全局变量由 _get_mpl() 统一填充，plt/figure/patch 等对象供 lib.plot_draw 取用
_matplotlib_module = None   # matplotlib 顶层模块（提供 rcParams、use 等）
_pyplot_module = None       # matplotlib.pyplot（命令式绘图接口）
_figure_module = None       # matplotlib.figure.Figure 类
_canvas_class = None        # matplotlib.backends.backend_qtagg.FigureCanvasQTAgg，嵌入 Qt 的画布类
_patches_module = None      # matplotlib.patches（图例色块等）
_sns_module = None          # seaborn 模块（可选，独立懒加载）
HAS_MPL = None              # 三态标记：None=未尝试，True=可用，False=不可用
HAS_SNS = None              # 三态标记：None=未尝试，True=可用，False=不可用（seaborn 为可选增强）

def _get_mpl():
    """懒加载 Matplotlib

    功能：
        首次调用时导入 matplotlib 并切换 QtAgg 后端，同时缓存
        Figure/Canvas/pyplot/patches 等对象；之后的调用直接返回缓存模块。

    参数：
        无。

    返回：
        module | None: matplotlib 顶层模块；未安装或初始化失败时返回 None。

    注意：
        修改全局变量 _matplotlib_module/_pyplot_module/_figure_module/
        _canvas_class/_patches_module 与 HAS_MPL；调用 matplotlib.use()
        会切换绘图后端，必须在创建任何 Figure 之前完成。
        内部捕获全部异常（AnyException），不向外抛出，失败时把 HAS_MPL 置 False。
    """
    global _matplotlib_module, _pyplot_module, _figure_module, _canvas_class, _patches_module, HAS_MPL
    if HAS_MPL is not None:
        return _matplotlib_module
    try:
        import matplotlib as mpl_mod  # 作用说明：绘图顶层模块，用于设置中文字体栈与后端
        # 强制使用 QtAgg 后端：本系统只以 Qt 控件形式嵌入图表，不弹独立窗口
        mpl_mod.use('QtAgg')
        from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as canvas_cls  # 作用说明：可嵌入 Qt 布局的绘图画布类
        from matplotlib.figure import Figure as fig_cls  # 作用说明：Figure 画布容器类，供图表控件构造
        import matplotlib.pyplot as plt_mod  # 作用说明：命令式绘图接口，绘制折线/柱状等图表
        import matplotlib.patches as patches_mod  # 作用说明：图例色块、矩形等图形补丁，用于标注与高亮
        # 中文字体栈：与 TAB/widgets.py 的 FontUtils.FONT_FAMILIES 保持同一优先级。
        # matplotlib 默认 DejaVu Sans 不含中文字形，标题/坐标轴/颜色条会显示为方框；
        # 这里只固定字体相关 rcParams，不调用 seaborn.set_theme，
        # 以免 seaborn 的样式覆盖业务配色语义与现有白底画布。
        mpl_mod.rcParams['font.family'] = 'sans-serif'
        mpl_mod.rcParams['font.sans-serif'] = [
            'Microsoft YaHei', 'SimHei', 'SimSun', 'Arial', 'DejaVu Sans'
        ]
        # 负号使用 ASCII 连字符：中文字体普遍缺少 U+2212，保留 Unicode 负号会再次出现方框
        mpl_mod.rcParams['axes.unicode_minus'] = False
        _matplotlib_module = mpl_mod
        _pyplot_module = plt_mod
        _figure_module = fig_cls
        _canvas_class = canvas_cls
        _patches_module = patches_mod
        HAS_MPL = True   # 标记成功，后续调用直接命中缓存
    except Exception:
        # 这里吞掉异常是设计选择：matplotlib 属于可选依赖，
        # 缺失时界面应降级为纯文本输出，而不是让整个程序无法启动
        _matplotlib_module = None
        _pyplot_module = None
        _figure_module = None
        _canvas_class = None
        _patches_module = None
        HAS_MPL = False
    return _matplotlib_module

def _get_sns():
    """懒加载 Seaborn

    功能：
        首次调用时尝试导入 seaborn 并缓存模块对象，之后直接返回缓存结果。

    参数：
        无。

    返回：
        module | None: seaborn 模块；未安装或导入失败时返回 None。

    注意：
        写入全局变量 _sns_module 与 HAS_SNS。HAS_SNS 采用三态约定
        （None=未尝试，True=可用，False=不可用），与 _get_mpl 等加载器一致；
        失败后不再每次重复尝试导入。
        seaborn 属于可选增强库：HAS_SNS 为 False 时调用方必须回退到
        原 matplotlib 绘图路径，不能因为 seaborn 缺失而让图表消失。
    """
    global _sns_module, HAS_SNS
    if HAS_SNS is not None:
        return _sns_module
    try:
        import seaborn as sns_mod  # 作用说明：可选统计绘图库，仅用于热力图/分布图等增强展示
        _sns_module = sns_mod
        HAS_SNS = True   # 标记成功，后续调用直接命中缓存
    except Exception:
        _sns_module = None
        HAS_SNS = False  # 标记失败，调用方据此走 matplotlib 降级分支
    return _sns_module

# scipy延迟导入 - 启动时不加载
# scipy 子模块拆开缓存：不同算法只用到其中一两个子模块，避免整包导入
_scipy_stats_module = None       # scipy.stats：分布拟合、检验、描述统计
_scipy_optimize_module = None    # scipy.optimize：权重寻优、最小二乘
_scipy_signal_module = None      # scipy.signal：平滑、卷积去噪
_scipy_interpolate_module = None # scipy.interpolate：缺失值/趋势插值
_scipy_ks_module = None          # scipy.stats.ks_2samp：两样本 KS 分布一致性检验

def _get_scipy_stats():
    """懒加载 scipy.stats 模块

    功能：
        首次调用时导入 scipy.stats 并缓存，之后直接返回缓存模块。

    参数：
        无。

    返回：
        module | None: scipy.stats 模块；导入失败时返回 None。
    注意：
        写入全局变量 _scipy_stats_module（失败时缓存 None，
        因此下次调用仍会重复尝试导入）。
    """
    global _scipy_stats_module
    if _scipy_stats_module is not None:
        return _scipy_stats_module
    try:
        from scipy import stats as s_mod  # 作用说明：分布拟合、假设检验与描述统计
        _scipy_stats_module = s_mod
    except Exception:
        _scipy_stats_module = None
    return _scipy_stats_module

def _get_scipy_optimize():
    """懒加载 scipy.optimize 模块

    功能：
        首次调用时导入 scipy.optimize 并缓存，之后直接返回缓存模块。

    参数：
        无。

    返回：
        module | None: scipy.optimize 模块；导入失败时返回 None。
    注意：
        写入全局变量 _scipy_optimize_module。
    """
    global _scipy_optimize_module
    if _scipy_optimize_module is not None:
        return _scipy_optimize_module
    try:
        from scipy import optimize as o_mod  # 作用说明：权重寻优与最小二乘拟合
        _scipy_optimize_module = o_mod
    except Exception:
        _scipy_optimize_module = None
    return _scipy_optimize_module

def _get_scipy_signal():
    """懒加载 scipy.signal 模块

    功能：
        首次调用时导入 scipy.signal 并缓存，之后直接返回缓存模块。

    参数：
        无。

    返回：
        module | None: scipy.signal 模块；导入失败时返回 None。
    注意：
        写入全局变量 _scipy_signal_module。
    """
    global _scipy_signal_module
    if _scipy_signal_module is not None:
        return _scipy_signal_module
    try:
        from scipy import signal as sig_mod  # 作用说明：平滑滤波与卷积去噪
        _scipy_signal_module = sig_mod
    except Exception:
        _scipy_signal_module = None
    return _scipy_signal_module

def _get_scipy_interpolate():
    """懒加载 scipy.interpolate 模块

    功能：
        首次调用时导入 scipy.interpolate 并缓存，之后直接返回缓存模块。

    参数：
        无。

    返回：
        module | None: scipy.interpolate 模块；导入失败时返回 None。
    注意：
        写入全局变量 _scipy_interpolate_module。
    """
    global _scipy_interpolate_module
    if _scipy_interpolate_module is not None:
        return _scipy_interpolate_module
    try:
        from scipy import interpolate as int_mod  # 作用说明：缺失值与趋势插值
        _scipy_interpolate_module = int_mod
    except Exception:
        _scipy_interpolate_module = None
    return _scipy_interpolate_module

def _get_scipy_ks():
    """懒加载 scipy.stats.ks_2samp 函数

    功能：
        首次调用时导入 ks_2samp 并缓存函数对象，之后直接返回缓存结果。

    参数：
        无。

    返回：
        callable | None: ks_2samp 函数对象；导入失败时返回 None。
        用于两样本 Kolmogorov-Smirnov 检验，判断两组号码分布是否同源。
    注意：
        写入全局变量 _scipy_ks_module（缓存的是函数而不是模块，
        因此变量名带 module 与内容不符，属历史命名）。
    """
    global _scipy_ks_module
    if _scipy_ks_module is not None:
        return _scipy_ks_module
    try:
        from scipy.stats import ks_2samp as ks_mod  # 作用说明：两样本 KS 检验，判断两组号码分布是否同源
        _scipy_ks_module = ks_mod
    except Exception:
        _scipy_ks_module = None
    return _scipy_ks_module

# sklearn延迟导入 - 启动时不加载（节省~5秒）
# 说明：这里用一个布尔标记 _sklearn_loaded 表示“导入已尝试过”，
# 而不是用 None/对象做三态判断；导入失败时各组件保持 None，
# 调用方必须对每个组件单独判空（例如 `if RF is None: return {}, None`）。
_sklearn_loaded = False                  # True 表示已尝试导入（无论成功与否）
_train_test_split = None                 # 训练/测试集划分
_cross_val_score = None                  # 交叉验证评分
_RandomForestClassifier = None           # 随机森林分类器
_GradientBoostingClassifier = None       # 梯度提升分类器
_LogisticRegression = None               # 逻辑回归
_MLPClassifier = None                    # 多层感知机
_StandardScaler = None                   # 标准化（零均值、单位方差）
_MinMaxScaler = None                     # 归一化（缩放到固定区间，默认 0~1）
_accuracy_score = None                   # 准确率
_classification_report = None            # 分类报告（精确率/召回率/F1）
_KMeans = None                           # K 均值聚类
_GaussianNB = None                        # 高斯朴素贝叶斯
_PCA = None                              # 主成分分析（降维）
_cosine_similarity = None                # 余弦相似度

def _get_sklearn():
    """懒加载 sklearn 全部组件（一次性导入并填充上面 15 个全局变量）

    功能：
        首次调用时批量导入 sklearn 的训练/评估/聚类组件，填充到对应
        全局变量；之后调用直接返回，不再重复导入。

    参数：
        无。

    返回：
        None。本函数不返回任何对象，调用方必须从 `lib` 模块
        直接读取 _core._RandomForestClassifier 等全局变量。

    注意：
        写入 _sklearn_loaded 与各组件全局变量；导入失败时静默忽略
        （except 中只有 pass），所有组件保持 None，由调用方降级处理。
        sklearn 首次导入约需数秒，因此只在真正执行机器学习算法时调用。
    """
    global _sklearn_loaded, _train_test_split, _cross_val_score
    global _RandomForestClassifier, _GradientBoostingClassifier, _LogisticRegression
    global _MLPClassifier, _StandardScaler, _MinMaxScaler
    global _accuracy_score, _classification_report, _KMeans, _GaussianNB
    global _PCA, _cosine_similarity
    if _sklearn_loaded:
        return
    try:
        from sklearn.model_selection import train_test_split as tts, cross_val_score as cvs  # 作用说明：tts 划分训练/测试集；cvs 交叉验证评分
        from sklearn.ensemble import RandomForestClassifier as RFC, GradientBoostingClassifier as GBC  # 作用说明：RFC 随机森林分类器；GBC 梯度提升分类器
        from sklearn.linear_model import LogisticRegression as LR  # 作用说明：逻辑回归分类器
        from sklearn.neural_network import MLPClassifier as MLP  # 作用说明：多层感知机分类器
        from sklearn.preprocessing import StandardScaler as SS, MinMaxScaler as MMS  # 作用说明：SS 标准化（零均值单位方差）；MMS 归一化（缩放固定区间）
        from sklearn.metrics import accuracy_score as acc, classification_report as cr  # 作用说明：acc 准确率；cr 精确率/召回率/F1 分类报告
        from sklearn.cluster import KMeans as KM  # 作用说明：K 均值聚类
        from sklearn.naive_bayes import GaussianNB as GNB  # 作用说明：高斯朴素贝叶斯分类器
        from sklearn.decomposition import PCA as pca_cls  # 作用说明：主成分分析降维
        from sklearn.metrics.pairwise import cosine_similarity as cs  # 作用说明：余弦相似度，用于历史相似性度量
        _train_test_split = tts
        _cross_val_score = cvs
        _RandomForestClassifier = RFC
        _GradientBoostingClassifier = GBC
        _LogisticRegression = LR
        _MLPClassifier = MLP
        _StandardScaler = SS
        _MinMaxScaler = MMS
        _accuracy_score = acc
        _classification_report = cr
        _KMeans = KM
        _GaussianNB = GNB
        _PCA = pca_cls
        _cosine_similarity = cs
        _sklearn_loaded = True   # 只有全部组件都拿到才置 True
    except Exception:
        # 任一组件导入失败则整体放弃（保持各组件为 None），由算法层降级
        pass

# TensorFlow可选导入 - 懒加载
_tf_module = None       # tensorflow 顶层模块
_keras_module = None    # tensorflow.keras
_layers_module = None   # tensorflow.keras.layers（网络层构造）
HAS_TF = None           # None=未尝试，True=可用，False=不可用

def _get_tf():
    """懒加载 TensorFlow 与 Keras

    功能：
        首次调用时导入 TensorFlow/Keras/layers 并缓存，同时把 TensorFlow
        日志级别调到 ERROR；之后的调用直接返回缓存的顶层模块。

    参数：
        无。

    返回：
        module | None: tensorflow 顶层模块；未安装/初始化失败时返回 None。

    注意：
        写入 _tf_module/_keras_module/_layers_module 与 HAS_TF；
        并把 TensorFlow 日志级别调到 ERROR，屏蔽启动期的 INFO/WARNING 刷屏
        （这些日志会干扰用户在界面上查看算法输出）。
        TensorFlow 首次导入很慢且占用大量内存，仅 TENSORFLOW 相关算法调用。
    """
    global _tf_module, _keras_module, _layers_module, HAS_TF
    if HAS_TF is not None:
        return _tf_module
    try:
        import tensorflow as tf_mod  # 作用说明：TensorFlow 顶层模块（深度学习训练与日志级别设置）
        from tensorflow import keras as keras_mod  # 作用说明：Keras 高层建模接口（模型构建与训练流程）
        from tensorflow.keras import layers as layers_mod  # 作用说明：网络层构造（全连接、LSTM、自编码器等）
        tf_mod.get_logger().setLevel('ERROR')
        _tf_module = tf_mod
        _keras_module = keras_mod
        _layers_module = layers_mod
        HAS_TF = True
    except Exception:
        _tf_module = None
        _keras_module = None
        _layers_module = None
        HAS_TF = False
    return _tf_module

# Statsmodels可选导入 - 懒加载
_sm_module = None          # statsmodels.api（回归、假设检验）
_tsastats_module = None    # statsmodels.tsa.stattools（自相关 ACF 等时序工具）
HAS_STATSMODELS = None     # None=未尝试，True=可用，False=不可用

def _get_sm():
    """懒加载 Statsmodels

    功能：
        首次调用时导入 statsmodels.api 与 tsa.stattools 并缓存，之后直接返回缓存模块。

    参数：
        无。

    返回：
        module | None: statsmodels.api 模块；未安装时返回 None。
    注意：
        写入 _sm_module/_tsastats_module 与 HAS_STATSMODELS。
    """
    global _sm_module, _tsastats_module, HAS_STATSMODELS
    if HAS_STATSMODELS is not None:
        return _sm_module
    try:
        import statsmodels.api as sm_mod  # 作用说明：回归与假设检验接口
        from statsmodels.tsa import stattools as tsastats_mod  # 作用说明：时序工具（ACF 自相关等）
        _sm_module = sm_mod
        _tsastats_module = tsastats_mod
        HAS_STATSMODELS = True
    except Exception:
        _sm_module = None
        _tsastats_module = None
        HAS_STATSMODELS = False
    return _sm_module

# Optuna可选导入 - 懒加载
_optuna_module = None      # optuna 顶层模块（超参/权重搜索）
_TPESampler_class = None   # Tree-structured Parzen Estimator 采样器
HAS_OPTUNA = None          # None=未尝试，True=可用，False=不可用

def _get_optuna():
    """懒加载 Optuna 与 TPE 采样器

    功能：
        首次调用时导入 optuna 与 TPESampler 并缓存，之后直接返回缓存模块。

    参数：
        无。

    返回：
        module | None: optuna 模块；未安装时返回 None。
    注意：
        写入 _optuna_module/_TPESampler_class 与 HAS_OPTUNA。
        Optuna 用于综合推荐算法的集成权重寻优，缺失时算法改用默认权重。
    """
    global _optuna_module, _TPESampler_class, HAS_OPTUNA
    if HAS_OPTUNA is not None:
        return _optuna_module
    try:
        import optuna as optuna_mod  # 作用说明：超参与集成权重搜索框架
        from optuna.samplers import TPESampler as tpe_mod  # 作用说明：TPE（Tree-structured Parzen Estimator）采样器
        _optuna_module = optuna_mod
        _TPESampler_class = tpe_mod
        HAS_OPTUNA = True
    except Exception:
        _optuna_module = None
        _TPESampler_class = None
        HAS_OPTUNA = False
    return _optuna_module

# PyTorch可选导入 - 懒加载
_torch_module = None   # torch 顶层模块（张量运算）
_nn_module = None      # torch.nn（网络层与损失函数）
_optim_module = None   # torch.optim（优化器，如 Adam）
HAS_TORCH = None       # None=未尝试，True=可用，False=不可用

def _get_torch():
    """懒加载 PyTorch

    功能：
        首次调用时导入 torch/torch.nn/torch.optim 并缓存，之后直接返回缓存模块。

    参数：
        无。

    返回：
        module | None: torch 模块；未安装时返回 None。
    注意：
        写入 _torch_module/_nn_module/_optim_module 与 HAS_TORCH。
    """
    global _torch_module, _nn_module, _optim_module, HAS_TORCH
    if HAS_TORCH is not None:
        return _torch_module
    try:
        import torch as torch_mod  # 作用说明：PyTorch 顶层模块（张量运算）
        import torch.nn as nn_mod  # 作用说明：网络层与损失函数
        import torch.optim as optim_mod  # 作用说明：优化器（Adam/SGD 等）
        _torch_module = torch_mod
        _nn_module = nn_mod
        _optim_module = optim_mod
        HAS_TORCH = True
    except Exception:
        _torch_module = None
        _nn_module = None
        _optim_module = None
        HAS_TORCH = False
    return _torch_module

def _get_nn():
    """获取 PyTorch 的 nn 模块（必要时先触发 _get_torch 懒加载）

    功能：
        调用 _get_torch() 确保 PyTorch 已尝试导入，然后返回缓存的 torch.nn 模块。

    参数：
        无。

    返回：
        module | None: torch.nn 模块；PyTorch 未安装时返回 None。
    注意：
        附带 _get_torch() 的懒加载副作用（导入失败后 HAS_TORCH 置 False）。
    """
    _get_torch()
    return _nn_module

def _get_optim():
    """获取 PyTorch 的 optim 模块（必要时先触发 _get_torch 懒加载）

    功能：
        调用 _get_torch() 确保 PyTorch 已尝试导入，然后返回缓存的 torch.optim 模块。

    参数：
        无。

    返回：
        module | None: torch.optim 模块；PyTorch 未安装时返回 None。
    注意：
        附带 _get_torch() 的懒加载副作用（导入失败后 HAS_TORCH 置 False）。
    """
    _get_torch()
    return _optim_module

# NetworkX可选导入 - 懒加载
_nx_module = None   # networkx 模块（图构建、中心性、社区发现）
HAS_NX = None       # None=未尝试，True=可用，False=不可用

def _get_nx():
    """懒加载 NetworkX

    功能：
        首次调用时导入 networkx 并缓存，之后直接返回缓存模块。

    参数：
        无。

    返回：
        module | None: networkx 模块；未安装时返回 None。
    注意：
        写入 _nx_module 与 HAS_NX。
        供号码关联图、最短路径、社区发现、图聚类等图论算法使用。
    """
    global _nx_module, HAS_NX
    if HAS_NX is not None:
        return _nx_module
    try:
        import networkx as nx_mod  # 作用说明：图构建、中心性、社区发现与图聚类
        _nx_module = nx_mod
        HAS_NX = True
    except Exception:
        _nx_module = None
        HAS_NX = False
    return _nx_module
