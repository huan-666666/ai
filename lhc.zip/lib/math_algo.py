# -*- coding: utf-8 -*-
"""
===========================================================================
lib/math_algo.py - numpy、scipy：数值、统计计算与预测算法
===========================================================================
模块职责：
    提供与界面无关的纯计算层：
    - 基础统计：号码频率、遗漏周期、区间/尾数/奇偶/大小分布、
      49x49 共现相关矩阵、自相关、间隔统计、移动平均、连号邻号概率；
    - 预测算法：基于 NumPy/SciPy/sklearn/TensorFlow/PyTorch 的 23 种
      统计/图论/机器学习/深度学习算法，并做加权融合推荐；
    - 大数据分析：BigDataAnalyzer 负责频率/遗漏/转移加权、三色波与统计检验。

依赖关系：
    - NumPy 为硬依赖，在模块顶层直接 import；
    - SciPy / sklearn / statsmodels / TensorFlow / PyTorch / Optuna / NetworkX
      均为可选重型库，统一由 lib/__init__.py 的懒加载器按需加载
      （_get_scipy_stats、_get_sklearn、_get_tf、_get_torch、_get_optuna 等），
      未安装时相关方法回退到默认值而不是抛异常；
    - LotteryConfig 来自 lib.data_process，统一奇偶/大小/区间/尾数的判定口径。

架构位置：
    位于 UI/插件层与数据层之间。插件只依赖本模块导出的类，
    本模块禁止引入任何 Qt 界面代码，以保证可无头运行与单元测试。

包含类：
    MathUtils:            数学工具（频率统计、遗漏周期计算）
    PredictionAlgorithms: 23种彩票预测算法（统计/图论/机器学习/深度学习）
    BigDataAnalyzer:      大数据分析（频率/遗漏/转移加权 + 三色波 + 统计检验）
    NumberStrategyPredictor: 七策略号码预测（热门/冷门/综合/均衡/走势/马尔科夫/机器学习）

线程与资源约束：
    - PredictionAlgorithms 在构造期同步完成数据准备，其中可能训练
      TensorFlow/PyTorch 模型，耗时较长且会临时关闭 Python GC，
      因此应在后台/工作线程构造，不要阻塞 UI 主线程；
    - 模型训练涉及 C 运行时（TF/PyTorch/BLAS），用完后应调用 cleanup()
      释放模型引用，避免解释器退出阶段的堆冲突（0xC0000374/0xC0000409）。

约束：禁止任何 Qt 界面代码；sklearn/torch/optuna 等经懒加载器按需加载。
===========================================================================
"""

import datetime  # 作用说明：期号日期解析与时间窗口计算（开奖日期、时间戳转换）
import random  # 作用说明：兜底随机抽样（异常路径抽号、无历史数据时生成候选）
import math  # 作用说明：基础标量数学函数（取整、指数、对数等轻量计算）
import warnings  # 作用说明：屏蔽第三方库的 FutureWarning/DeprecationWarning 噪声
from collections import Counter, defaultdict  # 作用说明：号码计票（Counter）与邻号/连号概率的默认零值字典（defaultdict）

warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)

import lib as _core  # 作用说明：访问 lib/__init__.py 统一持有的懒加载器与重型库状态（_StandardScaler/_KMeans/_keras_module 等）
from lib import (  # 作用说明：按需懒加载 SciPy/sklearn/TensorFlow/statsmodels/Optuna/PyTorch/NetworkX 等可选重型库
    _get_scipy_stats,  # 作用说明：懒加载 scipy.stats（偏度、分布检验）
    _get_scipy_optimize,  # 作用说明：懒加载 scipy.optimize（L-BFGS-B 权重优化）
    _get_scipy_signal,  # 作用说明：懒加载 scipy.signal（高斯核卷积平滑）
    _get_scipy_interpolate,  # 作用说明：懒加载 scipy.interpolate（样条插值/外推）
    _get_scipy_ks,  # 作用说明：懒加载 scipy.stats.ks_2samp（双样本 KS 检验）
    _get_sklearn,  # 作用说明：懒加载 sklearn（标准化、KMeans、逻辑回归等）
    _get_tf,  # 作用说明：懒加载 TensorFlow（LSTM/全连接/自编码器训练）
    _get_sm,  # 作用说明：懒加载 statsmodels（ACF 自相关分析）
    _get_optuna,  # 作用说明：懒加载 Optuna（TPE 搜索集成权重）
    _get_torch,  # 作用说明：懒加载 PyTorch（LSTM/自编码器训练）
    _get_nn,  # 作用说明：懒加载 torch.nn（网络层与损失函数）
    _get_optim,  # 作用说明：懒加载 torch.optim（Adam 优化器）
    _get_nx,  # 作用说明：懒加载 NetworkX（号码图/最短路/社区检测）
)

import numpy as np  # 作用说明：全部数值与矩阵运算（统计、回归、直方图、相关系数）

from lib.data_process import LotteryConfig  # 作用说明：统一奇偶/大小/区间/尾数的判定口径


def get_numpy():
    """导出 NumPy 模块对象，供插件层间接获取数值库

    功能：返回模块级已导入的 NumPy 模块对象；不触发懒加载或重复导入，
    仅作为“禁止插件直接 import numpy”的统一出口。
    参数：无。
    返回：module: 模块级已导入的 NumPy 模块对象（即 np）。
    注意：无副作用。NumPy 在模块顶层已 import，调用本函数不会触发额外加载。
    【规范】重型库统一由lib管理，插件层经由此函数间接获取，禁止直接import numpy
    """
    return np


# 数学工具


def _sample_skewness(values):
    """计算样本偏度（无偏估计 G1，与 scipy.stats.skew(bias=False) 同口径）

    公式：G1 = sqrt(n*(n-1))/(n-2) * m3 / m2**1.5，其中 m2/m3 为二/三阶中心矩
    （除以 n），n 为样本数。样本数 < 3 或方差为 0 时偏度无定义，返回 0.0。
    参数：values (Sequence[int|float])。
    返回：float 偏度值；正偏表示右侧长尾，负偏表示左侧长尾。
    """
    n = len(values)
    if n < 3:
        return 0.0
    arr = np.asarray(values, dtype=np.float64)
    mean = float(np.mean(arr))
    m2 = float(np.mean((arr - mean) ** 2))
    if m2 == 0:
        return 0.0
    m3 = float(np.mean((arr - mean) ** 3))
    g1 = m3 / (m2 ** 1.5)
    return float(np.sqrt(n * (n - 1)) / (n - 2) * g1)


class MathUtils:
    """
    数学工具类 - 提供统计分析所需的数学函数

    功能分类：
    - 频率统计：calculate_frequency（号码出现频次）
    - 遗漏计算：calculate_missing_cycle（遗漏周期概率）

    关键属性：
        无。本类不持有实例状态，全部为 @staticmethod，仅作为命名空间使用。

    生命周期/线程约束：
        - 无构造与销毁成本，可在任意线程并发调用；
        - 仅依赖模块级 NumPy，不触发 TensorFlow/PyTorch 等重型库懒加载。

    【可改】如需添加新的统计函数，在此类的静态方法中实现
    """
    
    
    
    
    @staticmethod
    def calculate_frequency(numbers):
        """计算频率统计（各号码出现次数）

        功能：统计各号码出现次数并保持首次出现顺序，供频率/冷热等下游算法使用。
        参数：
            numbers (Iterable[int|float|str]): 待统计的号码序列，通常是多期
                开奖号码展平后的一维列表，允许重复、允许乱序。
        返回：dict: 键为号码（保持首次出现顺序），值为该号码出现的次数。
        注意：无副作用。内部使用 collections.Counter 做哈希计数，不修改入参；
            空序列返回空 dict，不抛异常。
        """
        return dict(Counter(numbers))
    
    @staticmethod
    def calculate_missing_cycle(current_miss, avg_frequency):
        """计算遗漏周期（指数分布 CDF 近似回补概率）

        功能：用指数分布的累积分布函数 1-exp(-current_miss/avg_frequency) 近似
        “该号码在平均间隔内已经回补”的概率：遗漏越长，回补概率越接近 1。
        参数：
            current_miss (int|float): 当前遗漏期数（距最近一次出现的期数）。
            avg_frequency (int|float): 平均出现间隔（期）。调用方常以
                len(data)/49 或固定值 6 传入。
        返回：float: 回补概率，已裁剪到 [0.0, 1.0]；avg_frequency<=0 时返回 0.5
            （中性值，避免除零并保持与其它默认概率一致）。
        注意：无副作用；avg_frequency<=0 的除零边界按中性值 0.5 处理。
        """
        if avg_frequency <= 0:
            # 平均间隔无效（数据为空或号码从未出现）时退化为中性概率 0.5
            return 0.5
        probability = 1 - np.exp(-current_miss / avg_frequency)
        return min(1.0, max(0.0, probability))
    
    


# 预测算法集合（23种算法）


class PredictionAlgorithms:
    """预测算法集合 - v7.5增强版，深度集成11大核心库

    职责：
        在构造时一次性完成历史数据的统计特征提取与（可选的）模型训练，
        之后通过 _get_weighted_score / comprehensive_recommendation 等
        方法输出 1..49 每个号码的得分或推荐组合。所有计算均为纯内存计算，
        不读写文件、不访问网络、不涉及 Qt。

    构造与生命周期：
        __init__ 会同步执行 _prepare_data（完整）或 _prepare_data_light（轻量），
        中途任一环节异常都会回退到 _init_defaults() 创建中性默认值，
        以保证后续方法访问属性时不会 AttributeError。因此“属性存在”
        不代表“属性已被真实计算”，使用方需容忍默认值。
        cleanup() 会删除模型引用，调用后本实例不应再用于预测。

    关键属性（按准备阶段分组）：
        data (list[dict]): 原始历史记录列表；主窗口以 insert(0, record) 维护，
            约定下标 0 为最新一期、下标越大越旧（见下方关于时间方向的说明）。
        device (torch.device|None): 仅在首次使用 PyTorch 时按 CUDA 可用性设置。
        基础统计:
            frequency (dict[int,int]): 全量号码出现次数。
            missing (dict[int,int]): 1..49 每个号码的当前遗漏期数。
            range_distribution (dict[int,int]): 键 0..4 的区间出现次数。
            tail_distribution (dict[int,int]): 键 0..9 的尾数出现次数。
            odd_even_ratio / big_small_ratio (float): 奇数、大号占比，缺省 0.5。
        序列与相关:
            correlation_matrix (np.ndarray 49x49): 共现矩阵按行归一化。
            autocorrelation (dict[int,float]): 每个号码的一阶自相关系数。
            interval_stats (dict[int,dict]): mean/std/skew/zscore。
            adjacent_prob / consecutive_prob (defaultdict(float)): 邻号/连号概率。
            moving_avg (dict[int,dict[int,float]]): 号码 -> {5/10/20: 出现率}。
            df (pandas.DataFrame|None): 仅完整模式构建，轻量模式不创建；
                完整模式但缺 pandas 时为 None，并写入 degradation_notices。
        sklearn:
            sklearn_features (np.ndarray (49,5)|None)、sklearn_features_scaled、
            scaler、kmeans_labels (np.ndarray|None)、kmeans_centers (np.ndarray|None)。
        NumPy:
            np_features (np.ndarray (49,7) float32|None)、
            np_regression_coeffs (np.ndarray(2,))、np_predicted_missing (float)、
            np_histogram (np.ndarray(10,))、np_bin_edges (np.ndarray(11,))、
            np_percentiles (np.ndarray(4,))、np_corrcoef (np.ndarray 7x7)。
        SciPy:
            scipy_weights (list[float] 长度5|None)、ks_test_result (float p 值)、
            scipy_smoothed (np.ndarray(49,)|None)、
            scipy_interp_func (callable|None)、scipy_interp_edge (float)。
        TensorFlow（仅完整模式且库可用）:
            tf_predictions (dict[int,float])、tf_lstm_model/tf_fc_model、
            tf_fc_predictions、tf_autoencoder、tf_encoded (np.ndarray|None)。
        PyTorch（仅完整模式且库可用）:
            pt_lstm_preds (dict[int,float])、pt_lstm_model、pt_encoded (np.ndarray|None)。

    线程约束：
        构造过程可能触发 TensorFlow/PyTorch 训练并临时禁用 GC，耗时且占用
        CPU/GPU，必须在后台线程调用；训练完成后恢复 GC 状态（try/finally）。
        本类实例不要在多个线程间并发调用会修改属性的方法。

    TODO(待确认): 时间方向在各类方法中不一致——_calculate_missing 用
        reversed(data)（视末尾为最新）、_calculate_moving_avg 取 series[:window]
        （self.data[0] 为最新，故取到最近 window 期），而
        _get_weighted_score/_scipy_distribution_test 把 data[0] 当作最新；
        与主窗口 insert(0, record) 的约定冲突，相关方法的语义需逐一核对。
    """

    def __init__(self, historical_data, _light_mode=False):
        """初始化预测算法实例并完成数据准备

        功能：保存历史数据引用，按 _light_mode 选择完整/轻量数据准备管线，
        并初始化 PyTorch 设备占位（device=None）。
        参数：
            historical_data (list[dict]): 历史开奖记录列表，每条至少包含
                'numbers'（list[int]，1..49）键；允许为空列表。
            _light_mode (bool): True 时只做基础统计（回测常用），
                跳过 pandas、SciPy、sklearn、TF、PyTorch 等重型步骤，
                可显著缩短构造时间。
        返回：无（构造函数）。
        注意：
            内部准备阶段的异常会被捕获并回退到默认值（仅 print 警告）；
            - 设置 self.data / self.device，并创建大量统计与模型属性；
            - 完整模式可能训练 TensorFlow/PyTorch 模型（重 CPU/GPU、阻塞）；
            - 不修改传入的 historical_data 列表本身。
        """
        self.data = historical_data
        # PyTorch设备只在第一次使用时设置
        self.device = None
        if _light_mode:
            self._prepare_data_light()
        else:
            self._prepare_data()
    
    def _prepare_data_light(self):
        """功能：轻量级数据准备（仅基础统计，跳过 TF/PyTorch/sklearn/SciPy）

        只为回测/快速打分提供最小可用属性集：频率、遗漏、区间/尾数/奇偶/大小
        分布。相关矩阵、自相关、间隔统计、移动平均均以空值或占位默认值填充，
        因此依赖这些特征的算法在轻量模式下会退化为中性结果。
        参数：无。
        返回：None
        注意：
            内部异常被捕获，打印“轻量数据准备警告”后回退到 _init_defaults；
            - 在 self 上写入 frequency/missing/.../pt_encoded 等属性；
            - 空数据时直接走 _init_defaults，此时不会创建 tf_*/pt_* 模型属性，
              外部访问需用 hasattr 兜底；
            - 不加载任何重型库（NumPy 已在模块顶层导入）。
        """
        if not self.data:
            self._init_defaults()
            return
        try:
            all_numbers = []
            for record in self.data:
                all_numbers.extend(record.get('numbers', []))
            self.frequency = MathUtils.calculate_frequency(all_numbers)
            self.missing = {}
            # 号码池固定为 1..49，range(1, 50) 的上界 50 不包含
            for num in range(1, 50):
                self.missing[num] = self._calculate_missing(num)
            self.range_distribution = self._calculate_range_distribution()
            self.tail_distribution = self._calculate_tail_distribution()
            self.odd_even_ratio = self._calculate_odd_even_ratio()
            self.big_small_ratio = self._calculate_big_small_ratio()
            # 轻量模式不计算共现矩阵，用 49x49 单位阵占位，
            # 使 _get_weighted_score 的共现项保持中性（仅自身相关为 1）
            self.correlation_matrix = np.eye(49)
            self.autocorrelation = {}
            self.interval_stats = {}
            self.adjacent_prob = defaultdict(float)
            self.consecutive_prob = defaultdict(float)
            self.moving_avg = {num: {} for num in range(1, 50)}
            self.sklearn_features = None
            self.sklearn_features_scaled = None
            self.scaler = None
            self.kmeans_labels = None
            self.kmeans_centers = None
            self.np_features = None
            # 默认回归参数 [slope, intercept] 与默认遗漏预测值 25，
            # 25 约等于 1..49 的中位数，作为无信息先验
            self.np_regression_coeffs = np.array([0, 25])
            self.np_predicted_missing = 25
            # 逐号码时间回归结果：轻量模式不训练，留空由调用方按当前遗漏兜底
            self.np_predicted_missing_by_num = {}
            self.np_histogram = np.zeros(10)
            self.np_bin_edges = np.arange(11) * 5
            self.np_percentiles = np.array([12.5, 25, 37.5, 45])
            self.np_corrcoef = np.eye(7)
            self.scipy_weights = [0.2, 0.2, 0.15, 0.15, 0.2]
            self.ks_test_result = 0.5
            self.scipy_smoothed = None
            self.scipy_interp_func = lambda xi: 25.0
            self.scipy_interp_edge = 25.0
            self.tf_predictions = {}
            self.tf_autoencoder = None
            # 【修复0xC0000409】轻量模式必须初始化pt_lstm_preds，
            # 否则hasattr检查虽能工作但设计不一致，且后续算法可能误触PyTorch懒加载
            self.pt_lstm_preds = {}
            self.pt_lstm_model = None
            self.pt_autoencoder_model = None
            self.pt_encoded = None
        except Exception as e:
            print("轻量数据准备警告: " + str(e))
            self._init_defaults()
    
    def _prepare_data(self):
        """功能：完整增强的数据准备管线

        完整的数据准备管线，按固定顺序执行（后一步依赖前一步产出的属性）：
        基础统计 -> DataFrame -> 共现矩阵 -> 自相关 -> 间隔统计 ->
        连号/邻号 -> 移动平均 -> sklearn 特征 -> NumPy 深层运算 ->
        SciPy 优化/检验/平滑/插值 -> TensorFlow -> PyTorch。
        参数：无。
        返回：None
        注意：
            顺序约束：
            - _prepare_numpy_advanced 读取 moving_avg / interval_stats /
              autocorrelation，必须在它们之后；
            - _prepare_sklearn_features 读取 moving_avg / interval_stats，
              且其产出 sklearn_features_scaled 又被 _tf_autoencoder 和
              _pt_autoencoder 使用，因此必须先于 TensorFlow/PyTorch；
            - 任一重型库不可用时由对应方法内部回退默认值，不中断主流程。
            整体异常被捕获，打印“数据准备警告”后回退到 _init_defaults；
            例外：缺少 pandas 时不会走到整体回退——_build_dataframe 内部只捕获
            ImportError，置 self.df=None 后本管线继续执行后续步骤；
            - 写入大量统计/模型属性；
            - 可能训练 TensorFlow（LSTM/FC 10 epochs、AE 20 epochs）与
              PyTorch（LSTM 30 epochs、AE 50 epochs）模型，期间临时关闭 GC，
              耗时且阻塞调用线程；
            - 创建 pandas.DataFrame（self.df）；缺 pandas 时 self.df=None 并写入
              self.degradation_notices（同时打印一条可读的降级提示）。
        """
        # 每次完整准备都重置降级提示，避免沿用上一轮的旧提示
        self.degradation_notices = []
        if not self.data:
            # 初始化默认值防止后续访问报错
            self._init_defaults()
            return
        try:
            # 原有基础统计
            all_numbers = []
            for record in self.data:
                all_numbers.extend(record.get('numbers', []))
            self.frequency = MathUtils.calculate_frequency(all_numbers)
            self.missing = {}
            # 号码池固定为 1..49，range 上界 50 不包含
            for num in range(1, 50):
                self.missing[num] = self._calculate_missing(num)
            self.range_distribution = self._calculate_range_distribution()
            self.tail_distribution = self._calculate_tail_distribution()
            self.odd_even_ratio = self._calculate_odd_even_ratio()
            self.big_small_ratio = self._calculate_big_small_ratio()
            
            # 新增：Pandas DataFrame构建
            self._build_dataframe()
            
            # 新增：NumPy共现相关性矩阵
            self._calculate_correlation_matrix()
            
            # 新增：StatsModels自相关分析
            self._calculate_autocorrelation()
            
            # 新增：间隔统计特征
            self._calculate_interval_stats()
            
            # 新增：连号邻号历史概率
            self._calculate_adjacent_stats()
            
            # 新增：移动平均
            self._calculate_moving_avg()
            
            # 新增：sklearn特征准备
            # 依赖 moving_avg / interval_stats；其产出供后续 TF/PT 自编码器使用
            self._prepare_sklearn_features()
            
            # 新增：深度NumPy矩阵运算
            self._prepare_numpy_advanced()
            
            # 新增：SciPy优化和分布分析
            self._prepare_scipy_advanced()
            
            # 新增：TensorFlow深度学习模型（可选）
            # 仅在 TF 可加载时执行，内部再判断数据量是否 >=20 期
            if _get_tf():
                self._prepare_tensorflow_model()
            
            # 新增：PyTorch LSTM时序模型（可选）
            # 与 TF 相同，失败时只需回退 pt_lstm_preds，不影响其它属性
            if _get_torch():
                self._prepare_pytorch_lstm()
        except Exception as e:
            print("数据准备警告: " + str(e))
            self._init_defaults()
    
    def _init_defaults(self):
        """功能：初始化默认值，防止后续访问属性报错

        在空数据或准备管线异常时调用，为所有会被后续算法读取的统计属性
        提供中性值：缺失计数 50、奇偶/大小比例 0.5、共现矩阵为单位阵、
        NumPy 结果为空/零/中位数先验。
        参数：无。
        返回：None
        注意：
            覆盖 self 上已有的统计属性（全部重置为默认值）；
            不创建 tf_lstm_model / tf_fc_model / tf_encoded / pt_lstm_preds /
            pt_lstm_model / pt_encoded 等模型属性，因此外部读取这些属性时
            必须使用 hasattr/getattr 兜底。
        """
        self.frequency = {}
        # 50 为遗漏上限哨兵：历史长度不足或号码从未出现时按最大遗漏处理
        self.missing = {i: 50 for i in range(1, 50)}
        self.range_distribution = {i: 0 for i in range(5)}
        self.tail_distribution = {i: 0 for i in range(10)}
        self.odd_even_ratio = 0.5
        self.big_small_ratio = 0.5
        self.consecutive_prob = {}
        self.adjacent_prob = {}
        self.correlation_matrix = np.eye(49)
        self.autocorrelation = {}
        self.interval_stats = {}
        self.moving_avg = {}
        self.sklearn_features = None
        self.sklearn_features_scaled = None
        self.scaler = None
        self.kmeans_labels = None
        self.kmeans_centers = None
        self.np_features = None
        self.np_regression_coeffs = np.array([0, 25])
        self.np_predicted_missing = 25
        # 逐号码时间回归结果：默认空字典，_np_regression_bonus 会按当前遗漏兜底
        self.np_predicted_missing_by_num = {}
        self.np_histogram = np.zeros(10)
        self.np_bin_edges = np.arange(11) * 5
        self.np_percentiles = np.array([12.5, 25, 37.5, 45])
        self.np_corrcoef = np.eye(7)
        self.scipy_weights = [0.2, 0.2, 0.15, 0.15, 0.2]
        self.ks_test_result = 0.5
        self.scipy_smoothed = None
        self.scipy_interp_func = lambda xi: 25.0
        self.scipy_interp_edge = 25.0
        self.tf_predictions = {}
        self.tf_autoencoder = None
        # TODO(待确认): 此处未初始化 pt_lstm_preds/pt_lstm_model/pt_encoded，
        # 与 _prepare_data_light 的属性集合不一致；当前调用方均用 hasattr 兜底
    
    def cleanup(self):
        """功能：安全释放 TF/PyTorch 模型资源（修复 0xC0000374 堆冲突）

        【修复0xC0000374】通过逐项 delattr 删除模型与中间结果引用，让 GC 在
        Python 可控的时机回收；不用 del self 整对象，避免误删统计属性影响仍
        在进行的调用。
        参数：无。
        返回：None
        注意：
            目标属性不存在时吞掉 AttributeError，使 cleanup 可重复调用；
            - 删除 TF/PyTorch/sklearn 的模型与预测属性（见下方三个元组）；
            - 删除后实例不再具备完整预测能力，只适合丢弃；
            - 不主动调用 tf.keras.backend.clear_session() 或 torch.cuda.empty_cache()。
        """
        # 清理TensorFlow模型引用，让TF运行时有机会释放GPU/CPU内存
        for attr in ('tf_lstm_model', 'tf_fc_model', 'tf_autoencoder', 'tf_encoded',
                      'tf_predictions', 'tf_fc_predictions'):
            try:
                delattr(self, attr)
            except AttributeError:
                pass
        # 清理PyTorch模型引用
        # 注意：pt_lstm_model 仅在完整模式训练成功时存在，故逐个 try
        for attr in ('pt_lstm_model', 'pt_lstm_preds', 'pt_encoded'):
            try:
                delattr(self, attr)
            except AttributeError:
                pass
        # 清理sklearn模型引用
        for attr in ('scaler', 'kmeans_labels', 'kmeans_centers',
                      'sklearn_features', 'sklearn_features_scaled'):
            try:
                delattr(self, attr)
            except AttributeError:
                pass
    
    def _prepare_numpy_advanced(self):
        """功能：深度 NumPy 矩阵运算（特征向量构建 + 回归/直方图/相关系数）

        为 1..49 每个号码构造 7 维特征 [频率, 遗漏, MA5, MA10, MA20, zscore,
        自相关]，整体存为 (49,7) 的 float32 矩阵，再顺序执行线性回归、
        直方图与相关系数三个子步骤。
        参数：无（读取 self.frequency/self.missing/self.moving_avg/
            self.interval_stats/self.autocorrelation）。
        返回：None
        注意：
            数据不足 10 期时直接把 np_features 置 None 并返回；
            写入 self.np_features，并触发 _np_linear_regression_trend /
            _np_distribution_histogram / _np_correlation_coefficients 三个方法
            各自写入对应属性。
        """
        # 少于 10 期时统计量噪声过大，直接跳过深层特征，避免下游拿到全零矩阵
        if len(self.data) < 10:
            self.np_features = None
            return
        # 构建49个数字的特征向量矩阵
        def _to_int(value, scale=1):
            """NaN/inf 安全转 int

            功能：避免 int(NaN) 抛异常导致整段数据准备回退默认值。
            参数：
                value: 任意数值（可能是 NaN/inf/None/字符串）。
                scale (int): 放大倍数，用于把小数比例保留若干位后取整。
            返回：int: 无法转换或非有限值时返回 0；否则返回 int(value*scale)。
            注意：无副作用；类型转换异常与 NaN/inf 均被吞掉并返回 0。
            """
            try:
                v = float(value)
            except (TypeError, ValueError):
                return 0
            if not np.isfinite(v):
                return 0
            return int(v * scale)

        features_list = []
        for num in range(1, 50):
            freq = self.frequency.get(num, 0)
            # 遗漏统一截断到 50：50 是全局约定的最大遗漏哨兵，
            # 防止历史极长时出现离群值把其它特征压扁
            miss = min(self.missing.get(num, 50), 50)
            # 移动平均是 0..1 的比例，放大 100 倍取整（精度 0.01）
            ma5 = _to_int(self.moving_avg.get(num, {}).get(5, 0), 100)
            ma10 = _to_int(self.moving_avg.get(num, {}).get(10, 0), 100)
            ma20 = _to_int(self.moving_avg.get(num, {}).get(20, 0), 100)
            # zscore 通常在 ±数倍标准差内，放大 10 倍取整（精度 0.1）
            zscore = _to_int(self.interval_stats.get(num, {}).get('zscore', 0), 10)
            autocorr = _to_int(self.autocorrelation.get(num, 0), 100)
            features_list.append([freq, miss, ma5, ma10, ma20, zscore, autocorr])
        # 统一用 float32：49×7 矩阵体量很小，但可让后续 lstsq/直方图/相关
        # 走 NumPy 的向量化与 BLAS 路径，避免 Python 循环逐元素运算
        self.np_features = np.array(features_list, dtype=np.float32)
        # np.linalg.lstsq线性回归：预测遗漏值趋势
        self._np_linear_regression_trend()
        # np.histogram分析分布
        self._np_distribution_histogram()
        # np.corrcoef计算数字间相关性
        self._np_correlation_coefficients()
    
    def _np_linear_regression_trend(self):
        """功能：NumPy np.linalg.lstsq 逐号码时间回归预测“下一期”遗漏

        数学口径（时间方向 旧 → 新）:
            对每个号码 n（1..49）取它自己的逐期“当前遗漏”序列
            y_t（t=0 最旧 … t=N-1 最新），以期序 x_t=t 为自变量做一次最小二乘
            直线拟合（np.vander 生成 [x, 1]），再外推 x=N 得到下一期遗漏预测
            p_n = slope_n * N + intercept_n。49 个号码各有一条回归线，因此
            p_n 逐号码不同；这是时间外推，不是按“号码序号”做横截面拟合。
            外推结果再按可行性剪到 [0, 当前遗漏+1]（下一期遗漏只可能为 0 或 cur+1）
            并统一裁剪到 [0,50]，抑制末端趋势发散。
        参数：无（读取 self.data / self.missing）。
        返回：None。
        注意：
            拟合异常时回退为空字典与默认系数；
            写入：
                np_predicted_missing_by_num (dict[int,float]) —— 逐号码下一期遗漏预测；
                np_regression_coeffs (np.ndarray(2,)) —— 49 条直线斜率/截距的均值，
                    仅为兼容旧属性保留，不再用于逐号码预测；
                np_predicted_missing (float) —— 49 个预测值的均值，兼容旧属性。
        """
        if self.np_features is None or len(self.data) < 10:
            return
        try:
            _, miss_series = self._get_number_series()
            n = miss_series.shape[1]
            if n < 2:
                return
            x = np.arange(n, dtype=np.float64)
            X = np.vander(x, 2)  # [[0,1],[1,1],...,[N-1,1]]
            slopes, intercepts, preds = [], [], {}
            for num in range(1, 50):
                y = miss_series[num - 1]
                cur = float(self.missing.get(num, 50))
                coeffs, residuals, rank, s = np.linalg.lstsq(X, y, rcond=None)
                slope, intercept = float(coeffs[0]), float(coeffs[1])
                p = slope * n + intercept
                if not np.isfinite(p):
                    # 数值异常时回退为该号码当前遗漏，保证下游有值可用
                    p = cur
                # 可行性约束：下一期遗漏只可能为 0（出现）或 cur+1（未出现），
                # 把直线外推结果剪到 [0, cur+1]，避免末端趋势外推发散。
                p = min(max(p, 0.0), cur + 1.0, 50.0)
                preds[num] = float(p)
                slopes.append(slope)
                intercepts.append(intercept)
            self.np_predicted_missing_by_num = preds
            # 兼容旧属性：保存 49 条回归线的平均系数（下游不再按号码序号解释）
            self.np_regression_coeffs = np.array(
                [float(np.mean(slopes)), float(np.mean(intercepts))], dtype=np.float64
            )
            self.np_predicted_missing = float(np.mean(list(preds.values())))
        except Exception:
            self.np_predicted_missing_by_num = {}
            self.np_regression_coeffs = np.array([0, 25])
            self.np_predicted_missing = 25
    
    def _np_distribution_histogram(self):
        """功能：NumPy np.histogram 分析遗漏值分布

        对 1..49 的遗漏值做 10 个等宽区间的直方图统计，并计算
        25/50/75/90 分位数。
        参数：无（读取 self.missing）。
        返回：None
        注意：
            空数据时对空数组求分位数会得到 NaN 并触发 RuntimeWarning，
            但该路径在完整管线中不会出现（调用前已保证 >=10 期）；
            写入 self.np_histogram（长度 10 的计数）、self.np_bin_edges
            （长度 11 的边界）、self.np_percentiles（4 个分位数）。
        """
        miss_arr = np.array([self.missing.get(i, 50) for i in range(1, 50)], dtype=np.float32)
        # np.histogram分10个区间统计
        # range=(0,50) 与遗漏上限哨兵 50 对齐，每个区间宽度为 5
        hist, bin_edges = np.histogram(miss_arr, bins=10, range=(0, 50))
        self.np_histogram = hist
        self.np_bin_edges = bin_edges
        # np.percentile计算分位数
        self.np_percentiles = np.percentile(miss_arr, [25, 50, 75, 90])
    
    def _np_correlation_coefficients(self):
        """功能：NumPy np.corrcoef 计算数字间相关性矩阵

        参数：无（读取 self.np_features）。
        返回：None
        注意：
            常量列会导致 0/0，已用 errstate 抑制告警并将 NaN 归零；
            写入 self.np_corrcoef。

        TODO(待确认): np.corrcoef(self.np_features.T) 是对 7 个特征列求
            相关系数，结果为 7x7；而本方法兜底分支写 np.eye(49)，
            _init_defaults/_prepare_data_light 又写 np.eye(7)，三处维度不一致，
            需确认下游期望的形状。
        """
        if self.np_features is None:
            return
        if self.np_features.shape[1] < 2:
            self.np_corrcoef = np.eye(49)
            return
        # 常量特征列标准差为 0，np.corrcoef 会做 0/0 除法并告警；忽略后统一把 NaN 归零
        with np.errstate(invalid='ignore', divide='ignore'):
            self.np_corrcoef = np.corrcoef(self.np_features.T)
        self.np_corrcoef = np.nan_to_num(self.np_corrcoef, nan=0.0)
    
    def _prepare_scipy_advanced(self):
        """功能：SciPy 深度分析（权重优化 + 分布检验 + 平滑 + 插值）

        依次调用 optimize.minimize 权重优化、ks_2samp 分布检验、
        signal.convolve 平滑、interpolate 样条插值四个子步骤。
        参数：无。
        返回：None
        注意：
            数据不足 10 期时把 scipy_weights 置 None 并直接返回；
            各子方法内部还会各自判断库可用性与数据量；
            依次写入 scipy_weights / ks_test_result / scipy_smoothed /
            scipy_interp_func / scipy_interp_edge；仅优化权重一步为数值迭代，
            其余为一次性的向量/统计计算。
        """
        # SciPy 各步骤都依赖至少 10 期数据才有统计意义；阈值与 NumPy 部分一致
        if len(self.data) < 10:
            self.scipy_weights = None
            return
        # scipy.optimize.minimize优化集成权重
        self._scipy_optimize_weights()
        # scipy.stats.ks_2samp分布一致性检验
        self._scipy_distribution_test()
        # scipy.signal.convolve趋势平滑
        self._scipy_smooth_trend()
        # scipy.interpolate插值预测遗漏值
        self._scipy_interpolate_missing()
    
    def _scipy_optimize_weights(self):
        """功能：SciPy optimize.minimize 优化集成权重（L-BFGS-B 梯度优化）

        （注：实现使用的是 L-BFGS-B 梯度优化，并非贝叶斯优化。）

        以 5 个权重为自变量，目标函数为 -加权得分（minimize 求最小值等价于
        最大化得分）。初始点取 [0.2,0.2,0.15,0.15,0.2]（和为 0.9，随后在
        目标函数内归一化），边界 [0,1]，最终结果再次按和归一化。
        参数：无。
        返回：None
        注意：
            SciPy 不可用或优化抛异常时回退固定权重；
            写入 self.scipy_weights（长度 5 的 list 或 None）。

        TODO(待确认): objective 只对号码 1..5 调用 _get_weighted_score(i+1)，
            并未覆盖 1..49；且 _get_weighted_score 本身已含 7 个维度的固定权重，
            这里的 5 个外层次权重与其语义重叠，需确认是否为预期设计。
        """
        def objective(w):
            """SciPy minimize 优化目标函数

            功能：把 5 个权重归一化后与号码 1..5 的加权得分相乘求和，
            返回负值以适配 minimize（等价于最大化总分）。
            参数：
                w (Sequence[float]): 5 个待优化权重。
            返回：float: 负的加权总分（供 minimize 使用）。
            注意：无副作用；分母加 1e-8 避免全零权重时除零。
            """
            w1, w2, w3, w4, w5 = w
            # +1e-8 防止全零权重时除零
            total = sum(w) + 1e-8
            score = sum(self._get_weighted_score(i+1) * wi / total for i, wi in enumerate([w1, w2, w3, w4, w5]))
            return -score  # minimize转maximize
        try:
            scipy_opt = _get_scipy_optimize()
            if scipy_opt is not None:
                minimize = scipy_opt.minimize
                result = minimize(objective, [0.2, 0.2, 0.15, 0.15, 0.2], method='L-BFGS-B', bounds=[(0, 1)]*5)
                # 优化结果可能全为 0（边界解），此时退回等权默认值
                self.scipy_weights = result.x / sum(result.x) if sum(result.x) > 0 else [0.2]*5
            else:
                self.scipy_weights = [0.2, 0.2, 0.15, 0.15, 0.2]
        except Exception:
            self.scipy_weights = [0.2, 0.2, 0.15, 0.15, 0.2]
    
    def _scipy_distribution_test(self):
        """功能：SciPy ks_2samp 检验历史分布一致性

        取两组各 10 期数据（下标 0:10 与 10:20），分别统计 1..49 每个号码
        在组内的平均出现间隔，再用双样本 KS 检验比较两组分布。p 值越高
        表示前后两段时间的遗漏分布越一致。
        时间方向假设：调用方约定 data[0] 为最新一期，因此 data[0:10] 是
        “最近 10 期”，data[10:20] 是更早的 10 期；若传入数据顺序相反，
        两组的“新/旧”标签会颠倒（但 KS 检验本身对称，p 值不受影响）。
        参数：无。
        返回：None
        注意：
            数据不足 20 期、SciPy 不可用或检验异常时回退 0.5；
            写入 self.ks_test_result（p 值，float）。
        """
        # 两组各需 10 期，故要求至少 20 期；不足时用中性 p 值 0.5
        if len(self.data) < 20:
            self.ks_test_result = 0.5
            return
        try:
            ks_func = _get_scipy_ks()
            if ks_func is None:
                self.ks_test_result = 0.5
                return
            # 比较前10期和后10期的遗漏分布（按时间维度切分）
            early_data = self.data[10:20]  # 较早的10期
            late_data = self.data[0:10]    # 最近的10期
            early_miss = []
            late_miss = []
            for num in range(1, 50):
                # 计算该号码在两个时间段的平均出现间隔
                # 组内用下标差作为间隔（单位：期），而非真实期号差
                early_last = None
                early_intervals = []
                for idx, record in enumerate(early_data):
                    if num in record.get('numbers', []):
                        if early_last is not None:
                            early_intervals.append(idx - early_last)
                        early_last = idx
                late_last = None
                late_intervals = []
                for idx, record in enumerate(late_data):
                    if num in record.get('numbers', []):
                        if late_last is not None:
                            late_intervals.append(idx - late_last)
                        late_last = idx
                # 组内一次都没出现的号码用 50（遗漏上限哨兵）代表“极长间隔”
                early_miss.append(np.mean(early_intervals) if early_intervals else 50.0)
                late_miss.append(np.mean(late_intervals) if late_intervals else 50.0)
            early_miss = np.array(early_miss, dtype=np.float32)
            late_miss = np.array(late_miss, dtype=np.float32)
            if len(early_miss) > 3 and len(late_miss) > 3:
                stat, pval = ks_func(early_miss, late_miss)
                self.ks_test_result = pval  # p值越高分布越一致
            else:
                self.ks_test_result = 0.5
        except Exception:
            self.ks_test_result = 0.5
    
    def _scipy_smooth_trend(self):
        """功能：SciPy signal.convolve 趋势平滑

        把 1..49 的累计出现次数作为一维序列，用窗口 5、标准差 1.0 的高斯核
        （归一化后）做 same 模式卷积，得到平滑后的频率曲线。
        参数：无（读取 self.frequency）。
        返回：None
        注意：
            数据不足 5 期或 SciPy 不可用时置 None；
            写入 self.scipy_smoothed（长度 49 的 np.float32 数组或 None）。
        """
        if len(self.data) < 5:
            self.scipy_smoothed = None
            return
        scipy_sig = _get_scipy_signal()
        if scipy_sig is None:
            self.scipy_smoothed = None
            return
        # 获取最近20期的频率序列
        # TODO(修复): 上一行注释与实现不符——此处用的是全量 self.frequency，
        # 并非“最近 20 期”；需对齐注释或实现。
        freq_series = np.array([self.frequency.get(i, 0) for i in range(1, 50)], dtype=np.float32)
        # 高斯平滑核
        # 兼容旧版 SciPy：新版在 scipy.signal.windows 下，旧版直接挂在 signal 上
        try:
            kernel = scipy_sig.windows.gaussian(5, 1.0)
        except AttributeError:
            kernel = scipy_sig.gaussian(5, 1.0)
        # 归一化使卷积不改变整体幅值（避免平滑后总和漂移）
        kernel = kernel / kernel.sum()
        # scipy_signal.convolve卷积平滑
        self.scipy_smoothed = scipy_sig.convolve(freq_series, kernel, mode='same')
    
    def _scipy_interpolate_missing(self):
        """功能：SciPy interpolate 样条插值预测遗漏值

        以号码 1..49 为 x、对应遗漏为 y 构造散点，用 s=0（必须穿过所有点）
        的三次样条拟合，得到可在任意 xi 处求值的函数，并额外计算 25.5
        处的插值作为“中位边界”参考值。
        参数：无（读取 self.missing）。
        返回：None
        注意：
            数据不足 10 期或 SciPy 不可用时置 None / 默认函数；
            写入 self.scipy_interp_func（callable 或 None）与
            self.scipy_interp_edge（float）。
        """
        if len(self.data) < 10:
            self.scipy_interp_func = None
            return
        scipy_int = _get_scipy_interpolate()
        if scipy_int is None:
            self.scipy_interp_func = None
            return
        try:
            # 构建x=数字,y=遗漏的散点
            x = np.arange(1, 50, dtype=np.float32)
            y = np.array([self.missing.get(i, 50) for i in range(1, 50)], dtype=np.float32)
            # 三次样条插值
            # s=0 表示不做平滑、曲线必须经过全部 49 个点
            tck = scipy_int.splrep(x, y, s=0)
            self.scipy_interp_func = lambda xi: scipy_int.splev(xi, tck)
            # 预测边界值
            # 25.5 位于号码区间正中间，作为“中心位置”的参考插值
            self.scipy_interp_edge = float(scipy_int.splev(25.5, tck))
        except Exception:
            self.scipy_interp_func = lambda xi: 25.0
            self.scipy_interp_edge = 25.0

    def _predict_next_missing_by_spline(self, splrep, splev):
        """功能：逐个号码用其自身遗漏序列做三次样条外推“下一期”遗漏

        数学口径（时间方向 旧 → 新）:
            对每个号码 n 取其自身的逐期遗留序列 y_t（t=0 最旧 … t=N-1 最新），
            以 x_t=t 为自变量做三次样条 splrep(x, y, k=3, s=N)，再在 x=N 处求值，
            得到该号码“下一期”的遗漏预测。每个号码一条独立序列，因此 49 个预测值
            各不相同；这是时间外推，不再是按号码序号做横截面平滑。
            s=N 为较强平滑：遗漏序列是 0/长遗漏的锯齿波，强平滑可保留长期冷热水平、
            抑制单期抖动；外推点仅超出最后一个结点 1 期，避免高阶外推发散。
            末端遇到锯齿跳变时样条仍可能剧烈过冲（实测 25/49 个号码超过上界），
            因此再用可行性约束剪到 [0, 当前遗漏+1]（下一期真实遗漏只可能取这两个端点
            之一：出现记 0、未出现记当前遗漏+1），再统一裁剪到 [0,50]。

        参数：
            splrep (callable|None): scipy.interpolate.splrep。
            splev (callable|None): scipy.interpolate.splev。
            splrep/splev 任一为 None 时返回空字典，由调用方回退当前遗漏。
        返回：dict[int,float]，键 1..49，值为预测的下一期遗漏，已裁剪到 [0,50]；
            SciPy 不可用或拟合失败时，该号码回退为序列最后一个值（当前遗漏）。
        注意：
            单号码异常被捕获并逐个回退；
            写入 self._interp_missing_cache（键含 _data_signature）；同指纹直接复用。
        """
        if splrep is None or splev is None:
            return {}
        key = ('spline_next_missing', self._data_signature())
        cache = getattr(self, '_interp_missing_cache', None)
        if cache is not None and cache.get('key') == key:
            return cache['pred']

        _, miss_series = self._get_number_series()
        n = miss_series.shape[1]
        if n < 4:
            # 三次样条至少需要 4 个结点；不足时不做外推
            return {}

        x = np.arange(n, dtype=np.float64)
        preds = {}
        for num in range(1, 50):
            y = miss_series[num - 1]
            cur = float(self.missing.get(num, 50))
            p = float(y[-1])  # 兜底：当前遗漏（最新一期结束时的值）
            try:
                tck = splrep(x, y, k=3, s=float(n))
                p = float(splev([float(n)], tck)[0])
            except Exception:
                pass
            if not np.isfinite(p):
                p = float(y[-1])
            # 可行性约束：下一期的真实遗漏只可能是 0（出现）或 cur+1（未出现），
            # 故预测值必须落在 [0, cur+1]。样条在序列末端遇到锯齿跳变时可能剧烈过冲
            #（实测 25/49 个号码超过该上界），此约束把“时间外推”拉回物理可行区间。
            p = min(max(p, 0.0), cur + 1.0, 50.0)
            preds[num] = float(p)

        self._interp_missing_cache = {'key': key, 'pred': preds}
        return preds

    def _prepare_sklearn_features(self):
        """功能：sklearn 特征准备（StandardScaler 归一化 + KMeans 聚类）

        为 1..49 每个号码构造 5 维特征 [频率占比, 截断遗漏/50, MA5, MA20,
        zscore]，先用 StandardScaler 标准化（sklearn 不可用时退化为原始矩阵），
        再按数据量聚成 3~4 类，记录标签与簇中心供后续算法使用。
        参数：无（读取 self.frequency/self.missing/self.moving_avg/
            self.interval_stats）。
        返回：None
        注意：
            数据不足 10 期或 sklearn 不可用时相关属性置 None；
            写入 self.sklearn_features（(49,5)）、self.sklearn_features_scaled、
            self.scaler、self.kmeans_labels、self.kmeans_centers；
            会触发 sklearn 懒加载（_get_sklearn()）。
        """
        _get_sklearn()
        if len(self.data) < 10:
            self.sklearn_features = None
            self.kmeans_labels = None
            self.scaler = None
            return
        
        # 构建49个数字的特征矩阵：频率+遗漏+MA5+MA20
        # 实际为 5 列，额外包含 zscore（用于刻画遗漏的异常程度）
        features = []
        for num in range(1, 50):
            # 频率除以总期数得到 0..1 的出现率；空数据时按 0
            freq = self.frequency.get(num, 0) / len(self.data) if self.data else 0
            # 遗漏截断到 50 后再归一化，与其它特征量级大致对齐
            miss = min(self.missing.get(num, 50), 50) / 50.0
            ma5 = self.moving_avg.get(num, {}).get(5, 0.1)
            ma20 = self.moving_avg.get(num, {}).get(20, 0.1)
            zscore = self.interval_stats.get(num, {}).get('zscore', 0)
            features.append([freq, miss, ma5, ma20, zscore])
        
        self.sklearn_features = np.array(features)
        
        # StandardScaler归一化
        if _core._StandardScaler is not None:
            self.scaler = _core._StandardScaler()
            self.sklearn_features_scaled = self.scaler.fit_transform(self.sklearn_features)
        else:
            # 无 sklearn 时不做标准化，保留原始尺度（后续距离类算法会有偏差）
            self.scaler = None
            self.sklearn_features_scaled = self.sklearn_features
        
        # KMeans聚类分组（3-5组）
        # TODO(待确认): 实际 min(4, max(3, len//20)) 只能得到 3 或 4 组，
        # 注释中的“3-5组”与实现不符。
        if _core._KMeans is not None:
            # 每 20 期增加一簇，但限制在 3..4 之间，避免小样本簇过细
            n_clusters = min(4, max(3, len(self.data) // 20))
            # 去重后的样本数不足 n_clusters 时，KMeans 会告警「distinct clusters 小于 n_clusters」，
            # 这里把簇数限制为实际不同点的数量，少于 2 个则跳过聚类
            n_unique = len(np.unique(self.sklearn_features_scaled, axis=0))
            n_clusters = min(n_clusters, n_unique)
            if n_clusters >= 2:
                # 【修复】sklearn 1.4+已移除KMeans的n_jobs参数，GBC本就不支持n_jobs
                # random_state/n_init 固定以保证回测可复现
                kmeans = _core._KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
                self.kmeans_labels = kmeans.fit_predict(self.sklearn_features_scaled)
                # 记录聚类中心用于预测
                self.kmeans_centers = kmeans.cluster_centers_
            else:
                self.kmeans_labels = None
                self.kmeans_centers = None
        else:
            self.kmeans_labels = None
            self.kmeans_centers = None
    
    def _prepare_tensorflow_model(self):
        """功能：TensorFlow 深度学习（LSTM 时序预测 + 全连接分类器 + AutoEncoder）

        用最近连续 5 期的 49 维 one-hot 作为输入序列，标签为紧随其后那一期
        的 49 维出现向量，训练两层 LSTM（64→32）输出 sigmoid 概率；
        随后再训练全连接分类器与自编码器。
        参数：无（读取 self.data/self.sklearn_features_scaled）。
        返回：None
        注意：
            TF 不可用、数据不足或训练异常时把 tf_predictions 置 {}、
            tf_autoencoder 置 None，不影响其它属性；
            - 写入 tf_predictions/tf_lstm_model/tf_fc_predictions/tf_autoencoder/
              tf_encoded；
            - 训练期间 disable Python GC（防止 0xC0000374），finally 中恢复；
            - 会设置全局 TF 随机种子为 42，影响进程内其它 TF 使用者。
        """
        tf = _get_tf()
        keras = _core._keras_module
        layers = _core._layers_module
        # 任一层缺失都视为 TF 不可用：keras/layers 由 lib 懒加载器注入
        if tf is None:
            self.tf_predictions = {}
            self.tf_autoencoder = None
            return
        if len(self.data) < 20:
            self.tf_predictions = {}
            self.tf_autoencoder = None
            return
        # 【修复0xC0000374】抑制Python GC在TF模型训练期间运行，
        # 防止GC回收临时numpy数组时与TF的C运行时后台线程产生堆冲突
        import gc as _gc  # 作用说明：训练期间临时关闭循环垃圾回收，finally 中按原状态恢复
        _gc_was_enabled = _gc.isenabled()
        _gc.disable()
        try:
            tf.random.set_seed(42)
            # 构建时序特征：5期窗口 × 每期49维one-hot
            # data[0] 是最新一期，先反转为“旧→新”，再滑窗，
            # 保证标签始终在窗口之后（用过去预测未来）
            data_ordered = list(reversed(self.data))
            X_seq, y_seq = [], []
            for i in range(len(data_ordered) - 5):
                seq = []
                for j in range(5):
                    one_hot = [0] * 49
                    for n in data_ordered[i + j].get('numbers', []):
                        # 过滤非法号码，避免 one_hot 索引越界
                        if 1 <= n <= 49:
                            one_hot[n - 1] = 1
                    seq.append(one_hot)
                X_seq.append(seq)
                # 标签：序列之后的下一期是否出现
                next_nums = set(data_ordered[i + 5].get('numbers', []))
                y_seq.append([1 if n in next_nums else 0 for n in range(1, 50)])
            # 至少 10 个样本才训练；注意上一道门槛是 20 期，此处是二次保护
            if len(X_seq) < 10:
                self.tf_predictions = {}
                return
            X_seq = np.array(X_seq, dtype=np.float32)
            y_seq = np.array(y_seq, dtype=np.float32)
            # tf.keras.Sequential LSTM模型
            # 输入 (batch, 5, 49)；输出 49 维 sigmoid，属于多标签二分类
            self.tf_lstm_model = keras.Sequential([
                layers.LSTM(64, return_sequences=True, input_shape=(5, 49)),
                layers.LSTM(32),
                layers.Dense(49, activation='sigmoid')
            ])
            self.tf_lstm_model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
            # epochs=10/batch=16 是速度与拟合程度的折中（历史数据通常仅数百期）
            self.tf_lstm_model.fit(X_seq, y_seq, epochs=10, batch_size=16, verbose=0)
            # 预测下期：用最新 5 期构建真正用于“下一期”的窗口
            latest_seq = []
            for record in data_ordered[-5:]:
                one_hot = [0] * 49
                for n in record.get('numbers', []):
                    if 1 <= n <= 49:
                        one_hot[n - 1] = 1
                latest_seq.append(one_hot)
            X_last = np.array([latest_seq], dtype=np.float32)
            self.tf_predictions = {n+1: float(p) for n, p in enumerate(self.tf_lstm_model.predict(X_last, verbose=0)[0])}
            # tf.keras.Sequential 全连接分类器预测
            self._tf_fc_classifier(X_seq, y_seq)
            # tf.keras AutoEncoder特征降维
            self._tf_autoencoder()
        except Exception as e:
            self.tf_predictions = {}
            self.tf_autoencoder = None
        finally:
            # 只有原本启用过 GC 才恢复，避免覆盖外部主动禁用的状态
            if _gc_was_enabled:
                _gc.enable()
    
    def _tf_fc_classifier(self, X_seq, y_seq):
        """TensorFlow 全连接分类器预测数字出现概率

        功能：把 (N,5,49) 时序特征展平为 245 维，训练 Dense 128→64→49 的
        多标签分类器，再用最新 5 期预测下一期各号码出现概率。
        参数：
            X_seq (np.ndarray): 形状 (N,5,49) 的时序 one-hot 特征。
            y_seq (np.ndarray): 形状 (N,49) 的 0/1 标签。
        返回：None
        注意：
            keras/layers 缺失或训练异常时把 tf_fc_predictions 置 {}；
            写入 self.tf_fc_model 与 self.tf_fc_predictions；
            会触发模型训练（10 epochs）并占用调用线程。
        """
        keras = _core._keras_module
        layers = _core._layers_module
        if keras is None or layers is None:
            self.tf_fc_predictions = {}
            return
        try:
            # 展平 5x49=245 维，把窗口内所有期作为普通特征
            X_flat = X_seq.reshape(len(X_seq), -1)
            self.tf_fc_model = keras.Sequential([
                layers.Dense(128, activation='relu', input_shape=(X_flat.shape[1],)),
                # Dropout 0.2 缓解小样本过拟合
                layers.Dropout(0.2),
                layers.Dense(64, activation='relu'),
                layers.Dense(49, activation='sigmoid')
            ])
            self.tf_fc_model.compile(optimizer='adam', loss='binary_crossentropy')
            self.tf_fc_model.fit(X_flat, y_seq, epochs=10, batch_size=16, verbose=0)
            # 用最新 5 期（旧→新）构建预测窗口，而不是取最后一个带标签样本
            data_ordered = list(reversed(self.data))
            latest_seq = []
            for record in data_ordered[-5:]:
                one_hot = [0] * 49
                for n in record.get('numbers', []):
                    if 1 <= n <= 49:
                        one_hot[n - 1] = 1
                latest_seq.append(one_hot)
            X_last_flat = np.array(latest_seq, dtype=np.float32).reshape(1, -1)
            self.tf_fc_predictions = {n+1: float(p) for n, p in enumerate(self.tf_fc_model.predict(X_last_flat, verbose=0)[0])}
        except Exception:
            self.tf_fc_predictions = {}
    
    def _tf_autoencoder(self):
        """功能：TensorFlow AutoEncoder 特征降维

        以 sklearn 标准化后的 (49,5) 特征为输入，训练 5→32→10→32→5 的
        自编码器（瓶颈 10 维），再用编码器部分得到 49x10 的压缩表示。
        标签即输入本身（重构误差 MSE），用于后续相似度计算。
        参数：无（读取 self.sklearn_features_scaled）。
        返回：None
        注意：
            sklearn 特征为 None、keras/layers 缺失或训练异常时，
            把 tf_autoencoder/tf_encoded 置 None；
            写入 self.tf_autoencoder（keras.Model）与 self.tf_encoded
            （np.ndarray (49,10)）；训练 20 epochs。
        """
        keras = _core._keras_module
        layers = _core._layers_module
        if keras is None or layers is None:
            self.tf_autoencoder = None
            self.tf_encoded = None
            return
        try:
            # 依赖完整模式先执行过 _prepare_sklearn_features；None 会触发异常并回退
            X_flat = self.sklearn_features_scaled.astype(np.float32)
            encoding_dim = 10
            # 编码器
            inputs = keras.Input(shape=(X_flat.shape[1],))
            encoded = layers.Dense(32, activation='relu')(inputs)
            encoded = layers.Dense(encoding_dim, activation='relu')(encoded)
            # 解码器
            decoded = layers.Dense(32, activation='relu')(encoded)
            decoded = layers.Dense(X_flat.shape[1], activation='sigmoid')(decoded)
            autoencoder = keras.Model(inputs, decoded)
            autoencoder.compile(optimizer='adam', loss='mse')
            # 输入=输出，学习恒等映射；epochs=20 为小样本下的固定配置
            autoencoder.fit(X_flat, X_flat, epochs=20, batch_size=16, verbose=0)
            # 编码器部分
            encoder = keras.Model(inputs, encoded)
            self.tf_encoded = encoder.predict(X_flat, verbose=0)
            self.tf_autoencoder = autoencoder
        except Exception:
            self.tf_autoencoder = None
            self.tf_encoded = None
    
    def _prepare_pytorch_lstm(self):
        """功能：PyTorch LSTM 时序模型（完整训练循环）

        用连续 5 期 49 维 one-hot 序列训练 LSTM，输出下一期每个号码的出现
        概率。样本数 <30 时退化为单层 LSTM（dropout=0），否则两层 + dropout 0.2；
        训练 30 epochs、batch 16、Adam lr=0.001、BCE 损失。
        参数：无（读取 self.data）。
        返回：None
        注意：
            PyTorch 不可用、数据不足 20 期或训练异常时 pt_lstm_preds 置 {}；
            - 首次调用时把 self.device 设为 cuda（可用时）或 cpu；
            - 写入 pt_lstm_preds / pt_lstm_model，并触发 _pt_autoencoder；
            - 设置全局 torch 随机种子 42；
            - 训练期间 disable Python GC，finally 中恢复；
            - 把张量/模型搬运到 self.device，占用 GPU 显存。

        TODO(待确认): 原 docstring 提到“动态温度采样”，但实现中没有温度参数，
            预测阶段也未采样，仅有 LSTM 前向输出，需确认是否为遗留描述。
        """
        torch_mod = _get_torch()
        nn = _get_nn()
        optim_mod = _get_optim()
        if torch_mod is None:
            self.pt_lstm_preds = {}
            return
        # 延迟设置device
        # 仅在首次真正需要 PyTorch 时才探测 CUDA，避免构造期无谓初始化
        if self.device is None:
            self.device = torch_mod.device('cuda' if torch_mod.cuda.is_available() else 'cpu')
        if len(self.data) < 20:
            self.pt_lstm_preds = {}
            return
        # 【修复0xC0000374】抑制Python GC在PyTorch模型训练期间运行
        import gc as _gc  # 作用说明：训练期间临时关闭循环垃圾回收，finally 中按原状态恢复
        _gc_was_enabled = _gc.isenabled()
        _gc.disable()
        try:
            torch_mod.manual_seed(42)
            # 构建时序数据：先反转为“旧→新”，再滑窗，标签在窗口之后
            data_ordered = list(reversed(self.data))
            X_pt, y_pt = [], []
            for i in range(len(data_ordered) - 5):
                seq = []
                for j in range(5):
                    one_hot = [0.0] * 49
                    for n in data_ordered[i + j].get('numbers', []):
                        # 过滤非法号码，避免 one_hot 索引越界
                        if 1 <= n <= 49:
                            one_hot[n - 1] = 1.0
                    seq.append(torch_mod.tensor(one_hot))
                # 每个样本先 stack 成 (5,49)，再 unsqueeze 成 (1,5,49)，最后 cat 拼批
                X_pt.append(torch_mod.stack(seq).unsqueeze(0))
                # 标签：序列之后的下一期是否出现
                next_nums = data_ordered[i + 5].get('numbers', [])
                y_pt.append(torch_mod.tensor([1.0 if n in next_nums else 0.0 for n in range(1, 50)]))
            if len(X_pt) < 10:
                self.pt_lstm_preds = {}
                return
            X_pt = torch_mod.cat(X_pt, dim=0)
            y_pt = torch_mod.stack(y_pt)
            # PyTorch LSTM完整训练循环 - 根据数据量自适应模型复杂度
            n_samples = len(X_pt)
            if n_samples < 30:
                # 数据量不足时使用简化模型，避免过拟合
                _num_layers, _dropout = 1, 0.0
            else:
                _num_layers, _dropout = 2, 0.2
            # 嵌套类在每次调用时重新定义，通过闭包读取 _num_layers/_dropout
            class LotteryLSTM(nn.Module):
                """功能：彩票LSTM模型类

                输入 (batch, 5, 49)，输出 (batch, 49) 的出现概率。

                Attributes:
                    lstm (nn.LSTM): 49 维输入、64 维隐藏状态，batch_first=True。
                    fc (nn.Sequential): 64->32->49，末层 Sigmoid。
                """
                def __init__(self):
                    """功能：构建 LSTM 网络结构

                    按闭包中的 _num_layers/_dropout 构建 LSTM：
                    单层时不传 dropout（PyTorch 单层 LSTM 使用 dropout 会告警）。
                    参数：无。
                    返回：无（构造函数）。
                    注意：无副作用；仅创建网络层，不搬运设备、不训练。
                    """
                    super().__init__()
                    if _num_layers >= 2:
                        self.lstm = nn.LSTM(49, 64, batch_first=True, num_layers=_num_layers, dropout=_dropout)
                    else:
                        # 单层LSTM不支持dropout
                        self.lstm = nn.LSTM(49, 64, batch_first=True, num_layers=1)
                    self.fc = nn.Sequential(
                        nn.Linear(64, 32), nn.ReLU(),
                        nn.Linear(32, 49), nn.Sigmoid()
                    )
                def forward(self, x):
                    """LSTM 前向传播

                    功能：经 LSTM 编码 5 期序列，取最后一个时间步送入
                    64→32→49 全连接层并做 Sigmoid。
                    参数：
                        x (torch.Tensor): 形状 (batch, 5, 49)。
                    返回：torch.Tensor: 形状 (batch, 49)，取最后一个时间步。
                    注意：无副作用；纯前向计算，不修改模型参数。
                    """
                    lstm_out, _ = self.lstm(x)
                    return self.fc(lstm_out[:, -1, :])
            model = LotteryLSTM().to(self.device)
            criterion = nn.BCELoss()
            optimizer = optim_mod.Adam(model.parameters(), lr=0.001)
            # 完整训练循环：前向传播/损失计算/反向传播/权重更新
            model.train()
            for epoch in range(30):
                total_loss = 0
                for i in range(0, len(X_pt), 16):
                    # 按 16 切批；最后一批可能不足 16，切片自动截断
                    batch_x = X_pt[i:i+16].to(self.device)
                    batch_y = y_pt[i:i+16].to(self.device)
                    optimizer.zero_grad()  # 梯度清零
                    outputs = model(batch_x)  # 前向传播
                    loss = criterion(outputs, batch_y)  # 损失计算
                    loss.backward()  # 反向传播
                    optimizer.step()  # 权重更新
                    total_loss += loss.item()
            # 预测：用最新 5 期（旧→新）构建下一期窗口
            latest_seq = []
            for record in data_ordered[-5:]:
                one_hot = [0.0] * 49
                for n in record.get('numbers', []):
                    if 1 <= n <= 49:
                        one_hot[n - 1] = 1.0
                latest_seq.append(one_hot)
            model.eval()
            with torch_mod.no_grad():
                last_seq = torch_mod.stack([torch_mod.tensor(x) for x in latest_seq]).unsqueeze(0).to(self.device)
                pred = model(last_seq).cpu().numpy()[0]
                self.pt_lstm_preds = {n+1: float(p) for n, p in enumerate(pred)}
            self.pt_lstm_model = model
            # PyTorch AutoEncoder特征降维
            self._pt_autoencoder()
        except Exception as e:
            self.pt_lstm_preds = {}
        finally:
            if _gc_was_enabled:
                _gc.enable()
    
    def _pt_autoencoder(self):
        """功能：PyTorch AutoEncoder 特征降维

        以 sklearn 标准化后的 (49,5) 特征为输入，训练 5→3→5 的自编码器
        （瓶颈 3 维），输出编码器部分的 49x3 压缩表示。
        参数：无（读取 self.sklearn_features_scaled）。
        返回：None
        注意：
            PyTorch 不可用、特征为 None 或训练异常时 pt_encoded 置 None；
            写入 self.pt_encoded（np.ndarray (49,3) 或 None）；
            训练 50 epochs（每次全量输入，不分批）。

        TODO(待确认): 本方法未把模型/张量 .to(self.device)，始终在 CPU 上训练；
            另外没有把模型保存到 self.pt_autoencoder_model（该属性只在轻量模式
            被置 None），与 LSTM 的属性约定不一致。
        """
        torch_mod = _get_torch()
        nn = _get_nn()
        optim_mod = _get_optim()
        if torch_mod is None or nn is None:
            self.pt_encoded = None
            return
        try:
            X = torch_mod.tensor(self.sklearn_features_scaled, dtype=torch_mod.float32)
            class PtAutoEncoder(nn.Module):
                """功能：PyTorch自编码器类

                Attributes:
                    encoder (nn.Sequential): 5->3，ReLU。
                    decoder (nn.Sequential): 3->5，Sigmoid。
                """
                def __init__(self):
                    """构建自编码器网络结构

                    功能：创建 5→3 的编码器与 3→5 的解码器，均带激活函数。
                    参数：无。
                    返回：无（构造函数）。
                    注意：无副作用；仅创建网络层，不训练、不搬运设备。
                    """
                    super().__init__()
                    self.encoder = nn.Sequential(
                        nn.Linear(5, 3), nn.ReLU()
                    )
                    self.decoder = nn.Sequential(
                        nn.Linear(3, 5), nn.Sigmoid()
                    )
                def forward(self, x):
                    """自编码器前向传播（重构）

                    功能：先编码到 3 维瓶颈，再解码回 5 维，输出重构结果。
                    参数：
                        x (torch.Tensor): 形状 (49,5)。
                    返回：torch.Tensor: 形状 (49,5) 的重构结果。
                    注意：无副作用；纯前向计算，不修改模型参数。
                    """
                    return self.decoder(self.encoder(x))
            model = PtAutoEncoder()
            optimizer = optim_mod.Adam(model.parameters(), lr=0.01)
            criterion = nn.MSELoss()
            model.train()
            # 全批量训练 50 轮；49x5 数据量很小，无需分 batch
            for epoch in range(50):
                recon = model(X)
                loss = criterion(recon, X)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            model.eval()
            with torch_mod.no_grad():
                self.pt_encoded = model.encoder(X).numpy()
        except Exception:
            self.pt_encoded = None
    
    def _build_dataframe(self):
        """构建 Pandas DataFrame，每期包含统计特征

        功能：
            为每期记录展开：和值、均值、标准差、奇偶/大小计数、跨度（最大-最小）、
            5 个区间计数（range_0..range_4）与 10 个尾数计数（tail_0..tail_9）。

        参数：
            无（读取 self.data）。

        返回：
            None。

        注意：
            降级边界（仅当 pandas 未安装时生效）：
            - 失效：本方法的结构化 DataFrame 特征（self.df），以及
              range_distribution_algorithm 里基于 DataFrame 列的趋势分支；
              该分支已有纯 Python 计数兜底，取最近 10 期 numbers 统计区间，
              与 DataFrame 分支仅在“期数不足 6 个号码的记录是否参与”上口径略异。
            - 仍可用：SciPy（检验/拟合/平滑/插值）、sklearn 特征与 GBDT、
              NumPy 矩阵、PyTorch/NetworkX 以及基础频率/遗漏/移动平均等，
              均不依赖 DataFrame。
            - 连带失效：statsmodels 自身依赖 pandas，缺 pandas 时
              HAS_STATSMODELS 为 False，自相关分析自动回退到 NumPy 基础算法
              （数值口径略有差异，依赖自相关的下游得分可能小幅变化，流程不中断）。
            - 缺少 pandas 时只置 self.df=None 并登记降级提示，不能抛出
              ImportError 冒泡到 _prepare_data，否则整条准备链会回退到
              _init_defaults（frequency 变空、预测退化为近似随机）。
            写入 self.df（DataFrame 或 None）；缺 pandas 时追加一条
            self.degradation_notices 并打印提示；pandas 的 ImportError 在方法
            内部捕获并转为降级，其它异常不做额外兜底，仍由上层 _prepare_data
            统一处理。
        """
        try:
            from pandas import DataFrame  # 作用说明：延迟导入 pandas DataFrame（仅预测算法使用，避免程序启动即加载）
        except ImportError:
            # 只捕获 pandas 缺失这一种：局部降级，不中断后续 SciPy/sklearn/时序步骤
            self.df = None
            self._record_degradation('pandas', [
                'DataFrame 结构化特征（和值/均值/标准差/奇偶/大小/跨度/区间/尾数）不可用',
                'range_distribution_algorithm 的 DataFrame 趋势分支退化为纯 Python 计数',
                'statsmodels 因自身依赖 pandas 无法加载，自相关系数改用 NumPy 基础算法（下游少量得分可能略有差异）',
            ])
            return
        records = []
        for record in self.data:
            numbers = record.get('numbers', [])
            # 少于 6 个号码的记录无法构成一注完整开奖，整条跳过
            if len(numbers) >= 6:
                rec = {
                    'numbers': numbers,
                    'sum': sum(numbers),
                    'mean': np.mean(numbers),
                    # np.std 默认 ddof=0（总体标准差）；单号码时无离散度，按 0
                    'std': np.std(numbers) if len(numbers) > 1 else 0,
                    'odd_count': sum(1 for n in numbers if LotteryConfig.is_odd(n)),
                    'even_count': sum(1 for n in numbers if LotteryConfig.is_even(n)),
                    'big_count': sum(1 for n in numbers if LotteryConfig.is_big(n)),
                    'small_count': sum(1 for n in numbers if LotteryConfig.is_small(n)),
                    'span': max(numbers) - min(numbers),
                }
                # 区间分布
                # 区间编号由 LotteryConfig 定义，非法号码返回 -1 需跳过
                range_counts = [0] * 5
                for n in numbers:
                    idx = LotteryConfig.get_range_index(n)
                    if idx >= 0:
                        range_counts[idx] += 1
                for i in range(5):
                    rec[f'range_{i}'] = range_counts[i]
                # 尾数分布
                tail_counts = [0] * 10
                for n in numbers:
                    tail = LotteryConfig.get_tail_digit(n)
                    tail_counts[tail] += 1
                for i in range(10):
                    rec[f'tail_{i}'] = tail_counts[i]
                records.append(rec)
        self.df = DataFrame(records) if records else DataFrame()

    def _record_degradation(self, missing_lib, failed_items):
        """功能：登记并打印一条数据准备降级提示（不弹窗、不抛出）

        可选依赖缺失时使用。预测在后台线程执行，这里只写属性并打印到标准输出，
        不弹任何界面窗口，避免打断用户操作；调用方可经 get_degradation_notices()
        读取同一份提示并展示在分析结果/日志里。
        参数：
            missing_lib (str): 缺失的库名，如 'pandas'。
            failed_items (list[str]): 因该库缺失而失效的具体特征/功能清单。
        返回：None
        注意：
            属性缺失时自动初始化列表，打印失败也不影响主流程；
            向 self.degradation_notices 追加一个 dict；
            向标准输出打印「[降级] ...」及逐项失效清单。
        """
        if getattr(self, 'degradation_notices', None) is None:
            self.degradation_notices = []
        notice = {
            'library': missing_lib,
            'message': '未安装 %s，以下分析已降级；SciPy/sklearn/NumPy/时序步骤照常可用' % missing_lib,
            'failed_items': list(failed_items),
        }
        self.degradation_notices.append(notice)
        print('[降级] ' + notice['message'])
        for item in notice['failed_items']:
            print('[降级]   - ' + item)

    # 预留：降级提示读取入口（当前未接界面）
    def get_degradation_notices(self):
        """功能：返回数据准备阶段的降级提示（只读副本）

        参数：无。
        返回：list[dict]: 每项含 library（缺失库名）、message（提示文案）、
            failed_items（失效项清单）；无降级时返回空列表。
        注意：无副作用（返回浅拷贝列表，调用方增删元素不影响内部状态）。
        """
        return list(getattr(self, 'degradation_notices', None) or [])

    def _calculate_correlation_matrix(self):
        """功能：NumPy 计算 49x49 共现相关性矩阵

        统计同一期内任意两个号码共同出现的次数（含 i==j 的自共现），
        再按行归一化，使每行之和为 1，便于作为条件概率使用。
        参数：无（读取 self.data）。
        返回：None
        注意：
            无异常兜底；少于 10 期时直接退回单位阵；
            写入 self.correlation_matrix（49x49 np.ndarray，1 基号码映射到 n-1）。
        """
        # 少于 10 期时共现统计不稳定，退回单位阵（仅自身共现为 1）
        if len(self.data) < 10:
            self.correlation_matrix = np.eye(49)
            return
        matrix = np.zeros((49, 49))
        for record in self.data:
            numbers = record.get('numbers', [])
            for i in numbers:
                for j in numbers:
                    # 过滤非法号码，避免 i-1/j-1 为负或越界
                    if 1 <= i <= 49 and 1 <= j <= 49:
                        matrix[i-1, j-1] += 1
        # 归一化
        # 从未出现的号码行和为 0，先把 0 替换为 1，避免除零；这些行归一化后仍为 0
        row_sums = matrix.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1
        self.correlation_matrix = matrix / row_sums
    
    def _calculate_autocorrelation(self):
        """功能：计算每个数字的一阶自相关系数（优先 statsmodels）

        把每期“号码 num 是否出现”编码成 0/1 序列，计算一阶（lag=1）
        自相关系数，衡量相邻两期出现情况的相关性。
        参数：无（读取 self.data）。
        返回：None
        注意：
            单个号码的异常被捕获并记为 0.0；
            写入 self.autocorrelation（dict[int,float]，1..49）。

        TODO(待确认): 局部变量 tsastats = _core._tsastats_module 赋值后未使用，
            疑为历史遗留；可确认后删除。
        """
        self.autocorrelation = {}
        sm = _get_sm()
        tsastats = _core._tsastats_module
        for num in range(1, 50):
            series = []
            for record in self.data:
                series.append(1 if num in record.get('numbers', []) else 0)
            # 少于 10 期的 0/1 序列自相关不可靠，直接记 0
            if len(series) >= 10:
                try:
                    # 常量序列（全 0 或全 1）方差为 0，statsmodels 的 acf 会做 0/0 除法，
                    # 抛出 RuntimeWarning 并返回 NaN；这里直接判定为无自相关
                    if float(np.var(series)) <= 0:
                        self.autocorrelation[num] = 0.0
                        continue
                    if sm is not None and _core.HAS_STATSMODELS:
                        # nlags 最多 5，且不超过序列长度一半（statsmodels 建议）
                        acf = sm.tsa.acf(np.array(series), nlags=min(5, len(series)//2))
                        val = acf[1] if len(acf) > 1 else 0.0
                        # acf 可能返回 NaN/inf，统一归零，避免后续 int() 转换抛异常
                        self.autocorrelation[num] = float(val) if np.isfinite(val) else 0.0
                    else:
                        # 无statsmodels时使用基础自相关计算
                        if len(series) > 1:
                            mean = np.mean(series)
                            var = np.var(series)
                            if var > 0:
                                # 有偏估计：分母用 n*var（而非 (n-1)*var），
                                # 与 statsmodels 的 acf 口径接近
                                autocorr = np.sum((np.array(series[:-1]) - mean) * (np.array(series[1:]) - mean)) / (len(series) * var)
                                self.autocorrelation[num] = float(autocorr) if not np.isnan(autocorr) else 0.0
                            else:
                                self.autocorrelation[num] = 0.0
                        else:
                            self.autocorrelation[num] = 0.0
                except Exception:
                    self.autocorrelation[num] = 0.0
            else:
                self.autocorrelation[num] = 0.0
    
    def _calculate_interval_stats(self):
        """功能：计算间隔统计特征（均值、方差、偏度、Z-score）

        对每个号码统计相邻两次出现之间的“下标距离”（单位：期），
        得到 mean/std/skew，并用当前遗漏与间隔分布比较得到 zscore。
        偏度采用样本偏度（无偏估计 G1，n>=3 且方差非零时有效），
        正偏表示间隔右侧长尾（偶发长间隔），负偏表示左侧长尾。
        下标差计算依赖 self.data 的排列顺序，但间隔长度本身与方向无关。
        参数：无（读取 self.data/self.missing）。
        返回：None
        注意：间隔数 < 3 或方差为 0 时 skew 记 0；
            写入 self.interval_stats（dict[int,dict]，1..49）。
        """
        self.interval_stats = {}
        for num in range(1, 50):
            intervals = []
            last_appeared = None
            for i, record in enumerate(self.data):
                if num in record.get('numbers', []):
                    if last_appeared is not None:
                        intervals.append(i - last_appeared)
                    last_appeared = i
            if intervals:
                self.interval_stats[num] = {
                    'mean': np.mean(intervals),
                    # 单个间隔时标准差无定义，按 0
                    'std': np.std(intervals) if len(intervals) > 1 else 0,
                    'skew': _sample_skewness(intervals),
                    'zscore': self._calculate_zscore(self.missing.get(num, 50), intervals)
                }
            else:
                # 从未出现过（或只出现一次）时无间隔可算，用均值 6.0 作历史中性先验
                self.interval_stats[num] = {
                    'mean': 6.0, 'std': 0, 'skew': 0, 'zscore': 0
                }
    
    def _calculate_zscore(self, current_miss, intervals):
        """计算当前遗漏的 Z-score

        功能：z = (current_miss - mean(intervals)) / std(intervals)，用于衡量
        当前遗漏相对历史间隔的异常程度。
        参数：
            current_miss (int|float): 当前遗漏期数。
            intervals (Sequence[int]): 历史出现间隔（下标差）。
        返回：float: (current_miss - mean) / std；intervals 为空或 std==0 时返回 0。
        注意：无副作用；空序列与零标准差的除零边界均返回 0。
        """
        if not intervals:
            return 0
        mean = np.mean(intervals)
        # 只有 1 个间隔时无法估标准差，用 1 兜底避免除零
        std = np.std(intervals) if len(intervals) > 1 else 1
        if std == 0:
            return 0
        return (current_miss - mean) / std
    
    def _calculate_adjacent_stats(self):
        """功能：计算连号/邻号历史概率

        对每期内排序后的号码两两比较：差值 <=2 记为“邻号”，差值 ==1 记为
        “连号”。邻号按 (a,b) 与 (b,a) 双向各累计一次；连号对两个端点号码
        分别累计。最后分别按总对数归一化。
        参数：无（读取 self.data）。
        返回：None
        注意：
            空数据时 total 为 0，跳过归一化，概率字典为空；
            写入 self.adjacent_prob / self.consecutive_prob
            （defaultdict(float)，键为号码或号码对）。

        TODO(待确认): consecutive_prob 的分子对连号两端各计一次，而分母
            total_consec 只按“连号对”计一次，归一化后所有号码的值之和约为 2，
            并非严格概率；调用方若按概率解释需注意。
        """
        self.adjacent_prob = defaultdict(float)
        self.consecutive_prob = defaultdict(float)
        total_pairs = 0
        total_consec = 0
        for record in self.data:
            # 排序后只需比较 i<j 的组合，避免重复计数
            numbers = sorted(record.get('numbers', []))
            for i in range(len(numbers)):
                for j in range(i+1, len(numbers)):
                    diff = abs(numbers[j] - numbers[i])
                    # 差值 1 为连号、2 为隔一号的邻号，统一归入邻号概率
                    if diff <= 2:
                        self.adjacent_prob[(numbers[i], numbers[j])] += 1
                        self.adjacent_prob[(numbers[j], numbers[i])] += 1
                        total_pairs += 2  # 双向计数，与上面两行对称
                    if diff == 1:
                        self.consecutive_prob[numbers[i]] += 1
                        self.consecutive_prob[numbers[j]] += 1
                        total_consec += 1
        # 归一化
        if total_pairs > 0:
            for key in self.adjacent_prob:
                self.adjacent_prob[key] /= total_pairs
        if total_consec > 0:
            for key in self.consecutive_prob:
                self.consecutive_prob[key] /= total_consec
    
    def _calculate_moving_avg(self):
        """功能：计算 5 期/10 期/20 期移动平均出现率

        对每个号码把每期编码为 0/1，取最近 window 期的均值作为出现率；
        历史长度不足 window 时用 0.1 作为默认出现率（约等于 1/10 的中性先验）。
        参数：无（读取 self.data）。
        返回：None
        注意：
            空数据时 len(series)=0，全部走默认值分支，不抛异常；
            写入 self.moving_avg（dict[int,dict[int,float]]）。

        说明:
            self.data[0] 为最新一期，因此 series[:window] 才是最近 window 期；
            原实现 series[-window:] 取到的是最旧窗口。
        """
        self.moving_avg = {num: {} for num in range(1, 50)}
        for window in [5, 10, 20]:
            for num in range(1, 50):
                series = [1 if num in r.get('numbers', []) else 0 for r in self.data]
                if len(series) >= window:
                    self.moving_avg[num][window] = np.mean(series[:window])
                else:
                    # 数据不足一个窗口时无法计算，用 0.1 避免 0 值把后续得分压死
                    self.moving_avg[num][window] = 0.1
    
    def _calculate_missing(self, number):
        """计算指定号码的当前遗漏期数

        功能：自最新一期（data[0]）向后遍历，遇到该号码即返回已走过的期数；
        从未出现时返回历史长度 + 10 的惩罚值。
        参数：
            number (int): 号码（1..49）。
        返回：int: 遗漏期数；号码从未出现时返回 len(data)+10（额外加 10 作为惩罚）。
        注意：无副作用；空数据时返回 10，不抛异常。

        说明:
            self.data[0] 是最新一期，直接从头遍历得到的才是当前遗漏；
            原实现 reversed 后找的是“距最旧一次出现”的期数。
        """
        missing = 0
        for record in self.data:
            if number in record.get('numbers', []):
                return missing
            missing += 1
        # 从未出现：以“历史长度 + 10”作为罚值，保证大于任何正常遗漏
        return missing + 10

    def _data_signature(self):
        """功能：返回当前历史数据的轻量指纹，用于实例内算法缓存失效

        参数：无（读取 self.data）。
        返回：tuple: (期数, 内容哈希)；空数据返回 (0, 0)。
        注意：无副作用；指纹变化即代表数据追加/删改/换窗口，相关缓存自动失效。

        说明:
            self.data 约定为“期号倒序、最新在前”。指纹由期数 + 全部期的
            (期号, 号码元组) 组成，数据一旦追加、删改或换窗口，指纹立即变化，
            以它为 key 的缓存（逐期序列、sklearn 特征表、样条外推结果）自动失效。
            100 期数据哈希开销约几十微秒，远小于重复计算 49 条序列的成本。
        """
        if not self.data:
            return (0, 0)
        payload = tuple(
            (record.get('period'), tuple(record.get('numbers', [])))
            for record in self.data
        )
        return (len(payload), hash(payload))

    def _get_number_series(self):
        """功能：构建 1..49 每个号码的逐期出现序列与当前遗漏序列（时间方向：旧 → 新）

        时间方向假设:
            self.data[0] 是最新一期、self.data[-1] 是最旧一期；本方法统一翻转为
            “旧 → 新”下标 t（t=0 最旧、t=N-1 最新），后续所有回归/样条/特征
            都按“用过去预测未来”的口径使用该方向，不再出现反向假设。
        参数：无（读取 self.data）。
        返回：tuple[np.ndarray, np.ndarray]:
            occ  (49, N) float64：occ[i, t]=1 表示号码 i+1 在第 t 期出现；
            miss (49, N) float64：miss[i, t] 为第 t 期结束时的“当前遗漏”，
                 即从第 t 期往回连续未出现的期数；当期出现记 0，
                 从未出现过则为 t+1（最多 N）。
        注意：
            空数据返回两个 (49,0) 空矩阵；
            写入 self._series_cache（键含 _data_signature）；同一指纹下重复调用直接复用。
        """
        key = ('number_series', self._data_signature())
        cache = getattr(self, '_series_cache', None)
        if cache is not None and cache.get('key') == key:
            return cache['occ'], cache['miss']

        n = len(self.data)
        occ = np.zeros((49, n), dtype=np.float64)
        # data[0] 最新，reversed 后按“旧 → 新”写入列 t
        for t, record in enumerate(reversed(self.data)):
            for num in record.get('numbers', []):
                if 1 <= num <= 49:
                    occ[num - 1, t] = 1.0

        miss = np.zeros((49, n), dtype=np.float64)
        last = np.full(49, -1, dtype=np.int64)  # 上一次出现的“旧→新”下标
        for t in range(n):
            appeared = occ[:, t] == 1
            last[appeared] = t
            # last<0 表示至今从未出现，此时 t-last = t+1（已观察期数）
            miss[:, t] = (t - last).astype(np.float64)

        self._series_cache = {'key': key, 'occ': occ, 'miss': miss}
        return occ, miss

    def _calculate_range_distribution(self):
        """计算区间分布（0..4 各区间的出现次数）

        功能：遍历全部历史号码，按 LotteryConfig.get_range_index 归类累加。
        参数：无（读取 self.data）。
        返回：dict[int,int]: 键 0..4 的区间出现次数；非法号码（区间索引 <0）忽略。
        注意：无副作用；不修改 self.data，非法号码静默跳过。
        """
        distribution = {i: 0 for i in range(5)}
        for record in self.data:
            for num in record.get('numbers', []):
                idx = LotteryConfig.get_range_index(num)
                # 区间索引由 LotteryConfig 决定，-1 表示号码不在任何有效区间
                if idx >= 0:
                    distribution[idx] += 1
        return distribution
    
    def _calculate_tail_distribution(self):
        """计算尾数分布（0..9 各尾数的出现次数）

        功能：遍历全部历史号码，按 LotteryConfig.get_tail_digit 归类累加。
        参数：无（读取 self.data）。
        返回：dict[int,int]: 键 0..9 的尾数出现次数。
        注意：无副作用；不修改 self.data。
        """
        distribution = {i: 0 for i in range(10)}
        for record in self.data:
            for num in record.get('numbers', []):
                tail = LotteryConfig.get_tail_digit(num)
                distribution[tail] += 1
        return distribution
    
    def _calculate_odd_even_ratio(self):
        """计算奇偶比例

        功能：统计历史全部号码中奇数的占比，偶数归入分母另一侧。
        参数：无（读取 self.data）。
        返回：float: 奇数号码占全部号码的比例；无数据时返回中性值 0.5。
        注意：无副作用；总数为 0 时返回中性值 0.5，避免除零。
        """
        odd_count = even_count = 0
        for record in self.data:
            for num in record.get('numbers', []):
                if LotteryConfig.is_odd(num):
                    odd_count += 1
                else:
                    even_count += 1
        total = odd_count + even_count
        return odd_count / total if total > 0 else 0.5
    
    def _calculate_big_small_ratio(self):
        """计算大小比例

        功能：统计历史全部号码中大号（LotteryConfig.is_big）的占比。
        参数：无（读取 self.data）。
        返回：float: 大号（LotteryConfig.is_big）占全部号码的比例；
            无数据时返回中性值 0.5。
        注意：无副作用；总数为 0 时返回中性值 0.5，避免除零。
        """
        big_count = small_count = 0
        for record in self.data:
            for num in record.get('numbers', []):
                if LotteryConfig.is_big(num):
                    big_count += 1
                else:
                    small_count += 1
        total = big_count + small_count
        return big_count / total if total > 0 else 0.5
    
    def _lr_roulette_weights(self):
        """功能：用 sklearn LogisticRegression 计算轮盘赌概率权重

        以 49x5 的 sklearn 特征为输入、以“最近一期是否出现”为 0/1 标签，
        训练逻辑回归后用 predict_proba 的类别 1 概率作为每个号码的权重。
        参数：无（读取 self.sklearn_features_scaled 与 self.data）。
        返回：list[float]: 长度 49 的权重；数据不足、sklearn 不可用或异常时
            返回全 0.02 的等权（0.02*49≈1）。
        注意：
            写入局部模型但不保存到 self；触发 sklearn 懒加载。

        TODO(待确认): 标签只来自 data[0] 一期，49 个样本中正负例极少且
            高度相关，逻辑回归可能难以收敛，权重稳定性需评估。
        """
        if len(self.data) < 20 or not hasattr(self, 'sklearn_features') or self.sklearn_features is None:
            return [0.02] * 49
        try:
            _get_sklearn()
            LR = _core._LogisticRegression
            if LR is None:
                return [0.02] * 49
            X = self.sklearn_features_scaled.copy()
            # 构造标签：最近一期出现的号码为1，未出现为0（data[0] 是最新一期）
            last_draw = set(self.data[0].get('numbers', [])) if self.data else set()
            y = np.array([1 if n in last_draw else 0 for n in range(1, 50)])
            # 【修复0xC0000409】设置n_jobs=1禁用OpenMP并行，防止C栈溢出
            # max_iter=100/random_state=42 保证结果可复现
            lr_model = LR(max_iter=100, random_state=42, n_jobs=1)
            lr_model.fit(X, y)
            proba = lr_model.predict_proba(X)
            # 取类别1的概率
            if proba.shape[1] == 2:
                weights = proba[:, 1].tolist()
            else:
                # 标签只有单一类别时 predict_proba 只有 1 列，无法给出出现概率
                weights = [0.02] * 49
            return weights
        except Exception:
            return [0.02] * 49
    
    def _get_weighted_score(self, num):
        """功能：综合多维度计算单个数字的加权得分

        权重配置：频率0.15、遗漏回补0.2、短期趋势0.15、中期趋势0.15、
        自相关0.1、Z-score0.1、共现0.15（合计 1.0）。各维度先归一到 0..1，
        再乘以权重和 100，得到便于比较的百分制分数。
        参数：
            num (int): 号码（1..49）。
        返回：float: 加权总分；无数据时多数项退化为 0/中性值，可能为负
            （短期趋势项允许负值），该分数只用于相对排序，不是概率。
        注意：
            无副作用（只读属性）；num 超出 1..49 时共现索引可能抛出
            IndexError，调用方保证范围。

        TODO(待确认): 频率分母 len(data)*6 假设每期固定 6 个号码；
            若彩种号码个数不同，频率占比会被系统性放大/缩小。
        """
        score = 0.0
        
        # 1. 频率得分 (权重0.15)
        freq = self.frequency.get(num, 0)
        # 每期假设 6 个号码，故总号码数为 期数*6
        total = len(self.data) * 6
        freq_score = freq / total if total > 0 else 0
        score += freq_score * 0.15 * 100
        
        # 2. 遗漏回补得分 (权重0.2)
        miss = self.missing.get(num, 50)
        # 49 个号码均分历史期数，得到每个号码的理论平均间隔
        avg_cycle = len(self.data) / 49 if len(self.data) > 0 else 6
        miss_score = MathUtils.calculate_missing_cycle(miss, avg_cycle)
        score += miss_score * 0.2 * 100
        
        # 3. 短期趋势MA5 vs MA20 (权重0.15)
        # +0.1 是基线偏移，使 MA5==MA20 时仍有中性基础分；*5 放大差值（约 -4.5..5.5）
        ma5 = self.moving_avg.get(num, {}).get(5, 0.1)
        ma20 = self.moving_avg.get(num, {}).get(20, 0.1)
        trend_score = (ma5 - ma20 + 0.1) * 5
        score += trend_score * 0.15 * 100
        
        # 4. 中期趋势 (权重0.15)
        # MA10 是 0..1 的出现率，*10 映射到 0..10
        ma10 = self.moving_avg.get(num, {}).get(10, 0.1)
        mid_trend_score = ma10 * 10
        score += mid_trend_score * 0.15 * 100
        
        # 5. 自相关性加成 (权重0.1)
        # 负自相关不加分（max(0,...)），只奖励正向延续
        autocorr = self.autocorrelation.get(num, 0)
        score += max(0, autocorr) * 0.1 * 100
        
        # 6. Z-score异常检测 (权重0.1)
        # sigmoid 把 zscore 映射到 0..1；zscore 越大（遗漏越异常）得分越高
        stats = self.interval_stats.get(num, {})
        zscore = stats.get('zscore', 0)
        zscore_score = 1.0 / (1 + np.exp(-zscore))  # sigmoid
        score += zscore_score * 0.1 * 100
        
        # 7. 共现相关性得分 (权重0.15)
        if len(self.data) > 0:
            latest_nums = self.data[0].get('numbers', [])
            # 【修复除零bug】latest_nums可能为空列表，len()=0会除零崩溃
            # 【修复越界bug】过滤掉不在1-49范围的异常号码，防止correlation_matrix索引越界
            valid_nums = [n for n in latest_nums if 1 <= n <= 49]
            if valid_nums:
                # 取该号码与最近一期所有号码的平均共现条件概率（行归一化后）
                cooccur = sum(self.correlation_matrix[num-1, n-1] for n in valid_nums) / len(valid_nums)
                score += cooccur * 0.15 * 100
        
        return score
    
    def _optimize_ensemble_weights(self, n_trials=10):
        """功能：Optuna 贝叶斯优化集成权重（无 Optuna 时使用固定权重）

        【Bug修复】补齐 w_odd_even 和 w_big_small 两个权重参数，与增强模式保持一致。
        用 TPE 采样器在给定区间内搜索 7 个权重，目标函数为 49 个号码加权得分
        之和（权重先按总和归一化，等价于在单纯形上搜索）。
        参数：
            n_trials (int): Optuna 试验次数，默认 10。
        返回：dict[str,float]: 最优权重字典（7 个键）；无 Optuna 时返回固定权重。
        注意：
            Optuna 内部异常会向上抛出（未在此捕获）；
            - 设置 optuna 日志级别为 WARNING；
            - 创建 study 并执行 n_trials 次目标函数，耗时随 n_trials 线性增长；
            - n_jobs=1 避免多进程/线程带来的 C 栈溢出（0xC0000409）。

        TODO(待确认): 原注释“模拟验证集评分（使用最后5期数据）”与实现不符，
            目标函数实际用全量统计量打分，没有使用最后 5 期，也没有回测命中率。
        """
        optuna = _get_optuna()
        TPESampler = _core._TPESampler_class
        # 无Optuna时返回固定权重（补齐7个权重）
        # 默认权重之和恰为 1.0
        if optuna is None or TPESampler is None:
            return {
                'w_hot_cold': 0.2, 'w_missing': 0.2, 'w_range': 0.15,
                'w_tail': 0.15, 'w_odd_even': 0.1, 'w_big_small': 0.1,
                'w_freq': 0.1
            }
        
        def objective(trial):
            """Optuna 优化目标函数

            功能：采样 7 个权重并按总和归一化，累加 1..49 的多维加权得分
            作为本次 trial 的评分（越大越好）。
            参数：
                trial (optuna.Trial): 用于 suggest_float 采样超参数。
            返回：float: 49 个号码归一化加权得分之和；全零权重时返回 0。
            注意：无副作用；全零权重直接返回 0，避免除零。
            """
            # 各权重区间来自经验设定：热冷/遗漏最重要（上限 0.4），
            # 区间/尾数/奇偶/大小/频率次之（上限 0.3）
            w1 = trial.suggest_float('w_hot_cold', 0.0, 0.4)
            w2 = trial.suggest_float('w_missing', 0.0, 0.4)
            w3 = trial.suggest_float('w_range', 0.0, 0.3)
            w4 = trial.suggest_float('w_tail', 0.0, 0.3)
            w5 = trial.suggest_float('w_odd_even', 0.0, 0.3)
            w6 = trial.suggest_float('w_big_small', 0.0, 0.3)
            w7 = trial.suggest_float('w_freq', 0.0, 0.3)
            total = w1 + w2 + w3 + w4 + w5 + w6 + w7
            if total == 0:
                return 0
            # 模拟验证集评分（使用最后5期数据）
            # TODO(待确认): 实现只遍历 49 个号码累加得分，并未使用最后 5 期
            scores = {}
            for num in range(1, 50):
                s = 0
                s += self._hot_cold_score(num) * w1 / total
                s += self._missing_score(num) * w2 / total
                s += self._range_score(num) * w3 / total
                s += self._tail_score(num) * w4 / total
                s += self._odd_even_score(num) * w5 / total
                s += self._big_small_score(num) * w6 / total
                s += self.frequency.get(num, 0) * w7 / total
                scores[num] = s
            # 返回模拟得分
            return sum(scores.values())
        
        optuna.logging.set_verbosity(optuna.logging.WARNING)
        study = optuna.create_study(direction='maximize', sampler=TPESampler(seed=42))
        # 【修复0xC0000409】设置n_jobs=1禁用并行，防止C栈溢出
        study.optimize(objective, n_trials=n_trials, show_progress_bar=False, n_jobs=1)
        return study.best_params
    
    def _hot_cold_score(self, num):
        """冷热得分

        功能：得分 = exp(-遗漏/5)*0.5 + 出现率*0.5，遗漏越小、出现越频繁
        的号码（热号）得分越高。
        参数：
            num (int): 号码（1..49）。
        返回：float: exp(-遗漏/5)*0.5 + 出现率*0.5；遗漏越小、出现越多得分越高。
        注意：无副作用；空数据时出现率按 0 处理，不除零。
        """
        # 衰减常数 5：遗漏每增加 5 期，历史热度权重衰减到 1/e
        decay = np.exp(-self.missing.get(num, 0) / 5)
        freq_score = self.frequency.get(num, 0) / len(self.data) if self.data else 0
        return decay * 0.5 + freq_score * 0.5
    
    def _missing_score(self, num):
        """遗漏得分

        功能：得分 = sigmoid(zscore)*0.5 + 遗漏回补概率*0.5，兼顾“遗漏异常
        程度”与指数回补概率，固定以平均间隔 6 计算。
        参数：
            num (int): 号码（1..49）。
        返回：float: sigmoid(zscore)*0.5 + 遗漏回补概率*0.5。
        注意：无副作用；zscore 缺失按 0、遗漏缺失按 50 兜底。
        """
        miss = self.missing.get(num, 50)
        stats = self.interval_stats.get(num, {})
        zscore = stats.get('zscore', 0)
        # 固定以 6 作为平均间隔（约等于 49 个号码每期开 6 个的理论周期）
        return (1 / (1 + np.exp(-zscore))) * 0.5 + MathUtils.calculate_missing_cycle(miss, 6) * 0.5
    
    def _range_score(self, num):
        """区间得分

        功能：得分 = (1 - 该区间出现占比) * 10，即越冷门的区间得分越高。
        参数：
            num (int): 号码（1..49）。
        返回：float: (1 - 该区间出现占比) * 10，即越冷门的区间得分越高。
        注意：无副作用；空分布时以 1 作分母兜底，避免除零。
        """
        idx = LotteryConfig.get_range_index(num)
        # 空分布时用 1 兜底避免除零；分布为空则占比为 0，得 10 分
        total = sum(self.range_distribution.values()) or 1
        return (1 - self.range_distribution.get(idx, 0) / total) * 10
    
    def _tail_score(self, num):
        """尾数得分

        功能：得分 = (1 - 该尾数出现占比) * 10，即越冷门的尾数得分越高。
        参数：
            num (int): 号码（1..49）。
        返回：float: (1 - 该尾数出现占比) * 10，即越冷门的尾数得分越高。
        注意：无副作用；空分布时以 1 作分母兜底，避免除零。
        """
        tail = LotteryConfig.get_tail_digit(num)
        # 空分布时用 1 兜底避免除零
        total = sum(self.tail_distribution.values()) or 1
        return (1 - self.tail_distribution.get(tail, 0) / total) * 10
    
    # 12种增强算法
    
    def comprehensive_recommendation(self, count=6, enhanced=True, reverse=False):
        """综合推荐（增强版：动态权重 + 多模型融合 + 模式识别）

        功能：对 1..49 每个号码计算“基础特征分 + 投票分 + 45*加权集成分 +
        多模型概率加成”，再按得分选号；reverse=True 时反向取低分号码。
        参数：
            count (int): 预测号码数量。
            enhanced (bool): 是否启用增强模式（动态权重+模式识别+分布平衡）。
            reverse (bool): 是否反向模式（True=选最不可能的号码，追求高错误率）。

        数学含义:
            对 1..49 每个号码计算
            score = 基础特征分 + 投票分 + 45 * 加权集成分 + 多模型概率加成，
            再按得分选出 count 个号码；reverse=True 时反过来取低分号码。
        输入依赖:
            self.data / frequency / missing / interval_stats / moving_avg /
            autocorrelation，以及可选模型产物 tf_predictions、pt_lstm_preds、
            np_features、scipy_interp_func；模型缺失时对应加成为 0，不会报错。
        适用场景:
            作为“综合推荐”算法入口；数据 >=20 期才会启用 GBDT 概率加成。
        返回：list[int]，长度为 count；正向模式由 _balance_selection 返回升序列表，
            反向模式返回 _reverse_balance_selection 的升序列表（不是概率字典）。
        注意：
            异常在内部被捕获并打印 traceback，然后降级到经典模式；
            - 依次调用 6 个子算法及多个模型，耗时较长；
            - 异常路径会向 stderr 打印 traceback；
            - 最底层兜底使用 random.sample，受全局随机状态影响。
        """
        try:
            if not enhanced:
                # 经典模式：原有逻辑
                result = self._classic_comprehensive(count)
                if reverse:
                    return self._reverse_selection(result, count)
                return result
            
            # 计算近期各算法实际表现，动态调整权重
            dynamic_weights = self._calculate_dynamic_weights(lookback=15)
            
            # 收集各算法预测
            # 候选倍数按算法可靠性分配：热冷/遗漏各取 3*count（历史命中相对高），
            # 区间/尾数/奇偶/大小各取 2*count，扩大投票池又不至于淹没共识号码
            predictions = []
            predictions.extend(self.hot_cold_algorithm(count * 3))
            predictions.extend(self.missing_value_analysis(count * 3))
            predictions.extend(self.range_distribution_algorithm(count * 2))
            predictions.extend(self.tail_distribution_algorithm(count * 2))
            predictions.extend(self.odd_even_algorithm(count * 2))
            predictions.extend(self.big_small_algorithm(count * 2))
            
            # 统计各数字出现次数（投票）
            counter = Counter(predictions)
            
            # 各机器学习模型预测概率
            gb_probs = self._gb_predict_probs() if len(self.data) >= 20 else {}
            tf_bonus = self.tf_predictions if hasattr(self, 'tf_predictions') and self.tf_predictions else {}
            pt_bonus = self.pt_lstm_preds if hasattr(self, 'pt_lstm_preds') and self.pt_lstm_preds else {}
            np_bonus = self._np_regression_bonus() if hasattr(self, 'np_features') and self.np_features is not None else {}
            scipy_bonus = self._scipy_interp_bonus() if hasattr(self, 'scipy_interp_func') and self.scipy_interp_func else {}
            
            # 近期模式识别加成
            pattern_bonus = self._pattern_recognition_bonus()
            
            # 计算综合得分
            scores = {}
            total_w = sum(dynamic_weights.values()) or 1
            for num in range(1, 50):
                # 基础特征得分
                feature_score = self._get_weighted_score(num)
                
                # 投票得分
                # 每票 12 分：多算法共识的权重高于单一特征（特征分通常为个位数~十几）
                vote_score = counter.get(num, 0) * 12
                
                # 动态权重集成得分
                ensemble_score = 0
                ensemble_score += self._hot_cold_score(num) * dynamic_weights.get('w_hot_cold', 0.18) / total_w
                ensemble_score += self._missing_score(num) * dynamic_weights.get('w_missing', 0.18) / total_w
                ensemble_score += self._range_score(num) * dynamic_weights.get('w_range', 0.12) / total_w
                ensemble_score += self._tail_score(num) * dynamic_weights.get('w_tail', 0.12) / total_w
                ensemble_score += self._odd_even_score(num) * dynamic_weights.get('w_odd_even', 0.1) / total_w
                ensemble_score += self._big_small_score(num) * dynamic_weights.get('w_big_small', 0.1) / total_w
                # 【修复除零bug】self.data可能为空，len()=0会导致除零崩溃
                freq_val = self.frequency.get(num, 0) / len(self.data) if self.data else 0
                ensemble_score += freq_val * dynamic_weights.get('w_freq', 0.15) / total_w
                ensemble_score += pattern_bonus.get(num, 0) * dynamic_weights.get('w_pattern', 0.15) / total_w
                
                # 多模型概率加成
                # 0.02 为模型缺失时的先验兜底（约等于无信息时的单号概率量级）；
                # 各乘数（120/80/80/40/25）用于把 0~1 的概率映射到与投票分相近的量级
                ml_bonus = 0
                ml_bonus += gb_probs.get(num, 0.02) * 120
                ml_bonus += tf_bonus.get(num, 0.02) * 80 if tf_bonus else 0
                ml_bonus += pt_bonus.get(num, 0.02) * 80 if pt_bonus else 0
                ml_bonus += np_bonus.get(num, 0) * 40
                ml_bonus += scipy_bonus.get(num, 0) * 25
                
                # 45 为集成分缩放系数：ensemble_score 是 0~1 量级的加权平均，
                # 放大后与 feature/vote 同量级，避免某一项完全主导
                scores[num] = feature_score + vote_score + ensemble_score * 45 + ml_bonus
            
            if reverse:
                # 反向模式：选择得分最低的号码（最不可能出现）
                selected = self._reverse_balance_selection(scores, count)
            else:
                # 正向模式：平衡奇偶、大小、区间分布
                selected = self._balance_selection(scores, count)
            
            return selected
        except Exception:
            # 【修复0xC0000409】增强模式出错时降级到经典模式，避免崩溃
            import traceback  # 作用说明：打印异常栈到 stderr，便于后台线程排查降级原因
            traceback.print_exc()
            try:
                result = self._classic_comprehensive(count)
                if reverse:
                    return self._reverse_selection(result, count)
                return result
            except Exception:
                return sorted(random.sample(range(1, 50), count))
    
    def _classic_comprehensive(self, count=6):
        """功能：经典综合推荐（原有逻辑）

        【Bug修复】补齐 odd_even_algorithm 和 big_small_algorithm 两种算法预测，
        与增强模式 comprehensive_recommendation 保持 6 种算法一致。
        参数：
            count (int): 预测号码数量。
        数学含义:
            与增强模式同为 49 个号码加权打分（score = 特征分 + 投票分 +
            50 * 集成分 + 多模型加成），区别是不做动态权重和分布平衡，
            直接按得分取 Top count。
        输入依赖:
            _optimize_ensemble_weights 返回的权重（7 个 w_* 键，通常由 Optuna 搜索；
            无 Optuna 时为固定权重），以及 self.data 与各模型产物。
        适用场景:
            enhanced=False 的经典路径，或增强路径异常时的降级路径。
        返回：list[int]，按得分降序的前 count 个号码（未升序、未做奇偶平衡）。
        注意：
            异常被捕获并打印 traceback；兜底 random.sample 受全局随机状态影响。
        """
        try:
            # 返回 7 个权重键（不含 w_pattern），调用方用 total_w 归一化，缺键时取默认值
            best_weights = self._optimize_ensemble_weights(n_trials=10)
            predictions = []
            predictions.extend(self.hot_cold_algorithm(count * 3))
            predictions.extend(self.missing_value_analysis(count * 3))
            predictions.extend(self.range_distribution_algorithm(count * 2))
            predictions.extend(self.tail_distribution_algorithm(count * 2))
            predictions.extend(self.odd_even_algorithm(count * 2))
            predictions.extend(self.big_small_algorithm(count * 2))
            counter = Counter(predictions)
            gb_probs = self._gb_predict_probs() if len(self.data) >= 20 else {}
            tf_bonus = self.tf_predictions if hasattr(self, 'tf_predictions') and self.tf_predictions else {}
            pt_bonus = self.pt_lstm_preds if hasattr(self, 'pt_lstm_preds') and self.pt_lstm_preds else {}
            np_bonus = self._np_regression_bonus() if hasattr(self, 'np_features') and self.np_features is not None else {}
            scipy_bonus = self._scipy_interp_bonus() if hasattr(self, 'scipy_interp_func') and self.scipy_interp_func else {}
            
            scores = {}
            total_w = sum(best_weights.values()) or 1
            for num in range(1, 50):
                feature_score = self._get_weighted_score(num)
                # 每票 12 分，与增强模式统一乘数，保证两条路径分值尺度可比
                vote_score = counter.get(num, 0) * 12  # 与增强模式统一乘数
                ensemble_score = 0
                ensemble_score += self._hot_cold_score(num) * best_weights.get('w_hot_cold', 0.2) / total_w
                ensemble_score += self._missing_score(num) * best_weights.get('w_missing', 0.2) / total_w
                ensemble_score += self._range_score(num) * best_weights.get('w_range', 0.15) / total_w
                ensemble_score += self._tail_score(num) * best_weights.get('w_tail', 0.15) / total_w
                ensemble_score += self._odd_even_score(num) * best_weights.get('w_odd_even', 0.1) / total_w
                ensemble_score += self._big_small_score(num) * best_weights.get('w_big_small', 0.1) / total_w
                # 【修复除零bug】self.data可能为空，len()=0会导致除零崩溃
                freq_val = self.frequency.get(num, 0) / len(self.data) if self.data else 0
                ensemble_score += freq_val * best_weights.get('w_freq', 0.1) / total_w
                # 乘数 150/100/100/50/30 比增强模式略大：经典模式没有模式识别项，
                # 用更高的模型加成弥补信息量
                gb_bonus = gb_probs.get(num, 0.02) * 150
                tf_b = tf_bonus.get(num, 0.02) * 100 if tf_bonus else 0
                pt_b = pt_bonus.get(num, 0.02) * 100 if pt_bonus else 0
                np_b = np_bonus.get(num, 0) * 50
                scipy_b = scipy_bonus.get(num, 0) * 30
                # 50 为集成分缩放系数（经典模式取 50，增强模式取 45）
                scores[num] = feature_score + vote_score + ensemble_score * 50 + gb_bonus + tf_b + pt_b + np_b + scipy_b
            
            sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
            return [num for num, _ in sorted_nums[:count]]
        except Exception:
            # 【修复0xC0000409】经典模式出错时返回随机选择，避免崩溃
            import traceback  # 作用说明：打印异常栈到 stderr，便于定位经典模式失败原因
            traceback.print_exc()
            return sorted(random.sample(range(1, 50), count))
    
    def _calculate_dynamic_weights(self, lookback=15):
        """根据近期表现计算动态权重 - v7.5增强版
        
        优化：增加回测深度、多维度评估、自适应权重放大

        功能：用最近至多 8 个可回测期做滚动回测，统计 6 个算法的命中数与
        “单期命中 >=2 个”的命中率，算出相对权重后压缩到 0.55 的算法预算，
        其余 0.45 固定分给频率特征（0.18）与模式识别（0.27）。
        参数：
            lookback (int): 近期分析窗口期数（取 recent_data = self.data[:lookback]），
                默认 15；数据总量不足 lookback+3 期时直接返回默认权重。
        返回：dict[str,float]: 8 个键：w_hot_cold/w_missing/w_range/w_tail/
            w_odd_even/w_big_small/w_freq/w_pattern；正常路径权重总和为 1.0，
            数据不足时返回总和 1.10 的经验默认值（调用方用 total_w 再归一化）。
        注意：
            - 每个回测期创建一个 PredictionAlgorithms(_light_mode=True) 临时对象并显式删除；
            - 最多 8 次回测，耗时随 test_periods 增长；
            - 轻量模式不训练 TF/PyTorch/sklearn，避免递归与栈溢出；
            - 单个回测周期异常被 continue 吞掉，不向外抛出。
        数学含义:
            对最近至多 8 个可回测期，用“第 i+1 期及更早”的数据训练轻量预测器，
            预测第 i 期并统计 6 个算法的命中数；base = 命中总数占比，
            hit_rate = “单期命中 >=2 个”的比例，weighted = base * (1 + hit_rate * 0.8)，
            最后把 6 个算法归一化后压缩到总预算 0.55。
        输入依赖:
            self.data（最新期在前），不足 lookback+3 期时直接返回默认权重。
        适用场景:
            comprehensive_recommendation 的权重自适应；仅在增强模式下调用。
        """
        # 数据不足时无法回测：保留经验默认权重（注意此处各权重之和为 1.10，
        # 调用方 comprehensive_recommendation 会用 total_w 再做归一化）
        if len(self.data) < lookback + 3:
            return {
                'w_hot_cold': 0.18, 'w_missing': 0.18, 'w_range': 0.12,
                'w_tail': 0.12, 'w_odd_even': 0.1, 'w_big_small': 0.1,
                'w_freq': 0.15, 'w_pattern': 0.15
            }
        
        recent_data = self.data[:lookback]
        algo_scores = {
            'hot_cold': 0, 'missing': 0, 'range': 0, 'tail': 0,
            'odd_even': 0, 'big_small': 0
        }
        algo_hit_counts = {
            'hot_cold': 0, 'missing': 0, 'range': 0, 'tail': 0,
            'odd_even': 0, 'big_small': 0
        }
        
        # 【修复0xC0000409】限制test_periods最大值，防止递归创建过多临时对象导致栈累积
        # 上限 8 期；len-3 保证至少给训练集留 3 期（配合下方 train_data < 5 的跳过判断）
        test_periods = max(0, min(8, len(recent_data) - 3))
        for i in range(test_periods):
            try:
                actual = set(recent_data[i].get('numbers', []))
                # 训练集必须严格晚于被预测期（data 最新在前，故取 i+1 之后），
                # 否则会用到未来信息；少于 5 期时统计量不可靠，直接跳过该期
                train_data = self.data[i + 1:]
                if len(train_data) < 5:
                    continue
                # 使用轻量模式，仅计算基础统计，跳过TF/PyTorch/sklearn等重量级训练
                temp_predictor = PredictionAlgorithms(train_data, _light_mode=True)
                
                hc_pred = set(temp_predictor.hot_cold_algorithm(6))
                hc_hit = len(hc_pred & actual)
                algo_scores['hot_cold'] += hc_hit
                # 6 个预测号码中命中 2 个及以上视为“本期有效命中”，
                # 单命中受随机性影响大，不作为命中率样本
                if hc_hit >= 2:
                    algo_hit_counts['hot_cold'] += 1
                
                miss_pred = set(temp_predictor.missing_value_analysis(6))
                miss_hit = len(miss_pred & actual)
                algo_scores['missing'] += miss_hit
                if miss_hit >= 2:
                    algo_hit_counts['missing'] += 1
                
                range_pred = set(temp_predictor.range_distribution_algorithm(6))
                range_hit = len(range_pred & actual)
                algo_scores['range'] += range_hit
                if range_hit >= 2:
                    algo_hit_counts['range'] += 1
                
                tail_pred = set(temp_predictor.tail_distribution_algorithm(6))
                tail_hit = len(tail_pred & actual)
                algo_scores['tail'] += tail_hit
                if tail_hit >= 2:
                    algo_hit_counts['tail'] += 1
                
                oe_pred = set(temp_predictor.odd_even_algorithm(6))
                oe_hit = len(oe_pred & actual)
                algo_scores['odd_even'] += oe_hit
                if oe_hit >= 2:
                    algo_hit_counts['odd_even'] += 1
                
                bs_pred = set(temp_predictor.big_small_algorithm(6))
                bs_hit = len(bs_pred & actual)
                algo_scores['big_small'] += bs_hit
                if bs_hit >= 2:
                    algo_hit_counts['big_small'] += 1
                
                # 【修复0xC0000409】显式删除临时对象，防止GC延迟回收导致内存压力
                del temp_predictor
            except Exception:
                # 单个回测周期失败不影响整体权重计算
                continue
        
        total_score = sum(algo_scores.values()) or 1
        
        # 综合得分：基础得分 + 高命中率加权
        weighted_scores = {}
        for algo in algo_scores:
            base = algo_scores[algo] / total_score
            hit_rate = algo_hit_counts[algo] / max(test_periods, 1)
            # 高命中率算法权重放大
            # 0.8 为放大上限系数：命中率 100% 时该算法相对分最多放大 1.8 倍，
            # 避免少数回测期的偶然命中把权重推到极端
            weighted_scores[algo] = base * (1 + hit_rate * 0.8)
        
        total_weighted = sum(weighted_scores.values()) or 1
        
        # 6 个算法共享 0.55 的权重预算，剩下的 0.18(w_freq)+0.27(w_pattern)
        # 固定分给频率特征与模式识别，三者合计恒为 1.0
        weights = {
            'w_hot_cold': weighted_scores['hot_cold'] / total_weighted * 0.55,
            'w_missing': weighted_scores['missing'] / total_weighted * 0.55,
            'w_range': weighted_scores['range'] / total_weighted * 0.55,
            'w_tail': weighted_scores['tail'] / total_weighted * 0.55,
            'w_odd_even': weighted_scores['odd_even'] / total_weighted * 0.55,
            'w_big_small': weighted_scores['big_small'] / total_weighted * 0.55,
            # 设计说明：6个算法权重动态分配总预算55%（0.55），
            # w_freq(0.18)和w_pattern(0.27)固定占45%，
            # 总权重 = 0.55 + 0.18 + 0.27 = 1.0，始终归一化
            'w_freq': 0.18,
            'w_pattern': 0.27
        }
        return weights
    
    def _pattern_recognition_bonus(self):
        """近期模式识别加成 - v7.5增强版
        
        增加：尾数趋势、区间分布、连号分析、冷热周期

        功能：以 5.0 为基础分，对 1..49 每个号码按最近 8 期的奇偶/大小偏态与趋势、
        热尾数、热门区间、近期加权出现频率、连号相邻关系逐项加分，输出相对加成分。
        参数：无。
        返回：dict[int,float]: 键为 1..49，值为 5.0 以上的模式分（未归一化）。
        注意：无副作用（只读 self.data）；不足 5 期时返回全 5 分的默认值。
        数学含义:
            以 5.0 为基础分，按最近 8 期的奇偶/大小偏态与趋势、热尾数、
            热门区间、近期加权出现频率、连号相邻关系逐项加分，输出相对加成分。
        输入依赖:
            self.data[:8]（最新期在前）；不足 5 期时返回全 5 分。
        适用场景:
            comprehensive_recommendation 中的 w_pattern 项，用于捕捉短期形态。
        """
        bonus = {}
        if len(self.data) < 5:
            return {num: 5 for num in range(1, 50)}
        
        # 8 期窗口：兼顾趋势稳定性（期数太少趋势不可靠）与近期性（期数太多会平均掉形态）
        recent = self.data[:8]  # 增加分析周期到8期
        
        # 1. 奇偶趋势分析
        odd_counts = [sum(1 for n in r.get('numbers', []) if n % 2 == 1) for r in recent]
        avg_odd = sum(odd_counts) / len(odd_counts)
        odd_trend = odd_counts[0] - odd_counts[-1]  # 正=奇数增多趋势
        
        # 2. 大小趋势分析
        big_counts = [sum(1 for n in r.get('numbers', []) if n > 25) for r in recent]
        avg_big = sum(big_counts) / len(big_counts)
        big_trend = big_counts[0] - big_counts[-1]
        
        # 3. 尾数分布分析
        tail_counts = {i: 0 for i in range(10)}
        for r in recent:
            for n in r.get('numbers', []):
                tail_counts[n % 10] += 1
        # 取 3 个热尾数（10 个尾数中约 30%，可覆盖约 15 个号码，避免候选过度集中）
        hot_tails = sorted(tail_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        hot_tail_nums = [t[0] for t in hot_tails]
        
        # 4. 区间分布分析
        zone_counts = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
        for r in recent:
            for n in r.get('numbers', []):
                zone = (n - 1) // 10 + 1
                zone_counts[zone] += 1
        
        # 5. 近期出现频率
        recent_nums = {}
        for i, r in enumerate(recent):
            # 线性衰减：最新期权重 1.0，第 8 期约 0.44（i=7 时 1-0.56）
            weight = 1.0 - i * 0.08  # 越近期权重越高
            for n in r.get('numbers', []):
                recent_nums[n] = recent_nums.get(n, 0) + weight
        
        # 6. 连号模式识别
        # 每出现一对相邻号码累计 0.5，只看最近 3 期（更早的连号对下期参考价值低）
        # TODO(待确认): consecutive_bonus 计算后未参与下方任何 score 计算，属未使用变量
        consecutive_bonus = 0
        for r in recent[:3]:
            nums = sorted(r.get('numbers', []))
            for j in range(len(nums) - 1):
                if nums[j + 1] - nums[j] == 1:
                    consecutive_bonus += 0.5
        
        for num in range(1, 50):
            score = 5.0
            is_odd = num % 2 == 1
            is_big = num > 25
            tail = num % 10
            zone = (num - 1) // 10 + 1
            
            # 奇偶趋势加成
            # 阈值 3.2/2.8：每期开 6 个号码，长期期望 3 个奇数，±0.2 作为“明显偏态”的容忍带
            if is_odd and avg_odd > 3.2:
                score += 2.5
            elif not is_odd and avg_odd < 2.8:
                score += 2.5
            if is_odd and odd_trend > 0:
                score += 1.5
            elif not is_odd and odd_trend < 0:
                score += 1.5
            
            # 大小趋势加成
            # 大小以 25 为界（>25 为大），均值阈值同为 3.2/2.8
            if is_big and avg_big > 3.2:
                score += 2
            elif not is_big and avg_big < 2.8:
                score += 2
            if is_big and big_trend > 0:
                score += 1
            elif not is_big and big_trend < 0:
                score += 1
            
            # 热尾数加成：命中近 8 期出现最多的 3 个尾数之一个 +2
            if tail in hot_tail_nums:
                score += 2
            
            # 区间热度加成
            zone_rank = sorted(zone_counts.items(), key=lambda x: x[1], reverse=True)
            # rank < 2 只奖励出现最多的前 2 个区间（5 区间中约 40%）
            for rank, (z, cnt) in enumerate(zone_rank):
                if zone == z and rank < 2:
                    score += 1.5
                    break
            
            # 近期出现频率加成：recent_nums 已按 1.0~0.44 加权，再乘 1.2 放大
            if num in recent_nums:
                score += recent_nums[num] * 1.2
            
            # 连号相邻加成
            if num > 1 and (num - 1) in recent_nums:
                score += 0.8
            if num < 49 and (num + 1) in recent_nums:
                score += 0.8
            
            bonus[num] = score
        return bonus
    
    def _balance_selection(self, scores, count=6):
        """平衡选择：确保奇偶、大小分布合理
        【Bug修复】添加去重逻辑，防止候选列表中出现重复数字导致最终结果重复

        功能：先取得分最高的 count*3 个号码作为候选池，再分别取奇数前 3、偶数前 3，
        合并去重后不足 count 个则按分数依次补位，最终升序截取 count 个。
        参数：
            scores (dict[int,float]): 各号码的综合得分，键应覆盖 1..49。
            count (int): 需要选出的号码个数，默认 6。
        返回：list[int]: 升序排列，长度通常为 count。
        注意：无副作用（不修改入参 scores）；候选不足时从全量排序结果补位，
            极端情况下（如全奇数/全偶数）实际返回可能少于 count。
        数学含义:
            先取得分最高的 count*3 个号码作为候选池，再分别取奇数前 3、偶数前 3，
            合并去重后不足 count 个则按分数依次补位，最终升序截取 count 个。
        输入依赖:
            scores（dict[int,float]，键应覆盖 1..49）。
        适用场景:
            comprehensive_recommendation 的正向模式，避免 6 个号码全奇/全偶。
        """
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        # 候选池取 3 倍数量（count=6 时为 18 个），给奇偶各 3 个的组合留出余量
        candidates = sorted_nums[:count * 3]
        
        # 【Bug修复】去重：确保候选列表中每个数字唯一
        # 解决"算法预测一半数字是重复的"问题
        unique_candidates = []
        seen = set()
        for num, score in candidates:
            if num not in seen:
                seen.add(num)
                unique_candidates.append((num, score))
        candidates = unique_candidates
        
        # 各取前 3（经验值）：使 6 码大致呈 3:3，允许因去重/补位变成 4:2
        odd_top = [n for n, s in candidates if n % 2 == 1][:3]
        even_top = [n for n, s in candidates if n % 2 == 0][:3]
        
        temp_selected = list(set(odd_top + even_top))
        
        if len(temp_selected) < count:
            for n, s in candidates:
                if n not in temp_selected:
                    temp_selected.append(n)
                    if len(temp_selected) >= count:
                        break
        
        # 最终再次去重确保没有重复
        temp_selected = list(dict.fromkeys(temp_selected))
        # 【Bug修复】安全补位：当候选不足count个时（极端情况如全奇数/全偶数），
        # 从全量排序结果中按分数降序补充，确保始终返回count个有效数字
        if len(temp_selected) < count:
            for n, s in sorted_nums:
                if n not in temp_selected and 1 <= n <= 49:
                    temp_selected.append(n)
                    if len(temp_selected) >= count:
                        break
        return sorted(temp_selected[:count])
    
    # 预留：classic_result 形参保留给后续「参考经典结果的反向策略」，当前实现未使用
    def _reverse_selection(self, classic_result, count):
        """经典模式反向选择：选出最不可能的号码

        功能：以 100 为基准，用 freq*3 + missing*0.5 作为“可能出现度”从基准中扣除，
        得分越低表示越可能，反向取升序前 count 即为最不可能。
        参数：
            classic_result (list[int]): 经典模式的推荐结果；当前实现未使用。
            count (int): 需要选出的号码个数。
        返回：list[int]: 按反向分升序的前 count 个（非升序排列）；单个分值下限为 1。
        注意：无副作用（只读 self.frequency/self.missing）；
            TODO(待确认): 参数 classic_result 传入后未使用，反向分完全由频率/遗漏重算。
        数学含义:
            以 100 为基准，用 freq*3 + missing*0.5 作为“可能出现度”从基准中扣除，
            得分越低表示越可能，反向取升序前 count 即为最不可能。
        输入依赖:
            self.frequency（全量出现次数）与 self.missing（当前遗漏期数）。
        适用场景:
            enhanced=False 且 reverse=True 时的反向推荐。
        """
        scores = {}
        for num in range(1, 50):
            freq = self.frequency.get(num, 0)
            missing = self.missing.get(num, 0)
            # 低分特征：频率极低 + 遗漏期极短（刚出过）+ 极端分布
            # 3 与 0.5 为经验权重：一次出现约等于 6 期遗漏的影响（3 : 0.5 = 6 : 1）
            score = 100 - (freq * 3 + missing * 0.5)
            scores[num] = max(1, score)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=False)
        return [num for num, _ in sorted_nums[:count]]
    
    def _reverse_balance_selection(self, scores, count=6):
        """反向平衡选择 - v7.5增强版：选出最不可能出现的号码
        
        核心策略：利用彩票的统计规律，选择"最不可能开出"的号码组合
        1. 近期热号优先（刚出过的号码连续出现概率低）
        2. 长期热号次之（出现频率过高，有均值回归趋势）
        3. 故意制造极端分布（全奇/全偶/全大/全小，这类组合出现概率极低）
        4. 避开冷门遗漏号（遗漏期长的号码反而容易开出）

        功能：先对综合分做 min-max 反转得到 base_reverse（原分最高 40 分、最低 100 分），
        再叠加近期热度（最多 +25）、高于均值的长期频率（最多 +15）、
        遗漏长于均值（最多 -20），得到“越不可能越高”的反向分；
        最后在 Top count*5 池中枚举全奇/全偶/全大/全小四种极端组合，
        取反向总分最高的一组。
        参数：
            scores (dict[int,float]): 正向综合得分（键应覆盖 1..49）。
            count (int): 需要选出的号码个数，默认 6。
        返回：list[int]: 升序，长度 count；极端组合不足时回退到反向分 Top count。
        注意：无副作用（只读 self.data/self.frequency/self.missing）；
            候选池取 count*5，同侧候选不足 count 时对应极端组合被跳过。
        数学含义:
            先对综合分做 min-max 反转得到 base_reverse（原分最高 40 分、最低 100 分），
            再叠加近期热度（最多 +25）、高于均值的长期频率（最多 +15）、
            遗漏长于均值（最多 -20），得到“越不可能越高”的反向分；
            最后在 Top count*5 池中枚举全奇/全偶/全大/全小四种极端组合，
            取反向总分最高的一组。
        输入依赖:
            scores（正向综合得分）、self.data[:8]、self.frequency、self.missing。
        适用场景:
            comprehensive_recommendation 的 reverse=True 分支（追求高错误率）。
        """
        # 计算反向得分：越高表示越不可能出现
        reverse_scores = {}
        
        # 1. 基础反向分：原得分越低越不可能（从综合得分反转）
        max_score = max(scores.values()) if scores else 1
        min_score = min(scores.values()) if scores else 0
        score_range = max_score - min_score or 1
        
        for num in range(1, 50):
            # 反转：原得分越高，反向分越低（越可能出现→越不是我们要的）
            # 基准 100、反转幅度 60：原分最高者得 40 分，最低者得 100 分
            base_reverse = 100 - ((scores.get(num, 0) - min_score) / score_range) * 60
            reverse_scores[num] = base_reverse
        
        # 2. 近期热度加成：越近期出现过，越不可能连续出现
        if len(self.data) >= 3:
            recent_nums_weight = {}
            for i in range(min(8, len(self.data))):
                # 线性衰减：最新期 1.0，第 8 期 0.3（比 _pattern_recognition_bonus 衰减更快）
                weight = 1.0 - i * 0.1  # 越近期权重越高
                for n in self.data[i].get('numbers', []):
                    recent_nums_weight[n] = recent_nums_weight.get(n, 0) + weight
            
            max_recent = max(recent_nums_weight.values()) if recent_nums_weight else 1
            for num in range(1, 50):
                if num in recent_nums_weight:
                    # 近期热号加分（越不可能出现加越多）
                    # 归一化后乘 25：最热的号码最多 +25，低于 60 分反转幅度的量级
                    bonus = (recent_nums_weight[num] / max_recent) * 25
                    reverse_scores[num] = reverse_scores.get(num, 50) + bonus
        
        # 3. 历史频率加成：出现频率太高的号码，可能进入冷周期
        if hasattr(self, 'frequency') and self.frequency:
            freqs = list(self.frequency.values())
            avg_freq = sum(freqs) / len(freqs) if freqs else 0
            max_freq = max(freqs) if freqs else 1
            
            for num in range(1, 50):
                freq = self.frequency.get(num, 0)
                if freq > avg_freq:
                    # 高于平均频率的，增加反向分（越热越可能冷下来）
                    # 相对高出比例归一化后乘 15；max(1, ...) 防止分母为 0 或负
                    bonus = ((freq - avg_freq) / max(1, max_freq - avg_freq)) * 15
                    reverse_scores[num] = reverse_scores.get(num, 50) + bonus
        
        # 4. 遗漏期数惩罚：遗漏期太长的号码反而容易开出，所以要减分
        if hasattr(self, 'missing') and self.missing:
            missing_values = list(self.missing.values())
            avg_missing = sum(missing_values) / len(missing_values) if missing_values else 0
            
            for num in range(1, 50):
                missing = self.missing.get(num, 0)
                if missing > avg_missing:
                    # 遗漏期太长，反而容易开出（冷号要出了），减分
                    # 每超出均值 1 期扣 0.5，单号码最多扣 20 分
                    penalty = min(20, (missing - avg_missing) * 0.5)
                    reverse_scores[num] = reverse_scores.get(num, 50) - penalty
        
        # 按反向得分排序（分越高越不可能出现）
        sorted_by_reverse = sorted(reverse_scores.items(), key=lambda x: x[1], reverse=True)
        # 候选池取 5 倍（count=6 时 30 个）：极端组合需要同侧至少 6 个候选，
        # 池子过小会导致四种极端组合全部不可行
        candidates = [n for n, s in sorted_by_reverse[:count * 5]]  # 扩大候选池
        
        # 5. 构造极端分布组合（提高错误率的关键）
        selected = []
        
        # 策略A：尝试极端奇偶分布（全奇或全偶，出现概率仅约1.5%）
        # 该概率为经验估值，不是本次数据计算所得，仅用于说明“极端组合更不可能”
        odd_candidates = [n for n in candidates if n % 2 == 1][:count]
        even_candidates = [n for n in candidates if n % 2 == 0][:count]
        
        # 策略B：尝试极端大小分布（全大或全小）
        big_candidates = [n for n in candidates if n > 25][:count]
        small_candidates = [n for n in candidates if n <= 25][:count]
        
        # 选择反向得分总和最高的极端组合
        def calc_total_score(nums):
            """功能：计算总分

            对传入号码序列累加其在 reverse_scores 中的反向得分，用于比较四种极端组合。
            参数：
                nums (Iterable[int]): 号码序列。
            返回：float: 这些号码反向得分之和；字典中缺失的号码按 0 计。
            注意：无副作用。
            """
            return sum(reverse_scores.get(n, 0) for n in nums)
        
        options = []
        if len(odd_candidates) >= count:
            options.append(('全奇', odd_candidates[:count]))
        if len(even_candidates) >= count:
            options.append(('全偶', even_candidates[:count]))
        if len(big_candidates) >= count:
            options.append(('全大', big_candidates[:count]))
        if len(small_candidates) >= count:
            options.append(('全小', small_candidates[:count]))
        
        if options:
            # 选反向得分最高的极端组合
            best_option = max(options, key=lambda x: calc_total_score(x[1]))
            selected = best_option[1]
        else:
            # 极端组合不可行时，选反向得分最高的号码
            selected = [n for n, s in sorted_by_reverse[:count]]
        
        return sorted(selected)
    
    def _odd_even_score(self, num):
        """单双得分

        功能：只奖励“与当前奇偶偏态相反”的一侧：score = max(0, |odd_ratio - 0.5| * 20 + 5)；
        odd_ratio = 0.5 时两侧各 5 分，偏态越大弱势一侧得分越高（上限 15）。
        参数：
            num (int): 号码（1..49），按 num % 2 == 1 判为奇数。
        返回：float: 0~15 的奇偶平衡得分。
        注意：无副作用（只读 self.odd_even_ratio）；属性缺失时按 0.5 处理。
        数学含义:
            只奖励“与当前奇偶偏态相反”的一侧：
            score = max(0, |odd_ratio - 0.5| * 20 + 5)。
            odd_ratio = 0.5 时两侧各 5 分；偏态越大，弱势一侧得分越高（上限 15）。
        输入依赖:
            self.odd_even_ratio（奇号占比，缺失时按 0.5 处理）。
        适用场景:
            综合打分中的奇偶平衡项（w_odd_even）。
        """
        is_odd = num % 2 == 1
        odd_ratio = self.odd_even_ratio if hasattr(self, 'odd_even_ratio') else 0.5
        # 20 为放大系数、5 为基准分：odd_ratio 偏离 0.5 每 0.1，弱势侧多得 2 分
        if is_odd:
            return max(0, (0.5 - odd_ratio) * 20 + 5)
        else:
            return max(0, (odd_ratio - 0.5) * 20 + 5)
    
    def _big_small_score(self, num):
        """大小得分

        功能：与单双得分同构：score = max(0, |big_ratio - 0.5| * 20 + 5)，
        奖励当前偏态中较少出现的一侧，大号定义为 >25。
        参数：
            num (int): 号码（1..49），按 num > 25 判为大号。
        返回：float: 0~15 的大小平衡得分。
        注意：无副作用（只读 self.big_small_ratio）；属性缺失时按 0.5 处理。
        数学含义:
            与单双得分同构：score = max(0, |big_ratio - 0.5| * 20 + 5)，
            奖励当前偏态中较少出现的一侧。
        输入依赖:
            self.big_small_ratio（大号占比，缺失时按 0.5 处理）；大号定义为 >25。
        适用场景:
            综合打分中的大小平衡项（w_big_small）。
        """
        is_big = num > 25
        big_ratio = self.big_small_ratio if hasattr(self, 'big_small_ratio') else 0.5
        # 系数 20 / 基准 5 与 _odd_even_score 保持一致，便于两项相加比较
        if is_big:
            return max(0, (0.5 - big_ratio) * 20 + 5)
        else:
            return max(0, (big_ratio - 0.5) * 20 + 5)
    
    def _np_regression_bonus(self):
        """NumPy 逐号码时间回归加成（预测“下一期”遗漏）

        功能：对每个号码 n，用其自身遗漏序列的时间回归外推出下一期遗漏 p_n，
        并换算为 bonus_n = max(0, 10 - max(0, p_n) * 0.5)；
        预测下一期遗漏越短，说明模型认为该号码越可能很快回补，加成越高，
        p_n >= 20 时加成为 0（不做负惩罚）。
        参数：无。
        返回：dict[int,float]: 键 1..49，值 0~10；模型缺失时返回 {}。
        注意：无副作用（只读）；异常被捕获并返回已计算的部分；
            逐号码预测缺失时按当前遗漏兜底。
        数学口径（时间方向 旧 → 新）:
            对每个号码 n，用其自身遗漏序列的时间回归外推出的下一期遗漏 p_n
            （由 _np_linear_regression_trend 写入 np_predicted_missing_by_num），
            计算 bonus_n = max(0, 10 - max(0, p_n) * 0.5)：
            预测下一期遗漏越短，说明模型认为该号码越可能很快回补，加成越高；
            p_n >= 20 时加成为 0（不做负惩罚）。每个号码一条回归线，加成逐号码不同。
        输入依赖:
            self.np_features（存在才计算）、self.np_predicted_missing_by_num、
            self.missing（逐号码预测缺失时按当前遗漏兜底）。
        适用场景:
            综合推荐中的 NumPy 模型加成项（乘数 40，与旧版量级一致）。
        """
        bonus = {}
        if not hasattr(self, 'np_features') or self.np_features is None:
            return bonus
        try:
            preds = getattr(self, 'np_predicted_missing_by_num', {}) or {}
            for num in range(1, 50):
                # 逐号码下一期遗漏预测；缺失时用当前遗漏兜底，仍保持逐号码差异
                predicted_next = float(preds.get(num, self.missing.get(num, 50)))
                # 0.5 为衰减系数：预测下一期遗漏每 1 期扣 0.5 分，>=20 期归零
                bonus[num] = max(0.0, 10.0 - max(0.0, predicted_next) * 0.5)
        except Exception:
            pass
        return bonus
    
    def _scipy_interp_bonus(self):
        """SciPy interpolate 时间口径插值加成（预测“下一期”遗漏）

        功能：对每个号码 n（1..49）取它自己的逐期「当前遗漏」序列，以期为自变量
        做三次样条外推得到下一期遗漏估值 p_n，再按
        bonus_n = max(0, 10 - |当前遗漏 - p_n| * 0.5) 转成加成。
        参数：无。
        返回：dict[int,float]: 键 1..49，值 0~10；无插值函数时返回 {}。
        注意：无副作用（只读；样条结果按 _data_signature() 缓存复用）；
            SciPy 不可用或数据不足（外推结果为空）时退回横截面插值
            self.scipy_interp_func(num)，行为与改动前一致；
            异常被捕获并返回已计算的部分。
        数学口径（时间方向 旧 → 新，与 interp_missing / sklearn 前缀特征 /
        逐号码时间回归同源）:
            对每个号码 n（1..49）取它自己的逐期「当前遗漏」序列，
            用 _predict_next_missing_by_spline 以期为自变量做三次样条外推，
            得到该号码「下一期」遗漏估值 p_n（已按可行性剪到 [0, 当前遗漏+1]）。
            再由原逻辑转成加成：bonus_n = max(0, 10 - |当前遗漏 - p_n| * 0.5)。
            49 个号码各一条序列，加成逐号码不同；衰减系数 0.5 与归一化区间 0~10
            与改动前完全一致，不引入任何随机性。
        降级:
            SciPy 不可用或数据不足（外推结果为空）时退回原横截面插值公式
            （self.scipy_interp_func(num)），保证行为与改动前一致；
            完整模式下 SciPy 缺失时 scipy_interp_func 为 None，仍返回 {}。
        输入依赖:
            self.data、self.missing、self.scipy_interp_func（仅作可用性门控与降级）。
        适用场景:
            综合推荐（增强 / 经典两条路径）中的 SciPy 模型加成项（乘数 25 / 30）。
        """
        bonus = {}
        if not hasattr(self, 'scipy_interp_func') or not self.scipy_interp_func:
            return bonus
        try:
            # 与 interp_missing 同源的时间口径：49 个号码各自逐期样例外推
            scipy_int = _get_scipy_interpolate()
            preds = {}
            if scipy_int is not None:
                preds = self._predict_next_missing_by_spline(
                    getattr(scipy_int, 'splrep', None),
                    getattr(scipy_int, 'splev', None),
                )
            if preds:
                for num in range(1, 50):
                    # 下一期遗漏估值；个别号码缺失时按当前遗漏兜底
                    predicted_next = float(preds.get(num, self.missing.get(num, 50)))
                    # 与改动前的量纲保持一致：预测偏差 1 期扣 0.5 分，偏差 >=20 期归零
                    diff = abs(self.missing.get(num, 50) - predicted_next)
                    bonus[num] = max(0, 10 - diff * 0.5)
            else:
                # 降级：SciPy 缺失 / 数据不足时保留原横截面插值结果，行为不变
                for num in range(1, 50):
                    interp_val = self.scipy_interp_func(num)
                    miss = self.missing.get(num, 50)
                    diff = abs(miss - interp_val)
                    bonus[num] = max(0, 10 - diff * 0.5)
        except Exception:
            pass
        return bonus
    
    def _gb_predict_probs(self):
        """GradientBoostingClassifier 预测每个数字出现概率

        功能：把“某号码是否出现”拆成 49 个独立的二分类任务，
        特征为 _build_sklearn_feature_vector(label_idx+1)（只用标签期及更旧历史），
        标签为第 label_idx 期的 0/1 向量（label_idx 越小越新，标签严格晚于特征窗口）；
        每个号码训练一个 GBC(50 棵树, 深度 3, seed 42)，再对第 0 期（全部历史）
        的推理特征输出“下一期出现”的 P(出现)。
        参数：无。
        返回：dict[int,float]: 键 1..49，值 0~1；条件不足或异常时返回 {}。
        注意：- 训练 49 个 GBDT，耗时明显，且每 10 个模型调用 gc.collect()；
            - 轻量模式直接返回 {}；不修改 self。
        数学含义:
            把“某号码是否出现”拆成 49 个独立的二分类任务；
            特征为 _build_sklearn_feature_vector(label_idx+1)（只用标签期及更旧历史），
            标签为第 label_idx 期的 0/1 向量（label_idx 越小越新，标签严格晚于特征窗口）；
            每个号码训练一个 GBC(50 棵树, 深度 3, seed 42)，再对第 0 期（全部历史）
            的推理特征输出“下一期出现”的 P(出现)。
        输入依赖:
            self.data（>=20 期）、self.sklearn_features。
        适用场景:
            综合推荐/经典推荐的 GBDT 概率加成（乘数 120 / 150）。
        """
        # 【修复0xC0000409】轻量模式下跳过sklearn模型训练
        if getattr(self, '_is_light_mode', False):
            return {}
        _get_sklearn()
        GBC = _core._GradientBoostingClassifier
        if len(self.data) < 20 or not hasattr(self, 'sklearn_features') or self.sklearn_features is None or GBC is None:
            return {}
        try:
            # 构建训练数据：用“第 label_idx+1 期及更旧历史”的特征 -> 预测第 label_idx 期出现
            # self.data[0] 最新，label_idx 越小标签越新；特征索引 label_idx+1 严格早于
            # 标签 data[label_idx]，窗口与标签不重叠、无未来泄漏。
            X, y = [], []
            for label_idx in range(len(self.data) - 1):
                features = self._build_sklearn_feature_vector(label_idx + 1)
                X.append(features)
                next_nums = self.data[label_idx].get('numbers', [])
                y_single = [1 if n in next_nums else 0 for n in range(1, 50)]
                y.append(y_single)
            # 少于 10 个样本时交叉特征无法支撑 49 个模型，直接放弃
            if len(X) < 10:
                return {}
            X, y = np.array(X), np.array(y)
            # 推理样本：第 0 期（全部历史）的特征，用于预测尚未发生的下一期
            X_latest = np.array([self._build_sklearn_feature_vector(0)])
            # 对每个数字训练一个分类器
            probs = {}
            import gc as _gc  # 作用说明：每训练 10 个 GBDT 手动触发一次垃圾回收，缓解 C 层内存/栈累积
            for n in range(1, 50):
                y_col = y[:, n-1]
                # 【修复0xC0000409】跳过单类目标，避免模型训练异常
                if len(set(y_col)) < 2:
                    # 单类标签无法训练分类器，用 0.02 先验兜底（与调用方的缺省值一致）
                    probs[n] = 0.02
                    continue
                # 【修复】GradientBoostingClassifier不支持n_jobs参数
                # 50 棵树 / 深度 3 为轻量配置：49 个模型串行训练，树太多会显著拖慢整体
                model = GBC(n_estimators=50, max_depth=3, random_state=42)
                model.fit(X, y_col)
                # 只取推理样本（第 0 期=全部历史，预测下一期）的第 1 类概率；类别数不足时用先验
                proba = model.predict_proba(X_latest)[0][1] if len(model.classes_) > 1 else 0.02
                probs[n] = proba
                del model
                # 每10个模型清理一次C级内存，防止堆栈累积
                if n % 10 == 0:
                    _gc.collect()
            return probs
        except Exception:
            return {}
    
    def hot_cold_algorithm(self, count=6):
        """冷热数字 - TensorFlow热号分类 + sklearn KMeans + NumPy直方图 + PyTorch平滑

        功能：score = 8*近期指数衰减频率 + 正 Z-score 加成 + (MA5-MA20) 动量
            + 自相关系数 + KMeans 簇热度 + NumPy 分位档位
            + TF/PyTorch/SciPy 加成，取 Top count。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 按得分降序的前 count 个（未升序）；空数据时为随机列表。
        注意：- 空数据时调用 random.sample，受全局随机状态影响；
            - 各模型加成函数仅读属性，不训练模型。
        数学含义:
            score = 8*近期指数衰减频率 + 正 Z-score 加成 + (MA5-MA20) 动量
                + 自相关系数 + KMeans 簇热度 + NumPy 分位档位
                + TF/PyTorch/SciPy 加成，取 Top count。
        输入依赖:
            self.data[:10]、missing、interval_stats、moving_avg、autocorrelation、
            kmeans_labels、np_histogram、tf_predictions、pt_lstm_preds、scipy_smoothed。
        适用场景:
            押注“近期热号延续”；数据为空时退化为随机选号。
        """
        if not self.data:
            return random.sample(range(1, 50), count)
        
        # sklearn: KMeans聚类分组（热/温/冷）
        cluster_bonus = {}
        if hasattr(self, 'kmeans_labels') and self.kmeans_labels is not None:
            for num in range(1, 50):
                cluster_id = self.kmeans_labels[num - 1]
                # 簇编号 0/1/2 对应冷/温/热，乘 10 后形成 0/10/20 的档位差
                cluster_bonus[num] = cluster_id * 10
        
        # NumPy直方图分析：热号分布
        np_hist_bonus = self._np_hot_histogram_bonus() if hasattr(self, 'np_histogram') else {}
        
        # TensorFlow热号分类预测
        tf_hot_probs = self._tf_hot_classifier() if hasattr(self, 'tf_predictions') and self.tf_predictions else {}
        
        # PyTorch神经网络平滑特征
        pt_smooth_bonus = self._pt_hot_smooth() if hasattr(self, 'pt_lstm_preds') and self.pt_lstm_preds else {}
        
        # SciPy卷积平滑趋势
        scipy_smooth_bonus = self._scipy_hot_smooth() if hasattr(self, 'scipy_smoothed') and self.scipy_smoothed is not None else {}
        
        scores = {}
        for num in range(1, 50):
            # 指数加权频率（NumPy exp计算）
            # 只看最近 10 期；exp(-i/5) 使权重每 5 期衰减到 1/e（半衰期约 3.5 期）
            decay_weight = 0
            for i, record in enumerate(self.data[:10]):
                weight = np.exp(-i / 5)
                if num in record.get('numbers', []):
                    decay_weight += weight
            
            # 遗漏Z-score异常检测
            miss = self.missing.get(num, 50)
            stats = self.interval_stats.get(num, {})
            zscore = stats.get('zscore', 0)
            # 只取正 Z-score：遗漏高于历史均值才有“回补”意义；乘 5 与档位加成同量级
            zscore_bonus = max(0, zscore) * 5
            
            # 趋势动量（MA5 vs MA20）
            ma5 = self.moving_avg.get(num, {}).get(5, 0.1)
            ma20 = self.moving_avg.get(num, {}).get(20, 0.1)
            # 短期均线高于长期均线即为正向动量；乘 50 把 0~1 的占比差放大到分数量级
            momentum = (ma5 - ma20) * 50
            
            # 自相关性加成
            # 自相关取值约 -1~1，乘 10 得到 -10~10 的加减分
            autocorr = self.autocorrelation.get(num, 0) * 10
            
            # KMeans聚类热度加成
            kmeans_bonus = cluster_bonus.get(num, 0)
            
            # NumPy直方图热号加成
            np_bonus = np_hist_bonus.get(num, 0)
            
            # TensorFlow热号概率加成
            # TF/PyTorch 概率乘数（100/80）把 0~1 概率映射到分数；SciPy 已归一化到 0~1，再乘 10
            tf_bonus = tf_hot_probs.get(num, 0.02) * 100
            
            # PyTorch平滑加成
            pt_bonus = pt_smooth_bonus.get(num, 0.02) * 80
            
            # SciPy平滑加成
            scipy_bonus = scipy_smooth_bonus.get(num, 0) * 10
            
            # 综合得分
            # 衰减频率乘 8：最近一期命中约 8 分，5 期前命中约 2.9 分
            scores[num] = (decay_weight * 8 + zscore_bonus + momentum + autocorr + kmeans_bonus +
                          np_bonus + tf_bonus + pt_bonus + scipy_bonus)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _np_hot_histogram_bonus(self):
        """NumPy 直方图分析热号分布

        功能：以当前遗漏值的 25/50/75 分位数为阈值，把 49 个号码分为
        极热(+20)/温热(+10)/温冷(0)/极冷(-10) 四档（分位数越低越热）。
        参数：无。
        返回：dict[int,int]: 键 1..49，值 -10~20；模型缺失/异常时返回 {}。
        注意：无副作用；异常被捕获并返回已累积结果（初始为空）。
        数学含义:
            以当前遗漏值的 25/50/75 分位数为阈值，把 49 个号码分为
            极热(+20)/温热(+10)/温冷(0)/极冷(-10) 四档（分位数越低越热）。
        输入依赖:
            self.np_histogram（存在才计算）、self.missing（缺失按 50 兜底）。
        适用场景:
            hot_cold_algorithm 的 NumPy 档位加成。
        """
        bonus = {}
        if not hasattr(self, 'np_histogram') or self.np_histogram is None:
            return bonus
        try:
            miss_arr = np.array([self.missing.get(i, 50) for i in range(1, 50)], dtype=np.float32)
            # 用分位数而非固定阈值，保证档位按当前数据分布自适应
            percentiles = np.percentile(miss_arr, [25, 50, 75])
            for num in range(1, 50):
                miss = self.missing.get(num, 50)
                if miss < percentiles[0]:
                    bonus[num] = 20  # 极热
                elif miss < percentiles[1]:
                    bonus[num] = 10  # 温热
                elif miss < percentiles[2]:
                    bonus[num] = 0   # 温冷
                else:
                    bonus[num] = -10  # 极冷
        except Exception:
            pass
        return bonus
    
    def _tf_hot_classifier(self):
        """TensorFlow 热号分类预测

        功能：以遗漏值的 30 分位数为阈值：遗漏低于阈值（偏热）的号码概率乘 1.3，
        其余乘 0.8，用遗漏长短修正 TF 原始概率。
        参数：无。
        返回：dict[int,float]: 键 1..49；无 tf_predictions 时返回 {}。
        注意：无副作用（只读 self.tf_predictions/self.missing）。
        数学含义:
            以遗漏值的 30 分位数为阈值：遗漏低于阈值（偏热）的号码概率乘 1.3，
            其余乘 0.8，用遗漏长短修正 TF 原始概率。
        输入依赖:
            self.tf_predictions、self.missing。
        适用场景:
            hot_cold_algorithm 的 TF 加成项。
        """
        if not hasattr(self, 'tf_predictions') or not self.tf_predictions:
            return {}
        probs = {}
        miss_arr = np.array([self.missing.get(i, 50) for i in range(1, 50)])
        # 30 分位为经验阈值：约 15 个号码视为“热号”，与 6 个推荐位的候选池量级匹配
        threshold = np.percentile(miss_arr, 30)
        for num in range(1, 50):
            miss = self.missing.get(num, 50)
            base_prob = self.tf_predictions.get(num, 0.02)
            # 1.3 / 0.8：热号增强 30%，冷号衰减 20%，避免修正幅度过大盖过模型本身
            if miss < threshold:
                probs[num] = base_prob * 1.3
            else:
                probs[num] = base_prob * 0.8
        return probs
    
    def _pt_hot_smooth(self):
        """PyTorch LSTM 平滑热号概率

        功能：直接复用 LSTM 输出的每号码概率，不做额外平滑运算。
        参数：无。
        返回：dict[int,float]: pt_lstm_preds 的浅拷贝；无模型时 {}。
        注意：返回副本，调用方修改结果不会污染 self.pt_lstm_preds。
        """
        if not hasattr(self, 'pt_lstm_preds') or not self.pt_lstm_preds:
            return {}
        return self.pt_lstm_preds.copy()
    
    def _scipy_hot_smooth(self):
        """SciPy signal.convolve 平滑热号趋势

        功能：对长度为 49 的平滑序列做 min-max 归一化（映射到 0~1），再乘 10 作为加成，
        归一化消除了原序列的量级差异。
        参数：无。
        返回：dict[int,float]: 键 1..49，值 0~10；序列长度不为 49 时返回 {}。
        注意：无副作用；异常被捕获并返回已累积结果。
        数学含义:
            对长度为 49 的平滑序列做 min-max 归一化（映射到 0~1），再乘 10 作为加成，
            归一化消除了原序列的量级差异。
        输入依赖:
            self.scipy_smoothed（卷积平滑后的数组，约定长度 49、下标 0..48 对应号码 1..49）。
        适用场景:
            hot_cold_algorithm 的 SciPy 趋势加成。
        """
        bonus = {}
        if not hasattr(self, 'scipy_smoothed') or self.scipy_smoothed is None:
            return bonus
        try:
            smoothed = self.scipy_smoothed
            # 长度必须与 49 个号码一一对应，否则索引映射会错位，直接跳过
            if len(smoothed) == 49:
                max_val = np.max(smoothed)
                min_val = np.min(smoothed)
                # 全平序列时 range 为 0，用 1 兜底避免除零
                range_val = max_val - min_val if max_val > min_val else 1
                for i in range(49):
                    norm_val = (smoothed[i] - min_val) / range_val
                    # 下标 i 对应号码 i+1
                    bonus[i + 1] = norm_val * 10
        except Exception:
            pass
        return bonus
    
    def odd_even_algorithm(self, count=6):
        """单双算法 - TensorFlow预测 + sklearn LogisticRegression + NumPy矩阵 + SciPy KS检验

        功能：先估计下期的奇数个数 predicted_odds：
        LR（用上期奇数个数预测下期）0.35 + 马尔可夫转移 0.35 + TF 期望 0.2
        + KS 修正 0.1，再与长期均值 3.0 按 0.6/0.4 做均值回归，并裁剪到 [2,4]；
        随后从奇/偶候选中各按 _get_weighted_score 取相应个数。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 顺序为“先奇后偶”；长度 ≤ count（某侧候选耗尽时会少号）。
        注意：- _get_sklearn() 触发 sklearn 懒加载；
            - 训练 LogisticRegression（非轻量模式）；
            - 空数据时 random.sample，受全局随机状态影响；
            - 各模型异常均被内部捕获。
        数学含义:
            先估计下期的奇数个数 predicted_odds：
            LR（用上期奇数个数预测下期）0.35 + 马尔可夫转移 0.35 + TF 期望 0.2
            + KS 修正 0.1，再与长期均值 3.0 按 0.6/0.4 做均值回归，并裁剪到 [2,4]；
            随后从奇/偶候选中各按 _get_weighted_score 取相应个数。
        输入依赖:
            self.data[:20] 每期奇数个数、tf_predictions、ks_test_result、
            _get_weighted_score；LR 仅在非轻量模式且样本 >=10 时训练。
        适用场景:
            近期奇偶比明显偏态时，调整下一期的奇数配额。
        """
        _get_sklearn()
        if not self.data:
            return random.sample(range(1, 50), count)
        
        # NumPy计算历史单数序列统计量
        # 取最近 20 期，按时间倒序（odd_seq[0] 为最新一期），后续马尔可夫链依赖此方向
        odd_seq = []
        for record in self.data[:20]:
            odds = sum(1 for n in record.get('numbers', []) if LotteryConfig.is_odd(n))
            odd_seq.append(odds)
        
        # NumPy np.corrcoef计算奇偶序列自相关性
        odd_np_corr = 0
        if len(odd_seq) >= 5:
            try:
                odd_np_corr = float(np.corrcoef(odd_seq[:-1], odd_seq[1:])[0, 1])
            except Exception:
                odd_np_corr = 0
        # TODO(待确认): odd_np_corr 计算后未参与后续任何融合，属未使用变量
        
        # sklearn: LogisticRegression预测下期单数个数概率分布
        lr_predicted_odds = 3
        # 【修复0xC0000409】轻量模式下跳过sklearn模型训练
        if not getattr(self, '_is_light_mode', False):
            LR = _core._LogisticRegression
            SS = _core._StandardScaler
            if LR is not None and SS is not None and len(odd_seq) >= 10:
                try:
                    # odd_seq 为「最新在前」，直接取 [:-1]/[1:] 会得到“较新 -> 较旧”的反向样本，
                    # 且 odd_seq[-1] 是最旧一期；这里先反转为“旧 -> 新”再训练，预测输入取最新一期
                    odd_chrono = odd_seq[::-1]
                    X_lr = np.array(odd_chrono[:-1]).reshape(-1, 1)
                    y_lr = np.array(odd_chrono[1:])
                    scaler_lr = SS()
                    X_lr_scaled = scaler_lr.fit_transform(X_lr)
                    # 【修复0xC0000409】设置n_jobs=1禁用OpenMP并行，防止C栈溢出
                    lr_model = LR(max_iter=100, random_state=42, n_jobs=1)
                    lr_model.fit(X_lr_scaled, y_lr)
                    X_next = scaler_lr.transform([[odd_chrono[-1]]])
                    lr_proba = lr_model.predict_proba(X_next)[0]
                    lr_predicted_odds = lr_model.predict(X_next)[0]
                    # 用“概率 * 列下标”求期望；TODO(待确认): 列下标是类别在 classes_ 中的位置，
                    # 并非奇数个数本身，若训练集中缺少某些类别（如 0 或 6），期望值会偏移
                    lr_predicted_odds = int(np.sum(lr_proba * np.arange(len(lr_proba))))
                except Exception:
                    lr_predicted_odds = 3
        elif len(odd_seq) >= 10:
            lr_predicted_odds = 3
        
        # TensorFlow神经网络预测单双分布
        tf_odds = self._tf_odd_even_predict(odd_seq) if len(odd_seq) >= 10 else 3
        
        # SciPy ks_2samp分布检验修正
        # 返回 2~4 的整数，作为“分布一致性”的先验修正项参与 0.1 权重的融合
        ks_correction = self._scipy_odd_correction() if hasattr(self, 'ks_test_result') else 0
        
        # 构建马尔可夫链状态转移矩阵
        # odd_seq[0] 是最新一期，历史转移应记录“较旧状态 -> 较新状态”，
        # 即 transition[odd_seq[i+1]][odd_seq[i]]，才能用于预测下一期
        transition = defaultdict(lambda: defaultdict(int))
        for i in range(len(odd_seq) - 1):
            transition[odd_seq[i+1]][odd_seq[i]] += 1
        
        # 预测下期单数（融合多模型）
        if odd_seq:
            last_odd = odd_seq[0]
            next_odds_probs = transition[last_odd]
            if next_odds_probs:
                markov_pred = max(next_odds_probs.items(), key=lambda x: x[1])[0]
            else:
                # 回退：最近 5 期（odd_seq 前 5 项）
                markov_pred = int(np.mean(odd_seq[:5]))
        else:
            markov_pred = 3
        
        # 多模型融合预测
        # 权重 0.35/0.35/0.2/0.1：LR 与马尔可夫为主，TF 次之，KS 修正仅作微调
        predicted_odds = int(round(lr_predicted_odds * 0.35 + markov_pred * 0.35 + tf_odds * 0.2 + ks_correction * 0.1))
        
        # 均值回归修正
        # 6 个号码的长期奇数期望为 3.0，按 0.6/0.4 向均值收缩，抑制单模型的极端预测
        expected_odds = 3.0
        predicted_odds = int(round(predicted_odds * 0.6 + expected_odds * 0.4))
        # 裁剪到 [2,4]：6 码中奇数 0/1 或 5/6 个属于极端形态，历史占比很低
        predicted_odds = max(2, min(4, predicted_odds))
        
        # 按特征得分选号
        selected = []
        odd_candidates = sorted([n for n in range(1, 50) if LotteryConfig.is_odd(n)], 
                                key=lambda x: self._get_weighted_score(x), reverse=True)
        even_candidates = sorted([n for n in range(1, 50) if LotteryConfig.is_even(n)], 
                                 key=lambda x: self._get_weighted_score(x), reverse=True)
        
        for _ in range(predicted_odds):
            if odd_candidates:
                selected.append(odd_candidates.pop(0))
        for _ in range(count - predicted_odds):
            if even_candidates:
                selected.append(even_candidates.pop(0))
        
        return selected[:count]
    
    def _tf_odd_even_predict(self, odd_seq):
        """TensorFlow 神经网络预测单双分布

        功能：对 25 个奇数号码的 tf_predictions 取均值，再乘 25 换算成
        “下期奇数个数期望”，结果裁剪到 [2,4]。
        参数：
            odd_seq (list[int]): 最近各期奇数个数序列；本函数仅用其长度做 >=10 的门控。
        返回：int: 范围 2~4；条件不满足或异常时返回默认 3。
        注意：无副作用（只读 self.tf_predictions）；异常被捕获并回退默认值 3。
        数学含义:
            对 25 个奇数号码的 tf_predictions 取均值，再乘 25 换算成“下期奇数个数期望”，
            结果裁剪到 [2,4]。
        输入依赖:
            odd_seq（长度 >=10 才启用）、self.tf_predictions。
        适用场景:
            odd_even_algorithm 中的 TF 融合项（权重 0.2）。
        """
        if len(odd_seq) < 10 or not hasattr(self, 'tf_predictions') or not self.tf_predictions:
            return 3
        try:
            # 基于tf_predictions计算预期单数个数
            odd_probs = [self.tf_predictions.get(n, 0.02) for n in range(1, 50) if n % 2 == 1]
            # 25 为奇数号码总个数；该换算假设各号码概率可加且互不排斥（实际 tf 概率未必归一）
            expected_odds = sum(odd_probs) / len(odd_probs) * 25 if odd_probs else 3
            return max(2, min(4, int(round(expected_odds))))
        except Exception:
            return 3
    
    def _scipy_odd_correction(self):
        """SciPy ks_2samp 分布检验修正预测

        功能：correction = round(2*p + 4*(1-p)) = 4 - 2p，
        p in [0,1] 时映射到 [2,4]；p 越大（两分布越一致）越接近 2，p 越小越接近 4。
        参数：无。
        返回：int: 范围 2~4；无 ks_test_result 时返回默认 3。
        注意：无副作用（只读 self.ks_test_result）；属性缺失时回退 3。
        数学含义:
            correction = round(2*p + 4*(1-p)) = 4 - 2p，p in [0,1] 时映射到 [2,4]；
            p 越大（两分布越一致）越接近 2，p 越小越接近 4。
        输入依赖:
            self.ks_test_result（KS 检验 p 值，缺失时按 0.5）。
        适用场景:
            odd_even_algorithm 融合中的 KS 修正项（权重 0.1）。
        """
        if not hasattr(self, 'ks_test_result'):
            return 3
        # p值越高分布越一致，预测值越接近均值；p值越低越偏离均值
        pval = getattr(self, 'ks_test_result', 0.5)
        return int(round(2.0 * pval + 4 * (1 - pval)))
    
    def big_small_algorithm(self, count=6):
        """大小算法 - TensorFlow预测 + sklearn RF + NumPy lstsq + SciPy插值

        功能：用 4 个模型估计下期大数（>25）个数：
        NumPy lstsq 线性外推 0.25 + RF 0.3 + TF 0.3 + SciPy 插值 0.15，
        裁剪到 [2,4]；再从大/小候选池各按 _get_weighted_score 取相应个数。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 顺序为“先大后小”；长度 ≤ count（某侧候选耗尽时会少号）。
        注意：- _get_sklearn() 触发懒加载，并训练 RandomForest（非轻量模式）；
            - 空数据时 random.sample，受全局随机状态影响；
            - 各模型异常均被内部捕获；
            - TODO(待确认): 区间平衡分支只比较 range_counts[0] 与 range_counts[3]，
              并在前者偏少时把区间 0 的小号排到候选队首；选择依据（为何只比这两个区间）待确认。
        数学含义:
            用 4 个模型估计下期大数（>25）个数：
            NumPy lstsq 线性外推 0.25 + RF 0.3 + TF 0.3 + SciPy 插值 0.15，
            裁剪到 [2,4]；再从大/小候选池各按 _get_weighted_score 取相应个数。
        输入依赖:
            self.data[:20]（每期大数个数）、tf_predictions、scipy_interp_func。
        适用场景:
            近期大小比偏态时调整下期大号配额。
        """
        _get_sklearn()
        if not self.data:
            return random.sample(range(1, 50), count)
        
        # NumPy np.linalg.lstsq线性回归趋势预测
        recent_bigs = []
        for record in self.data[:20]:
            bigs = sum(1 for n in record.get('numbers', []) if LotteryConfig.is_big(n))
            recent_bigs.append(bigs)
        
        np_predicted_bigs = 3
        if len(recent_bigs) >= 5:
            try:
                # NumPy np.linalg.lstsq矩阵求解
                n = len(recent_bigs)
                X = np.vander(np.arange(n), 2)
                y = np.array(recent_bigs, dtype=np.float64)
                coeffs, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
                next_x = np.array([[n, 1]])
                np_predicted_bigs = np.dot(next_x, coeffs)[0]
            except Exception:
                # 最小二乘失败时退回近 20 期大数个数的算术均值
                np_predicted_bigs = np.mean(recent_bigs)
        
        # sklearn: RandomForestClassifier预测下期大数个数
        rf_predicted_bigs = 3
        # 【修复0xC0000409】轻量模式下跳过sklearn模型训练
        if not getattr(self, '_is_light_mode', False):
            RF = _core._RandomForestClassifier
            SS = _core._StandardScaler
            if RF is not None and SS is not None and len(recent_bigs) >= 10:
                try:
                    X_rf = np.array(recent_bigs[:-1]).reshape(-1, 1)
                    y_rf = np.array(recent_bigs[1:])
                    scaler_rf = SS()
                    X_rf_scaled = scaler_rf.fit_transform(X_rf)
                    rf_model = RF(n_estimators=50, max_depth=3, random_state=42, n_jobs=1)
                    rf_model.fit(X_rf_scaled, y_rf)
                    X_next = scaler_rf.transform([[recent_bigs[-1]]])
                    rf_predicted_bigs = rf_model.predict(X_next)[0]
                except Exception:
                    rf_predicted_bigs = 3
        elif len(recent_bigs) >= 10:
            rf_predicted_bigs = 3
        
        # TensorFlow神经网络预测大小分布
        tf_bigs = self._tf_big_small_predict() if len(recent_bigs) >= 10 else 3
        
        # SciPy interpolate插值预测
        scipy_pred = self._scipy_big_interp() if hasattr(self, 'scipy_interp_func') and self.scipy_interp_func else 3
        
        # 融合预测
        # 权重 0.25/0.3/0.3/0.15：RF 与 TF 为主，线性外推次之，插值仅作辅助
        predicted_bigs = int(round(np_predicted_bigs * 0.25 + rf_predicted_bigs * 0.3 + tf_bigs * 0.3 + scipy_pred * 0.15))
        # 裁剪到 [2,4]：6 码中全大/全小或仅 1 个大号属于极端形态
        predicted_bigs = max(2, min(4, predicted_bigs))
        
        # 区间平衡调整
        range_counts = [0] * 5
        for record in self.data[:5]:
            for num in record.get('numbers', []):
                idx = LotteryConfig.get_range_index(num)
                if idx >= 0:
                    range_counts[idx] += 1
        
        # 选择候选池
        big_candidates = sorted([n for n in range(26, 50)], 
                                key=lambda x: self._get_weighted_score(x), reverse=True)
        small_candidates = sorted([n for n in range(1, 26)], 
                                 key=lambda x: self._get_weighted_score(x), reverse=True)
        
        # 按区间分布调整
        # 区间 0（1-10）近 5 期出现次数少于区间 3（31-40）时，把小号候选中的区间 0 号码提前，
        # 以增加被选中概率（只调整顺序，不改变候选集合本身）
        if range_counts[0] < range_counts[3]:
            small_candidates = sorted(small_candidates, key=lambda x: LotteryConfig.get_range_index(x) == 0, reverse=True)
        
        selected = []
        # 先按预测个数从大到小取号；若某一侧候选不足，最终长度会小于 count
        for _ in range(predicted_bigs):
            if big_candidates:
                selected.append(big_candidates.pop(0))
        for _ in range(count - predicted_bigs):
            if small_candidates:
                selected.append(small_candidates.pop(0))
        
        return selected[:count]
    
    def _tf_big_small_predict(self):
        """TensorFlow 神经网络预测大小分布

        功能：对 26..49 共 24 个大号号码的 tf_predictions 取均值，再乘 6 换算成
        “下期大号个数期望”，裁剪到 [2,4]。
        参数：无。
        返回：int: 范围 2~4；无模型或异常时返回默认 3。
        注意：无副作用（只读 self.tf_predictions）；异常被捕获并回退默认值 3。
        数学含义:
            对 26..49 共 24 个大号号码的 tf_predictions 取均值，再乘 6 换算成
            “下期大号个数期望”，裁剪到 [2,4]。
        输入依赖:
            self.tf_predictions。
        适用场景:
            big_small_algorithm 的 TF 融合项（权重 0.3）。
        """
        if not hasattr(self, 'tf_predictions') or not self.tf_predictions:
            return 3
        try:
            big_probs = [self.tf_predictions.get(n, 0.02) for n in range(26, 50)]
            # 乘 6 是每期开奖个数，把“平均单号概率”换算成期望大号个数
            expected_bigs = sum(big_probs) / len(big_probs) * 6 if big_probs else 3
            return max(2, min(4, int(round(expected_bigs))))
        except Exception:
            return 3
    
    def _scipy_big_interp(self):
        """SciPy interpolate 插值预测大小分布

        功能：对 26..49 的插值预测求和得 big_sum，avg = big_sum/24（big_sum<=0 时取 25），
        再用 round(avg/5) 映射为大号个数，并裁剪到 [2,4]。
        参数：无。
        返回：int: 范围 2~4；无插值函数或异常时返回默认 3。
        注意：无副作用（只读 self.scipy_interp_func）；异常被捕获并回退默认值 3；
            TODO(待确认): big_sum<=0 时 avg 取 25，经 /5 与裁剪后恒为 4，
            等于“认为下期有 4 个大号”，该兜底语义可疑。
        数学含义:
            对 26..49 的插值预测求和得 big_sum，avg = big_sum/24（big_sum<=0 时取 25），
            再用 round(avg/5) 映射为大号个数，并裁剪到 [2,4]。
        输入依赖:
            self.scipy_interp_func（插值预测的是“号码 -> 遗漏”曲线）。
        适用场景:
            big_small_algorithm 的 SciPy 融合项（权重 0.15）。
        """
        if not hasattr(self, 'scipy_interp_func') or not self.scipy_interp_func:
            return 3
        try:
            big_sum = sum(self.scipy_interp_func(n) for n in range(26, 50))
            # 24 为大号号码个数；big_sum 非正时用 25 兜底（TODO 见 docstring）
            avg = big_sum / 24 if big_sum > 0 else 25
            # 5 为经验缩放：把平均遗漏量级压到 2~4 个号码的区间
            return max(2, min(4, int(round(avg / 5))))
        except Exception:
            return 3
    
    def missing_value_analysis(self, count=6):
        """遗漏值分析 - TensorFlow回补预测 + sklearn GaussianNB + NumPy分位数 + SciPy插值

        功能：score = 0.2*sigmoid(zscore) + 0.25*指数回补概率 + 0.1*间隔规律性
            + 0.15*min(ratio,3)/3 + NB/分位数/TF/PyTorch/SciPy 加成，
            再进行 Top count 选取；ratio = 当前遗漏 / 历史平均间隔。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 按得分降序的前 count 个（未升序）。
        注意：- 训练 49 个 GaussianNB（>=20 期且非轻量模式）；
            - 空数据时 random.sample，受全局随机状态影响。
        数学含义:
            score = 0.2*sigmoid(zscore) + 0.25*指数回补概率 + 0.1*间隔规律性
                + 0.15*min(ratio,3)/3 + NB/分位数/TF/PyTorch/SciPy 加成，
            再进行 Top count 选取；ratio = 当前遗漏 / 历史平均间隔。
        输入依赖:
            self.missing、interval_stats、nb_probs（>=20 期）、np_percentiles、
            tf_predictions、pt_lstm_preds、scipy_interp_func；
            avg_cycle = 总期数 / 49（全量平均间隔的粗略估计）。
        适用场景:
            押注遗漏偏长、接近历史平均间隔的号码“该回补”。
        """
        if not self.data:
            return random.sample(range(1, 50), count)
        
        # sklearn: GaussianNB贝叶斯分类判断每个数字"即将出现"的概率
        nb_probs = self._nb_missing_probs() if len(self.data) >= 20 else {}
        
        # NumPy np.percentile分位数分析遗漏分布
        np_percentile_bonus = self._np_missing_percentile() if hasattr(self, 'np_percentiles') else {}
        
        # TensorFlow回补概率预测
        tf_backfill = self._tf_missing_predict() if hasattr(self, 'tf_predictions') and self.tf_predictions else {}
        
        # PyTorch遗漏回补预测
        pt_backfill = self._pt_missing_predict() if hasattr(self, 'pt_lstm_preds') and self.pt_lstm_preds else {}
        
        # SciPy interpolate插值预测遗漏
        scipy_interp_bonus = self._scipy_missing_interp() if hasattr(self, 'scipy_interp_func') and self.scipy_interp_func else {}
        
        total_records = len(self.data)
        # 平均回补周期的粗略估计：每期开 6 个，49 个号码轮流出现，理论周期约 49/6≈8.2；
        # 这里用“总期数/49”是历史平均出现间隔的另一种近似
        avg_cycle = total_records / 49 if total_records > 0 else 6
        
        scores = {}
        for num in range(1, 50):
            missing = self.missing.get(num, 50)
            stats = self.interval_stats.get(num, {})
            
            # Z-score异常检测
            zscore = stats.get('zscore', 0)
            # sigmoid 把 Z-score 压到 0~1，避免极端遗漏值直接主导总分
            zscore_score = 1.0 / (1 + np.exp(-zscore))  # sigmoid
            
            # 指数回补模型
            # 遗漏越长，按指数分布假设的“下一期出现”概率越高；avg_cycle 作为尺度参数
            exp_back = MathUtils.calculate_missing_cycle(missing, avg_cycle)
            
            # 间隔方差规律性得分
            interval_std = stats.get('std', 0)
            # 间隔标准差越小说明该号码出现节奏越规律，得分越高（0~1）
            regularity_score = 1.0 / (1 + interval_std)
            
            # 遗漏/均间隔比值
            # 当前遗漏相对历史平均间隔的倍数；历史均值为 0 时无法判断，取中性值 1
            ratio = missing / stats.get('mean', avg_cycle) if stats.get('mean', 0) > 0 else 1
            
            # sklearn GaussianNB概率加成
            # 乘数 50/10/80/60/5 把各模型输出映射到与基础项（0~0.7）相近的量级
            nb_bonus = nb_probs.get(num, 0.02) * 50
            
            # NumPy分位数加成
            np_bonus = np_percentile_bonus.get(num, 0) * 10
            
            # TensorFlow回补概率加成
            tf_bonus = tf_backfill.get(num, 0.02) * 80
            
            # PyTorch回补概率加成
            pt_bonus = pt_backfill.get(num, 0.02) * 60
            
            # SciPy插值加成
            scipy_bonus = scipy_interp_bonus.get(num, 0) * 5
            
            # 综合得分
            # 基础项权重合计 0.7；ratio 截断到 3 再除以 3 归一化，避免超长遗漏一家独大，
            # 模型加成项（NB/分位数/TF/PyTorch/SciPy）合计约 0.3 量级
            scores[num] = (
                zscore_score * 0.2 +
                exp_back * 0.25 +
                regularity_score * 0.1 +
                min(ratio, 3) / 3 * 0.15 +
                nb_bonus + np_bonus + tf_bonus + pt_bonus + scipy_bonus
            )
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _np_missing_percentile(self):
        """NumPy np.percentile 分位数分析遗漏

        功能：以 (p25, p50, p75, p90) 为阈值把遗漏分为五档，
        依次给 +5/+3/+1/-1/-3（越热得分越高）。
        参数：无。
        返回：dict[int,int]: 键 1..49，值 -3~5；模型缺失/异常时返回 {}。
        注意：无副作用；异常被捕获并返回已累积结果。
        数学含义:
            以 (p25, p50, p75, p90) 为阈值把遗漏分为五档，
            依次给 +5/+3/+1/-1/-3（越热得分越高）。
        输入依赖:
            self.np_percentiles（四元组，缺失或格式不符时不计算）、self.missing。
        适用场景:
            missing_value_analysis 的分位数档位加成。
        """
        bonus = {}
        if not hasattr(self, 'np_percentiles') or self.np_percentiles is None:
            return bonus
        try:
            p25, p50, p75, p90 = self.np_percentiles
            for num in range(1, 50):
                miss = self.missing.get(num, 50)
                if miss <= p25:
                    bonus[num] = 5  # 极热
                elif miss <= p50:
                    bonus[num] = 3  # 温热
                elif miss <= p75:
                    bonus[num] = 1  # 温冷
                elif miss <= p90:
                    bonus[num] = -1  # 冷
                else:
                    bonus[num] = -3  # 极冷
        except Exception:
            pass
        return bonus
    
    def _tf_missing_predict(self):
        """TensorFlow 回补概率预测

        功能：直接复用 TF 模型输出的每号码出现概率，不再做遗漏修正。
        参数：无。
        返回：dict[int,float]: tf_predictions 的浅拷贝；无模型时 {}。
        注意：返回副本，调用方修改不会污染 self.tf_predictions。
        """
        if not hasattr(self, 'tf_predictions') or not self.tf_predictions:
            return {}
        return self.tf_predictions.copy()
    
    def _pt_missing_predict(self):
        """PyTorch LSTM 回补概率预测

        功能：直接复用 LSTM 输出的每号码概率。
        参数：无。
        返回：dict[int,float]: pt_lstm_preds 的浅拷贝；无模型时 {}。
        注意：返回副本，调用方修改不会污染 self.pt_lstm_preds。
        """
        if not hasattr(self, 'pt_lstm_preds') or not self.pt_lstm_preds:
            return {}
        return self.pt_lstm_preds.copy()
    
    def _scipy_missing_interp(self):
        """SciPy interpolate 插值遗漏加成

        功能：diff = interp(num) - missing：
        diff>0（插值预测遗漏更长）给 min(diff*0.5, 5)，
        diff<=0 给 max(diff*0.3, -3)，即正向奖励更强、负向惩罚更温和。
        参数：无。
        返回：dict[int,float]: 键 1..49，值 -3~5；无插值函数/异常时返回 {}。
        注意：无副作用（只读 self.scipy_interp_func/self.missing）；异常被捕获。
        数学含义:
            diff = interp(num) - missing：
            diff>0（插值预测遗漏更长）给 min(diff*0.5, 5)，
            diff<=0 给 max(diff*0.3, -3)，即正向奖励更强、负向惩罚更温和。
        输入依赖:
            self.scipy_interp_func、self.missing。
        适用场景:
            missing_value_analysis 的 SciPy 加成项（乘数 5）。
        """
        bonus = {}
        if not hasattr(self, 'scipy_interp_func') or not self.scipy_interp_func:
            return bonus
        try:
            for num in range(1, 50):
                interp_val = self.scipy_interp_func(num)
                miss = self.missing.get(num, 50)
                diff = interp_val - miss
                # 0.5/5：正向最多 +5；0.3/-3：负向最多 -3，避免插值误差过度惩罚
                if diff > 0:
                    bonus[num] = min(diff * 0.5, 5)
                else:
                    bonus[num] = max(diff * 0.3, -3)
        except Exception:
            pass
        return bonus
    
    def _nb_missing_probs(self):
        """GaussianNB 贝叶斯分类判断每个数字“即将出现”的概率

        功能：49 个二分类任务；特征为 _build_sklearn_feature_vector(label_idx+2)
        （只用标签期及更旧历史），标签为“紧接着的未来 2 期
        （data[label_idx]、data[label_idx+1]）内是否出现”；GaussianNB 对
        第 0 期（全部历史）的推理特征输出 P(出现)。
        参数：无。
        返回：dict[int,float]: 键 1..49；样本不足/无 sklearn/异常时返回 {}。
        注意：- 训练 49 个 GaussianNB，每 10 个模型 gc.collect()；
            - 轻量模式或 sklearn 缺失时直接返回 {}；不修改 self。
        数学含义:
            49 个二分类任务；特征为 _build_sklearn_feature_vector(label_idx+2)
            （只用标签期及更旧历史），标签为“紧接着的未来 2 期
            （data[label_idx]、data[label_idx+1]）内是否出现”；GaussianNB 对
            第 0 期（全部历史）的推理特征输出 P(出现)。
        输入依赖:
            self.data、self.sklearn_features。
        适用场景:
            missing_value_analysis 的贝叶斯加成（>=20 期且非轻量模式）。
        """
        # 【修复0xC0000409】轻量模式下跳过sklearn模型训练
        if getattr(self, '_is_light_mode', False):
            return {}
        _get_sklearn()
        GNB = _core._GaussianNB
        if not hasattr(self, 'sklearn_features') or self.sklearn_features is None or GNB is None:
            return {}
        try:
            probs = {}
            # 特征：只用“第 label_idx+2 期及更旧历史”；标签：紧接着的未来 2 期
            # （data[label_idx]、data[label_idx+1]，比特征窗口更新）内是否出现
            X_nb, y_nb = [], []
            for label_idx in range(len(self.data) - 2):
                features = self._build_sklearn_feature_vector(label_idx + 2)
                X_nb.append(features)
                future_nums = set()
                for j in range(2):
                    future_nums.update(self.data[label_idx + j].get('numbers', []))
                y_single = [1 if n in future_nums else 0 for n in range(1, 50)]
                y_nb.append(y_single)
            if len(X_nb) < 10:
                return {}
            X_nb, y_nb = np.array(X_nb), np.array(y_nb)
            # 推理样本：第 0 期（全部历史）的特征，用于预测尚未发生的下一期
            X_nb_latest = np.array([self._build_sklearn_feature_vector(0)])
            import gc as _gc  # 作用说明：每训练 10 个 GaussianNB 手动触发一次垃圾回收，缓解内存/栈累积
            for n in range(1, 50):
                y_col = y_nb[:, n-1]
                # 【修复0xC0000409】跳过单类目标
                if len(set(y_col)) < 2:
                    probs[n] = 0.02
                    continue
                nb_model = GNB()
                nb_model.fit(X_nb, y_col)
                if len(nb_model.classes_) > 1:
                    proba = nb_model.predict_proba(X_nb_latest)[0][1]
                else:
                    proba = 0.02
                probs[n] = proba
                del nb_model
                if n % 10 == 0:
                    _gc.collect()
            return probs
        except Exception:
            return {}
    
    def adjacent_number_analysis(self, count=6):
        """连号/邻号 - TensorFlow预测 + sklearn MLP + NumPy共现矩阵 + PyTorch平滑

        功能：score = 0.2*条件概率 + 0.15*共现得分 + 0.1*距离衰减
            + 0.1*基础特征 + MLP/TF/PyTorch 概率加成；
        共现得分 = 相关系数矩阵行与“最新一期出现向量”的内积 / 本期号码个数，
        距离衰减 = 对每个最新号码取 exp(-|num-ln|/5) 后求平均。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 按得分降序的前 count 个（未升序）。
        注意：- 训练 49 个 MLP（>=20 期且非轻量模式）；
            - 空数据时 random.sample，受全局随机状态影响。
        数学含义:
            score = 0.2*条件概率 + 0.15*共现得分 + 0.1*距离衰减
                + 0.1*基础特征 + MLP/TF/PyTorch 概率加成；
            共现得分 = 相关系数矩阵行与“最新一期出现向量”的内积 / 本期号码个数，
            距离衰减 = 对每个最新号码取 exp(-|num-ln|/5) 后求平均。
        输入依赖:
            self.data[0]（最新一期）、consecutive_prob、correlation_matrix、
            mlp_probs（>=20 期）、tf_predictions、pt_lstm_preds。
        适用场景:
            预测与上一期号码相邻（±1/±2）的号码。
        """
        if not self.data:
            return random.sample(range(1, 50), count)
        
        # sklearn: MLPClassifier预测邻号出现概率
        mlp_probs = self._mlp_adjacent_probs() if len(self.data) >= 20 else {}
        
        # TensorFlow邻号预测
        tf_adj_probs = self._tf_adjacent_predict() if hasattr(self, 'tf_predictions') and self.tf_predictions else {}
        
        # PyTorch邻号预测
        pt_adj_probs = self._pt_adjacent_predict() if hasattr(self, 'pt_lstm_preds') and self.pt_lstm_preds else {}
        
        # 邻号候选
        # TODO(待确认): adjacent_candidates 构建后未参与打分/过滤，仅为死代码
        adjacent_candidates = set()
        latest_numbers = self.data[0].get('numbers', [])
        # 邻号定义为相差 1 或 2 的号码（不含号码自身），并裁剪到 1..49
        for num in latest_numbers:
            for offset in [-2, -1, 1, 2]:
                adj = num + offset
                if 1 <= adj <= 49:
                    adjacent_candidates.add(adj)
        
        scores = {}
        for num in range(1, 50):
            # 条件概率
            # 0.01 为历史未统计到该号码时的先验兜底（低但非零，避免完全排除）
            cond_prob = self.consecutive_prob.get(num, 0.01)
            
            # NumPy np.dot矩阵乘法计算共现得分
            cooccur_score = 0
            if latest_numbers:
                cooccur_vec = np.array([1 if n in latest_numbers else 0 for n in range(1, 50)], dtype=np.float32)
                # 行下标 num-1 对应号码 num；除以本期号码个数把共现总分转成平均值
                cooccur_score = np.dot(self.correlation_matrix[num-1], cooccur_vec) / len(latest_numbers)
            
            # 距离衰减得分
            # exp(-dist/5)：距离 1 约 0.82、距离 5 约 0.37，越近的邻号得分越高
            distance_score = 0
            for ln in latest_numbers:
                dist = abs(ln - num)
                distance_score += np.exp(-dist / 5)
            # 空列表时用 1 兜底避免除零
            distance_score /= len(latest_numbers) if latest_numbers else 1
            
            # 基础特征得分
            # 除以 100 把 _get_weighted_score 的量级压到约 0~1，与条件概率/共现/距离项可比
            base_score = self._get_weighted_score(num) / 100
            
            # sklearn MLP概率加成
            mlp_bonus = mlp_probs.get(num, 0.02) * 100
            
            # TensorFlow邻号加成
            tf_bonus = tf_adj_probs.get(num, 0.02) * 80
            
            # PyTorch邻号加成
            pt_bonus = pt_adj_probs.get(num, 0.02) * 60
            
            # 综合得分
            # 基础项权重 0.2/0.15/0.1/0.1；MLP/TF/PyTorch 加成乘数 100/80/60
            scores[num] = (cond_prob * 0.2 + cooccur_score * 0.15 + distance_score * 0.1 + 
                          base_score * 0.1 + mlp_bonus + tf_bonus + pt_bonus)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _tf_adjacent_predict(self):
        """TensorFlow 邻号出现概率

        功能：直接复用 TF 模型输出的每号码出现概率。
        参数：无。
        返回：dict[int,float]: tf_predictions 的浅拷贝；无模型时 {}。
        注意：返回副本，调用方修改不会污染 self.tf_predictions。
        """
        if not hasattr(self, 'tf_predictions') or not self.tf_predictions:
            return {}
        return self.tf_predictions.copy()
    
    def _pt_adjacent_predict(self):
        """PyTorch LSTM 邻号出现概率

        功能：直接复用 LSTM 输出的每号码概率。
        参数：无。
        返回：dict[int,float]: pt_lstm_preds 的浅拷贝；无模型时 {}。
        注意：返回副本，调用方修改不会污染 self.pt_lstm_preds。
        """
        if not hasattr(self, 'pt_lstm_preds') or not self.pt_lstm_preds:
            return {}
        return self.pt_lstm_preds.copy()
    
    def _mlp_adjacent_probs(self):
        """MLPClassifier 预测邻号出现概率

        功能：49 个二分类任务；特征为 _build_sklearn_feature_vector(label_idx+1)
        （只用标签期及更旧历史），经 StandardScaler 标准化后输入
        MLP(hidden=(50,25), max_iter=200, seed=42)，再对第 0 期（全部历史）
        的推理特征输出“下一期出现”的 P(出现)。
        参数：无。
        返回：dict[int,float]: 键 1..49，值 0~1；样本不足/无 sklearn/异常时返回 {}。
        注意：- 训练 49 个 MLP，耗时明显，每 10 个模型 gc.collect()；
            - 轻量模式或 sklearn 缺失时直接返回 {}；不修改 self。
        数学含义:
            49 个二分类任务；特征为 _build_sklearn_feature_vector(label_idx+1)
            （只用标签期及更旧历史），经 StandardScaler 标准化后输入
            MLP(hidden=(50,25), max_iter=200, seed=42)，再对第 0 期（全部历史）
            的推理特征输出“下一期出现”的 P(出现)。
        输入依赖:
            self.data、self.sklearn_features。
        适用场景:
            adjacent_number_analysis 的 MLP 概率加成（>=20 期且非轻量模式）。
        """
        # 【修复0xC0000409】轻量模式下跳过sklearn模型训练
        if getattr(self, '_is_light_mode', False):
            return {}
        _get_sklearn()
        MLP = _core._MLPClassifier
        SS = _core._StandardScaler
        if not hasattr(self, 'sklearn_features') or self.sklearn_features is None or MLP is None or SS is None:
            return {}
        try:
            probs = {}
            # 构建训练数据：用“第 label_idx+1 期及更旧历史”的特征 -> 预测第 label_idx 期出现
            # 特征索引严格早于标签 data[label_idx]，窗口与标签不重叠、无未来泄漏
            X_mlp, y_mlp = [], []
            for label_idx in range(len(self.data) - 1):
                features = self._build_sklearn_feature_vector(label_idx + 1)
                X_mlp.append(features)
                next_nums = self.data[label_idx].get('numbers', [])
                y_single = [1 if n in next_nums else 0 for n in range(1, 50)]
                y_mlp.append(y_single)
            if len(X_mlp) < 10:
                return {}
            X_mlp, y_mlp = np.array(X_mlp), np.array(y_mlp)
            scaler_mlp = SS()
            X_mlp_scaled = scaler_mlp.fit_transform(X_mlp)
            # 推理样本：第 0 期（全部历史）的特征，用训练集同一 scaler 变换
            X_mlp_latest = scaler_mlp.transform(
                np.array([self._build_sklearn_feature_vector(0)])
            )
            import gc as _gc  # 作用说明：每训练 10 个 MLP 手动触发一次垃圾回收，缓解内存/栈累积
            for n in range(1, 50):
                y_col = y_mlp[:, n-1]
                # 【修复0xC0000409】跳过单类目标
                if len(set(y_col)) < 2:
                    probs[n] = 0.02
                    continue
                # 两层隐藏层 (50,25) / 200 轮为轻量配置；49 个模型串行训练，层数再大耗时会失控
                mlp_model = MLP(hidden_layer_sizes=(50, 25), max_iter=200, random_state=42)
                mlp_model.fit(X_mlp_scaled, y_col)
                if len(mlp_model.classes_) > 1:
                    proba = mlp_model.predict_proba(X_mlp_latest)[0][1]
                else:
                    proba = 0.02
                probs[n] = proba
                del mlp_model
                if n % 10 == 0:
                    _gc.collect()
            return probs
        except Exception:
            return {}
    
    def tail_distribution_algorithm(self, count=6):
        """尾数分布 - TensorFlow预测 + sklearn KMeans + NumPy histogram + SciPy分布检验

        功能：tail_score = (期望-观测)/期望 * 10 + 近期缺失期数 * 0.5
            + KMeans/NumPy/TF/SciPy 加成；
        期望 = 尾数总频次/10，偏差越大（出现越少）得分越高；
        取 Top4 尾数，每个尾数再取权重分最高的 3 个号码，合并排序后取 count。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 长度 ≤ count（候选池最多 4*3=12 个，正常可满足 count<=6）。
        注意：- KMeans 训练（>=15 期、非轻量模式）；
            - 空数据时 random.sample，受全局随机状态影响；
            - TODO(待确认): chi2_stat/chi2_score 计算后未参与任何打分，属未使用变量。
        数学含义:
            tail_score = (期望-观测)/期望 * 10 + 近期缺失期数 * 0.5
                + KMeans/NumPy/TF/SciPy 加成；
            期望 = 尾数总频次/10，偏差越大（出现越少）得分越高；
            取 Top4 尾数，每个尾数再取权重分最高的 3 个号码，合并排序后取 count。
        输入依赖:
            self.tail_distribution、self.data[:10]、np_histogram、tf_predictions、
            ks_test_result、_tail_kmeans_bonus（>=15 期）。
        适用场景:
            在“尾数应均匀分布”的假设下押注低频尾数回补。
        """
        if not self.data:
            return random.sample(range(1, 50), count)
        
        # sklearn: KMeans对10个尾数的频率向量聚类，找出需要回补的尾数组
        # 15 期是 10 个尾数聚类的最低样本要求（每尾平均不到 1.5 期，再少则频率无意义）
        tail_cluster_bonus = self._tail_kmeans_bonus() if len(self.data) >= 15 else {}
        
        # NumPy histogram分析尾数分布
        np_hist_bonus = self._np_tail_histogram() if hasattr(self, 'np_histogram') else {}
        
        # TensorFlow尾数预测
        tf_tail_bonus = self._tf_tail_predict() if hasattr(self, 'tf_predictions') and self.tf_predictions else {}
        
        # SciPy分布检验修正
        scipy_tail_corr = self._scipy_tail_correction() if hasattr(self, 'ks_test_result') else {}
        
        # 计算尾数频率
        tail_counts = np.array([self.tail_distribution.get(i, 0) for i in range(10)])
        total = tail_counts.sum()
        expected = total / 10
        
        # Chi-square均匀性检验
        # 卡方统计量 sum((观测-期望)^2/期望)，expected 为 0 时（无任何尾数数据）置 0 避免除零
        chi2_stat = np.sum((tail_counts - expected) ** 2 / expected) if expected > 0 else 0
        # TODO(待确认): chi2_score 计算后未被使用，卡方结果没有进入 tail_scores
        chi2_score = chi2_stat / 100
        
        # 选择低频尾数（应该回补）
        tail_scores = {}
        for tail in range(10):
            observed = tail_counts[tail]
            # 相对偏差（期望-观测）/期望，空数据时取 0；乘 10 后与缺失期数项（0.5/期）同量级
            deviation = (expected - observed) / expected if expected > 0 else 0
            # 遗漏补偿
            # 统计最近 10 期中“完全没有出现该尾数”的期数，每期给 0.5 分
            tail_missing = sum(1 for record in self.data[:10] 
                              if not any(LotteryConfig.get_tail_digit(n) == tail for n in record.get('numbers', [])))
            # sklearn KMeans聚类加成
            cluster_bonus = tail_cluster_bonus.get(tail, 0)
            # NumPy直方图加成
            np_bonus = np_hist_bonus.get(tail, 0)
            # TensorFlow加成
            tf_bonus = tf_tail_bonus.get(tail, 0.02) * 50
            # SciPy加成
            scipy_bonus = scipy_tail_corr.get(tail, 0) * 10
            # 偏差项乘 10、缺失项每期 0.5：两者量级约 0~10，模型加成为 0~20 的补充
            tail_scores[tail] = deviation * 10 + tail_missing * 0.5 + cluster_bonus + np_bonus + tf_bonus + scipy_bonus
        
        # 选 4 个尾数（10 个中的 40%）；每个尾数约 5 个号码，4 个尾数可提供约 20 个候选
        sorted_tails = sorted(tail_scores.items(), key=lambda x: x[1], reverse=True)[:4]
        selected_tails = [t for t, _ in sorted_tails]
        
        # 按特征得分选号
        candidates = []
        for tail in selected_tails:
            tail_nums = [n for n in range(1, 50) if LotteryConfig.get_tail_digit(n) == tail]
            tail_nums.sort(key=lambda x: self._get_weighted_score(x), reverse=True)
            # 每个尾数取前 3 个，4 个尾数共 12 个候选，避免单一尾数垄断结果
            candidates.extend(tail_nums[:3])
        
        candidates.sort(key=lambda x: self._get_weighted_score(x), reverse=True)
        return candidates[:count]
    
    def _np_tail_histogram(self):
        """NumPy histogram 分析尾数分布

        功能：尾数频次低于均值 0.8 倍时给 +5，否则 0，用于鼓励低频尾数回补。
        参数：无。
        返回：dict[int,int]: 键 0..9，值 0 或 5；模型缺失/异常时返回 {}。
        注意：无副作用；异常被捕获并返回已累积结果。
        数学含义:
            尾数频次低于均值 0.8 倍时给 +5，否则 0，用于鼓励低频尾数回补。
        输入依赖:
            self.np_histogram（存在才计算）、self.tail_distribution。
        适用场景:
            tail_distribution_algorithm 的 NumPy 加成。
        """
        bonus = {}
        if not hasattr(self, 'np_histogram') or self.np_histogram is None:
            return bonus
        try:
            tail_counts = np.array([self.tail_distribution.get(i, 0) for i in range(10)], dtype=np.float32)
            avg = np.mean(tail_counts)
            for tail in range(10):
                # 0.8 为“偏低”的经验阈值，与 20% 的偏差容忍度对应
                if tail_counts[tail] < avg * 0.8:
                    bonus[tail] = 5  # 低频尾数
                else:
                    bonus[tail] = 0
        except Exception:
            pass
        return bonus
    
    def _tf_tail_predict(self):
        """TensorFlow 尾数分布预测

        功能：每个尾数取其号码 tf_predictions 的均值作为尾数概率；
        低于全体尾数均值 0.9 倍的低概率尾数按 prob*2 加成（回补），其余按 prob。
        参数：无。
        返回：dict[int,float]: 键 0..9；无模型时返回 {}。
        注意：无副作用（只读 self.tf_predictions）。
        数学含义:
            每个尾数取其号码 tf_predictions 的均值作为尾数概率；
            低于全体尾数均值 0.9 倍的低概率尾数按 prob*2 加成（回补），其余按 prob。
        输入依赖:
            self.tf_predictions。
        适用场景:
            tail_distribution_algorithm 的 TF 加成（乘数 50）。
        """
        if not hasattr(self, 'tf_predictions') or not self.tf_predictions:
            return {}
        bonus = {}
        tail_probs = []
        for tail in range(10):
            probs = [self.tf_predictions.get(n, 0.02) for n in range(1, 50) if LotteryConfig.get_tail_digit(n) == tail]
            tail_probs.append(sum(probs) / len(probs) if probs else 0.02)
        avg = sum(tail_probs) / len(tail_probs) if tail_probs else 0.02
        for tail, prob in enumerate(tail_probs):
            # 0.9 为“低概率”阈值；乘 2 是轻度补偿，避免低概率尾数被反转过头
            if prob < avg * 0.9:
                bonus[tail] = prob * 2  # 低概率尾数需回补
            else:
                bonus[tail] = prob
        return bonus
    
    def _scipy_tail_correction(self):
        """SciPy 分布检验修正尾数分布

        功能：当 KS 检验 p > 0.3（认为尾数分布接近均匀）时，低于均值的尾数给 +3，
        否则 0；p <= 0.3 说明分布明显不均，按“趋势延续”处理，不做回补加成。
        参数：无。
        返回：dict[int,int]: 键 0..9，值 0 或 3；无 ks_test_result 时返回 {}。
        注意：无副作用（只读 self.ks_test_result/self.tail_distribution）；
            TODO(待确认): 0.3 是经验阈值而非常用显著性水平 0.05，筛选条件偏宽松。
        数学含义:
            当 KS 检验 p > 0.3（认为尾数分布接近均匀）时，低于均值的尾数给 +3，
            否则 0；p <= 0.3 说明分布明显不均，按“趋势延续”处理，不做回补加成。
        输入依赖:
            self.ks_test_result（KS 检验 p 值）、self.tail_distribution。
        适用场景:
            tail_distribution_algorithm 的 SciPy 加成（乘数 10）。
        """
        bonus = {}
        if not hasattr(self, 'ks_test_result'):
            return bonus
        pval = getattr(self, 'ks_test_result', 0.5)
        tail_counts = np.array([self.tail_distribution.get(i, 0) for i in range(10)])
        avg = np.mean(tail_counts)
        for tail in range(10):
            # p > 0.3：分布可视为均匀，低频尾数具备回补空间
            if pval > 0.3:  # 分布一致，低频更可能回补
                if tail_counts[tail] < avg:
                    bonus[tail] = 3
                else:
                    bonus[tail] = 0
            else:  # 分布不一致，趋势延续
                bonus[tail] = 0
        return bonus
    
    def _tail_kmeans_bonus(self):
        """KMeans 对 10 个尾数聚类，找出低频尾数组需要回补

        功能：每个尾数的特征为 [频次/总期数]（10×1 矩阵），KMeans(n_clusters=2, n_init=10)
        分成高频/低频两组，低频组每个尾数 +10。
        参数：无。
        返回：dict[int,int]: 键 0..9，值 0 或 10；无 sklearn/数据退化/异常时返回 {}。
        注意：- 训练 1 个 2 簇 KMeans；random_state=42 保证结果可复现；
            - 轻量模式或 sklearn 缺失时直接返回 {}；不修改 self。
        数学含义:
            每个尾数的特征为 [频次/总期数]（10×1 矩阵），KMeans(n_clusters=2, n_init=10)
            分成高频/低频两组，低频组每个尾数 +10。
        输入依赖:
            self.tail_distribution、self.data。
        适用场景:
            tail_distribution_algorithm 的 KMeans 加成（>=15 期且非轻量模式）。
        """
        # 【修复0xC0000409】轻量模式下跳过sklearn模型训练
        if getattr(self, '_is_light_mode', False):
            return {}
        _get_sklearn()
        KM = _core._KMeans
        if KM is None:
            return {}
        try:
            # 构建10个尾数的频率向量
            tail_freq = []
            for tail in range(10):
                # 除以总期数做到“每期平均出现频次”，max(...,1) 防止空数据除零
                tail_freq.append([self.tail_distribution.get(tail, 0) / max(len(self.data), 1)])
            tail_freq = np.array(tail_freq)
            # 10 个尾数频率完全相同时无法分成高低两组，KMeans 会告警且结果无意义
            if len(np.unique(tail_freq)) < 2:
                return {}
            # KMeans聚类（2组：高频组vs低频组）
            # 【修复】sklearn 1.4+已移除KMeans的n_jobs参数
            # 固定为 2 簇（高频 vs 低频）；n_init=10 降低局部最优风险
            kmeans = KM(n_clusters=2, random_state=42, n_init=10)
            labels = kmeans.fit_predict(tail_freq)
            # 找出低频组的尾数
            centers = kmeans.cluster_centers_
            # 特征只有一维（频次），比较两个簇中心的大小即可确定低频组
            low_freq_cluster = 0 if centers[0][0] < centers[1][0] else 1
            bonus = {}
            for tail, label in enumerate(labels):
                bonus[tail] = 10 if label == low_freq_cluster else 0
            return bonus
        except Exception:
            return {}
    
    def range_distribution_algorithm(self, count=6):
        """区间分布 - TensorFlow预测 + sklearn MinMaxScaler + NumPy histogram + SciPy插值

        功能：按 range_weights[i] = 0.3*卡方冷门权重 + 0.2*(cv_score*10) + NumPy/TF/PyTorch/SciPy
            加成算出 5 个区间权重，取 Top4 区间、每区间按 _get_weighted_score 取前 3 号，
            合并排序后取 count 个。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 长度 ≤ count，按加权特征分降序的候选号码（候选池最多 4*3=12 个）。
        注意：- _range_cv_scores 会训练 5*cv_folds 个 GBDT（>=30 期且非轻量模式）；
            - 空数据时 random.sample，受全局随机状态影响；
            - self.df 为 None（缺 pandas）时改走纯 Python 计数，结果仍可用。
        数学含义:
            range_weights[i] = 0.3*卡方冷门权重 + 0.2*(cv_score*10)
                + NumPy/TF/PyTorch/SciPy 加成；
            卡方冷门权重 = max(0,(期望-观测)/期望)*5 + (总数-观测)/总数；
            选取 Top4 区间，每区间取权重分最高的 3 个号码，合并排序后取 count。
        输入依赖:
            self.data[:10]、self.df（range_0..4 列；缺 pandas 时为 None）、
            range_cv_scores（>=30 期）、np_histogram、tf_predictions、
            pt_lstm_preds、scipy_interp_func。
        适用场景:
            押注近 10 期出现偏少、且交叉验证认为可预测的号码区间。
            list[int]，长度 ≤ count（候选池最多 4*3=12 个）。
        """
        if not self.data:
            return random.sample(range(1, 50), count)
        
        # sklearn: MinMaxScaler归一化区间特征 + cross_val_score验证区间预测模型
        # 30 期才做交叉验证：样本更少时 3 折切分后每折不足 10 个样本，评分不可信；0.5 为中性默认值
        range_cv_scores = self._range_cv_scores() if len(self.data) >= 30 else {i: 0.5 for i in range(5)}
        
        # NumPy histogram区间分析
        np_range_bonus = self._np_range_histogram() if hasattr(self, 'np_histogram') else {}
        
        # TensorFlow区间预测
        tf_range_bonus = self._tf_range_predict() if hasattr(self, 'tf_predictions') and self.tf_predictions else {}
        
        # PyTorch区间预测
        pt_range_bonus = self._pt_range_predict() if hasattr(self, 'pt_lstm_preds') and self.pt_lstm_preds else {}
        
        # SciPy interpolate区间插值
        scipy_range_bonus = self._scipy_range_interp() if hasattr(self, 'scipy_interp_func') and self.scipy_interp_func else {}
        
        # 使用Pandas DataFrame计算区间趋势
        if getattr(self, 'df', None) is not None and not self.df.empty:
            # DataFrame 与 self.data 同序（最新在前），iloc[:10] 即最近 10 期
            recent_range_freq = self.df[['range_0', 'range_1', 'range_2', 'range_3', 'range_4']].iloc[:10].sum()
        else:
            # 无 DataFrame（df 为空或缺失 pandas）：用 self.data[:10] 直接统计区间次数
            range_counts = [0] * 5
            for record in self.data[:10]:
                for num in record.get('numbers', []):
                    idx = LotteryConfig.get_range_index(num)
                    if idx >= 0:
                        range_counts[idx] += 1
            try:
                from pandas import Series  # 作用说明：延迟导入 pandas Series，把兜底路径的区间计数列表包装成支持 sum()/iloc 的对象
            except ImportError:
                # 缺 pandas：保留纯列表，下方按 hasattr 决定用 sum()/iloc 还是内建 sum/下标
                recent_range_freq = range_counts
            else:
                recent_range_freq = Series(range_counts)
        
        # 卡方偏差；缺 pandas 时 recent_range_freq 是纯列表，sum()/元素读取改走内建路径
        if hasattr(recent_range_freq, 'sum'):
            total = recent_range_freq.sum()
        else:
            total = sum(recent_range_freq)
        expected = total / 5
        
        # 动态区间权重（融合多模型）
        range_weights = {}
        for i in range(5):
            # 前一项衡量“低于期望的程度”（乘 5 放大），后一项衡量该区间在总数中的稀缺程度；
            # expected/total 为 0 时依赖上方 total 的兜底，不会触发除零
            if hasattr(recent_range_freq, 'iloc'):
                count_i = recent_range_freq.iloc[i]
            else:
                count_i = recent_range_freq[i]
            chi2_weight = max(0, (expected - count_i) / expected) * 5 + (total - count_i) / total
            cv_weight = range_cv_scores.get(i, 0.5)
            np_b = np_range_bonus.get(i, 0) * 5
            tf_b = tf_range_bonus.get(i, 0.02) * 50
            pt_b = pt_range_bonus.get(i, 0.02) * 40
            scipy_b = scipy_range_bonus.get(i, 0) * 3
            # 卡方项权重 0.3；cv_weight（0~1）先乘 10 再乘 0.2，使其与卡方项同量级
            # np_b/tf_b/pt_b/scipy_b 的乘数分别为 5/50/40/3
            range_weights[i] = chi2_weight * 0.3 + cv_weight * 10 * 0.2 + np_b + tf_b + pt_b + scipy_b
        
        sorted_ranges = sorted(range_weights.items(), key=lambda x: x[1], reverse=True)[:4]
        selected_ranges = [r for r, _ in sorted_ranges]
        
        # 按特征得分选号
        candidates = []
        for rng_idx in selected_ranges:
            start, end, _ = LotteryConfig.RANGES[rng_idx]
            rng_nums = list(range(start, end + 1))
            rng_nums.sort(key=lambda x: self._get_weighted_score(x), reverse=True)
            candidates.extend(rng_nums[:3])
        
        candidates.sort(key=lambda x: self._get_weighted_score(x), reverse=True)
        return candidates[:count]
    
    def _np_range_histogram(self):
        """NumPy histogram 区间分布分析

        功能：统计 1..49 各区间的号码容量，低于均值 0.8 倍的区间给 +3，否则 0。
        参数：无。
        返回：dict[int,int]: 键 0..4，值 0 或 3；模型缺失/异常时返回 {}。
        注意：无副作用；异常被捕获并返回已累积结果。
        数学含义:
            统计 1..49 各区间包含的号码个数，低于均值 0.8 倍的区间给 +3。
        输入依赖:
            self.np_histogram（存在才计算）。
        适用场景:
            range_distribution_algorithm 的 NumPy 加成。
            dict[int,int]，键 0..4，值 0 或 3；模型缺失/异常时返回 {}。
        TODO(待确认): 这里统计的是区间“号码容量”（10/10/10/10/9），不是历史出现频次，
            与 self.np_histogram 无实际关系；除第 5 区间外均等于 10，几乎不会触发低频分支，
            导致该加成恒为 0。
        """
        bonus = {}
        if not hasattr(self, 'np_histogram') or self.np_histogram is None:
            return bonus
        try:
            rng_counts = [0] * 5
            for num in range(1, 50):
                idx = LotteryConfig.get_range_index(num)
                if idx >= 0:
                    rng_counts[idx] += 1
            total = sum(rng_counts) or 1
            avg = total / 5
            for i in range(5):
                # 0.8 为偏低的经验阈值
                if rng_counts[i] < avg * 0.8:
                    bonus[i] = 3  # 低频区间需关注
                else:
                    bonus[i] = 0
        except Exception:
            pass
        return bonus
    
    def _tf_range_predict(self):
        """TensorFlow 区间分布预测

        功能：把号码的 tf_predictions 按区间求和，再除以 10（区间容量量级）得到区间概率；
            概率为 0 时用 0.02 兜底。
        参数：无。
        返回：dict[int,float]: 键 0..4；无模型/异常时返回 {}。
        注意：无副作用（只读 self.tf_predictions）；异常被捕获。
        数学含义:
            把号码的 tf_predictions 按区间求和，再除以 10（区间容量量级）得到区间概率；
            概率为 0 时用 0.02 兜底。
        输入依赖:
            self.tf_predictions。
        适用场景:
            range_distribution_algorithm 的 TF 加成（乘数 50）。
            dict[int,float]，键 0..4；无模型/异常时返回 {}。
        """
        bonus = {}
        if not hasattr(self, 'tf_predictions') or not self.tf_predictions:
            return bonus
        try:
            rng_probs = [0] * 5
            for num in range(1, 50):
                idx = LotteryConfig.get_range_index(num)
                if idx >= 0:
                    rng_probs[idx] += self.tf_predictions.get(num, 0.02)
            for i in range(5):
                # 除以 10 取平均（每个区间约 10 个号码）；0.02 与单号先验概率同量级
                bonus[i] = rng_probs[i] / 10 if rng_probs[i] > 0 else 0.02
        except Exception:
            pass
        return bonus
    
    def _pt_range_predict(self):
        """PyTorch LSTM 区间分布预测

        功能：与 _tf_range_predict 同构：把 pt_lstm_preds 按区间求和后除以 10，
            为 0 时用 0.02 兜底。
        参数：无。
        返回：dict[int,float]: 键 0..4；无模型/异常时返回 {}。
        注意：无副作用（只读 self.pt_lstm_preds）；异常被捕获。
        数学含义:
            与 _tf_range_predict 同构：把 pt_lstm_preds 按区间求和后除以 10，
            为 0 时用 0.02 兜底。
        输入依赖:
            self.pt_lstm_preds。
        适用场景:
            range_distribution_algorithm 的 PyTorch 加成（乘数 40）。
            dict[int,float]，键 0..4；无模型/异常时返回 {}。
        """
        bonus = {}
        if not hasattr(self, 'pt_lstm_preds') or not self.pt_lstm_preds:
            return bonus
        try:
            rng_probs = [0] * 5
            for num in range(1, 50):
                idx = LotteryConfig.get_range_index(num)
                if idx >= 0:
                    rng_probs[idx] += self.pt_lstm_preds.get(num, 0.02)
            for i in range(5):
                # 除以 10 取区间平均；0.02 为无数据时的先验兜底
                bonus[i] = rng_probs[i] / 10 if rng_probs[i] > 0 else 0.02
        except Exception:
            pass
        return bonus
    
    def _scipy_range_interp(self):
        """SciPy interpolate 区间插值

        功能：对每个区间内所有号码的插值预测取算术平均，作为该区间的加成。
        参数：无。
        返回：dict[int,float]: 键 0..4；无插值函数/异常时返回 {}。
        注意：无副作用（只读 self.scipy_interp_func）；异常被捕获。
        数学含义:
            对每个区间内所有号码的插值预测取算术平均，作为该区间的加成。
        输入依赖:
            self.scipy_interp_func、LotteryConfig.RANGES（区间起止，含端点）。
        适用场景:
            range_distribution_algorithm 的 SciPy 加成（乘数 3）。
            dict[int,float]，键 0..4；无插值函数/异常时返回 {}。
        """
        bonus = {}
        if not hasattr(self, 'scipy_interp_func') or not self.scipy_interp_func:
            return bonus
        try:
            for i in range(5):
                start, end, _ = LotteryConfig.RANGES[i]
                # RANGES 的 end 为闭区间端点，故 range 用 end+1
                vals = [self.scipy_interp_func(n) for n in range(start, end + 1)]
                bonus[i] = np.mean(vals) if vals else 0.02
        except Exception:
            pass
        return bonus
    
    def _range_cv_scores(self):
        """MinMaxScaler 归一化区间特征 + cross_val_score 验证区间预测模型

        功能：以第 i..i+4 期各区间的出现次数为 25 维特征、第 i 期各区间出现次数为 5 维标签，
            MinMaxScaler 归一化后对每个区间训练 GradientBoostingClassifier 做 cv 折交叉验证，
            neg_mean_squared_error 经 max(0, 1 + mean/10) 映射为 0~1 的可预测性分数。
        参数：无。
        返回：dict[int,float]: 键 0..4，值约 0~1；样本不足/轻量/无 sklearn/异常时全 0.5。
        注意：- 训练 5*cv_folds 个 GBDT，耗时随数据量线性增长；
            - random_state=42 保证可复现；n_jobs=1 防止 C 栈溢出；
            - 轻量模式直接返回全 0.5。
        数学含义:
            特征 = 第 i..i+4 期各区间出现次数（5 期 × 5 区间 = 25 维），
            标签 = 第 i 期各区间出现次数（5 维）；MinMaxScaler 归一化后，
            对每个区间用 GradientBoostingClassifier 做 cv 折交叉验证，
            评分 neg_mean_squared_error 经 max(0, 1 + mean/10) 映射为 0~1。
        输入依赖:
            self.data（>=10 个样本，调用方通常已要求 >=30 期）。
        适用场景:
            range_distribution_algorithm 的 cv 权重项（可能与可预测性正相关）。
            dict[int,float]，键 0..4，值约 0~1；样本不足/轻量/无 sklearn/异常 → 全 0.5。
        TODO(待确认): 特征窗口第 1 组取 data[i]（标签期本身），
            等于把标签放进特征，存在信息泄漏；若意图是“用过去 5 期预测当期”，
            应改为 data[i+1..i+5]。
        """
        # 【修复0xC0000409】轻量模式下跳过sklearn模型训练
        if getattr(self, '_is_light_mode', False):
            return {i: 0.5 for i in range(5)}
        _get_sklearn()
        MMS = _core._MinMaxScaler
        GBC = _core._GradientBoostingClassifier
        CVS = _core._cross_val_score
        if MMS is None or GBC is None or CVS is None:
            return {i: 0.5 for i in range(5)}
        try:
            # 构建区间分布训练数据
            X_range, y_range = [], []
            for i in range(len(self.data) - 1):
                # 该 if 与 for 循环上界 len-1 等价，恒为真，属于冗余判断（保留原逻辑不改）
                if i < len(self.data) - 1:
                    # 特征：第 i..i+4 期各区间出现次数；data 最新在前，i 越大越久远
                    # TODO(待确认): j=0 取到的就是标签期 data[i]，存在标签泄漏
                    features = []
                    for j in range(5):
                        idx = i + j
                        if idx < len(self.data):
                            cnt = [0] * 5
                            for n in self.data[idx].get('numbers', []):
                                ri = LotteryConfig.get_range_index(n)
                                if ri >= 0:
                                    cnt[ri] += 1
                            features.extend(cnt)
                        else:
                            features.extend([0] * 5)
                    X_range.append(features)
                    # 标签：第 i 期（相对特征窗口的“当期”）各区间出现次数
                    next_nums = self.data[i].get('numbers', [])
                    label = [0] * 5
                    for n in next_nums:
                        ri = LotteryConfig.get_range_index(n)
                        if ri >= 0:
                            label[ri] += 1
                    y_range.append(label)
            if len(X_range) < 10:
                return {i: 0.5 for i in range(5)}
            X_range = np.array(X_range)
            y_range = np.array(y_range)
            # MinMaxScaler归一化
            scaler_range = MMS()
            X_range_scaled = scaler_range.fit_transform(X_range)
            # 对每个区间训练并验证
            cv_scores = {}
            for i in range(5):
                y_col = y_range[:, i]
                # 【修复0xC0000409】检查类别分布，避免cross_val_score在单类数据上崩溃
                unique_classes = np.unique(y_col)
                if len(unique_classes) < 2:
                    cv_scores[i] = 0.5
                    continue
                # 计算每个类别的样本数，确保cv不大于最小类样本数
                # 【修复np.bincount bug】bincount无法处理负值且对大值浪费内存，改用np.unique
                unique_classes, class_counts = np.unique(y_col, return_counts=True)
                min_class_count = min(class_counts)
                # 折数不能超过最小类样本数，否则某折可能缺失该类别导致训练失败；上限 3 折
                cv_folds = min(3, min_class_count)
                if cv_folds < 2:
                    cv_scores[i] = 0.5
                    continue
                # 【修复】GradientBoostingClassifier不支持n_jobs参数
                model = GBC(n_estimators=30, max_depth=3, random_state=42)
                try:
                    # 使用回归评分而非accuracy（区间出现次数是连续值，不是分类标签）
                    scores = CVS(model, X_range_scaled, y_col, cv=cv_folds, scoring='neg_mean_squared_error', n_jobs=1)
                    # neg_mean_squared_error 为负值；除以 10 后平移，把“误差小”映射为接近 1 的分数，
                    # 再截断到 >=0，避免误差过大时出现负权重
                    cv_scores[i] = max(0.0, 1.0 + np.mean(scores) / 10.0)
                except Exception:
                    cv_scores[i] = 0.5
            return cv_scores
        except Exception:
            return {i: 0.5 for i in range(5)}
    
    def roulette_selection(self, count=6):
        """轮盘赌采样 - TensorFlow概率 + PyTorch动态温度采样 + sklearn概率融合（无PyTorch时使用NumPy）

        功能：先按多源权重线性融合出 combined_weights（基础特征分 0.3、LogisticRegression
            0.2×200、TensorFlow 0.25×100、PyTorch 0.25×100），再按温度
            T = clip(标准差/50, 0.3, 0.8) 做 softmax 归一化为抽样概率，
            最后按“不放回”方式逐个抽取 count 个号码。
        参数：
            count (int): 期望抽取的号码个数，默认 6。
        返回：list[int]: 长度 <= count（可用号码耗尽时提前结束），元素为 1..49 的号码；不返回概率字典。
        注意：- 非轻量模式下把 PyTorch 全局随机种子重置为当前时间戳 % 1000000（影响全局 RNG）；
            - 使用 np.random.choice 采样，扰动 NumPy 全局随机状态；
            - 懒加载 PyTorch；各子系统异常在其内部处理，本方法未包 try。
        数学含义:
            先按多源权重线性融合出 combined_weights（基础特征分 0.3、LogisticRegression
            0.2×200、TensorFlow 0.25×100、PyTorch 0.25×100），再用 softmax(w/T)
            归一化为抽样概率，最后按“不放回”方式逐个抽取 count 个号码；T 越小分布越尖锐。
        输入依赖:
            self.data / frequency / missing / moving_avg / autocorrelation（经 _get_weighted_score），
            self._lr_roulette_weights 所需训练数据（>=20 期才启用），
            可选 self.tf_predictions、self.pt_lstm_preds；PyTorch 仅在非轻量模式懒加载。
        适用场景:
            需要“按概率随机抽取”的推荐入口；结果每次不同，不适合需要确定性复现的场景。
            list[int]，长度 <= count（可用号码耗尽时提前结束），元素为 1..49 的号码；
            不返回概率字典。
        """
        # 【修复0xC0000409】轻量模式下跳过PyTorch懒加载，使用NumPy替代
        torch_mod = None
        if not getattr(self, '_is_light_mode', False):
            torch_mod = _get_torch()
        if torch_mod is not None:
            torch_mod.manual_seed(int(datetime.datetime.now().timestamp()) % 1000000)
        
        # 计算综合权重
        weights = []
        for num in range(1, 50):
            w = self._get_weighted_score(num)
            weights.append(w)
        
        # sklearn: LogisticRegression概率权重
        lr_weights = self._lr_roulette_weights() if len(self.data) >= 20 else [0.02] * 49
        # 20 期是可训练的最小样本门槛；0.02 与单号先验 1/49 同量级
        
        # TensorFlow概率权重
        tf_weights = []
        if hasattr(self, 'tf_predictions') and self.tf_predictions:
            tf_weights = [self.tf_predictions.get(n, 0.02) for n in range(1, 50)]
        else:
            tf_weights = [0.02] * 49
        
        # PyTorch LSTM概率权重
        pt_weights = []
        if hasattr(self, 'pt_lstm_preds') and self.pt_lstm_preds:
            pt_weights = [self.pt_lstm_preds.get(n, 0.02) for n in range(1, 50)]
        else:
            pt_weights = [0.02] * 49
        
        # NumPy矩阵运算融合权重
        combined_weights = np.array(weights) * 0.3 + np.array(lr_weights) * 200 * 0.2 + np.array(tf_weights) * 100 * 0.25 + np.array(pt_weights) * 100 * 0.25
        # 200/100 把 sklearn/TF/PyTorch 的 0~1 概率放大到与 _get_weighted_score 相近的量级；
        # 0.2/0.25/0.3 是各路来源的权重占比
        
        # 动态温度：基于权重分布熵
        weight_std = np.std(combined_weights)
        temperature = max(0.3, min(0.8, weight_std / 50))
        # TODO(待确认): 实际用标准差（而非熵）衡量分散度，/50 把量纲压到温度区间；
        # 0.3/0.8 为经验上下限，防止分布过平或过尖
        
        # PyTorch动态温度softmax采样（无PyTorch时使用NumPy替代）
        # 【修复0xC0000409】轻量模式下跳过PyTorch懒加载
        if not getattr(self, '_is_light_mode', False):
            torch_mod = _get_torch()
        else:
            torch_mod = None
        if torch_mod is not None and self.device is not None:
            weights_tensor = torch_mod.tensor(combined_weights, dtype=torch_mod.float32, device=self.device)
            logits = weights_tensor / temperature
            probs = torch_mod.softmax(logits, dim=0)
            probs_np = probs.cpu().numpy()
        else:
            # NumPy替代实现
            logits = combined_weights / temperature
            probs_np = np.exp(logits - np.max(logits))  # 数值稳定的softmax
            probs_np = probs_np / probs_np.sum()
        
        # 不放回采样
        selected = []
        available = list(range(49))  # 0-based索引，对应号码1-49
        
        for _ in range(count):
            if not available:
                break
            probs_sum = probs_np[available].sum()
            if probs_sum <= 0:
                probs_sum = 1
            probs_normalized = probs_np[available] / probs_sum
            # 修正浮点精度误差，确保概率和严格为1且非负
            probs_normalized = np.maximum(probs_normalized, 0.0)
            total = probs_normalized.sum()
            if total > 0:
                probs_normalized = probs_normalized / total
            else:
                probs_normalized = np.ones(len(probs_normalized)) / len(probs_normalized)
            idx = np.random.choice(len(available), p=probs_normalized)
            num_idx = available[idx]
            selected.append(num_idx + 1)  # 转回1-based号码
            probs_np[num_idx] = 0
            available.remove(num_idx)
        
        return selected
    
    def historical_similarity(self, count=6):
        """历史相似性 - TensorFlow AutoEncoder + sklearn PCA + NumPy矩阵 + cosine_similarity

        功能：把每期号码编码为 49 维 one-hot + 统计特征（代码实际拼成 64 维），
            计算最新一期与最近 49 期的余弦相似度；再与 PCA、AutoEncoder 的余弦相似度
            各按 0.5/0.5 融合，取最相似的 5 期，用“更早一期号码出现次数 × int(sim*10+1)”投票。
        参数：
            count (int): 目标号码个数，默认 6。
        返回：list[int]: 长度 <= count（去重后可能不足 count），元素 1..49；不返回得分字典。
        注意：- 懒加载 sklearn；
            - 无可用投票时使用 random.sample，扰动全局随机状态；
            - 无 self 属性写入；
            - to_enhanced_vector 维度不一致时 cosine_similarity 可能抛出 ValueError（未捕获）。
        数学含义:
            把每期号码编码为 49 维 one-hot + 统计特征（代码实际拼成 15 维，见 TODO），
            计算最新一期与最近 49 期的余弦相似度；再与 PCA、AutoEncoder 的余弦相似度
            各按 0.5/0.5 融合，取最相似的 5 期，用“下一期号码出现次数 × 相似度权重”投票。
        输入依赖:
            self.data（>=10 期，否则随机返回）；可选 self.sklearn_features /
            self.sklearn_features_scaled、self.tf_encoded，以及 sklearn cosine_similarity。
        适用场景:
            依赖“相似历史之后走势相近”的假设，适合寻找历史类比。
            list[int]，长度 <= count（去重后可能不足 count），元素 1..49；不返回得分字典。
        TODO(修复): to_enhanced_vector 的统计特征实为 15 维（6 项基础 + 5 区间 + 4 尾数），
            one-hot 49 + 15 = 64 维；空列表分支已同步返回 64 维零向量，
            历史号码为空时不再触发 cosine_similarity 维度报错。
        """
        _get_sklearn()
        if len(self.data) < 10:
            return random.sample(range(1, 50), count)
        
        # sklearn: PCA降维（64维→10维）后再计算cosine_similarity
        pca_based_sim = self._pca_historical_similarity() if hasattr(self, 'sklearn_features') and self.sklearn_features is not None else []
        
        # TensorFlow AutoEncoder降维相似度
        tf_sim = self._tf_autoencoder_similarity() if hasattr(self, 'tf_encoded') and self.tf_encoded is not None else []
        
        # 构建增强特征向量（one-hot 49维 + 统计特征15维 = 64维）
        def to_enhanced_vector(numbers):
            """把一期号码编码为增强特征向量（49 维 one-hot + 统计特征）

            功能：号码在 1..49 内的位置置 1（49 维 one-hot），再拼接统计特征
                （和除以 6、均值、标准差、极差、奇数个数、大数个数、5 个区间计数、
                尾数 0..3 计数）；numbers 为空时返回与正常分支一致的 64 维零向量。
            参数：
                numbers (list[int]): 号码列表（通常 6 个，1..49）。
            返回：list[float]: 49+15=64 维特征向量；空列表返回 64 维零向量。
            注意：无副作用；空列表已提前返回，不抛异常。
            """
            # 【修复空列表bug】numbers可能为空，max/min/mean会抛异常；
            # 同时保证空输入与正常输入维度一致（49 one-hot + 15 统计 = 64）
            if not numbers:
                return [0] * 64
            # one-hot编码（49维）
            vec = [0] * 49
            for n in numbers:
                if 1 <= n <= 49:
                    vec[n - 1] = 1
            # 统计特征（15维：6 项基础 + 5 个区间 + 4 个尾数），与 one-hot 49 维拼成 64 维
            stats = []
            # 除以固定 6 是“按 6 个号码取均值”的近似，非 6 号玩法会失真
            stats.append(sum(numbers) / 6)
            stats.append(np.mean(numbers))
            stats.append(np.std(numbers) if len(numbers) > 1 else 0)
            stats.append(max(numbers) - min(numbers))
            stats.append(sum(1 for n in numbers if LotteryConfig.is_odd(n)))
            stats.append(sum(1 for n in numbers if LotteryConfig.is_big(n)))
            for i in range(5):
                stats.append(sum(1 for n in numbers if LotteryConfig.get_range_index(n) == i))
            for t in [0, 1, 2, 3]:
                stats.append(sum(1 for n in numbers if LotteryConfig.get_tail_digit(n) == t))
            # 只统计尾数 0..3，4..9 未纳入特征（是否有意省略待确认）
            result = vec + stats
            assert len(result) == 64, '增强特征维度应为 64'
            return result
        
        latest = to_enhanced_vector(self.data[0].get('numbers', []))
        
        # NumPy矩阵运算计算与历史的相似度
        similarities = []
        cosine_sim = _core._cosine_similarity
        if cosine_sim is not None:
            # 跳过 data[0]（最新一期自身），最多比较其后的 49 期
            for i, record in enumerate(self.data[1:50]):
                hist = to_enhanced_vector(record.get('numbers', []))
                # sklearn cosine_similarity
                sim = cosine_sim([latest], [hist])[0][0]
                similarities.append((i + 1, sim))
        else:
            for i, record in enumerate(self.data[1:50]):
                similarities.append((i + 1, 0))
        
        # 融合PCA和TF的相似度
        if pca_based_sim:
            for idx, sim in pca_based_sim:
                for i, (old_idx, old_sim) in enumerate(similarities):
                    if old_idx == idx:
                        similarities[i] = (old_idx, old_sim * 0.5 + sim * 0.5)
                        break
        
        if tf_sim:
            for idx, sim in tf_sim:
                for i, (old_idx, old_sim) in enumerate(similarities):
                    if old_idx == idx:
                        similarities[i] = (old_idx, old_sim * 0.5 + sim * 0.5)
                        break
        
        similarities.sort(key=lambda x: x[1], reverse=True)
        top_similar = similarities[:5]
        # 取最相似 5 期投票：期数越多引入的噪声越大，5 为经验折中
        
        # 相似度加权投票
        next_numbers = []
        for idx, sim in top_similar:
            if idx + 1 < len(self.data):
                for n in self.data[idx + 1].get('numbers', []):
                    next_numbers.extend([n] * int(sim * 10 + 1))
                    # idx+1 是相似期之后（更早）的一期；相似度约 0~1，重复 1~11 次实现加权投票
        
        if next_numbers:
            counter = Counter(next_numbers)
            selected = [num for num, cnt in counter.most_common(count * 2) if cnt >= 1]
            return selected[:count]
        return random.sample(range(1, 50), count)
    
    def _pca_historical_similarity(self):
        """sklearn PCA 降维后计算余弦相似度

        功能：对标准化后的特征矩阵做 PCA 降到 min(10, 特征数) 维，以第 0 行（最新一期）
            为基准，与第 1..49 行计算余弦相似度。
        参数：无。
        返回：list[tuple[int,float]]: 元素为 (data 下标 1..49, 相似度)；不可用时返回 []。
        注意：轻量模式直接返回 []；训练 PCA（仅写局部对象，不改 self）；
            异常被捕获返回 []。
        数学含义:
            对标准化后的特征矩阵做 PCA 降到 min(10, 特征数) 维，以第 0 行（最新一期）
            为基准，与第 1..49 行计算余弦相似度。
        输入依赖:
            self.sklearn_features_scaled（未初始化时返回空列表）；sklearn 可用。
        适用场景:
            historical_similarity 的 sklearn 相似度分支。
            list[tuple[int,float]]，元素为 (data 下标 1..49, 相似度)；不可用时返回 []。
        """
        # 【修复0xC0000409】轻量模式下跳过sklearn模型训练
        if getattr(self, '_is_light_mode', False):
            return []
        try:
            _get_sklearn()
            PCA = _core._PCA
            cosine_sim = _core._cosine_similarity
            if PCA is None or cosine_sim is None:
                return []
            similarities = []
            if self.sklearn_features_scaled is None:
                return similarities
            # PCA 降到 10 维：先消除 49 维 one-hot 特征的共线性并压缩噪声，
            # 再做余弦相似度，避免高维稀疏项压过真正相似的历史期
            pca = PCA(n_components=min(10, self.sklearn_features_scaled.shape[1]))
            encoded = pca.fit_transform(self.sklearn_features_scaled)
            latest_encoded = encoded[0] if len(encoded) > 0 else self.sklearn_features_scaled[0]
            for i in range(1, min(50, len(encoded))):
                sim = cosine_sim([latest_encoded], [encoded[i]])[0][0]
                similarities.append((i, sim))
            return similarities
        except Exception:
            return []
    
    def _tf_autoencoder_similarity(self):
        """TensorFlow AutoEncoder 编码后计算余弦相似度

        功能：以 self.tf_encoded 第 0 行（最新一期）为基准，与第 1..min(49, 行数) 行
            计算余弦相似度。
        参数：无。
        返回：list[tuple[int,float]]: (下标, 相似度)；无编码/异常时返回 []。
        注意：轻量模式直接返回 []；无 self 写入；异常被捕获。
        数学含义:
            以 self.tf_encoded 第 0 行（最新一期）为基准，与第 1..min(49, 行数) 行
            计算余弦相似度。
        输入依赖:
            self.tf_encoded（非空）；sklearn 的 cosine_similarity 可用。
        适用场景:
            historical_similarity 的 AutoEncoder 相似度分支。
            list[tuple[int,float]]，(下标, 相似度)；无编码/异常时返回 []。
        """
        # 【修复0xC0000409】轻量模式下跳过sklearn调用
        if getattr(self, '_is_light_mode', False):
            return []
        _get_sklearn()
        cosine_sim = _core._cosine_similarity
        if cosine_sim is None:
            return []
        try:
            similarities = []
            if not hasattr(self, 'tf_encoded') or self.tf_encoded is None:
                return similarities
            latest_encoded = self.tf_encoded[0] if len(self.tf_encoded) > 0 else self.sklearn_features_scaled[0]
            for i in range(1, min(50, len(self.tf_encoded))):
                sim = cosine_sim([latest_encoded], [self.tf_encoded[i]])[0][0]
                similarities.append((i, sim))
            return similarities
        except Exception:
            return []
    
    def poisson_distribution(self, count=6):
        """泊松分布 - TensorFlow补充 + sklearn NB + SciPy分布 + NumPy矩阵

        功能：对每个号码把“泊松命中概率、指数分布 CDF、指数分布生存函数、5 期移动平均、
            连号条件概率、GaussianNB/TF/PyTorch 概率”按固定权重线性融合：
            base = p_poisson*0.2 + p_exp*0.2 + p_survival*0.2 + ma*0.1 + cond*0.1，
            ml = nb*0.1 + tf*0.05 + pt*0.05；按总分取 Top-count。
        参数：
            count (int): 目标个数，默认 6。
        返回：list[int]: 长度 count，1..49 按得分降序的前 count 名；不返回概率字典。
        注意：- 可能懒加载 sklearn/SciPy；
            - 无数据时 random.sample 扰动全局随机状态；
            - SciPy 缺失时各概率用 0.5 兜底，不抛异常。
        数学含义:
            对每个号码把“泊松命中概率、指数分布 CDF、指数分布生存函数、5 期移动平均、
            连号条件概率、GaussianNB/TF/PyTorch 概率”按固定权重线性融合：
            base = p_poisson*0.2 + p_exp*0.2 + p_survival*0.2 + ma*0.1 + cond*0.1，
            ml = nb*0.1 + tf*0.05 + pt*0.05；按总分取 Top-count。
        输入依赖:
            self.data / frequency / interval_stats / missing / moving_avg /
            consecutive_prob / df；可选 tf_predictions、pt_lstm_preds；
            样本 >=20 才启用 GaussianNB。
        适用场景:
            把“出现频次”建模为泊松过程、把“遗漏期数”建模为指数等待时间的启发式排序。
            list[int]，长度 count，1..49 按得分降序的前 count 名；不返回概率字典。
        TODO(待确认): exp_prob 与 survival 是互补量（CDF + SF = 1），各乘 0.2 后
            合计恒为 0.4，实际只贡献常数项，对排序无区分度。
        """
        if not self.data:
            return random.sample(range(1, 50), count)
        
        # sklearn: GaussianNB补充概率估计
        nb_probs = self._nb_missing_probs() if len(self.data) >= 20 else {}
        
        # TensorFlow概率补充
        tf_probs = self._tf_poisson_supplement() if hasattr(self, 'tf_predictions') and self.tf_predictions else {}
        
        # PyTorch LSTM概率补充
        pt_probs = self._pt_poisson_supplement() if hasattr(self, 'pt_lstm_preds') and self.pt_lstm_preds else {}
        
        # 获取scipy.stats
        scipy_st = _get_scipy_stats()
        
        # NumPy矩阵运算计算综合概率
        probabilities = {}
        for num in range(1, 50):
            # 基础泊松参数
            freq = self.frequency.get(num, 0)
            lambda_param = freq / len(self.data) if len(self.data) > 0 else 1 / 49
            # λ = 该号码平均每期出现次数；无数据时用单号先验 1/49
            
            # SciPy泊松分布概率
            if scipy_st is not None:
                poisson_prob = 1 - scipy_st.poisson.cdf(0, lambda_param * len(self.data))
                # P(X>=1)=1-P(X=0)；λ×期数 正好还原为历史出现总次数 freq
            else:
                poisson_prob = 0.5
            
            # 指数分布拟合
            stats = self.interval_stats.get(num, {})
            mean_interval = stats.get('mean', 6)
            # 平均间隔默认 6 期（49 选 6 下平均约 8 期出现一次，6 为偏乐观的经验值）
            if scipy_st is not None and mean_interval > 0:
                exp_prob = scipy_st.expon.cdf(self.missing.get(num, 50), scale=mean_interval)
                # 遗漏默认 50（≥号码总数，表示“从未出现”的保守值）
            else:
                exp_prob = 0.5
            
            # 生存函数
            if scipy_st is not None:
                survival = scipy_st.expon.sf(self.missing.get(num, 50), scale=mean_interval)
            else:
                survival = 0.5
            
            # 移动平均趋势：moving_avg 本身不依赖 DataFrame。
            # - 有 pandas 且 df 非空：沿用原有取值逻辑（行为不变）
            # - 缺 pandas（df=None）：照常读取 moving_avg，不因降级而丢掉该特征
            # - df 为空或轻量模式无 df 属性：保持原兜底 0.1
            if getattr(self, 'df', None) is not None and not self.df.empty:
                ma_trend = self.moving_avg.get(num, {}).get(5, 0.1)
            elif getattr(self, 'df', 'missing') is None:
                ma_trend = self.moving_avg.get(num, {}).get(5, 0.1)
            else:
                ma_trend = 0.1
            
            # 条件概率
            cond_prob = self.consecutive_prob.get(num, 0.01)
            
            # sklearn GaussianNB概率
            nb_prob = nb_probs.get(num, 0.02)
            
            # TensorFlow概率
            tf_prob = tf_probs.get(num, 0.02)
            
            # PyTorch概率
            pt_prob = pt_probs.get(num, 0.02)
            
            # NumPy矩阵运算融合
            base_prob = poisson_prob * 0.2 + exp_prob * 0.2 + survival * 0.2 + ma_trend * 0.1 + cond_prob * 0.1
            ml_prob = nb_prob * 0.1 + tf_prob * 0.05 + pt_prob * 0.05
            # 权重合计 1.0（0.2×3 + 0.1×2 + 0.1 + 0.05×2），保持各号码得分量纲一致
            probabilities[num] = base_prob + ml_prob
        
        sorted_nums = sorted(probabilities.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _tf_poisson_supplement(self):
        """返回 TensorFlow 预测概率的浅拷贝，供 poisson_distribution 融合

        功能：直接复制 self.tf_predictions，避免调用方改动污染模型预测字典。
        参数：无。
        返回：dict[int,float]: 预测概率副本；无 tf_predictions 时返回 {}。
        注意：无副作用（copy 避免调用方修改 self.tf_predictions）。
        """
        if not hasattr(self, 'tf_predictions') or not self.tf_predictions:
            return {}
        return self.tf_predictions.copy()
    
    def _pt_poisson_supplement(self):
        """返回 PyTorch LSTM 预测概率的浅拷贝，供 poisson_distribution 融合

        功能：直接复制 self.pt_lstm_preds，避免调用方改动污染模型预测字典。
        参数：无。
        返回：dict[int,float]: 预测概率副本；无 pt_lstm_preds 时返回 {}。
        注意：无副作用（copy 避免调用方修改 self.pt_lstm_preds）。
        """
        if not hasattr(self, 'pt_lstm_preds') or not self.pt_lstm_preds:
            return {}
        return self.pt_lstm_preds.copy()
    
    def mystical_algorithm(self, count=6):
        """玄学算法 - TensorFlow随机采样 + sklearn KMeans五行聚类 + NumPy矩阵 + PyTorch采样

        功能：以“当前年份天干对应的五行”为核心：生我五行×1.2、克我五行×0.7、
            我生五行×0.8、我克五行×0.9；再乘 TF 归一化权重、KMeans 簇号加成
            (1+簇号×0.1)、近 5 期出现次数与时间噪声，最后经 softmax(w/0.7) 不放回采样。
        参数：
            count (int): 目标个数，默认 6。
        返回：list[int]: 长度 <= count，1..49；不返回得分字典。
        注意：- np.random.rand 与 np.random.choice 扰动全局随机状态；
            - 非轻量模式懒加载 PyTorch（但本方法未重置种子）；
            - 无 self 写入。
        数学含义:
            以“当前年份天干对应的五行”为核心，对相生（生我）数字加权 1.2、相克（克我）
            加权 0.7，再叠加本年天干所生/所克五行的 0.8/0.9 系数、TF 权重、KMeans 簇号
            加成、近 5 期出现次数与时间噪声，最后经 softmax(w/0.7) 不放回采样。
        输入依赖:
            self.data、self.tf_predictions（可选）、self.kmeans_labels（可选）、
            datetime 当前时间。
        适用场景:
            纯启发式“玄学”排序，不依赖统计显著性，仅作为多样性来源。
            list[int]，长度 <= count，1..49；不返回得分字典。
        TODO(待确认): zhi_idx（地支序号）计算后未使用；五行数字分组中 21、22
            同时属于“木”和“水”；KMeans 簇号是任意标签，用 cluster_id*0.1
            作为加成缺乏语义。
        """
        now = datetime.datetime.now()
        
        # TensorFlow随机采样生成初始权重
        tf_random_weights = self._tf_mystical_weights() if hasattr(self, 'tf_predictions') and self.tf_predictions else np.ones(49)
        
        # sklearn: KMeans对五行数字组做聚类分析
        wu_xing_cluster = self._mystical_kmeans_cluster()
        
        # 天干地支计算
        tian_gan = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸']
        di_zhi = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥']
        gan_idx = (now.year - 1984) % 10
        zhi_idx = (now.year - 1984) % 12
        # 1984 年为甲子年，作为天干/地支循环起点；zhi_idx 计算后未参与后续逻辑
        
        # 五行属性
        wu_xing = {
            '甲': '木', '乙': '木', '丙': '火', '丁': '火', '戊': '土',
            '己': '土', '庚': '金', '辛': '金', '壬': '水', '癸': '水'
        }
        wu_xing_strength = {
            '木': [3, 4, 21, 22, 41, 42],
            '火': [7, 8, 17, 18, 27, 28, 37, 38, 47, 48],
            '土': [9, 10, 19, 20, 29, 30, 39, 40, 49],
            '金': [5, 6, 15, 16, 25, 26, 35, 36, 45, 46],
            '水': [1, 2, 11, 12, 21, 22, 31, 32, 43, 44]
        }
        
        # 五行生克关系
        sheng = {'木': '火', '火': '土', '土': '金', '金': '水', '水': '木'}
        ke = {'木': '土', '火': '金', '土': '水', '金': '木', '水': '火'}
        
        current_element = wu_xing.get(tian_gan[gan_idx % 10], '土')
        Sheng_element = sheng.get(current_element, '')
        Ke_element = ke.get(current_element, '')
        
        # NumPy矩阵运算融合多源权重
        base_weights_np = np.ones(49)
        
        # 基于五行加权
        # 0.8/0.9 轻度抑制“我生/我克”的五行；1.2/0.7 放大“生我/克我”的五行（系数为经验值）
        for num in range(1, 50):
            idx = num - 1
            if Sheng_element:
                for wu_num in wu_xing_strength.get(Sheng_element, []):
                    if num == wu_num:
                        base_weights_np[idx] *= 0.8
            if Ke_element:
                for wu_num in wu_xing_strength.get(Ke_element, []):
                    if num == wu_num:
                        base_weights_np[idx] *= 0.9
            for element, nums in wu_xing_strength.items():
                if sheng.get(element, '') == current_element and num in nums:
                    base_weights_np[idx] *= 1.2
                if ke.get(element, '') == current_element and num in nums:
                    base_weights_np[idx] *= 0.7
        
        # 融合TensorFlow权重
        base_weights_np *= tf_random_weights
        
        # sklearn KMeans聚类加成
        for num, cluster_id in wu_xing_cluster.items():
            base_weights_np[num - 1] *= (1.0 + cluster_id * 0.1)
            # TODO(待确认): 簇号是任意标签，cluster_id 越大权重越大并无实际语义
        
        # 融合历史数据
        if self.data:
            for i, record in enumerate(self.data[:5]):
                weight = (5 - i) * 0.1
                for num in record.get('numbers', []):
                    if 1 <= num <= 49:
                        base_weights_np[num - 1] += weight
        
        # 时间因子
        time_factor = now.hour * 60 + now.minute
        time_bonus = (time_factor % 10) / 100
        # 取分钟数个位作为 0~0.09 的微小扰动，使同一套权重在不同时刻略有差异
        base_weights_np += np.random.rand(49) * time_bonus
        
        # PyTorch加权采样（无PyTorch时使用NumPy替代）
        # 【修复0xC0000409】轻量模式下跳过PyTorch懒加载
        if not getattr(self, '_is_light_mode', False):
            torch_mod = _get_torch()
        else:
            torch_mod = None
        if torch_mod is not None and self.device is not None:
            base_weights = torch_mod.tensor(base_weights_np, dtype=torch_mod.float32, device=self.device)
            probs = torch_mod.softmax(base_weights / 0.7, dim=0)
            # 0.7 为温度：<1 使分布更尖锐，偏向高权重号码
            probs_np = probs.cpu().numpy()
        else:
            # NumPy替代实现
            logits = base_weights_np / 0.7
            probs_np = np.exp(logits - np.max(logits))  # 数值稳定的softmax
            probs_np = probs_np / probs_np.sum()
        
        # 【修复】初始化可选数字列表和已选列表（原代码缺失这两行导致NameError）
        available = list(range(1, 50))
        selected = []

        for _ in range(count):
            if not available:
                break
            # 【修复】probs_np是0-based索引，available中数字为1-based，需转换为0-based索引
            avail_idx = [n - 1 for n in available]
            probs_sum = probs_np[avail_idx].sum()
            if probs_sum <= 0:
                probs_sum = 1
            probs_normalized = probs_np[avail_idx] / probs_sum
            # 修正浮点精度误差，确保概率和严格为1
            diff = 1.0 - probs_normalized.sum()
            probs_normalized[-1] += diff
            # 把浮点误差补偿到最后一个可用号码，保证 np.random.choice 的概率和严格为 1
            idx = np.random.choice(len(available), p=probs_normalized)
            num = available[idx]
            selected.append(num)
            probs_np[num - 1] = 0
            available.remove(num)
        
        return selected
    
    def _tf_mystical_weights(self):
        """TensorFlow 概率归一化为玄学权重

        功能：取 tf_predictions 的 1..49 概率，除以总和再乘 49，使权重均值为 1。
        参数：无。
        返回：numpy.ndarray: shape (49,)；无预测或异常时返回全 1 数组。
        注意：无副作用（只读 self.tf_predictions）；异常被捕获。
        数学含义:
            取 tf_predictions 的 1..49 概率，除以总和再乘 49，使权重均值为 1。
        """
        if not hasattr(self, 'tf_predictions') or not self.tf_predictions:
            return np.ones(49)
        try:
            weights = np.array([self.tf_predictions.get(n, 0.02) for n in range(1, 50)])
            weights = weights / weights.sum() * 49  # 归一化
            return weights
        except Exception:
            return np.ones(49)
    
    def _mystical_kmeans_cluster(self):
        """把 self.kmeans_labels 映射为 号码 -> 簇号

        功能：按 0-based 下标把 kmeans_labels[i] 映射为号码 i+1 的簇号。
        参数：无。
        返回：dict[int,int]: 键 1..49，值簇号；无标签或异常时为空/部分映射。
        注意：无副作用；kmeans_labels 长度不足 49 时异常在循环中途抛出，
            返回截断的部分映射而非空字典（见 TODO）。
        输入依赖:
            self.kmeans_labels（长度至少 49；缺失时返回空字典）。
            dict[int,int]，键 1..49，值簇号；无标签或异常时为空/部分映射。
        TODO(待确认): 若 kmeans_labels 长度不足 49，异常会在循环中途抛出，
            返回的是截断的部分映射，而非空字典。
        """
        cluster_map = {}
        if not hasattr(self, 'kmeans_labels') or self.kmeans_labels is None:
            return cluster_map
        try:
            for num in range(1, 50):
                cluster_map[num] = self.kmeans_labels[num - 1]
        except Exception:
            pass
        return cluster_map
    
    # 4个NetworkX图算法新增
    
    def _build_number_graph(self):
        """构建号码共现图 - NetworkX Graph

        功能：49 个号码为节点，节点属性 missing/freq；同一期内任意两个号码之间加一条边，
            边权为共现次数（每期每对号码贡献 1 次）。
        参数：无。
        返回：networkx.Graph: 共现图；NetworkX 不可用时返回 None。
        注意：懒加载 NetworkX；不修改 self；节点数固定 49，边数随历史期数增长。
        数学含义:
            49 个号码为节点，节点属性 missing/freq；同一期内任意两个号码之间加一条边，
            边权为共现次数（每期每对号码贡献 1 次）。
        输入依赖:
            self.data、self.missing、self.frequency；NetworkX 可用。
        适用场景:
            号码关联、社区发现、图聚类等算法的公共输入。
            networkx.Graph；NetworkX 不可用时返回 None。
        """
        nx = _get_nx()
        if nx is None:
            return None
        G = nx.Graph()
        # 添加49个节点
        for num in range(1, 50):
            G.add_node(num, missing=self.missing.get(num, 50), freq=self.frequency.get(num, 0))
        # 添加共现边
        for record in self.data:
            numbers = record.get('numbers', [])
            for i in range(len(numbers)):
                for j in range(i + 1, len(numbers)):
                    n1, n2 = numbers[i], numbers[j]
                    if G.has_edge(n1, n2):
                        G[n1][n2]['weight'] += 1
                    else:
                        G.add_edge(n1, n2, weight=1)
        return G
    
    def _build_transition_graph(self):
        """构建号码转移图 - NetworkX DiGraph

        功能：49 个节点；对相邻两期 (data[i], data[i+1]) 从前一期号码连向后一期号码，
            边权累加转移次数。
        参数：无。
        返回：networkx.DiGraph: 转移有向图；NetworkX 不可用时返回 None。
        注意：懒加载 NetworkX；不修改 self；
            data 最新在前，故 i -> i+1 的边实为“较新期 → 较旧期”（见 TODO）。
        数学含义:
            49 个节点；对相邻两期 (data[i], data[i+1])，从前一期号码连向后一期号码，
            边权累加转移次数。
        输入依赖:
            self.data；NetworkX 可用。
        适用场景:
            shortest_path_algorithm 的 Dijkstra 图输入。
            networkx.DiGraph；NetworkX 不可用时返回 None。
        TODO(待确认): data 以“最新在前”排序（data[0] 最新），因此 i -> i+1 的边
            实际是“较新期 → 较旧期”，与通常“上一期→下一期”的转移方向相反。
        """
        nx = _get_nx()
        if nx is None:
            return None
        DG = nx.DiGraph()
        for num in range(1, 50):
            DG.add_node(num)
        # 统计号码转移
        for i in range(len(self.data) - 1):
            curr_nums = set(self.data[i].get('numbers', []))
            next_nums = set(self.data[i + 1].get('numbers', []))
            for n1 in curr_nums:
                for n2 in next_nums:
                    if DG.has_edge(n1, n2):
                        DG[n1][n2]['weight'] += 1
                    else:
                        DG.add_edge(n1, n2, weight=1)
        return DG
    
    def number_graph_algorithm(self, count=6):
        """号码关联图算法 - NetworkX PageRank/度中心性/介数中心性（无NetworkX时使用基础统计）

        功能：在共现图上计算 PageRank（随机游走平稳分布，默认 alpha=0.85）、
            度中心性、介数中心性，按 pr*50 + dc*30 + bc*20 + 遗漏回补*10 综合排序。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 得分 Top-count，1..49；不返回得分字典。
        注意：- 懒加载 NetworkX；无 self 写入；
            - 无 NetworkX 时走 _nx_number_graph_fallback；
            - 图算法异常时降级为 _get_weighted_score，数据 <10 期或无边时随机返回。
        数学含义:
            在共现图上计算 PageRank（随机游走平稳分布，NetworkX 默认 alpha=0.85）、
            度中心性、介数中心性，按 pr*50 + dc*30 + bc*20 + 遗漏回补*10 综合排序。
        输入依赖:
            self.data（>=10 期）、self.missing、self.frequency；NetworkX 可用。
        适用场景:
            利用号码共现结构的中心性排序，偏好“与热门号码常同现”的号码。
            list[int]，得分 Top-count，1..49；不返回得分字典。
        TODO(待确认): betweenness_centrality(weight='weight') 把共现次数当“距离”，
            共现越强反而路径越远，语义与“关联强度”相反。
        """
        if len(self.data) < 10:
            return random.sample(range(1, 50), count)
        
        # 无NetworkX时使用基础统计方法
        nx = _get_nx()
        if nx is None:
            return self._nx_number_graph_fallback(count)
        
        # 构建共现图
        G = self._build_number_graph()
        if G.number_of_edges() == 0:
            return random.sample(range(1, 50), count)
        
        scores = {}
        try:
            # NetworkX PageRank中心性
            pagerank = nx.pagerank(G, weight='weight')
            # NetworkX 度中心性
            degree_cent = nx.degree_centrality(G)
            # NetworkX 介数中心性
            betweenness = nx.betweenness_centrality(G, weight='weight')
            # 融合多中心性
            for num in range(1, 50):
                pr = pagerank.get(num, 0)
                dc = degree_cent.get(num, 0)
                bc = betweenness.get(num, 0)
                # 遗漏回补加成
                miss = self.missing.get(num, 50)
                miss_bonus = MathUtils.calculate_missing_cycle(miss, 6)
                # 综合得分
                scores[num] = pr * 50 + dc * 30 + bc * 20 + miss_bonus * 10
                # 50/30/20/10 为经验权重：PageRank 主导，度/介数次之，遗漏回补只作修正
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def shortest_path_algorithm(self, count=6):
        """最短路径算法 - NetworkX Dijkstra号码转移分析（无NetworkX时使用基础统计）

        功能：在转移图上以最新一期号码为源点，对每个目标求 Dijkstra 最短路长 d，
            得分 = 30/(d_min+1) + 20*Σ1/(d_source+1) + 30*特征向量中心性 + 20*遗漏回补。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: Top-count，1..49；不返回得分字典。
        注意：- 懒加载 NetworkX；eigenvector_centrality max_iter=1000，图较大时较慢；
            - 无路径时跳过该源点；异常降级到 _get_weighted_score；
            - 无 NetworkX 时走 _nx_shortest_path_fallback。
        数学含义:
            在转移图上，以最新一期号码为源点，对每个目标求 Dijkstra 最短路长度 d，
            得分 = 30/(d+1) + 20*Σ1/(d_source+1) + 30*特征向量中心性 + 20*遗漏回补。
        输入依赖:
            self.data（>=10 期）、self.missing；NetworkX 可用。
        适用场景:
            利用“号码间转移可达性”寻找下一期候选。
            list[int]，Top-count，1..49；不返回得分字典。
        TODO(待确认): 边权为转移次数，Dijkstra 中权越大路径越“长”，
            强转移反而不利于得分；且转移方向为“新→旧”，见 _build_transition_graph。
        """
        if len(self.data) < 10:
            return random.sample(range(1, 50), count)
        
        # 无NetworkX时使用基础统计方法
        nx = _get_nx()
        if nx is None:
            return self._nx_shortest_path_fallback(count)
        
        DG = self._build_transition_graph()
        if DG.number_of_edges() == 0:
            return random.sample(range(1, 50), count)
        
        scores = {}
        try:
            latest_nums = self.data[0].get('numbers', [])
            # 预计算特征向量中心性（避免循环内重复计算整个图）
            try:
                eigen_cent = nx.eigenvector_centrality(DG, weight='weight', max_iter=1000)
            except Exception:
                eigen_cent = {}
            # NetworkX Dijkstra最短路径
            for target in range(1, 50):
                min_dist = float('inf')
                total_prob = 0.0
                for source in latest_nums:
                    try:
                        path_length = nx.dijkstra_path_length(DG, source, target, weight='weight')
                        path_prob = 1.0 / (path_length + 1)
                        min_dist = min(min_dist, path_length)
                        total_prob += path_prob
                    except nx.NetworkXNoPath:
                        continue
                # 特征向量中心性（使用预计算结果）
                eigen = eigen_cent.get(target, 0)
                # 遗漏加成
                miss = self.missing.get(target, 50)
                miss_bonus = MathUtils.calculate_missing_cycle(miss, 6)
                # 综合得分
                scores[target] = (1.0 / (min_dist + 1)) * 30 + total_prob * 20 + eigen * 30 + miss_bonus * 20
                # 1/(d+1) 把最短路距离映射到 (0,1]；30/20/30/20 为经验权重
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def community_detection_algorithm(self, count=6):
        """社区发现算法 - NetworkX Louvain社区检测（无NetworkX时使用基础统计）

        功能：用 greedy_modularity_communities（贪心模块度最大化）划分共现图社区；
            号码与最新一期号码同社区给 5 分、否则 1 分，再叠加加权度×0.5、
            PageRank×50 与遗漏回补×10。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: Top-count，1..49；不返回得分字典。
        注意：- 懒加载 NetworkX；PageRank 已预计算一次；
            - 无 NetworkX 时走 _nx_community_fallback，异常降级到 _get_weighted_score；
            - 数据 <15 期或边数 <5 时随机返回。
        数学含义:
            用 greedy_modularity_communities（Louvain 类贪心模块度最大化，默认分辨率 1）
            划分共现图社区；号码与最新一期号码同社区给 5 分、否则 1 分，
            再叠加加权度、PageRank 与遗漏回补。
        输入依赖:
            self.data（>=15 期，门槛高于其它图算法）、self.missing；NetworkX 可用。
        适用场景:
            寻找与最新一期“同社区”的号码，强调局部聚集结构。
            list[int]，Top-count，1..49；不返回得分字典。
        TODO(待确认): 建图包含 data[0]（最新一期）本身，目标社区由最新号码确定，
            预测下一期时存在“用当期信息选当期社区”的泄漏风险。
        """
        if len(self.data) < 15:
            return random.sample(range(1, 50), count)
        
        # 无NetworkX时使用基础统计方法
        nx = _get_nx()
        if nx is None:
            return self._nx_community_fallback(count)
        
        G = self._build_number_graph()
        if G.number_of_edges() < 5:
            return random.sample(range(1, 50), count)
        
        scores = {}
        try:
            # NetworkX Louvain社区检测 (greedy_modularity)
            communities = list(nx.community.greedy_modularity_communities(G, weight='weight'))
            # 找出最新一期号码所在的社区
            latest_nums = set(self.data[0].get('numbers', []))
            target_communities = set()
            for idx, comm in enumerate(communities):
                if latest_nums & comm:  # 有交集
                    target_communities.add(idx)
            
            # 预计算PageRank（避免循环内重复计算整个图）
            pagerank_dict = nx.pagerank(G, weight='weight')
            
            # 统计每个社区的得分
            for num in range(1, 50):
                # 找到该号码所在的社区
                num_community = -1
                for idx, comm in enumerate(communities):
                    if num in comm:
                        num_community = idx
                        break
                
                # 与目标社区的关联度
                community_score = 5 if num_community in target_communities else 1
                # 社区内连接强度
                degree_in_comm = G.degree(num, weight='weight') if G.has_node(num) else 0
                # PageRank（使用预计算结果）
                pagerank = pagerank_dict.get(num, 0)
                # 遗漏加成
                miss = self.missing.get(num, 50)
                miss_bonus = MathUtils.calculate_missing_cycle(miss, 6)
                
                scores[num] = community_score * 15 + degree_in_comm * 0.5 + pagerank * 50 + miss_bonus * 10
                # community_score 取 5/1，×15 使同社区号码领先约 60 分；degree_in_comm 实为加权度（强度）
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def graph_clustering_algorithm(self, count=6):
        """图聚类算法 - NetworkX连通分量/k-clique聚类（无NetworkX时使用基础统计）

        功能：用连通分量与 3-clique 社区刻画号码聚集：与最新号码同连通分量给 10 分
            （否则 1），再叠加分量大小×0.5、k-clique 规模×2、聚类系数×20、
            基础分×20 与遗漏回补×10。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: Top-count，1..49；不返回得分字典。
        注意：- 懒加载 NetworkX；无 self 写入；
            - 无 NetworkX 时走 _nx_clustering_fallback，k_clique 失败时置空，整体异常降级；
            - 数据 <10 期或边数 <3 时随机返回。
        数学含义:
            用连通分量与 3-clique 社区刻画号码聚集：命中最新号码所在连通分量给 10 分
            （否则 1），再叠加分量大小、k-clique 规模、聚类系数、基础分与遗漏回补。
        输入依赖:
            self.data（>=10 期）、self.missing；NetworkX 可用。
        适用场景:
            偏好与最新一期处于同一连通结构的号码。
            list[int]，Top-count，1..49；不返回得分字典。
        TODO(待确认): nx.clustering 未传 weight，忽略共现强度；
            目标分量同样由 data[0] 自身决定，存在当期信息泄漏。
        """
        if len(self.data) < 10:
            return random.sample(range(1, 50), count)
        
        # 无NetworkX时使用基础统计方法
        nx = _get_nx()
        if nx is None:
            return self._nx_clustering_fallback(count)
        
        G = self._build_number_graph()
        if G.number_of_edges() < 3:
            return random.sample(range(1, 50), count)
        
        scores = {}
        try:
            # NetworkX 连通分量分析
            components = list(nx.connected_components(G))
            # NetworkX k-clique社区检测
            kclique_communities = []
            try:
                kclique_communities = list(nx.community.k_clique_communities(G, 3))
            except Exception:
                kclique_communities = []
            
            # 找出热门连通分量
            latest_nums = set(self.data[0].get('numbers', []))
            target_components = []
            for comp in components:
                if len(comp & latest_nums) > 0:
                    target_components.append(comp)
            
            # k-clique社区得分
            kclique_scores = {}
            for num in range(1, 50):
                kclique_scores[num] = 0
                for comm in kclique_communities:
                    if num in comm:
                        kclique_scores[num] += len(comm)
            
            for num in range(1, 50):
                # 所在连通分量大小
                comp_size = 0
                for comp in components:
                    if num in comp:
                        comp_size = len(comp)
                        break
                # 与目标连通分量的关联
                in_target = any(num in comp for comp in target_components)
                target_bonus = 10 if in_target else 1
                # k-clique得分
                kc_score = kclique_scores.get(num, 0)
                # 聚类系数
                clustering_coeff = nx.clustering(G, num) if G.has_node(num) else 0
                # 基础特征得分
                base_score = self._get_weighted_score(num) / 100
                # 遗漏加成
                miss = self.missing.get(num, 50)
                miss_bonus = MathUtils.calculate_missing_cycle(miss, 6)
                
                scores[num] = (target_bonus * 10 + comp_size * 0.5 + kc_score * 2 + 
                              clustering_coeff * 20 + base_score * 20 + miss_bonus * 10)
                # 10/1 为目标分量奖励差；comp_size、kc_score、聚类系数与遗漏的系数均为经验值
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def numpy_matrix_algorithm(self, count=6):
        """NumPy矩阵算法 - 基于NumPy矩阵运算深度分析预测

        功能：构造 49×8 特征矩阵（频率、遗漏、MA5/10/20、自相关、zscore、尾数频率），
            经 SVD 前 3 个右奇异向量投影、np.corrcoef 选 4 个最相关特征、四分位分档、
            三阶多项式外推遗漏、np.histogram 热区，按
            0.25/0.2/0.15/0.15/0.1/0.1/0.03/0.02 的权重汇总为每个号码的得分。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: Top-count，1..49；不返回得分字典。
        注意：无重型库懒加载；不修改 self；SVD/整体异常时降级到 _get_weighted_score。
        数学含义:
            构造 49×8 特征矩阵（频率、遗漏、MA5/10/20、自相关、zscore、尾数频率），
            经 SVD 取前 3 个右奇异向量投影、相关系数选 4 个最相关特征、四分位分档、
            三阶多项式外推遗漏、直方图热区，按固定权重汇总为每个号码的得分。
        输入依赖:
            self.data（>=10 期）、frequency/missing/moving_avg/autocorrelation/
            interval_stats/tail_distribution。
        适用场景:
            纯 NumPy 的多视角特征融合排序，无需 sklearn/TensorFlow。
            list[int]，Top-count，1..49；不返回得分字典。
        TODO(待确认): np.corrcoef 遇到常量特征列会返回 NaN，可能污染 corr_score 与排序；
            多项式自变量是“号码序号”，预测的是虚拟第 n+1 个号码的遗漏，而非下一期遗漏。
        """
        if len(self.data) < 10:
            return random.sample(range(1, 50), count)
        
        scores = {}
        try:
            # 构建49个数字的特征矩阵
            feature_matrix = np.zeros((49, 8), dtype=np.float32)
            # 8 列依次为 freq、miss、ma5、ma10、ma20、autocorr、zscore、tail_freq；
            # 行号 num-1 对应号码 num
            for num in range(1, 50):
                freq = self.frequency.get(num, 0)
                miss = min(self.missing.get(num, 50), 50)
                # 遗漏截断到 50，避免极端值把其它特征压扁
                ma5 = self.moving_avg.get(num, {}).get(5, 0.1)
                ma10 = self.moving_avg.get(num, {}).get(10, 0.1)
                ma20 = self.moving_avg.get(num, {}).get(20, 0.1)
                autocorr = self.autocorrelation.get(num, 0)
                zscore = self.interval_stats.get(num, {}).get('zscore', 0)
                tail = LotteryConfig.get_tail_digit(num)
                tail_freq = self.tail_distribution.get(tail, 1)
                
                feature_matrix[num-1] = [freq, miss, ma5*100, ma10*100, ma20*100, 
                                        autocorr*100, zscore*10, tail_freq]
            
            # np.linalg.svd奇异值分解降维
            try:
                U, s, Vt = np.linalg.svd(feature_matrix, full_matrices=False)
                # 取前3个奇异值对应的特征
                svd_features = np.dot(feature_matrix, Vt[:3].T)
                # 取前 3 个右奇异向量投影：保留主要结构、降低随机噪声
            except Exception:
                svd_features = feature_matrix[:, :3]
            
            # np.corrcoef计算特征相关性矩阵
            corr_matrix = np.corrcoef(feature_matrix.T)
            # TODO(待确认): 任一特征列为常量时相关系数为 NaN，会向下污染 corr_score
            # 取与频率相关性最高的特征
            freq_corr = corr_matrix[0]
            top_corr_idx = np.argsort(np.abs(freq_corr))[::-1][:4]
            # 按相关系数绝对值降序取前 4 个特征（含频率自身，相关系数恒为 1）
            
            # np.percentile计算分位数
            freq_percentiles = np.percentile(feature_matrix[:, 0], [25, 50, 75])
            miss_percentiles = np.percentile(feature_matrix[:, 1], [25, 50, 75])
            
            # np.vander构建多项式基进行遗漏趋势预测
            n = min(20, len(self.data))
            y_miss = np.array([self.missing.get(i+1, 50) for i in range(n)], dtype=np.float64)
            X_poly = np.vander(np.arange(n), 3)  # 三阶多项式基
            # 自变量为号码序号 0..n-1，外推 x=n 得到的是虚拟第 n+1 个号码的遗漏，而非下期遗漏
            coeffs, residuals, rank, s_val = np.linalg.lstsq(X_poly, y_miss, rcond=None)
            next_x = np.array([[n**2, n, 1]])
            predicted_missing = np.dot(next_x, coeffs)[0]
            
            # np.histogram分析频率分布
            hist, bin_edges = np.histogram(feature_matrix[:, 0], bins=10)
            hot_bin_idx = np.argmax(hist)
            hot_bin_range = (bin_edges[hot_bin_idx], bin_edges[hot_bin_idx+1])
            
            # np.dot矩阵乘法计算综合得分
            weights = np.array([0.25, 0.2, 0.15, 0.15, 0.1, 0.1, 0.03, 0.02])
            # 固定权重合计 1.0，与 8 列特征一一对应，属经验配置
            for num in range(1, 50):
                # 基础得分
                base_score = np.dot(feature_matrix[num-1], weights)
                
                # SVD特征得分
                svd_score = np.linalg.norm(svd_features[num-1])
                
                # 相关性加权得分
                corr_score = sum(feature_matrix[num-1, top_corr_idx[i]] * (1.0 / (i+1)) 
                                for i in range(len(top_corr_idx)))
                
                # 分位数位置得分
                freq_val = feature_matrix[num-1, 0]
                miss_val = feature_matrix[num-1, 1]
                if freq_val >= freq_percentiles[2]:
                    percentile_score = 20
                elif freq_val >= freq_percentiles[1]:
                    percentile_score = 15
                elif freq_val >= freq_percentiles[0]:
                    percentile_score = 10
                else:
                    percentile_score = 5
                
                if miss_val <= miss_percentiles[0]:
                    miss_percentile_score = 20
                elif miss_val <= miss_percentiles[1]:
                    miss_percentile_score = 15
                elif miss_val <= miss_percentiles[2]:
                    miss_percentile_score = 10
                else:
                    miss_percentile_score = 5
                
                # 遗漏趋势偏离得分
                miss_deviation = abs(feature_matrix[num-1, 1] - predicted_missing)
                trend_score = max(0, 15 - miss_deviation * 0.5)
                
                # 分布热区得分
                dist_score = 10 if hot_bin_range[0] <= feature_matrix[num-1, 0] <= hot_bin_range[1] else 3
                
                # 综合得分
                scores[num] = (base_score * 20 + svd_score * 5 + corr_score * 3 + 
                             percentile_score * 3 + miss_percentile_score * 3 + 
                             trend_score * 5 + dist_score * 2)
                # 20/5/3/3/3/5/2 为经验缩放，使量纲不同的子得分可比较
            
        except Exception as e:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def scipy_optimization_algorithm(self, count=6):
        """SciPy优化算法 - 基于SciPy科学计算优化预测

        功能：用高斯核（窗口 7、σ=1.5）平滑频率，用 Nelder-Mead 最小化 objective 求
            5 个归一化权重（频率、遗漏、趋势、相关、区间），再用逐号码样条外推下一期遗漏、
            正态/指数分布拟合与 KS 检验，按优化权重汇总为每个号码的得分。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: Top-count，1..49；不返回得分字典。
        注意：- 懒加载 SciPy 各子模块；
            - Nelder-Mead 最多 100 次迭代，耗时随数据量增长；
            - scipy_opt 缺失直接随机返回；其余异常降级到 _get_weighted_score，
              降级路径的 random.sample 扰动全局随机状态。
        数学含义:
            用高斯核平滑频率，用 Nelder-Mead 最小化负加权得分求 5 个权重（频率、遗漏、
            趋势、相关、区间），再用样条插值外推遗漏、正态/指数分布拟合与 KS 检验，
            汇总为每个号码的得分。
        输入依赖:
            self.data（>=10 期）、frequency/missing/moving_avg/correlation_matrix/
            range_distribution；SciPy 的 signal/optimize/interpolate/stats 可用。
        适用场景:
            需要连续优化权重与分布检验的启发式排序。
            list[int]，Top-count，1..49；不返回得分字典。
        TODO(待确认): 变量 poisson 取到后未使用。
            v0.0.45 已修复 interp_missing：改为逐号码时间序列样条外推下一期
            （见 _predict_next_missing_by_spline），不再共用常量键 1。
        """
        if len(self.data) < 10:
            return random.sample(range(1, 50), count)
        
        scores = {}
        try:
            # scipy.signal.convolve高斯平滑趋势
            scipy_sig = _get_scipy_signal()
            scipy_opt = _get_scipy_optimize()
            scipy_int = _get_scipy_interpolate()
            scipy_st = _get_scipy_stats()
            
            freq_array = np.array([self.frequency.get(i, 0) for i in range(1, 50)], dtype=np.float32)
            # 高斯核
            if scipy_sig is not None:
                try:
                    gauss_kernel = scipy_sig.windows.gaussian(7, std=1.5)
                    # 窗口 7、标准差 1.5：覆盖约 ±2σ，兼顾平滑与保留局部峰值
                except AttributeError:
                    gauss_kernel = scipy_sig.gaussian(7, std=1.5)
                gauss_kernel = gauss_kernel / gauss_kernel.sum()
                smoothed_freq = scipy_sig.convolve(freq_array, gauss_kernel, mode='same')
            else:
                smoothed_freq = freq_array
            
            # scipy.optimize.minimize权重优化
            if scipy_opt is None:
                return random.sample(range(1, 50), count)
            minimize = scipy_opt.minimize
            
            def objective(params):
                """SciPy minimize 的负加权得分目标函数

                功能：先把 5 个参数归一化为 w_freq/w_miss/w_trend/w_corr/w_range，
                    再对 1..49 求加权特征和 score，返回 -score 供 minimize 最小化。
                参数：
                    params (list[float]): 5 个非负权重，顺序为频率、遗漏、趋势、相关、区间。
                返回：float: 权重和为 0 时返回 0，否则返回 -score。
                注意：无副作用（只读 self 的统计属性）；除零处已特判。
                数学含义:
                    先把 5 个参数归一化为 w_freq/w_miss/w_trend/w_corr/w_range，
                    再对 1..49 求加权特征和 score，返回 -score 供 minimize 最小化。
                TODO(待确认): 原 docstring 写“Optuna 优化目标函数”，实际由 SciPy
                    minimize 调用，与 Optuna 无关。
                """
                w_freq, w_miss, w_trend, w_corr, w_range = params
                total_w = w_freq + w_miss + w_trend + w_corr + w_range
                if total_w == 0:
                    return 0
                    # TODO(待确认): 权重全 0 时返回 0，会被 minimize 当成最优解；更合理是返回大惩罚值
                w_freq, w_miss, w_trend, w_corr, w_range = [p/total_w for p in params]
                
                score = 0
                for num in range(1, 50):
                    freq_s = self.frequency.get(num, 0) / len(self.data) if self.data else 0
                    miss_s = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                    ma5 = self.moving_avg.get(num, {}).get(5, 0.1)
                    ma20 = self.moving_avg.get(num, {}).get(20, 0.1)
                    trend_s = ma5 - ma20 + 0.1
                    
                    corr_s = 0
                    if len(self.data) > 0:
                        latest_nums = self.data[0].get('numbers', [])
                        # 【修复除零+越界bug】latest_nums可能为空导致除零；
                        # 号码可能不在1-49范围内导致correlation_matrix索引越界
                        valid_nums = [n for n in latest_nums if 1 <= n <= 49]
                        if valid_nums:
                            corr_s = sum(self.correlation_matrix[num-1, n-1] for n in valid_nums) / len(valid_nums)
                    
                    range_idx = LotteryConfig.get_range_index(num)
                    # 【修复除零bug】range_distribution值之和可能为0
                    range_total = sum(self.range_distribution.values()) or 1
                    range_s = 1 - self.range_distribution.get(range_idx, 0) / range_total
                    
                    score += (w_freq * freq_s + w_miss * miss_s + w_trend * trend_s + 
                             w_corr * corr_s + w_range * range_s)
                return -score  # minimize，所以取负
            
            # 优化权重
            x0 = [0.25, 0.25, 0.2, 0.15, 0.15]
            # 初始权重与后续融合比例一致；Nelder-Mead 无需梯度，适合 5 维连续优化
            result = minimize(objective, x0, method='Nelder-Mead', 
                           options={'maxiter': 100, 'disp': False})
            opt_weights = result.x
            total_w = sum(opt_weights)
            opt_weights = [w/total_w if total_w > 0 else 1/5 for w in opt_weights]
            
            # scipy.interpolate样条插值预测遗漏趋势
            if scipy_int is not None:
                splrep = scipy_int.splrep
                splev = scipy_int.splev
            else:
                splrep = None
                splev = None
            # 【口径修复】原实现以“号码序号”为 x、以 1..30 号遗漏为 y 拟合，
            # 再外推 x=30/31/32 得到的是“第 31/32/33 个号码”的遗漏，循环里却固定取键 1，
            # 导致 49 个号码共用同一个常量分。现改为逐号码、逐期的时间外推：
            # 每个号码用自己的旧→新遗漏序列拟合样条，外推 x=N（下一期），得到逐号码预测。
            interp_missing = self._predict_next_missing_by_spline(splrep, splev)
            if not interp_missing:
                # 无 SciPy 或数据不足时回退为各号码当前遗漏，保持逐号码差异
                interp_missing = {num: self.missing.get(num, 50) for num in range(1, 50)}
            
            # scipy.stats.poisson分布建模
            poisson = None
            expon = None
            norm = None
            ks_2samp_func = None
            if scipy_st is not None:
                poisson = getattr(scipy_st, 'poisson', None)
                # TODO(待确认): poisson 取出后未被使用
                expon = getattr(scipy_st, 'expon', None)
                norm = getattr(scipy_st, 'norm', None)
                ks_2samp_func = getattr(scipy_st, 'ks_2samp', None)
            # 拟合泊松分布
            intervals_all = []
            for num in range(1, 50):
                intervals = []
                last_appeared = None
                for i, record in enumerate(self.data):
                    if num in record.get('numbers', []):
                        if last_appeared is not None:
                            intervals.append(i - last_appeared)
                        last_appeared = i
                intervals_all.extend(intervals)
            
            mu, std = 0, 1
            loc_exp, scale_exp = 0, 1
            if intervals_all and norm is not None and expon is not None:
                # 拟合正态分布参数
                mu, std = norm.fit(intervals_all)
                # 拟合指数分布
                loc_exp, scale_exp = expon.fit(intervals_all)
            
            # scipy.stats.ks_2samp分布一致性检验
            for num in range(1, 50):
                intervals = []
                last_appeared = None
                for i, record in enumerate(self.data):
                    if num in record.get('numbers', []):
                        if last_appeared is not None:
                            intervals.append(i - last_appeared)
                        last_appeared = i
                
                # KS检验得分
                if intervals and intervals_all and ks_2samp_func is not None:
                    try:
                        ks_stat, ks_pval = ks_2samp_func(intervals, intervals_all)
                        ks_score = ks_pval * 10  # p值越高说明越符合整体分布
                        # 10 为放大系数，把 0~1 的 p 值映射到 0~10 分
                    except Exception:
                        ks_score = 5
                else:
                    ks_score = 5
                
                # 计算综合得分
                freq_s = self.frequency.get(num, 0) / len(self.data) if self.data else 0
                miss_s = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                ma5 = self.moving_avg.get(num, {}).get(5, 0.1)
                ma20 = self.moving_avg.get(num, {}).get(20, 0.1)
                trend_s = ma5 - ma20 + 0.1
                
                corr_s = 0
                if len(self.data) > 0:
                    latest_nums = self.data[0].get('numbers', [])
                    # 【修复除零+越界bug】latest_nums可能为空导致除零；
                    # 号码可能不在1-49范围内导致correlation_matrix索引越界
                    valid_nums = [n for n in latest_nums if 1 <= n <= 49]
                    if valid_nums:
                        corr_s = sum(self.correlation_matrix[num-1, n-1] for n in valid_nums) / len(valid_nums)
                
                range_idx = LotteryConfig.get_range_index(num)
                # 【修复除零bug】range_distribution值之和可能为0
                range_total = sum(self.range_distribution.values()) or 1
                range_s = 1 - self.range_distribution.get(range_idx, 0) / range_total
                
                # 平滑后的频率得分
                smooth_freq = smoothed_freq[num-1] if num-1 < len(smoothed_freq) else freq_s
                
                # 插值预测遗漏得分：interp_missing 已按号码给出“下一期”遗漏预测
                interp_miss = interp_missing.get(num, self.missing.get(num, 50))
                # 当前遗漏与下一期预测遗漏越接近，说明该号码的冷热节奏越可解释
                interp_miss_score = max(0, 10 - abs(self.missing.get(num, 50) - interp_miss) * 0.3)
                
                # 分布拟合得分
                dist_score = 5
                if intervals and norm is not None and expon is not None:
                    try:
                        norm_prob = norm.pdf(self.missing.get(num, 50), mu, std) if std > 0 else 0.02
                        exp_prob = expon.pdf(self.missing.get(num, 50), loc_exp, scale_exp) if scale_exp > 0 else 0.02
                        dist_score = (norm_prob + exp_prob) * 50
                    except Exception:
                        dist_score = 5
                
                scores[num] = (opt_weights[0] * freq_s * 100 + 
                              opt_weights[1] * miss_s * 100 + 
                              opt_weights[2] * trend_s * 50 +
                              opt_weights[3] * corr_s * 100 +
                              opt_weights[4] * range_s * 50 +
                              smooth_freq * 2 +  # 高斯平滑
                              interp_miss_score * 5 +  # 样条插值
                              dist_score +  # 分布拟合
                              ks_score)  # KS检验
                # 各项乘 100/50，把 0~1 的比例特征放大到可比较的得分区间
            
        except Exception as e:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def sklearn_ensemble_algorithm(self, count=6):
        """Scikit-learn集成算法 - 基于Sklearn多模型集成预测

        功能：对 1..49 每个号码单独训练二分类器（RF/GBC/LR/MLP/GaussianNB），
            特征为 _build_sklearn_feature_vector(label_idx+1)、标签为 data[label_idx] 是否出现；
            按 0.25/0.25/0.2/0.15/0.15 融合“下一期出现”概率，再叠加基础分×30、
            遗漏×20、KMeans 簇偏好×3、频率×50 与交叉验证奖励。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: Top-count，1..49；不返回概率字典。
        注意：- 训练 49×5 个模型，耗时显著；
            - 每 10 个目标调用 gc.collect 清理内存；
            - random_state=42、n_jobs=1 保证可复现并规避 C 栈溢出；
            - 轻量模式降级到 _classic_comprehensive；样本 <20 期或训练样本 <10 时随机返回。
        数学含义:
            对 1..49 每个号码单独训练二分类器（RF/GBC/LR/MLP/GaussianNB），
            训练样本的特征为 _build_sklearn_feature_vector(label_idx+1)（只用标签期
            及更旧历史）、标签为紧接着的未来一期 data[label_idx] 是否出现；
            按 0.25/0.25/0.2/0.15/0.15 融合“下一期出现”的预测概率（推理输入为
            第 0 期=全部历史的特征），再叠加基础特征分、遗漏、KMeans 簇偏好、
            频率与交叉验证奖励，取 Top-count。
        输入依赖:
            self.data（>=20 期）、_build_sklearn_feature_vector 以及全部基础统计；
            轻量模式直接降级到 _classic_comprehensive。
        适用场景:
            样本量较大时的多模型集成排序，耗时最高。
            list[int]，Top-count，1..49；不返回概率字典。
        TODO(待确认): KMeans 已按样本数降级（v0.0.42），
            但 X_pca 计算后仍未使用。
        """
        # 【修复0xC0000409】轻量模式下跳过sklearn模型训练，降级到基础统计
        if getattr(self, '_is_light_mode', False):
            return self._classic_comprehensive(count)
        _get_sklearn()
        SS = _core._StandardScaler
        MMS = _core._MinMaxScaler
        PCA = _core._PCA
        RF = _core._RandomForestClassifier
        GBC = _core._GradientBoostingClassifier
        LR = _core._LogisticRegression
        MLP = _core._MLPClassifier
        GNB = _core._GaussianNB
        KM = _core._KMeans
        CVS = _core._cross_val_score
        
        # 20 期为多模型训练的最低样本量，不足时直接随机返回
        if len(self.data) < 20:
            return random.sample(range(1, 50), count)
        
        scores = {}
        try:
            # 构建训练数据：用“第 label_idx+1 期及更旧历史”的特征 -> 预测第 label_idx 期出现
            # 特征索引严格早于标签 data[label_idx]，窗口与标签不重叠、无未来泄漏
            X, y = [], []
            for label_idx in range(len(self.data) - 1):
                features = self._build_sklearn_feature_vector(label_idx + 1)
                X.append(features)
                next_nums = self.data[label_idx].get('numbers', [])
                y_single = [1 if n in next_nums else 0 for n in range(1, 50)]
                y.append(y_single)

            if len(X) < 10:
                return random.sample(range(1, 50), count)

            X = np.array(X)
            y = np.array(y)
            # 推理样本：第 0 期（全部历史）的特征，用于预测尚未发生的下一期
            X_latest = np.array([self._build_sklearn_feature_vector(0)])
            
            # 特征标准化
            if SS is not None:
                scaler = SS()
                X_scaled = scaler.fit_transform(X)
                # 推理样本使用训练集同一 scaler 变换，避免分布错位
                X_latest_scaled = scaler.transform(X_latest)
            else:
                X_scaled = X
                X_latest_scaled = X_latest
            
            # MinMax归一化
            if MMS is not None:
                minmax_scaler = MMS()
                X_minmax = minmax_scaler.fit_transform(X)
                X_latest_minmax = minmax_scaler.transform(X_latest)
            else:
                X_minmax = X
                X_latest_minmax = X_latest
            
            # PCA降维
            pca = None
            if PCA is not None and X_scaled.shape[1] >= 5:
                pca = PCA(n_components=min(10, X_scaled.shape[1]))
                X_pca = pca.fit_transform(X_scaled)
                # TODO(待确认): X_pca 计算后未参与后续训练/预测，PCA 实际未生效
            
            # 各模型预测概率
            model_probs = {n: 0.0 for n in range(1, 50)}
            # 键 1..49；五个模型权重合计 1.0（0.25+0.25+0.2+0.15+0.15）
            
            for target_num in range(1, 50):
                y_target = y[:, target_num-1]
                # 【修复0xC0000409】跳过单类目标，避免模型训练异常和堆栈损坏
                if len(set(y_target)) < 2:
                    model_probs[target_num] += 0.02 * 1.0
                    continue
                
                # RandomForestClassifier
                if RF is not None:
                    # 【修复0xC0000409】必须设置n_jobs=1，禁用OpenMP多线程，
                    # 49轮循环中每次fork OpenMP线程池会导致C栈累积溢出
                    rf = RF(n_estimators=50, max_depth=5, random_state=42, n_jobs=1)
                    try:
                        rf.fit(X_scaled, y_target)
                        rf_prob = rf.predict_proba(X_latest_scaled)[0]
                        if len(rf_prob) > 1:
                            model_probs[target_num] += rf_prob[1] * 0.25
                        else:
                            model_probs[target_num] += 0.02 * 0.25
                    except Exception:
                        model_probs[target_num] += 0.02 * 0.25
                
                # GradientBoostingClassifier
                if GBC is not None:
                    # 【修复】GradientBoostingClassifier不支持n_jobs参数
                    gb = GBC(n_estimators=50, max_depth=3, random_state=42)
                    try:
                        gb.fit(X_scaled, y_target)
                        gb_prob = gb.predict_proba(X_latest_scaled)[0]
                        if len(gb_prob) > 1:
                            model_probs[target_num] += gb_prob[1] * 0.25
                        else:
                            model_probs[target_num] += 0.02 * 0.25
                    except Exception:
                        model_probs[target_num] += 0.02 * 0.25
                
                # LogisticRegression
                if LR is not None:
                    # 【修复0xC0000409】设置n_jobs=1禁用OpenMP并行，防止C栈溢出
                    lr = LR(max_iter=200, random_state=42, n_jobs=1)
                    try:
                        lr.fit(X_scaled, y_target)
                        lr_prob = lr.predict_proba(X_latest_scaled)[0]
                        if len(lr_prob) > 1:
                            model_probs[target_num] += lr_prob[1] * 0.2
                        else:
                            model_probs[target_num] += 0.02 * 0.2
                    except Exception:
                        model_probs[target_num] += 0.02 * 0.2
                
                # MLPClassifier
                if MLP is not None:
                    mlp_model = MLP(hidden_layer_sizes=(32, 16), max_iter=200, random_state=42)
                    try:
                        mlp_model.fit(X_minmax, y_target)
                        mlp_prob = mlp_model.predict_proba(X_latest_minmax)[0]
                        if len(mlp_prob) > 1:
                            model_probs[target_num] += mlp_prob[1] * 0.15
                        else:
                            model_probs[target_num] += 0.02 * 0.15
                    except Exception:
                        model_probs[target_num] += 0.02 * 0.15
                
                # GaussianNB
                if GNB is not None:
                    gnb = GNB()
                    try:
                        gnb.fit(X_scaled, y_target)
                        gnb_prob = gnb.predict_proba(X_latest_scaled)[0]
                        if len(gnb_prob) > 1:
                            model_probs[target_num] += gnb_prob[1] * 0.15
                        else:
                            model_probs[target_num] += 0.02 * 0.15
                    except Exception:
                        model_probs[target_num] += 0.02 * 0.15
                
                # 【修复0xC0000409】周期性清理C级内存，防止堆栈累积
                if target_num % 10 == 0:
                    import gc as _gc  # 作用说明：每训练 10 个号码的 5 个模型手动触发垃圾回收，缓解 49×5 次训练累积的内存/C 栈压力
                    _gc.collect()
            
            # KMeans聚类分析
            # v0.0.42：样本数不足 5 时显式降级簇数（而不是静默失败），并打印日志；
            # 每个簇用“簇内各号码出现率最高的 7 个”作为代表号码，避免空簇无加成
            cluster_nums = {0: list(range(1, 50))}
            target_cluster = 0
            if KM is not None:
                n_samples = len(X_scaled)
                n_clusters = min(5, n_samples)
                if n_clusters >= 2:
                    try:
                        kmeans = KM(n_clusters=n_clusters, random_state=42, n_init=10)
                        cluster_labels = kmeans.fit_predict(X_scaled)
                        # 推理样本（第 0 期=全部历史）所属簇，用于预测下一期
                        target_cluster = int(kmeans.predict(X_latest_scaled)[0])
                        cluster_nums = {c: [] for c in range(n_clusters)}
                        for c in range(n_clusters):
                            mask = cluster_labels == c
                            if mask.any():
                                rates = y[mask].mean(axis=0)
                                # 每个簇取出现率最高的 7 个号码（与单期出号个数一致）
                                cluster_nums[c] = [int(i) + 1 for i in np.argsort(rates)[-7:]]
                        print(f"[KMeans] 样本数={n_samples}，实际簇数={n_clusters}"
                              + ("（已按样本数降级）" if n_clusters < 5 else ""))
                    except Exception as e:
                        # 显式降级：聚类异常时全体号码拿中性加成，并打印原因
                        print("KMeans 聚类失败，聚类加成退化为全局中性:", str(e))
                        cluster_nums = {0: list(range(1, 50))}
                        target_cluster = 0
                else:
                    print(f"[KMeans] 样本数={n_samples} < 2，跳过聚类，聚类加成取全局中性")
            
            # cross_val_score验证
            cv_bonus = 0
            if CVS is not None and RF is not None:
                try:
                    y_cv = y[:, 25]
                    # 取第 26 个号码作交叉验证标签，仅用于估计模型稳定性
                    # 【修复0xC0000409】检查类别分布，确保每类至少有cv个样本
                    unique_classes, class_counts = np.unique(y_cv, return_counts=True)
                    if len(unique_classes) >= 2:
                        min_count = min(class_counts)
                        cv_folds = min(5, min_count, len(X))
                        if cv_folds >= 2:
                            rf_cv = RF(n_estimators=30, max_depth=4, random_state=42, n_jobs=1)
                            # 【修复0xC0000409】cross_val_score也必须设置n_jobs=1，
                            # 默认None会使用OpenMP并行各折，在QThread中导致C栈溢出
                            cv_scores = CVS(rf_cv, X_scaled, y_cv, cv=cv_folds, n_jobs=1)
                            cv_bonus = np.mean(cv_scores) * 5
                except Exception:
                    cv_bonus = 0
            
            # 综合得分
            for num in range(1, 50):
                # 模型集成概率得分
                ensemble_prob = model_probs[num] if model_probs[num] > 0 else 0.02
                
                # 基础特征得分
                base_score = self._get_weighted_score(num) / 100
                
                # 遗漏得分
                miss_s = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                
                # 聚类偏好得分
                cluster_bonus = 10 if num in cluster_nums.get(target_cluster, []) else 1
                
                # 频率得分
                freq_s = self.frequency.get(num, 0) / len(self.data) if self.data else 0
                
                scores[num] = (ensemble_prob * 200 +  # 模型集成权重最高
                             base_score * 30 +
                             miss_s * 20 +
                             cluster_bonus * 3 +
                             freq_s * 50 +
                             cv_bonus)
                # 200/30/20/3/50 为经验权重；ensemble_prob 默认 0.02，主导排序
            
        except Exception as e:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _build_prefix_feature_table(self):
        """为每一期构建“只用该期及更旧历史”的 343 维 sklearn 特征向量表

        功能：把 self.data 翻成“旧→新”序列，逐期计算前缀统计（只用该期及更旧历史），
            每个号码 7 维（freq、miss/50、MA5/10/20、一阶自相关、zscore/5），
            49×7 拼接为 343 维后映射回“最新在前”下标 idx=N-1-t。
        参数：
            无（读取 self.data 与 _get_number_series()）。
        返回：list[numpy.ndarray]: 长度 N（与 self.data 等长），每个元素为 343 维
            float64 数组；空数据返回 []。
        注意：写入 self._sklearn_feature_table_cache（键含 _data_signature），
            同指纹后续调用直接命中缓存；只读 self.data，不修改其它状态。
        时间方向假设（旧 → 新）:
            self.data[0] 最新、self.data[-1] 最旧。本方法先把它翻成旧→新序列，
            对旧→新下标 t（m=t+1 期可用历史）计算前缀统计，再映射回“最新在前”
            下标 idx=N-1-t：table[idx] 只使用 self.data[idx:]（第 idx 期及其更旧
            的全部历史），绝不包含 self.data[0:idx]（更新/未来期）。
            因此与标签 data[idx-1]（紧接着的未来一期）配对时窗口与标签不重叠、无泄漏。

        每个号码的 7 维特征（与原实现同名同序，保证 343 维结构不变）:
            freq      = 前 m 期出现次数 / m
            miss      = 第 m-1 期结束时的当前遗漏（截断 0..50）/ 50
            ma5/10/20 = 最近 5/10/20 期出现率（不足时按已有期数）
            autocorr  = 前 m 期 0/1 序列的一阶自相关
            zscore    = (当前遗漏 - 历史出现间隔均值) / 间隔标准差 / 5
                        间隔样本 <2 或标准差为 0 时记 0

        """
        key = ('sklearn_prefix_table', self._data_signature())
        cache = getattr(self, '_sklearn_feature_table_cache', None)
        if cache is not None and cache.get('key') == key:
            return cache['table']

        occ, _ = self._get_number_series()      # (49, N) 旧→新
        n = occ.shape[1]
        if n == 0:
            self._sklearn_feature_table_cache = {'key': key, 'table': []}
            return []

        occT = occ.T                             # (N, 49) 旧→新
        # cum[m] = 前 m 期累计出现次数（m=0..N）
        cum = np.vstack([np.zeros((1, 49)), np.cumsum(occT, axis=0)])
        # 相邻两期共现累计，用于一阶自相关
        pair_prod = occT[:-1] * occT[1:] if n > 1 else np.zeros((0, 49))
        pcum = np.zeros((n, 49))
        if n > 1:
            pcum[1:] = np.cumsum(pair_prod, axis=0)

        table = [None] * n
        last_seen = np.full(49, -1, dtype=np.int64)
        # 间隔统计（逐号码累计）：用于 zscore
        gap_sum = np.zeros(49)
        gap_sq = np.zeros(49)
        gap_cnt = np.zeros(49)

        for t in range(n):
            appeared = occT[t] == 1
            # 先更新“出现间隔”统计（间隔 = 本次 - 上次出现），再更新 last_seen
            mask = appeared & (last_seen >= 0)
            if mask.any():
                gap = (t - last_seen[mask]).astype(np.float64)
                gap_sum[mask] += gap
                gap_sq[mask] += gap ** 2
                gap_cnt[mask] += 1
            last_seen[appeared] = t
            m = t + 1                        # 可用历史期数（含当期）

            freq = cum[m] / m
            miss = (t - last_seen).astype(np.float64)  # 从未出现时 last=-1 → t+1
            ma5 = (cum[m] - cum[max(0, m - 5)]) / min(5, m)
            ma10 = (cum[m] - cum[max(0, m - 10)]) / min(10, m)
            ma20 = (cum[m] - cum[max(0, m - 20)]) / min(20, m)

            autocorr = np.zeros(49)
            n_pairs = m - 1
            if n_pairs >= 2:
                mean_x = cum[m - 1] / n_pairs              # 序列 o[0..m-2]
                mean_y = (cum[m] - occT[0]) / n_pairs      # 序列 o[1..m-1]
                cov = pcum[m - 1] / n_pairs - mean_x * mean_y
                var_x = mean_x - mean_x ** 2
                var_y = mean_y - mean_y ** 2
                denom = np.sqrt(var_x * var_y)
                autocorr = np.where(denom > 1e-12, cov / np.maximum(denom, 1e-12), 0.0)

            gap_mean = np.where(gap_cnt > 0, gap_sum / np.maximum(gap_cnt, 1), 0.0)
            gap_var = np.where(
                gap_cnt > 0,
                gap_sq / np.maximum(gap_cnt, 1) - gap_mean ** 2,
                0.0,
            )
            gap_std = np.sqrt(np.maximum(gap_var, 0.0))
            zscore = np.where(
                (gap_cnt >= 2) & (gap_std > 1e-9),
                (miss - gap_mean) / np.maximum(gap_std, 1e-9),
                0.0,
            )

            vec = np.column_stack([
                freq,
                np.clip(miss, 0, 50) / 50,
                ma5,
                ma10,
                ma20,
                autocorr,
                zscore / 5,
            ]).reshape(-1)
            # 旧→新下标 t 映射回最新在前下标 idx = N-1-t
            table[n - 1 - t] = vec

        self._sklearn_feature_table_cache = {'key': key, 'table': table}
        return table

    def _build_sklearn_feature_vector(self, idx):
        """构建第 idx 期的 sklearn 特征向量（只用该期及更旧历史）

        功能：取 _build_prefix_feature_table() 的第 idx 行并转成 list，即“只用第 idx 期
            及更旧历史”的 343 维特征；idx=0 使用全部历史，用于预测下一期。
        参数：
            idx (int): 期号下标（最新在前）；越界时钳制到 [0, N-1]。
        返回：list[float]: 长度 343 的特征向量；空数据返回 []。
        注意：首次调用会构建并缓存全量特征表；同一数据指纹下后续调用为 O(1)。
        时间方向假设（旧 → 新）:
            idx 是 self.data 的“最新在前”下标：向量只由 self.data[idx:] 计算，
            idx 越小历史越长、idx=0 使用全部历史（用于预测“下一期”）；
            任何未来期 data[0:idx] 都不参与计算，避免标签泄漏。

        数学口径:
            49 个号码各自的 7 维特征（频率、遗漏/50、MA5/10/20、自相关、zscore/5）
            首尾拼接为 343 维，详见 _build_prefix_feature_table。

        """
        table = self._build_prefix_feature_table()
        if not table:
            return []
        idx = min(max(int(idx), 0), len(table) - 1)
        return table[idx].tolist()
    
    def pytorch_deep_learning_algorithm(self, count=6):
        """PyTorch深度学习算法 - 基于PyTorch LSTM神经网络预测（无PyTorch时使用基础统计）

        功能：把连续 10 期、每期 49 个号码的 5 维前缀特征按“旧→新”拼成 245 维序列，
            输入 2 层 LSTM（隐藏 64、dropout 0.2），取最后时间步经 Dropout →
            Linear(64→49) → Sigmoid 得各号码独立出现概率；再用温度
            [2.0, 1.5, 1.0, 0.5] 的 softmax 退火取平均，与基础特征得分融合排序。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 长度 count，按综合得分降序的号码（1..49）。
        异常：内部异常被捕获，退化为按 _get_weighted_score 排序，不向外抛出。
        注意：- 懒加载 PyTorch（_get_torch/_get_nn/_get_optim）；
            - 首次调用时设置 self.device（CUDA 可用则 cuda，否则 cpu）；
            - 训练 30 epochs、mini-batch（≤16），阻塞当前线程并占用 CPU/GPU；
            - 不修改 self.data；<20 期随机抽样，轻量模式或无 PyTorch 走 _pytorch_fallback。
        数学含义:
            把连续 10 期、每期 49 个号码的 5 维归一化特征（频率、遗漏/50、
            MA5、MA10、自相关）按时间顺序拼成 245 维向量，输入 2 层 LSTM
            （隐藏维度 64、dropout 0.2）；取最后时间步隐状态经 Dropout →
            Linear(64→49) → Sigmoid，得到 49 个号码各自的独立出现概率；
            再用温度 [2.0, 1.5, 1.0, 0.5] 的 softmax 退火取平均，
            与基础特征得分融合后排序。
        输入依赖:
            self.data（至少 20 期）、self.frequency、self.missing、
            self.moving_avg、self.autocorrelation、self.correlation_matrix、
            self._get_weighted_score。
        适用场景:
            样本量足够且 PyTorch 可用时；轻量模式或库缺失时退化到
            _pytorch_fallback，数据不足 20 期时随机抽样。
        说明:
            样本按“旧→新”滑窗构建，标签取窗口之后的下一期，避免标签与窗口重叠。
            v0.0.42 起每期特征只用该期之前的历史计算（前缀累积），
            不再使用覆盖全量的 frequency/moving_avg/autocorrelation，消除未来数据泄漏。
        """
        if len(self.data) < 20:
            return random.sample(range(1, 50), count)
        
        # 【修复0xC0000409】轻量模式下直接使用基础统计方法，不触发PyTorch懒加载
        # PyTorch的C运行时后台线程在QThread中会导致栈缓冲区溢出
        if getattr(self, '_is_light_mode', False):
            return self._pytorch_fallback(count)
        
        # 无PyTorch时使用基础统计方法
        torch_mod = _get_torch()
        nn = _get_nn()
        optim_mod = _get_optim()
        if torch_mod is None:
            return self._pytorch_fallback(count)
        
        scores = {}
        try:
            # 构建时序数据
            # 回溯窗口固定 10 期：窗口越长样本数越少（N-10），10 期是样本量与
            # 周期信息量的折中。data[0] 是最新一期，先反转为“旧→新”，
            # 标签取窗口之后的下一期，避免与窗口重叠（标签泄漏）
            sequence_length = 10
            data_ordered = list(reversed(self.data))
            n_hist = len(data_ordered)

            # 前缀特征：对每一期只用它之前（不含当期）的数据计算 5 维特征，
            # 避免全局 frequency/moving_avg/autocorrelation 把未来期信息带入样本
            occ = np.zeros((n_hist, 49), dtype=np.float64)
            for rec_idx, record in enumerate(data_ordered):
                for num in record.get('numbers', []):
                    if 1 <= num <= 49:
                        occ[rec_idx, num - 1] = 1.0

            # 累计出现次数：cum[m] 表示前 m 期的累计值
            cum_occ = np.vstack([np.zeros((1, 49)), np.cumsum(occ, axis=0)])
            # 相邻两期的共现累计：pcum[m] 表示前 m-1 个相邻对（t, t+1）的累计值
            pair_prod = occ[:-1] * occ[1:] if n_hist > 1 else np.zeros((0, 49))
            pcum = np.zeros((n_hist, 49))
            if n_hist > 1:
                pcum[1:] = np.cumsum(pair_prod, axis=0)

            prefix_features = [None] * n_hist
            last_seen = np.full(49, -1, dtype=np.int64)  # 上一次出现的期号（旧→新下标）
            for idx in range(n_hist):
                # 特征包含“当前期及之前”的历史，不含任何未来期；标签才是下一期
                last_seen[occ[idx] == 1] = idx
                m = idx + 1  # 可用历史长度（含当期）
                freq = cum_occ[m] / m
                miss = np.where(last_seen >= 0, idx - last_seen, 50).astype(np.float64)
                ma5 = (cum_occ[m] - cum_occ[max(0, m - 5)]) / min(5, m)
                ma10 = (cum_occ[m] - cum_occ[max(0, m - 10)]) / min(10, m)
                # 一阶自相关：基于前 m 期的相邻对 (o[t], o[t+1])
                n_pairs = m - 1
                autocorr = np.zeros(49)
                if n_pairs >= 2:
                    mean_x = cum_occ[m - 1] / n_pairs              # o[0..m-2] 均值
                    mean_y = (cum_occ[m] - occ[0]) / n_pairs       # o[1..m-1] 均值
                    cov = pcum[m - 1] / n_pairs - mean_x * mean_y
                    var_x = mean_x - mean_x ** 2
                    var_y = mean_y - mean_y ** 2
                    denom = np.sqrt(var_x * var_y)
                    autocorr = np.where(denom > 1e-12, cov / np.maximum(denom, 1e-12), 0.0)
                prefix_features[idx] = np.column_stack([
                    freq,
                    np.clip(miss, 0, 50) / 50,
                    ma5,
                    ma10,
                    autocorr,
                ])

            def _make_seq(start_idx):
                """按“旧→新”顺序生成从 start_idx 起的 10 期前缀特征序列

                功能：从 start_idx 起依次取 sequence_length（=10）期的前缀特征，
                    展平为 list 后组成序列。
                参数：
                    start_idx (int): 旧→新序列中的起始期下标；调用方保证后续期下标不越界。
                返回：list[list[float]]: 长度 10 的序列，每个元素为该期 245 维特征列表。
                注意：无副作用（只读闭包中的 prefix_features）。
                """
                seq = []
                for j in range(sequence_length):
                    idx = start_idx + j
                    seq.append(prefix_features[idx].reshape(-1).tolist())
                return seq

            X_seq, y_seq = [], []
            for i in range(len(data_ordered) - sequence_length):
                X_seq.append(_make_seq(i))
                # 标签：窗口之后的下一期出现的数字
                next_nums = data_ordered[i + sequence_length].get('numbers', [])
                y_single = [1 if n in next_nums else 0 for n in range(1, 50)]
                y_seq.append(y_single)
            
            if len(X_seq) < 5:
                return random.sample(range(1, 50), count)
            
            # 延迟设置device
            if self.device is None:
                self.device = torch_mod.device('cuda' if torch_mod.cuda.is_available() else 'cpu')
            
            X_seq = torch_mod.tensor(X_seq, dtype=torch_mod.float32)
            y_seq = torch_mod.tensor(y_seq, dtype=torch_mod.float32)
            
            # PyTorch LSTM模型
            class LotteryLSTM(nn.Module):
                """彩票LSTM模型类（定义在方法内部，每次调用都重新构造并从头训练）

                功能：组合 LSTM(245→64, 2 层, batch_first=True, dropout=0.2)、
                    Dropout(0.2) 与 Linear(64→49)，由 forward 输出各号码概率。
                参数：
                    由 __init__ 的默认参数决定（input_size=245、hidden_size=64、
                    num_layers=2、dropout=0.2）。
                返回：LotteryLSTM 实例（nn.Module 子类）。
                注意：仅在 pytorch_deep_learning_algorithm 内部使用，未注册到 self；
                    模型与参数不落盘，每次调用重新初始化。
                结构:
                    LSTM(245→64, 2 层, batch_first=True, dropout=0.2) →
                    取最后时间步隐状态 → Dropout(0.2) → Linear(64→49) → Sigmoid。
                适用场景:
                    仅用于本方法的 49 号码多标签出现概率预测。
                """
                def __init__(self, input_size=245, hidden_size=64, num_layers=2, dropout=0.2):
                    """初始化 LSTM 与输出层

                    功能：调用父类构造，创建 lstm/fc/dropout 三个子模块
                        （LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout)、
                        Linear(hidden_size, 49)、Dropout(dropout)）。
                    参数：
                        input_size (int): 每期特征维度；245 = 49 个号码 × 5 个特征，
                            必须与上游 features.extend 的维度一致。
                        hidden_size (int): LSTM 隐藏维度；64 为兼顾拟合能力与
                            训练耗时的经验值。
                        num_layers (int): LSTM 堆叠层数；2 层可表达更复杂的时序模式。
                        dropout (float): 层间/输出前丢弃比例；0.2 用于抑制过拟合。
                    返回：无（构造函数）。
                    注意：创建 lstm/fc/dropout 三个子模块，占用少量显存/内存。
                    """
                    super().__init__()
                    self.lstm = nn.LSTM(input_size, hidden_size, num_layers, 
                                       batch_first=True, dropout=dropout)
                    self.fc = nn.Linear(hidden_size, 49)
                    self.dropout = nn.Dropout(dropout)
                
                def forward(self, x):
                    """前向传播：输出每个号码的出现概率

                    功能：LSTM 前向取最后时间步隐状态，经 Dropout 与 Linear(64→49)，
                        再 Sigmoid 输出 49 个号码的独立概率。
                    参数：
                        x (Tensor): 形状 (batch, seq_len, 245) 的时序特征。
                    返回：Tensor: 形状 (batch, 49)，Sigmoid 后的独立概率；
                        各列不要求和为 1（多标签设定，允许一期出现多个号码）。
                    注意：无副作用（不修改输入张量）。
                    """
                    lstm_out, _ = self.lstm(x)
                    out = self.fc(self.dropout(lstm_out[:, -1, :]))
                    return torch_mod.sigmoid(out)
            
            # 初始化模型
            # 默认 input_size=245 必须与上方每期 5 维特征 × 49 号码对齐
            model = LotteryLSTM().to(self.device)
            criterion = nn.BCELoss()
            optimizer = optim_mod.Adam(model.parameters(), lr=0.001)
            
            # 训练循环
            # 【修复0xC0000409】原代码逐样本训练(batch_size=1)，30 epochs × N样本
            # 产生大量backward调用，PyTorch ATen C++栈帧频繁创建/销毁导致栈溢出
            # 改为mini-batch训练，减少backward调用次数，降低C栈压力
            model.train()
            batch_size = min(16, len(X_seq))  # 小样本时 batch 不超过样本总数
            for epoch in range(30):  # 30 轮为经验值：更多轮次在 245 维输入上易过拟合
                total_loss = 0
                n_batches = 0
                for start in range(0, len(X_seq), batch_size):
                    end = min(start + batch_size, len(X_seq))
                    batch_x = X_seq[start:end].to(self.device)
                    batch_y = y_seq[start:end].to(self.device)
                    
                    optimizer.zero_grad()
                    outputs = model(batch_x)
                    loss = criterion(outputs, batch_y)
                    loss.backward()
                    optimizer.step()
                    total_loss += loss.item()
                    n_batches += 1
            
            # 预测：用最新 10 期（旧→新）构建下一期窗口
            model.eval()
            with torch_mod.no_grad():
                last_seq = torch_mod.tensor(
                    [_make_seq(len(data_ordered) - sequence_length)],
                    dtype=torch_mod.float32).to(self.device)
                predictions = model(last_seq).squeeze().cpu().numpy()
            
            # 动态温度采样
            # temperature=1.0 时下面的幂运算与归一化实际不改变分布，
            # 真正的温度退火在下方 temp_schedule 中对 logits 做 softmax 时进行
            temperature = 1.0
            probs = np.array(predictions)
            probs = np.power(probs, 1.0/temperature)
            probs = probs / probs.sum()
            
            # torch.softmax动态温度退火采样
            logits = torch_mod.tensor(probs, dtype=torch_mod.float32)
            temp_schedule = [2.0, 1.5, 1.0, 0.5]
            all_probs = []
            for temp in temp_schedule:
                scaled = logits / temp
                softmax_probs = torch_mod.softmax(scaled, dim=0).numpy()
                all_probs.append(softmax_probs)
            
            avg_probs = np.mean(all_probs, axis=0)
            
            # 综合得分
            for num in range(1, 50):
                lstm_prob = avg_probs[num-1] if num-1 < len(avg_probs) else 0.02
                
                # 基础特征得分
                base_score = self._get_weighted_score(num) / 100
                
                # 遗漏得分
                miss_s = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                
                # 频率得分
                freq_s = self.frequency.get(num, 0) / len(self.data) if self.data else 0
                
                # 相关性得分
                corr_s = 0
                if len(self.data) > 0:
                    latest_nums = self.data[0].get('numbers', [])
                    # 【修复除零+越界bug】latest_nums可能为空导致除零；
                    # 号码可能不在1-49范围内导致correlation_matrix索引越界
                    valid_nums = [n for n in latest_nums if 1 <= n <= 49]
                    if valid_nums:
                        corr_s = sum(self.correlation_matrix[num-1, n-1] for n in valid_nums) / len(valid_nums)
                
                # 权重为经验值：LSTM 概率 150 主导，频率 50、共现 40 次之，
                # 基础加权分与遗漏各 30，用于在模型概率接近时打破平局
                scores[num] = (lstm_prob * 150 +  # LSTM预测权重最高
                             base_score * 30 +
                             miss_s * 30 +
                             freq_s * 50 +
                             corr_s * 40)
            
        except Exception as e:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    # Fallback方法 - 无重依赖库时的替代实现
    
    def _pytorch_fallback(self, count=6):
        """PyTorch fallback - 使用NumPy/Sklearn替代深度学习

        功能：无神经网络时的线性加权打分（各项先折算到百分制）：
            基础加权分×0.3 + 遗漏周期×100×0.25 + 频率×100×0.2 +
            (MA5-MA20)×50×0.15 + 共现相关×100×0.1，权重和为 1。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 长度 count，按得分降序的号码（1..49）。
        异常：计算异常被捕获，退化为按 _get_weighted_score 排序。
        注意：无副作用（不加载 PyTorch、不训练模型、无阻塞、无随机性）。
        数学含义:
            无神经网络时的线性加权打分（各项先折算到百分制）：
            基础加权分×0.3 + 遗漏周期×100×0.25 + 频率×100×0.2 +
            MA5/MA20 趋势×0.15 + 共现相关×100×0.1，权重和为 1。
        输入依赖:
            self.frequency、self.missing、self.moving_avg、
            self.correlation_matrix、self._get_weighted_score。
        适用场景:
            轻量模式（_is_light_mode=True）或 PyTorch 不可用/导入失败时，
            作为深度学习结果的确定性替代。
        """
        scores = {}
        try:
            for num in range(1, 50):
                # 基础特征得分
                base_score = self._get_weighted_score(num)
                
                # 遗漏得分
                miss = self.missing.get(num, 50)
                # 平均出现周期：每期约 7 个号码摊到 49 个号码约 6.7 期/次，
                # 空数据时取经验值 6
                avg_cycle = len(self.data) / 49 if len(self.data) > 0 else 6
                miss_score = MathUtils.calculate_missing_cycle(miss, avg_cycle)
                
                # 频率得分
                freq = self.frequency.get(num, 0)
                freq_score = freq / len(self.data) if self.data else 0
                
                # 趋势得分
                ma5 = self.moving_avg.get(num, {}).get(5, 0.1)
                ma20 = self.moving_avg.get(num, {}).get(20, 0.1)
                trend_score = (ma5 - ma20) * 50
                
                # 相关性得分
                corr_s = 0
                if len(self.data) > 0:
                    latest_nums = self.data[0].get('numbers', [])
                    # 【修复除零+越界bug】latest_nums可能为空导致除零；
                    # 号码可能不在1-49范围内导致correlation_matrix索引越界
                    valid_nums = [n for n in latest_nums if 1 <= n <= 49]
                    if valid_nums:
                        corr_s = sum(self.correlation_matrix[num-1, n-1] for n in valid_nums) / len(valid_nums)
                
                # 权重 0.3/0.25/0.2/0.15/0.1 为经验值且总和为 1，
                # 保证不同量纲的特征折算后量级相近
                scores[num] = base_score * 0.3 + miss_score * 100 * 0.25 + freq_score * 100 * 0.2 + trend_score * 0.15 + corr_s * 100 * 0.1
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _nx_number_graph_fallback(self, count=6):
        """NetworkX number_graph fallback - 使用基础统计替代PageRank

        功能：用线性代理近似图中高中心性号码的偏好：
            频率×2 + 遗漏周期×30 + 与最新一期号码的共现强度×20 + (MA5-MA20)×50×0.5。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 长度 count，按得分降序的号码（1..49）。
        异常：计算异常被捕获，退化为按 _get_weighted_score 排序。
        注意：无副作用（不加载 NetworkX、不建图、无随机性）。
        数学含义:
            用线性代理近似图中高中心性号码的偏好：
            频率×2 + 遗漏周期×30 + 与最新一期号码的共现强度×20 +
            MA5/MA20 趋势×0.5。
        输入依赖:
            self.frequency、self.missing、self.correlation_matrix、
            self.moving_avg、self.data[0]（最新一期）、self._get_weighted_score。
        适用场景:
            NetworkX 不可用，或 networkx_graph_algorithm 需要降级时。
        """
        scores = {}
        try:
            for num in range(1, 50):
                # 频率得分
                freq_score = self.frequency.get(num, 0)
                
                # 遗漏得分
                miss = self.missing.get(num, 50)
                miss_score = MathUtils.calculate_missing_cycle(miss, 6)
                
                # 共现得分
                cooccur_score = 0
                if len(self.data) > 0:
                    latest_nums = self.data[0].get('numbers', [])
                    # 【修复越界bug】号码可能不在1-49范围内导致correlation_matrix索引越界
                    for n in latest_nums:
                        if 1 <= n <= 49:
                            cooccur_score += self.correlation_matrix[num-1, n-1]
                
                # 趋势得分
                ma5 = self.moving_avg.get(num, {}).get(5, 0.1)
                ma20 = self.moving_avg.get(num, {}).get(20, 0.1)
                trend_score = (ma5 - ma20) * 50
                
                scores[num] = freq_score * 2 + miss_score * 30 + cooccur_score * 20 + trend_score * 0.5
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _nx_shortest_path_fallback(self, count=6):
        """NetworkX shortest_path fallback - 使用基础距离计算替代Dijkstra

        功能：用号码与最新一期号码的最小绝对差（|num-ln|）构造距离得分
            max(0, 20 - min_distance)，近似 Dijkstra 最短路中“靠近源节点”
            的偏好；再叠加基础分、遗漏周期×20 与 ±2 邻号的转移计数×0.5。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 长度 count，按得分降序的号码（1..49）。
        异常：计算异常被捕获，退化为按 _get_weighted_score 排序。
        注意：无副作用；data 为空时在 except 中整体降级（无随机性）。
        数学含义:
            用号码与最新一期号码的最小绝对差（|num-ln|）构造距离得分
            max(0, 20 - min_distance)，近似 Dijkstra 最短路中“靠近源节点”
            的偏好；再叠加基础分、遗漏周期与 ±2 邻号的转移计数。
        输入依赖:
            self.data[0].numbers（最近一期）、self.missing、
            self._get_weighted_score。
        适用场景:
            NetworkX 不可用时；data 为空会在 except 中整体降级。
        """
        scores = {}
        try:
            latest_nums = set(self.data[0].get('numbers', []))
            for num in range(1, 50):
                # 基础得分
                base_score = self._get_weighted_score(num)
                
                # 距离得分（替代最短路径）
                # 25 为号码 1..49 的中位距离，作为无源点时的中性罚值；
                # 20 是距离得分上限，距离越近得分越高
                min_distance = min(abs(num - ln) for ln in latest_nums) if latest_nums else 25
                distance_score = max(0, 20 - min_distance)
                
                # 遗漏得分
                miss = self.missing.get(num, 50)
                miss_score = MathUtils.calculate_missing_cycle(miss, 6)
                
                # 转移得分（替代转移图）
                transfer_score = 0
                if len(self.data) > 0:
                    for i in range(len(self.data) - 1):
                        curr = set(self.data[i].get('numbers', []))
                        next_nums = set(self.data[i + 1].get('numbers', []))
                        if num in next_nums:
                            for c in curr:
                                if abs(c - num) <= 2:
                                    transfer_score += 1
                
                scores[num] = base_score + distance_score * 2 + miss_score * 20 + transfer_score * 0.5
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _nx_community_fallback(self, count=6):
        """NetworkX community fallback - 使用KMeans替代Louvain

        功能：以聚类标签（KMeans 分簇结果，或按遗漏 <10/<20 划分的 2/1/0 三档）作为
            社区归属代理：KMeans 时按簇内平均频率降序给 20/15/10/5/0 加成，
            非 KMeans 时按档位×5；再叠加基础分与遗漏周期×20。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        返回：list[int]: 长度 count，按得分降序的号码（1..49）。
        异常：计算异常被捕获，退化为按 _get_weighted_score 排序。
        注意：无副作用（不训练 KMeans，只读取已有属性）。
        数学含义:
            用聚类标签（sklearn KMeans 的分簇结果，或按遗漏阈值 10/20 划分的
            热/温/冷三档）作为社区归属代理：同社区号码额外加分，
            再叠加基础分与遗漏周期×20。
        v0.0.42:
            KMeans 簇编号本身没有冷热语义，不能直接“标签×5”当加成；
            改为按“簇内号码平均频率”降序给簇排名，名次越高加成分越高
            （20/15/10/5/0），既保留原量级又让加成与热度方向一致。
        输入依赖:
            self.kmeans_labels、self.frequency、self.missing、
            self._get_weighted_score。
        适用场景:
            NetworkX 社区检测不可用；无 KMeans 标签时按遗漏值分 3 档。
        说明:
            self.kmeans_labels 是 np.ndarray（见 _prepare_sklearn_features），
            需先转成 {号码: 簇标签} 字典再调用 .get，避免 AttributeError。
        """
        scores = {}
        is_kmeans = False
        try:
            # 使用sklearn的KMeans做聚类分组
            if hasattr(self, 'kmeans_labels') and self.kmeans_labels is not None:
                cluster_scores = self.kmeans_labels
                is_kmeans = True
            else:
                # 基础聚类（按遗漏值分组，数值 2/1/0 本身即热/温/冷语义）
                cluster_scores = {}
                for num in range(1, 50):
                    miss = self.missing.get(num, 50)
                    if miss < 10:
                        cluster_scores[num] = 2  # 热号
                    elif miss < 20:
                        cluster_scores[num] = 1  # 温号
                    else:
                        cluster_scores[num] = 0  # 冷号
            # KMeans 标签是 ndarray，统一转成“号码 -> 簇标签”字典
            if isinstance(cluster_scores, np.ndarray):
                cluster_scores = {i + 1: int(v) for i, v in enumerate(cluster_scores)}

            # KMeans 簇号任意，按簇内平均频率排序后映射为热度加成
            bonus_map = {}
            if is_kmeans:
                members = {}
                for num, cluster_id in cluster_scores.items():
                    members.setdefault(cluster_id, []).append(num)
                total = len(self.data) if self.data else 1
                avg_freq = {
                    c: sum(self.frequency.get(n, 0) / total for n in nums) / len(nums)
                    for c, nums in members.items()
                }
                ranked = sorted(avg_freq, key=avg_freq.get, reverse=True)
                bonus_map = {c: max(0, 20 - 5 * rank) for rank, c in enumerate(ranked)}

            for num in range(1, 50):
                base_score = self._get_weighted_score(num)
                miss = self.missing.get(num, 50)
                miss_score = MathUtils.calculate_missing_cycle(miss, 6)

                # 聚类内连接强度（替代社区检测）
                if is_kmeans:
                    cluster_bonus = bonus_map.get(cluster_scores.get(num, -1), 0)
                else:
                    cluster_bonus = cluster_scores.get(num, 0) * 5

                scores[num] = base_score + miss_score * 20 + cluster_bonus
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _nx_clustering_fallback(self, count=6):
        """NetworkX clustering fallback - 使用基础统计替代连通分量

        功能：用“区间同组 / 尾数同组”替代图的连通分量：候选号码与最新一期
            每个号码同区间加 2 分、同尾数加 1 分，再叠加基础加权分与
            MathUtils.calculate_missing_cycle(遗漏, 6)×20，最后按得分降序取前 count 个。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        数学含义:
            用“区间同组 / 尾数同组”替代图的连通分量：
            候选号码与最新一期每个号码同区间加 2 分、同尾数加 1 分，
            再叠加基础分与遗漏周期×20。
        输入依赖:
            LotteryConfig.get_range_index/get_tail_digit、self.data[0]、
            self.missing、self._get_weighted_score。
        适用场景:
            NetworkX 不可用，或连通分量结果过于粗粒度时。
        返回：
            list[int]，长度 count，按得分降序的号码（1..49）。
        异常：
            计算异常被捕获，退化为按 _get_weighted_score 排序。
        注意：
            无副作用。
        """
        scores = {}
        try:
            # 按区间分组
            range_groups = {i: [] for i in range(5)}
            for num in range(1, 50):
                idx = LotteryConfig.get_range_index(num)
                if idx >= 0:
                    range_groups[idx].append(num)
            
            # 按尾数分组
            tail_groups = {i: [] for i in range(10)}
            for num in range(1, 50):
                tail = LotteryConfig.get_tail_digit(num)
                tail_groups[tail].append(num)
            
            latest_nums = set(self.data[0].get('numbers', []))
            for num in range(1, 50):
                base_score = self._get_weighted_score(num)
                miss = self.missing.get(num, 50)
                miss_score = MathUtils.calculate_missing_cycle(miss, 6)
                
                # 分组内连接强度（替代连通分量）
                comp_score = 0
                rng_idx = LotteryConfig.get_range_index(num)
                tail_idx = LotteryConfig.get_tail_digit(num)
                
                for ln in latest_nums:
                    ln_rng = LotteryConfig.get_range_index(ln)
                    ln_tail = LotteryConfig.get_tail_digit(ln)
                    if rng_idx == ln_rng:
                        comp_score += 2
                    if tail_idx == ln_tail:
                        comp_score += 1
                
                scores[num] = base_score + miss_score * 20 + comp_score
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def _networkx_fallback(self, count=6):
        """NetworkX综合fallback - 使用多种基础统计

        功能：对 1..49 每个号码线性叠加五类代理特征——频率×2、遗漏周期×30、
            与最新一期号码的共现强度×20、距离得分（20-最小绝对差）×2、
            基础加权分×0.5，最后按得分降序取前 count 个。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        数学含义:
            五类线性代理特征直接叠加：频率×2、遗漏周期×30、共现×20、
            距离得分（20-与最新号码的最小差）×2、基础加权分×0.5，
            近似 NetworkX 综合图算法的多指标融合。
        输入依赖:
            self.frequency、self.missing、self.correlation_matrix、
            self.data[0]、self._get_weighted_score。
        适用场景:
            NetworkX 不可用（networkx_graph_algorithm 的最终降级路径）。
        返回：
            list[int]，长度 count，按得分降序的号码（1..49）。
        异常：
            计算异常被捕获，退化为按 _get_weighted_score 排序。
        注意：
            无副作用。
        """
        scores = {}
        try:
            # 综合多种基础统计指标
            for num in range(1, 50):
                # 频率得分
                freq_score = self.frequency.get(num, 0) * 2
                
                # 遗漏得分
                miss = self.missing.get(num, 50)
                miss_score = MathUtils.calculate_missing_cycle(miss, 6) * 30
                
                # 共现得分
                cooccur_score = 0
                # 【修复未定义变量bug】latest_nums需要在if块外初始化，
                # 否则当len(self.data)==0时，下方latest_nums引用会抛NameError
                latest_nums = []
                if len(self.data) > 0:
                    latest_nums = self.data[0].get('numbers', [])
                    # 【修复越界bug】号码可能不在1-49范围内导致correlation_matrix索引越界
                    for n in latest_nums:
                        if 1 <= n <= 49:
                            cooccur_score += self.correlation_matrix[num-1, n-1]
                cooccur_score *= 20
                
                # 距离得分
                min_distance = 25
                if latest_nums:
                    min_distance = min(abs(num - ln) for ln in latest_nums)
                distance_score = max(0, 20 - min_distance) * 2
                
                # 基础特征得分
                base_score = self._get_weighted_score(num) * 0.5
                
                scores[num] = freq_score + miss_score + cooccur_score + distance_score + base_score
        except Exception:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    def networkx_graph_algorithm(self, count=6):
        """NetworkX图算法 - 基于图论多层网络分析预测（无NetworkX时使用基础统计）

        功能：样本不足 10 期时随机抽样；NetworkX 不可用时走 _networkx_fallback；
            否则构建共现图/转移图/区间图/尾数图 4 层图，分别计算 PageRank、
            度/介数/特征向量中心性、社区、连通分量、Dijkstra 最短路与
            区间/尾数关联分，按经验权重汇总后取前 count 个号码。
        参数：
            count (int): 需要返回的号码个数，默认 6。
        数学含义:
            构建 4 层图：共现图（边权为同期共现次数）、转移图（相邻两期共现）、
            区间关系图（同区间 weight=3、相邻区间 weight=1）、尾数关系图
            （同尾数 weight=2）；对前两层计算 PageRank（NetworkX 默认
            alpha=0.85）、度中心性、介数中心性、特征向量中心性，
            再叠加社区（greedy_modularity_communities，Louvain 近似）、
            连通分量、Dijkstra 最短路、区间/尾数关联分，线性加权为图论得分。
        输入依赖:
            self.data（至少 10 期）、_build_number_graph、_build_transition_graph、
            self.missing、self.frequency、self._get_weighted_score。
        适用场景:
            需要用图结构刻画号码共现/转移关系时；NetworkX 缺失时走
            _networkx_fallback，样本不足 10 期时随机抽样。
        返回：
            list[int]，长度 count，按综合得分降序的号码（1..49）。
        异常：
            各图指标单独 try/except 兜底；整体异常时退化为
            _get_weighted_score 排序。
        注意：
            懒加载 NetworkX；构建多个 49 节点小图，纯内存计算，不阻塞。
        """
        if len(self.data) < 10:
            return random.sample(range(1, 50), count)
        
        # 无NetworkX时使用基础统计方法
        nx = _get_nx()
        if nx is None:
            return self._networkx_fallback(count)
        
        scores = {}
        try:
            # 构建多层图网络
            # 层1：共现图
            G_cooccur = self._build_number_graph()
            
            # 层2：转移图
            G_trans = self._build_transition_graph()
            
            # 层3：区间关系图
            G_range = nx.Graph()
            for i in range(1, 50):
                for j in range(i+1, 50):
                    range_diff = abs(LotteryConfig.get_range_index(i) - LotteryConfig.get_range_index(j))
                    if range_diff == 0:
                        G_range.add_edge(i, j, weight=3)
                    elif range_diff == 1:
                        G_range.add_edge(i, j, weight=1)
            
            # 层4：尾数关系图
            G_tail = nx.Graph()
            for i in range(1, 50):
                for j in range(i+1, 50):
                    if LotteryConfig.get_tail_digit(i) == LotteryConfig.get_tail_digit(j):
                        G_tail.add_edge(i, j, weight=2)
            
            # 综合图论指标
            # PageRank中心性
            try:
                pagerank_cooccur = nx.pagerank(G_cooccur, weight='weight')
                pagerank_trans = nx.pagerank(G_trans, weight='weight')
            except Exception:
                # 1/49≈0.0204：PageRank 失败时用均匀分布作为中性兜底
                pagerank_cooccur = {n: 0.02 for n in range(1, 50)}
                pagerank_trans = {n: 0.02 for n in range(1, 50)}
            
            # 度中心性
            try:
                degree_cooccur = nx.degree_centrality(G_cooccur)
                degree_trans = nx.degree_centrality(G_trans)
            except Exception:
                degree_cooccur = {n: 0 for n in range(1, 50)}
                degree_trans = {n: 0 for n in range(1, 50)}
            
            # 介数中心性
            try:
                betweenness_cooccur = nx.betweenness_centrality(G_cooccur, weight='weight')
                betweenness_trans = nx.betweenness_centrality(G_trans, weight='weight')
            except Exception:
                betweenness_cooccur = {n: 0 for n in range(1, 50)}
                betweenness_trans = {n: 0 for n in range(1, 50)}
            
            # 特征向量中心性
            try:
                eigen_cooccur = nx.eigenvector_centrality(G_cooccur, weight='weight', max_iter=1000)
                eigen_trans = nx.eigenvector_centrality(G_trans, weight='weight', max_iter=1000)
            except Exception:
                eigen_cooccur = {n: 0 for n in range(1, 50)}
                eigen_trans = {n: 0 for n in range(1, 50)}
            
            # 社区检测
            try:
                communities = list(nx.community.greedy_modularity_communities(G_cooccur, weight='weight'))
                community_id = {n: -1 for n in range(1, 50)}
                for idx, comm in enumerate(communities):
                    for n in comm:
                        community_id[n] = idx
            except Exception:
                # 社区检测失败时把所有号码视作同一社区，避免整段结果丢失
                communities = [set(range(1, 50))]
                community_id = {n: 0 for n in range(1, 50)}
            
            # 连通分量
            try:
                components = list(nx.connected_components(G_cooccur))
                component_id = {n: -1 for n in range(1, 50)}
                for idx, comp in enumerate(components):
                    for n in comp:
                        component_id[n] = idx
            except Exception:
                components = [set(range(1, 50))]
                component_id = {n: 0 for n in range(1, 50)}
            
            # 聚类系数
            try:
                clustering_cooccur = nx.clustering(G_cooccur)
            except Exception:
                clustering_cooccur = {n: 0 for n in range(1, 50)}
            
            # 最新一期所在社区和分量
            latest_nums = set(self.data[0].get('numbers', []))
            target_communities = set()
            target_components = set()
            for num in latest_nums:
                target_communities.add(community_id.get(num, -1))
                target_components.add(component_id.get(num, -1))
            
            # Dijkstra最短路径
            try:
                shortest_paths = {}
                for target in range(1, 50):
                    min_dist = float('inf')
                    for source in latest_nums:
                        try:
                            path_len = nx.dijkstra_path_length(G_trans, source, target, weight='weight')
                            min_dist = min(min_dist, path_len)
                        except nx.NetworkXNoPath:
                            continue
                    shortest_paths[target] = min_dist if min_dist < float('inf') else 100
            except Exception:
                # 100 表示“不可达”；统一罚值可让后续 path_score 归零
                shortest_paths = {n: 100 for n in range(1, 50)}
            
            # 综合得分
            for num in range(1, 50):
                # 共现图指标
                pr_co = pagerank_cooccur.get(num, 0.02)
                deg_co = degree_cooccur.get(num, 0)
                betw_co = betweenness_cooccur.get(num, 0)
                eigen_co = eigen_cooccur.get(num, 0)
                cluster_co = clustering_cooccur.get(num, 0)
                
                # 转移图指标
                pr_tr = pagerank_trans.get(num, 0.02)
                deg_tr = degree_trans.get(num, 0)
                betw_tr = betweenness_trans.get(num, 0)
                eigen_tr = eigen_trans.get(num, 0)
                
                # 社区得分
                comm_score = 15 if community_id.get(num, -1) in target_communities else 3
                
                # 连通分量得分
                comp_score = 10 if component_id.get(num, -1) in target_components else 2
                
                # 最短路径得分
                # 100 是不可达的罚值；乘以 2 后 max(0, ...) 归零，等价于不给分
                path_score = max(0, 20 - shortest_paths.get(num, 100) * 2)
                
                # 区间和尾数关联得分
                range_score = 0
                tail_score = 0
                for ln in latest_nums:
                    if G_range.has_edge(num, ln):
                        range_score += G_range[num][ln].get('weight', 1)
                    if G_tail.has_edge(num, ln):
                        tail_score += G_tail[num][ln].get('weight', 1)
                
                # 基础特征得分
                base_score = self._get_weighted_score(num) / 100
                
                # 遗漏得分
                miss_s = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                
                # 频率得分
                freq_s = self.frequency.get(num, 0) / len(self.data) if self.data else 0
                
                # 综合图论得分
                # 共现图 40/20/15/15、转移图 30/15/10/15 为经验权重：
                # PageRank 反映全局中心性故权重最高，介数/特征向量次之
                graph_score = (pr_co * 40 + deg_co * 20 + betw_co * 15 + eigen_co * 15 +
                              pr_tr * 30 + deg_tr * 15 + betw_tr * 10 + eigen_tr * 15 +
                              cluster_co * 10 + comm_score * 8 + comp_score * 5 +
                              path_score * 3 + range_score * 2 + tail_score * 2)
                
                scores[num] = (graph_score * 3 +  # 图论指标权重
                             base_score * 30 +
                             miss_s * 20 +
                             freq_s * 50)
            
        except Exception as e:
            for num in range(1, 50):
                scores[num] = self._get_weighted_score(num)
        
        sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [num for num, _ in sorted_nums[:count]]
    
    # 功能8：特别码专项分析 - 新增特别码专属算法
    def special_frequency_regression(self, count=1):
        """
        基于特别码历史频率加权回归算法（索引21）

        功能：基于特别码历史频率加权回归（索引21）：
        - 分析历史特别码的出现频率
        - 结合遗漏周期和频率进行加权回归
        - 返回置信度最高的特别码
        参数：
            count (int): 需要返回的特别码个数，默认 1；通常只取第 1 名。
        数学含义:
            对每个特别码计算三项分数并加权求和：
            频率得分（按历史最大频次归一化）权重 0.3；
            遗漏得分 min(1, gap/(N/3)) 权重 0.3；
            指数回归得分 1-exp(-gap/10) 权重 0.4（遗漏越久越接近“回补”）。
        输入依赖:
            self.data 中每期的 'special' 字段（仅统计 1..49）；无特别码的期忽略。
        适用场景:
            LotteryConfig.ALGORITHMS 下标 21 的专项算法，只预测 1 个特别码。
        返回：
            list[int]: 预测的特别码列表（通常为1个，按得分降序）；
            数据不足 5 期或异常时返回 [random.randint(1, 49)]。
        异常：
            内部异常被捕获，返回随机特别码，不向外抛出。
        注意：
            兜底路径使用全局 random，结果不可复现；正常路径无副作用。
        """
        if not self.data or len(self.data) < 5:
            return [random.randint(1, 49)]
        
        try:
            # 统计特别码频率
            special_freq = Counter()
            for record in self.data:
                special = record.get('special', 0)
                if 1 <= special <= 49:
                    special_freq[special] += 1
            
            # 计算遗漏值
            special_missing = {i: 0 for i in range(1, 50)}
            appeared_specials = set()
            for i, record in enumerate(self.data):
                sp = record.get('special', 0)
                # 只在首次出现时记录下标，即最近一次出现的期距离
                # （沿用 data[0] 为最新一期的约定）
                if sp and sp not in appeared_specials:
                    special_missing[sp] = i
                    appeared_specials.add(sp)
            for num in range(1, 50):
                if num not in appeared_specials:
                    special_missing[num] = len(self.data)
            
            # 加权得分计算
            max_freq = max(special_freq.values()) if special_freq else 1
            scores = {}
            for num in range(1, 50):
                # 频率得分（归一化）
                freq_score = special_freq.get(num, 0) / max_freq if max_freq > 0 else 0
                
                # 遗漏回归得分（遗漏越大，回归概率越高）
                miss = special_missing.get(num, len(self.data))
                # 以 N/3 为饱和点：遗漏达到样本数的 1/3 即视为满分
                miss_score = min(1.0, miss / (len(self.data) / 3))
                
                # 指数加权回归
                miss_exp = 1 - np.exp(-miss / 10)
                
                # 综合得分
                scores[num] = freq_score * 0.3 + miss_score * 0.3 + miss_exp * 0.4
            
            # 按得分排序，取前count个
            sorted_nums = sorted(scores.items(), key=lambda x: x[1], reverse=True)
            return [num for num, _ in sorted_nums[:count]]
        except Exception:
            return [random.randint(1, 49)]
    
    def special_correlation_algorithm(self, count=1):
        """
        基于特别码与正码关联规则挖掘算法（索引22）

        功能：基于特别码与正码关联规则挖掘（索引22）：
        - 挖掘正码与特别码之间的关联规则
        - 分析哪些正码经常与哪些特别码同时出现
        - 基于最新一期正码预测最可能出现的特别码
        参数：
            count (int): 需要返回的特别码个数，默认 1；通常只取第 1 名。
        数学含义:
            统计“正码→特别码”的共现频次（一阶关联规则），用最新一期正码
            查表汇总各特别码的关联强度并归一化；
            综合得分 = 关联 0.5 + 遗漏得分 0.25 + 指数回归 0.25。
        输入依赖:
            self.data 的 'numbers'（正码）与 'special'（特别码）；两者都需在 1..49。
        适用场景:
            LotteryConfig.ALGORITHMS 下标 22 的专项算法，只预测 1 个特别码。
        返回：
            list[int]: 预测的特别码列表（通常为1个，按得分降序）；
            数据不足 10 期、无共现或异常时返回 [random.randint(1, 49)]。
        异常：
            内部异常被捕获，返回随机特别码，不向外抛出。
        注意：
            兜底路径使用全局 random，结果不可复现；正常路径无副作用。
        """
        if not self.data or len(self.data) < 10:
            return [random.randint(1, 49)]
        
        try:
            # 构建正码与特别码的共现矩阵
            cooccurrence = defaultdict(Counter)
            for record in self.data:
                numbers = record.get('numbers', [])
                special = record.get('special', 0)
                if 1 <= special <= 49 and numbers:
                    for num in numbers:
                        if 1 <= num <= 49:
                            cooccurrence[num][special] += 1
            
            if not cooccurrence:
                return [random.randint(1, 49)]
            
            # 获取最新一期正码
            latest_numbers = self.data[0].get('numbers', []) if self.data else []
            
            # 统计每个特别码的关联得分
            special_scores = Counter()
            for num in latest_numbers:
                if num in cooccurrence:
                    for sp, count_val in cooccurrence[num].items():
                        special_scores[sp] += count_val
            
            # 如果没有关联数据，使用频率
            if not special_scores:
                for record in self.data:
                    sp = record.get('special', 0)
                    if 1 <= sp <= 49:
                        special_scores[sp] += 1
            
            # 计算遗漏值进行修正
            special_missing = {i: 0 for i in range(1, 50)}
            appeared_specials = set()
            for i, record in enumerate(self.data):
                sp = record.get('special', 0)
                if sp and sp not in appeared_specials:
                    special_missing[sp] = i
                    appeared_specials.add(sp)
            for num in range(1, 50):
                if num not in appeared_specials:
                    special_missing[num] = len(self.data)
            
            # 综合得分
            max_cooc = max(special_scores.values()) if special_scores else 1
            final_scores = {}
            for sp in range(1, 50):
                cooc_score = special_scores.get(sp, 0) / max_cooc if max_cooc > 0 else 0
                miss = special_missing.get(sp, len(self.data))
                miss_score = min(1.0, miss / (len(self.data) / 3))
                miss_exp = 1 - np.exp(-miss / 10)
                final_scores[sp] = cooc_score * 0.5 + miss_score * 0.25 + miss_exp * 0.25
            
            # 排序取前count个
            sorted_nums = sorted(final_scores.items(), key=lambda x: x[1], reverse=True)
            return [num for num, _ in sorted_nums[:count]]
        except Exception:
            return [random.randint(1, 49)]
    
    # 功能4：预测结果置信度显示 - 获取预测置信度
    def get_prediction_scores(self, algorithm_index, count=6):
        """
        获取预测号码及其置信度

        功能：按 algorithm_index 选择对应得分方法，把原始得分线性归一化到
            40~100 的置信度百分比后降序取前 count 个；索引 21/22 直接调用
            特别码算法并固定给 75.0；越界索引回退综合推荐。
        - 基于算法内部得分计算每个预测号码的置信度百分比
        - 置信度分级：≥70%强烈推荐，40%-69%一般推荐，<40%谨慎参考
          （归一化公式下限为 40，因此实际输出不会低于 40%）

        algorithm_index 与 LotteryConfig.ALGORITHMS（共 23 项）下标一一对应：
            0 综合推荐              → _get_comprehensive_scores
            1 冷热数字算法          → _get_hot_cold_scores
            2 单双算法              → _get_odd_even_scores
            3 大小算法              → _get_big_small_scores
            4 遗漏值分析算法        → _get_missing_scores
            5 连号/邻号分析算法     → _get_adjacent_scores
            6 尾数分布算法          → _get_tail_scores
            7 区间分布算法          → _get_range_scores
            8 轮盘赌选择算法        → _get_roulette_scores
            9 历史相似性算法        → _get_similarity_scores
            10 泊松概率分布算法     → _get_poisson_scores
            11 玄学算法             → _get_mystical_scores
            12 号码关联图算法       → _get_graph_scores
            13 最短路径算法         → _get_shortest_path_scores
            14 社区发现算法         → _get_community_scores
            15 图聚类算法           → _get_cluster_scores
            16 NumPy矩阵算法        → _get_numpy_scores
            17 SciPy优化算法        → _get_scipy_scores
            18 Scikit-learn集成算法 → _get_sklearn_scores
            19 PyTorch深度学习算法  → _get_pytorch_scores
            20 NetworkX图算法       → _get_networkx_scores
            21 特别码频率回归       → special_frequency_regression（固定 75.0）
            22 特别码关联算法       → special_correlation_algorithm（固定 75.0）
            其他越界索引            → 回退到 _get_comprehensive_scores

        参数：
            algorithm_index: 算法索引（0-22）
            count: 需要返回的号码数量

        返回：
            tuple: (numbers: list[int], scores_dict: dict[int, float])
                   numbers为按置信度降序的预测号码列表；
                   scores_dict为{number: confidence_percentage}（40~100 的百分比）；
                   raw_scores 为空时返回 ([], {})
        异常：
            整体异常被捕获，返回 ([随机号码], {同一随机号码: 50.0})。
        注意：
            不修改 self；仅 21/22 两条分支会调用带随机兜底的特别码算法。
        TODO(待确认): 索引 9/13/14/15/20 虽有独立分支，但其得分方法内部
            复用综合/图得分，并非各自独立的算法实现。
        """
        try:
            # 根据算法索引选择预测方法并获取得分
            raw_scores = {}
            
            if algorithm_index == 0:
                # 综合推荐
                raw_scores = self._get_comprehensive_scores()
            elif algorithm_index == 1:
                # 冷热数字
                raw_scores = self._get_hot_cold_scores()
            elif algorithm_index == 2:
                # 单双算法
                raw_scores = self._get_odd_even_scores()
            elif algorithm_index == 3:
                # 大小算法
                raw_scores = self._get_big_small_scores()
            elif algorithm_index == 4:
                # 遗漏值分析
                raw_scores = self._get_missing_scores()
            elif algorithm_index == 5:
                # 连号邻号分析
                raw_scores = self._get_adjacent_scores()
            elif algorithm_index == 6:
                # 尾数分布
                raw_scores = self._get_tail_scores()
            elif algorithm_index == 7:
                # 区间分布
                raw_scores = self._get_range_scores()
            elif algorithm_index == 8:
                # 轮盘赌选择
                raw_scores = self._get_roulette_scores()
            elif algorithm_index == 9:
                # 历史相似性
                raw_scores = self._get_similarity_scores()
            elif algorithm_index == 10:
                # 泊松分布
                raw_scores = self._get_poisson_scores()
            elif algorithm_index == 11:
                # 玄学算法
                raw_scores = self._get_mystical_scores()
            elif algorithm_index == 12:
                # 号码关联图
                raw_scores = self._get_graph_scores()
            elif algorithm_index == 13:
                # 最短路径
                raw_scores = self._get_shortest_path_scores()
            elif algorithm_index == 14:
                # 社区发现
                raw_scores = self._get_community_scores()
            elif algorithm_index == 15:
                # 图聚类
                raw_scores = self._get_cluster_scores()
            elif algorithm_index == 16:
                # NumPy矩阵
                raw_scores = self._get_numpy_scores()
            elif algorithm_index == 17:
                # SciPy优化
                raw_scores = self._get_scipy_scores()
            elif algorithm_index == 18:
                # Scikit-learn
                raw_scores = self._get_sklearn_scores()
            elif algorithm_index == 19:
                # PyTorch
                raw_scores = self._get_pytorch_scores()
            elif algorithm_index == 20:
                # NetworkX图算法
                raw_scores = self._get_networkx_scores()
            elif algorithm_index == 21:
                # 特别码频率回归（返回1个特别码）
                numbers = self.special_frequency_regression(count=1)
                scores_dict = {num: 75.0 for num in numbers}
                return (numbers, scores_dict)
            elif algorithm_index == 22:
                # 特别码关联（返回1个特别码）
                numbers = self.special_correlation_algorithm(count=1)
                scores_dict = {num: 75.0 for num in numbers}
                return (numbers, scores_dict)
            else:
                # 越界索引兜底为综合推荐，避免返回空结果
                raw_scores = self._get_comprehensive_scores()
            
            # 归一化得分到0-100%
            if raw_scores:
                max_score = max(raw_scores.values())
                min_score = min(raw_scores.values())
                score_range = max_score - min_score if max_score != min_score else 1
                # 线性映射到 [40,100]：60 为跨度、40 为保底，再裁剪防止越界
                confidence_dict = {
                    num: max(0, min(100, ((score - min_score) / score_range * 60) + 40))
                    for num, score in raw_scores.items()
                }
                
                # 排序取前count个
                sorted_items = sorted(confidence_dict.items(), key=lambda x: x[1], reverse=True)
                top_numbers = [num for num, _ in sorted_items[:count]]
                top_scores = {num: score for num, score in sorted_items[:count]}
                return (top_numbers, top_scores)
            else:
                return ([], {})
        except Exception:
            # 兜底号码只随机一次，保证返回号码与得分字典键一致
            fallback_num = random.randint(1, 49)
            return ([fallback_num], {fallback_num: 50.0})
    
    def _get_comprehensive_scores(self):
        """综合推荐得分

        功能：对 1..49 每个号码计算 _get_weighted_score×0.4 +
            MathUtils.calculate_missing_cycle(遗漏, 6)×30 + 每期出现概率×100。
        参数：无。
        数学含义:
            基础加权分×0.4 + 遗漏周期×30 + 频率×100；后两项把 [0,1] 区间的
            概率/周期量放大到百分制，作为置信度的主要驱动。
        输入依赖:
            self.frequency、self.missing、self.data、self._get_weighted_score。
        适用场景:
            索引 0（综合推荐），也作为未知索引与图算法/模型缺失时的兜底打分。
        返回：
            dict[int,float]，键 1..49，值为原始综合分（未归一化）。
        异常：
            不抛异常；self.data 为空时频率项按 0 处理。
        注意：
            无。
        """
        scores = {}
        for num in range(1, 50):
            base = self._get_weighted_score(num)
            miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
            # 频率折算为每期出现概率（0..1），再乘以 100 放大到百分制
            freq = self.frequency.get(num, 0) / len(self.data) if self.data else 0
            scores[num] = base * 0.4 + miss * 30 + freq * 100
        return scores
    
    def _get_hot_cold_scores(self):
        """冷热数字得分

        功能：以历史最大频次归一化频率×50，再叠加遗漏周期×50。
        参数：无。
        数学含义:
            归一化频率×50 + 遗漏周期×50：频率衡量“热”，遗漏衡量“该回补”，
            两项等权，兼顾追热与补冷。
        输入依赖:
            self.frequency（以历史最大频次归一化）、self.missing。
        适用场景:
            索引 1（冷热数字算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            不抛异常；频率字典为空时 max_freq 取 1 避免除零。
        注意：
            无。
        """
        scores = {}
        max_freq = max(self.frequency.values()) if self.frequency else 1
        for num in range(1, 50):
            freq = self.frequency.get(num, 0) / max_freq if max_freq > 0 else 0
            miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
            scores[num] = freq * 50 + miss * 50
        return scores
    
    def _get_odd_even_scores(self):
        """单双算法得分

        功能：按历史奇数占比决定多数派方向，奇数/偶数分别取 0.6/0.4（或反向），
            得分×100 后叠加遗漏周期×30。
        参数：无。
        数学含义:
            把历史奇数占比直接当作“多数派方向”：占比 >0.5 时奇数给 0.6、
            偶数给 0.4，否则反向；得分×100 后再加遗漏×30。
        输入依赖:
            self.odd_even_ratio（缺失时按 0.5 中性处理）、self.missing。
        适用场景:
            索引 2（单双算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分（同类号码得分相同，靠遗漏分打破平局）。
        异常：
            不抛异常。
        注意：
            无。
        """
        scores = {}
        odd_ratio = self.odd_even_ratio if hasattr(self, 'odd_even_ratio') else 0.5
        # 0.6/0.4 是“多数派略占优”的经验偏置，而非严格按历史比例取值
        target_odd = 0.6 if odd_ratio > 0.5 else 0.4
        for num in range(1, 50):
            is_odd = num % 2 == 1
            score = target_odd if is_odd else (1 - target_odd)
            miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
            scores[num] = score * 100 + miss * 30
        return scores
    
    def _get_big_small_scores(self):
        """大小算法得分

        功能：以 25 为界（1..25 小、26..49 大），按历史大号占比决定大小方向，
            多数派取 0.6、少数派取 0.4，得分×100 后叠加遗漏周期×30。
        参数：无。
        数学含义:
            以 25 为界（1..25 为小、26..49 为大，与 LotteryConfig.is_big 一致）：
            历史大号占比 >0.5 时大号给 0.6、小号 0.4，否则反向；
            得分×100 后再加遗漏×30。
        输入依赖:
            self.big_small_ratio（缺失时按 0.5）、self.missing。
        适用场景:
            索引 3（大小算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            不抛异常。
        注意：
            无。
        """
        scores = {}
        big_ratio = self.big_small_ratio if hasattr(self, 'big_small_ratio') else 0.5
        # 0.6/0.4 为多数派偏置的经验值
        target_big = 0.6 if big_ratio > 0.5 else 0.4
        for num in range(1, 50):
            # 25 及以下为小号，26..49 为大号
            is_big = num > 25
            score = target_big if is_big else (1 - target_big)
            miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
            scores[num] = score * 100 + miss * 30
        return scores
    
    def _get_missing_scores(self):
        """遗漏值得分

        功能：对每个号码计算 MathUtils.calculate_missing_cycle(遗漏, 6)×100。
        参数：无。
        数学含义:
            MathUtils.calculate_missing_cycle(遗漏, 6)×100：以平均周期 6 期为
            基准，把当前遗漏映射为 0..1 的回补概率再放大到百分制。
        输入依赖:
            self.missing。
        适用场景:
            索引 4（遗漏值分析算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分；遗漏越大得分越高。
        异常：
            不抛异常。
        注意：
            无。
        """
        scores = {}
        for num in range(1, 50):
            miss = self.missing.get(num, 50)
            scores[num] = MathUtils.calculate_missing_cycle(miss, 6) * 100
        return scores
    
    def _get_adjacent_scores(self):
        """连号邻号得分

        功能：所有号码先得基础 30 分，最近 5 期出现的号码其 n±1 邻号每次加 15 分
            （1 与 49 为边界，越界邻号忽略），最后叠加遗漏周期×20。
        参数：无。
        数学含义:
            所有号码先得基础 30 分；最近 5 期每个号码的 n±1 邻号每次加 15 分
            （1 与 49 为边界，越界邻号忽略），最后叠加遗漏周期×20。
        输入依赖:
            self.data 前 5 期（按 data[0] 为最新一期的约定）、self.missing。
        适用场景:
            索引 5（连号/邻号分析算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            不抛异常；data 为空时仅保留基础分与遗漏分。
        注意：
            无。
        """
        scores = {i: 30 for i in range(1, 50)}
        if self.data:
            recent = self.data[:5]
            for record in recent:
                for n in record.get('numbers', []):
                    for adj in [n-1, n+1]:
                        if 1 <= adj <= 49:
                            scores[adj] += 15
        for num in range(1, 50):
            miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
            scores[num] += miss * 20
        return scores
    
    def _get_tail_scores(self):
        """尾数分布得分

        功能：基础 20 分 + 尾数分布归一化值×60 + 遗漏周期×20，
            即历史越热的尾数，其下所有号码加分越多。
        参数：无。
        数学含义:
            基础 20 分 + 尾数分布归一化值×60 + 遗漏周期×20：
            历史尾数越热，该尾数下所有号码加分越多。
        输入依赖:
            self.tail_distribution（缺失时跳过该项）、self.missing。
        适用场景:
            索引 6（尾数分布算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            不抛异常；分布为空时 max_tail 取 1 避免除零。
        注意：
            无。
        """
        scores = {i: 20 for i in range(1, 50)}
        if hasattr(self, 'tail_distribution'):
            max_tail = max(self.tail_distribution.values()) if self.tail_distribution else 1
            for num in range(1, 50):
                tail = num % 10
                tail_freq = self.tail_distribution.get(tail, 0) / max_tail if max_tail > 0 else 0
                scores[num] += tail_freq * 60
        for num in range(1, 50):
            miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
            scores[num] += miss * 20
        return scores
    
    def _get_range_scores(self):
        """区间分布得分

        功能：基础 25 分 + 区间分布归一化值×55 + 遗漏周期×20，
            即历史越热的区间，其下所有号码加分越多。
        参数：无。
        数学含义:
            基础 25 分 + 区间分布归一化值×55 + 遗漏周期×20：历史越热的区间，
            该区间内所有号码加分越多。
        输入依赖:
            self.range_distribution（缺失时跳过该项）、LotteryConfig.get_range_index、
            self.missing。
        适用场景:
            索引 7（区间分布算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            不抛异常；分布为空时 max_range 取 1，区间索引 <0 的号码不加分。
        注意：
            无。
        """
        scores = {i: 25 for i in range(1, 50)}
        if hasattr(self, 'range_distribution'):
            max_range = max(self.range_distribution.values()) if self.range_distribution else 1
            for num in range(1, 50):
                ridx = LotteryConfig.get_range_index(num)
                if ridx >= 0:
                    range_freq = self.range_distribution.get(ridx, 0) / max_range if max_range > 0 else 0
                    scores[num] += range_freq * 55
        for num in range(1, 50):
            miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
            scores[num] += miss * 20
        return scores
    
    def _get_roulette_scores(self):
        """轮盘赌选择得分

        功能：每个号码取原始频率 + 遗漏周期×50，相当于轮盘赌扇区面积再叠加回补偏置。
        参数：无。
        数学含义:
            原始频率 + 遗漏周期×50：相当于轮盘赌的“扇区面积”（频率）
            再叠加回补偏置，使长期未出的号码获得更大权重。
        输入依赖:
            self.frequency、self.missing。
        适用场景:
            索引 8（轮盘赌选择算法）的置信度展示。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            不抛异常。
        注意：
            无。
        """
        scores = {}
        for num in range(1, 50):
            freq = self.frequency.get(num, 0)
            miss = self.missing.get(num, 50)
            scores[num] = freq + MathUtils.calculate_missing_cycle(miss, 6) * 50
        return scores
    
    def _get_similarity_scores(self):
        """历史相似性得分

        功能：当前实现不做历史相似度匹配，直接返回 _get_comprehensive_scores()
            的结果（基础加权分×0.4 + 遗漏×30 + 频率×100）。
        参数：无。
        数学含义:
            当前实现不做历史相似度匹配，直接复用综合得分
            （基础加权分×0.4 + 遗漏×30 + 频率×100）。
        输入依赖:
            同 _get_comprehensive_scores。
        适用场景:
            索引 9（历史相似性算法）的置信度展示。
        返回：
            dict[int,float]，键 1..49，值为原始综合分。
        异常：
            不抛异常。
        注意：
            无。
        TODO(待确认): 未体现“历史相似性”，与 ALGORITHMS 中该算法描述不符。
        """
        return self._get_comprehensive_scores()
    
    def _get_poisson_scores(self):
        """泊松分布得分

        功能：以 λ=N/49 为参数，对每个号码历史出现次数 freq 计算泊松概率
            pmf(freq; λ)×100，再叠加遗漏周期×50。
        参数：无。
        数学含义:
            以 λ=N/49（每期单号平均出现次数）为参数，计算该号码历史出现次数
            freq 的泊松概率 pmf(freq; λ)，×100 后叠加遗漏周期×50。
        输入依赖:
            self.data、self.frequency、self.missing；可选 SciPy（懒加载）。
        适用场景:
            索引 10（泊松概率分布算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            不抛异常；SciPy 不可用或 λ≤0 时概率项固定取 0.01。
        注意：
            首次调用可能触发 SciPy 懒加载。
        """
        scores = {}
        avg_freq = len(self.data) / 49 if self.data else 10
        scipy_st = _get_scipy_stats()
        for num in range(1, 50):
            freq = self.frequency.get(num, 0)
            lambda_param = avg_freq
            if lambda_param > 0 and scipy_st is not None and hasattr(scipy_st, 'poisson'):
                poisson_prob = scipy_st.poisson.pmf(freq, lambda_param)
            else:
                poisson_prob = 0.01
            miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
            scores[num] = poisson_prob * 100 + miss * 50
        return scores
    
    def _get_mystical_scores(self):
        """玄学算法得分

        功能：每个号码先取 [25,75) 的伪随机分（RandomState.random()×50+25），
            再叠加遗漏周期×30；无历史规律，仅用于娱乐场景。
        参数：无。
        数学含义:
            每个号码先取 [25,75) 的伪随机分（rng.random()×50+25），
            再叠加遗漏周期×30；无历史规律，仅用于“玄学”娱乐场景。
        输入依赖:
            self.missing；随机数来自本地 RandomState。
        适用场景:
            索引 11（玄学算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            不抛异常。
        注意：
            - 每次调用结果不同（种子取当前时间戳，仅到百万分之一秒级变化）；
            - 使用局部 RandomState 而非全局 random，避免污染全局随机种子。
        """
        # 使用局部RandomState，避免污染全局随机种子
        rng = np.random.RandomState(int(datetime.datetime.now().timestamp()) % 1000000)
        scores = {num: rng.random() * 50 + 25 for num in range(1, 50)}
        for num in range(1, 50):
            miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
            scores[num] += miss * 30
        return scores
    
    def _get_graph_scores(self):
        """号码关联图得分

        功能：用最近 20 期号码的同期共现关系建无向图（边权=共现次数），
            以加权度中心性×2 + 遗漏周期×50 作为得分；NetworkX 不可用或
            样本不足 10 期时回退到 _get_comprehensive_scores。
        参数：无。
        数学含义:
            用最近 20 期的同期共现关系建无向图（边权=共现次数），
            以加权度中心性 degree×2 + 遗漏周期×50 作为得分；
            度越高说明该号码与其它号码的共现网络越中心。
        输入依赖:
            self.data（至少 10 期）、self.missing；可选 NetworkX（懒加载）。
        适用场景:
            索引 12（号码关联图算法）；也作为最短路径/社区/图聚类的近似得分。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            建图或计算异常被捕获；NetworkX 缺失或样本不足 10 期时回退到
            _get_comprehensive_scores。
        注意：
            首次调用可能触发 NetworkX 懒加载；仅构建 49 节点内存图。
        """
        nx_mod = _get_nx()
        if nx_mod is None or not hasattr(self, 'data') or len(self.data) < 10:
            return self._get_comprehensive_scores()
        try:
            G = nx_mod.Graph()
            for num in range(1, 50):
                G.add_node(num)
            for record in self.data[:20]:
                nums = record.get('numbers', [])
                for i in range(len(nums)):
                    for j in range(i+1, len(nums)):
                        if G.has_edge(nums[i], nums[j]):
                            G[nums[i]][nums[j]]['weight'] += 1
                        else:
                            G.add_edge(nums[i], nums[j], weight=1)
            scores = {}
            for num in range(1, 50):
                degree = G.degree(num, weight='weight')
                miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                scores[num] = degree * 2 + miss * 50
            return scores
        except Exception:
            return self._get_comprehensive_scores()
    
    def _get_shortest_path_scores(self):
        """最短路径得分

        功能：当前实现不做 Dijkstra 计算，直接返回 _get_graph_scores()
            的加权度中心性 + 遗漏得分。
        参数：无。
        数学含义:
            当前实现不做 Dijkstra 计算，直接复用 _get_graph_scores 的
            加权度中心性 + 遗漏得分。
        输入依赖:
            同 _get_graph_scores。
        适用场景:
            索引 13（最短路径算法）的置信度展示。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            同 _get_graph_scores（内部已兜底，不向外抛）。
        注意：
            同 _get_graph_scores。
        TODO(待确认): 未实现最短路径语义，与 ALGORITHMS 描述不符。
        """
        return self._get_graph_scores()
    
    def _get_community_scores(self):
        """社区发现得分

        功能：当前实现不做社区划分，直接返回 _get_graph_scores()
            的加权度中心性 + 遗漏得分。
        参数：无。
        数学含义:
            当前实现不做社区划分，直接复用 _get_graph_scores 的
            加权度中心性 + 遗漏得分。
        输入依赖:
            同 _get_graph_scores。
        适用场景:
            索引 14（社区发现算法）的置信度展示。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            同 _get_graph_scores（已内部兜底）。
        注意：
            同 _get_graph_scores。
        TODO(待确认): 未体现社区/模块度语义，与 ALGORITHMS 描述不符。
        """
        return self._get_graph_scores()
    
    def _get_cluster_scores(self):
        """图聚类得分

        功能：当前实现不做连通分量/图聚类，直接返回 _get_graph_scores()
            的加权度中心性 + 遗漏得分。
        参数：无。
        数学含义:
            当前实现不做连通分量/图聚类，直接复用 _get_graph_scores 的
            加权度中心性 + 遗漏得分。
        输入依赖:
            同 _get_graph_scores。
        适用场景:
            索引 15（图聚类算法）的置信度展示。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            同 _get_graph_scores（已内部兜底）。
        注意：
            同 _get_graph_scores。
        TODO(待确认): 未体现图聚类语义，与 ALGORITHMS 描述不符。
        """
        return self._get_graph_scores()
    
    def _get_numpy_scores(self):
        """NumPy矩阵得分

        功能：对 self.np_features（约 (49,7) 的特征矩阵）按列求均值，
            取第 idx%7 个特征均值×50，再叠加遗漏周期×50；矩阵缺失或异常时
            回退到 _get_comprehensive_scores。
        参数：无。
        数学含义:
            对 self.np_features（形状约 (49,7) 的特征矩阵）按列求均值，
            取 7 个特征均值中的第 idx%7 个作为该号码的模型分，
            ×50 后叠加遗漏周期×50。
        输入依赖:
            self.np_features（缺失或计算失败时回退）、self.missing。
        适用场景:
            索引 16（NumPy矩阵算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分；
            np_features 为 None 或异常时返回 _get_comprehensive_scores 的结果。
        异常：
            内部异常被捕获后回退，不向外抛。
        注意：
            无（只读矩阵，不做矩阵分解）。
        TODO(待确认): 7 个特征均值按 idx%7 循环赋给 49 个号码，与号码本身无对应
            关系，仅能提供整体热度基准。
        """
        if hasattr(self, 'np_features') and self.np_features is not None:
            try:
                scores = {}
                feature_means = np.mean(self.np_features, axis=0)
                for idx, num in enumerate(range(1, 50)):
                    score = float(feature_means[idx % len(feature_means)])
                    miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                    scores[num] = score * 50 + miss * 50
                return scores
            except Exception:
                pass
        return self._get_comprehensive_scores()
    
    def _get_scipy_scores(self):
        """SciPy优化得分

        功能：读取 self.scipy_smoothed（长度 49 的卷积平滑频率序列），
            取第 idx%len 个值×50，再叠加遗漏周期×50；缺失或异常时回退到
            _get_comprehensive_scores。
        参数：无。
        数学含义:
            读取 self.scipy_smoothed（长度 49 的卷积平滑频率序列），
            取第 idx%len 个值×50，再叠加遗漏周期×50。
        输入依赖:
            self.scipy_smoothed（缺失时回退）、self.missing。
        适用场景:
            索引 17（SciPy优化算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分；
            scipy_smoothed 为 None 或异常时返回 _get_comprehensive_scores。
        异常：
            内部异常被捕获后回退，不向外抛。
        注意：
            无（不重新做卷积/优化）。
        """
        if hasattr(self, 'scipy_smoothed') and self.scipy_smoothed is not None:
            try:
                scores = {}
                smoothed_arr = self.scipy_smoothed
                for idx, num in enumerate(range(1, 50)):
                    score = float(smoothed_arr[idx % len(smoothed_arr)])
                    miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                    scores[num] = score * 50 + miss * 50
                return scores
            except Exception:
                pass
        return self._get_comprehensive_scores()
    
    def _get_sklearn_scores(self):
        """Scikit-learn得分

        功能：读取 KMeans 聚类标签 self.kmeans_labels，以 49 号所属簇为目标簇，
            同簇号码得 100 分、异簇 30 分，再叠加遗漏周期×30；标签缺失或
            异常时回退到 _get_comprehensive_scores。
        参数：无。
        数学含义:
            读取 KMeans 聚类标签 self.kmeans_labels（下标 0..48 对应号码 1..49），
            以最后一个号码（49 号）所属簇为目标簇：同簇得 100 分、异簇 30 分，
            再叠加遗漏周期×30。
        输入依赖:
            self.kmeans_labels（np.ndarray|None）、self.missing。
        适用场景:
            索引 18（Scikit-learn集成算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分；
            kmeans_labels 为 None 或异常时返回 _get_comprehensive_scores。
        异常：
            内部异常被捕获后回退，不向外抛。
        注意：
            无（不重新训练 KMeans）。
        TODO(待确认): 以 49 号所属簇作为“目标簇”缺乏业务依据，建议确认设计意图。
        """
        if hasattr(self, 'kmeans_labels') and self.kmeans_labels is not None:
            try:
                scores = {}
                target_cluster = self.kmeans_labels[-1] if len(self.kmeans_labels) > 0 else 0
                for idx, num in enumerate(range(1, 50)):
                    cluster = self.kmeans_labels[idx % len(self.kmeans_labels)]
                    score = 100 if cluster == target_cluster else 30
                    miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                    scores[num] = score + miss * 30
                return scores
            except Exception:
                pass
        return self._get_comprehensive_scores()
    
    def _get_pytorch_scores(self):
        """PyTorch得分

        功能：读取 LSTM 预测概率 self.pt_lstm_preds（{号码: 概率}），
            按最大概率归一化后×100，再叠加遗漏周期×30；概率缺失或异常时
            回退到 _get_comprehensive_scores。
        参数：无。
        数学含义:
            读取 LSTM 预测概率 self.pt_lstm_preds（{号码: 概率}），
            按最大概率归一化后×100，再叠加遗漏周期×30。
        输入依赖:
            self.pt_lstm_preds（缺失时回退）、self.missing。
        适用场景:
            索引 19（PyTorch深度学习算法）。
        返回：
            dict[int,float]，键 1..49，值为原始得分；
            pt_lstm_preds 为空或异常时返回 _get_comprehensive_scores。
        异常：
            内部异常被捕获后回退，不向外抛。
        注意：
            无（不重新训练模型）。
        """
        if hasattr(self, 'pt_lstm_preds') and self.pt_lstm_preds:
            try:
                scores = {}
                max_prob = max(self.pt_lstm_preds.values()) if self.pt_lstm_preds else 1
                for num in range(1, 50):
                    prob = self.pt_lstm_preds.get(num, 0) / max_prob if max_prob > 0 else 0
                    miss = MathUtils.calculate_missing_cycle(self.missing.get(num, 50), 6)
                    scores[num] = prob * 100 + miss * 30
                return scores
            except Exception:
                pass
        return self._get_comprehensive_scores()
    
    def _get_networkx_scores(self):
        """NetworkX图算法得分

        功能：直接返回 _get_graph_scores() 的加权度中心性 + 遗漏得分，
            未重复计算 PageRank/中心性/社区等全套图指标。
        参数：无。
        数学含义:
            当前实现直接复用 _get_graph_scores 的加权度中心性 + 遗漏得分，
            未重复计算 PageRank/中心性/社区等全套图指标。
        输入依赖:
            同 _get_graph_scores。
        适用场景:
            索引 20（NetworkX图算法）的置信度展示。
        返回：
            dict[int,float]，键 1..49，值为原始得分。
        异常：
            同 _get_graph_scores（已内部兜底）。
        注意：
            同 _get_graph_scores。
        TODO(待确认): 与 networkx_graph_algorithm 的多层图指标不一致，
            置信度展示仅为近似值。
        """
        return self._get_graph_scores()


# 库使用统计注释 - v7.5深度集成验证
#
# 【NumPy深度使用】
# - np.linalg.lstsq: _np_linear_regression_trend, _scipy_big_interp
# - np.dot: _np_correlation_coefficients, _scipy_big_interp
# - np.histogram: _np_distribution_histogram, _np_hot_histogram_bonus
# - np.percentile: _np_distribution_histogram, _np_missing_percentile
# - np.corrcoef: _np_correlation_coefficients, _scipy_odd_correction
# - np.exp: hot_cold_algorithm, _scipy_hot_smooth
# - np.vander: _np_linear_regression_trend
# - np.nan_to_num: _np_correlation_coefficients
#
# 【SciPy深度使用】
# - scipy.optimize.minimize: _scipy_optimize_weights
# - scipy.signal.convolve: _scipy_smooth_trend, _scipy_hot_smooth
# - scipy.interpolate.splrep/splev: _scipy_interpolate_missing, _scipy_missing_interp
# - scipy.stats.ks_2samp: _scipy_distribution_test, _scipy_odd_correction
# - scipy.stats.poisson.cdf/sf: poisson_distribution
# - scipy.stats.expon.cdf/sf: poisson_distribution
#
# 【Scikit-learn深度使用】
# - StandardScaler: _prepare_sklearn_features, odd_even_algorithm, big_small_algorithm
# - MinMaxScaler: _range_cv_scores, _scipy_big_interp
# - RandomForestClassifier: big_small_algorithm, _gb_predict_probs
# - GradientBoostingClassifier: comprehensive_recommendation, _range_cv_scores
# - LogisticRegression: odd_even_algorithm, _lr_roulette_weights, roulette_selection
# - MLPClassifier: adjacent_number_analysis (_mlp_adjacent_probs)
# - GaussianNB: missing_value_analysis (_nb_missing_probs)
# - KMeans: _prepare_sklearn_features, hot_cold_algorithm, tail_distribution_algorithm
# - PCA: _pca_historical_similarity
# - cosine_similarity: historical_similarity, _pca_historical_similarity
# - cross_val_score: _range_cv_scores
#
# 【PyTorch深度使用】
# - torch.nn.LSTM: _prepare_pytorch_lstm, LotteryLSTM类
# - torch.nn.Linear/ReLU/Dropout/Sigmoid: _prepare_pytorch_lstm
# - torch.nn.BCELoss/MSELoss: _prepare_pytorch_lstm, _pt_autoencoder
# - torch.optim.Adam: _prepare_pytorch_lstm, _pt_autoencoder
# - torch.softmax: roulette_selection, mystical_algorithm
# - torch.rand: mystical_algorithm, _prepare_pytorch_lstm
# - torch.cat/stack: _prepare_pytorch_lstm
# - model.train/backward/step: _prepare_pytorch_lstm完整训练循环
#
# 【TensorFlow深度使用】
# - tensorflow.keras.Sequential: _prepare_tensorflow_model, _tf_fc_classifier
# - tensorflow.keras.layers.LSTM: _prepare_tensorflow_model
# - tensorflow.keras.layers.Dense/Dropout: _prepare_tensorflow_model, _tf_fc_classifier
# - tensorflow.keras.Model: _tf_autoencoder
# - tf.random.set_seed: _prepare_tensorflow_model
# - model.compile/fit/predict: _prepare_tensorflow_model, _tf_fc_classifier
#
# 【Pandas深度使用（可选）】
# - pandas.DataFrame: _build_dataframe（缺库时 self.df=None，仅本步骤降级）
# - pandas.Series: range_distribution_algorithm 的兜底路径（缺库时改用纯列表）
#
# 【Statsmodels深度使用】
# - sm.tsa.acf: _calculate_autocorrelation
#
# 【Optuna深度使用】
# - optuna.create_study/suggest_float: _optimize_ensemble_weights
# - TPESampler: 贝叶斯优化采样器
#



# 大数据分析器：从历史记录中挖掘最合适的 7 个生肖与 7 个数字，并给出红波 / 绿波 / 蓝波评分


class BigDataAnalyzer:
    """大数据分析器（历史频率 + 遗漏 + 转移 三维评分，含红波/绿波/蓝波波色分析）

    功能：按 period 倒序取窗口记录，计算频率/遗漏/转移三项特征与波色特征，
        各自归一化后加权求和，挖掘最合适的 pick 个数字与生肖，并附带
        统计检验与趋势文本。
    参数：无（类无实例状态，所有方法均为 @classmethod，入参见各方法）。
    返回：无（类本身不返回值，分析结果由 analyze 返回 dict）。
    从历史开奖记录中挖掘最合适的 7 个生肖与 7 个数字，保证：
        - 推荐的数字互不重复（每个数字只出现一次）
        - 推荐的生肖互不重复（每个生肖只出现一次）

    评分模型（三项特征归一化后加权求和）：
        1. 频率特征 freq：按时间衰减加权的出现次数，近期权重更高
        2. 遗漏特征 gap ：距离上次出现的期数，越久未出补偿越高
        3. 转移特征 trans：以最近一期号码为条件的一阶马尔可夫转移强度
    生肖评分：由其成员号码的综合分均值 + 生肖整体出现频率共同决定

    数学细节:
        - 三项特征各自除以本维最大值做线性归一化（见 analyze 内 _normalize），
          再按权重（默认 0.55/0.25/0.20，可传参覆盖并重新归一化到和为 1）加权；
        - 时间衰减为 decay**idx（idx=0 为最新一期），decay 默认 0.995；
        - 波色（红波/绿波/蓝波）沿用同一套 freq/gap/trans 口径统计成员号码命中。

    注意：
        - 全部方法为 @classmethod，不持有实例状态，可只读并发调用；
        - 只读入参 records（排序会生成新列表，不修改原列表）；
        - 纯内存计算，不写文件、不联网、不使用随机数。

    适用场景:
        需要 7 个互不重复号码/生肖建议、并附带统计检验与波色冷热时；
        结果仅供数据分析参考，不构成投注建议。
    """

    # 默认特征权重（自动归一化，可传参覆盖）
    DEFAULT_WEIGHTS = {'freq': 0.55, 'gap': 0.25, 'trans': 0.20}

    # 三色波号码分组（红波 / 绿波 / 蓝波），用于波色分析
    WAVE_GROUPS = [
        ('红波', LotteryConfig.RED_NUMBERS),
        ('绿波', LotteryConfig.GREEN_NUMBERS),
        ('蓝波', LotteryConfig.BLUE_NUMBERS),
    ]

    @classmethod
    def analyze(cls, records, zodiac_binding=None, window=100, weights=None,
                pick=7, decay=0.995, special_weight=0.8):
        """执行大数据分析，返回推荐生肖与推荐数字

        功能：records 按 period 倒序取前 window 期后，依次计算号码的频率
            （时间衰减加权）、遗漏（距上次出现期数）、转移（最近一期条件状态
            下的后继强度）与红/绿/蓝波特征，按归一化后权重加权打分，
            再去重取前 pick 个数字与生肖，并调用 _compute_statistics 生成统计检验。
        窗口方向:
            records 先按 period 倒序（索引 0 为最新一期），再取前 window 期；
            因此 idx 越小越新，时间衰减 decay**idx 随 idx 增大而递减。
        参数：
            records: 历史记录列表，元素形如
                     {'period': int, 'date': str, 'numbers': [6个号码], 'special': int}
                     无需保证顺序，内部会按 period 倒序排列
            zodiac_binding: {数字: 生肖名称} 映射；为空时使用 LotteryConfig.NUMBER_NAMES
            window: 参与分析的最大期数（从最新一期往前取），默认 100
            weights: 三项特征权重，形如 {'freq':0.55,'gap':0.25,'trans':0.20}；
                     负值按 0 处理，随后归一化到总和为 1
            pick: 推荐数量，默认 7（即 7 个数字 / 7 个生肖）
            decay: 时间衰减系数，每往前一期权重乘以该值，取值 (0, 1]
            special_weight: 特别码在频率统计中的权重（正码固定为 1.0）

        权重含义:
            freq 越大越偏好近期频繁出现的号码；
            gap  越大越偏好长期未出的号码（回补）；
            trans 越大越偏好与最近一期号码“同环境”后继出现的号码。

        返回：
            dict，结构如下：
            {
              'numbers': [ {'number','score','freq','gap','trans','zodiac'} ... ],  推荐数字（pick个）
              'zodiacs': [ {'zodiac','score','freq','count','numbers'} ... ],       推荐生肖（pick个）
              'waves': [ {'wave','score','freq','gap','gap_periods','trans',
                          'count','avg_per_draw','numbers'} ... ],                 波色评分（3项，按分降序）
              'numbers_detail': [...],   全部候选数字评分明细（按分数降序）
              'zodiacs_detail': [...],   全部候选生肖评分明细（按分数降序）
              'stats': dict,             _compute_statistics 的统计检验结果
              'meta': {'total','used','window','latest_period','top_wave','weights'} 统计元信息
            }

        统计检验用途:
            stats 中的卡方均匀性检验用于判断号码频数是否显著偏离均匀分布
            （p<0.05 视为存在偏态）；95% 置信区间、Z-score、信息熵、和值趋势
            用于描述样本冷热与走势（KS 检验由其他 SciPy 算法方法使用，本方法不涉及）。

        异常：
            ValueError: 历史记录为空时抛出
        注意：
            纯内存计算；不修改 records；数据不足或 SciPy 缺失时
            _compute_statistics 给出安全默认值，不影响主流程。
        """
        # 1. 参数与数据准备
        if not records:
            raise ValueError('历史记录为空，无法进行大数据分析')

        if zodiac_binding is None:
            zodiac_binding = LotteryConfig.NUMBER_NAMES

        # 权重归一化，避免用户随意填写后量级失衡
        w = dict(cls.DEFAULT_WEIGHTS)
        if weights:
            for k in ('freq', 'gap', 'trans'):
                if k in weights:
                    w[k] = max(0.0, float(weights[k]))
        w_sum = sum(w.values())
        if w_sum <= 0:
            w = dict(cls.DEFAULT_WEIGHTS)
            w_sum = sum(w.values())
        w = {k: v / w_sum for k, v in w.items()}  # 归一化到总和为 1

        # 统一按 period 倒序（索引 0 为最新一期）
        ordered = sorted(records, key=lambda r: r.get('period', 0), reverse=True)
        # window≤0 时按 1 期处理，避免空切片导致后续 max() 抛错
        used = ordered[:max(1, int(window))]

        # 2. 频率特征（时间衰减加权）
        # freq[号码] = Σ (decay ** 期序号) * (正码权重或特别码权重)
        freq = {n: 0.0 for n in range(1, 50)}
        for idx, rec in enumerate(used):
            time_weight = decay ** idx  # 越新的期数权重越大
            for n in rec.get('numbers', []) or []:
                if 1 <= n <= 49:
                    freq[n] += time_weight
            special = rec.get('special', 0)
            if isinstance(special, int) and 1 <= special <= 49:
                freq[special] += time_weight * special_weight

        # 3. 遗漏特征（距上次出现期数）
        # gap[号码] = 从最新一期往回数，首次出现位置的索引；从未出现则记为总期数
        gap = {n: len(used) for n in range(1, 50)}
        for idx, rec in enumerate(used):
            draw = list(rec.get('numbers', []) or [])
            special = rec.get('special', 0)
            if isinstance(special, int) and special:
                draw.append(special)
            for n in draw:
                if 1 <= n <= 49 and gap[n] == len(used):  # 只记录首次（即最近一次）出现
                    gap[n] = idx

        # 4. 转移特征（最近一期号码的一阶马尔可夫强度）
        # 以最新一期出现的号码为条件：统计其后继各期号码的出现强度（同样时间衰减）
        latest_numbers = set(used[0].get('numbers', []) or [])
        special0 = used[0].get('special', 0)
        if isinstance(special0, int) and special0:
            latest_numbers.add(special0)
        trans = {n: 0.0 for n in range(1, 50)}
        for idx in range(1, len(used)):
            prev = used[idx - 1]
            prev_draw = set(prev.get('numbers', []) or [])
            sp = prev.get('special', 0)
            if isinstance(sp, int) and sp:
                prev_draw.add(sp)
            # 前一期与最新一期有交集时，才认为处于相似的号码环境
            if prev_draw & latest_numbers:
                time_weight = decay ** idx
                for n in (used[idx].get('numbers', []) or []):
                    if 1 <= n <= 49:
                        trans[n] += time_weight
                cur_sp = used[idx].get('special', 0)
                if isinstance(cur_sp, int) and 1 <= cur_sp <= 49:
                    trans[cur_sp] += time_weight * special_weight

        # 5. 波色特征（红波 / 绿波 / 蓝波）
        # 与号码同口径统计三项特征，衡量各波色整体的冷热程度
        wave_freq = {name: 0.0 for name, _ in cls.WAVE_GROUPS}
        wave_gap = {name: len(used) for name, _ in cls.WAVE_GROUPS}
        wave_trans = {name: 0.0 for name, _ in cls.WAVE_GROUPS}

        for idx, rec in enumerate(used):
            time_weight = decay ** idx
            draw = list(rec.get('numbers', []) or [])
            sp = rec.get('special', 0)
            if isinstance(sp, int) and sp:
                draw.append(sp)
            for name, members in cls.WAVE_GROUPS:
                member_set = set(members)
                hits = sum(1 for n in draw if n in member_set)
                if hits:
                    wave_freq[name] += time_weight * hits
                    # 只记录最近一次出现的期距离
                    if wave_gap[name] == len(used):
                        wave_gap[name] = idx

        for idx in range(1, len(used)):
            prev_draw = set(used[idx - 1].get('numbers', []) or [])
            prev_sp = used[idx - 1].get('special', 0)
            if isinstance(prev_sp, int) and prev_sp:
                prev_draw.add(prev_sp)
            if prev_draw & latest_numbers:
                time_weight = decay ** idx
                cur_draw = list(used[idx].get('numbers', []) or [])
                cur_sp = used[idx].get('special', 0)
                if isinstance(cur_sp, int) and cur_sp:
                    cur_draw.append(cur_sp)
                for name, members in cls.WAVE_GROUPS:
                    member_set = set(members)
                    wave_trans[name] += time_weight * sum(1 for n in cur_draw if n in member_set)

        # 6. 归一化与综合评分
        def _normalize(source):
            """把特征字典线性归一化到 0~1 区间

            功能：每个值除以该字典的最大值，使频率/遗漏/转移三项特征可加权相加。
            参数：
                source: {数值: 原始特征值} 字典
            数学含义:
                每个值除以该字典的最大值（max-normalization），使三项特征
                可加权相加；不是 min-max 归一化，归一化后的最小值不一定为 0。
            返回：
                dict: {数值: 归一化值}；全为 0 或空字典时统一返回 0.0。
            异常：
                无（非数值输入不在本函数职责范围内）。
            注意：
                无（返回新字典，不修改 source）。
            """
            top = max(source.values()) if source else 0.0
            if top <= 0:
                return {k: 0.0 for k in source}
            return {k: v / top for k, v in source.items()}

        freq_n = _normalize(freq)
        gap_n = _normalize(gap)
        trans_n = _normalize(trans)

        detail = []
        for n in range(1, 50):
            score = (w['freq'] * freq_n[n] + w['gap'] * gap_n[n] + w['trans'] * trans_n[n])
            detail.append({
                'number': n,
                'score': round(score, 6),
                'freq': round(freq_n[n], 4),
                'gap': round(gap_n[n], 4),
                'gap_periods': gap[n],
                'trans': round(trans_n[n], 4),
                'zodiac': zodiac_binding.get(n, ''),
            })
        detail.sort(key=lambda x: (-x['score'], x['number']))

        # 6. 生肖评分（成员号码综合分 + 生肖整体频率）
        zodiac_scores = {}
        zodiac_numbers = {}
        for item in detail:
            z = item['zodiac']
            if not z:
                continue
            zodiac_scores.setdefault(z, []).append(item['score'])
            zodiac_numbers.setdefault(z, []).append(item['number'])

        # 生肖整体出现频率（衰减加权）：每期把出现的号码映射为生肖后累加
        zodiac_freq = {}
        for idx, rec in enumerate(used):
            time_weight = decay ** idx
            draw = list(rec.get('numbers', []) or [])
            sp = rec.get('special', 0)
            if isinstance(sp, int) and sp:
                draw.append(sp)
            for n in draw:
                z = zodiac_binding.get(n)
                if z:
                    zodiac_freq[z] = zodiac_freq.get(z, 0.0) + time_weight
        zodiac_freq_n = _normalize(zodiac_freq)

        zodiac_detail = []
        for z, scores in zodiac_scores.items():
            member_avg = sum(scores) / len(scores)  # 成员号码综合分均值
            # 0.7/0.3 为经验权重：成员号码质量为主，生肖整体热度为辅
            z_score = 0.7 * member_avg + 0.3 * zodiac_freq_n.get(z, 0.0)
            zodiac_detail.append({
                'zodiac': z,
                'score': round(z_score, 6),
                'freq': round(zodiac_freq_n.get(z, 0.0), 4),
                'count': len(scores),
                'numbers': sorted(zodiac_numbers[z]),
            })
        zodiac_detail.sort(key=lambda x: (-x['score'], x['zodiac']))

        # 7. 波色评分与排序
        wave_freq_n = _normalize(wave_freq)
        wave_gap_n = _normalize(wave_gap)
        wave_trans_n = _normalize(wave_trans)
        wave_detail = []
        for name, members in cls.WAVE_GROUPS:
            score = (w['freq'] * wave_freq_n.get(name, 0.0)
                     + w['gap'] * wave_gap_n.get(name, 0.0)
                     + w['trans'] * wave_trans_n.get(name, 0.0))
            wave_detail.append({
                'wave': name,
                'score': round(score, 6),
                'freq': round(wave_freq_n.get(name, 0.0), 4),
                'gap': round(wave_gap_n.get(name, 0.0), 4),
                'gap_periods': wave_gap[name],
                'trans': round(wave_trans_n.get(name, 0.0), 4),
                'count': len(members),
                'avg_per_draw': round(wave_freq[name] / max(1, len(used)), 3),
                'numbers': sorted(members),
            })
        wave_detail.sort(key=lambda x: (-x['score'], x['wave']))

        # 8. 去重选取
        # 数字本身按号码唯一评分，天然不重复；生肖按名称唯一，取前 pick 个不同生肖
        # pick≤0 时也至少返回 1 个，保持与 _compute_statistics 的 picks_gap 一致
        picked_numbers = detail[:max(1, int(pick))]
        picked_zodiacs = zodiac_detail[:max(1, int(pick))]

        # 9. 统计检验与趋势（numpy + scipy 计算能力）
        stats = cls._compute_statistics(used, detail)

        return {
            'numbers': picked_numbers,
            'zodiacs': picked_zodiacs,
            'waves': wave_detail,
            'numbers_detail': detail,
            'zodiacs_detail': zodiac_detail,
            'stats': stats,
            'meta': {
                'total': len(records),
                'used': len(used),
                'window': int(window),
                'latest_period': used[0].get('period', ''),
                'top_wave': wave_detail[0]['wave'] if wave_detail else '',
                'weights': {k: round(v, 4) for k, v in w.items()},
            },
        }

    @classmethod
    def _compute_statistics(cls, used, detail):
        """用 numpy + scipy 计算统计检验与趋势特征

        功能：基于 used 记录计算和值序列及其趋势、一阶自相关、号码信息熵、
            卡方均匀性检验、95% 置信区间、Z-score 热冷异常与推荐号码遗漏显著性，
            任何子项失败时保留安全默认值。
        计算内容：
            1. 和值序列：均值/标准差/最新值、MA5、EMA5、线性斜率与趋势判断
            2. 一阶自相关（和值序列相邻期相关性）
            3. 号码信息熵（Shannon，bits 与归一化值）
            4. 卡方均匀性检验（实际频数 vs 均匀期望）
            5. 单号出现次数 95% 置信区间（二项分布；无 scipy 时用正态近似）
            6. Z-score 热度异常（热号 / 冷号）
            7. 推荐号码的遗漏显著性（连续未出概率）

        数学含义:
            - 和值 = 6 个正码之和 + 特别码；chrono 为“旧 → 新”，趋势斜率由
              一阶多项式拟合得到，阈值 max(0.2, std/10) 用于抑制噪声；
            - EMA(5) 平滑系数 alpha=2/(5+1)=1/3，等价 pandas ewm(span=5, adjust=False)；
            - p0=7/49 为单个号码每期出现概率（6 个正码 + 1 个特别码 = 7 个号码）；
            - 卡方自由度 48（49 类减 1 个约束）；Z-score 以 n_draw×p0 为期望、
              标准差 sqrt(n×p0×(1-p0))，|Z|≥1.5 记为热号/冷号；
            - 遗漏显著性 (1-p0)**gap 为连续 gap 期不出现的概率，越小越接近回补。

        参数：
            used: 参与分析的历史记录（按 period 倒序）
            detail: 全部号码评分明细（含 gap_periods）
        返回：
            dict: 统计结果，键为
                draws / libs / sum / autocorr / entropy / chi2 / ci95 / zscore / picks_gap；
                任何子项失败时给出安全默认值，不影响主流程。
        异常：
            整体异常被捕获并 print 警告，不向外抛出。
        注意：
            - 可能触发 SciPy 懒加载（_get_scipy_stats）；
            - 计算失败时向标准输出打印“统计检验计算警告”；
            - 不修改 used/detail。
        """
        n_draw = len(used)
        p0 = 7.0 / 49.0  # 单个号码每期出现概率
        stats = {
            'draws': n_draw,
            'libs': {'numpy': getattr(np, '__version__', '?'), 'scipy': _get_scipy_stats() is not None},
            'sum': {'mean': 0.0, 'std': 0.0, 'latest': 0.0, 'ma5': 0.0,
                    'ema5': 0.0, 'slope': 0.0, 'trend': '平稳'},
            'autocorr': 0.0,
            'entropy': {'bits': 0.0, 'max_bits': round(math.log2(49), 3), 'normalized': 0.0},
            'chi2': {'statistic': 0.0, 'pvalue': 1.0, 'dof': 48, 'conclusion': '样本不足'},
            'ci95': {'mean': 0.0, 'low': 0, 'high': 0},
            'zscore': {'expected': 0.0, 'hot': [], 'cold': []},
            'picks_gap': [],
        }
        try:
            # 1) 和值序列（按时间正序：旧 → 新）
            chrono = list(reversed(used))
            sums = [sum(r.get('numbers', []) or []) + (r.get('special') or 0) for r in chrono]
            arr = np.asarray(sums, dtype=float)
            if arr.size:
                std = float(arr.std(ddof=1)) if arr.size > 1 else 0.0
                slope = float(np.polyfit(np.arange(arr.size), arr, 1)[0]) if arr.size >= 2 else 0.0
                threshold = max(0.2, std / 10.0)
                trend = '上行' if slope > threshold else ('下行' if slope < -threshold else '平稳')
                ma5 = float(np.mean(arr[-5:])) if arr.size >= 5 else float(arr.mean())
                # EMA(5)：等价于 pandas ewm(span=5, adjust=False)，此处不依赖 pandas
                alpha = 2.0 / (5 + 1)
                ema = float(arr[0])
                for v in arr[1:]:
                    ema = alpha * float(v) + (1 - alpha) * ema
                ema5 = ema
                stats['sum'] = {
                    'mean': round(float(arr.mean()), 2),
                    'std': round(std, 2),
                    'latest': round(float(arr[-1]), 2),
                    'ma5': round(ma5, 2),
                    'ema5': round(ema5, 2),
                    'slope': round(slope, 3),
                    'trend': trend,
                }
                # 2) 一阶自相关
                if arr.size >= 3 and float(arr.std()) > 0:
                    stats['autocorr'] = round(float(np.corrcoef(arr[:-1], arr[1:])[0, 1]), 3)

            # 3) 号码频数与信息熵
            counts = np.zeros(49)
            for rec in used:
                for n in (rec.get('numbers', []) or []):
                    if 1 <= n <= 49:
                        counts[n - 1] += 1
                sp = rec.get('special', 0)
                if isinstance(sp, int) and 1 <= sp <= 49:
                    counts[sp - 1] += 1
            total = float(counts.sum())
            if total > 0:
                probs = counts / total
                nz = probs[probs > 0]
                entropy = float(-(nz * np.log2(nz)).sum())
                max_bits = math.log2(49)
                stats['entropy'] = {
                    'bits': round(entropy, 3),
                    'max_bits': round(max_bits, 3),
                    'normalized': round(entropy / max_bits, 3) if max_bits else 0.0,
                }

            # 4) 卡方均匀性检验 + 5) 二项分布置信区间
            scipy_st = _get_scipy_stats()
            if scipy_st is not None and total > 0:
                expected = np.full(49, total / 49.0)
                chi_res = scipy_st.chisquare(counts, expected)
                p_value = float(chi_res.pvalue)
                stats['chi2'] = {
                    'statistic': round(float(chi_res.statistic), 3),
                    'pvalue': round(p_value, 4),
                    'dof': 48,
                    'conclusion': ('接近均匀分布（无显著偏差）' if p_value >= 0.05
                                   else '分布显著偏离均匀（存在偏态）'),
                }
                low = int(scipy_st.binom.ppf(0.025, n_draw, p0))
                high = int(scipy_st.binom.ppf(0.975, n_draw, p0))
                stats['ci95'] = {'mean': round(n_draw * p0, 2), 'low': low, 'high': high}
            elif total > 0:
                mu = n_draw * p0
                sd = math.sqrt(n_draw * p0 * (1 - p0))
                stats['ci95'] = {'mean': round(mu, 2),
                                 'low': max(0, int(mu - 1.96 * sd)),
                                 'high': int(mu + 1.96 * sd)}

            # 6) Z-score 热度异常
            if total > 0:
                mu = n_draw * p0
                sd = math.sqrt(n_draw * p0 * (1 - p0)) or 1.0
                z = (counts - mu) / sd
                hot = sorted(((i + 1, float(z[i])) for i in range(49) if z[i] >= 1.5),
                             key=lambda x: -x[1])[:3]
                cold = sorted(((i + 1, float(z[i])) for i in range(49) if z[i] <= -1.5),
                              key=lambda x: x[1])[:3]
                stats['zscore'] = {
                    'expected': round(mu, 2),
                    'hot': [(n, round(v, 2)) for n, v in hot],
                    'cold': [(n, round(v, 2)) for n, v in cold],
                }

            # 7) 推荐号码的遗漏显著性
            stats['picks_gap'] = [
                {'number': d['number'], 'gap': d['gap_periods'],
                 'miss_prob': round((1 - p0) ** d['gap_periods'], 3)}
                for d in detail[:7]
            ]
        except Exception as e:
            print('统计检验计算警告: ' + str(e))
        return stats

    @classmethod
    def format_stats_text(cls, stats):
        """把统计检验与趋势结果格式化为纯文本（供复制/导出/界面展示）

        功能：读取 _compute_statistics 的字典结果，拼成固定 9 行的多行文本，
            缺失字段用 '-'、0 或“无”兜底。
        输出结构（按行顺序，共 9 行）:
            1. 标题与库状态：【统计检验与趋势】（numpy 版本 / scipy 可用性）
            2. 样本期数、和值均值/标准差/最新值
            3. 和值趋势（斜率）、MA5、EMA5
            4. 一阶自相关（附 |r|<0.2 弱相关提示）
            5. 号码信息熵（bits / 归一化百分比 / 最大 bits）
            6. 卡方均匀性检验（χ²、p、结论）
            7. 单号出现次数 95% 置信区间（上下界与期望次数）
            8. Z-score 热度异常（热号/冷号列表，无则“无”）
            9. 推荐数字的遗漏显著性（遗漏期数与未出概率）

        参数：
            stats: _compute_statistics() 的返回值
        返回：
            str: 多行文本，以 '\\n' 连接；stats 为空时返回空字符串。
        异常：
            不抛异常（缺失字段用 '-'、0 或“无”兜底）。
        注意：
            无（只读 stats，不修改）。
        """
        if not stats:
            return ''
        s = stats.get('sum', {})
        ent = stats.get('entropy', {})
        chi = stats.get('chi2', {})
        ci = stats.get('ci95', {})
        zs = stats.get('zscore', {})
        hot = zs.get('hot', [])
        cold = zs.get('cold', [])
        hot_text = '、'.join('%02d(Z=%.2f)' % (n, z) for n, z in hot) if hot else '无'
        cold_text = '、'.join('%02d(Z=%.2f)' % (n, z) for n, z in cold) if cold else '无'
        picks = stats.get('picks_gap', [])
        picks_text = '  '.join('%02d(遗漏%d期/未出%.2f)' % (p['number'], p['gap'], p['miss_prob'])
                               for p in picks) if picks else '无'
        libs = stats.get('libs', {})
        lines = [
            '【统计检验与趋势】（numpy %s / scipy %s）' % (
                libs.get('numpy', '?'), '可用' if libs.get('scipy') else '不可用'),
            '  样本期数: %s   和值均值 %.2f / 标准差 %.2f / 最新 %.2f' % (
                stats.get('draws', 0), s.get('mean', 0), s.get('std', 0), s.get('latest', 0)),
            '  和值趋势: %s（斜率 %.3f）  MA5=%.2f  EMA5=%.2f' % (
                s.get('trend', '-'), s.get('slope', 0), s.get('ma5', 0), s.get('ema5', 0)),
            '  一阶自相关: %.3f（|r|<0.2 视为弱相关）' % stats.get('autocorr', 0),
            '  号码信息熵: %.3f bits（归一化 %.1f%%，最大 %.3f bits）' % (
                ent.get('bits', 0), ent.get('normalized', 0) * 100, ent.get('max_bits', 0)),
            '  卡方均匀性检验: χ²=%.3f, p=%.4f → %s' % (
                chi.get('statistic', 0), chi.get('pvalue', 1), chi.get('conclusion', '-')),
            '  单号出现次数 95%% 置信区间: [%s, %s]（期望 %.2f 次）' % (
                ci.get('low', 0), ci.get('high', 0), ci.get('mean', 0)),
            '  热度异常(Z-score): 热号 %s / 冷号 %s' % (hot_text, cold_text),
            '  遗漏显著性（推荐数字，概率越低越接近回补）: %s' % picks_text,
        ]
        return '\n'.join(lines)

    @classmethod
    def format_result_text(cls, result):
        """把分析结果格式化为可直接复制/导出的纯文本

        功能：读取 analyze 返回的 numbers/zodiacs/waves/stats/meta，拼成含
            分区标题、推荐明细、波色分析与统计检验的完整文本报告。
        输出结构（段落顺序）:
            1. 60 个 '=' 分隔线 + “大数据分析报告（历史记录挖掘）”标题
            2. 总记录数 / 参与分析期数 / 最新期号；数据源（默认“内存”）
            3. 特征权重：频率 / 遗漏 / 转移
            4. 【推荐 N 生肖】逐行：序号、生肖、综合分、出现强度、成员号码
            5. 【推荐 N 数字】逐行：序号、号码、生肖、综合分、频率、遗漏期数、转移
            6. 【波色分析】逐行：波色、综合分、频率、遗漏、转移、成员数、场均个数
            7. 统计检验文本（由 format_stats_text 生成，可能为空）
            8. 免责说明与结尾分隔线

        参数：
            result: analyze() 的返回值
        返回：
            str: 多行纯文本报告，以 '\\n' 连接。
        异常：
            不抛异常；但 result 中缺少 numbers/zodiacs/waves 的必需键时会
            因下标访问抛 KeyError（正常由 analyze 保证）。
        注意：
            无（只读 result）。
        TODO(待确认): meta['source'] 在 analyze() 的返回值中并未产出，
            此处的“数据源”实际总是走默认值“内存”。
        """
        meta = result.get('meta', {})
        lines = [
            '=' * 60,
            '大数据分析报告（历史记录挖掘）',
            '=' * 60,
            '总记录数: %s   参与分析期数: %s   最新期号: %s' % (
                meta.get('total', ''), meta.get('used', ''), meta.get('latest_period', '')),
            '数据源: %s' % meta.get('source', '内存'),
            '特征权重: 频率 %s / 遗漏 %s / 转移 %s' % (
                meta.get('weights', {}).get('freq', ''),
                meta.get('weights', {}).get('gap', ''),
                meta.get('weights', {}).get('trans', '')),
            '',
            '【推荐 %d 生肖】（互不重复）' % len(result.get('zodiacs', [])),
        ]
        for i, item in enumerate(result.get('zodiacs', []), 1):
            lines.append('  %d. %s  综合分=%.4f  出现强度=%.4f  成员号码=%s' % (
                i, item['zodiac'], item['score'], item['freq'],
                ','.join('%02d' % n for n in item['numbers'])))
        lines.append('')
        lines.append('【推荐 %d 数字】（互不重复）' % len(result.get('numbers', [])))
        for i, item in enumerate(result.get('numbers', []), 1):
            lines.append('  %d. %02d  生肖=%s  综合分=%.4f  频率=%.4f  遗漏=%d期  转移=%.4f' % (
                i, item['number'], item['zodiac'], item['score'],
                item['freq'], item['gap_periods'], item['trans']))
        lines.append('')
        lines.append('【波色分析】（红波 / 绿波 / 蓝波，按综合分降序）')
        for i, item in enumerate(result.get('waves', []), 1):
            lines.append('  %d. %s  综合分=%.4f  频率=%.4f  遗漏=%d期  转移=%.4f  成员=%d个  场均%.2f个' % (
                i, item['wave'], item['score'], item['freq'], item['gap_periods'],
                item['trans'], item['count'], item['avg_per_draw']))
        lines.append('')
        stats_text = cls.format_stats_text(result.get('stats'))
        if stats_text:
            lines.extend(stats_text.splitlines())
            lines.append('')
        lines.append('说明: 本结果基于历史统计特征计算，仅供数据分析参考，不构成投注建议。')
        lines.append('=' * 60)
        return '\n'.join(lines)


# 七策略号码预测（[3] 预测与抽取 →「号码预测」子选项卡专用计算层）


class NumberStrategyPredictor:
    """七策略号码预测器：热门 / 冷门 / 综合 / 均衡 / 走势 / 马尔科夫 / 机器学习

    功能：一次性提取 1~49 的频次/遗漏/近期窗口/走势斜率/马尔科夫转移/特码频率
        特征，按七套权重公式打分，生成 6 个正码 + 1 个特别码及计算原理/分析说明。
    参数：无（类构造参数见 __init__）。
    返回：无（类本身不返回值，预测结果由 predict_all 返回 dict）。
    职责:
        从历史开奖记录中一次性提取 1~49 每个号码的频率、遗漏、近期窗口、
        走势斜率、马尔科夫转移强度与特码频率，再按七套可解释的权重公式
        分别打分、取前 6 个正码与 1 个特别码，并生成「计算原理 + 分析说明」
        文本。界面层只负责调用本类与渲染，不参与任何评分计算。

    数据方向:
        本项目主窗口用 insert(0, record) 维护 historical_data，索引 0 是
        最新一期；但本类不依赖调用方顺序，构造时统一按 period 降序重排。
        因此所有「最近 N 期」都从索引 0 向后取，避免照抄 docs/号码预测.md
        的升序假设导致取到最旧数据。

    关键属性:
        data (list[dict])      按期号降序排列的完整历史；
        used (list[dict])      实际参与计算的窗口（默认最新 100 期）；
        draws (int)            参与期数；
        freq / recent10 / ...  归一化前的原始特征字典（键为 1..49）；
        score_maps (dict)      六个非 ML 策略的原始得分字典；
        component_scores       综合策略使用的三个基础策略归一化分。

    约束:
        - 六个统计策略只依赖 numpy 与标准库，可无头运行；
        - 「机器学习」策略在调用时才懒加载 lib.ml_model，避免启动即训练；
        - 数据不足（少于 MIN_DRAWS 期）时返回明确错误，不静默出号；
        - 生肖只从调用方传入的 binding 读取（界面传入 [10] 页配置），
          未传入时才回退 LotteryConfig.NUMBER_NAMES。

    注意：
        统计特征与打分是纯内存只读计算，可在后台线程调用；
        ML 策略会同步训练 sklearn 模型并可能写模型缓存，耗时较长，
        UI 应显示等待光标/进度，并避免同一实例并发调用。
    """

    # 七个策略的固定展示顺序（与界面列表顺序一致，避免字典顺序漂移）
    STRATEGIES = (
        ('hot', '热门'),
        ('cold', '冷门'),
        ('hybrid', '综合'),
        ('balanced', '均衡'),
        ('trend', '走势'),
        ('markov', '马尔科夫'),
        ('ml', '机器学习'),
    )

    # 数据不足阈值：20 期以下连 10 期滑动窗口都组不成稳定样本，
    # 30 期可保证每个号码平均出现约 4 次，频率/遗漏/转移才有统计意义
    MIN_DRAWS = 30
    DEFAULT_WINDOW = 100
    SHORT_WINDOW = 10       # 近期窗口：热门、走势、均衡共用
    MICRO_WINDOW = 5        # 微窗口：走势策略捕捉最近 5 期加速
    PREV_WINDOW = 10        # 前 10 期：与最近 10 期做差分
    MEMORY_WINDOW = 20      # 斜率拟合窗口：20 期 0/1 序列
    DECAY = 0.995           # 时间衰减：每往前一期权重乘以 0.995
    SPECIAL_BALL_WEIGHT = 0.8  # 特别码在频率统计中的权重（正码固定 1.0）

    # 每个策略的「计算原理」文本。公式中的权重与下方 _build_score_maps
    # 的真实代码一一对应，禁止只写文案不改权重，避免说明与结果不一致。
    STRATEGY_FORMULAS = {
        'hot': (
            'score_hot = 0.65·F_all + 0.35·F_10；'
            'F_all=分析窗口内出现次数（正码 1.0、特别码 0.8），'
            'F_10=最近 10 期同口径次数；两项各自 min-max 归一化到 [0,1] 后加权，'
            '分数越高越优先。'
        ),
        'cold': (
            'score_cold = 0.55·Gap + 0.30·Overdue + 0.15·(1-F_all)；'
            'Gap=当前遗漏期数（最新一期未出为 0），Overdue=Gap/平均出现间隔，'
            'F_all=窗口内频次；三项各自 min-max 归一化，'
            '分数越高代表越久未出、越接近回补。'
        ),
        'hybrid': (
            'score_hybrid = 0.40·Hot* + 0.25·Cold* + 0.35·Trend*；'
            'Hot*/Cold*/Trend* 是热门、冷门、走势三种基础得分再做 min-max '
            '归一化后的结果，三方向同时加权，避免单一口径。'
        ),
        'balanced': (
            'score_balanced = 0.30·M_freq + 0.25·M_gap + 0.25·F_10 + 0.20·Trans；'
            'M_freq=1-min(1,|Z_freq|/2)、M_gap=1-min(1,|Z_gap|/2) 表示“越接近均值越好”，'
            'F_10/Trans 为归一化近期频率与马尔科夫转移强度；'
            '取号时再对奇偶 3:3、大小 3:3、尾数/波色/生肖分散做贪心惩罚，'
            '因此它与“综合”的高分优先口径不同。'
        ),
        'trend': (
            'score_trend = 0.45·F_5 + 0.30·Slope_20 + 0.25·max(0,F_10-F_prev10)；'
            'F_5/F_10/F_prev10=最近 5 期、最近 10 期、前 10 期出现次数，'
            'Slope_20=最近 20 期 0/1 出现序列的一次多项式斜率；'
            '三项 min-max 归一化，分数越高代表近期走强。'
        ),
        'markov': (
            'score_markov = 0.70·Trans + 0.20·F_10 + 0.10·(1-Gap)；'
            'Trans 以最新一期 7 个号码为条件，统计历史中“前一期状态与最新期有交集”'
            '时其下一期的后继号码强度（时间衰减 0.995^期序，交集个数最多计 3 倍）；'
            '三项归一化后加权。'
        ),
        'ml': (
            '调用 lib/ml_model.MLPredictionModel：用最近 10 期 × 58 维 = 580 维特征，'
            '为 49 个号码分别训练随机森林/梯度提升/逻辑回归/MLP 二分类器，'
            '取四类模型 P(该号出现) 的算术平均作为得分；按概率降序取前 6，'
            '不使用 docs/号码预测.md 的硬编码权重。'
        ),
    }

    # 特别码口径：沿用现有 _predict_special_number 的“排除正码 + 特码历史频率”
    # 思路，但改为确定性取最高分，保证七行结果在一次生成内稳定、可截图复现
    SPECIAL_FORMULA = (
        '特别码：排除 6 个正码后，先取本策略得分最高的 10 个候选形成候选池，'
        '再在池内选择特码历史频率最高者（同频率按本策略得分、最后按号码升序），'
        '确定性选取、不随机，保证 7 个号码互不重复。'
    )

    def __init__(self, historical_data, zodiac_binding=None, window=DEFAULT_WINDOW,
                 ml_base_dir=None, ml_use_cache=True, progress_callback=None):
        """初始化并计算全部统计特征

        功能：校验历史数据非空，按 period 降序重排并截取最新 window 期，
            初始化 1..49 的特征字典，随后调用 _compute_features 完成
            频次/遗漏/近期窗口/走势/马尔科夫转移等特征计算。
        参数：
            historical_data (list[dict]): 历史记录，元素含 period/date/numbers/special；
                允许任意顺序，内部会按 period 降序重排。
            zodiac_binding (dict|None): {号码: 生肖} 映射；界面必须传 [10] 页绑定，
                为空时才回退 LotteryConfig.NUMBER_NAMES。
            window (int): 参与计算的最新期数，默认 100；小于 1 时按 1 处理。
            ml_base_dir (str|None): ML 模型缓存目录；None 时用 ml_model 默认目录。
            ml_use_cache (bool): 机器学习是否优先使用 ml_models.pkl 缓存。
            progress_callback (callable|None): 可选进度回调 callback(percent, msg)，
                仅 ML 训练阶段触发。
        返回：
            无。
        异常：
            ValueError: historical_data 为空时抛出。
        注意：
            只做内存统计；不读文件、不训练模型（ML 延迟到 predict_all）。
        """
        if not historical_data:
            raise ValueError('历史开奖数据为空，无法进行号码预测')

        self.zodiac_binding = dict(zodiac_binding) if zodiac_binding else dict(LotteryConfig.NUMBER_NAMES)
        # 显式按期号降序重排：即使调用方传入升序，后续 idx=0 也一定是“最新”
        self.data = self._order_records(historical_data)
        try:
            self.window = max(1, int(window))
        except (TypeError, ValueError):
            self.window = self.DEFAULT_WINDOW
        self.used = self.data[:self.window]
        self.draws = len(self.used)
        self.latest_period = self.used[0].get('period', '') if self.used else ''

        self.ml_base_dir = ml_base_dir
        self.ml_use_cache = bool(ml_use_cache)
        self.progress_callback = progress_callback

        # 所有特征都以 1..49 为键预先建好，保证缺失号码取 0 而不是 KeyError
        self.freq = {n: 0.0 for n in range(1, 50)}          # 时间衰减加权频次
        self.hit_count = {n: 0 for n in range(1, 50)}        # 出现次数（整数）
        self.recent10 = {n: 0.0 for n in range(1, 50)}
        self.recent5 = {n: 0.0 for n in range(1, 50)}
        self.recent20 = {n: 0.0 for n in range(1, 50)}
        self.prev10 = {n: 0.0 for n in range(1, 50)}
        self.gap = {n: self.draws for n in range(1, 50)}     # 当前遗漏期数
        self.special_freq = {n: 0.0 for n in range(1, 50)}
        self.trans_raw = {n: 0.0 for n in range(1, 50)}
        self.momentum = {n: 0.0 for n in range(1, 50)}
        self.avg_interval = {n: float(self.draws) for n in range(1, 50)}
        self.overdue = {n: 0.0 for n in range(1, 50)}
        self.score_maps = {}
        self.component_scores = {}

        self._compute_features()

    # 数据准备与特征提取
    @staticmethod
    def _to_int(value, default=0):
        """把 period / 号码等可能为字符串或 numpy 标量的值安全转成 int

        功能：尝试 int(value)，失败时返回 default，避免脏数据中断特征计算。
        参数：
            value: 任意标量；无法转换时返回 default。
            default (int): 兜底值。
        返回：
            int: 转换后的整数。
        注意：
            无副作用。
        """
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    @classmethod
    def _period_key(cls, record):
        """取期号排序键；缺失期号记 0，稳定排序会保留调用方原有相对顺序

        功能：读取 record 的 period 并用 _to_int 转成 int，作为降序排序键。
        参数：
            record (dict): 单期历史记录。
        返回：
            int: 期号整数；缺失或无法转换时为 0。
        注意：
            无副作用。
        """
        return cls._to_int(record.get('period', 0), 0)

    @classmethod
    def _order_records(cls, records):
        """按期号降序返回新列表（不修改入参）

        功能：用 sorted 按 _period_key 降序复制 records，保证索引 0 为最新一期。
        参数：
            records (list[dict]): 任意顺序的历史记录。
        返回：
            list[dict]: 按期号降序的新列表。
        注意：
            不修改入参 records。
        为什么显式排序:
            项目 historical_data 是 insert(0) 维护的倒序，但文档示例是升序；
            若照抄文档的 idx<30 当“最近 30 期”，实际会取到最旧的 30 期。
            这里统一重排后，idx=0 始终是最新一期。
        """
        return sorted(list(records), key=cls._period_key, reverse=True)

    @classmethod
    def _draw_numbers(cls, record):
        """返回一期的全部有效号码（正码 + 特别码，1..49）

        功能：遍历 record 的 numbers 与 special，过滤非 1..49 或重复的值。
        参数：
            record (dict): 单期记录。
        返回：
            list[int]: 去重后的号码列表；非法值被丢弃。
        注意：
            无副作用。
        """
        result = []
        for n in record.get('numbers', []) or []:
            value = cls._to_int(n, 0)
            if 1 <= value <= 49 and value not in result:
                result.append(value)
        special = cls._to_int(record.get('special', 0), 0)
        if 1 <= special <= 49 and special not in result:
            result.append(special)
        return result

    def _accumulate(self, number, time_weight, ball_weight, idx):
        """累加单个号码在某一期的窗口特征

        功能：把 time_weight×ball_weight 累加到 freq，并按 idx 落点更新
            recent20/recent10/recent5/prev10、hit_count 与首次出现遗漏 gap。
        参数：
            number (int): 号码 1..49。
            time_weight (float): 时间衰减权重 DECAY**idx。
            ball_weight (float): 正码 1.0 / 特别码 0.8。
            idx (int): 距最新一期的期序（0 为最新）。
        返回：
            无。
        注意：
            只写本实例的 freq/recent*/gap 等字典。
        """
        value = time_weight * ball_weight
        self.freq[number] += value
        self.hit_count[number] += 1
        if idx < self.MEMORY_WINDOW:
            self.recent20[number] += ball_weight
        if idx < self.SHORT_WINDOW:
            self.recent10[number] += ball_weight
        if idx < self.MICRO_WINDOW:
            self.recent5[number] += ball_weight
        if self.PREV_WINDOW <= idx < self.PREV_WINDOW + self.SHORT_WINDOW:
            self.prev10[number] += ball_weight
        # gap 只记录“第一次（即最近一次）出现”的期序；循环从新到旧，
        # 因此第一次满足 gap==draws 时写入的就是当前遗漏值
        if self.gap[number] == self.draws:
            self.gap[number] = idx

    def _compute_features(self):
        """计算全部 49 个号码的统计特征、走势斜率与马尔科夫转移强度

        功能：遍历 used 逐期累加号码权重特征，再计算平均间隔/超期比、
            最近 20 期 0/1 序列的 numpy 拟合斜率，以及以最新一期为条件状态的
            马尔科夫后继转移强度。
        参数：无。
        计算口径:
            1. 权重频次：正码 1.0、特别码 0.8，按 DECAY**idx 时间衰减；
            2. 近期窗口：最近 5 / 10 / 20 期与前 10 期；
            3. 遗漏 gap：从最新一期往回数，首次出现的期序；
               平均间隔 = 参与期数 / 出现次数，超期比 = gap / 平均间隔；
            4. 走势斜率：最近 20 期按时间正序（旧→新）的 0/1 序列，
               用 numpy 一次多项式拟合，斜率正表示近期走强；
            5. 马尔科夫转移：最新一期 7 个号码作为条件状态，遍历历史中
               每个“前一期与最新状态有交集”的位置，把下一期号码按
               时间衰减加权累加；交集个数最多计 3 倍，避免 7 个号码全中
               时单期权重过大。
        返回：
            无。
        注意：
            只写实例特征字典。
        """
        for idx, record in enumerate(self.used):
            time_weight = self.DECAY ** idx
            normal_numbers = []
            for n in record.get('numbers', []) or []:
                value = self._to_int(n, 0)
                if 1 <= value <= 49 and value not in normal_numbers:
                    normal_numbers.append(value)
            for number in normal_numbers:
                self._accumulate(number, time_weight, 1.0, idx)

            special = self._to_int(record.get('special', 0), 0)
            if 1 <= special <= 49:
                # 特别码进入频次/遗漏窗口，但权重 0.8 低于正码
                self._accumulate(special, time_weight, self.SPECIAL_BALL_WEIGHT, idx)
                self.special_freq[special] += 1.0

        # 平均间隔与超期比：从未出现的号码按整个窗口计遗漏
        for number in range(1, 50):
            hits = max(1, self.hit_count[number])
            self.avg_interval[number] = float(self.draws) / hits
            self.overdue[number] = self.gap[number] / max(1.0, self.avg_interval[number])

        # 走势斜率：最近 20 期转成时间正序，对每个号码拟合 0/1 序列
        chrono = list(reversed(self.used[:min(self.draws, self.MEMORY_WINDOW)]))
        chrono_sets = [set(self._draw_numbers(record)) for record in chrono]
        if len(chrono_sets) >= 3:
            x_axis = np.arange(len(chrono_sets), dtype=float)
            for number in range(1, 50):
                y_axis = np.asarray([1.0 if number in draw_set else 0.0 for draw_set in chrono_sets])
                # 全 0 序列方差为 0，polyfit 会告警；直接记 0 斜率
                if float(y_axis.std()) <= 0:
                    self.momentum[number] = 0.0
                else:
                    self.momentum[number] = float(np.polyfit(x_axis, y_axis, 1)[0])

        # 马尔科夫转移：latest_set 是条件状态（最新一期），
        # 历史中 used[i] 是较旧的一期，其“下一期”是 used[i-1]（更新的一期）
        self.latest_set = set(self._draw_numbers(self.used[0])) if self.used else set()
        for idx in range(1, self.draws):
            state_draw = set(self._draw_numbers(self.used[idx]))
            overlap = len(state_draw & self.latest_set)
            if overlap <= 0:
                continue
            next_draw = set(self._draw_numbers(self.used[idx - 1]))
            weight = (self.DECAY ** idx) * min(overlap, 3)
            for number in next_draw:
                self.trans_raw[number] += weight

    # 归一化与打分
    @staticmethod
    def _minmax(source):
        """把特征字典线性归一化到 [0,1]

        功能：计算字典的最小值/最大值并做 min-max 缩放，使不同量级特征可加权。
        参数：
            source (dict): {号码: 原始值}。
        返回：
            dict: 归一化结果；最大值等于最小值时统一返回 0.5（中性），
                避免除零把某一号码误判成唯一最高分。
        注意：
            返回新字典，不修改 source。
        """
        if not source:
            return {}
        values = list(source.values())
        low = min(values)
        high = max(values)
        if high - low < 1e-12:
            return {key: 0.5 for key in source}
        return {key: (value - low) / (high - low) for key, value in source.items()}

    @staticmethod
    def _zscore(source):
        """把特征字典转成 Z-score（均值 0、标准差 1）

        功能：用 numpy 计算字典的均值与标准差，把每个值标准化为 (值-均值)/标准差。
        参数：
            source (dict): {号码: 原始值}。
        返回：
            dict: Z-score；标准差为 0 时全部返回 0（表示没有偏离）。
        注意：
            返回新字典，不修改 source。
        """
        if not source:
            return {}
        values = np.asarray(list(source.values()), dtype=float)
        mean = float(values.mean())
        std = float(values.std())
        if std <= 1e-12:
            return {key: 0.0 for key in source}
        return {key: (float(value) - mean) / std for key, value in source.items()}

    def _build_score_maps(self):
        """按七套公式生成六个统计策略的原始得分字典（ML 在调用时单独计算）

        功能：先 min-max 归一化 freq/recent/gap/overdue/trans/momentum 等特征，
            再按 0.65/0.35 等固定权重生成 hot/cold/trend/hybrid/balanced/markov
            六套得分，并保存综合策略所需的三个基础归一化分。
        参数：无。
        归一化策略:
            每个原始特征先 min-max 到 [0,1]，再代入公式；这样 0.65/0.35
            这类权重才真正表示“占比”，不会因某项量级大而吞掉另一项。
            综合策略对三个基础得分再做一次 min-max，保证三者同尺度；
            均衡策略对频率/遗漏取 Z-score 后转成“接近均值得高分”。
        返回：
            无。
        注意：
            写 self.score_maps 与 self.component_scores。
        """
        freq_n = self._minmax(self.freq)
        recent10_n = self._minmax(self.recent10)
        recent5_n = self._minmax(self.recent5)
        gap_n = self._minmax(self.gap)
        overdue_n = self._minmax(self.overdue)
        trans_n = self._minmax(self.trans_raw)
        momentum_n = self._minmax(self.momentum)
        # 近期增量：最近 10 期 - 前 10 期，只保留走强部分（负值记 0）
        delta_raw = {n: max(0.0, self.recent10[n] - self.prev10[n]) for n in range(1, 50)}
        delta_n = self._minmax(delta_raw)
        z_freq = self._zscore({n: float(self.hit_count[n]) for n in range(1, 50)})
        z_gap = self._zscore(self.gap)

        # 1) 热门：指数衰减加权频次为主（self.freq 已按期序衰减，并非原始全量计数），近期 10 期为辅
        hot = {n: 0.65 * freq_n[n] + 0.35 * recent10_n[n] for n in range(1, 50)}
        # 2) 冷门：遗漏与超期比为主，低全量频次为辅
        cold = {
            n: 0.55 * gap_n[n] + 0.30 * overdue_n[n] + 0.15 * (1.0 - freq_n[n])
            for n in range(1, 50)
        }
        # 3) 走势：最近 5 期 + 20 期斜率 + 10/前10增量
        trend = {
            n: 0.45 * recent5_n[n] + 0.30 * momentum_n[n] + 0.25 * delta_n[n]
            for n in range(1, 50)
        }

        # 综合需要先把三个基础分再归一化，否则 cold 的绝对量级会压过 trend
        hot_n = self._minmax(hot)
        cold_n = self._minmax(cold)
        trend_n = self._minmax(trend)
        hybrid = {
            n: 0.40 * hot_n[n] + 0.25 * cold_n[n] + 0.35 * trend_n[n]
            for n in range(1, 50)
        }

        # 均衡：频率/遗漏越接近均值越好（M=1-min(1,|Z|/2)），
        # 再叠加近期频率与转移强度；取号阶段再做结构分散惩罚
        balanced = {}
        for n in range(1, 50):
            moderate_freq = max(0.0, 1.0 - min(1.0, abs(z_freq[n]) / 2.0))
            moderate_gap = max(0.0, 1.0 - min(1.0, abs(z_gap[n]) / 2.0))
            balanced[n] = (
                0.30 * moderate_freq
                + 0.25 * moderate_gap
                + 0.25 * recent10_n[n]
                + 0.20 * trans_n[n]
            )

        # 马尔科夫：转移强度为主，近期频率与“未被长期遗漏”为辅
        markov = {
            n: 0.70 * trans_n[n] + 0.20 * recent10_n[n] + 0.10 * (1.0 - gap_n[n])
            for n in range(1, 50)
        }

        self.component_scores = {'hot': hot_n, 'cold': cold_n, 'trend': trend_n}
        self.score_maps = {
            'hot': hot,
            'cold': cold,
            'hybrid': hybrid,
            'balanced': balanced,
            'trend': trend,
            'markov': markov,
        }

    # 机器学习策略（复用 lib/ml_model.py，不复制 md 的硬编码权重）
    def _report_progress(self, percent, message):
        """安全调用进度回调；回调异常不影响主计算流程

        功能：若配置了 progress_callback，则以 (percent, message) 调用一次，
            并吞掉回调抛出的任何异常。
        参数：
            percent (int|float): 当前进度百分比。
            message (str): 进度提示文本。
        返回：
            无。
        注意：
            回调异常被静默忽略；不修改实例状态。
        """
        if not self.progress_callback:
            return
        try:
            self.progress_callback(percent, message)
        except Exception:
            pass

    def _ml_scores(self):
        """调用现有 MLPredictionModel 得到 49 个号码的出现概率

        功能：检查期数是否达到 MIN_DRAWS，延迟导入 MLPredictionModel 并用
            self.data 训练/预测，把四类模型概率的算术平均整理成 1..49 的字典。
        参数：无。
        返回：
            tuple[dict, str]: (概率字典, 错误信息)；成功时错误信息为空串。
        说明:
            - 使用 self.data（已按最新在前排序），MLPredictionModel 内部会
              自行反转成旧→新训练顺序；
            - 4 类模型概率算术平均，不做 md 里的 color/odd 硬编码加权；
            - 数据不足或 sklearn 缺失时返回明确错误，由上层展示。
        注意：
            可能训练并写 ml_models.pkl（ml_use_cache=True 且无缓存时）。
        """
        if self.draws < self.MIN_DRAWS:
            return {}, '数据不足：机器学习至少需要 %d 期，当前 %d 期' % (self.MIN_DRAWS, self.draws)
        try:
            # 延迟导入：只有用户点「机器学习」策略时才加载 sklearn 链路
            from lib.ml_model import MLPredictionModel  # 作用说明：延迟导入机器学习预测模型，仅在机器学习策略路径加载 sklearn 训练链路
            self._report_progress(10, '机器学习：准备训练数据...')
            model = MLPredictionModel(self.data, base_dir=self.ml_base_dir)
            result = model.predict_with_all_models(
                progress_callback=lambda percent, msg: self._report_progress(percent, '机器学习：' + msg),
                use_cache=self.ml_use_cache,
            )
            if not result:
                return {}, '机器学习模型未返回有效结果（数据不足或 sklearn 不可用）'
            _predictions, probabilities = result
            if not probabilities:
                return {}, '机器学习未返回号码概率'
            scores = {}
            for number in range(1, 50):
                scores[number] = float(probabilities.get(number, 0.0))
            return scores, ''
        except Exception as exc:
            return {}, '机器学习计算失败：%s' % str(exc)[:120]

    # 选号、特别码与均衡约束
    @staticmethod
    def _rank(scores):
        """按得分降序、同分号码升序排序，保证结果可复现

        功能：以 (-得分, 号码) 为键对 scores 的键排序，返回号码列表。
        参数：
            scores (dict): {号码: 得分}。
        返回：
            list[int]: 号码列表，按得分降序、同分升序。
        注意：
            无副作用。
        """
        return sorted(scores.keys(), key=lambda number: (-float(scores[number]), number))

    def _wave_of(self, number):
        """返回号码所属波色名称（红波/绿波/蓝波），用于均衡分散惩罚

        功能：依次检查 LotteryConfig.RED_NUMBERS/BLUE_NUMBERS/GREEN_NUMBERS，
            返回首个命中的波色名称。
        参数：
            number (int): 号码 1..49。
        返回：
            str: '红波'/'蓝波'/'绿波'；未命中返回空串。
        注意：
            无副作用。
        """
        if number in LotteryConfig.RED_NUMBERS:
            return '红波'
        if number in LotteryConfig.BLUE_NUMBERS:
            return '蓝波'
        if number in LotteryConfig.GREEN_NUMBERS:
            return '绿波'
        return ''

    def _balance_penalty(self, number, selected):
        """计算均衡策略在已选号码下的结构惩罚值

        功能：对候选号码统计已选号码的奇偶/大小结构、尾数重复、同波色数量、
            同生肖数量与部分和极值，逐项累加惩罚值，供贪心选号时扣分。
        为什么需要惩罚:
            只按分数取 Top-6 会让均衡策略退化成另一个综合策略；
            这里对奇偶 3:3、大小 3:3、尾数/波色/生肖分散逐项惩罚，
            使最终组合在结构上真正“均衡”，而不是只换一套权重。
        参数：
            number (int): 候选号码。
            selected (list[int]): 已选号码。
        返回：
            float: 惩罚值，越大越不倾向选择。
        注意：
            只读 selected，不修改任何状态。
        """
        if not selected:
            return 0.0
        penalty = 0.0
        odd = sum(1 for n in selected if n % 2 == 1)
        even = len(selected) - odd
        # 6 个正码的理想结构是 3 奇 3 偶、3 小 3 大（小=1..25）
        if number % 2 == 1 and odd >= 3:
            penalty += 0.12
        if number % 2 == 0 and even >= 3:
            penalty += 0.12
        big_count = sum(1 for n in selected if n > 25)
        small_count = len(selected) - big_count
        if number > 25 and big_count >= 3:
            penalty += 0.12
        if number <= 25 and small_count >= 3:
            penalty += 0.12

        # 尾数重复会让组合分布过于集中，重复一次罚 0.06
        if number % 10 in {n % 10 for n in selected}:
            penalty += 0.06
        # 同一波色超过 3 个开始罚，避免全红/全绿
        wave = self._wave_of(number)
        if wave and sum(1 for n in selected if self._wave_of(n) == wave) >= 3:
            penalty += 0.06
        # 生肖按 [10] 页绑定去重；同生肖第 2 个开始罚，保证生肖覆盖
        zodiac = self.zodiac_binding.get(number, '')
        if zodiac and sum(1 for n in selected if self.zodiac_binding.get(n) == zodiac) >= 2:
            penalty += 0.05

        # 部分和防极端：已有 3 个号时，避免继续堆 40+ 或 10- 的极值
        if len(selected) >= 3:
            partial_avg = sum(selected) / float(len(selected))
            if number > 40 and partial_avg > 32:
                penalty += 0.03
            if number < 10 and partial_avg < 18:
                penalty += 0.03
        return penalty

    def _select_balanced(self, scores):
        """均衡策略贪心选号：每步在得分上扣结构惩罚，取净分最高者

        功能：循环 6 次，每次遍历未选号码，计算 得分-结构惩罚，取净分最高
            （同分取小号），直到选满 6 个或无可选号码。
        参数：
            scores (dict): 本策略 1..49 得分。
        返回：
            list[int]: 升序排列的 6 个正码。
        注意：
            无副作用；候选为空时可能返回不足 6 个。
        """
        selected = []
        while len(selected) < 6:
            best_number = None
            best_value = None
            for number in range(1, 50):
                if number in selected:
                    continue
                value = float(scores[number]) - self._balance_penalty(number, selected)
                if (best_value is None or value > best_value + 1e-12
                        or (abs(value - best_value) <= 1e-12 and number < best_number)):
                    best_value = value
                    best_number = number
            if best_number is None:
                break
            selected.append(best_number)
        return sorted(selected)

    def _select_numbers(self, key, scores):
        """按策略选 6 个正码；均衡走结构贪心，其余走纯分数 Top-6

        功能：key=='balanced' 时调用 _select_balanced，否则按 _rank 取前 6 个。
        参数：
            key (str): 策略标识（hot/cold/hybrid/balanced/trend/markov/ml）。
            scores (dict): 本策略 1..49 得分。
        返回：
            list[int]: 升序排列的 6 个正码。
        注意：
            无副作用。
        """
        if key == 'balanced':
            return self._select_balanced(scores)
        return sorted(self._rank(scores)[:6])

    def _select_special(self, normal_numbers, scores):
        """选择特别码，保证与 6 个正码互不重复

        功能：从非正码中按本策略得分取前 10 名形成候选池，再按特码历史频率、
            本策略得分、号码升序确定性择优。
        口径:
            沿用现有 _predict_special_number 的“排除已选正码 + 特码历史频率”
            基础，但把候选范围收敛到本策略得分前 10 名：
            既避免随机性导致七行结果不可复现，又让不同策略的特别码
            跟随各自的正码口径变化，而不是七个策略永远输出同一个特码。
        参数：
            normal_numbers (list[int]): 已选正码。
            scores (dict): 本策略 1..49 得分。
        返回：
            int: 特别码；候选为空时返回 0。
        注意：
            确定性选取，不使用随机数，保证同一次生成结果可复现。
        """
        candidates = [n for n in range(1, 50) if n not in set(normal_numbers)]
        if not candidates:
            return 0
        special_n = self._minmax(self.special_freq)
        score_n = self._minmax(scores)
        # 候选池：本策略得分最高的 10 个非正码（不足 10 个时全取）
        pool = self._rank({n: scores[n] for n in candidates})[:10]
        return min(pool, key=lambda number: (-special_n.get(number, 0.0),
                                              -score_n.get(number, 0.0), number))

    # 分析说明文本（数值来自本次真实特征，不写空泛套话）
    def _analysis_text(self, key, numbers, special, scores):
        """生成某策略的“分析说明”

        功能：拼装分析窗口与取号口径、入选号码得分、该策略关键特征的真实数值、
            特别码候选口径与免责说明，返回一段文本。
        内容:
            窗口与取号口径 → 该策略关键特征的真实数值 → 入选号码得分区间
            → 特别码候选口径。所有数字都来自本次计算，不是模板文案。
        参数：
            key (str): 策略标识。
            numbers (list[int]): 已选正码。
            special (int): 已选特别码。
            scores (dict): 本策略 1..49 得分。
        返回：
            str: 分析说明文本；未生成号码时返回“未生成有效号码。”。
        注意：
            纯文本拼接，不含 Qt 控件；只读实例特征，不修改状态。
        """
        if not numbers:
            return '未生成有效号码。'
        score_text = '、'.join('%02d=%.3f' % (n, float(scores.get(n, 0.0))) for n in numbers)
        parts = [
            '分析窗口 %d 期（最新期号 %s），按 1~49 独立评分后降序取前 6。'
            % (self.draws, self.latest_period),
            '入选号码得分：%s。' % score_text,
        ]

        if key == 'hot':
            detail = '、'.join(
                '%02d(全量%.1f次/近10期%.1f次)' % (n, self.hit_count[n], self.recent10[n])
                for n in numbers
            )
            parts.append('频率依据：%s；全量频次权重 0.65，近期 10 期权重 0.35。' % detail)
        elif key == 'cold':
            detail = '、'.join(
                '%02d(遗漏%d期/平均间隔%.1f期/超期比%.2f)'
                % (n, self.gap[n], self.avg_interval[n], self.overdue[n])
                for n in numbers
            )
            parts.append('遗漏依据：%s；遗漏期数权重 0.55、超期比 0.30、低全量频次 0.15。' % detail)
        elif key == 'trend':
            detail = '、'.join(
                '%02d(近5期%.1f/近10期%.1f/斜率%+.3f)'
                % (n, self.recent5[n], self.recent10[n], self.momentum[n])
                for n in numbers
            )
            parts.append('走势依据：%s；斜率由 numpy 对最近 20 期 0/1 出现序列做一次多项式拟合得到。' % detail)
        elif key == 'hybrid':
            hot_n = self.component_scores.get('hot', {})
            cold_n = self.component_scores.get('cold', {})
            trend_n = self.component_scores.get('trend', {})
            detail = '、'.join(
                '%02d(热%.3f/冷%.3f/势%.3f)'
                % (n, hot_n.get(n, 0), cold_n.get(n, 0), trend_n.get(n, 0))
                for n in numbers
            )
            parts.append('三基元归一化分：%s；最终按 0.40/0.25/0.35 相加。' % detail)
        elif key == 'balanced':
            odd = sum(1 for n in numbers if n % 2 == 1)
            big = sum(1 for n in numbers if n > 25)
            tails = len({n % 10 for n in numbers})
            waves = len({self._wave_of(n) for n in numbers if self._wave_of(n)})
            zodiacs = len({self.zodiac_binding.get(n, '') for n in numbers if self.zodiac_binding.get(n, '')})
            parts.append(
                '结构覆盖：奇偶 %d:%d，大小 %d:%d，尾数 %d 种，波色 %d 种，生肖 %d 种；'
                '取号时对超出 3:3 的奇偶/大小、重复尾数、同波色第 4 个、同生肖第 3 个逐项扣分。'
                % (odd, 6 - odd, big, 6 - big, tails, waves, zodiacs)
            )
        elif key == 'markov':
            detail = '、'.join(
                '%02d(转移%.3f)' % (n, self._minmax(self.trans_raw).get(n, 0))
                for n in numbers
            )
            parts.append(
                '转移依据：%s；以最新一期 7 个号码为条件，统计历史相似状态下下一期的后继号码，'
                '时间衰减系数 0.995。' % detail
            )
        elif key == 'ml':
            detail = '、'.join('%02d(P=%.4f)' % (n, float(scores.get(n, 0))) for n in numbers)
            parts.append(
                '模型概率：%s；随机森林/梯度提升/逻辑回归/MLP 四类模型概率算术平均，'
                '不是硬编码颜色或奇偶权重。' % detail
            )

        parts.append(
            '特别码 %02d：在非正码中取本策略得分前 10 名形成候选池，'
            '池内按特码历史频率择优，与正码互不重复。' % special
        )
        parts.append('说明：本结果为历史统计筛选，不保证中奖。')
        return ' '.join(parts)

    # 对外入口
    def _empty_item(self, key, label, error):
        """数据不足或 ML 失败时返回带原理与错误提示的空结果条目

        功能：构造 numbers/special/scores 为空、principle 为策略公式、
            analysis/error 为错误信息的统一结果字典。
        参数：
            key (str): 策略标识。
            label (str): 策略中文名。
            error (str): 错误提示文本。
        返回：
            dict: 策略结果条目，键为 key/label/numbers/special/scores/
                principle/analysis/error。
        注意：
            只读类常量 STRATEGY_FORMULAS/SPECIAL_FORMULA，无副作用。
        """
        return {
            'key': key,
            'label': label,
            'numbers': [],
            'special': 0,
            'scores': {},
            'principle': self.STRATEGY_FORMULAS.get(key, '') + ' ' + self.SPECIAL_FORMULA,
            'analysis': error,
            'error': error,
        }

    def predict_all(self, include_ml=True):
        """生成七策略号码预测结果

        功能：先构建六个统计策略得分，再逐个策略选 6 正码 + 1 特别码并生成
            原理/分析文本；机器学习策略按 include_ml 决定是否计算，七个结果
            顺序固定为 STRATEGIES。数据不足 MIN_DRAWS 时整体返回错误。
        参数：
            include_ml (bool): 是否计算机器学习策略；False 时该行标注“未启用”。
        返回：
            dict: {
                'ok': bool,                 数据是否足够
                'error': str,               整体错误信息（无则空串）
                'draws': int,               参与期数
                'window': int,              请求窗口
                'latest_period': str,       最新期号
                'used_records': int,        实际参与期数
                'strategies': [             七个策略结果，顺序固定
                    {'key','label','numbers','special','scores',
                     'principle','analysis','error'}
                ],
            }
        异常：
            不向外抛异常；ML 失败只影响机器学习那一行。
        注意：
            可能训练/写 ML 模型缓存；其余为纯内存计算。
        """
        result = {
            'ok': self.draws >= self.MIN_DRAWS,
            'error': '',
            'draws': self.draws,
            'window': self.window,
            'latest_period': self.latest_period,
            'used_records': self.draws,
            'strategies': [],
        }
        if not result['ok']:
            message = (
                '数据不足：七策略预测至少需要 %d 期历史数据，当前仅 %d 期。'
                '请先导入更多历史开奖记录后再生成。' % (self.MIN_DRAWS, self.draws)
            )
            result['error'] = message
            for key, label in self.STRATEGIES:
                result['strategies'].append(self._empty_item(key, label, message))
            return result

        # 先构建六个统计策略的得分，避免在循环里重复归一化
        self._build_score_maps()
        for key, label in self.STRATEGIES:
            if key == 'ml':
                if include_ml:
                    scores, error = self._ml_scores()
                else:
                    scores, error = {}, '机器学习策略未启用'
            else:
                scores = self.score_maps.get(key, {})
                error = ''

            if error or not scores:
                result['strategies'].append(
                    self._empty_item(key, label, error or '该策略未产生有效得分'))
                continue

            numbers = self._select_numbers(key, scores)
            special = self._select_special(numbers, scores)
            result['strategies'].append({
                'key': key,
                'label': label,
                'numbers': numbers,
                'special': special,
                'scores': {n: round(float(scores.get(n, 0.0)), 6) for n in numbers},
                'principle': self.STRATEGY_FORMULAS.get(key, '') + ' ' + self.SPECIAL_FORMULA,
                'analysis': self._analysis_text(key, numbers, special, scores),
                'error': '',
            })
        return result
