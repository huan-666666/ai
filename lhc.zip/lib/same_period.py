# -*- coding: utf-8 -*-
"""
============================================================================
lib/same_period.py - 同期对照纯逻辑（禁止 Qt、零新依赖）
============================================================================
在架构中的位置：
    lib/ 纯逻辑层，只被 TAB/same_period_view.py 调用；本模块不 import Qt，
    只依赖标准库 datetime，可在任意线程安全调用。

职责：
    1. parse_source_period()     —— 拆解源站期号（年份 + 年内序号）
    2. normalize_online_record() —— 在线库行归一化并校验（前缀年必须等于日期年）
    3. normalize_local_record()  —— 本地历史记录归一化与校验
    4. filter_records()          —— 批量过滤异常记录并统计
    5. year_stats()              —— 某年的期数 / 序号范围
    6. build_year_rows()         —— 按「同年同期号」并排在线与本地
    7. summarize_rows()          —— 四类状态计数

日期口径：
    在线 draw_date 与本地 date 都先经 lib/date_utils.normalize_date() 归一成
    ISO 再比较；因此「2026年11月04日」「2026/11/04」等录入链写法不会被静默剔除。

口径（与 docs/设计稿/同期对照/设计方案.md §2.3 一致）：
    - 源站期号 source_period 前 4 位是年份，其余是年内序号；
      年内序号数值比较用 int，展示用 zfill(4)。
    - 本地 period 是本地自增序号，不是源站期号，因此两边对齐只看开奖日期：
      本地日期命中在线同日期记录时，用在线记录的年份/序号作为“同期号”。
    - 缺期不补、异常记录隔离，绝不拿该年最后一期冒充目标期。
============================================================================
"""

from datetime import date as _date

from lib.date_utils import normalize_date

STATUS_SAME = 'same'                 # 一致
STATUS_ONLINE_ONLY = 'online_only'   # 仅在线有
STATUS_LOCAL_ONLY = 'local_only'     # 仅本地有
STATUS_DIFF = 'diff'                 # 值不同

STATUS_LABELS = {
    STATUS_SAME: '一致',
    STATUS_ONLINE_ONLY: '仅在线有',
    STATUS_LOCAL_ONLY: '仅本地有',
    STATUS_DIFF: '值不同',
}


def parse_source_period(raw):
    """拆解源站期号：前 4 位年份，其余为年内序号

    参数:
        raw (str|int): 源站期号，如 2026307 / 20260307。

    返回:
        dict: {'year': int, 'seq': int, 'seq_text': str(4 位补零), 'raw': str}。

    异常:
        ValueError：非纯数字、长度不在 5–8、序号小于 1。
    """
    text = str(raw or '').strip()
    if not text.isdigit() or not 5 <= len(text) <= 8:
        raise ValueError('期号格式非法: %r' % raw)
    year = int(text[:4])
    if year < 1900 or year > 2200:
        raise ValueError('期号年份非法: %r' % raw)
    seq = int(text[4:])
    if seq < 1:
        raise ValueError('期号序号非法: %r' % raw)
    return {'year': year, 'seq': seq, 'seq_text': str(seq).zfill(4), 'raw': text}


def _valid_numbers(numbers, special):
    """校验 6 个正码 + 1 个特别码：范围 1–49、正码不重复、特别码不撞正码"""
    mains = [int(n) for n in (numbers or [])]
    special = int(special)
    if len(mains) != 6 or len(set(mains)) != 6:
        raise ValueError('正码必须是 6 个不重复号码')
    if any(n < 1 or n > 49 for n in mains) or special < 1 or special > 49:
        raise ValueError('号码超出 1–49')
    if special in mains:
        raise ValueError('特别码不能与正码重复')
    return mains, special


def _parse_date(text):
    """归一化日期（ISO / 年月日 / 斜杠 / 点号）并返回 date；失败抛 ValueError"""
    try:
        return _date.fromisoformat(normalize_date(text))
    except ValueError:
        raise ValueError('日期格式非法: %r' % text)


def validate_numbers(numbers, special):
    """公开的号码校验入口：返回 (6 个正码 int 列表, 特别码 int)

    校验规则：正码 6 个且不重复、全部 1–49、特别码 1–49 且不撞正码。
    异常:
        ValueError：任一规则不满足（文案可直接展示给用户）。
    """
    return _valid_numbers(numbers, special)


def normalize_online_record(row):
    """把在线库行归一化为同期对照统一记录

    参数:
        row (dict): 含 source_period / draw_date / numbers / special，
            以及可选的 source / fetched_at / url。

    返回:
        dict: {'year','seq','seq_text','period','date','numbers','special',
               'source','fetched_at','url'}。

    异常:
        ValueError：期号非法、日期非法、前缀年份 ≠ 日期年份、号码非法。
    """
    period = parse_source_period((row or {}).get('source_period'))
    date_obj = _parse_date((row or {}).get('draw_date'))
    if period['year'] != date_obj.year:
        raise ValueError('prefix year %d != draw_date year %d' % (period['year'], date_obj.year))
    numbers, special = _valid_numbers((row or {}).get('numbers'), (row or {}).get('special'))
    return {
        'year': period['year'],
        'seq': period['seq'],
        'seq_text': period['seq_text'],
        'period': period['raw'],
        'date': date_obj.isoformat(),
        'numbers': numbers,
        'special': special,
        'source': str((row or {}).get('source') or ''),
        'fetched_at': str((row or {}).get('fetched_at') or ''),
        'url': str((row or {}).get('url') or ''),
    }


def normalize_local_record(row):
    """把本地历史记录归一化为同期对照统一记录（只读，不修改入参）

    参数:
        row (dict): 含 period / date / numbers / special。

    返回:
        dict: {'period','date','numbers','special'}。

    异常:
        ValueError：日期非法、期号非法、号码非法。
    """
    date_obj = _parse_date((row or {}).get('date'))
    period_raw = (row or {}).get('period')
    try:
        period = int(period_raw)
    except (TypeError, ValueError):
        raise ValueError('本地期号非法: %r' % period_raw)
    numbers, special = _valid_numbers((row or {}).get('numbers'), (row or {}).get('special'))
    return {
        'period': period,
        'date': date_obj.isoformat(),
        'numbers': numbers,
        'special': special,
    }


def filter_records(rows, normalizer):
    """批量归一化：有效记录与异常记录分离，同 (year, seq) 或同日期只保留一条

    参数:
        rows (list[dict]): 原始记录。
        normalizer (callable): normalize_online_record 或 normalize_local_record。

    返回:
        tuple(list[dict], list[dict]): (有效记录, 异常记录)。
            异常项为 {'raw': 原记录, 'reason': 原因文本}。
    """
    valid, anomalies = [], []
    seen = set()
    for row in rows or []:
        try:
            record = normalizer(row)
        except (ValueError, TypeError) as exc:
            anomalies.append({'raw': row, 'reason': str(exc)})
            continue
        key = (record.get('year'), record.get('seq')) if 'seq' in record else record.get('date')
        if key in seen:
            anomalies.append({'raw': row, 'reason': '重复记录: %r' % (key,)})
            continue
        seen.add(key)
        valid.append(record)
    return valid, anomalies


def year_stats(records, year):
    """返回某年的期数与年内序号范围（无记录时 count=0、min/max 为 None）

    参数:
        records (list[dict]): 已归一化的在线记录。
        year (int): 年份。

    返回:
        dict: {'count','min_seq','max_seq'}。
    """
    seqs = [record['seq'] for record in records or [] if record.get('year') == year]
    if not seqs:
        return {'count': 0, 'min_seq': None, 'max_seq': None}
    return {'count': len(seqs), 'min_seq': min(seqs), 'max_seq': max(seqs)}


def build_year_rows(online_records, local_records, year, seq_min=None, seq_max=None):
    """按「同年同期号」并排某年的在线与本地记录

    对齐规则:
        1) 本地记录的日期命中在线同日期记录 → 用在线记录的年份/序号作为同期号，
           两侧并排；号码集合或特别码不同记“值不同”，全同记“一致”。
        2) 在线有、本地无同日记录 → “仅在线有”。
        3) 本地有、在线无同日记录 → “仅本地有”（没有同期号，序号列为 None）。

    参数:
        online_records (list[dict]): 已归一化的在线记录。
        local_records (list[dict]): 已归一化的本地记录。
        year (int): 目标年份。
        seq_min (int|None): 年内序号下界（含）。
        seq_max (int|None): 年内序号上界（含）。

    返回:
        list[dict]: 每行含 year / seq / seq_text / date / online / local / status / label。
    """
    low = int(seq_min) if seq_min is not None else 1
    high = int(seq_max) if seq_max is not None else 999
    if low > high:
        low, high = high, low

    online_year = [record for record in online_records or [] if record.get('year') == year]
    online_by_date = {record['date']: record for record in online_year}
    local_year = []
    for record in local_records or []:
        try:
            iso_date = normalize_date(record.get('date'))
        except (TypeError, ValueError):
            continue
        if iso_date[:4] != str(year).zfill(4):
            continue
        normalized = dict(record)
        normalized['date'] = iso_date
        local_year.append(normalized)
    local_by_date = {}
    for record in local_year:
        local_by_date.setdefault(record['date'], record)

    rows = []
    paired_local_dates = set()
    for record in sorted(online_year, key=lambda item: item['seq']):
        if not low <= record['seq'] <= high:
            continue
        local = local_by_date.get(record['date'])
        if local is None:
            rows.append({
                'year': year, 'seq': record['seq'], 'seq_text': record['seq_text'],
                'date': record['date'], 'online': record, 'local': None,
                'status': STATUS_ONLINE_ONLY, 'label': STATUS_LABELS[STATUS_ONLINE_ONLY],
            })
            continue
        paired_local_dates.add(local['date'])
        same = (sorted(record['numbers']) == sorted(local['numbers'])
                and record['special'] == local['special'])
        status = STATUS_SAME if same else STATUS_DIFF
        rows.append({
            'year': year, 'seq': record['seq'], 'seq_text': record['seq_text'],
            'date': record['date'], 'online': record, 'local': local,
            'status': status, 'label': STATUS_LABELS[status],
        })

    # 本地有、在线无同日记录：没有同期号，排在本年编号行之后
    for record in sorted(local_year, key=lambda item: item['date']):
        if record['date'] in paired_local_dates or record['date'] in online_by_date:
            continue
        rows.append({
            'year': year, 'seq': None, 'seq_text': '—',
            'date': record['date'], 'online': None, 'local': record,
            'status': STATUS_LOCAL_ONLY, 'label': STATUS_LABELS[STATUS_LOCAL_ONLY],
        })
    return rows


def summarize_rows(rows):
    """统计四类状态数量与合计

    参数:
        rows (list[dict]): build_year_rows 的返回值。

    返回:
        dict: {'total','same','online_only','local_only','diff'}。
    """
    summary = {'total': len(rows or []), STATUS_SAME: 0, STATUS_ONLINE_ONLY: 0,
               STATUS_LOCAL_ONLY: 0, STATUS_DIFF: 0}
    for row in rows or []:
        status = row.get('status')
        if status in summary:
            summary[status] += 1
    return summary
