# -*- coding: utf-8 -*-
"""
============================================================================
lib/online_store.py - 在线开奖独立 SQLite 库（纯逻辑层，禁止 Qt）
============================================================================
数据库位置：
    程序目录/系统v7.5/在线开奖.db（与 app_config.db 完全独立）

设计约束：
    1. 启动期绝不建库：只有“抓取成功 + 解析成功”后才由 worker 调用 save_snapshot()
    2. 每次操作使用短连接；写后 PRAGMA wal_checkpoint(TRUNCATE)，空闲时 -wal 为 0
    3. 只读查询用 mode=ro 打开，库不存在时不会创建文件
    4. 不清理：不做按期/按天自动删除，只提供 clear_online_store() 手动清空
    5. 线程安全：每次调用独立连接，可被多个 worker 串行调用

对外函数：
    db_exists()           —— 库文件是否存在（纯 stat）
    save_snapshot()       —— 建表 + 单事务增量写入 + checkpoint
    load_meta()           —— 读取 online_meta（库/表缺失返回 {}）
    count_records()       —— 总期数（库缺失返回 0）
    fetch_page_newest()   —— 最新一页（keyset 首页）
    fetch_page_next()     —— 向后一页（keyset）
    fetch_page_prev()     —— 向前一页（keyset，返回正序）
    fetch_page_offset()   —— 按偏移取页（备用：页码跳转）
    clear_online_store()  —— 关连接并删除 .db/-wal/-shm
============================================================================
"""

import json                   # 作用说明：numbers_json 与 v_warnings 的序列化
import os                     # 作用说明：删除库文件前判断存在性
import sqlite3                # 作用说明：独立在线库读写
import sys                    # 作用说明：判断 PyInstaller 打包，确定基准目录
import time                   # 作用说明：记录写库耗时
from pathlib import Path

SCHEMA_VERSION = '1'
DB_FILENAME = '在线开奖.db'


def _base_dir():
    """返回程序基准目录（与 lib/db_helper.py 的口径一致，但不产生任何写盘）"""
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = _base_dir()
DATA_DIR = BASE_DIR / '系统v7.5'
DB_PATH = DATA_DIR / DB_FILENAME


def db_exists():
    """判断在线库文件是否存在（启动期只允许做这种无副作用的 stat）"""
    return DB_PATH.is_file()


def _db_size(path):
    """返回单个文件字节数（不存在返回 0）"""
    try:
        return path.stat().st_size
    except OSError:
        return 0


def wal_size():
    """返回当前 -wal 文件字节数（用于验证 checkpoint 是否归零）"""
    return _db_size(Path(str(DB_PATH) + '-wal'))


def _connect(readonly=False):
    """打开数据库连接；只读模式使用 URI mode=ro，库缺失也不会创建文件"""
    if readonly:
        uri = 'file:%s?mode=ro' % DB_PATH.as_posix()
        connection = sqlite3.connect(uri, uri=True, timeout=10.0)
    else:
        connection = sqlite3.connect(str(DB_PATH), timeout=10.0)
    connection.row_factory = sqlite3.Row
    return connection


def _ensure_schema(connection):
    """创建 online_records / online_meta 与索引（只在写库时调用）"""
    connection.execute('''
        CREATE TABLE IF NOT EXISTS online_records (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            source        TEXT NOT NULL,
            source_period TEXT NOT NULL,
            draw_date     TEXT NOT NULL,
            numbers_json  TEXT NOT NULL,
            special       INTEGER NOT NULL,
            fetched_at    TEXT NOT NULL,
            url           TEXT,
            content_hash  TEXT NOT NULL,
            UNIQUE(source, source_period)
        )
    ''')
    connection.execute('''
        CREATE INDEX IF NOT EXISTS idx_online_date
        ON online_records(draw_date DESC)
    ''')
    connection.execute('''
        CREATE INDEX IF NOT EXISTS idx_online_source_date
        ON online_records(source, draw_date DESC)
    ''')
    connection.execute('''
        CREATE TABLE IF NOT EXISTS online_meta (
            key        TEXT PRIMARY KEY,
            value      TEXT,
            updated_at TEXT
        )
    ''')


def _row_to_record(row):
    """把 SQLite 行转换成界面/逻辑层使用的记录字典"""
    try:
        numbers = json.loads(row['numbers_json'])
    except (TypeError, ValueError):
        numbers = []
    return {
        'id': row['id'],
        'source': row['source'],
        'source_period': row['source_period'],
        'draw_date': row['draw_date'],
        'numbers': numbers,
        'special': row['special'],
        'fetched_at': row['fetched_at'],
        'url': row['url'],
        'content_hash': row['content_hash'],
    }


def save_snapshot(records, url, source_type, warnings=None):
    """把抓取成功的记录增量写入独立在线库，并在结束前 checkpoint

    参数:
        records (list[dict]): normalize/dedupe 后的记录（至少含 source_period、
            draw_date、numbers、special、content_hash）。
        url (str): 本次抓取地址，写入 online_meta.v_url。
        source_type (str): 解析器类型，写入 online_meta.v_source_type。
        warnings (list[str]|None): 解析警告，写入 online_meta.v_warnings。

    返回:
        dict: 含 inserted/updated/unchanged/total/wal_before/wal_after/
        db_bytes/elapsed_ms/summary。

    异常:
        ValueError：records 为空（调用方应先拦截）；
        sqlite3.Error：磁盘错误等，由调用方转成 store_failed 文案。

    副作用:
        创建 系统v7.5/在线开奖.db（目录不存在时先创建）、写入数据与元信息、
        执行 wal_checkpoint(TRUNCATE)。
    """
    if not records:
        raise ValueError('records 为空，不创建在线库')
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    connection = _connect(readonly=False)
    try:
        connection.execute('PRAGMA journal_mode=WAL')
        connection.execute('PRAGMA synchronous=NORMAL')
        connection.execute('BEGIN IMMEDIATE')
        _ensure_schema(connection)
        total_before = connection.execute('SELECT COUNT(*) FROM online_records').fetchone()[0]
        changes_before = connection.total_changes
        for record in records:
            connection.execute(
                'INSERT INTO online_records'
                ' (source, source_period, draw_date, numbers_json, special, fetched_at, url, content_hash)'
                ' VALUES (?,?,?,?,?,?,?,?)'
                ' ON CONFLICT(source, source_period) DO UPDATE SET'
                '   draw_date=excluded.draw_date,'
                '   numbers_json=excluded.numbers_json,'
                '   special=excluded.special,'
                '   fetched_at=excluded.fetched_at,'
                '   url=excluded.url,'
                '   content_hash=excluded.content_hash'
                ' WHERE online_records.content_hash <> excluded.content_hash',
                (record.get('source') or source_type, record['source_period'],
                 record['draw_date'], json.dumps(record['numbers']), int(record['special']),
                 record.get('fetched_at') or time.strftime('%Y-%m-%d %H:%M:%S'),
                 record.get('url') or url, record['content_hash']))
        changed = connection.total_changes - changes_before
        total_after = connection.execute('SELECT COUNT(*) FROM online_records').fetchone()[0]
        dates = [r['draw_date'] for r in records if r.get('draw_date')]
        meta = {
            'v_url': url,
            'v_fetched_at': time.strftime('%Y-%m-%d %H:%M:%S'),
            'v_source_type': source_type,
            'v_count': str(total_after),
            'v_range_start': min(dates) if dates else '',
            'v_range_end': max(dates) if dates else '',
            'v_warnings': json.dumps(list(warnings or []), ensure_ascii=False),
            'schema_version': SCHEMA_VERSION,
        }
        now = time.strftime('%Y-%m-%d %H:%M:%S')
        for key, value in meta.items():
            connection.execute(
                'INSERT INTO online_meta (key, value, updated_at) VALUES (?,?,?)'
                ' ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at',
                (key, value, now))
        connection.commit()
        inserted = total_after - total_before
        updated = max(0, changed - inserted)
        unchanged = len(records) - changed
        wal_before = wal_size()
        connection.execute('PRAGMA wal_checkpoint(TRUNCATE)')
    finally:
        connection.close()
    return {
        'inserted': inserted,
        'updated': updated,
        'unchanged': max(0, unchanged),
        'total': total_after,
        'wal_before': wal_before,
        'wal_after': wal_size(),
        'db_bytes': _db_size(DB_PATH),
        'elapsed_ms': (time.perf_counter() - started) * 1000.0,
        'meta': meta,
        'summary': {
            'count': total_after,
            'range_start': min(dates) if dates else '',
            'range_end': max(dates) if dates else '',
        },
    }


def load_meta():
    """读取 online_meta；库或表不存在时返回空字典（不创建任何文件）"""
    if not db_exists():
        return {}
    try:
        connection = _connect(readonly=True)
    except sqlite3.Error:
        return {}
    try:
        rows = connection.execute('SELECT key, value FROM online_meta').fetchall()
        return {row['key']: row['value'] for row in rows}
    except sqlite3.Error:
        return {}
    finally:
        connection.close()


def count_records():
    """返回在线库总期数；库/表不存在返回 0"""
    if not db_exists():
        return 0
    try:
        connection = _connect(readonly=True)
    except sqlite3.Error:
        return 0
    try:
        return connection.execute('SELECT COUNT(*) FROM online_records').fetchone()[0]
    except sqlite3.Error:
        return 0
    finally:
        connection.close()


def _fetch_rows(sql, params):
    """执行分页 SQL；库缺失返回空列表"""
    if not db_exists():
        return []
    try:
        connection = _connect(readonly=True)
    except sqlite3.Error:
        return []
    try:
        rows = connection.execute(sql, params).fetchall()
        return [_row_to_record(row) for row in rows]
    except sqlite3.Error:
        return []
    finally:
        connection.close()


_SELECT = ('SELECT id, source, source_period, draw_date, numbers_json, special,'
           ' fetched_at, url, content_hash FROM online_records ')


def fetch_page_newest(limit=100):
    """取最新一页：draw_date DESC, id DESC（keyset 首页）"""
    return _fetch_rows(_SELECT + 'ORDER BY draw_date DESC, id DESC LIMIT ?', (int(limit),))


def fetch_page_next(last_date, last_id, limit=100):
    """向后翻页：只取严格小于 (last_date, last_id) 的记录（keyset，避免深 OFFSET）"""
    sql = (_SELECT + 'WHERE draw_date < ? OR (draw_date = ? AND id < ?) '
           'ORDER BY draw_date DESC, id DESC LIMIT ?')
    return _fetch_rows(sql, (last_date, last_date, last_id, int(limit)))


def fetch_page_prev(first_date, first_id, limit=100):
    """向前翻页：反向取 100 条后翻转为正序（keyset）"""
    sql = (_SELECT + 'WHERE draw_date > ? OR (draw_date = ? AND id > ?) '
           'ORDER BY draw_date ASC, id ASC LIMIT ?')
    rows = _fetch_rows(sql, (first_date, first_date, first_id, int(limit)))
    rows.reverse()
    return rows


# 预留：按偏移分页取数（当前未接界面，仅保留能力）
def fetch_page_offset(offset, limit=100):
    """按偏移取页（备用；5000 期实测 OFFSET 约 0.3–0.9ms，仍远低于 200ms）"""
    sql = _SELECT + 'ORDER BY draw_date DESC, id DESC LIMIT ? OFFSET ?'
    return _fetch_rows(sql, (int(limit), int(offset)))


def _fetch_raw(sql, params):
    """执行只读 SQL 并返回原始 dict 行；库缺失/损坏返回空列表（不创建文件）"""
    if not db_exists():
        return []
    try:
        connection = _connect(readonly=True)
    except sqlite3.Error:
        return []
    try:
        rows = connection.execute(sql, params).fetchall()
        return [dict(row) for row in rows]
    except sqlite3.Error:
        return []
    finally:
        connection.close()


def probe_store():
    """探测在线库可用性，供同期对照页区分「不存在 / 空库 / 读失败」

    返回:
        dict: {'exists': bool, 'ok': bool, 'count': int, 'error': str}。
            exists=False 表示文件不存在；exists=True 且 ok=False 表示文件在但打不开
            或不是合法库（损坏/被占用）；ok=True 时 count 为记录数。
    """
    if not db_exists():
        return {'exists': False, 'ok': False, 'count': 0, 'error': ''}
    try:
        connection = _connect(readonly=True)
    except sqlite3.Error as exc:
        return {'exists': True, 'ok': False, 'count': 0, 'error': str(exc)}
    try:
        count = int(connection.execute('SELECT COUNT(*) FROM online_records').fetchone()[0])
        return {'exists': True, 'ok': True, 'count': count, 'error': ''}
    except sqlite3.Error as exc:
        return {'exists': True, 'ok': False, 'count': 0, 'error': str(exc)}
    finally:
        connection.close()


def fetch_years():
    """返回在线库覆盖的年份及期数（新年份在前）；库缺失/损坏返回空列表

    返回:
        list[dict]: 每项 {'year': 'YYYY', 'count': int}。
    """
    rows = _fetch_raw(
        "SELECT substr(draw_date, 1, 4) AS year, COUNT(*) AS count"
        " FROM online_records GROUP BY year ORDER BY year DESC", ())
    years = []
    for row in rows:
        text = str(row.get('year') or '')
        if len(text) == 4 and text.isdigit():
            years.append({'year': text, 'count': int(row.get('count') or 0)})
    return years


def fetch_year_records(year):
    """取某自然年的全部在线记录（按日期升序），供同期对照一次性构建

    参数:
        year (str|int): 四位年份。

    返回:
        list[dict]: 记录字典列表（字段同 _row_to_record）；库缺失/损坏返回空列表。
    """
    text = str(year).strip()
    if len(text) != 4 or not text.isdigit():
        return []
    sql = (_SELECT + 'WHERE draw_date >= ? AND draw_date <= ? ORDER BY draw_date ASC, id ASC')
    return _fetch_rows(sql, (text + '-01-01', text + '-12-31'))


def fetch_year_summary(year):
    """统计某年的在线期数与年内序号范围（无效期号不计入 min/max）

    参数:
        year (str|int): 四位年份。

    返回:
        dict: {'count','min_seq','max_seq','range_start','range_end'}；
            无记录时 count=0、min/max 为 None。
    """
    records = fetch_year_records(year)
    seqs, dates = [], []
    for record in records:
        period = str(record.get('source_period') or '')
        date_text = str(record.get('draw_date') or '')
        if date_text:
            dates.append(date_text)
        if len(period) >= 5 and period.isdigit():
            seqs.append(int(period[4:]))
    if not records:
        return {'count': 0, 'min_seq': None, 'max_seq': None, 'range_start': '', 'range_end': ''}
    return {
        'count': len(records),
        'min_seq': min(seqs) if seqs else None,
        'max_seq': max(seqs) if seqs else None,
        'range_start': min(dates) if dates else '',
        'range_end': max(dates) if dates else '',
    }


def clear_online_store():
    """手动清空入口：删除 .db/-wal/-shm 三个文件（无持久连接，无需先关库）

    返回:
        dict: {'deleted': [文件名...], 'missing': [文件名...]}

    异常:
        OSError：文件被占用或无权限时向上抛出，由界面转成失败提示。
    """
    deleted, missing = [], []
    for suffix in ('', '-wal', '-shm'):
        path = Path(str(DB_PATH) + suffix)
        if not path.exists():
            missing.append(path.name)
            continue
        os.remove(str(path))
        deleted.append(path.name)
    return {'deleted': deleted, 'missing': missing}
