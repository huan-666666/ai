# -*- coding: utf-8 -*-
"""
============================================================================
lib/db_helper.py - SQLite + DuckDB 双嵌入式数据库封装层
============================================================================
在架构中的位置：
    lib/ 纯逻辑层的持久化基础设施，被 TAB/ 与 plugins/ 通过 get_db() 单例调用；
    上层不直接 import sqlite3 / duckdb，所有连接、加锁、建表逻辑收敛在本模块。

主要导出对象：
    get_db()            —— 全局唯一 DBHelper 实例（双重检查锁单例）
    DBHelper            —— SQLite（业务）+ DuckDB（分析）双数据库封装
    BASE_DIR / DATA_DIR / SQLITE_PATH / DUCKDB_PATH —— 统一的数据目录与文件路径

依赖：
    sqlite3（标准库）、threading（标准库）；duckdb 与 pandas 均为按需导入，
    lib.data_process.DataUtils 提供号码解析统一实现；
    duckdb 缺失时仅分析类接口不可用，不影响程序启动。

数据库方案（双嵌入式架构，不需要额外启动数据库服务）：
    - SQLite：保存程序配置、用户数据、功能状态，适合增删改查业务数据
              文件：程序目录/系统v7.5/app_config.db
    - DuckDB：数据分析、统计建模、大数据集查询，原生支持CSV/Parquet直接读取
              文件：程序目录/系统v7.5/analysis.duckdb
              分析表：history_detail（每期每个号码一行，供按窗口聚合/统计查询）
              当前使用方：[16] 大数据分析（sync_history_to_duckdb + load_history_for_analysis）

使用方式：
    from lib.db_helper import get_db
    db = get_db()                       # 获取全局唯一实例
    db.set_config('theme', 'dark')      # SQLite 写配置
    theme = db.get_config('theme')      # SQLite 读配置
    df = db.query_analysis('SELECT ...')  # DuckDB 分析查询，返回DataFrame

注意：
    - duckdb 采用懒加载，首次使用 DuckDB 功能时才导入
    - pandas 仅在需要返回 DataFrame 时按需导入
============================================================================
"""

import json          # 作用说明：history_records 的 numbers、storage_items 的 tags 以 JSON 字符串存取
import shutil        # 作用说明：旧版 data/ 目录迁移时用 shutil.move 移动数据库文件
import sys           # 作用说明：用 sys.frozen / sys.executable 判断是否 PyInstaller 打包运行，确定基准目录
import sqlite3       # 作用说明：SQLite 本地库读写，存放程序配置、用户数据、功能状态与历史/存储镜像
import threading     # 作用说明：为 SQLite / DuckDB 连接与全局单例提供互斥锁，保证跨线程安全
from pathlib import Path  # 作用说明：跨平台路径拼接与目录定位（程序目录/数据目录/数据库文件路径）

from lib.data_process import DataUtils  # 作用说明：CSV/Parquet 号码文本统一解析（parse_numbers_text），禁止在本模块另写一份

# ============================================================================
# 数据库文件路径（与 JSON / INI / 数据存储统一放在 程序目录/系统v7.5/）
# ============================================================================
def _get_base_dir():
    """获取程序基准目录

    功能：
        PyInstaller 打包成 exe 后，以 exe 所在目录为基准，保证数据库、
        配置等数据文件与程序放在同一目录，便于整体迁移与备份；
        源码运行时以项目根目录（lib/ 的上一级）为基准。
    参数：
        无。
    返回：
        pathlib.Path: 程序基准目录。
    注意：
        无副作用：仅做路径解析，不创建目录、不写盘。
    """
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).resolve().parent
    # lib/ 的上一级即为项目根目录
    return Path(__file__).resolve().parent.parent


BASE_DIR = _get_base_dir()
# 统一运行时数据目录：数据库与 JSON/INI/数据存储放在同一文件夹
DATA_DIR = BASE_DIR / '系统v7.5'
LEGACY_DATA_DIR = BASE_DIR / 'data'    # 旧版独立数据库目录，仅用于一次性迁移
# 模块导入即创建目录：后续 sqlite3.connect() 不会自动建目录，缺失会直接报错
DATA_DIR.mkdir(parents=True, exist_ok=True)


def _migrate_legacy_db_dir():
    """把旧版 ./data 下的数据库文件迁移到 系统v7.5/（首次启动执行一次）

    功能：
        旧版本把数据库单独放在程序目录/data/，与业务数据目录分离，
        打包或拷贝时容易漏掉数据库；这里逐个把普通文件移动到 DATA_DIR，
        删除 .gitkeep，目标已存在则保留原文件不覆盖，迁移后目录为空则删除 data/。
    参数：
        无。
    返回：
        无。
    注意：
        写盘：会移动/删除旧目录中的文件；所有 OSError 均被捕获忽略，
        失败时保留原文件，不影响程序启动；模块导入时自动执行一次。
    """
    if not LEGACY_DATA_DIR.is_dir():
        return
    for old in list(LEGACY_DATA_DIR.iterdir()):
        if not old.is_file():
            continue
        if old.name == '.gitkeep':
            try:
                old.unlink()
            except OSError:
                pass
            continue
        target = DATA_DIR / old.name
        if target.exists():
            continue
        try:
            shutil.move(str(old), str(target))
        except OSError:
            pass
    try:
        LEGACY_DATA_DIR.rmdir()
    except OSError:
        pass


_migrate_legacy_db_dir()

SQLITE_PATH = DATA_DIR / 'app_config.db'    # SQLite业务数据库
DUCKDB_PATH = DATA_DIR / 'analysis.duckdb'  # DuckDB分析数据库


class DBHelper:
    """双嵌入式数据库封装类（线程安全）

    职责分离：
        - SQLite 连接：配置、用户数据、功能状态等业务数据的增删改查
        - DuckDB 连接：分析型查询、CSV/Parquet 直读、大数据集统计

    关键属性：
        _data_dir (Path)     —— 数据库文件所在目录
        _sqlite_path (Path)  —— app_config.db 完整路径
        _duckdb_path (Path)  —— analysis.duckdb 完整路径
        _sqlite (Connection) —— sqlite3 连接，check_same_thread=False
        _sqlite_lock (Lock)  —— SQLite 互斥锁，所有读/写都在锁内完成
        _duckdb_conn         —— DuckDB 连接，首次使用 _get_duckdb() 时才创建
        _duckdb_lock (Lock)  —— DuckDB 互斥锁，同一连接上的操作串行执行

    生命周期/线程约束：
        - 建议全程只通过 get_db() 获取单例，避免多实例各自持有连接导致 WAL 写冲突
        - 本类不创建线程，所有方法可在任意线程调用；SQLite 通过“单连接 + 锁”
          实现串行化，DuckDB 通过“单连接 + 锁”实现串行化
        - 一个 DBHelper 实例必须 close() 后才能被垃圾回收，否则 WAL/SHM 文件
          可能残留
        - 由于 SQLite 连接跨线程共享，绝不能在持有锁时再调用会再次加锁的
          公有方法（threading.Lock 不可重入，会自死锁）
    """

    def __init__(self, data_dir=None):
        """初始化数据库连接并建表

        功能：
            确定数据目录并确保存在，打开 SQLite 连接、尝试开启 WAL、执行建表；
            DuckDB 连接与模块延后到首次调用 _get_duckdb() 时才创建。
        参数：
            data_dir (str | Path | None): 数据目录。None 时使用模块级 DATA_DIR
                （程序目录/系统v7.5/）；目录不存在会自动创建。

        返回：
            无。

        注意：
            副作用：创建目录、打开 SQLite 连接、尝试开启 WAL、执行建表 DDL；
            DuckDB 此时不连接。
            异常：sqlite3.OperationalError 会在内部被捕获并降级为 DELETE 日志模式后
            重试；若重试仍失败则继续向外抛出，导致实例化失败。
        """
        # 确定数据目录并确保存在
        self._data_dir = Path(data_dir) if data_dir else DATA_DIR
        self._data_dir.mkdir(parents=True, exist_ok=True)
        self._sqlite_path = self._data_dir / SQLITE_PATH.name
        self._duckdb_path = self._data_dir / DUCKDB_PATH.name

        # SQLite 多线程访问锁（WAL模式 + 锁，保证并发写安全）
        self._sqlite_lock = threading.Lock()
        # check_same_thread=False 允许跨线程使用，配合锁保证安全
        self._sqlite = sqlite3.connect(str(self._sqlite_path), check_same_thread=False)
        self._sqlite.row_factory = sqlite3.Row  # 查询结果支持按列名访问
        # 开启WAL日志模式，提升并发读写性能
        try:
            self._sqlite.execute('PRAGMA journal_mode=WAL')
        except sqlite3.Error:
            pass  # 个别文件系统不支持 WAL，忽略，后续按实际写入结果判断
        # 说明：PRAGMA 只负责“尝试切换”，不会抛错时也未必真正生效；
        # 真正的失败通常在随后首次写入（建表）时以 OperationalError 暴露，
        # 因此下面 _init_tables() 还准备了一次 DELETE 模式的降级重试。

        # DuckDB 懒加载：连接在首次使用时创建
        self._duckdb_conn = None
        # DuckDB 连接锁（连接对象非线程安全，读写统一串行）
        self._duckdb_lock = threading.Lock()

        # 初始化业务表结构
        # 兼容性回退：虚拟共享目录、网络盘等文件系统无法使用 WAL，
        # 首次建表会报 disk I/O error，此时退回传统 DELETE 日志模式重试
        try:
            self._init_tables()
        except sqlite3.OperationalError:
            # 降级路径：网络盘/虚拟共享目录常不支持 WAL 的共享内存文件（-shm），
            # 首次建表会报 disk I/O error；改用传统 DELETE 日志模式后重试。
            # 此时并发读写性能下降，但可保证程序在非本地磁盘上也能启动。
            try:
                self._sqlite.execute('PRAGMA journal_mode=DELETE')
            except sqlite3.Error:
                pass
            self._init_tables()

    # ========================================================================
    # SQLite：初始化表结构
    # ========================================================================
    def _init_tables(self):
        """创建SQLite业务表（不存在时才创建）

        功能：
            在 SQLite 中创建 app_config、user_data、func_state、history_records、
            storage_items 五张业务表（全部使用 CREATE TABLE IF NOT EXISTS）。

        表说明：
            app_config:      程序配置键值表
            user_data:       用户数据表
            func_state:      插件功能状态表
            history_records: 历史开奖数据镜像表（JSON 丢失时兜底恢复）
            storage_items:   [15] 数据存储索引表（index.json 的数据库镜像）

        参数：
            无。

        返回：
            无。

        注意：
            副作用：在 SQLite 中创建上述 5 张表并提交事务；表已存在时不做任何修改
            （全部使用 CREATE TABLE IF NOT EXISTS，可重复调用）。
            异常：sqlite3.OperationalError 由调用方 __init__ 捕获以触发 WAL→DELETE
            降级；sqlite3.Error（如磁盘满）会直接向外抛出。
        """
        with self._sqlite_lock:
            # 程序配置表：键值存储
            self._sqlite.execute('''
                CREATE TABLE IF NOT EXISTS app_config (
                    key        TEXT PRIMARY KEY,
                    value      TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            # 用户数据表：通用业务数据
            self._sqlite.execute('''
                CREATE TABLE IF NOT EXISTS user_data (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    category   TEXT NOT NULL,
                    content    TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            # 功能状态表：记录各插件的启用状态与运行参数
            self._sqlite.execute('''
                CREATE TABLE IF NOT EXISTS func_state (
                    plugin_name TEXT PRIMARY KEY,
                    enabled     INTEGER DEFAULT 1,
                    state_json  TEXT,
                    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            # 历史开奖数据镜像表：以 period 为主键，numbers 存 JSON 字符串
            # 作用：彩票数据.json 丢失/损坏时，可从数据库恢复全部历史记录
            self._sqlite.execute('''
                CREATE TABLE IF NOT EXISTS history_records (
                    period     INTEGER PRIMARY KEY,
                    date       TEXT,
                    numbers    TEXT NOT NULL,
                    special    INTEGER NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            # 数据存储索引表：镜像 系统v7.5/数据存储/index.json
            # 文件本体仍放磁盘，数据库只存元数据，JSON 丢失时据此恢复列表
            self._sqlite.execute('''
                CREATE TABLE IF NOT EXISTS storage_items (
                    id         TEXT PRIMARY KEY,
                    type       TEXT,
                    title      TEXT,
                    content    TEXT,
                    file_path  TEXT,
                    tags       TEXT,
                    created_at TEXT,
                    updated_at TEXT,
                    size       INTEGER,
                    synced_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            self._sqlite.commit()

    # ========================================================================
    # SQLite：配置读写（程序配置）
    # ========================================================================
    def set_config(self, key, value):
        """写入/更新程序配置（INSERT ... ON CONFLICT 实现 upsert）

        功能：
            以 upsert 方式写入 app_config 表：键不存在则插入，存在则覆盖
            value 与 updated_at。
        参数：
            key (str): 配置键，写入前统一转 str
            value (Any): 配置值，统一转 str 后存储；读取时调用方需自行还原类型

        返回：
            无。

        注意：
            写盘：写 app_config 表并 commit，写操作不可回滚。
            并发：全程持有 _sqlite_lock，与其它写操作串行。
        """
        with self._sqlite_lock:
            self._sqlite.execute(
                'INSERT INTO app_config(key, value) VALUES(?, ?) '
                'ON CONFLICT(key) DO UPDATE SET value=excluded.value, '
                'updated_at=CURRENT_TIMESTAMP',
                (str(key), str(value)))
            self._sqlite.commit()

    def get_config(self, key, default=None):
        """读取程序配置

        功能：
            按 key 查询 app_config 表，命中则返回 value 字符串，未命中返回 default。
        参数：
            key (str): 配置键
            default (Any): 键不存在时的返回值
        返回：
            str | Any: 存在时返回配置值的字符串形式，不存在时返回 default。
        注意：
            只读：只执行 SELECT，不写库、不 commit；读取在 _sqlite_lock 内完成。
        """
        with self._sqlite_lock:
            row = self._sqlite.execute(
                'SELECT value FROM app_config WHERE key=?', (str(key),)).fetchone()
        return row['value'] if row else default


    # ========================================================================
    # SQLite：功能状态（插件启用状态）
    # ========================================================================
    def set_func_state(self, plugin_name, enabled=True, state_json=None):
        """保存插件功能状态（按插件名 upsert）

        功能：
            以 plugin_name 为主键向 func_state 表 upsert，enabled 转为 1/0 存储。
        参数：
            plugin_name (str): 插件名称（主键）
            enabled (bool): 是否启用；入库时转换为 1/0（SQLite 无布尔类型）
            state_json (str | None): 插件运行参数的 JSON 字符串，可为 None

        返回：
            无。

        注意：
            写盘：写 func_state 表并 commit；同插件已存在时覆盖 enabled/state_json。
            并发：全程持有 _sqlite_lock，与其它写操作串行。
        """
        with self._sqlite_lock:
            self._sqlite.execute(
                'INSERT INTO func_state(plugin_name, enabled, state_json) VALUES(?, ?, ?) '
                'ON CONFLICT(plugin_name) DO UPDATE SET enabled=excluded.enabled, '
                'state_json=excluded.state_json, updated_at=CURRENT_TIMESTAMP',
                (plugin_name, 1 if enabled else 0, state_json))
            self._sqlite.commit()

    def get_func_state(self, plugin_name):
        """读取插件功能状态（func_state 单行，只读）

        功能：
            按 plugin_name 查询单行状态，供调用方做「内容没变就不写」的写前比对。
        参数：
            plugin_name (str): 插件名称（主键）
        返回：
            dict | None: 命中时返回 {'plugin_name','enabled','state_json','updated_at'}，
                未命中返回 None。
        注意：
            无副作用：只执行 SELECT，不写库、不 commit，不产生新的 WAL 帧。
        """
        with self._sqlite_lock:
            row = self._sqlite.execute(
                'SELECT plugin_name, enabled, state_json, updated_at '
                'FROM func_state WHERE plugin_name=?', (str(plugin_name),)).fetchone()
        return dict(row) if row else None


    # ========================================================================
    # SQLite：通用执行接口（业务增删改查）
    # ========================================================================
    def execute(self, sql, params=()):
        """执行 SQLite 写操作（INSERT/UPDATE/DELETE/DDL）

        功能：
            在锁内执行一条 SQL 并立即 commit，返回受影响行数。
        参数：
            sql (str): SQL 语句，使用 ? 占位符（不要用 f-string 拼接，避免注入）
            params (tuple | list): 与占位符一一对应的参数，默认空元组
        返回：
            int: cursor.rowcount，即受影响行数；DDL 语句的 rowcount 通常为 -1 或 0。
        注意：
            写盘：立即 commit，写操作不可回滚。
            并发：全程持有 _sqlite_lock；异常：sqlite3.Error 不捕获，由调用方处理
            （例如唯一键冲突）。
        """
        with self._sqlite_lock:
            cursor = self._sqlite.execute(sql, params)
            self._sqlite.commit()
            return cursor.rowcount



    # ========================================================================
    # SQLite：历史开奖数据镜像（JSON 为主，数据库兜底）
    # ========================================================================
    def save_history(self, records):
        """整体覆盖写入历史开奖数据镜像

        功能：
            先把记录规整为 (period, date, numbers, special)，再整体覆盖写入
            history_records 表。
        参数：
            records (list[dict]): 每项含 period / date / numbers / special
        返回：
            int: 实际写入条数（跳过脏数据后的有效行数）

        注意：
            写盘：先 DELETE 全表再批量插入（整体覆盖语义），与 JSON 主存储保持同步。
            边界：跳过缺少合法 period/special 的记录，避免脏数据阻断整批写入；
            numbers 以 JSON 字符串存储。
        """
        rows = []
        for r in records:
            try:
                rows.append((
                    int(r.get('period')),
                    str(r.get('date', '')),
                    json.dumps(r.get('numbers', []), ensure_ascii=False),
                    int(r.get('special', 0)),
                ))
            except (TypeError, ValueError):
                continue  # 跳过缺少期号/特别码的脏数据，不影响其余记录入库
        with self._sqlite_lock:
            self._sqlite.execute('DELETE FROM history_records')
            self._sqlite.executemany(
                'INSERT OR REPLACE INTO history_records(period, date, numbers, special) '
                'VALUES(?, ?, ?, ?)', rows)
            self._sqlite.commit()
        return len(rows)

    def load_history(self):
        """读取历史开奖数据镜像

        功能：
            读取 history_records 全部行，按期号倒序还原为记录列表。
        参数：
            无。
        返回：
            list[dict]: 结构与 彩票数据.json 完全一致，可直接赋给 historical_data；
                排列为按期号倒序（最新一期在最前），与主窗口 insert(0, ...) 的习惯一致
        注意：
            只读：在锁内 SELECT，不写库、不 commit；单行 numbers 的 JSON 解析失败时
            退化为空列表 []，不抛出异常。
        """
        with self._sqlite_lock:
            rows = self._sqlite.execute(
                'SELECT period, date, numbers, special FROM history_records '
                'ORDER BY period DESC').fetchall()
        result = []
        for r in rows:
            try:
                numbers = json.loads(r['numbers'])
            except (TypeError, ValueError):
                numbers = []
            result.append({
                'period': int(r['period']),
                'date': r['date'] or '',
                'numbers': numbers,
                'special': int(r['special']),
            })
        return result

    # ========================================================================
    # SQLite：数据存储索引（[15] 数据存储）
    # ========================================================================
    def save_storage_items(self, items, tags=None):
        """整体覆盖写入数据存储索引镜像

        功能：
            把数据存储索引（index.json 的 items 元数据）镜像写入 storage_items 表；
            写前先与现有行逐字段比对，内容一致则直接返回、不写库。

        说明：数据库只存元数据（标题/标签/路径/时间/大小），图片与文档本体仍在磁盘；
              作用是 index.json 丢失或损坏时能恢复存储列表。

        写前比对（为什么加这道闸门）：
            旧实现无论内容是否变化都先 DELETE 全表再批量 INSERT，于是「空表→空表」
            也会产生 WAL 帧、改写 -wal/-shm。启动链路每次都会走到这里（见
            TAB/data_storage.py 的 sync_storage_files），但绝大多数启动并没有任何
            存储项变化，属于纯浪费 I/O。现在先读出表中现有行，与待写入行逐字段
            比较：完全一致就直接返回、不执行 DELETE；确有增删改时仍走原来的
            整体覆盖写入，行为不变。

        参数：
            items (list[dict]): 每项含 id/type/title/content/file_path/tags/created_at/updated_at/size
            tags (list[str] | None):  额外标签列表（index.json 顶层 tags，可为 None）
        返回：
            int: 待写入条数（内容一致未实际写库时同样返回该条数）
        注意：
            写盘：确有增删改时先 DELETE 全表再批量 INSERT 并 commit；内容一致时
            不写库、不 commit；全程持有 _sqlite_lock。
            边界：跳过 id 为空或字段异常的条目，不影响其余索引入库。
        """
        rows = []
        for it in items:
            try:
                item_id = str(it.get('id', '')).strip()
                if not item_id:
                    continue
                rows.append((
                    item_id,
                    str(it.get('type', '')),
                    str(it.get('title', '')),
                    str(it.get('content', '') or ''),
                    str(it.get('file_path', '') or ''),
                    json.dumps(list(it.get('tags', []) or []), ensure_ascii=False),
                    str(it.get('created_at', '') or ''),
                    str(it.get('updated_at', '') or ''),
                    int(it.get('size', 0) or 0),
                ))
            except (TypeError, ValueError):
                continue  # 跳过字段异常的条目，不影响其余索引入库
        with self._sqlite_lock:
            # 以 id 为键建立「现有行 / 待写行」映射（去掉主键列后比较其余 8 个字段）；
            # 重复 id 时后写覆盖，与下方 INSERT OR REPLACE 的实际落库语义一致。
            existing = self._sqlite.execute(
                'SELECT id, type, title, content, file_path, tags, created_at, updated_at, size '
                'FROM storage_items').fetchall()
            existing_map = {r['id']: tuple(r)[1:] for r in existing}
            incoming_map = {}
            for r in rows:
                incoming_map[r[0]] = r[1:]
            if existing_map == incoming_map:
                # 内容完全一致：不 DELETE、不 commit，避免产生无意义的 WAL 帧
                return len(rows)
            self._sqlite.execute('DELETE FROM storage_items')
            if rows:
                self._sqlite.executemany(
                    'INSERT OR REPLACE INTO storage_items'
                    '(id, type, title, content, file_path, tags, created_at, updated_at, size) '
                    'VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)', rows)
            self._sqlite.commit()
        return len(rows)

    def load_storage_items(self):
        """读取数据存储索引镜像

        功能：
            读取 storage_items 全部行，反序列化 tags，按 created_at 降序组装 items。
        参数：
            无。
        返回：
            (items, tags): items 为 list[dict]（结构同 index.json 的 items）；
                tags 为全部标签集合 list[str]（去重并排序）
        注意：
            只读：在锁内 SELECT，不写库；单行 tags 解析失败或非 list 时退化为空列表。
        """
        with self._sqlite_lock:
            rows = self._sqlite.execute(
                'SELECT id, type, title, content, file_path, tags, created_at, updated_at, size '
                'FROM storage_items ORDER BY created_at DESC').fetchall()
        items = []
        tags = set()
        for r in rows:
            try:
                tag_list = json.loads(r['tags']) if r['tags'] else []
            except (TypeError, ValueError):
                tag_list = []
            if not isinstance(tag_list, list):
                tag_list = []
            items.append({
                'id': r['id'],
                'type': r['type'] or '',
                'title': r['title'] or '',
                'content': r['content'] or '',
                'file_path': r['file_path'] or '',
                'tags': tag_list,
                'created_at': r['created_at'] or '',
                'updated_at': r['updated_at'] or '',
                'size': int(r['size'] or 0),
            })
            tags.update(str(t) for t in tag_list)
        return items, sorted(tags)


    def _get_duckdb(self):
        """获取DuckDB连接（懒加载，首次调用时导入duckdb并连接）

        功能：
            首次调用时在锁内导入 duckdb、打开 analysis.duckdb 并缓存连接；
            后续调用直接返回同一连接对象。
        参数：
            无。
        返回：
            duckdb.DuckDBPyConnection: 进程内共享的同一连接对象。
        注意：
            副作用：首次调用导入 duckdb 模块并创建/打开 analysis.duckdb 文件；
            后续调用直接返回缓存连接。
            异常：ImportError 在 duckdb 未安装时向外抛出（调用方需自行降级）。
            并发：连接创建与缓存读取都在 _duckdb_lock 内完成，避免并发首调
            各自建立连接（后建立的会覆盖前者，造成连接泄漏/文件锁冲突）。
        """
        with self._duckdb_lock:
            if self._duckdb_conn is not None:
                return self._duckdb_conn
            import duckdb  # 作用说明：DuckDB 分析引擎按需导入（首次获取连接时才加载重型库）
            self._duckdb_conn = duckdb.connect(str(self._duckdb_path))
            return self._duckdb_conn

    # 预留：DuckDB 分析查询入口（当前未接界面）
    def query_analysis(self, sql, params=None):
        """执行DuckDB分析查询

        功能：
            在共享 DuckDB 连接上执行分析型 SQL，并把结果转换为 DataFrame。
        参数：
            sql (str): 分析型 SQL（可直接查询 CSV/Parquet，如
                "SELECT * FROM 'data.csv'" 或 read_parquet('x.parquet')）
            params (list | None): 可选参数列表，按 ? 占位符顺序绑定
        返回：
            pandas.DataFrame: DuckDB 结果的 DataFrame 视图（.df() 内部会导入 pandas）
        注意：
            异常：ImportError 在 duckdb 或 pandas 缺失时抛出。
            并发：查询与 sync_history_to_duckdb 等写操作共用同一连接，
            通过 _duckdb_lock 串行化，避免 execute 互相干扰。
        """
        conn = self._get_duckdb()
        with self._duckdb_lock:
            result = conn.execute(sql, params) if params else conn.execute(sql)
            return result.df()

    # ========================================================================
    # DuckDB：历史明细分析表（[16] 大数据分析的数据源）
    # ========================================================================
    def _init_duckdb_tables(self):
        """创建DuckDB分析表（不存在时才创建）

        功能：
            在 DuckDB 中创建 history_detail 明细表（IF NOT EXISTS，可重复调用）。
        表说明：
            history_detail: 历史开奖明细，每期每个号码一行，便于按号码聚合、
                            按窗口切片、做频率/遗漏等分析型查询
                            （period, date, seq, number, is_special）
        参数：
            无。
        返回：
            无。
        注意：
            副作用：在 DuckDB 中建表。
            并发：建表与并发写操作共用同一连接，通过 _duckdb_lock 串行化，
            避免 DuckDB 单连接上的事务冲突。
        """
        conn = self._get_duckdb()
        with self._duckdb_lock:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS history_detail (
                    period     INTEGER,
                    date       TEXT,
                    seq        INTEGER,
                    number     INTEGER,
                    is_special INTEGER
                )
            ''')

    def sync_history_to_duckdb(self, records):
        """把历史开奖数据整体覆盖写入 DuckDB 分析表

        功能：
            把每期数据展开为明细行（每个正码一行、特别码一行），先清空
            history_detail 再批量插入。
        说明：SQLite 的 history_records 是业务主存储（按 period 一行的 JSON），
              DuckDB 这里展开成明细行，只服务于统计/分析类查询，不做业务回写。

        参数：
            records (list[dict]): 每项含 period / date / numbers / special
        返回：
            int: 实际写入的明细行数（每期 6 个正码 + 1 个特别码）
        注意：
            写盘：先 DELETE 全表再批量插入；缺少期号的记录会被跳过。
            并发：写入在共享连接上执行，通过 _duckdb_lock 串行化。
        """
        conn = self._get_duckdb()
        self._init_duckdb_tables()

        rows = []
        for rec in records:
            try:
                period = int(rec.get('period'))
            except (TypeError, ValueError):
                continue  # 缺少期号的脏数据跳过，不影响其余记录
            date_text = str(rec.get('date', ''))
            numbers = list(rec.get('numbers', []) or [])
            try:
                special = int(rec.get('special', 0) or 0)
            except (TypeError, ValueError):
                special = 0
            for seq, num in enumerate(numbers):
                try:
                    # seq 记录号码在该期正码列表中的原始位置（0~5），供还原时排序
                    rows.append((period, date_text, seq, int(num), 0))
                except (TypeError, ValueError):
                    continue
            # special 为 0 视为“无特别码”（数据缺失），此时不插入特别码明细行；
            # seq 取 len(numbers)，保证特别码在 (is_special, seq) 排序中排在正码之后
            if special:
                rows.append((period, date_text, len(numbers), special, 1))

        with self._duckdb_lock:
            conn.execute('DELETE FROM history_detail')
            if rows:
                conn.executemany(
                    'INSERT INTO history_detail(period, date, seq, number, is_special) '
                    'VALUES(?, ?, ?, ?, ?)', rows)
        return len(rows)

    def load_history_for_analysis(self, window=None):
        """从 DuckDB 读取最近 window 期历史记录（供大数据分析使用）

        功能：
            按 window 取最近 N 期（None 或 <=0 取全部）的明细行，再重新组装成
            一期一行的记录结构。
        参数：
            window (int | None): 取最近多少期；None 或 <=0 表示全部
        返回：
            list[dict]: 结构与 彩票数据.json 一致，按期号倒序（最新在前）
        注意：
            只读：不写库；window 无法转 int 时按全部处理；
            边界：LIMIT 作用于去重后的期号子查询，避免只取到最后一期的部分号码。
        """
        conn = self._get_duckdb()
        self._init_duckdb_tables()

        limit_sql = ''
        try:
            window_int = int(window)
            if window_int > 0:
                # LIMIT 必须作用在“去重后的期号列表”子查询上（按 period 降序取最近 N 期），
                # 若放到外层会变成限制明细行数，导致最后一期只取到部分号码
                limit_sql = ' LIMIT %d' % window_int
        except (TypeError, ValueError):
            pass
        # 外层 is_special 升序：0（正码）在前、1（特别码）在后；同组内按 seq 还原原始顺序
        sql = ('SELECT period, date, seq, number, is_special FROM history_detail '
               'WHERE period IN (SELECT DISTINCT period FROM history_detail '
               'ORDER BY period DESC%s) ORDER BY period DESC, is_special, seq' % limit_sql)

        with self._duckdb_lock:
            rows = conn.execute(sql).fetchall()

        # 把明细行重新组装成「一期一行」的记录结构
        result = []
        current = None
        for period, date_text, _seq, number, is_special in rows:
            period_int = int(period)
            if current is None or current['period'] != period_int:
                current = {'period': period_int, 'date': date_text or '',
                           'numbers': [], 'special': 0}
                result.append(current)
            if int(is_special) == 0:
                current['numbers'].append(int(number))
            else:
                current['special'] = int(number)

        # 正码按 seq 已有序，这里再按号码升序兜底（与 JSON 数据习惯一致）
        for rec in result:
            rec['numbers'].sort()
        return result





    # ========================================================================
    # DuckDB：CSV / Parquet 直读（[1] 数据导入）
    # ========================================================================
    def read_table_file(self, path):
        """用 DuckDB 直接读取 CSV / Parquet，转换成历史记录结构

        功能：
            按扩展名选择 read_parquet / read_csv_auto 直接在 DuckDB 中读取文件，
            取列名与全部行后交给 _records_from_table 转换。
        参数：
            path (str | Path): .csv 或 .parquet 文件绝对路径
        返回：
            list[dict]: 结构同 load_history（period/date/numbers/special）
        注意：
            只读文件，不写库；扩展名不是 .csv/.parquet 时抛出 ValueError；
            路径中的单引号会被转义后拼入 SQL。
        说明：
            列名兼容三种写法：
            1) numbers 列（正码用空格/逗号/顿号分隔） + special 列
            2) n1..n6 / num1..num6 / 号码1..号码6 六列 + special
            3) 无匹配列名时按位置取前 9 列（期号、日期、6 正码、特码）
        """
        lower = str(path).lower()
        if lower.endswith('.parquet'):
            sql = "SELECT * FROM read_parquet('%s')" % str(path).replace("'", "''")
        elif lower.endswith('.csv'):
            sql = ("SELECT * FROM read_csv_auto('%s', sample_size=-1)"
                   % str(path).replace("'", "''"))
        else:
            raise ValueError('DuckDB 直读仅支持 .csv / .parquet 文件')

        conn = self._get_duckdb()
        with self._duckdb_lock:
            result = conn.execute(sql)
            # description 是 (name, type_code, ...) 元组序列，只取第一项作为列名
            columns = [str(d[0]) for d in result.description]
            rows = result.fetchall()
        # 列名解析放在锁外：纯 Python 处理，不占用数据库连接
        return _records_from_table(columns, rows)

    # ========================================================================
    # 资源释放
    # ========================================================================
    def close(self):
        """关闭全部数据库连接（程序退出时调用）

        功能：
            关闭 DuckDB 与 SQLite 连接，并把 _duckdb_conn 置空。
        参数：
            无。
        返回：
            无。
        注意：
            副作用：关闭连接；关闭过程中的异常全部被吞掉（DuckDB 可能仍被查询中
            的线程使用），重复调用是安全的（内部判空 + 异常保护）。
            关闭后本实例不可再使用；get_db() 的全局单例仍指向已关闭实例，
            因此只能在程序退出阶段调用。
        """
        try:
            if self._duckdb_conn is not None:
                self._duckdb_conn.close()
                self._duckdb_conn = None
        except Exception:
            pass
        try:
            with self._sqlite_lock:
                self._sqlite.close()
        except Exception:
            pass


# ============================================================================
# CSV / Parquet 列名 → 历史记录结构（供 DBHelper.read_table_file 使用）
# ============================================================================
def _index_of(columns, candidates):
    """在列名中查找候选名（不区分大小写）

    功能：
        按候选名优先级在列名列表中查找，返回第一个命中的下标。
    参数：
        columns (list): 原始列名序列
        candidates (tuple): 候选列名，按优先级排列（前面的优先命中）
    返回：
        int: 命中的列下标；全部未命中返回 -1。
    注意：
        无副作用；比较前先 strip() 并转小写，规避 CSV 表头带空格、大小写不一致。
    """
    lowered = [str(c).strip().lower() for c in columns]
    for name in candidates:
        if name.lower() in lowered:
            return lowered.index(name.lower())
    return -1


def _records_from_table(columns, rows):
    """把 DuckDB 查询结果（列名 + 行）转换为历史记录列表

    功能：
        先按列名识别期号/日期/正码/特别码的位置，再逐行解析并组装成记录字典。
    参数：
        columns (list[str]): 列名
        rows (list[tuple]): 查询返回的原始行
    返回：
        list[dict]: 每项 {period, date, numbers(6 个), special}；
            有效正码不足 6 个或无法解析的行会被跳过。
    注意：
        无副作用（纯内存转换）；列名识别优先级：六列式（n1..n6 等）>
        numbers 单列 > 按位置取前 9 列；
        号码统一由 DataUtils.parse_numbers_text(dedupe=True, limit_range=True,
        normalize_text=False) 解析（数据库字段不解码 HTML、不做 NFKC）；
        特别码缺失时记 0，日期缺失时为空字符串。
    """
    p_idx = _index_of(columns, ('period', '期号', '期数', 'issue', 'draw'))
    d_idx = _index_of(columns, ('date', '日期', '开奖日期', 'draw_date'))
    s_idx = _index_of(columns, ('special', '特别码', '特码', '特别号码', 'special_number'))
    n_idx = _index_of(columns, ('numbers', '号码', '正码', '开奖号码', 'draw_numbers'))

    # 六列式布局：n1..n6 / num1..num6 / 号码1..号码6 / 正码1..正码6
    seq_idx = []
    for prefix in ('n', 'num', '号码', '正码'):
        found = [_index_of(columns, (prefix + str(i),)) for i in range(1, 7)]
        if all(i >= 0 for i in found):
            seq_idx = found
            break

    records = []
    for row in rows:
        try:
            period = int(row[p_idx]) if p_idx >= 0 else int(row[0])
            if d_idx >= 0:
                date_text = str(row[d_idx])
            else:
                date_text = str(row[1]) if len(row) > 1 else ''
            if seq_idx:
                nums = DataUtils.parse_numbers_text(
                    [row[i] for i in seq_idx],
                    dedupe=True, limit_range=True, normalize_text=False)
            elif n_idx >= 0:
                nums = DataUtils.parse_numbers_text(
                    row[n_idx],
                    dedupe=True, limit_range=True, normalize_text=False)
            else:
                nums = DataUtils.parse_numbers_text(
                    [row[i] for i in range(2, 8)],
                    dedupe=True, limit_range=True, normalize_text=False)
            if s_idx >= 0:
                special = int(float(row[s_idx]))
            elif len(row) >= 9:
                special = int(float(row[8]))
            else:
                special = 0
        except (TypeError, ValueError, IndexError):
            continue  # 跳过无法解析的行
        if len(nums) < 6:
            continue
        records.append({
            'period': period,
            'date': date_text,
            'numbers': nums[:6],
            'special': special,
        })
    return records


# ============================================================================
# 全局唯一实例（单例）
# ============================================================================
_db_instance = None
_db_instance_lock = threading.Lock()


def get_db():
    """获取全局唯一的数据库封装实例（双重检查锁单例）

    功能：
        返回进程级唯一的 DBHelper，首次调用时创建实例并完成建表。
    参数：
        无。
    返回：
        DBHelper: 进程级唯一实例，首次调用时创建并完成建表。
    注意：
        并发：第一次判空为无锁快速路径（绝大多数调用），仅首次创建时进入
        _db_instance_lock 并在锁内二次判空，避免重复初始化数据库连接。
        异常：目录不可写或建表失败时，DBHelper() 抛出的异常会原样传出。
    """
    global _db_instance
    if _db_instance is None:
        with _db_instance_lock:
            if _db_instance is None:
                _db_instance = DBHelper()
    return _db_instance
