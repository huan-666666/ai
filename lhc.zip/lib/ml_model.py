# -*- coding: utf-8 -*-
"""
===========================================================================
lib/ml_model.py - sklearn、statsmodels、optuna、torch：机器学习建模
===========================================================================
模块职责：
    把历史开奖数据转换为监督学习样本，训练 4 类分类器
    （随机森林 / 梯度提升 / 逻辑回归 / MLP），并把每个模型的
    输出概率按算术平均聚合成 1~49 的号码得分，取 Top-6 作为预测号码。

在架构中的位置：
    位于 lib/ 纯逻辑层，被 plugins/ 的「Scikit-learn 集成算法」等插件调用；
    训练特征依赖 lib.data_process.LotteryConfig 的颜色常量，
    模型文件路径依赖 lib.db_helper.BASE_DIR，保证 exe 打包后仍写在程序目录下。

依赖：
    numpy 为模块级导入；sklearn 通过 lib 的懒加载器 _get_sklearn() 按需加载；
    torch/optuna/statsmodels 由其它算法模块自行懒加载，本模块不使用。

包含类：
    MLPredictionModel:    机器学习预测模型（多模型训练/评估/预测）

约束：禁止任何 Qt 界面代码；torch/optuna 等经懒加载器或函数内按需导入。
===========================================================================
"""

import json  # 作用说明：序列化历史数据生成一致性指纹（json.dumps）
import os  # 作用说明：拼接模型文件路径、创建存放目录、判断文件是否存在并读取体积
import pickle  # 作用说明：模型对象序列化到 ml_models.pkl，供下次启动直接加载复用
import datetime  # 作用说明：在模型文件里记录保存时间戳（timestamp 字段）
import warnings  # 作用说明：过滤 FutureWarning/DeprecationWarning，避免 sklearn 版本告警刷屏

warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)

import lib as _core  # 作用说明：懒加载核心：从 _core 取用 _RandomForestClassifier 等重型 sklearn 类与状态全局变量
from lib import _get_sklearn  # 作用说明：懒加载 sklearn 组件，训练/预测前先触发一次导入

import numpy as np  # 作用说明：构造特征/标签矩阵，累计 49 维概率向量并用 argsort 取 Top-6

from lib.data_process import LotteryConfig  # 作用说明：读取红波/蓝波号码常量，用于构造窗口统计特征
from lib.db_helper import BASE_DIR as _APP_BASE_DIR  # 作用说明：程序基准目录（兼容exe打包），用于定位「系统v7.5」模型存放目录


# ==========================================================================
# 机器学习预测模型
# ==========================================================================


class MLPredictionModel:
    """机器学习预测模型 - v7.5增强版

    职责：
        以“10 期滑动窗口 × 每期 58 维特征 = 580 维”为输入，
        对 1~49 每个号码分别训练一个二分类器（该号码是否在本期出现），
        再用各模型的 P(出现) 求平均，作为号码排序得分。

    关键属性：
        data (list[dict])       —— 历史开奖记录，调用方保证 data[0] 是最新一期
        _model_file (str)       —— 模型 pickle 路径（ml_models.pkl）
        _training_data_file(str)—— 训练数据 JSON 路径（当前仅保留路径，不再写入，见 save 流程注释）

    模型持久化：训练后的模型保存到 ml_models.pkl，下次预测时优先加载缓存，
    文件存在直接使用，仅在文件不存在时重新训练，大幅提升预测速度。

    生命周期/线程约束：
        无实例级锁，也无线程池；训练为同步阻塞操作（可能持续数十秒），
        UI 层应放到后台线程调用并配合 progress_callback 更新进度。
        模型文件读写无并发保护，同一进程内不要用多个实例同时训练。
    """
    
    # 模型与训练数据默认存放在「程序目录/系统v7.5」下（exe打包后随程序目录走）
    _DEFAULT_DATA_DIR = str(_APP_BASE_DIR / "系统v7.5")
    MODEL_FILE = os.path.join(_DEFAULT_DATA_DIR, "ml_models.pkl")
    TRAINING_DATA_FILE = os.path.join(_DEFAULT_DATA_DIR, "training_data.json")  # 训练数据存储文件
    
    def __init__(self, historical_data, base_dir=None):
        """初始化

        功能：
            保存历史数据的引用，并按 base_dir 决定模型与训练数据的落盘位置：
            传入 base_dir 时拼成绝对路径，否则沿用类常量 MODEL_FILE / TRAINING_DATA_FILE。

        参数:
            historical_data (list[dict]): 历史开奖记录，约定 data[0] 为最新一期
                （主窗口用 insert(0, record) 维护该顺序）。
            base_dir (str | None): 可选的基础目录。提供时模型文件写入该目录，
                用于避免工作目录变化导致找不到模型文件；None 时使用类默认路径。

        返回:
            None: 构造函数不返回数值，只完成 self.data / _model_file / _training_data_file 的赋值。

        注意：
            不读写文件，仅确定模型/训练数据路径；self.data 保存的是调用方列表的
            引用而非副本，外部增删记录会直接反映到本实例。
        """
        self.data = historical_data
        # 【修复】如果提供了base_dir，使用绝对路径确保模型文件能被正确找到
        # 预留：_training_data_file 为训练数据 JSON 路径，当前仅保留路径、不写入
        if base_dir:
            import os  # 作用说明：用 os.path.join 把外部 base_dir 拼成模型与训练数据的绝对路径
            self._model_file = os.path.join(base_dir, "ml_models.pkl")
            self._training_data_file = os.path.join(base_dir, "training_data.json")
        else:
            self._model_file = self.MODEL_FILE
            self._training_data_file = self.TRAINING_DATA_FILE
    
    def _get_data_fingerprint(self):
        """计算当前数据的指纹（用于判断数据是否变化）

        功能：
            用 json.dumps（sort_keys=True、ensure_ascii=False，非标准类型交给
            _json_default_handler）序列化全部历史数据，取 MD5 十六进制摘要作为指纹。

        参数：无。

        返回:
            str | None: 全部历史数据序列化后的 MD5 十六进制串；
                序列化失败时返回 None（不中断保存流程）。

        【Bug修复】使用全部数据（与主窗口 _compute_data_fingerprint 一致），
        确保两处指纹可互相验证。之前只取前100条导致数据超100条时指纹不一致。

        注意：
            序列化/哈希过程中的任何异常都在本函数内捕获，仅打印堆栈并返回 None；
            本方法不写盘。指纹由 save_models 写入 pickle，load_models 加载时会
            把它与当前数据指纹比对，不一致即放弃旧模型。
        """
        import hashlib  # 作用说明：对序列化后的历史数据取 MD5 摘要，作为数据指纹
        try:
            # 【Bug修复】使用全部数据（与 MainWindow._compute_data_fingerprint 一致）
            data_str = json.dumps(self.data, sort_keys=True, ensure_ascii=False, 
                                  default=self._json_default_handler)
            return hashlib.md5(data_str.encode('utf-8')).hexdigest()
        except Exception as e:
            # 【Bug修复】打印异常信息，便于排查指纹计算失败原因
            import traceback  # 作用说明：指纹计算失败时打印异常堆栈，便于排查序列化问题
            print(f"[MLPredictionModel] 数据指纹计算失败: {e}")
            traceback.print_exc()
            return None
    
    @staticmethod
    def _json_default_handler(obj):
        """JSON序列化默认处理器 - 处理numpy等非标准类型（全项目唯一实现，主窗口与本模块均引用此处）

        功能：
            作为 json.dumps 的 default 回调，把 numpy 整数/浮点/数组分别转成
            int/float/list，其余无法识别的对象统一转成字符串，保证序列化不中断。

        参数:
            obj: json.dumps 无法直接序列化的对象
        返回:
            int | float | list | str: numpy 标量/数组转为 Python 原生类型，
                其它对象回退为 str(obj)，保证 json.dumps 不会因类型问题失败。
        注意：
            函数内 import numpy 失败（ImportError）时跳过 numpy 分支，直接走 str 回退；
            只保证 json.dumps 不抛异常，不保证能还原原对象的类型。
        """
        try:
            import numpy as np  # 作用说明：识别 numpy 整数/浮点/数组并转成 Python 原生类型
            if isinstance(obj, (np.integer,)):
                return int(obj)
            if isinstance(obj, (np.floating,)):
                return float(obj)
            if isinstance(obj, (np.ndarray,)):
                return obj.tolist()
        except ImportError:
            pass
        # 回退到字符串表示
        return str(obj)
    
    def save_models(self, rf_models, rf_scaler, gb_models, gb_scaler,
                    lr_models, lr_scaler, mlp_models, mlp_scaler,
                    X=None, y=None, X_latest=None):
        """将所有训练好的模型和训练数据保存到单个pickle文件

        功能：
            把 4 组模型字典与对应 scaler、训练矩阵 X/y、最新特征 X_latest、
            数据指纹与时间戳打包成 dict，以 pickle 最高协议覆盖写入 self._model_file。
        
        参数:
            rf_models/gb_models/lr_models/mlp_models: 训练好的模型字典
            rf_scaler/gb_scaler/lr_scaler/mlp_scaler: 对应的scaler
            X: 训练特征矩阵 (numpy.ndarray, 可选)
            y: 训练标签矩阵 (numpy.ndarray, 可选)
            X_latest: 最新一期特征 (numpy.ndarray, 可选)

        返回:
            bool: 写入成功返回 True；任何异常（权限、磁盘空间、pickle 失败）
                被捕获后返回 False，并打印堆栈。

        注意：
            创建目标目录并以 pickle 最高协议覆盖写 ml_models.pkl；
            文件体积约数 MB（默认 X/y 也会被一起序列化）。
            指纹计算失败时仍继续保存（fingerprint 记为 None），不阻断落盘。
        """
        try:
            import os  # 作用说明：拼接模型保存路径、创建目录并读取落盘后的文件体积
            model_file = self._model_file
            save_dir = os.path.dirname(model_file)
            if save_dir:
                os.makedirs(save_dir, exist_ok=True)
            # 【修复】先计算指纹，排除指纹计算失败的影响
            fp = self._get_data_fingerprint()
            if fp is None:
                print(f"[MLPredictionModel] 警告：数据指纹计算失败，仍将保存模型（指纹为None）")
            data = {
                'fingerprint': fp,
                'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'data_count': len(self.data),  # 训练数据条数
                'rf_models': rf_models,
                'rf_scaler': rf_scaler,
                'gb_models': gb_models,
                'gb_scaler': gb_scaler,
                'lr_models': lr_models,
                'lr_scaler': lr_scaler,
                'mlp_models': mlp_models,
                'mlp_scaler': mlp_scaler,
                'X': X,           # 训练特征矩阵
                'y': y,           # 训练标签矩阵
                'X_latest': X_latest,  # 最新预测特征
            }
            with open(model_file, 'wb') as f:
                pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)
            file_size = os.path.getsize(model_file)
            print(f"[MLPredictionModel] 模型已保存: {model_file} ({file_size/1024:.1f} KB, {len(self.data)}条数据, 指纹={fp})")
            return True
        except Exception as e:
            import traceback  # 作用说明：保存失败时打印异常堆栈，便于排查权限/磁盘问题
            print(f"[MLPredictionModel] 保存模型失败: {e}")
            traceback.print_exc()
            return False
    
    
    def _get_feature_names(self):
        """获取特征名称列表（10期窗口 × 每期58个特征 = 580维）

        功能：
            按「期1~期10 ×（49 个号码名 + 9 个统计特征名）」的顺序生成 580 个名称，
            与 _extract_window_features 的输出位置逐位对应。

        参数：无。

        返回:
            list[str]: 580 个特征名，按窗口期次（期1~期10）顺序排列。
        注意：
            纯字符串拼接，不读数据、不写盘，无副作用；特征名与
            _extract_window_features 的输出顺序、以及 580 这一维度常量需人工保持同步。

        说明:
            每期 58 维 = 49 维号码 one-hot + 9 维统计特征
            （平均值/最大值/最小值/单数个数/大号个数/跨度/红波数/蓝波数/尾数种类）。
            本方法仅用于输出可读的特征清单，实际训练直接用数值矩阵，
            因此特征增删必须同步修改 _extract_window_features 与 580 这一常量。
        """
        names = []
        for period in range(10):
            p = period + 1
            # 49个one-hot编码
            for num in range(1, 50):
                names.append(f"期{p}_号码{num}")
            # 统计特征
            names.append(f"期{p}_平均值")
            names.append(f"期{p}_最大值")
            names.append(f"期{p}_最小值")
            names.append(f"期{p}_单数个数")
            names.append(f"期{p}_大号个数")
            names.append(f"期{p}_跨度")
            names.append(f"期{p}_红波数")
            names.append(f"期{p}_蓝波数")
            names.append(f"期{p}_尾数种类")
        return names
    
    def load_models(self):
        """从pickle文件加载训练好的模型和训练数据

        功能：
            从 self._model_file 反序列化 4 组模型/缩放器及 X、y、X_latest；
            文件不存在直接返回 None；文件内带指纹且与当前数据指纹不一致时
            同样返回 None，调用方据此转为重新训练。

        参数：无。
        
        【v7.5简化】文件存在就直接加载使用；只有文件内指纹与当前数据不一致时，
        才放弃旧模型并返回 None 触发重新训练。
        
        返回:
            文件存在时返回 (rf_models, rf_scaler, gb_models, gb_scaler,
                        lr_models, lr_scaler, mlp_models, mlp_scaler,
                        X, y, X_latest)
            文件不存在、指纹不一致或加载失败时返回 None

        注意：
            从磁盘反序列化 pickle（会执行文件中的对象构造），文件损坏或版本
            不兼容时捕获异常并返回 None，让调用方回退到重新训练。
            读取失败只打印堆栈，不向调用方抛出异常。
        说明:
            文件内带 fingerprint 时会与当前数据指纹比对；不一致说明历史数据
            已更新，返回 None 触发重新训练，避免复用与最新数据脱节的旧模型。
        """
        try:
            import os  # 作用说明：拼接模型文件路径并判断该文件是否存在
            model_file = self._model_file
            if not os.path.exists(model_file):
                print(f"[MLPredictionModel] 模型文件不存在，将进行训练: {model_file}")
                return None
            
            with open(model_file, 'rb') as f:
                data = pickle.load(f)
            
            saved_fp = data.get('fingerprint')
            current_fp = self._get_data_fingerprint()
            if saved_fp and current_fp and saved_fp != current_fp:
                print("[MLPredictionModel] 数据指纹已变化，放弃旧模型并重新训练: "
                      f"文件={str(saved_fp)[:8]} 当前={current_fp[:8]}")
                return None
            
            saved_count = data.get('data_count', '?')
            saved_time = data.get('timestamp', '?')
            
            print(f"[MLPredictionModel] 模型文件已存在，直接加载使用（跳过训练）: "
                  f"保存时数据={saved_count}条, 保存时间={saved_time}")
            
            return (data['rf_models'], data['rf_scaler'],
                    data['gb_models'], data['gb_scaler'],
                    data['lr_models'], data['lr_scaler'],
                    data['mlp_models'], data['mlp_scaler'],
                    data.get('X'), data.get('y'), data.get('X_latest'))
        except Exception as e:
            import traceback  # 作用说明：加载失败时打印异常堆栈，便于排查文件损坏/版本不兼容
            print(f"[MLPredictionModel] 加载模型失败: {e}")
            traceback.print_exc()
            return None
    
    def _extract_window_features(self, record):
        """从单条记录中提取 58 维窗口特征

        功能：
            把单期 6 个正码展开成 49 维 one-hot，再追加平均值/最大值/最小值/
            单数个数/大号个数/跨度/红波数/蓝波数/尾数种类 共 9 维统计特征。

        参数:
            record (dict): 单期记录，读取 numbers（6 个正码）
        返回:
            list: 长度恰为 58 的数值列表 = 49 维 one-hot + 9 维统计特征。
        注意：
            只读入参，不修改 record；不在 1~49 范围内的号码不计入 one-hot；
            空记录时 9 维统计特征填固定兜底值，保证长度恒为 58。

        说明:
            numbers 为空时填固定兜底值 [25, 49, 1, 3, 3, 48, 2, 2, 5]，
            保持维度一致，避免训练矩阵列数错位；
            平均值按固定 6 个号码计算（sum/6），而不是 sum/len(numbers)。
        """
        numbers = record.get('numbers', [])
        features = []
        # one-hot编码
        one_hot = [0] * 49
        for n in numbers:
            if 1 <= n <= 49:
                one_hot[n - 1] = 1
        features.extend(one_hot)
        # 统计特征
        if numbers:
            # 以下 9 个统计特征与 _get_feature_names 的 9 个名字一一对应，顺序不可调换
            features.append(sum(numbers) / 6)  # 平均值（固定除以 6，与「6 个正码」的业务口径一致）
            features.append(max(numbers))  # 最大值
            features.append(min(numbers))  # 最小值
            features.append(sum(n % 2 for n in numbers))  # 单数个数（n%2 为 1 表示奇数）
            features.append(sum(1 for n in numbers if n > 25))  # 大号个数（>25 为大，与 LotteryConfig.is_big 一致）
            features.append(max(numbers) - min(numbers))  # 跨度（极差，反映号码分散程度）
            # 颜色分布
            red_c = sum(1 for n in numbers if n in LotteryConfig.RED_NUMBERS)
            blue_c = sum(1 for n in numbers if n in LotteryConfig.BLUE_NUMBERS)
            features.append(red_c)
            features.append(blue_c)
            # 尾数分布
            tails = [n % 10 for n in numbers]
            features.append(len(set(tails)))  # 不同尾数个数
        else:
            # 空记录兜底：9 个特征取“典型值”（均值 25、最大 49、最小 1 等），
            # 目的是保证特征维度恒为 58，否则拼接窗口时各期长度不一致会建不出矩阵
            features.extend([25, 49, 1, 3, 3, 48, 2, 2, 5])
        return features
    
    def prepare_features(self):
        """【需求2-BUG修复】增强特征工程：10期滑动窗口 + 丰富统计特征

        功能：
            先把 self.data（约定 data[0] 为最新一期）反转为时间正序，再以第 i~i+9
            期共 10 期、每期 58 维的特征拼接为输入，用第 i+10 期的 6 个正码
            one-hot 作为标签，构造监督学习样本。
        参数：无。

        返回:
            (X, y): np.ndarray, np.ndarray
                X 形状 (n_samples, 580)，y 形状 (n_samples, 49) 的 0/1 标签；
                样本数 n_samples = 记录数 - 10（少于 20 条记录时返回两个空数组）。
        注意：
            只读 self.data，不修改也不排序原列表（用 reversed 得到新列表）；
            记录数少于 20 条时直接返回两个空数组，不产生任何样本；
            样本数 = 记录数 - 10，特征维度固定 580、标签维度固定 49。

        说明:
            用第 i~i+9 共 10 期特征预测第 i+10 期，标签是该期 6 个正码的 one-hot。
        """
        if len(self.data) < 20:
            return np.array([]), np.array([])
        
        # 【需求2-BUG修复】将数据反转，使data[0]为最旧，data[-1]为最新
        # 原始historical_data是insert(0, record)，所以data[0]是最新的
        # 需要反转使训练时用旧→新的顺序
        data_ordered = list(reversed(self.data))
        
        X = []
        y = []
        window_size = 10
        for i in range(len(data_ordered) - window_size):
            features = []
            for j in range(window_size):
                record = data_ordered[i + j]
                features.extend(self._extract_window_features(record))
            X.append(features)
            next_record = data_ordered[i + window_size]
            label = [0] * 49
            for n in next_record.get('numbers', []):
                if 1 <= n <= 49:
                    label[n - 1] = 1
            y.append(label)
        return np.array(X), np.array(y)
    
    def train_random_forest(self, X, y):
        """增强随机森林：100棵树 + 每数字独立分类

        功能：
            先用 StandardScaler 标准化 580 维特征，再对 1~49 每个号码各自训练
            一个 100 棵树、max_depth=10 的 RandomForestClassifier 二分类器；
            标签只有单一取值（从不出现或期期出现）的号码直接置 None 跳过。

        参数:
            X (np.ndarray): 特征矩阵 (n_samples, 580)
            y (np.ndarray): 标签矩阵 (n_samples, 49)
        返回:
            (dict[int, model|None], scaler|None): 键为号码下标 0~48；
                某个号码在训练集中从未出现/全部出现（标签只有一种取值）时
                该位置为 None；sklearn 不可用时返回 ({}, None)。
        注意：
            无文件写入；训练期间每 10 个号码调用一次 gc.collect() 回收中间对象。
            训练为同步阻塞，n_jobs=1 强制单线程以配合项目的 BLAS 单线程策略；
            sklearn 类不可用（_core 中为 None）时直接返回 ({}, None)。
        """
        _get_sklearn()
        RF = _core._RandomForestClassifier
        SS = _core._StandardScaler
        if RF is None or SS is None:
            return {}, None
        models = {}
        scaler = SS()
        X_scaled = scaler.fit_transform(X)
        import gc as _gc  # 作用说明：每训练 10 个号码回收一次中间对象，抑制内存增长
        for num_idx in range(49):
            y_num = y[:, num_idx]
            # 标签只有单一取值（该号码在训练集里从不出现或每期都出现）时，
            # 二分类器无正负样本可分，直接置 None 跳过，避免 sklearn 抛异常
            if len(set(y_num)) < 2:
                models[num_idx] = None
                continue
            # n_jobs=1 强制单线程：与 lib/__init__.py 的 BLAS 单线程策略一致，防栈溢出；
            # max_depth=10 限制树深，抑制样本量小（几百条）时的过拟合
            model = RF(
                n_estimators=100, max_depth=10, min_samples_split=5,
                min_samples_leaf=2, random_state=42, n_jobs=1
            )
            model.fit(X_scaled, y_num)
            models[num_idx] = model
            if num_idx % 10 == 0:
                _gc.collect()
        return models, scaler
    
    def train_gradient_boosting(self, X, y):
        """增强梯度提升：100轮 + 每数字独立分类

        功能：
            先用 StandardScaler 标准化特征，再对 1~49 每个号码各自训练一个
            100 轮、max_depth=4、learning_rate=0.1 的 GradientBoostingClassifier；
            标签单类的号码置 None 跳过。

        参数:
            X (np.ndarray): 特征矩阵 (n_samples, 580)
            y (np.ndarray): 标签矩阵 (n_samples, 49)
        返回:
            (dict[int, model|None], scaler|None): 结构与 train_random_forest 相同。
        注意：
            无文件写入；每训练 10 个号码 gc.collect() 一次；
            sklearn 类不可用时直接返回 ({}, None)；训练为同步阻塞。

        说明:
            GradientBoostingClassifier 不支持 n_jobs，故未传该参数；
            学习率 0.1 + 最大深度 4 是偏差-方差折中的常用组合。
        """
        _get_sklearn()
        GBC = _core._GradientBoostingClassifier
        SS = _core._StandardScaler
        if GBC is None or SS is None:
            return {}, None
        models = {}
        scaler = SS()
        X_scaled = scaler.fit_transform(X)
        import gc as _gc  # 作用说明：每训练 10 个号码回收一次中间对象，抑制内存增长
        for num_idx in range(49):
            y_num = y[:, num_idx]
            # 标签只有单一取值（该号码在训练集里从不出现或每期都出现）时，
            # 二分类器无正负样本可分，直接置 None 跳过，避免 sklearn 抛异常
            if len(set(y_num)) < 2:
                models[num_idx] = None
                continue
            # 【修复】GradientBoostingClassifier不支持n_jobs参数
            model = GBC(
                n_estimators=100, max_depth=4, learning_rate=0.1,
                min_samples_split=5, min_samples_leaf=3, random_state=42
            )
            model.fit(X_scaled, y_num)
            models[num_idx] = model
            if num_idx % 10 == 0:
                _gc.collect()
        return models, scaler
    
    
    def _train_logistic_regression(self, X, y):
        """Logistic 回归：每数字独立分类

        功能：
            先用 StandardScaler 标准化特征，再对 1~49 每个号码各自训练一个
            LogisticRegression（max_iter=500、C=1.0）二分类器；
            标签单类的号码置 None 跳过。

        参数:
            X (np.ndarray): 特征矩阵 (n_samples, 580)
            y (np.ndarray): 标签矩阵 (n_samples, 49)
        返回:
            (dict[int, model|None], scaler|None)：同 train_random_forest。
        注意：
            无文件写入；每训练 10 个号码 gc.collect() 一次；
            n_jobs=1 禁用 OpenMP 并行以防 C 栈溢出；
            sklearn 类不可用时直接返回 ({}, None)；训练为同步阻塞。

        说明:
            max_iter=500 是放宽的迭代上限（默认 100 在 580 维特征下常不收敛）；
            C=1.0 表示不做额外正则化强度的调整。
        """
        _get_sklearn()
        LR = _core._LogisticRegression
        SS = _core._StandardScaler
        if LR is None or SS is None:
            return {}, None
        models = {}
        scaler = SS()
        X_scaled = scaler.fit_transform(X)
        import gc as _gc  # 作用说明：每训练 10 个号码回收一次中间对象，抑制内存增长
        for num_idx in range(49):
            y_num = y[:, num_idx]
            # 标签只有单一取值（该号码在训练集里从不出现或每期都出现）时，
            # 二分类器无正负样本可分，直接置 None 跳过，避免 sklearn 抛异常
            if len(set(y_num)) < 2:
                models[num_idx] = None
                continue
            # 【修复0xC0000409】设置n_jobs=1禁用OpenMP并行，防止C栈溢出
            model = LR(max_iter=500, C=1.0, random_state=42, n_jobs=1)
            model.fit(X_scaled, y_num)
            models[num_idx] = model
            if num_idx % 10 == 0:
                _gc.collect()
        return models, scaler
    
    def _train_mlp_classifier(self, X, y):
        """MLP 分类器：每数字独立分类

        功能：
            先用 MinMaxScaler 把特征压到 0~1，再对 1~49 每个号码各自训练一个
            隐藏层 (64, 32)、max_iter=150、early_stopping=True 的 MLPClassifier；
            标签单类或训练抛 ValueError 的号码置 None 跳过。

        参数:
            X (np.ndarray): 特征矩阵 (n_samples, 580)
            y (np.ndarray): 标签矩阵 (n_samples, 49)
        返回:
            (dict[int, model|None], scaler|None)：同 train_random_forest。
        注意：
            无文件写入；每训练 10 个号码 gc.collect() 一次；
            单个号码训练抛 ValueError 时捕获并把该号码置 None，不中断整体训练；
            sklearn 类不可用时直接返回 ({}, None)。

        说明:
            与其它三个模型不同，此处用 MinMaxScaler（把特征压到 0~1），
            因为神经网络对输入尺度更敏感，且 580 维 one-hot 本身已是 0/1。
        """
        _get_sklearn()
        MLP = _core._MLPClassifier
        MMS = _core._MinMaxScaler
        if MLP is None or MMS is None:
            return {}, None
        models = {}
        scaler = MMS()
        X_scaled = scaler.fit_transform(X)
        import gc as _gc  # 作用说明：每训练 10 个号码回收一次中间对象，抑制内存增长
        for num_idx in range(49):
            y_num = y[:, num_idx]
            # 标签只有单一取值（该号码在训练集里从不出现或每期都出现）时，
            # 二分类器无正负样本可分，直接置 None 跳过，避免 sklearn 抛异常
            if len(set(y_num)) < 2:
                models[num_idx] = None
                continue
            model = MLP(
                hidden_layer_sizes=(64, 32), max_iter=150,
                learning_rate='adaptive', early_stopping=True,
                random_state=42
            )
            try:
                model.fit(X_scaled, y_num)
                models[num_idx] = model
            except ValueError:
                # 当某个类别的样本数过少时，train_test_split的stratify参数会失败
                # 此时跳过该模型，继续训练其他模型
                models[num_idx] = None
            if num_idx % 10 == 0:
                _gc.collect()
        return models, scaler
    
    
    def predict_with_all_models(self, progress_callback=None, use_cache=True):
        """多模型概率加权集成 + 模型持久化缓存

        功能：
            优先尝试加载 ml_models.pkl 缓存；命中时直接用缓存模型预测，
            未命中时依次训练随机森林/梯度提升/逻辑回归/MLP 四个模型，
            对 49 个号码取各模型 P(出现) 的算术平均作为得分，取得分最高的
            6 个号码并按升序返回。

        优先从 ml_models.pkl 加载已训练的模型（文件存在直接使用），
        仅在文件不存在时重新训练，大幅提升预测速度。
        
        参数:
            progress_callback: 可选的进度回调函数 callback(percent, msg)
            use_cache: 是否使用缓存的模型文件（ml_models.pkl），False=强制重新训练

        返回:
            tuple | None: (预测号码列表(升序 6 个), {号码: 平均概率})；
                数据不足、sklearn 缺失或全部模型失败时返回 None。

        注意：
            - 可能写 ml_models.pkl（缓存未命中且至少一个模型训练成功时）
            - 训练为同步阻塞，通过 progress_callback 汇报 5%~95% 的进度
            - 单个模型训练异常只记失败并跳过，不中断其余模型；
              四个模型全部失败时返回 None，不返回随机结果
        """
        def _emit(percent, msg):
            """安全地上报训练进度

            功能：
                在 progress_callback 存在时把 (percent, msg) 原样转发给调用方，
                用于把训练阶段进度回显到界面；不存在时什么都不做。

            参数:
                percent (int): 进度百分比（本方法使用 5~95）
                msg (str): 展示给用户的阶段说明
            返回:
                None: 只触发回调，不返回进度值。

            注意：
                progress_callback 为 None 时静默跳过，便于后台/无界面调用复用同一套流程。
                回调在训练线程内同步执行，回调方若做耗时操作会拖慢训练。
            """
            if progress_callback:
                progress_callback(percent, msg)
        
        _emit(5, "正在准备数据...")
        X, y = self.prepare_features()
        if len(X) < 20:
            # 【Bug修复】数据不足时返回None而非随机结果，避免假预测被保存指纹
            return None
        
        # 构建最新特征（取最新10条记录，非最旧10条）
        # data[0]是最新（insert(0,...)），reversed后data_ordered[-1]是最新
        # 取最后10条=最新10条记录的特征
        data_ordered = list(reversed(self.data))
        latest_features = []
        latest_10 = data_ordered[-10:] if len(data_ordered) >= 10 else data_ordered
        for record in latest_10:
            latest_features.extend(self._extract_window_features(record))
        
        # 580 = 10 期 × 58 维，必须与 prepare_features 生成的训练矩阵列数一致，
        # 否则 scaler.transform 会因维度不匹配报错；历史不足 10 期时用 0 补齐，超长时截断
        expected_len = 580
        if len(latest_features) < expected_len:
            latest_features.extend([0] * (expected_len - len(latest_features)))
        elif len(latest_features) > expected_len:
            latest_features = latest_features[:expected_len]
        
        X_latest = np.array([latest_features])
        
        # ================================================================
        # 尝试加载缓存的模型（仅在use_cache=True且文件存在时使用）
        # ================================================================
        _emit(10, "正在检查模型缓存...")
        cached = self.load_models() if use_cache else None
        
        if cached is not None:
            # 模型文件已存在，直接使用缓存模型预测，跳过训练
            _emit(15, "使用缓存模型预测（跳过训练）...")
            return self._predict_with_cached_models(
                cached, X_latest, _emit)
        
        # ================================================================
        # 缓存未命中，训练所有模型（训练一次即用，不做准确率检查）
        # ================================================================
        all_probs = np.zeros(49)
        model_count = 0
        rf_models = rf_scaler = gb_models = gb_scaler = None
        lr_models = lr_scaler = mlp_models = mlp_scaler = None
        # 记录各模型训练结果（用于保存到训练数据文件）
        model_results = {}
        
        # 1. Random Forest
        _emit(20, "正在训练模型（1/4 随机森林）...")
        try:
            rf_models, rf_scaler = self.train_random_forest(X, y)
            _emit(25, "随机森林训练完成")
            X_scaled = rf_scaler.transform(X_latest)
            model_probs = np.zeros(49)
            for num_idx in range(49):
                if rf_models.get(num_idx) is not None:
                    # predict_proba 返回 [P(不出现), P(出现)]；取下标 1 作为得分。
                    # 训练时曾跳过“单类标签”的号码，理论上不会出现长度 1 的情况，
                    # 但仍做兜底：长度 1 时取 prob[0]，避免索引越界
                    prob = rf_models[num_idx].predict_proba(X_scaled)[0]
                    model_probs[num_idx] += prob[1] if len(prob) > 1 else prob[0]
            all_probs += model_probs
            model_count += 1
            model_results['random_forest'] = {'status': 'success', 'trained_nums': sum(1 for m in rf_models.values() if m is not None)}
        except Exception as e:
            _emit(28, "随机森林训练异常: %s" % str(e)[:60])
            model_results['random_forest'] = {'status': 'failed', 'error': str(e)[:80]}
        
        # 2. Gradient Boosting
        _emit(35, "正在训练模型（2/4 梯度提升）...")
        try:
            gb_models, gb_scaler = self.train_gradient_boosting(X, y)
            _emit(45, "梯度提升训练完成")
            X_scaled = gb_scaler.transform(X_latest)
            model_probs = np.zeros(49)
            for num_idx in range(49):
                if gb_models.get(num_idx) is not None:
                    prob = gb_models[num_idx].predict_proba(X_scaled)[0]
                    model_probs[num_idx] += prob[1] if len(prob) > 1 else prob[0]
            all_probs += model_probs
            model_count += 1
            model_results['gradient_boosting'] = {'status': 'success', 'trained_nums': sum(1 for m in gb_models.values() if m is not None)}
        except Exception as e:
            _emit(48, "梯度提升训练异常: %s" % str(e)[:60])
            model_results['gradient_boosting'] = {'status': 'failed', 'error': str(e)[:80]}
        
        # 3. Logistic Regression
        _emit(55, "正在训练模型（3/4 逻辑回归）...")
        try:
            lr_models, lr_scaler = self._train_logistic_regression(X, y)
            _emit(65, "逻辑回归训练完成")
            X_scaled = lr_scaler.transform(X_latest)
            model_probs = np.zeros(49)
            for num_idx in range(49):
                if lr_models.get(num_idx) is not None:
                    prob = lr_models[num_idx].predict_proba(X_scaled)[0]
                    model_probs[num_idx] += prob[1] if len(prob) > 1 else prob[0]
            all_probs += model_probs
            model_count += 1
            model_results['logistic_regression'] = {'status': 'success', 'trained_nums': sum(1 for m in lr_models.values() if m is not None)}
        except Exception as e:
            _emit(68, "逻辑回归训练异常: %s" % str(e)[:60])
            model_results['logistic_regression'] = {'status': 'failed', 'error': str(e)[:80]}
        
        # 4. MLP Classifier
        _emit(75, "正在训练模型（4/4 MLP分类器）...")
        try:
            mlp_models, mlp_scaler = self._train_mlp_classifier(X, y)
            _emit(85, "MLP分类器训练完成")
            X_scaled = mlp_scaler.transform(X_latest)
            model_probs = np.zeros(49)
            for num_idx in range(49):
                if mlp_models.get(num_idx) is not None:
                    prob = mlp_models[num_idx].predict_proba(X_scaled)[0]
                    model_probs[num_idx] += prob[1] if len(prob) > 1 else prob[0]
            all_probs += model_probs
            model_count += 1
            model_results['mlp_classifier'] = {'status': 'success', 'trained_nums': sum(1 for m in mlp_models.values() if m is not None)}
        except Exception as e:
            _emit(88, "MLP训练异常: %s" % str(e)[:60])
            model_results['mlp_classifier'] = {'status': 'failed', 'error': str(e)[:80]}
        
        # ================================================================
        # 保存训练好的模型到文件（供下次预测使用）
        # ================================================================
        _emit(90, "正在保存模型和训练数据...")
        if model_count > 0:
            save_ok = self.save_models(rf_models, rf_scaler, gb_models, gb_scaler,
                           lr_models, lr_scaler, mlp_models, mlp_scaler,
                           X=X, y=y, X_latest=X_latest)
            if save_ok:
                _emit(92, f"模型已保存（{len(self.data)}条数据，下次预测将直接加载）")
            else:
                _emit(92, "模型保存失败，下次预测需重新训练")
            # 【删除】不再生成training_data.json（纯诊断文件，不参与预测，占用磁盘空间）
            # self.save_training_data(X, y, model_results=model_results)
        else:
            _emit(92, "所有模型训练失败，无法保存模型")
        
        # 归一化概率（按“成功参与预测的模型个数”做算术平均）
        _emit(95, "正在汇总结果...")
        # 每个模型先累加到局部 model_probs，循环完整成功后才并入 all_probs，
        # 中途异常时该模型的局部结果自动丢弃，不会被算进平均值
        if model_count > 0:
            all_probs = all_probs / model_count
        else:
            # 【Bug修复】所有模型训练/预测失败时返回None而非随机结果，
            # 避免随机结果被当作有效预测保存指纹，导致无法重新预测
            return None
        
        # 构建概率字典 {num: prob} 用于生肖组选择
        all_probs_dict = {i + 1: float(all_probs[i]) for i in range(49)}
        
        top_indices = np.argsort(all_probs)[::-1][:6]
        predictions = [idx + 1 for idx in top_indices]
        
        return (sorted(predictions), all_probs_dict)
    
    def _predict_with_cached_models(self, cached, X_latest, _emit):
        """使用缓存的模型和训练数据进行预测（跳过训练和特征工程）
        
        功能：
            用当前计算的最新特征 X_latest，依次让缓存中的 4 组模型各自输出
            49 个号码的 P(出现)，累加后除以成功预测的模型个数求平均，
            取平均概率最高的 6 个号码升序返回。

        参数:
            cached: load_models() 返回的 (模型..., X, y, X_latest) 元组
            X_latest: 最新特征向量（当前计算的，作为fallback）
            _emit: 进度回调函数

        返回:
            tuple | None: (升序 6 个预测号码, {号码: 平均概率})；
                缓存中所有模型都不可用时返回 None。

        注意：
            每个模型的异常都被静默吞掉（该模型不计入 model_count）；
            缓存里的 X/y/X_latest 仅用于元组解包对齐，不参与预测，
            实际特征始终使用调用方传入的 X_latest，避免复用过期特征。
        """
        rf_models, rf_scaler, gb_models, gb_scaler, \
            lr_models, lr_scaler, mlp_models, mlp_scaler, \
            _cached_X, _cached_y, cached_X_latest = cached
        
        # 【Bug修复】使用当前最新数据计算的X_latest（非缓存旧值），
        # 确保每次预测反映最新数据状态，避免缓存模型+缓存旧特征导致结果永远不变
        # 注：_cached_X/_cached_y/cached_X_latest 仅用于load_models返回元组对齐，
        # 实际预测中不使用，避免大矩阵反序列化浪费内存
        
        all_probs = np.zeros(49)
        model_count = 0
        
        # 1. Random Forest
        try:
            if rf_models and rf_scaler:
                X_scaled = rf_scaler.transform(X_latest)
                model_probs = np.zeros(49)
                for num_idx in range(49):
                    if rf_models.get(num_idx) is not None:
                        prob = rf_models[num_idx].predict_proba(X_scaled)[0]
                        model_probs[num_idx] += prob[1] if len(prob) > 1 else prob[0]
                all_probs += model_probs
                model_count += 1
        except Exception:
            pass
        
        # 2. Gradient Boosting
        try:
            if gb_models and gb_scaler:
                X_scaled = gb_scaler.transform(X_latest)
                model_probs = np.zeros(49)
                for num_idx in range(49):
                    if gb_models.get(num_idx) is not None:
                        prob = gb_models[num_idx].predict_proba(X_scaled)[0]
                        model_probs[num_idx] += prob[1] if len(prob) > 1 else prob[0]
                all_probs += model_probs
                model_count += 1
        except Exception:
            pass
        
        # 3. Logistic Regression
        try:
            if lr_models and lr_scaler:
                X_scaled = lr_scaler.transform(X_latest)
                model_probs = np.zeros(49)
                for num_idx in range(49):
                    if lr_models.get(num_idx) is not None:
                        prob = lr_models[num_idx].predict_proba(X_scaled)[0]
                        model_probs[num_idx] += prob[1] if len(prob) > 1 else prob[0]
                all_probs += model_probs
                model_count += 1
        except Exception:
            pass
        
        # 4. MLP Classifier
        try:
            if mlp_models and mlp_scaler:
                X_scaled = mlp_scaler.transform(X_latest)
                model_probs = np.zeros(49)
                for num_idx in range(49):
                    if mlp_models.get(num_idx) is not None:
                        prob = mlp_models[num_idx].predict_proba(X_scaled)[0]
                        model_probs[num_idx] += prob[1] if len(prob) > 1 else prob[0]
                all_probs += model_probs
                model_count += 1
        except Exception:
            pass
        
        _emit(95, "正在汇总结果...")
        if model_count > 0:
            all_probs = all_probs / model_count
        else:
            # 【Bug修复】所有模型预测失败时返回None而非随机结果，
            # 避免随机结果被当作有效预测保存指纹，导致无法重新预测
            return None
        
        # 构建概率字典 {num: prob} 用于生肖组选择
        all_probs_dict = {i + 1: float(all_probs[i]) for i in range(49)}
        
        top_indices = np.argsort(all_probs)[::-1][:6]
        predictions = [idx + 1 for idx in top_indices]
        
        return (sorted(predictions), all_probs_dict)
