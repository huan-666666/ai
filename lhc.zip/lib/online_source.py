# -*- coding: utf-8 -*-
"""
============================================================================
lib/online_source.py - 在线开奖抓取与解析（纯逻辑层，禁止 Qt）
============================================================================
在架构中的位置：
    lib/ 纯逻辑层。被 TAB/history.py 的 worker 线程调用；本模块不 import 任何
    Qt 对象，也不写任何界面控件，可在任意线程安全调用。

职责：
    1. fetch_url()       —— 下载网页/JSON（requests 优先，标准库 urllib 兜底）
    2. detect_source()   —— 先站点注册表、再内容嗅探，判定解析器类型
    3. parse_*()         —— 澳门 JSON / 单条 JSON / 通用 JSON / 通用 HTML
    4. dedupe_records()  —— 按期号去重（保留后到的一条）
    5. summarize()       —— 期数、起止日期、警告汇总
    6. compare_with_local() / select_newer() —— 只读对比与“新增期”判定，
       本模块绝不修改本地历史数据

年份路径语义（重要）：
    站点模板中的 {year} 不等于「自然年」筛选：常见开奖接口返回的是以该年最后
    一天为终点的「最近 366 期」滚动窗口（会含上一年年末的跨年记录）。因此本模块
    与下游（同期对照、回填）一律按 draw_date 的年份归类，禁止用 source_period 的
    前缀年份做自然年假设；前缀年份只用于校验（见 parse_macau_json 的脏期号隔离）。

依赖：
    - 标准库：json / gzip / hashlib / logging / re / urllib / datetime
    - 可选：requests（缺失时自动走 urllib.request）
    - 可选：lxml（缺失时 HTML 解析自动走 html.parser）

线程约束：
    本模块只做网络与纯数据转换；调用方负责把结果写库/渲染，并传入 should_stop
    回调以便在下载分块之间协作式取消（不依赖 Qt）。
============================================================================
"""

import gzip                   # 作用说明：urllib 路径下手动解压 gzip 响应
import hashlib                # 作用说明：生成 content_hash，供增量去重
import json                   # 作用说明：JSON 接口解析
import logging                # 作用说明：拦截/脏期号隔离时写 WARNING 日志（无 Qt 依赖）
import re                     # 作用说明：HTML 文本、日期、号码切分
import socket                 # 作用说明：识别超时/连接错误
import time                   # 作用说明：记录下载耗时
from datetime import datetime
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse, urlunparse

from lib import online_sites  # 作用说明：站点注册表只来自配置文件，代码内不预置任何域名/网址
from lib.date_utils import normalize_date  # 作用说明：本地日期与在线日期统一成 ISO 后再对比
from urllib.request import HTTPRedirectHandler, Request, build_opener

try:                          # 作用说明：可选依赖，缺失时不影响本模块导入
    import requests as _requests
except Exception:             # pragma: no cover - 环境缺库时的兜底
    _requests = None

try:                          # 作用说明：可选依赖，缺失时回退标准库 html.parser
    from lxml import html as _lxml_html
except Exception:             # pragma: no cover
    _lxml_html = None

from html.parser import HTMLParser  # 作用说明：lxml 缺失时的 HTML 表格兜底解析

logger = logging.getLogger(__name__)  # 作用说明：拦截页与脏期号隔离的 WARNING 落点（不配置 handler，跟随宿主日志）

# ============================================================================
# 常量与失败文案（统一在 UI 侧按「标题：正文」展示）
# ============================================================================
DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)
DEFAULT_TIMEOUT = 15.0
MAX_BYTES = 8 * 1024 * 1024
MAX_REDIRECTS = 5

FAILURE_TEXTS = {
    'invalid_url':   ('网址无效', '请粘贴完整的 http:// 或 https:// 网址'),
    'offline':       ('无法连接', '连接不上目标站点，请检查网络或网址后重试'),
    'timeout':       ('连接超时', '站点在 15 秒内没有响应，请稍后重试'),
    'not_found':     ('页面不存在', '目标站点返回 HTTP 404，请确认网址是否正确'),
    'http_error':    ('站点返回错误', '目标站点返回 HTTP %s'),
    'too_large':     ('内容过大', '返回内容超过 8MB 上限，已停止下载'),
    'not_text':      ('内容无法解析', '返回的是图片、脚本或二进制内容，不是可解析的开奖数据'),
    'unknown_site':  ('无法识别的站点', '已获取页面，但没有识别出可用的开奖结果表；请从支持站点清单中选择或粘贴接口网址'),
    'unsupported_site': ('该站点不在支持列表', '支持的形式：%s'),
    'empty_data':    ('没有有效数据', '页面已获取，但未解析到「期号 + 7 个号码」的有效记录'),
    'blocked_html':  ('被目标站拦截', '被目标站拦截或返回了 HTML 页面（%s）'),
    'parse_failed':  ('解析失败', '数据格式与已知开奖口径不符：%s'),
    'cancelled':     ('已取消', '抓取已取消'),
    'store_failed':  ('保存失败', '在线数据写入本地库失败：%s'),
}


class OnlineSourceError(Exception):
    """在线抓取/解析统一异常：kind 决定界面标题，detail 为可读原因"""

    def __init__(self, kind, detail=None, title=None):
        """构造异常并回填统一文案

        参数:
            kind (str): FAILURE_TEXTS 的键，如 offline/timeout/unknown_site。
            detail (str|None): 覆盖默认正文的补充说明。
            title (str|None): 覆盖默认标题（一般不需要）。
        返回: None。
        注意: 只保存字符串，不访问网络、不触碰界面。
        """
        default_title, default_detail = FAILURE_TEXTS.get(kind, ('抓取失败', '%s'))
        self.kind = kind
        self.title = title or default_title
        self.detail = detail or default_detail
        super().__init__("%s：%s" % (self.title, self.detail))

# ============================================================================
# 下载
# ============================================================================
# 站点识别与网址归一化：全部由 lib/online_sites 的配置注册表驱动。
# 本模块不预置任何站点、域名或完整网址；站点清单/模板只存在于
# 系统v7.5/在线站点.json（用户配置文件）。
def host_is_registered(url):
    """网址主机是否命中配置注册表（用于区分「不在支持列表」与解析失败）"""
    return bool(online_sites.match_site(normalize_url_input(url)))



_INVISIBLE_CHARS = '\u200b\u200c\u200d\u200e\u200f\u2060\ufeff\u00ad'
_WRAP_CHARS = '"\'`“”‘’<>'
_FULLWIDTH_CHARS = str.maketrans({
    # 全角 ASCII（！～~）整体转半角：含全角字母/数字/标点（ｈｔｔｐｓ：／／ 等）
    **{chr(0xFF01 + i): chr(0x21 + i) for i in range(94)},
    '　': ' ',
})


def normalize_url_input(url):
    """归一化用户粘贴的网址，返回可直接识别/抓取的 URL

    规则:
        1. 去掉首尾与内部空白、换行及不可见字符（零宽空格/BOM/软连字符）；
        2. 去掉包裹引号/书名号，全角标点转半角；
        3. 无协议时补 https://（// 开头补 https:），scheme 与 host 转小写；
        4. 合并重复斜杠、去掉尾随斜杠（保留查询串与锚点）；
        5. 若输入命中配置站点的 url_template 且路径缺少年份（甚至缺年份上一级），
           按模板 + 当前年补齐，避免静默判失败；模板不存在时不猜测。

    参数:
        url (str): 用户原始输入。

    返回:
        str: 归一化后的网址；输入为空时返回空串。
    """
    text = str(url or '')
    for char in _INVISIBLE_CHARS:
        text = text.replace(char, '')
    text = text.translate(_FULLWIDTH_CHARS)
    text = text.strip().strip(_WRAP_CHARS)
    text = re.sub(r'\s+', '', text)
    text = text.strip(_WRAP_CHARS)
    if not text:
        return ''
    if text.startswith('//'):
        text = 'https:' + text
    elif not re.match(r'^[A-Za-z][A-Za-z0-9+.\-]*://', text):
        text = 'https://' + text
    parsed = urlparse(text)
    scheme = (parsed.scheme or 'https').lower()
    netloc = (parsed.netloc or '').lower()
    path = re.sub(r'/{2,}', '/', parsed.path or '').rstrip('/')
    normalized = urlunparse((scheme, netloc, path, parsed.params, parsed.query, parsed.fragment))
    return _complete_template_path(normalized)


def _complete_template_path(text):
    """按命中站点的 url_template 补齐缺年份路径（仅影响识别，不改变 URL 语义）

    规则:
        模板 path 为 /a/b/{year} 时接受：/a/b、/a/b/y、/a/b/y/2026。
        命中后用模板生成完整地址（保留用户 query/fragment）；未命中原样返回。
    """
    parsed = urlparse(text)
    site = online_sites.match_site(text)
    if not site:
        return text
    template = str(site.get('url_template') or '')
    if '{year}' not in template:
        return text
    prefix = (urlparse(template).path or '').split('{year}')[0].rstrip('/')
    if not prefix:
        return text
    accepted = {prefix}
    parent = prefix.rsplit('/', 1)[0]
    if parent:
        accepted.add(parent)
    path = (parsed.path or '').rstrip('/') or '/'
    if path not in accepted:
        return text
    filled = urlparse(template.format(year=datetime.now().year))
    return urlunparse((parsed.scheme or filled.scheme, parsed.netloc or filled.netloc,
                       filled.path, parsed.params or filled.params,
                       parsed.query, parsed.fragment))


def _url_echo(url, limit=120):
    """回显用户输入（超过 limit 字符时截断）"""
    text = str(url or '')
    return text if len(text) <= limit else text[:limit] + '…'


def unknown_site_detail(url, limit=120):
    """生成「无法识别」的可行动文案：指引到高级区站点清单 + 回显实际输入"""
    return ('请展开「高级 / 自定义站点」查看站点清单，或在「站点编辑」中新增站点'
            '（url_template 需含 {year}）。实际收到的字符串：%r'
            % _url_echo(url, limit))


def unsupported_site_detail(url, limit=120):
    """生成「不在支持列表」的可行动文案：指引到高级区新增站点 + 回显实际输入"""
    return ('请展开「高级 / 自定义站点」查看已配置站点，或在「站点编辑」中新增站点。'
            '实际收到的字符串：%r' % _url_echo(url, limit))


def _validate_url(url):
    """归一化并校验只允许 http/https 且必须有主机名；不合法时抛出 invalid_url"""
    text = normalize_url_input(url)
    parsed = urlparse(text)
    if parsed.scheme not in ('http', 'https') or not parsed.netloc:
        raise OnlineSourceError('invalid_url')
    return text


def _decode(raw, content_type):
    """按 Content-Type 的 charset 解码，缺省 utf-8，失败时替换非法字节"""
    charset = 'utf-8'
    match = re.search(r'charset=([\w\-]+)', content_type or '', re.I)
    if match:
        charset = match.group(1)
    try:
        return raw.decode(charset, errors='replace')
    except LookupError:
        return raw.decode('utf-8', errors='replace')


def _looks_binary(content_type, raw):
    """判断响应是否明显为图片/音视频/二进制；用于 not_text 失败态"""
    ctype = (content_type or '').lower()
    if ctype.startswith(('image/', 'video/', 'audio/')):
        return True
    if 'application/octet-stream' in ctype or 'application/pdf' in ctype:
        return True
    return b'\x00' in raw[:4096]


def _snippet(text, limit=80):
    """压缩空白后截取前 limit 个字符，供拦截文案与日志展示响应头/正文特征"""
    return re.sub(r'\s+', ' ', (text or '').strip())[:limit]


def _is_json_text(text):
    """正文是否以 { 或 [ 开头（只做形状判断，真 JSON 解析仍交给 json.loads）"""
    return (text or '').lstrip('\ufeff \t\r\n')[:1] in ('{', '[')


def _is_html_text(content_type, text):
    """判断响应是不是 HTML 页面（Content-Type 或正文前 2KB 的标签特征）"""
    if 'html' in (content_type or '').lower():
        return True
    head = (text or '').lstrip().lower()[:2048]
    return any(marker in head for marker in
               ('<!doctype html', '<html', '<head', '<body', '<title'))


def _blocked_html_error(status, content_type, text):
    """构造「被拦截/返回 HTML」失败态，并写一条 WARNING 日志（不抛，由调用方 raise）"""
    detail = FAILURE_TEXTS['blocked_html'][1] % (
        'status=%s, content-type=%s, 前 80 字符=%r' % (
            status if status is not None else '未知',
            content_type or '未知',
            _snippet(text),
        ),
    )
    logger.warning('[在线开奖] %s', detail)
    return OnlineSourceError('blocked_html', detail)


def _http_error(status, content_type=None, text=None):
    """把 HTTP 状态码映射为统一异常（404 单独成类）

    说明:
        403/429/503 或正文为 HTML 时按「被拦截」处理（典型是 Cloudflare 挑战页），
        避免把 HTML 挑战页误报成「解析失败：不是合法 JSON」；404 始终走 not_found。
    """
    if status == 404:
        return OnlineSourceError('not_found', '目标站点返回 HTTP 404，请确认网址是否正确')
    if text is not None and not _is_json_text(text):
        if status in (403, 429, 503) or _is_html_text(content_type, text):
            return _blocked_html_error(status, content_type, text)
    return OnlineSourceError('http_error', '目标站点返回 HTTP %s' % status, title='站点返回错误')


def _read_error_body(response, limit=8192):
    """读取 4xx/5xx 响应的前 limit 字节，用于区分「HTTP 错误页」与「拦截/挑战页」"""
    buffer = bytearray()
    try:
        for chunk in response.iter_content(chunk_size=4096):
            if not chunk:
                continue
            buffer.extend(chunk)
            if len(buffer) >= limit:
                break
    except Exception:  # 读取失败不影响错误分类，按无正文处理
        pass
    return bytes(buffer[:limit])


def _fetch_requests(url, timeout, max_bytes, max_redirects, should_stop):
    """requests 路径：流式读取、分块检查取消、8MB 上限、最多 5 跳重定向"""
    session = _requests.Session()
    session.max_redirects = int(max_redirects)
    headers = {
        'User-Agent': DEFAULT_UA,
        'Accept': 'application/json, text/html, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9',
    }
    started = time.time()
    response = session.get(url, headers=headers, timeout=(min(5.0, timeout), timeout),
                           stream=True, allow_redirects=True)
    try:
        if response.status_code >= 400:
            error_type = response.headers.get('Content-Type', '')
            error_text = ''
            if response.status_code != 404:  # 404 保持原 not_found，无需读正文
                error_text = _decode(_read_error_body(response), error_type)
            raise _http_error(response.status_code, error_type, error_text)
        content_type = response.headers.get('Content-Type', '')
        buffer = bytearray()
        for chunk in response.iter_content(chunk_size=64 * 1024):
            if should_stop is not None and should_stop():
                raise OnlineSourceError('cancelled')
            if not chunk:
                continue
            buffer.extend(chunk)
            if len(buffer) > max_bytes:
                raise OnlineSourceError('too_large')
        raw = bytes(buffer)
    finally:
        response.close()
        session.close()
    if _looks_binary(content_type, raw):
        raise OnlineSourceError('not_text')
    return {
        'url': response.url or url,
        'text': _decode(raw, content_type),
        'content_type': content_type,
        'size': len(raw),
        'status': response.status_code,
        'elapsed_ms': (time.time() - started) * 1000.0,
    }


class _LimitedRedirect(HTTPRedirectHandler):
    """限制重定向次数的 urllib 处理器（默认最多 5 跳）"""

    def __init__(self, limit=MAX_REDIRECTS):
        super().__init__()
        self._limit = int(limit)
        self._count = 0

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        self._count += 1
        if self._count > self._limit:
            raise OnlineSourceError('http_error', '重定向超过 %d 次' % self._limit, title='跳转过多')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _fetch_urllib(url, timeout, max_bytes, max_redirects, should_stop):
    """标准库路径：无 requests 时使用；流式读取并在分块间检查取消"""
    opener = build_opener(_LimitedRedirect(max_redirects))
    request = Request(url, headers={
        'User-Agent': DEFAULT_UA,
        'Accept': 'application/json, text/html, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Accept-Encoding': 'gzip',
    })
    started = time.time()
    try:
        with opener.open(request, timeout=timeout) as response:
            status = getattr(response, 'status', 200)
            content_type = response.headers.get('Content-Type', '')
            buffer = bytearray()
            while True:
                if should_stop is not None and should_stop():
                    raise OnlineSourceError('cancelled')
                chunk = response.read(64 * 1024)
                if not chunk:
                    break
                buffer.extend(chunk)
                if len(buffer) > max_bytes:
                    raise OnlineSourceError('too_large')
            raw = bytes(buffer)
            final_url = response.geturl()
    except OnlineSourceError:
        raise
    except HTTPError as exc:
        error_type = ''
        error_text = ''
        if exc.code != 404:  # 404 保持原 not_found，无需读正文
            try:
                error_type = (exc.headers.get('Content-Type', '') if exc.headers else '')
                error_text = _decode(exc.read(8192), error_type)
            except Exception:  # 读错误页失败时按无正文分类
                pass
        raise _http_error(exc.code, error_type, error_text)
    except (socket.timeout, TimeoutError):
        raise OnlineSourceError('timeout')
    except URLError as exc:
        reason = getattr(exc, 'reason', None)
        if isinstance(reason, (socket.timeout, TimeoutError)):
            raise OnlineSourceError('timeout')
        raise OnlineSourceError('offline')
    if response.headers.get('Content-Encoding', '').lower() == 'gzip' or raw[:2] == b'\x1f\x8b':
        try:
            raw = gzip.decompress(raw)
        except OSError:
            raise OnlineSourceError('parse_failed', 'gzip 解压失败')
    if _looks_binary(content_type, raw):
        raise OnlineSourceError('not_text')
    return {
        'url': final_url or url,
        'text': _decode(raw, content_type),
        'content_type': content_type,
        'size': len(raw),
        'status': status,
        'elapsed_ms': (time.time() - started) * 1000.0,
    }


def fetch_url(url, timeout=DEFAULT_TIMEOUT, max_bytes=MAX_BYTES,
              max_redirects=MAX_REDIRECTS, should_stop=None):
    """下载指定网址并返回文本内容（requests 优先，urllib 兜底）

    参数:
        url (str): 用户粘贴的完整网址。
        timeout (float): 连接/读取超时秒数，默认 15。
        max_bytes (int): 最大下载字节数，默认 8MB。
        max_redirects (int): 最大重定向次数，默认 5。
        should_stop (callable|None): 返回 True 时在分块之间中止下载。

    返回:
        dict: url/text/content_type/size/status/elapsed_ms。

    异常:
        OnlineSourceError：kind 为 invalid_url/offline/timeout/not_found/
        http_error/too_large/not_text/cancelled。

    线程约束:
        无 Qt 依赖，可在任意线程调用；should_stop 由调用方提供。
    """
    target = _validate_url(url)
    if _requests is None:
        return _fetch_urllib(target, timeout, max_bytes, max_redirects, should_stop)
    try:
        return _fetch_requests(target, timeout, max_bytes, max_redirects, should_stop)
    except OnlineSourceError:
        raise
    except _requests.exceptions.Timeout:
        raise OnlineSourceError('timeout')
    except _requests.exceptions.TooManyRedirects:
        raise OnlineSourceError('http_error', '重定向超过 %d 次' % max_redirects, title='跳转过多')
    except _requests.exceptions.SSLError as exc:
        raise OnlineSourceError('offline', 'HTTPS 证书校验失败：%s' % exc)
    except _requests.exceptions.ConnectionError:
        raise OnlineSourceError('offline')
    except _requests.exceptions.RequestException as exc:
        raise OnlineSourceError('parse_failed', '请求失败：%s' % exc)


# ============================================================================
# 站点识别
# ============================================================================
def detect_source(url, content_type, text):
    """按配置注册表识别站点解析器类型；未配置的站点一律返回 'unknown'

    返回类型:
        macau_json / hkjc_json / generic_json / generic_html / unknown

    说明:
        本模块不预置任何域名，因此不按 host 硬编码判断，也不把内容嗅探当成
        「已支持站点」的证据：主机不在注册表 → 'unknown'，由调用方区分
        「不在支持列表」与「已配置站点解析失败」两类提示。
    """
    return online_sites.registry_source_type(normalize_url_input(url)) or 'unknown'


# ============================================================================
# 解析：公共小工具
# ============================================================================
def _split_numbers(value):
    """把 openCode / 号码文本切成整数列表（支持 , + & 空格 - 分隔）"""
    if isinstance(value, (list, tuple)):
        parts = list(value)
    elif isinstance(value, (int, float)):
        parts = [value]
    else:
        parts = re.split(r'[^\d]+', str(value or ''))
    numbers = []
    for part in parts:
        if part is None or part == '':
            continue
        try:
            numbers.append(int(part))
        except (TypeError, ValueError):
            continue
    return numbers


def _normalize_date(value):
    """把常见日期字符串统一为 YYYY-MM-DD；无法识别时返回空串"""
    if value is None:
        return ''
    if isinstance(value, (int, float)):
        try:
            stamp = value / 1000.0 if value > 1e11 else value
            return datetime.fromtimestamp(stamp).strftime('%Y-%m-%d')
        except (ValueError, OSError, OverflowError):
            return ''
    text = str(value).strip()
    match = re.search(r'(\d{4})[-/.年](\d{1,2})[-/.月](\d{1,2})', text)
    if match:
        year, month, day = (int(match.group(i)) for i in (1, 2, 3))
        return '%04d-%02d-%02d' % (year, month, day)
    return ''


def _build_record(period, date, numbers, source_type, url, fetched_at=None):
    """把 7 个号码组装为统一记录；号码非法时返回 None（由调用方计警告）"""
    if not period or not date or len(numbers) != 7:
        return None
    if any((not isinstance(n, int)) or n < 1 or n > 49 for n in numbers):
        return None
    return {
        'source': source_type,
        'source_period': str(period),
        'draw_date': date,
        'numbers': numbers[:6],
        'special': numbers[6],
        'fetched_at': fetched_at or datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'url': url,
        'content_hash': hashlib.sha1(
            ('%s|%s|%d' % (date, json.dumps(numbers[:6]), numbers[6])).encode('utf-8')
        ).hexdigest(),
    }


# ============================================================================
# 解析：澳门 / 香港 JSON
# ============================================================================
def _period_prefix_year(period):
    """取期号前 4 位数字作为「来源年份」；不是纯数字期号时返回 None"""
    match = re.match(r'\s*(\d{4})', str(period or ''))
    return int(match.group(1)) if match else None


def _empty_parse_stats():
    """统一的解析统计初值（无隔离/无跳过），供各解析器返回三元组时复用"""
    return {'quarantined': 0, 'quarantine_samples': [], 'skipped': 0}


def _draw_year(date):
    """取规范化日期 YYYY-MM-DD 的年份；日期无法识别时返回 None"""
    match = re.match(r'(\d{4})-', date or '')
    return int(match.group(1)) if match else None


def parse_macau_json(text, url, source_type='macau_json'):
    """解析澳门风格 JSON：data[].expect/openTime/openCode

    参数:
        text (str): 接口原文。
        url (str): 来源地址（写入记录）。
        source_type (str): macau_json 或 hkjc_json。

    返回:
        (list[dict], list[str], dict): 记录列表、警告列表、统计字典
        （stats 含 quarantined 隔离条数、quarantine_samples 样本、skipped 跳过条数）。

    异常:
        OnlineSourceError('parse_failed'|'empty_data')：JSON 结构不符或无有效记录。

    年路径语义（重要）:
        模板 {year} 对应的接口通常是「最近 366 期」滚动窗口，不是自然年；
        例如某年窗口会带出上一年年末的跨年记录。本函数不做自然年过滤，
        跨年记录按 openTime 归年，期号前缀年份只用于一致性校验。

    脏期号隔离:
        expect 的前 4 位年份与 openTime 年份不一致时（如 expect=2023004、
        openTime=2024-01-04），该记录被视为脏数据：写 WARNING 日志、计入
        stats['quarantined'] 并在警告列表留痕，**不加入返回记录**，因此不会
        写入在线库；不静默丢弃。
    """
    try:
        payload = json.loads(text)
    except ValueError as exc:
        raise OnlineSourceError('parse_failed', '不是合法 JSON：%s' % exc)
    data = payload.get('data') if isinstance(payload, dict) else None
    if not isinstance(data, list):
        raise OnlineSourceError('parse_failed', 'JSON 缺少 data 数组')
    records, warnings = [], []
    stats = {'quarantined': 0, 'quarantine_samples': [], 'skipped': 0}
    for row in data:
        if not isinstance(row, dict):
            continue
        code = row.get('openCode')
        numbers = _split_numbers(code)
        period = row.get('expect') or row.get('issue') or row.get('period')
        date = _normalize_date(row.get('openTime') or row.get('date'))
        period_year = _period_prefix_year(period)
        draw_year = _draw_year(date)
        if period_year is not None and draw_year is not None and period_year != draw_year:
            stats['quarantined'] += 1
            if len(stats['quarantine_samples']) < 5:
                stats['quarantine_samples'].append({
                    'period': str(period), 'date': date,
                    'period_year': period_year, 'draw_year': draw_year,
                })
            message = ('隔离期号 %s：expect 前缀年份 %d 与 openTime %s 的年份 %d 不一致'
                       '（不写入在线库）' % (period, period_year, date, draw_year))
            warnings.append(message)
            logger.warning('[在线开奖] %s', message)
            continue
        record = _build_record(period, date, numbers, source_type, url)
        if record is None:
            stats['skipped'] += 1
            warnings.append('跳过一条字段不完整的记录：%s' % (period or '?'))
            continue
        records.append(record)
    if stats['quarantined']:
        summary_message = ('本次共隔离 %d 条期号年份与开奖日期不一致的记录'
                           '（未写入在线库）' % stats['quarantined'])
        warnings.append(summary_message)
        logger.warning('[在线开奖] %s', summary_message)
    if not records:
        if stats['quarantined']:
            raise OnlineSourceError(
                'empty_data',
                '页面已获取，但没有有效记录；其中 %d 条因期号年份与开奖日期不一致被隔离'
                % stats['quarantined'])
        raise OnlineSourceError('empty_data')
    return records, warnings, stats


def parse_single_json(text, url, source_type='generic_json'):
    """解析只有单条开奖记录的 JSON（如个别 API 只返回最新一期）"""
    try:
        payload = json.loads(text)
    except ValueError as exc:
        raise OnlineSourceError('parse_failed', '不是合法 JSON：%s' % exc)
    candidates = []
    if isinstance(payload, dict):
        for key in ('data', 'result', 'record', 'lottery'):
            value = payload.get(key)
            if isinstance(value, dict):
                candidates.append(value)
            elif isinstance(value, list):
                candidates.extend([x for x in value if isinstance(x, dict)])
        if not candidates and any(k in payload for k in ('expect', 'openCode', 'issue')):
            candidates.append(payload)
    elif isinstance(payload, list):
        candidates.extend([x for x in payload if isinstance(x, dict)])
    records = []
    for row in candidates:
        numbers = _split_numbers(row.get('openCode') or row.get('code') or row.get('numbers'))
        record = _build_record(
            row.get('expect') or row.get('issue') or row.get('period'),
            _normalize_date(row.get('openTime') or row.get('date')),
            numbers, source_type, url)
        if record:
            records.append(record)
    if not records:
        raise OnlineSourceError('empty_data')
    return records, [], _empty_parse_stats()


# ============================================================================
# 解析：通用 JSON
# ============================================================================
_PERIOD_KEYS = ('expect', 'issue', 'period', 'qishu', 'qi', '期号', '期數', '期数')
_DATE_KEYS = ('openTime', 'open_time', 'drawDate', 'draw_date', 'date', '日期', '开奖时间')
_CODE_KEYS = ('openCode', 'open_code', 'code', 'numbers', 'num', 'result', '号码', '开奖号码')


def _pick(row, keys):
    """按候选键顺序取第一个非空值"""
    for key in keys:
        value = row.get(key)
        if value not in (None, ''):
            return value
    return None


def _find_record_lists(obj):
    """递归找出“看起来像开奖记录列表”的数组"""
    found = []
    stack = [obj]
    while stack:
        current = stack.pop()
        if isinstance(current, list):
            dicts = [x for x in current if isinstance(x, dict)]
            if dicts and any(_pick(x, _PERIOD_KEYS) for x in dicts):
                found.append(dicts)
            for item in current:
                if isinstance(item, (list, dict)):
                    stack.append(item)
        elif isinstance(current, dict):
            for value in current.values():
                if isinstance(value, (list, dict)):
                    stack.append(value)
    return found


def parse_generic_json(text, url, source_type='generic_json'):
    """解析通用 JSON：递归寻找含期号字段的记录数组，兼容常见别名"""
    try:
        payload = json.loads(text)
    except ValueError as exc:
        raise OnlineSourceError('parse_failed', '不是合法 JSON：%s' % exc)
    lists = _find_record_lists(payload)
    if not lists:
        raise OnlineSourceError('empty_data')
    records, warnings = [], []
    for rows in lists:
        for row in rows:
            numbers = _split_numbers(_pick(row, _CODE_KEYS))
            record = _build_record(
                _pick(row, _PERIOD_KEYS),
                _normalize_date(_pick(row, _DATE_KEYS)),
                numbers, source_type, url)
            if record is None:
                continue
            records.append(record)
    if not records:
        raise OnlineSourceError('empty_data')
    return records, warnings, _empty_parse_stats()


# ============================================================================
# 解析：通用 HTML
# ============================================================================
class _TableCollector(HTMLParser):
    """标准库兜底：收集所有 <table> 的行文本（每个单元格一个字符串）"""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows = []
        self._row = None
        self._cell = None
        self._depth = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag == 'table':
            self._depth += 1
        elif tag == 'tr':
            self._row = []
        elif tag in ('td', 'th') and self._row is not None:
            self._cell = []

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag == 'table':
            self._depth = max(0, self._depth - 1)
        elif tag in ('td', 'th') and self._cell is not None and self._row is not None:
            self._row.append(''.join(self._cell).strip())
            self._cell = None
        elif tag == 'tr' and self._row is not None:
            if any(x for x in self._row):
                self.rows.append(self._row)
            self._row = None

    def handle_data(self, data):
        if self._cell is not None:
            self._cell.append(data)


def _rows_from_html(text):
    """优先 lxml 提取表格行，缺失时回退 html.parser"""
    if _lxml_html is not None:
        try:
            doc = _lxml_html.fromstring(text)
            rows = []
            for table in doc.iter('table'):
                for tr in table.iter('tr'):
                    cells = []
                    for cell in tr.iter('td', 'th'):
                        text_value = cell.text_content().strip()
                        if text_value:
                            cells.append(text_value)
                    if cells:
                        rows.append(cells)
            if rows:
                return rows
        except Exception:
            pass
    collector = _TableCollector()
    collector.feed(text)
    return collector.rows


def parse_generic_html(text, url, source_type='generic_html'):
    """解析通用结果表格 HTML：按“期号 + 日期 + 7 个号码”识别每一行

    识别规则:
        行内至少出现 7 个 1..49 的号码；期号取 4 位以上连续数字；
        日期取 YYYY-MM-DD / YYYY/MM/DD / YYYY年MM月DD日。
        年份（如 2026）会因大于 49 被排除在号码之外。

    异常:
        unknown_site：页面里没有表格或结果表特征；
        empty_data：有表格但没有任何一行满足“期号 + 7 个号码”。
    """
    rows = _rows_from_html(text)
    if not rows:
        raise OnlineSourceError('unknown_site')
    records = []
    for cells in rows:
        joined = ' '.join(cells)
        # 先剔除日期，避免把 2026-11-03 里的 11、03 误当号码；再剔除 3 位以上数字串（期号/年份）
        cleaned = re.sub(r'\d{4}[-/.]\d{1,2}[-/.]\d{1,2}', ' ', joined)
        cleaned = re.sub(r'\d{4}年\d{1,2}月\d{1,2}日', ' ', cleaned)
        numbers = []
        for token in re.split(r'[^\d]+', cleaned):
            if token and len(token) <= 2:
                value = int(token)
                if 1 <= value <= 49:
                    numbers.append(value)
        if len(numbers) < 7:
            continue
        date = _normalize_date(joined)
        period = None
        for cell in cells:
            match = re.search(r'\d{5,}', cell)
            if match:
                period = match.group(0)
                break
        if not period:
            continue
        record = _build_record(period, date, numbers[:7], source_type, url)
        if record:
            records.append(record)
    if not records:
        raise OnlineSourceError('empty_data')
    return records, [], _empty_parse_stats()


def parse_payload(source_type, text, url, content_type=None, status=None):
    """按识别出的站点类型分派解析器

    参数:
        source_type (str): detect_source() 的返回值。
        text (str): 响应原文。
        url (str): 来源地址。
        content_type (str|None): 响应头 Content-Type，仅用于拦截判定文案。
        status (int|None): HTTP 状态码，仅用于拦截判定文案。

    返回:
        (list[dict], list[str], dict)：记录、警告、解析统计（含 quarantined 隔离条数）。

    异常:
        OnlineSourceError：blocked_html（JSON 接口返回 HTML/非 JSON 正文，典型为
        Cloudflare 挑战页）/ unknown_site / empty_data / parse_failed。
        注意：只有「正文以 { 或 [ 开头但 JSON 非法」才走 parse_failed。
    """
    if source_type in ('macau_json', 'hkjc_json', 'generic_json') and not _is_json_text(text):
        # JSON 接口却拿到 HTML/纯文本：判定为拦截，不进入 json.loads，
        # 避免把挑战页误报成「解析失败：不是合法 JSON」
        raise _blocked_html_error(status, content_type, text)
    if source_type in ('macau_json', 'hkjc_json'):
        return parse_macau_json(text, url, source_type)
    if source_type == 'generic_json':
        try:
            return parse_generic_json(text, url)
        except OnlineSourceError:
            return parse_single_json(text, url)
    if source_type in ('generic_html', 'hkjc_html'):
        return parse_generic_html(text, url, 'hkjc_html' if source_type == 'hkjc_html' else 'generic_html')
    raise OnlineSourceError('unknown_site')


# ============================================================================
# 归一化 / 去重 / 摘要 / 对比
# ============================================================================
def dedupe_records(records):
    """按期号去重（同一 source + source_period 只留后出现的一条）

    参数:
        records (list[dict]): 已归一化记录。

    返回:
        (list[dict], int): 去重后的列表（按日期、期号倒序）与被移除条数。
    """
    seen = {}
    removed = 0
    for record in records:
        key = (record.get('source'), record.get('source_period'))
        if key in seen:
            removed += 1
        seen[key] = record
    unique = sorted(seen.values(), key=lambda r: (r.get('draw_date', ''), r.get('source_period', '')),
                    reverse=True)
    return unique, removed


def summarize(records, warnings=None):
    """汇总期数、起止日期与警告条数（供摘要条与跑测断言使用）"""
    if not records:
        return {'count': 0, 'range_start': '', 'range_end': '', 'warnings': list(warnings or [])}
    dates = [r.get('draw_date', '') for r in records if r.get('draw_date')]
    return {
        'count': len(records),
        'range_start': min(dates) if dates else '',
        'range_end': max(dates) if dates else '',
        'warnings': list(warnings or []),
    }


def _local_date(record):
    """读取本地记录的日期字段并归一成 ISO（兼容 date / draw_date 两种历史口径）

    说明:
        录入链会产出「2026年11月04日」「2026/11/04」等写法；不归一会导致同日记录
        匹配不上，进而同时计入 online_only 与 local_only。无法识别的日期返回空串，
        由调用方按「无日期」处理（同期对照另有 local_anomalies 统计，不静默）。
    """
    raw = (record or {}).get('date') or (record or {}).get('draw_date') or ''
    if not raw:
        return ''
    try:
        return normalize_date(raw)
    except (TypeError, ValueError):
        return ''


def _same_content(online, local):
    """判断在线与本地同一期的号码是否完全一致（正码按集合比，特别码单独比）"""
    online_numbers = [int(n) for n in (online.get('numbers') or [])]
    local_numbers = [int(n) for n in (local.get('numbers') or [])]
    try:
        online_special = int(online.get('special'))
        local_special = int(local.get('special'))
    except (TypeError, ValueError):
        return False
    return sorted(online_numbers) == sorted(local_numbers) and online_special == local_special


def _conflict_side(online, local):
    """判定冲突两侧哪边更新（只能按日期：同日即无法判定先后）"""
    online_date = str(online.get('draw_date') or '')
    local_date = _local_date(local)
    if online_date > local_date:
        return 'online'
    if online_date < local_date:
        return 'local'
    return 'same'


def compare_with_local(online_records, local_records):
    """只读对比在线与本地历史，返回三类差异明细（绝不合并、绝不写入）

    对齐口径:
        以开奖日期为唯一对齐键。本地 period 是本地自增序号，不是源站期号，
        不能与在线 source_period 直接比较（见同期对照设计稿 §2.3）。

    参数:
        online_records (list[dict]): 在线记录（含 source_period / draw_date /
            numbers / special / fetched_at）。
        local_records (list[dict]): 本地历史记录（含 period / date / numbers /
            special）。

    返回:
        dict:
            online / local / date_hits / number_matches —— 既有汇总口径，保持兼容；
            online_only  —— 仅在线有（本地没有该日期）；
            conflicts    —— 双方同日但号码或特别码不同；
            local_only   —— 仅本地有（在线没有该日期）；
            online_only_count / conflict_count / local_only_count；
            local_latest_date —— 本地最新开奖日期（无本地数据时为空串）；
            local_valid_count / local_anomaly_count / local_anomalies ——
                本地记录中可对齐条数与异常明细（日期/号码非法等），异常不静默剔除。

    说明:
        online_only 项带 newer=True 表示日期晚于本地最新日期（由 select_newer 判定），
        即“在线新增”；newer=False 表示早于本地最新日期，属于“在线补录”。
        冲突项 newer_side 只能是 same/online/local；同日冲突恒为 same。
    """
    online_records = list(online_records or [])
    from lib.same_period import filter_records, normalize_local_record
    local_valid, local_anomalies = filter_records(
        list(local_records or []), normalize_local_record)
    local_by_date = {}
    for record in local_valid:
        date = record.get('date')
        if date and date not in local_by_date:
            local_by_date[date] = record

    online_by_date = {}
    for record in online_records:
        date = _local_date(record)
        if date and date not in online_by_date:
            online_by_date[date] = record

    # 复用 select_newer：只有日期晚于本地最新日期的在线记录才算“在线新增”
    newer_keys = {(r.get('source'), r.get('source_period'))
                  for r in select_newer(online_records, local_records)}
    latest_local_date = max(local_by_date.keys()) if local_by_date else ''

    online_only, conflicts, local_only = [], [], []
    number_matches = 0
    for date, online in online_by_date.items():
        local = local_by_date.get(date)
        if local is None:
            online_only.append({
                'date': date,
                'online_period': str(online.get('source_period') or ''),
                'online_numbers': [int(n) for n in (online.get('numbers') or [])],
                'online_special': online.get('special'),
                'online_fetched_at': str(online.get('fetched_at') or ''),
                'newer': (online.get('source'), online.get('source_period')) in newer_keys,
            })
            continue
        if _same_content(online, local):
            number_matches += 1
            continue
        conflicts.append({
            'date': date,
            'online_period': str(online.get('source_period') or ''),
            'local_period': local.get('period'),
            'online_numbers': [int(n) for n in (online.get('numbers') or [])],
            'online_special': online.get('special'),
            'local_numbers': [int(n) for n in (local.get('numbers') or [])],
            'local_special': local.get('special'),
            'newer_side': _conflict_side(online, local),
        })
    for date, local in local_by_date.items():
        if date not in online_by_date:
            local_only.append({
                'date': date,
                'local_period': local.get('period'),
                'local_numbers': [int(n) for n in (local.get('numbers') or [])],
                'local_special': local.get('special'),
            })

    for items in (online_only, conflicts, local_only):
        items.sort(key=lambda item: item.get('date', ''), reverse=True)

    return {
        'online': len(online_records),
        'local': len(local_records or []),
        'local_valid_count': len(local_valid),
        'local_anomaly_count': len(local_anomalies),
        'local_anomalies': local_anomalies,
        'date_hits': number_matches + len(conflicts),
        'number_matches': number_matches,
        'online_only': online_only,
        'conflicts': conflicts,
        'local_only': local_only,
        'online_only_count': len(online_only),
        'conflict_count': len(conflicts),
        'local_only_count': len(local_only),
        'local_latest_date': latest_local_date,
    }


def select_newer(online_records, local_records):
    """返回在线记录中日期晚于本地最新开奖日期的部分（只读，不写任何一侧）

    参数:
        online_records (list[dict]): 在线记录。
        local_records (list[dict]): 本地历史记录。

    返回:
        list[dict]: 在线记录中 draw_date 严格大于本地最新日期的子集。
    """
    local_dates = [_local_date(record) for record in (local_records or [])]
    latest = max([d for d in local_dates if d] or [''])
    return [record for record in (online_records or [])
            if (_local_date(record) or '') > latest]
