# -*- coding: utf-8 -*-
"""
===========================================================================
lib/data_process.py - 配置常量、数据工具
===========================================================================
模块职责：
    1. 集中声明全系统的静态配置与常量（窗口尺寸、字号档位、分隔符、
       红蓝绿三色波号码、生肖分组、五行映射、区间划分、23 项算法清单）
    2. 提供与业务数据格式相关的纯函数工具（网页 HTML 转纯文本、
       期号规范化、开奖原始数据解析、标准格式输出、样例数据生成）
    3. D1–D4 统计分析纯函数（图表频次/遗漏/分布/共现、第七位预判、
       回测命中率、共现矩阵），供 TAB 页面取数后直接绘图或展示

在架构中的位置：
    本模块位于 lib/ 纯逻辑层的最底层，不依赖其他 lib 子模块，
    被 plugins/（算法插件）与 TAB/（功能选项卡）共同依赖，属于“公共基础层”。
    模块只处理字符串/整数/字典等基础类型，不涉及 Qt 与数据库。

依赖：
    - 仅标准库：re、datetime、random、warnings（及函数内局部导入的 html、unicodedata）
    - 不依赖 numpy/pandas 等重型库，保证任何模块都能零成本导入

主要导出对象：
    LotteryConfig   —— 全部业务常量与号码属性判定（颜色/单双/大小/区间/生肖）
    DataUtils       —— 数据清洗、解析、格式化、样例数据生成
    统计函数         —— compute_* / build_* / summarize_*（D1–D4，见文件末尾）

约束：禁止任何 Qt 界面代码；重型库按需导入。
===========================================================================
"""

import re  # 作用说明：正则清洗与解析：去 HTML 标签、抽日期/期号、按 \d+ 切分号码
import datetime  # 作用说明：缺失日期用今天兜底（date.today）、样例数据按期倒推日期（timedelta）
import random  # 作用说明：generate_sample_data 用 random.sample 抽取每期 7 个不重复号码
import warnings  # 作用说明：模块导入时屏蔽 FutureWarning / DeprecationWarning 噪声
from collections import Counter, defaultdict  # 作用说明：Counter 统计特别码频次；defaultdict(Counter) 累计“正码→特别码”共现计数

warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)

# 算法注册表（唯一来源）：算法名称/描述/编号/调度全部在 lib/algorithms.py 定义，
# 本模块只把它派生成历史沿用的 (名称, 描述) 元组列表，避免两份清单分叉
from lib.algorithms import ALGORITHM_DEFS as _ALGORITHM_DEFS  # 作用说明：算法注册表唯一来源，在类体中派生成 LotteryConfig.ALGORITHMS 的 (名称, 描述) 列表
# 回测口径判定统一走注册表：is_special_algorithm 判断“是否特别码专项算法”，
# get_output_count 给出该算法每期实际输出的号码个数（常规 6 / 特别码 1）
from lib.algorithms import get_output_count, is_special_algorithm  # 作用说明：get_output_count 提供回测每期分母（常规 6 / 特别码 1）；is_special_algorithm 判定是否特别码专项算法


# ==========================================================================
# 全局配置与常量
# ==========================================================================


class LotteryConfig:
    """
    彩票配置类 - 定义所有全局配置和常量

    职责：
        作为全系统的“只读配置中心”，把界面尺寸、字体档位、输出分隔符、
        号码颜色/生肖/五行/区间属性以及算法清单集中在一处，
        UI 层与 plugins/ 算法层都从这里取值，避免同一常量在多处硬编码。

    本系统使用香港六合彩（Mark Six）的规则：
    - 49个数字（01-49）
    - 每次开奖7个数字（前6个为正码，第7个为特别码）
    - 数字分为三种颜色：红、蓝、绿

    关键属性：
        NUMBER_COLORS / NUMBER_NAMES / NUMBER_ELEMENTS —— 号码的三类派生属性
        RED_NUMBERS / BLUE_NUMBERS / GREEN_NUMBERS       —— 三色波原始名单
        NUMBER_GROUPS                                    —— 按 n%12 分成的 12 组（生肖基数）
        RANGES                                           —— 5 个区间，供区间分布分析
        ALGORITHMS                                       —— (算法名, 描述) 元组列表，共 23 项
        FONT_SIZES / TEXT_MAX_PX 等                      —— 界面尺寸与字号规范

    生命周期/线程约束：
        全部为类属性与 @classmethod，无实例状态，可被任意线程只读并发访问；
        但 NUMBER_COLORS/NUMBER_NAMES 是以类体代码块构建的普通 dict，
        若调用方原地修改会全局生效，应视为只读。

    【可改】大部分常量都可以根据需要调整，
    如窗口尺寸、颜色方案、算法列表、生肖五行绑定等
    """
    
    # ===== 窗口设置 =====
    WINDOW_TITLE = "系统v7.5"  # 【可改】窗口标题
    WINDOW_MIN_WIDTH = 1180   # 【可改】窗口最小宽度（保证顶部工具栏与选项卡不重叠）
    WINDOW_MIN_HEIGHT = 720   # 【可改】窗口最小高度
    
    # ===== 界面尺寸规范（v0.0.19）=====
    # 【规范】所有像素尺寸不得超过上限，避免大字体/大按钮撑破布局
    TEXT_MAX_PX = 150            # 文字最大字号（px）
    BUTTON_MAX_WIDTH = 300       # 按钮最大宽度（px）
    BUTTON_MAX_HEIGHT = 300      # 按钮最大高度（px）
    BUTTON_DEFAULT_WIDTH = 80    # 按钮默认宽度（px）
    BUTTON_DEFAULT_HEIGHT = 60   # 按钮默认高度（px）
    TEXT_DEFAULT_PX = 20         # 文字默认字号（px）

    # ===== 字体大小选项 =====
    # 【可改】字体大小选项列表，用于字体大小调整菜单
    # v0.0.36：最小字号硬性下限 15px（防止文字过小看不清），故最小档位「小四」由 12 抬到 15
    FONT_SIZES = {
        '小四': 15, '三号': 16, '小二': 18, '标准': 20,
        '二号': 22, '小一': 24, '一号': 26, '小初': 36, '初号': 42,
    }
    DEFAULT_FONT_SIZE_KEY = '标准'  # 【可改】默认字体大小（20px）

    # ===== 多格式分隔符（结果输出 + 文本输入解析统一口径） =====
    # 【规范】顺序保持稳定：前 11 项为历史顺序（INI 记忆索引兼容），后 4 项为 v0.0.19 新增
    RESULT_SEPARATORS = [
        ("空格", " "),
        ("英文逗号（,）", ","),
        ("顿号（、）", "、"),
        ("分号（;）", ";"),
        ("减号（-）", "-"),
        ("正斜杠（/）", "/"),
        ("竖线（|）", "|"),
        ("换行（\\n）", "\n"),
        ("中文逗号（，）", "，"),
        ("中文句号（。）", "。"),
        ("英文句号（.）", "."),
        ("加号（+）", "+"),
        ("反斜杠（\\）", "\\"),
        ("波浪号（~）", "~"),
        ("井号（#）", "#"),
    ]
    
    # ===== 号码颜色分组（六合彩三色波） =====
    # 【可改】红波号码列表
    RED_NUMBERS = [1, 2, 7, 8, 12, 13, 18, 19, 23, 24, 29, 30, 34, 35, 40, 45, 46]
    # 【可改】蓝波号码列表
    BLUE_NUMBERS = [3, 4, 9, 10, 14, 15, 20, 25, 26, 31, 36, 37, 41, 42, 47, 48]
    # 【可改】绿波号码列表
    GREEN_NUMBERS = [5, 6, 11, 16, 17, 21, 22, 27, 28, 32, 33, 38, 39, 43, 44, 49]
    
    # 号码颜色映射（白底彩色边框）
    NUMBER_COLORS = {}
    for num in RED_NUMBERS:
        NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": "#FF0000", "border": "#FF0000"}
    for num in BLUE_NUMBERS:
        NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": "#0000FF", "border": "#0000FF"}
    for num in GREEN_NUMBERS:
        NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": "#008000", "border": "#008000"}
    
    # ===== 生肖配置 =====
    # 生肖顺时针顺序: 龙→兔→虎→牛→鼠→猪→狗→鸡→猴→羊→马→蛇
    # 12组数字(同余12): {01,13,25,37,49}{02,14,26,38}...{12,24,36,48}
    # 默认: 龙=组1, 兔=组2, 虎=组3, 牛=组4, 鼠=组5, 猪=组6, 狗=组7, 鸡=组8, 猴=组9, 羊=组10, 马=组11, 蛇=组12
    ZODIAC_CLOCKWISE = ["龙", "兔", "虎", "牛", "鼠", "猪", "狗", "鸡", "猴", "羊", "马", "蛇"]
    
    # 12组数字，按同余12分组（n%12的结果）
    # 注意：分组依据是号码除以 12 的余数，组1~组11 对应余数 1~11，
    # 组12 对应余数 0（即 12、24、36、48 这些 12 的倍数），写成 n%12==12 不成立。
    NUMBER_GROUPS = [
        [1, 13, 25, 37, 49],  # 组1: n%12==1（含 49，是 49 个号码里唯一有 5 个元素的组）
        [2, 14, 26, 38],      # 组2: n%12==2
        [3, 15, 27, 39],      # 组3: n%12==3
        [4, 16, 28, 40],      # 组4: n%12==4
        [5, 17, 29, 41],      # 组5: n%12==5
        [6, 18, 30, 42],      # 组6: n%12==6
        [7, 19, 31, 43],      # 组7: n%12==7
        [8, 20, 32, 44],      # 组8: n%12==8
        [9, 21, 33, 45],      # 组9: n%12==9
        [10, 22, 34, 46],     # 组10: n%12==10
        [11, 23, 35, 47],     # 组11: n%12==11
        [12, 24, 36, 48],     # 组12: n%12==0（12 的倍数）
    ]
    
    @classmethod
    def generate_zodiac_binding(cls, start_zodiac="龙"):
        """根据起始生肖生成49个数字的生肖绑定（顺时针排列）

        功能：
            以 start_zodiac 对应 NUMBER_GROUPS 的第 1 组（n%12==1），
            按 ZODIAC_CLOCKWISE 的环形顺序依次绑定第 1~12 组号码，
            生成覆盖 1~49 的 {号码: 生肖名} 映射。

        参数:
            start_zodiac (str): 起始生肖名称，必须存在于 ZODIAC_CLOCKWISE，
                它对应组1（即 n%12==1 的那组号码）。默认 "龙"。
        返回:
            dict[int, str]: {号码: 生肖名}，键覆盖 1~49 全部号码；
                组1 绑 start_zodiac，组2 绑顺时针下一生肖，依此类推。
        异常:
            ValueError: start_zodiac 不在 ZODIAC_CLOCKWISE 中时，list.index() 抛出。
        注意:
            本函数按“输入起始生肖”动态生成绑定，不修改类属性 NUMBER_NAMES；
            类体里另有一段等价代码以 "龙" 为默认起始生成 NUMBER_NAMES。
        """
        idx = cls.ZODIAC_CLOCKWISE.index(start_zodiac)
        binding = {}
        for group_idx in range(12):
            zodiac = cls.ZODIAC_CLOCKWISE[(idx + group_idx) % 12]
            for num in cls.NUMBER_GROUPS[group_idx]:
                binding[num] = zodiac
        return binding

    # ===== 历史记录生肖快照 =====
    # 背景：历史详情原先用“当前生效的 NUMBER_NAMES”实时推算生肖，用户改绑某个号码后，
    # 往期开奖的生肖会被追溯改写。这里把“写入时刻的当前绑定”固化成记录字段，展示时优先读它。
    # 字段约定（只新增、不改动既有字段）：
    #   record['zodiacs']         : list[str]，与 record['numbers'] 按下标一一对应；
    #   record['special_zodiac']  : str，特别码对应的生肖。
    # 两字段缺失或长度不一致即视为“旧数据无快照”，展示时回退当前绑定并明确标注来源。
    # 口径限制：快照记录的是“写入时刻的绑定”，不是“开奖日期所在农历年的当年映射”（本轮不做年份维度）。
    ZODIAC_SNAPSHOT_FIELDS = ('zodiacs', 'special_zodiac')

    @staticmethod
    def _binding_lookup(binding, number):
        """从生肖绑定字典里取某个号码的生肖（兼容 int 键与 str 键）

        参数:
            binding (dict|None): {号码: 生肖名}，键可能是 int 也可能是 str（JSON 读入后为 str）。
            number (int): 待查号码。
        返回:
            str: 生肖名；字典为空或未命中时返回空字符串。
        """
        if not binding:
            return ''
        # 归一化为 int：导入数据里的号码可能是 "05" 这类字符串，绑定键则可能是 int 或 "5"
        try:
            number = int(number)
        except (TypeError, ValueError):
            return ''
        if number in binding:
            return binding[number] or ''
        key = str(number)
        if key in binding:
            return binding[key] or ''
        return ''

    @classmethod
    def has_zodiac_snapshot(cls, record):
        """判断一条历史记录是否带有完整、可用的生肖快照

        功能:
            校验 record['zodiacs'] 是列表、长度与 record['numbers'] 一致、
            且每一项都是非空字符串；同时 record['special_zodiac'] 为非空字符串。
            任一条件不满足都视为“无快照”，避免把残缺数据伪装成历史快照。

        参数:
            record (dict): 历史记录字典。
        返回:
            bool: True 表示快照完整可用。
        """
        if not isinstance(record, dict):
            return False
        numbers = record.get('numbers')
        zodiacs = record.get('zodiacs')
        special_zodiac = record.get('special_zodiac')
        if not isinstance(numbers, list) or not numbers:
            return False
        if not isinstance(zodiacs, list) or len(zodiacs) != len(numbers):
            return False
        if not all(isinstance(z, str) and z for z in zodiacs):
            return False
        return isinstance(special_zodiac, str) and bool(special_zodiac)

    @classmethod
    def build_zodiac_snapshot(cls, numbers, special, binding):
        """按给定绑定生成一条记录的生肖快照取值

        参数:
            numbers (list[int]): 正码列表（保持记录中的原始顺序）。
            special (int): 特别码。
            binding (dict): 当前生效的 {号码: 生肖名}。
        返回:
            tuple[list[str], str, bool]:
                (正码生肖列表, 特别码生肖, 是否完整)。
                只要有一个号码取不到生肖，第三项为 False，调用方不应写入快照。
        """
        zodiacs = [cls._binding_lookup(binding, n) for n in (numbers or [])]
        special_zodiac = cls._binding_lookup(binding, special)
        complete = bool(zodiacs) and all(zodiacs) and bool(special_zodiac)
        return zodiacs, special_zodiac, complete

    @classmethod
    def attach_zodiac_snapshot(cls, record, binding):
        """给一条历史记录补写生肖快照（已有完整快照时绝不覆盖）

        功能:
            在“开奖记录写入时刻”调用：用当前绑定把该期号码的生肖固化成
            record['zodiacs'] / record['special_zodiac']。
            幂等：已存在完整快照的记录直接跳过，保证重复回填结果一致。

        参数:
            record (dict): 待写入的历史记录（原地修改）。
            binding (dict): 当前生效的 {号码: 生肖名}。
        返回:
            bool: True 表示本次写入了快照；False 表示已有快照或数据不完整（未写入）。
        """
        if not isinstance(record, dict) or cls.has_zodiac_snapshot(record):
            return False
        numbers = record.get('numbers') or []
        special = record.get('special', 0)
        zodiacs, special_zodiac, complete = cls.build_zodiac_snapshot(numbers, special, binding)
        if not complete:
            return False
        record['zodiacs'] = zodiacs
        record['special_zodiac'] = special_zodiac
        return True

    @classmethod
    def ensure_zodiac_snapshots(cls, records, binding):
        """批量补写生肖快照（幂等、可重复运行、不覆盖已有快照）

        功能:
            遍历历史记录，对所有“缺快照”的记录调用 attach_zodiac_snapshot()。
            已有完整快照的记录原样保留；绑定取不到生肖的记录保持缺快照状态，
            展示时仍走“当前绑定实时推算”的回退路径。

        参数:
            records (list[dict]): 历史记录列表（原地修改）。
            binding (dict): 当前生效的 {号码: 生肖名}。
        返回:
            dict: 统计信息，键如下：
                total          —— 记录总数
                filled         —— 本次补写成功的记录数
                skipped_existing —— 已有完整快照而跳过的记录数
                skipped_incomplete —— 绑定不完整、无法补写的记录数
                remaining      —— 跑完后仍缺快照的记录数
        """
        stats = {'total': 0, 'filled': 0, 'skipped_existing': 0, 'skipped_incomplete': 0, 'remaining': 0}
        for record in records or []:
            stats['total'] += 1
            if cls.has_zodiac_snapshot(record):
                stats['skipped_existing'] += 1
                continue
            if cls.attach_zodiac_snapshot(record, binding):
                stats['filled'] += 1
            else:
                stats['skipped_incomplete'] += 1
        stats['remaining'] = stats['skipped_incomplete']
        return stats

    @classmethod
    def resolve_record_zodiacs(cls, record, binding):
        """解析一条历史记录展示用的生肖（快照优先，缺失时回退当前绑定）

        参数:
            record (dict): 历史记录字典。
            binding (dict): 当前生效的 {号码: 生肖名}，仅在缺快照时使用。
        返回:
            tuple[list[str], str, bool]:
                (正码生肖列表, 特别码生肖, 是否来自历史快照)。
                第三项为 False 时表示该期无快照、按当前绑定实时推算，界面须如实标注。
        """
        if cls.has_zodiac_snapshot(record):
            return list(record['zodiacs']), record['special_zodiac'], True
        numbers = record.get('numbers') or []
        special = record.get('special', 0)
        zodiacs, special_zodiac, _ = cls.build_zodiac_snapshot(numbers, special, binding)
        return zodiacs, special_zodiac, False

    # 默认生肖绑定（以龙为起始）
    # 类体里的这段构建代码与 generate_zodiac_binding("龙") 等价，
    # 之所以在类体中直接展开，是为了在类定义阶段就得到 NUMBER_NAMES，
    # 供模块导入后立即使用（无需实例化或额外调用）。
    NUMBER_NAMES = {}
    _default_start = ZODIAC_CLOCKWISE.index("龙")   # 龙的索引为 0，用变量保存便于未来改起始生肖
    for _gidx in range(12):
        # (索引 + 组号) % 12 实现环形顺延：越界后回到列表开头
        _zodiac = ZODIAC_CLOCKWISE[(_default_start + _gidx) % 12]
        for _n in NUMBER_GROUPS[_gidx]:
            NUMBER_NAMES[_n] = _zodiac
    
    # ===== 五行配置 =====
    # 【可改】数字与五行的对应关系
    # 这里按号码逐个穷举，没有可按公式推导的简单周期：
    # 例如 1、2 为金，但 11、12 为木，所以不能用「每 10 个号码循环」来理解。
    # 该对应关系属于业务给定配置，直接查表使用；映射依据与版本来源
    # TODO(待确认): 五行对应表的具体依据（年份变化/流派差异）未在代码中说明。
    NUMBER_ELEMENTS = {
        1: "金", 2: "金", 3: "木", 4: "木", 5: "水", 6: "水", 7: "火", 8: "火",
        9: "土", 10: "土", 11: "木", 12: "木", 13: "水", 14: "水", 15: "金", 16: "金",
        17: "火", 18: "火", 19: "土", 20: "土", 21: "木", 22: "木", 23: "水", 24: "水",
        25: "金", 26: "金", 27: "火", 28: "火", 29: "土", 30: "土", 31: "木", 32: "木",
        33: "水", 34: "水", 35: "金", 36: "金", 37: "火", 38: "火", 39: "土", 40: "土",
        41: "木", 42: "木", 43: "水", 44: "水", 45: "金", 46: "金", 47: "火", 48: "火", 49: "土"
    }
    # 出厂只读副本：NUMBER_ELEMENTS 会被界面原地 update，恢复默认时必须从这里取
    DEFAULT_NUMBER_ELEMENTS = dict(NUMBER_ELEMENTS)
    
    # ===== 区间划分 =====
    # 【可改】数字区间划分，用于区间分布分析
    # 每个元素为 (下界, 上界, 区间名)，闭区间；注意 1-9 区只有 9 个号码，
    # 其余 4 个区间各 10 个，做等概率假设时不能按“每区 10 个”计算。
    RANGES = [
        (1, 9, "1-9区"), (10, 19, "10-19区"), (20, 29, "20-29区"),
        (30, 39, "30-39区"), (40, 49, "40-49区"),
    ]
    
    # ===== 算法列表 =====
    # 【只读派生】格式仍为 (算法名称, 算法描述)，但内容来自 lib/algorithms.py 注册表。
    # 列表下标同时是算法编号：界面下拉框按本顺序展示，
    # PredictionAlgorithms.get_prediction_scores 按同一编号分派到具体算法，
    # 因此新增算法必须同时更新注册表与该方法的分派，否则编号会整体错位。
    # 共 23 项：前 21 项为通用算法，最后 2 项为特别码专项算法（只预测 1 个特别码）。
    # 【唯一来源】算法清单由 lib/algorithms.py 注册表派生，禁止在此手写第二份：
    # 新增算法请改注册表，下拉框/回测/预测页会自动同步名称、描述与编号
    ALGORITHMS = [(_algo.name, _algo.description) for _algo in _ALGORITHM_DEFS]
    
    @classmethod
    def get_number_color(cls, number):
        """获取指定号码的颜色配置

        功能：
            从类属性 NUMBER_COLORS 读取号码的三色波配色（白底 + 红/蓝/绿字与边框），
            供界面给号码格子上色。

        参数:
            number (int): 号码（1-49）
        返回:
            dict: {"bg": 背景色, "text": 文字色, "border": 边框色}；
                号码不在 1-49 时返回白底黑字灰框的兜底配色，不抛异常。

        注意：
            不做范围校验，未配置的号码走兜底配色；
            返回的是 NUMBER_COLORS 内的 dict 引用，调用方原地修改会全局生效。
        """
        return cls.NUMBER_COLORS.get(number, {"bg": "#FFFFFF", "text": "#000000", "border": "#CCCCCC"})
    
    @classmethod
    def is_red(cls, number):
        """判断号码是否为红波

        功能：
            按 RED_NUMBERS 名单判断号码是否属于红波（业务给定名单，非公式推导）。

        参数:
            number (int): 号码
        返回:
            bool: 在 RED_NUMBERS 名单中返回 True。

        注意：
            只做名单成员判断，不做 1-49 范围校验，0/50 等越界值返回 False；
            名单是类属性，运行时被替换后判定结果随之变化。
        """
        return number in cls.RED_NUMBERS
    
    @classmethod
    def is_blue(cls, number):
        """判断号码是否为蓝波

        功能：
            按 BLUE_NUMBERS 名单判断号码是否属于蓝波（业务给定名单，非公式推导）。

        参数:
            number (int): 号码
        返回:
            bool: 在 BLUE_NUMBERS 名单中返回 True。

        注意：
            只做名单成员判断，不做 1-49 范围校验，0/50 等越界值返回 False；
            名单是类属性，运行时被替换后判定结果随之变化。
        """
        return number in cls.BLUE_NUMBERS
    
    @classmethod
    def is_green(cls, number):
        """判断号码是否为绿波

        功能：
            按 GREEN_NUMBERS 名单判断号码是否属于绿波（业务给定名单，非公式推导）。

        参数:
            number (int): 号码
        返回:
            bool: 在 GREEN_NUMBERS 名单中返回 True。

        注意：
            只做名单成员判断，不做 1-49 范围校验，0/50 等越界值返回 False；
            名单是类属性，运行时被替换后判定结果随之变化。
        """
        return number in cls.GREEN_NUMBERS
    
    @classmethod
    def is_odd(cls, number):
        """判断号码是否为单数（奇数）

        功能：
            按 number % 2 == 1 判定单数。

        参数:
            number (int): 号码
        返回:
            bool: 除以 2 余 1 返回 True。

        注意：
            不做 1-49 范围校验，负数/越界值也按取模结果判定。
        """
        return number % 2 == 1
    
    @classmethod
    def is_even(cls, number):
        """判断号码是否为偶数

        功能：
            按 number % 2 == 0 判定偶数。

        参数:
            number (int): 号码
        返回:
            bool: 除以 2 余 0 返回 True。

        注意：
            不做 1-49 范围校验，负数/越界值也按取模结果判定。
        """
        return number % 2 == 0
    
    @classmethod
    def is_big(cls, number):
        """判断号码是否为大数

        功能：
            以 25 为界判定大数：number > 25 记为大。

        参数:
            number (int): 号码
        返回:
            bool: number > 25 返回 True。
        注意:
            49 个号码以 25 为界分两半：1~25 为小数（25 个），26~49 为大数（24 个），
            因此大/小两类的个数并不相等，等概率假设下有偏。
        """
        return number > 25
    
    @classmethod
    def is_small(cls, number):
        """判断号码是否为小数

        功能：
            以 25 为界判定小数：number <= 25 记为小，与 is_big 严格互补。

        参数:
            number (int): 号码
        返回:
            bool: number <= 25 返回 True（25 本身算小数，与 is_big 严格互补）。

        注意：
            与 compute_size_distribution 的「>24 记大」口径不同（25 在统计处算大号），
            跨页面比较时不要混用两种分界。
        """
        return number <= 25
    
    @classmethod
    def get_tail_digit(cls, number):
        """获取号码尾数（个位数字）

        功能：
            按 number % 10 取出个位数字（尾数）。

        参数:
            number (int): 号码
        返回:
            int: 0~9 的尾数，例如 13 返回 3、40 返回 0。

        注意：
            不做 1-49 范围校验；负数按 Python 取模语义仍返回 0~9。
        """
        return number % 10
    
    @classmethod
    def get_range_index(cls, number):
        """获取号码所属区间的下标

        功能：
            按 RANGES 的闭区间 [下界, 上界] 顺序查找号码所属区间，返回其下标。

        参数:
            number (int): 号码
        返回:
            int: cls.RANGES 的下标（0~4）；号码不在 1-49 范围内返回 -1。

        注意：
            返回 -1 表示越界/脏数据，调用方需自行过滤
            （compute_range_distribution 即按 idx >= 0 才计数）。
        """
        for i, (start, end, name) in enumerate(cls.RANGES):
            if start <= number <= end:
                return i
        return -1


# ==========================================================================
# 生肖绑定校验（纯函数，无 Qt / 无文件 I/O）
# ==========================================================================


def zodiac_binding_groups(binding):
    """把「号码 → 生肖」绑定反向聚合为「生肖 → 号码列表」

    功能:
        z.validate 的输入是 1~49 的绑定字典（键为 int 或 str），本函数把它转成
        12 个生肖各自包含的号码列表，便于做“是否齐全 / 是否重复 / 数量是否标准”的
        整体校验。列表统一升序，输出稳定，方便对话框逐行渲染与问题文案拼接。

    参数:
        binding (dict): {号码: 生肖名}；键允许 int 或数字字符串，值允许空串。
    返回:
        dict[str, list[int]]: {生肖名: [号码, ...]}；无法转成整数的键会被忽略
        （正常数据不会出现，忽略可避免脏数据让聚合过程抛异常）。

    副作用:
        无（不读写文件、不修改入参）。
    """
    groups = {}
    for key, value in (binding or {}).items():
        try:
            number = int(key)
        except (TypeError, ValueError):
            continue
        zodiac = str(value or '')
        groups.setdefault(zodiac, []).append(number)
    return {name: sorted(numbers) for name, numbers in groups.items()}


def validate_zodiac_groups(groups, allow_nonstandard_counts=False):
    """校验 12 生肖号码分组是否满足完整、不重不漏、数量 5+4×11

    功能:
        对「生肖 → 号码列表」做全量校验，返回人类可读的问题清单。
        空列表代表通过，调用方据此启用「确定」按钮或阻止保存。

    校验规则（硬性）:
        1) 生肖名必须是 LotteryConfig.ZODIAC_CLOCKWISE 中的 12 个之一；
        2) 12 个生肖都必须至少包含 1 个号码；
        3) 每个号码必须是 1~49 的整数；
        4) 1~49 每个号码必须出现且仅出现一次；
        5) 数量必须为 5+4×11：恰好一个生肖 5 个、其余各 4 个。
           该条仅在 allow_nonstandard_counts=False 时启用；勾选“允许非标准数量”
           只放宽第 5 条，第 1~4 条（覆盖性）永远不放宽。

    参数:
        groups (dict[str, list[int]]): {生肖名: [号码, ...]}，通常由
            zodiac_binding_groups() 或对话框逐行解析得到。
        allow_nonstandard_counts (bool): 是否放宽数量配比校验，默认 False。
    返回:
        list[str]: 问题描述列表；无问题时返回空列表。顺序固定（先生肖名/越界，
        再重复/缺失，最后数量），便于界面稳定展示。

    副作用:
        无（不读写文件、不修改入参）。
    """
    expected = list(LotteryConfig.ZODIAC_CLOCKWISE)
    expected_set = set(expected)
    issues = []

    normalized = {}
    for name, numbers in (groups or {}).items():
        name = str(name or '')
        normalized[name] = list(numbers or [])

    # 1) 未知生肖名（例如脏数据写成“馬”或空串）
    for name in sorted(normalized):
        if name not in expected_set:
            label = name if name else '(空生肖名)'
            issues.append("未知生肖：" + label + "（不属于十二生肖）")

    # 2) 12 生肖齐全（空列表视为缺失）
    for name in expected:
        if not normalized.get(name):
            issues.append("生肖缺失：" + name + " 没有任何号码")

    # 3) 号码越界（非整数在解析阶段已被过滤，这里只查范围）
    out_of_range = {}
    for name, numbers in normalized.items():
        bad = [n for n in numbers if not isinstance(n, int) or n < 1 or n > 49]
        if bad:
            out_of_range[name] = bad
    for name, bad in out_of_range.items():
        label = name if name else '(空生肖名)'
        issues.append("号码越界：" + label + " 包含 " + '、'.join(str(n) for n in bad) + "（只允许 1–49）")

    # 4) 重复与遗漏（先按号码统计出现位置）
    owners = {}
    for name, numbers in normalized.items():
        for number in numbers:
            if isinstance(number, int) and 1 <= number <= 49:
                owners.setdefault(number, []).append(name if name else '(空生肖名)')
    duplicates = []
    for number in range(1, 50):
        names = owners.get(number, [])
        if len(names) > 1:
            duplicates.append(number)
            issues.append("号码重复：" + str(number).zfill(2) + " 同时出现在 " + "、".join(names))
    missing = [number for number in range(1, 50) if number not in owners]
    if missing:
        issues.append("号码缺失：" + '、'.join(str(n).zfill(2) for n in missing) + " 未被任何生肖包含")

    # 5) 数量必须 5+4×11（只检查非空生肖，空生肖已在上面报“生肖缺失”）
    #    勾选“允许非标准数量”时整段跳过：覆盖性（1~4 条）不受影响。
    if not allow_nonstandard_counts:
        counts = {name: len(numbers) for name, numbers in normalized.items()
                  if name in expected_set and numbers}
        five_names = [name for name in expected if counts.get(name) == 5]
        for name in expected:
            count = counts.get(name)
            if count is None:
                continue
            if count == 5:
                continue
            if count != 4:
                issues.append("数量异常：" + name + " 有 " + str(count) + " 个（应为 4）")
        if len(five_names) != 1:
            issues.append("数量异常：5 个号码的生肖有 " + str(len(five_names)) + " 个（应恰好 1 个）")
    return issues


def binding_from_groups(groups):
    """把「生肖 → 号码列表」展开为 1~49 的「号码 → 生肖」绑定

    功能:
        对话框在 validate_zodiac_groups() 通过后调用本函数生成完整绑定。
        按 ZODIAC_CLOCKWISE 顺序展开，保证同一输入每次得到相同字典内容。

    参数:
        groups (dict[str, list[int]]): {生肖名: [号码, ...]}。
    返回:
        dict[int, str]: {号码: 生肖名}，键覆盖 1~49（入参非法时以最后一次赋值
        为准；调用方必须先通过 validate_zodiac_groups，避免重复号码被静默覆盖）。

    副作用:
        无（不读写文件、不修改入参）。
    """
    binding = {}
    for zodiac in LotteryConfig.ZODIAC_CLOCKWISE:
        for number in (groups or {}).get(zodiac, []) or []:
            try:
                number = int(number)
            except (TypeError, ValueError):
                continue
            binding[number] = zodiac
    return dict(sorted(binding.items()))


# ==========================================================================
# 数据工具
# ==========================================================================


class DataUtils:
    """数据工具类（纯静态方法，无实例状态，可安全并发调用）

    职责：
        负责“外部文本 → 系统内部开奖记录结构”的转换：
        网页 HTML 清洗、期号规范化、多格式原始数据解析、标准格式输出、
        无数据时的样例数据生成。

    统一的数据结构（本模块所有解析/生成的返回值都遵循）：
        {
            'period': int,          # 期号
            'date': 'YYYY年MM月DD日' 或 'YYYY-MM-DD',
            'numbers': [6 个正码],
            'special': int,          # 特别码
            'all_numbers': [7 个号码] # 仅部分接口返回
        }

    线程约束：全部方法为 @staticmethod 且不读写全局可变状态，可并发调用；
        唯一例外是 generate_sample_data 使用全局 random 模块的随机数状态。
    """
    @staticmethod
    def strip_html(text):
        """把网页复制来的 HTML 片段转换为纯文本（v0.0.28）

        功能：
            把网页源码/富文本清洗为可供号码解析的纯文本，规则：
            1) <script>/<style> 整段丢弃
            2) <br> → 换行；</td></th> → 空格；</tr></p></div></table> → 换行
               （保证表格相邻单元格的数字不会被粘成 "0102"）
            3) 去掉其余所有标签（<span style=...>、<b>、<a> 等）
            4) 解码 HTML 实体（&nbsp; &amp; &lt; &#49; 等）

        参数:
            text: 原始文本（可能是网页源码或富文本）
        返回:
            str: 纯文本；不含 "<" 时原样返回

        注意：
            基于正则逐条替换而非 HTML 解析器；text 为 None 或空串时
            走「不含 '<'」快速路径原样返回；不解析号码、不读写外部状态。
        """
        import html as _html  # 作用说明：_html.unescape 解码 &nbsp; / &amp; / &#49; 等 HTML 实体
        # 快速路径：纯文本不含 "<" 时无需任何清洗，直接返回，避免无谓的正则开销
        if not text or '<' not in text:
            return text
        # 整段丢弃脚本与样式内容（含标签本身），替换为空格防止前后数字粘连
        cleaned = re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', ' ', text)
        # <br> 是网页表格里最常见的换行方式，必须转成真实换行
        cleaned = re.sub(r'(?i)<br\s*/?>', '\n', cleaned)
        # 单元格结束转空格：若直接删标签，"01" 与 "02" 会连成 "0102" 被误判为一个号码
        cleaned = re.sub(r'(?i)</(td|th)>', ' ', cleaned)
        # 行/段落/表格结束转换行：保证每条记录至少按行分隔
        cleaned = re.sub(r'(?i)</(tr|p|div|table|li)>', '\n', cleaned)
        # 删除剩余所有标签（<span style=...>、<b>、<a> 等），标签内文本保留
        cleaned = re.sub(r'(?s)<[^>]+>', '', cleaned)
        # 解码实体：&nbsp;→空格、&amp;→&、&#49;→"1" 等（数字实体常用于隐藏号码）
        cleaned = _html.unescape(cleaned)
        return cleaned

    @staticmethod
    def _normalize_period(period_text, date_year=None):
        """把期号规范化为「年份 + 期序」的完整期号：2026116 / 20260116 / 202600116 → 2026116

        功能：
            先剔除期号文本中的所有非数字字符；当数字长度 >= 7 且前 4 位落在
            1990~2099 时视为「年份 + 期序」，统一取「前 4 位年份 + 后 3 位期序」；
            否则视为纯期序，只有拿到年份（date_year）时才补全为完整期号。

        参数:
            period_text: 期号文本或数字（如 "第2026116期"、"20260116"、"116"）
            date_year (int | None): 该行开奖日期里的年份；仅在期号本身不含年份时使用
        返回:
            int | None: 完整期号（如 2026116）；无有效数字、或纯期序又无年份时返回 None
        注意:
            期号口径已统一为「完整期号」，不再把 2026001 归一成 1；
            期号只有期序且该行有日期时用日期年份补全（116 + 2026-04-26 → 2026116）；
            纯期序又缺日期时返回 None，由导入层按「缺期号」拒绝，不拿今天兜底造号。
        """
        # 先剔除所有非数字字符（如 "第" / "期" / "No." / 空格）
        raw_text = str(period_text or '').strip()
        # 空串 / None / 0 / 负数一律视为“没有期号”，不参与补号
        if raw_text in ('', 'None', 'null'):
            return None
        try:
            if int(float(raw_text)) <= 0:
                return None
        except ValueError:
            pass
        digits = re.sub(r'\D', '', raw_text)
        if not digits or int(digits) == 0:
            return None
        # 长度 >= 7 才可能是「4 位年份 + 期序」；
        # 再用年份范围 1990~2099 做二次校验，避免把 8 位以上的其他数字误当年份。
        if len(digits) >= 7:
            year = int(digits[:4])
            if 1990 <= year <= 2099:
                # 期序在一年内最多 3 位（约 150 期），统一取后 3 位补足
                return int('%d%s' % (year, digits[-3:].zfill(3)))
        # 纯期序：必须有日期年份才能补全；否则无法确定年份，返回 None
        if date_year:
            return int('%d%s' % (int(date_year), digits.zfill(3)))
        return None

    @staticmethod
    def normalize_period(period_value, date_text=None):
        """按「日期里的年份 + 期序」补全期号（供 JSON / CSV / DuckDB 导入共用）

        功能：
            从 date_text 中取 4 位年份，再委托 _normalize_period 得到完整期号；
            期号本身已含合法年份时，date_text 不参与计算。

        参数:
            period_value: 期号原值（int / str，可能带「第」「期」等字符）
            date_text: 该行日期文本（2026年04月26日 / 2026-04-26 / 20260426 均可）
        返回:
            int | None: 完整期号；无有效期号数字，或纯期序又取不到年份时返回 None
        """
        year = None
        if date_text:
            year_match = re.search(r'(19\d{2}|20\d{2})', str(date_text))
            if year_match:
                year = int(year_match.group(1))
        return DataUtils._normalize_period(period_value, year)

    @staticmethod
    def split_period(period_value, date_text=None):
        """把期号原值拆成「期序 / 完整期号 / 年份」三字段（H63 唯一口径入口）

        功能：
            展示层与存储层统一走这里：`period` 存期序（如 308），
            `period_full` 存完整期号（如 2026308），`period_year` 存年份（2026）。
            去重与库内重复判定只用 period_full，避免 2025/2026 的同一期序互撞。

        参数:
            period_value: 期号原值（int / str，可能带「第」「期」等字符）
            date_text: 该行日期文本（2026年04月26日 / 2026-04-26 / 20260426 均可）
        返回:
            tuple[int | None, int | None, int | None]: (期序, 完整期号, 年份)；
            无有效期号时三项均为 None。
        """
        full = DataUtils.normalize_period(period_value, date_text)
        if full is None:
            return None, None, None
        full_text = str(int(full))
        year = int(full_text[:4])
        sequence = int(full_text[4:]) if len(full_text) > 4 else int(full_text)
        return sequence, int(full), year

    @staticmethod
    def parse_raw_data(raw_text):
        """解析原始开奖数据，兼容多种日期、期号与号码排列顺序

        功能：
            把单条开奖文本转换为 {period, date, numbers, special, all_numbers}：
            先 strip_html + NFKC 归一化并压缩空白，再依次剔除时间、抽取日期、
            抽取并把期号从文本中挖掉、按 "+" 或第 7 个号码确定特别码，
            最后提取 1~49 且去重的号码。

        支持的输入写法（可混用中文/英文标点、全角/半角数字）：
          A. 第116期最新开奖结果 2026年04月26日 15 龙/水 46 鸡/木 ... 22 鸡/水
          B. 第 2026129 期 2026年05月09日 34 07 40 21 17 25 41 鸡/金 ...
          C. 第129期最新开奖结果 2026年05月09日 34 鸡/金 07 鼠/土 ... + 41 虎/火
          D. 第116期 2026年04月26日 15 46 16 10 48 33 + 22
          E. 开奖记录2026年07月31日第212期 / 43 / 鼠/金 / 32 / 猪/火 ...
          F. 2026年04月26日 第116期 15 46 16 10 48 33 + 22      （日期在前）
          G. 2026-04-26 15:30 第116期 15 46 16 10 48 33 + 22    （时间在前）
          H. 2026年04月26日 116 15 46 16 10 48 33 + 22         （无「第X期」，期号在日期后）
          I. 116 2026年04月26日 15 46 16 10 48 33 + 22         （期号在日期前）
          J. 2026-04-26 15 46 16 10 48 33 + 22                  （无期号）

        参数:
            raw_text: 一条开奖记录的原始文本
        返回:
            dict | None: {period, date, numbers, special, all_numbers}；
                         无法识别出 6 个正码 + 特别码时返回 None

        注意：
            任何异常都在 try 内捕获并 print，最终返回 None，不向上抛；
            文本缺日期时用「今天」兜底，期号识别不到时为 None；
            号码按出现顺序去重且只保留 1~49；特别码缺失或正码不足 6 个即判失败。
        """
        try:
            raw_text = DataUtils.strip_html(raw_text)
            # 全角数字/符号转半角，兼容从网页或聊天窗口复制的数据
            # NFKC 会把 "１２３"（全角）→ "123"，"：" → ":"，否则后续正则的 \d 匹配不到全角数字
            import unicodedata  # 作用说明：NFKC 归一化把全角数字/标点转半角，保证后续正则 \d 能匹配
            raw_text = unicodedata.normalize('NFKC', raw_text)
            # 压缩连续空白为单个空格，并去掉首尾空白：简化后续正则的空白匹配
            raw_text = ' '.join(raw_text.split())

            # 1) 去掉时间（15:30 / 15：30：00），避免时、分被当成号码
            text = re.sub(r'(?:开奖时间|发布时间|时间)?\s*\d{1,2}\s*[:：]\s*\d{1,2}(?:\s*[:：]\s*\d{1,2})?', ' ', raw_text)

            # 2) 日期：中文 / 横线 / 斜杠 / 点号四种写法
            date_str = None
            # 记录原文是否真的带日期：只有原文带日期时，才允许用该年份补全纯期序期号；
            # 下方 date_str 的“今天兜底”不能参与期号补全，否则会给缺日期行凭空造年份
            date_year = None
            date_match = re.search(r'(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日?', text)
            if not date_match:
                date_match = re.search(r'(\d{4})\s*[-/.]\s*(\d{1,2})\s*[-/.]\s*(\d{1,2})', text)
            if date_match:
                date_str = '%s年%s月%s日' % (
                    date_match.group(1), date_match.group(2).zfill(2), date_match.group(3).zfill(2))
                date_year = int(date_match.group(1))
                text = text[:date_match.start()] + ' ' + text[date_match.end():]
            if date_str is None:
                # 原文没有日期时用今天兜底：保证记录结构完整，避免下游按日期排序时出现空值
                date_str = datetime.date.today().strftime("%Y年%m月%d日")

            # 3) 期号：第X期 / X期 / 日期旁的独立数字
            period = None
            period_span = None
            period_match = re.search(r'第\s*(\d+)\s*期', text)
            if not period_match:
                period_match = re.search(r'(\d+)\s*期', text)
            if period_match:
                period = DataUtils._normalize_period(period_match.group(1), date_year)
                period_span = period_match.span()
            else:
                # 没有「期」字：按期号 + 6 正码 + 1 特别码 = 8 个数字判断；
                # 不足 8 个说明首数字是号码而不是期号。
                # 期号可能是 7-9 位「年份+期号」（如 2026001），按 1-4 位切分会把
                # 首段截成 2026、剩 001 混进号码；这里整段取首数字再交给规范化函数
                tokens = list(re.finditer(r'\d{1,9}', text))
                if len(tokens) >= 8:
                    period = DataUtils._normalize_period(tokens[0].group(0), date_year)
                    period_span = tokens[0].span()
            # 把已识别出的期号从文本中挖掉（替换为空格），
            # 否则它会被后续的号码提取当成一个 1~49 的号码
            if period_span:
                text = text[:period_span[0]] + ' ' + text[period_span[1]:]

            # 4) 有 + 号：+ 后面是特别码
            special_candidate = None
            plus_match = re.search(r'\+\s*(\d{1,2})', text)
            if plus_match:
                special_candidate = int(plus_match.group(1))
                # "＋" 之后的整段（含特别码本身及其后的生肖/五行标记）全部截掉，
                # 防止特别码再被当成第 7 个正码重复计入 numbers
                text = re.sub(r'\s*\+\s*\d{1,2}.*$', ' ', text)

            # 5) 去掉文字标签，只留号码、生肖/五行
            text = re.sub(r'开奖记录|最新开奖结果|开奖结果|开奖公告|开奖时间|发布时间|期号|时间', ' ', text)

            # 6) 生肖/五行标记：龙/水、鸡/木 等；纯生肖也一并去掉
            # \u9f99-\u9fbf 覆盖常见生肖汉字区间，配合 "生肖/五行" 的斜杠写法整体删除；
            # 斜杠同时兼容半角 "/" 与全角 "／"
            text = re.sub(r'[\u9f99-\u9fbf]\s*[/／]\s*[\u91d1\u6728\u6c34\u706b\u571f]', ' ', text)
            # 单独出现的生肖名（没有斜杠+五行）也要删掉，否则其中的汉字会残留
            zodiacs = '龙|马|蛇|羊|猴|鸡|狗|猪|鼠|牛|虎|兔'
            text = re.sub(zodiacs, ' ', text)
            # 把除数字、空白、加号以外的字符统一替换为空格，
            # 进一步清除“第/期/年/月/日”等标签与各种标点
            text = re.sub(r'[^\d\s+]', ' ', text)

            # 7) 提取 1-49 号码（保持原始顺序，重复号码只保留一次）
            numbers = []
            seen = set()
            for match in re.finditer(r'\b(\d{1,2})\b', text):
                num = int(match.group(1))
                # 限定 1~49：年份、时间等残留数字会被 \b\d{1,2}\b 部分匹配，
                # 用号码范围把它们过滤掉；seen 去重是因为部分站点会重复展示号码
                if 1 <= num <= 49 and num not in seen:
                    seen.add(num)
                    numbers.append(num)

            # 8) 特别码：+ 后优先；否则第 7 个号码
            special = special_candidate
            if special is None and len(numbers) >= 7:
                # 无 "+" 时按“前 6 正码 + 第 7 特别码”的固定顺序取，
                # 然后截断为 6 个正码，防止特别码留在 numbers 里
                special = numbers[6]
                numbers = numbers[:6]

            if len(numbers) >= 6 and special is not None:
                return {
                    'period': period, 'date': date_str,
                    'numbers': numbers[:6], 'special': special,
                    'all_numbers': numbers[:6] + [special],
                }
            return None
        except Exception as e:
            print("解析数据失败: " + str(e))
            return None

    @staticmethod
    def parse_txt_line(line):
        """解析一行「空格分隔」的开奖数据（全系统 TXT 行解析的唯一实现）

        功能：
            把 TXT 导出格式的一行文本解析为结构化元组，供三个入口共用：
            TAB/data_import.py 的 TXT 文件导入、TAB/history.py 的批量添加、
            plugins/彩票预测.py 的顶栏「添加数据」。三者共用本函数后，
            特别码口径不会再出现「取第 6 个正码」的分叉。

        行结构（以 TAB/history.py 的导出表头为准）:
            # 期号 日期 正码1 正码2 正码3 正码4 正码5 正码6 特别码
            共 9 段：parts[0]=期号、parts[1]=日期、parts[2..7]=6 个正码、
            parts[8]=特别码（即整行的第 7 个号码）。

        规则:
            1) None / 空行 / 纯空白 → None；
            2) 以 # 开头的表头或注释行 → None；
            3) 按任意空白切分（空格、多空格、制表符、CRLF 行尾都折叠）；
            4) 段数 < 9 → None：8 段表示缺少特别码，若仍解析会把第 6 个
               正码当成特别码，造成同一期号码重复；
            5) 段数 >= 9 时固定取 parts[8] 作特别码，多余段忽略，与
               TAB/history.py 的历史口径保持一致；
            6) 期号、6 个正码、特别码任一段不是十进制整数 → None。

        参数:
            line (str | None): 单行原始文本（调用方负责逐行拆分，不传整段多行文本）。

        返回:
            tuple | None: 成功时为
                (period:int, date:str, numbers:list[int] 长度 6, special:int)；
            空行、表头、段数不足、非数字等非法输入一律返回 None。

        注意:
            只用标准库，不 import Qt，也不读写文件；任何异常都在内部吞掉
            并返回 None，调用方按「跳过该行」处理，不会中断整个导入流程。
        """
        try:
            if line is None:
                return None
            # BOM 常见于 Windows 记事本保存的 UTF-8 文件，先剔除避免污染期号
            text = str(line).lstrip('\ufeff').strip()
            # 空行与 '#' 注释/表头（导出文件第一行以 # 开头）不是数据行
            if not text or text.startswith('#'):
                return None
            # 不带参数的 split() 会把连续空白视为一个分隔符，
            # 因此多空格、制表符、\r\n 残留都能正确切分
            parts = text.split()
            # 少 9 段就凑不齐「期号 + 日期 + 6 正码 + 特别码」；
            # 8 段的行只有 6 个号码，没有真正的特别码，必须拒绝而不是猜测
            if len(parts) >= 9:
                # 期号：第 1 段；日期：第 2 段（用于纯期序补全年份）
                period = DataUtils.normalize_period(parts[0], parts[1])
                # 期号既无年份、日期也取不到年份时无法确定完整期号，按该行非法跳过
                if period is None:
                    return None
                # 日期：第 2 段（导出为 2026-04-26 单段，不再拆年月日）
                date = parts[1]
                # 正码：第 3~8 段（下标 2..7），共 6 个
                numbers = [int(parts[i]) for i in range(2, 8)]
                # 特别码：第 9 段（下标 8），也就是 6 个正码之后的第 7 个号码
                special = int(parts[8])
                return (period, date, numbers, special)
            return None
        except (ValueError, TypeError, IndexError):
            # 任一段不是整数（日期含时间、乱码、空段等）都视为该行非法，
            # 返回 None 由调用方跳过，避免单行脏数据中断整批导入
            return None

    @staticmethod
    def format_data(data):
        """【需求1-更新】格式化数据为标准输出：2026年04月26日 第116期 15 46 16 10 48 33 + 22

        功能：
            把开奖记录拼成「日期 第X期 正码… + 特别码」的标准输出行，
            号码统一补零到两位；缺少号码时只输出「日期 第X期」。

        参数:
            data (dict): 开奖记录，读取 period/date/numbers/special 四个键；
                缺失键用 '?' 或空列表兜底，不抛异常。
        返回:
            str: 正码与特别码齐全时返回完整一行（号码统一补零到两位）；
                缺少号码时只返回「日期 + 第X期」。

        注意：
            只读取上述四个键，不校验号码合法性、不修改传入 dict；
            用 special != '?' 判断是否齐全，因此 special=0 仍会按号码输出 "00"。
        """
        period = data.get('period', '?')
        date = data.get('date', '?')
        numbers = data.get('numbers', [])
        special = data.get('special', '?')
        if numbers and special != '?':
            numbers_str = ' '.join(str(n).zfill(2) for n in numbers)
            return date + " 第" + str(period) + "期 " + numbers_str + " + " + str(special).zfill(2)
        return date + " 第" + str(period) + "期"
    
    @staticmethod
    def parse_numbers_text(text, dedupe=False, limit_range=False, normalize_text=True):
        """从文本或号码序列中解析号码（全系统唯一实现）

        功能:
            文本输入：先把网页/富文本转纯文本（DataUtils.strip_html），再做
            NFKC 归一化，然后按“连续数字串”切分得到整数列表；
            序列输入：逐个元素转 int，不按分隔符切分、不拆小数点，非法元素丢弃；
            两种输入都支持可选去重与 1~49 范围过滤，用同一份逻辑同时覆盖
            “统计要保留重复与越界值”和“选号只收合法号码”两类相反需求，
            避免调用方各自实现导致行为分叉。

        参数:
            text (str | list | tuple | set | None): 待解析的输入。
                字符串（None 视为空串）：按 \\d+ 提取连续数字串；
                list/tuple/set：逐个元素 int() 转换，转换失败的元素丢弃。
            dedupe (bool): 是否去重（保留首次出现顺序），默认 False。
            limit_range (bool): 是否只保留 1~49 的号码，默认 False。
            normalize_text (bool): 仅对字符串输入生效的显式开关。
                True（默认）：strip_html 去标签 + NFKC 归一化，兼容网页复制、
                    全角数字、带圈数字与 HTML 实体；
                False：直接 str(text) 后按 \\d+ 提取，不解码 HTML、不做 NFKC，
                    供数据库字段解析沿用既有行为；
                序列输入不受此参数影响（元素值已由调用方给出，只做 int 转换）。

        返回:
            list[int]: 按输入顺序排列的整数列表；无有效数字时返回空列表。

        四种参数组合的语义与典型调用场景:
            1) dedupe=False, limit_range=False（默认，统计/展示类）：
               原样保留，重复号码与 0、50 等越界值都保留。用于「数字排序」
               「数字选尾」「数字与五行」等需要统计出现次数、回显用户
               全部输入的页面。
            2) dedupe=True, limit_range=True（选号类）：
               按首次出现顺序去重，并丢弃 1~49 之外的号码。用于「数字选择」
               的三色分组设置等只接受合法且唯一号码的场景。
            3) dedupe=False, limit_range=True（保重复、去越界）：
               只保留合法号码但保留重复，用于需要统计合法号码重复次数
               或“输入个数/去重个数”对比的场合。
            4) dedupe=True, limit_range=False（去重、保越界）：
               去重但保留 0、50 等越界值，用于按原样回显用户输入的唯一数字。

        契约差异（数据库字段解析按此调用）:
            lib/db_helper 的 CSV/Parquet 行字段解析固定使用
            dedupe=True, limit_range=True, normalize_text=False，
            与原模块级 _parse_numbers 逐值等价：保留 1~49 过滤与去重、
            非法元素丢弃、字符串不做 HTML 解码与 NFKC 归一化。
            注意 \\d 本身可匹配全角数字，未归一化时全角数字同样能解析。

        注意:
            NFKC 归一化保证全角数字/标点（０１、，）与半角等价；按 \\d+ 提取
            数字串，因此空格、中英文逗号、顿号、分号、冒号、换行、制表符、
            横线、斜杠、加减号等任意符号及其混用都能作为分隔符。
        """
        import unicodedata  # 作用说明：normalize_text=True 时用 NFKC 把全角数字/标点统一为半角后再抽数字
        numbers = []
        if isinstance(text, (list, tuple, set)):
            # 序列输入：逐元素转 int（与旧 _parse_numbers 一致，不做 \\d+ 切分，
            # 因此 "2.7" 这类元素整体转换失败会被丢弃，而不是拆成 2 和 7）
            for token in text:
                try:
                    value = int(token)
                except (TypeError, ValueError):
                    continue
                if limit_range and not (1 <= value <= 49):
                    continue
                if dedupe and value in numbers:
                    continue
                numbers.append(value)
            return numbers
        if normalize_text:
            # 先识别网页内容：网页源码/富文本/表格先转纯文本；None 统一按空串处理
            normalized = unicodedata.normalize('NFKC', DataUtils.strip_html(text or ''))
        else:
            # 数据库字段沿用旧行为：str() 后直接抽数字，不解码 HTML、不做 NFKC
            normalized = str(text)
        for token in re.findall(r'\d+', normalized):
            value = int(token)
            # 先过滤范围再去重：与旧选号实现（先判 1~49 再查重）结果一致
            if limit_range and not (1 <= value <= 49):
                continue
            if dedupe and value in numbers:
                continue
            numbers.append(value)
        return numbers

    @staticmethod
    def validate_number_combo(numbers):
        """校验一组 6 个号码并汇总统计指标（纯函数，不依赖 Qt）

        功能:
            供「验证号码组合」功能使用：先做数量/去重/范围三项合法性校验，
            全部通过后统计和值、单双比、大小比与红蓝绿三色分布。

        参数:
            numbers (list[int]): 待校验的号码列表（调用方已把输入文本转成整数）。

        返回:
            tuple[str | None, dict | None]:
                - 不合法时返回 (错误提示, None)，提示文案与主窗口原有弹窗逐字一致；
                - 合法时返回 (None, 统计字典)，字典键为：
                  numbers（升序号码）/ sum / odd / even / big / small /
                  red / blue / green。

        注意:
            大小以 25 为分界（n > 25 记为大），与窗口既有口径保持一致；
            颜色优先按 LotteryConfig.is_red / is_blue 判定，其余计为绿色。
        """
        if len(numbers) != 6:
            return '必须输入6个号码', None
        if len(set(numbers)) != 6:
            return '号码不能重复', None
        invalid = [n for n in numbers if not (1 <= n <= 49)]
        if invalid:
            return '以下号码不在1-49范围内: ' + str(invalid), None

        red_count = sum(1 for n in numbers if LotteryConfig.is_red(n))
        blue_count = sum(1 for n in numbers if LotteryConfig.is_blue(n))
        odd_count = sum(1 for n in numbers if n % 2 == 1)
        big_count = sum(1 for n in numbers if n > 25)
        return None, {
            'numbers': sorted(numbers),
            'sum': sum(numbers),
            'odd': odd_count, 'even': 6 - odd_count,
            'big': big_count, 'small': 6 - big_count,
            'red': red_count, 'blue': blue_count,
            'green': 6 - red_count - blue_count,
        }

    @staticmethod
    def generate_sample_data(count=100):
        """生成示例彩票数据（仅在用户没有真实数据时用于界面演示）

        功能：
            生成 count 期演示记录：每期用 random.sample(range(1,50), 7) 抽取并排序，
            前 6 个作正码、第 7 个作特别码；期号从 count 递减到 1，
            日期以今天为基准每期向前倒推一天。

        参数:
            count (int): 生成的期数，默认 100。
        返回:
            list[dict]: 按期号由远到近排列的记录列表，结构同 parse_raw_data
                的返回值（另含 all_numbers 键）。

        注意：
            使用全局 random 的随机数状态，结果不可复现（同时会推进随机序列）；
            不做 count <= 0 校验，count=0 时返回空列表；日期格式为 YYYY-MM-DD。

        实现说明:
            每期用 random.sample(range(1,50), 7) 从 49 个号码中不重复抽 7 个，
            排序后前 6 个作正码、第 7 个作特别码；日期从今天向前每天一期倒推。
        """
        data = []
        base_date = datetime.date.today()
        for i in range(count):
            # 每期抽取 7 个互不相同的号码（1~49），避免出现重复号码这种非法记录
            numbers = random.sample(range(1, 50), 7)
            numbers.sort()
            record = {
                'period': count - i, 'date': (base_date - datetime.timedelta(days=i)).strftime("%Y-%m-%d"),
                'numbers': numbers[:6], 'special': numbers[6], 'all_numbers': numbers,
            }
            data.append(record)
        return data


def format_tails(tails):
    """把尾数集合格式化为「顿号分隔、升序」的展示文本（纯函数，不依赖 Qt）

    功能:
        数字选尾页在统计完成后需要把尾数列表转成界面文本，原实现位于主窗口
        `_format_tails`；这里下沉为纯函数，供 TAB 直接调用，避免窗口层持有
        格式化逻辑。

    参数:
        tails (Iterable[int] | None): 尾数集合/列表；None 或空集合视为无尾数。

    返回:
        str: 空时返回「无」（保持原界面文案不变）；否则按数值升序用「、」连接。

    注意:
        元素本身若不可比较或不可转字符串，沿用原实现的 `sorted`+`str` 行为，
        异常会原样抛出（与原窗口方法一致，不额外吞错）。
    """
    if not tails:
        return "无"
    return "、".join(str(t) for t in sorted(tails))


def get_latest_period(historical_data):
    """取得历史数据中的最新期号（纯函数，不依赖 Qt）

    功能:
        已保存预测需要判断「预测是否已过期」。原实现位于主窗口
        `_get_latest_period`；该逻辑被预测页与数据同步共用，因此下沉到 lib。

    参数:
        historical_data (list[dict] | None): 历史开奖记录列表，记录需含 period 键。

    返回:
        str: 最新期号；无数据时返回空字符串。
            期号优先按 int 数值比较取最大（兼容 1/10/100 等非等长期号），
            int 转换失败时回退到第一条记录的 period（与原实现逐字一致）。

    注意:
        不抛异常：period 缺失时返回空字符串；数据为空返回空字符串。
    """
    if historical_data and len(historical_data) > 0:
        try:
            return max(historical_data, key=lambda r: int(r.get('period', 0))).get('period', '')
        except (ValueError, TypeError):
            # 期号不是纯数字时按原实现回退到首条记录，保证展示不崩
            return historical_data[0].get('period', '')
    return ''


# ==========================================================================
# D1–D4 统计分析纯函数（原独立模块方案改为扩展本模块，避免新增文件改动目录树文档）
# 本段不依赖 Qt；numpy 仅在 cooccurrence_to_matrix 内按需导入
# ==========================================================================

NUM_MIN = 1
NUM_MAX = 49
# 常规算法每期输出的正码个数（回测分母默认值）；
# 特别码专项算法的分母由 get_output_count 给出（1），不套用本常量
REGULAR_PER_PERIOD = 6


def _numbers_of(record):
    """安全读取一条记录的 numbers 字段

    功能:
        从单期记录读取 numbers，兼容「键缺失」与「值为 None」两种历史写法，
        统一返回列表，保证后续累加循环不会因 None 中断。

    参数:
        record (dict): 单期开奖记录。
    返回:
        list: numbers 列表；缺失/None 时返回空列表（不抛异常）。
    注意:
        页面历史上有 record.get('numbers', []) 与 record.get('numbers') 两种写法，
        统一为空列表可保证累加循环不会因 None 中断；不校验元素是否为 1~49。
    """
    return record.get('numbers', []) or []


def _valid_special(record):
    """读取并校验特别码（1~49 之外视为无效）

    功能:
        读取记录的 special 字段，并按 NUM_MIN~NUM_MAX（1~49）闭区间校验，
        合法时返回该特别码，否则返回 None。

    参数:
        record (dict): 单期开奖记录。
    返回:
        int | None: 合法特别码；0/缺失/越界返回 None。
    注意:
        改造前第七位页面的三个预判函数都先做 `1 <= special <= 49` 过滤，
        此处保持同一口径，避免 0 被误计入小号/双号/小尾。
    """
    special = record.get('special', 0)
    if NUM_MIN <= special <= NUM_MAX:
        return special
    return None


# ==========================================================================
# D1 图表统计：频次 / 遗漏 / 分布 / 走势 / 共现 / 间隔 / 连号 / 和值
# ==========================================================================

def compute_frequency(records):
    """统计 1~49 号码的出现次数（正码 + 特别码）

    功能:
        供「频率分布图」使用；每个正码与特别码都计 1 次，不区分位置。

    参数:
        records (list[dict]): 开奖记录（最新在前；本函数与顺序无关）。

    返回:
        dict[int, int]: 号码 → 出现次数；只包含实际出现过的号码。

    注意:
        记录缺少 numbers/special 时按空值处理，返回空 dict 而不抛异常。
        调用方需自行判断空 dict 并跳过绘图。
    """
    frequency = {}
    for record in records:
        for num in _numbers_of(record):
            frequency[num] = frequency.get(num, 0) + 1
        special = record.get('special')
        # 特别码只累加非 0 值，与改造前 `if special:` 判断一致
        if special:
            frequency[special] = frequency.get(special, 0) + 1
    return frequency


def compute_missing(records):
    """统计每个号码距今最近一次出现的遗漏期数

    功能:
        供「遗漏值分析图」使用。records 约定最新在前，因此第一条出现位置
        索引 0 表示「刚出现」，值越大表示遗漏越久。

    参数:
        records (list[dict]): 开奖记录（最新在前）。

    返回:
        dict[int, int]: 1~49 每个号码的遗漏期数；从未出现记 len(records)。

    注意:
        为什么用 `if num not in appeared` 而不是 `missing[num] = i`：
        遍历从新到旧，第一次遇到某号码时 i 即「最近一次出现」的期数差，
        之后再遇到该号码应忽略，否则会被更早的 i 覆盖成大遗漏值。
    """
    missing = {i: 0 for i in range(NUM_MIN, NUM_MAX + 1)}
    appeared = set()
    for i, record in enumerate(records):
        for num in _numbers_of(record):
            if num not in appeared:
                missing[num] = i
            appeared.add(num)
    # 从未出现的号码：遗漏值等于总期数（改造前同样以 len(records) 兜底）
    for num in range(NUM_MIN, NUM_MAX + 1):
        if num not in appeared:
            missing[num] = len(records)
    return missing


def compute_odd_even_distribution(records):
    """统计正码的单双分布

    功能:
        遍历每期 numbers 中的正码，按 num % 2 分别累计单数与双数个数。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict[str, int]: 固定键顺序 {'单数', '双数'}，供饼图按该顺序着色。
    注意:
        只统计正码，不含特别码；不做 1~49 过滤（0/50 等越界号码也按取模参与计数）；
        records 为空时两键均为 0。
    """
    odd_count = even_count = 0
    for record in records:
        for num in _numbers_of(record):
            if num % 2 == 1:
                odd_count += 1
            else:
                even_count += 1
    return {'单数': odd_count, '双数': even_count}


def compute_size_distribution(records):
    """统计正码的大小分布（以 24 为界）

    功能:
        遍历正码，按 num > 24 累计大号个数，其余计入小号。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict[str, int]: 固定键顺序 {'大号(25-49)', '小号(1-24)'}。
    注意:
        改造前页面使用 `num > 24` 判大，因此 25~49 为大、1~24 为小；
        这与 LotteryConfig.is_big（>25）不同，不能替换成 is_big，
        否则 25 会被改判为小号。
    """
    big_count = small_count = 0
    for record in records:
        for num in _numbers_of(record):
            if num > 24:
                big_count += 1
            else:
                small_count += 1
    return {'大号(25-49)': big_count, '小号(1-24)': small_count}


def compute_color_distribution(records):
    """统计正码的红/蓝/绿波色分布

    功能:
        遍历正码，按红波、蓝波、其余为绿的顺序累计三种波色个数。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict[str, int]: 固定键顺序 {'红色', '蓝色', '绿色'}。
    注意:
        改造前采用「先判红、再判蓝、其余一律绿」的两分支写法，
        而不是 is_red/is_blue/is_green 三分支；为保持口径，此处沿用原写法。
    """
    red_count = blue_count = green_count = 0
    for record in records:
        for num in _numbers_of(record):
            if LotteryConfig.is_red(num):
                red_count += 1
            elif LotteryConfig.is_blue(num):
                blue_count += 1
            else:
                green_count += 1
    return {'红色': red_count, '蓝色': blue_count, '绿色': green_count}


def compute_range_distribution(records):
    """统计正码的五区间分布

    功能:
        用 LotteryConfig.get_range_index 把每个正码归入 RANGES 的 5 个闭区间，
        再按配置顺序输出各区间计数。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict[str, int]: 以 LotteryConfig.RANGES 的区间名为键，顺序与配置一致。
    注意:
        get_range_index 对越界号码返回 -1，改造前会跳过不计；此处保持跳过，
        保证 0/大于 49 的脏数据不会落入任何区间。
    """
    range_count = {i: 0 for i in range(5)}
    for record in records:
        for num in _numbers_of(record):
            idx = LotteryConfig.get_range_index(num)
            if idx >= 0:
                range_count[idx] += 1
    return {LotteryConfig.RANGES[i][2]: range_count[i] for i in range(5)}


def compute_tail_distribution(records):
    """统计正码的尾数（个位 0~9）分布

    功能:
        用 LotteryConfig.get_tail_digit 取每个正码的个位，按 0~9 归类计数。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict[str, int]: 键为 '0尾'~'9尾'，顺序 0→9。
    注意:
        只统计正码，不含特别码；不做 1~49 过滤，尾数始终落在 0~9；
        records 为空时各尾数计数均为 0。
    """
    tail_count = {i: 0 for i in range(10)}
    for record in records:
        for num in _numbers_of(record):
            tail = LotteryConfig.get_tail_digit(num)
            tail_count[tail] += 1
    return {str(i) + '尾': tail_count[i] for i in range(10)}


def build_trend_data(records, limit=50):
    """构造「综合走势图」所需的数据

    功能:
        取最新 limit 期，逐期输出 (期号字符串, 正码列表)，供走势图按系列绘制。

    参数:
        records (list[dict]): 开奖记录（最新在前）。
        limit (int): 最多取多少期，默认 50。
    返回:
        list[tuple[str, list[int]]]: [(期号字符串, 正码列表), ...]。
    注意:
        改造前直接取 records[:50] 且 plot_trend 内部再取前 50，
        两层截断保持 limit=50；期号统一 str() 以免 None 参与绘图标签。
    """
    trend_data = []
    for record in records[:limit]:
        trend_data.append((str(record.get('period', '?')), _numbers_of(record)))
    return trend_data


def build_cooccurrence_matrix(records):
    """构造 49×49 正码共现计数矩阵（D4 数据准备）

    功能:
        供「号码相关性热力图」使用；统计同一期内任意两个不同正码
        共同出现的次数。

    参数:
        records (list[dict]): 开奖记录。

    返回:
        dict[int, dict[int, int]]: cooccurrence[n1][n2] = 共现次数，
        固定包含 1~49 全部行列，未共现为 0。

    注意:
        为什么用双重循环遍历每期正码：共现矩阵按「有序对」累加，
        因此 (a,b) 与 (b,a) 都会 +1，矩阵天然对称；
        改造前 `if n1 != n2` 只为排除自身共现，此处保持不变。
        每期的特别码不参与共现，保持原页面口径。
    """
    cooccurrence = {i: {j: 0 for j in range(NUM_MIN, NUM_MAX + 1)}
                    for i in range(NUM_MIN, NUM_MAX + 1)}
    for record in records:
        numbers = _numbers_of(record)
        for n1 in numbers:
            for n2 in numbers:
                if n1 != n2:
                    # 记录脏数据时容错：只累加矩阵内存在的号码
                    if n1 in cooccurrence and n2 in cooccurrence[n1]:
                        cooccurrence[n1][n2] += 1
    return cooccurrence


def cooccurrence_to_matrix(cooccurrence, size=NUM_MAX):
    """把共现嵌套字典转换为 numpy 二维矩阵（D4 绘图前格式转换）

    功能:
        按 sorted(cooccurrence.keys()) 的行列顺序，把嵌套字典铺成
        numpy 二维 float 矩阵，缺失键补 0。

    参数:
        cooccurrence (dict[int, dict[int, int]]): build_cooccurrence_matrix 的结果。
        size (int): 矩阵边长，默认 49。

    返回:
        numpy.ndarray | None: shape=(size, size) 的 float 矩阵；
        numpy 不可用或输入为空时返回 None，由绘图控件降级为「暂无数据」。

    注意:
        函数内部按需导入 numpy：本模块被回测/第七位页面导入时不会触发
        numpy 加载，避免无关页面承担重型库的启动成本。
        为什么用 sorted(keys) 而不是直接 range(1, 50)：与改造前
        plot_correlation_heatmap 的字典分支保持完全相同的行/列顺序，
        即便未来传入稀疏字典也不会错位。
    """
    if not cooccurrence:
        return None
    try:
        import numpy as np  # 作用说明：按需构建共现热力图使用的二维 float 矩阵
    except ImportError:
        return None
    numbers = sorted(cooccurrence.keys())
    matrix = np.zeros((len(numbers), len(numbers)))
    for i, n1 in enumerate(numbers):
        for j, n2 in enumerate(numbers):
            matrix[i, j] = cooccurrence[n1].get(n2, 0)
    # size 参数保留为接口说明；实际边长由输入键数量决定，与改造前一致
    _ = size
    return matrix


def build_interval_data(records, min_appearances=3):
    """统计每个号码相邻两次出现的间隔期数

    功能:
        记录每个号码在各期（按记录索引）的出现位置；出现次数达到
        min_appearances 时，计算相邻两次出现的索引差作为间隔列表。

    参数:
        records (list[dict]): 开奖记录（最新在前）。
        min_appearances (int): 至少出现多少次才产出间隔，默认 3。
    返回:
        dict[int, list[int]]: 号码 → 间隔列表；样本不足的号码不出现在结果中。
    注意:
        为什么要求至少 3 次：两次出现只能得到 1 个间隔，箱线图无法形成
        有效分布，改造前同样是 >=3 次才纳入。
        间隔使用记录索引差（不是期号差），与改造前一致；records 顺序
        必须保持最新在前，否则间隔方向会反过来。
    """
    number_appearances = {i: [] for i in range(NUM_MIN, NUM_MAX + 1)}
    for idx, record in enumerate(records):
        for num in _numbers_of(record):
            if num in number_appearances:
                number_appearances[num].append(idx)
    interval_data = {}
    for num, appearances in number_appearances.items():
        if len(appearances) >= min_appearances:
            intervals = [appearances[i] - appearances[i - 1]
                         for i in range(1, len(appearances))]
            interval_data[num] = intervals
    return interval_data


def select_top_interval_samples(interval_data, limit=15):
    """按样本数降序选取前 N 个号码的间隔列表

    功能:
        按每个号码的间隔列表长度（样本数）降序排序，截取前 limit 个。

    参数:
        interval_data (dict[int, list[int]]): build_interval_data 的结果。
        limit (int): 最多保留多少个号码，默认 15。
    返回:
        list[tuple[int, list[int]]]: [(号码, 间隔列表), ...]，已按样本数降序。
    注意:
        为什么用 sorted(..., reverse=True) 且只按 len 排序：
        Python 的 sorted 是稳定排序，样本数相同时会保留 interval_data 的
        插入顺序（1~49 升序），改造前箱线图的号码顺序也依赖这一点，
        改成不稳定排序会导致同长度号码的标签顺序漂移。
    """
    return sorted(interval_data.items(), key=lambda x: len(x[1]), reverse=True)[:limit]


def compute_consecutive_probability(records):
    """统计连号 / 邻号 / 同尾数的每期平均出现概率

    功能:
        逐期把正码升序排序后，统计相邻差值 1（连号）、差值 2（邻号）的对数，
        以及同尾数配对数；除以记录条数得到每期平均出现次数，
        同时累计各类号码对的跨期次数。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict: {'consecutive'|'adjacent'|'same_tail': {'avg_prob': float, 'pairs': dict}}
        records 为空时返回空 dict（改造前 total_combinations==0 时不产出数据）。

    注意:
        - 分母 total_combinations = 记录条数（不是号码对数），因此 avg_prob
          表示「平均每期出现多少次连号/邻号/同尾」；
        - 连号：排序后相邻号码差值为 1；邻号：差值为 2，用 elif 保证同一对
          不会同时计为连号和邻号；
        - 同尾数：按排序后的顺序，每个尾数只与「上一个同尾号码」配成一对，
          因此一期出现 3 个同尾号码时记 2 次，与改造前一致。
        - pairs 的键为 tuple(sorted([n1, n2]))，保证 (a,b) 与 (b,a)
          在跨期累计时合并为同一键。
    """
    consecutive_count = 0
    adjacent_count = 0
    same_tail_count = 0
    total_combinations = 0

    consecutive_pairs = {}
    adjacent_pairs = {}
    same_tail_pairs = {}

    for record in records:
        numbers = sorted(_numbers_of(record))
        total_combinations += 1

        for i in range(len(numbers) - 1):
            diff = numbers[i + 1] - numbers[i]
            if diff == 1:
                consecutive_count += 1
                pair = tuple(sorted([numbers[i], numbers[i + 1]]))
                consecutive_pairs[pair] = consecutive_pairs.get(pair, 0) + 1
            elif diff == 2:
                adjacent_count += 1
                pair = tuple(sorted([numbers[i], numbers[i + 1]]))
                adjacent_pairs[pair] = adjacent_pairs.get(pair, 0) + 1

        tails = {}
        for num in numbers:
            tail = num % 10
            if tail in tails:
                same_tail_count += 1
                pair = tuple(sorted([tails[tail], num]))
                same_tail_pairs[pair] = same_tail_pairs.get(pair, 0) + 1
            tails[tail] = num

    data = {}
    if total_combinations > 0:
        data['consecutive'] = {
            'avg_prob': consecutive_count / total_combinations,
            'pairs': consecutive_pairs,
        }
        data['adjacent'] = {
            'avg_prob': adjacent_count / total_combinations,
            'pairs': adjacent_pairs,
        }
        data['same_tail'] = {
            'avg_prob': same_tail_count / total_combinations,
            'pairs': same_tail_pairs,
        }
    return data


def compute_sum_values(records):
    """提取每期正码和值（供和值分布直方图）

    功能:
        逐期对 numbers 求和，只收集有正码的期。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        list[int]: 仅包含有正码的期；空 numbers 的期不计入（改造前同口径）。
    注意:
        只算正码、不含特别码；numbers 为空（含缺失/None 兜底为空列表）的期
        直接跳过，不做 1~49 校验，0/50 等越界号码照常参与求和。
    """
    sums = []
    for record in records:
        numbers = _numbers_of(record)
        if numbers:
            sums.append(sum(numbers))
    return sums


# ==========================================================================
# D2 第七位预判：特别码频率 / 走势 / 关联得分 / 三维统计与候选
# ==========================================================================

def build_special_frequency(records):
    """统计有效特别码的出现频率

    功能:
        逐期用 _valid_special 过滤特别码，再用 Counter 统计 1~49 各号码出现次数。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict[int, int]: 特别码 → 次数；只含 1~49 的有效值。
    注意:
        为什么过滤 1~49：缺失/异常 special 常写 0，若不过滤会在频率图
        x 轴生成 0 号柱，误导阅读（页面改造前已加同样过滤）。
    """
    special_freq = Counter()
    for record in records:
        special = _valid_special(record)
        if special is not None:
            special_freq[special] += 1
    return dict(special_freq)


def build_special_trend(records, limit=30):
    """构造特别码走势图数据（最近 N 期，时间正序）

    功能:
        取最新 limit 期后反转为旧→新，逐期取有效特别码，
        输出一一对应的期号列表与特别码列表（无效期整条跳过）。

    参数:
        records (list[dict]): 开奖记录（最新在前）。
        limit (int): 最多取的期数，默认 30。
    返回:
        tuple[list[str], list[int]]: (期号列表, 特别码列表)，两者一一对应。
    注意:
        records[:limit] 是最新 N 期（新→旧），reversed 后变成旧→新，
        这样折线图从左到右才是时间正序；无效特别码整条跳过，
        期号与号码保持配对，不会错位。
    """
    recent = list(reversed(records[:limit]))
    specials = []
    periods = []
    for record in recent:
        special = _valid_special(record)
        if special is not None:
            specials.append(special)
            periods.append(str(record.get('period', '?')))
    return periods, specials


def compute_special_correlation(records, top_n=10):
    """计算「正码 → 特别码」关联得分并取前 N 名

    功能:
        供第七位页「正码关联分析」。某特别码的得分 = 它在所有正码计数
        下的总和，等价于「该特别码出现时，同期正码的共现总次数」。

    参数:
        records (list[dict]): 开奖记录。
        top_n (int): 取前多少名，默认 10。

    返回:
        tuple[dict[int, int], list[tuple[int, int]]]:
        (1~49 全部特别码的得分, 按得分降序的 Top N 列表)。

    注意:
        无有效记录时返回全 0 得分与全 0 的 Top N 列表，不抛异常；
        调用方可用「是否全 0」或原始记录是否为空给出提示。

    说明:
        为什么用 defaultdict(Counter)：cooccurrence[正码][特别码] += 1，
        天然完成「时期内正码与特别码同现」的累计；特别码 1~49 之外的
        记录与越界正码都被跳过，与改造前过滤条件一致。
        排序使用 sorted(..., key=score, reverse=True)：稳定排序，
        同分时保持 1~49 升序，保证 Top N 名单稳定可复现。
    """
    cooccurrence = defaultdict(Counter)
    for record in records:
        numbers = _numbers_of(record)
        special = _valid_special(record)
        if special is not None and numbers:
            for num in numbers:
                if NUM_MIN <= num <= NUM_MAX:
                    cooccurrence[num][special] += 1

    scores = {}
    for special in range(NUM_MIN, NUM_MAX + 1):
        scores[special] = sum(counter.get(special, 0)
                              for counter in cooccurrence.values())
    top = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
    return scores, top


def compute_seventh_size(records):
    """第七位「大小」维度统计与预判

    功能:
        统计有效特别码中 >24 为大、其余为小的个数，计算各自占比（%），
        并按占比大小给出预判与置信度。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict | None: {big_count, small_count, total, big_ratio, small_ratio,
        prediction, confidence}；无有效特别码时返回 None。
    注意:
        special > 24 记大、其余记小（与页面改造前一致）；
        prediction 用 `big_ratio > small_ratio`，平局落到「小」；
        confidence 直接取占优一方的历史占比，不是模型概率。
    """
    big_count = small_count = 0
    for record in records:
        seventh = _valid_special(record)
        if seventh is None:
            continue
        if seventh > 24:
            big_count += 1
        else:
            small_count += 1
    total = big_count + small_count
    if total == 0:
        return None
    big_ratio = big_count / total * 100
    small_ratio = small_count / total * 100
    return {
        'big_count': big_count,
        'small_count': small_count,
        'total': total,
        'big_ratio': big_ratio,
        'small_ratio': small_ratio,
        'prediction': '大' if big_ratio > small_ratio else '小',
        'confidence': max(big_ratio, small_ratio),
    }


def compute_seventh_odd_even(records):
    """第七位「单双」维度统计与预判

    功能:
        统计有效特别码的单/双个数，计算各自占比（%），
        并按占比大小给出预判与置信度。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict: {odd_count, even_count, total, odd_ratio, even_ratio,
        prediction, confidence}。
    注意:
        special % 2 == 1 记单；无有效样本时两个比例兜底 50%，
        因判断用 `>`，平局预判为「双」，confidence 为 50。
    """
    odd_count = even_count = 0
    for record in records:
        seventh = _valid_special(record)
        if seventh is None:
            continue
        if seventh % 2 == 1:
            odd_count += 1
        else:
            even_count += 1
    total = odd_count + even_count
    # 兜底 50 是改造前的既有行为：无样本时仍输出一个不偏不倚的默认值
    odd_ratio = odd_count / total * 100 if total > 0 else 50
    even_ratio = even_count / total * 100 if total > 0 else 50
    return {
        'odd_count': odd_count,
        'even_count': even_count,
        'total': total,
        'odd_ratio': odd_ratio,
        'even_ratio': even_ratio,
        'prediction': '单' if odd_ratio > even_ratio else '双',
        'confidence': max(odd_ratio, even_ratio),
    }


def compute_seventh_tail(records):
    """第七位「尾数大小」维度统计与预判

    功能:
        按特别码个位（special % 10）统计 0~4 小尾、5~9 大尾的个数与占比（%），
        并按占比大小给出预判与置信度。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict: {big_tail_count, small_tail_count, total, big_ratio, small_ratio,
        prediction, confidence}。
    注意:
        tail = special % 10；0~4 为小尾、5~9 为大尾；
        prediction 为 '大尾(5-9)' 或 '小尾(0-4)'；
        无样本时比例兜底 50%，平局预判为小尾。
    """
    big_tail_count = small_tail_count = 0
    for record in records:
        seventh = _valid_special(record)
        if seventh is None:
            continue
        tail = seventh % 10
        if tail >= 5:
            big_tail_count += 1
        else:
            small_tail_count += 1
    total = big_tail_count + small_tail_count
    big_ratio = big_tail_count / total * 100 if total > 0 else 50
    small_ratio = small_tail_count / total * 100 if total > 0 else 50
    return {
        'big_tail_count': big_tail_count,
        'small_tail_count': small_tail_count,
        'total': total,
        'big_ratio': big_ratio,
        'small_ratio': small_ratio,
        'prediction': '大尾(5-9)' if big_ratio > small_ratio else '小尾(0-4)',
        'confidence': max(big_ratio, small_ratio),
    }


def compute_seventh_all(records):
    """第七位「综合预判」：三维统计 + 候选号码筛选

    功能:
        对有效特别码同时做大小、单双、尾数大小三维计数与预判，
        再按三维条件的交集筛出 1~49 的候选号码。

    参数:
        records (list[dict]): 开奖记录。
    返回:
        dict: {
            big_count, small_count, odd_count, even_count,
            big_tail_count, small_tail_count, total,
            size_pred ('大'/'小'), odd_even_pred ('单'/'双'),
            tail_pred ('大尾'/'小尾'), recommended (list[int])
        }。

    注意:
        三维预判直接比较原始计数（不是比例），与改造前
        `big_count > small_count` 等写法一致；total 取大小维度样本数，
        因为所有有效特别码都会同时被三个维度统计，三者样本数必然相等。
        候选号码按 1~49 升序逐个检查 size_ok/odd_ok/tail_ok，
        只做条件交集、不做概率排序；平局统一落到小/双/小尾。
        无有效样本时仍会返回预测标签与候选，由页面决定是否提示无数据
        （改造前同样如此，不因 total=0 提前返回）。
    """
    big_count = small_count = odd_count = even_count = 0
    big_tail_count = small_tail_count = 0
    for record in records:
        seventh = _valid_special(record)
        if seventh is None:
            continue
        if seventh > 24:
            big_count += 1
        else:
            small_count += 1
        if seventh % 2 == 1:
            odd_count += 1
        else:
            even_count += 1
        if seventh % 10 >= 5:
            big_tail_count += 1
        else:
            small_tail_count += 1

    size_pred = '大' if big_count > small_count else '小'
    odd_even_pred = '单' if odd_count > even_count else '双'
    tail_pred = '大尾' if big_tail_count > small_tail_count else '小尾'

    recommended = []
    for num in range(NUM_MIN, NUM_MAX + 1):
        size_ok = (num > 24) == (size_pred == '大')
        odd_ok = (num % 2 == 1) == (odd_even_pred == '单')
        tail_ok = (num % 10 >= 5) == (tail_pred == '大尾')
        if size_ok and odd_ok and tail_ok:
            recommended.append(num)

    return {
        'big_count': big_count,
        'small_count': small_count,
        'odd_count': odd_count,
        'even_count': even_count,
        'big_tail_count': big_tail_count,
        'small_tail_count': small_tail_count,
        'total': big_count + small_count,
        'size_pred': size_pred,
        'odd_even_pred': odd_even_pred,
        'tail_pred': tail_pred,
        'recommended': recommended,
    }


# ==========================================================================
# D3 回测命中：单期命中数 / 汇总口径 / 累计命中率
# ==========================================================================

def get_backtest_reference(actual_record, algo_index=None):
    """按算法口径解析该期的「实际对照号码」与「每期分母」

    功能:
        用 is_special_algorithm / get_output_count 从算法注册表判定回测口径，
        返回该期的对照号码集合、展示用号码（升序）列表与每期分母
        （常规算法 6 / 特别码算法 1）。

    两种回测口径（由算法注册表自动判定，调用方不需要也不允许写特判）:

        1. 常规算法（is_special_algorithm(algo_index) 为 False，输出 6 个正码）
           对照集合 = 该期正码 record['numbers']（6 个）
           每期分母 = get_output_count(algo_index) = 6
           为什么: 常规算法预测的 6 个号都是正码，只有与当期正码取交集，
                   才能衡量「预测的号里有几个真的开奖为正码」。
                   若拿特别码或 7 个号一起比，会把不同玩法的命中混在一起。

        2. 特别码专项算法（is_special_algorithm(algo_index) 为 True，输出 1 个号）
           对照集合 = 该期特别码 record['special']（1 个）
           每期分母 = get_output_count(algo_index) = 1
           为什么: 特别码算法只输出一个特别号，预测值天生不会出现在正码集合里。
                   若仍拿正码作对照，命中数恒为 0；分母再按 6 计算，
                   等于「0 命中 + 6 倍分母」的双重压低，命中率会接近 0，
                   完全失去评估意义。正确口径必须是「特别码对特别码」，
                   且每期只有 1 次命中机会，所以分母必须是 1。

    参数:
        actual_record (dict | iterable[int]): 单期开奖记录。
            生产代码传入完整记录 dict（读取 numbers / special）；
            为兼容旧调用与单元样例，也允许直接传号码集合或列表，
            此时按常规口径把传入号码整体作为对照集合。
        algo_index (int | None): 算法编号；None 或未知编号按常规算法处理。

    返回:
        tuple[set[int], list[int], int]:
            - set[int]：对照集合（已去重），用于与预测号码取交集；
            - list[int]：展示用实际号码（升序）；特别码口径下为 [特别码]，
              特别码缺失/非法时为 []；
            - int：每期分母（常规算法 6，特别码算法 1）。

    注意:
        特别码是否有效统一由 _valid_special 判定（1~49 之外视为缺失）。
        缺失时该期仍计入分母、命中数按 0 处理，避免因缺数据把命中率抬高。
    """
    special_mode = is_special_algorithm(algo_index)
    per_period = get_output_count(algo_index, default=REGULAR_PER_PERIOD)

    if isinstance(actual_record, dict):
        if special_mode:
            # 特别码口径：只对照当期的特别码，不与正码混比
            special = _valid_special(actual_record)
            actual_numbers = [int(special)] if special is not None else []
        else:
            # 常规口径：对照当期的 6 个正码
            actual_numbers = sorted(int(n) for n in _numbers_of(actual_record))
    else:
        # 兼容旧调用：调用方直接给定对照号码（视为常规口径）
        actual_numbers = sorted(int(n) for n in (actual_record or []))

    return set(actual_numbers), actual_numbers, per_period


def compute_hits(predicted, actual_record, algo_index=None):
    """计算单期命中个数（按算法口径选择对照集合后取交集大小）

    功能:
        先由 get_backtest_reference 取该期实际对照集合，再与预测号码取交集，
        交集大小即该期命中数。

    口径（详见 get_backtest_reference 的“为什么”）:
        - 常规算法：命中数 = |预测正码 ∩ 当期实际正码|；
        - 特别码算法：命中数 = 预测特别号是否等于当期实际特别码（0 或 1）。

    参数:
        predicted (iterable[int]): 算法输出的预测号码（常规 6 个 / 特别码 1 个）。
        actual_record (dict | iterable[int]): 单期开奖记录；生产代码传完整
            dict（含 numbers / special），也兼容直接传对照号码集合。
        algo_index (int | None): 算法编号，用于从注册表判定特别码口径；
            None 或未知编号按常规 6 码口径。

    返回:
        int: 命中个数。常规口径 0~6，特别码口径 0 或 1。

    注意:
        为什么要 set：预测结果可能重复/乱序，实际号码也可能重复；
        先转集合再取交集，等价于「按号码去重后的命中个数」，
        重复预测不会虚增命中（与改造前常规算法行为一致）。
    """
    reference, _display, _per_period = get_backtest_reference(actual_record, algo_index)
    return len(set(predicted) & reference)


def summarize_backtest(hits, numbers_per_period=None, algo_index=None):
    """汇总回测命中次数与命中率（单算法回测 / 算法对比 / 摘要展示共用）

    功能:
        对每期命中个数汇总出总命中、期数、每期分母、总分母、平均每期命中与
        命中率（%），并用 max/min 定位最佳/最差期下标；hits 为空时全 0 兜底。

    参数:
        hits (list[int]): 每期命中个数（仅包含有效回测期）。
        numbers_per_period (int | None): 显式指定每期分母；None 时按
            algo_index 从注册表推导（常规 6 / 特别码 1）。
            该参数主要用于单元测试或特殊统计场景，页面不应传死值。
        algo_index (int | None): 算法编号；用于推导分母。None 或未知编号
            按常规 6 码处理，保证旧调用行为不变。

    返回:
        dict: {
            total_hits       总命中次数,
            periods          有效回测期数,
            numbers_per_period 每期分母（6 或 1）,
            total_possible   总分母 = periods × numbers_per_period,
            avg_hit          平均每期命中 = total_hits / periods,
            hit_rate         平均命中率 = total_hits / total_possible × 100,
            best_index, worst_index  最佳/最差期下标
        }；hits 为空时 periods=0、total_possible=0、rate=0、best/worst 为 None。

    注意:
        - 常规算法分母 = 有效回测期数 × 6（与改造前完全一致，逐值不变）；
        - 特别码算法分母 = 有效回测期数 × 1，因为该算法每期只输出 1 个号；
        - 分母按「算法的实际输出个数」累计，而不是按实际开奖号码总数累计，
          否则 6 正码 + 1 特别码的 7 个号码会让两种玩法共用同一分母，口径混淆；
        - best/worst 用 max/min 取第一个出现的位置（Python 内置的稳定语义），
          同命中数时返回最早的一期，与改造前一致。
    """
    periods = len(hits)
    per_period = (numbers_per_period if numbers_per_period is not None
                  else get_output_count(algo_index, default=REGULAR_PER_PERIOD))

    if periods == 0:
        return {
            'total_hits': 0,
            'periods': 0,
            'numbers_per_period': per_period,
            'total_possible': 0,
            'avg_hit': 0.0,
            'hit_rate': 0.0,
            'best_index': None,
            'worst_index': None,
        }

    total_hits = sum(hits)
    total_possible = periods * per_period
    return {
        'total_hits': total_hits,
        'periods': periods,
        'numbers_per_period': per_period,
        'total_possible': total_possible,
        'avg_hit': total_hits / periods,
        'hit_rate': total_hits / total_possible * 100,
        'best_index': max(range(periods), key=lambda i: hits[i]),
        'worst_index': min(range(periods), key=lambda i: hits[i]),
    }


def compute_cumulative_rates(hits, numbers_per_period=None, algo_index=None):
    """计算累计命中率序列（供命中趋势图）

    功能:
        按回测顺序逐期累加命中数与分母，输出每个时点的累计命中率百分比。

    参数:
        hits (list[int]): 每期命中个数，按回测顺序排列。
        numbers_per_period (int | None): 显式指定每期分母；None 时按
            algo_index 从注册表推导（常规 6 / 特别码 1）。
        algo_index (int | None): 算法编号；用于推导分母，None/未知按常规 6 码。

    返回:
        list[float]: 与 hits 等长的累计命中率百分比列表；空输入返回空列表。

    注意:
        第 i 个点 = 前 i+1 期总命中 / ((i+1) × 每期分母) × 100。
        分母随期数累加，不能提前用「总期数 × 每期分母」算整体，
        否则趋势线会失去累计意义。
        常规算法每期 +6、特别码算法每期 +1，二者分别由 algo_index 自动决定，
        页面不需要（也不应该）再写“如果是特别码就换分母”的特判。
    """
    per_period = (numbers_per_period if numbers_per_period is not None
                  else get_output_count(algo_index, default=REGULAR_PER_PERIOD))

    total_hits = 0
    total_possible = 0
    cumulative_rates = []
    for h in hits:
        total_hits += h
        total_possible += per_period
        cumulative_rates.append(total_hits / total_possible * 100)
    return cumulative_rates
