# -*- coding: utf-8 -*-
"""
===========================================================================
lib/algorithms.py - 算法注册表（全项目唯一算法定义来源）
===========================================================================
模块职责：
    1. 用一张表集中定义 23 个预测算法的全部元信息：编号、键名、中文名称、
       描述、计算函数名（指向 lib/math_algo.py 的 PredictionAlgorithms 方法）、
       输出号码数量、分类标签、是否需要模型、是否输出特别码等；
    2. 提供稳定访问接口：get_algorithm / iter_algorithms / ALGORITHM_COUNT /
       run_algorithm，供主窗口、预测页、回测页三处共同消费；
    3. 作为 LotteryConfig.ALGORITHMS（下拉框名称/描述）的唯一来源，
       新增算法只需在本文件加一条，界面名称与调度逻辑自动同步。

在架构中的位置：
    lib/ 纯逻辑层，位于 data_process（配置）之上、math_algo（实现）之下。
    本模块只描述"哪个编号调用哪个方法"，不复制任何算法实现：
    计算函数以方法名字符串保存，调用时才在传入的 predictor 实例上 getattr，
    因此导入本模块不会连带导入 numpy/sklearn 等重型库，也不存在循环依赖。

编号兼容（硬约束）：
    编号 0..22 与历史下拉顺序逐项一致，含义永不改变（禁止重排、禁止插入）。
    旧数据（已保存预测.json、预测记录.json、回测结果、配置.ini）保存的是
    算法中文名称或整数编号；因为本表名称逐字沿用旧文案、编号原样保留，
    旧记录无需任何映射层即可回读。新增算法只能追加到末尾（编号 23 起）。

线程与依赖约束：
    - 纯 Python 标准库实现（dataclasses/typing），禁止 import 任何 Qt；
    - 不可变定义（frozen dataclass），可被任意线程只读并发访问。
===========================================================================
"""

from __future__ import annotations  # 作用说明：延迟注解求值，使类型提示不在运行期解析，兼容旧版本解释器

from dataclasses import dataclass  # 作用说明：用 frozen dataclass 定义不可变的算法注册表条目
from typing import Iterator, Optional, Sequence  # 作用说明：提供迭代器/可选值/只读序列的返回类型标注

# ==========================================================================
# 分类标签（供界面分组/统计使用，取值保持稳定）
# ==========================================================================
CATEGORY_TRADITIONAL = "传统算法"
CATEGORY_GRAPH = "图算法"
CATEGORY_SCIENTIFIC = "科学计算"
CATEGORY_MACHINE_LEARNING = "机器学习"

# 常规算法输出 6 个正码；特别码专项算法只输出 1 个特别码
COUNT_REGULAR = 6
COUNT_SPECIAL = 1

# 兜底编号：调用方遇到未知编号时的默认算法（综合推荐）
DEFAULT_ALGORITHM_INDEX = 0


@dataclass(frozen=True)
class AlgorithmDef:
    """单个算法的不可变定义（注册表条目）

    属性:
        index (int): 算法编号（0..22），与历史下拉顺序一致，禁止重排。
        key (str): 稳定英文键名，供代码引用，避免依赖中文名称做判断。
        name (str): 中文名称，与下拉框显示文本逐字一致（旧记录靠它回读）。
        description (str): 中文描述，显示在预测页算法说明标签。
        method (str): lib/math_algo.py 中 PredictionAlgorithms 的方法名，
            本模块不复制实现，仅保存名字，调用时再绑定实例方法。
        count (int): 该算法输出的号码数量（正码 6 / 特别码 1）。
        category (str): 分类标签（传统算法/图算法/科学计算/机器学习）。
        needs_model (bool): 是否依赖训练模型（sklearn/PyTorch），
            供界面提示耗时与决定是否复用模型缓存。
        is_special (bool): 是否特别码专项算法（只输出 1 个号码，不做生肖组选）。
        uses_enhanced (bool): 调用时是否需要传入 enhanced/reverse 模式参数。
    """

    index: int
    key: str
    name: str
    description: str
    method: str
    count: int = COUNT_REGULAR
    category: str = CATEGORY_TRADITIONAL
    needs_model: bool = False
    is_special: bool = False
    uses_enhanced: bool = False

    def resolve_method(self, predictor):
        """在传入的 predictor 实例上解析计算方法

        功能：
            用 getattr(predictor, self.method) 把注册表里保存的方法名字符串
            绑定成 predictor 上的可调用方法，不复制任何算法实现。

        参数:
            predictor: PredictionAlgorithms 实例（回测时可为轻量模式实例）。
        返回:
            callable: 绑定到 predictor 的方法对象。
        注意：
            属性不存在时 getattr 直接抛 AttributeError，本方法不做兜底；
            每次调用都重新 getattr，不缓存绑定结果。
        异常:
            AttributeError: 方法名在 predictor 上不存在（说明注册表与 math_algo 脱节）。
        """
        return getattr(predictor, self.method)

    def invoke(self, predictor, count=None, enhanced=False, reverse=False):
        """按条目定义调用算法，返回号码列表（不复制算法实现）

        功能：
            先解析出绑定的计算方法，再按 uses_enhanced 决定调用形态：
            该条目为 True 时传 (output_count, enhanced=..., reverse=...)，
            否则只传 output_count。

        参数:
            predictor: PredictionAlgorithms 实例。
            count: 覆盖输出数量；None 表示使用条目默认 count。
            enhanced: 综合推荐是否启用增强模式（仅 uses_enhanced 条目会传入）。
            reverse: 综合推荐是否启用反向模式（仅 uses_enhanced 条目会传入）。
        返回:
            list[int]: 预测号码列表（常规 6 个，特别码算法 1 个）。
        注意：
            enhanced/reverse 仅对 uses_enhanced=True 的条目生效，其余条目静默忽略；
            count 传 None 时回落到条目自带的 count；本方法不校验返回号码个数。
        异常:
            算法内部异常原样抛出，由调用方决定降级策略。
        """
        func = self.resolve_method(predictor)
        output_count = self.count if count is None else count
        if self.uses_enhanced:
            return func(output_count, enhanced=enhanced, reverse=reverse)
        return func(output_count)


# ==========================================================================
# 唯一注册表（顺序即下拉顺序，编号必须与下标一致，禁止重排）
# 名称/描述与历史 LotteryConfig.ALGORITHMS 逐字一致，保证旧记录可回读
# ==========================================================================
ALGORITHM_DEFS: Sequence[AlgorithmDef] = (
    AlgorithmDef(
        0, 'comprehensive', '综合推荐', '综合多种算法得出最优预测',
        'comprehensive_recommendation', COUNT_REGULAR, CATEGORY_TRADITIONAL,
        needs_model=False, is_special=False, uses_enhanced=True,
    ),
    AlgorithmDef(
        1, 'hot_cold', '冷热数字算法', '基于数字出现频率分析',
        'hot_cold_algorithm',
    ),
    AlgorithmDef(
        2, 'odd_even', '单双算法', '分析单双号出现规律',
        'odd_even_algorithm',
    ),
    AlgorithmDef(
        3, 'big_small', '大小算法', '分析大小号出现规律',
        'big_small_algorithm',
    ),
    AlgorithmDef(
        4, 'missing_value', '遗漏值分析算法', '基于数字遗漏周期',
        'missing_value_analysis',
    ),
    AlgorithmDef(
        5, 'adjacent', '连号/邻号分析算法', '分析相邻数字出现规律',
        'adjacent_number_analysis',
    ),
    AlgorithmDef(
        6, 'tail_distribution', '尾数分布算法', '分析数字尾数分布',
        'tail_distribution_algorithm',
    ),
    AlgorithmDef(
        7, 'range_distribution', '区间分布算法', '分析数字区间分布',
        'range_distribution_algorithm',
    ),
    AlgorithmDef(
        8, 'roulette', '轮盘赌选择算法', '基于概率分布随机选择',
        'roulette_selection',
    ),
    AlgorithmDef(
        9, 'historical_similarity', '历史相似性算法', '寻找历史相似模式',
        'historical_similarity',
    ),
    AlgorithmDef(
        10, 'poisson', '泊松概率分布算法', '使用泊松分布建模',
        'poisson_distribution',
    ),
    AlgorithmDef(
        11, 'mystical', '玄学算法', '神秘算法，谨慎使用',
        'mystical_algorithm',
    ),
    AlgorithmDef(
        12, 'number_graph', '号码关联图算法', 'NetworkX PageRank/中心性分析',
        'number_graph_algorithm', COUNT_REGULAR, CATEGORY_GRAPH,
    ),
    AlgorithmDef(
        13, 'shortest_path', '最短路径算法', 'NetworkX Dijkstra号码转移分析',
        'shortest_path_algorithm', COUNT_REGULAR, CATEGORY_GRAPH,
    ),
    AlgorithmDef(
        14, 'community_detection', '社区发现算法', 'NetworkX Louvain社区检测',
        'community_detection_algorithm', COUNT_REGULAR, CATEGORY_GRAPH,
    ),
    AlgorithmDef(
        15, 'graph_clustering', '图聚类算法', 'NetworkX连通分量聚类',
        'graph_clustering_algorithm', COUNT_REGULAR, CATEGORY_GRAPH,
    ),
    AlgorithmDef(
        16, 'numpy_matrix', 'NumPy矩阵算法', '基于NumPy矩阵运算深度分析',
        'numpy_matrix_algorithm', COUNT_REGULAR, CATEGORY_SCIENTIFIC,
    ),
    AlgorithmDef(
        17, 'scipy_optimization', 'SciPy优化算法', '基于SciPy科学计算优化预测',
        'scipy_optimization_algorithm', COUNT_REGULAR, CATEGORY_SCIENTIFIC,
    ),
    AlgorithmDef(
        18, 'sklearn_ensemble', 'Scikit-learn集成算法', '基于Sklearn多模型集成预测',
        'sklearn_ensemble_algorithm', COUNT_REGULAR, CATEGORY_MACHINE_LEARNING,
        needs_model=True,
    ),
    AlgorithmDef(
        19, 'pytorch_deep_learning', 'PyTorch深度学习算法', '基于PyTorch神经网络预测',
        'pytorch_deep_learning_algorithm', COUNT_REGULAR, CATEGORY_MACHINE_LEARNING,
        needs_model=True,
    ),
    AlgorithmDef(
        20, 'networkx_graph', 'NetworkX图算法', '基于图论网络分析预测',
        'networkx_graph_algorithm', COUNT_REGULAR, CATEGORY_GRAPH,
    ),
    # 特别码专项分析算法：只输出 1 个特别码
    AlgorithmDef(
        21, 'special_frequency_regression', '特别码频率回归', '基于特别码历史频率加权回归',
        'special_frequency_regression', COUNT_SPECIAL, CATEGORY_TRADITIONAL,
        is_special=True,
    ),
    AlgorithmDef(
        22, 'special_correlation', '特别码关联算法', '基于特别码与正码关联规则挖掘',
        'special_correlation_algorithm', COUNT_SPECIAL, CATEGORY_TRADITIONAL,
        is_special=True,
    ),
)

ALGORITHM_COUNT = len(ALGORITHM_DEFS)


def _validate_registry() -> None:
    """导入期自检：编号连续、键名/名称唯一，防止未来重排或误插条目

    功能：
        逐条遍历 ALGORITHM_DEFS，校验 index 与元组下标一致、key 与 name 不重复；
        任一校验失败立即抛出 ValueError，使问题在模块导入阶段就暴露。

    参数：无。

    返回：
        无。

    注意：
        由模块级 `_validate_registry()` 在导入时执行一次，本身不修改注册表；
        校验失败会中断导入，依赖本模块的界面与调度逻辑随之不可用。

    异常:
        ValueError: 编号不等于下标、键名重复或名称重复时抛出，
            让问题在启动阶段暴露，而不是等到旧记录错位后才发现。
    """
    keys = set()
    names = set()
    for position, algo in enumerate(ALGORITHM_DEFS):
        if algo.index != position:
            raise ValueError(
                "算法注册表编号不连续：位置 %d 的编号为 %d" % (position, algo.index)
            )
        if algo.key in keys:
            raise ValueError("算法注册表键名重复：" + algo.key)
        if algo.name in names:
            raise ValueError("算法注册表名称重复：" + algo.name)
        keys.add(algo.key)
        names.add(algo.name)


_validate_registry()


def get_algorithm(index) -> Optional[AlgorithmDef]:
    """按编号取得算法定义（编号来自下拉框/配置/历史记录）

    功能：
        先用 int(index) 做宽松转换（兼容配置里的数字字符串），
        再校验 0 <= idx < ALGORITHM_COUNT，通过后直接按下标从注册表取条目。

    参数:
        index: 整数编号；兼容配置文件中可能出现的数字字符串（如 "21"）。
    返回:
        AlgorithmDef | None: 命中返回定义；越界/非法返回 None，
            由调用方决定是否回退到 DEFAULT_ALGORITHM_INDEX。
    注意：
        转换失败（None、非数字字符串）与越界都返回 None，不抛异常；
        负数编号同样视为非法。
    """
    try:
        idx = int(index)
    except (TypeError, ValueError):
        return None
    if 0 <= idx < ALGORITHM_COUNT:
        return ALGORITHM_DEFS[idx]
    return None


def iter_algorithms() -> Iterator[AlgorithmDef]:
    """按编号顺序迭代全部算法定义

    功能：
        返回注册表元组的迭代器，迭代顺序即编号 0..22。

    参数：无。

    返回:
        Iterator[AlgorithmDef]: 0..22 顺序的迭代器，供下拉框/回测批量遍历。
    注意：
        返回的是对模块级只读元组的迭代器，迭代期间不可增删条目；
        条目本身 frozen，可被任意线程并发只读。
    """
    return iter(ALGORITHM_DEFS)


def is_special_algorithm(index) -> bool:
    """判断编号是否特别码专项算法（只输出 1 个号码，不参与生肖组选）

    功能：
        查询编号对应条目的 is_special 标志并转成 bool 返回。

    参数:
        index: 算法编号。
    返回:
        bool: 未知编号按 False 处理。
    注意：
        未知/非法编号经 get_algorithm 得到 None 后直接为 False，不抛异常；
        本函数只读注册表，无副作用。
    """
    algo = get_algorithm(index)
    return bool(algo and algo.is_special)


def get_output_count(index, default=COUNT_REGULAR) -> int:
    """取得编号对应的输出号码数量

    功能：
        查询编号对应条目的 count 字段（常规 6 / 特别码 1），未知编号返回 default。

    参数:
        index: 算法编号。
        default: 编号未知时的兜底数量。
    返回:
        int: 常规算法 6，特别码算法 1，未知编号返回 default。
    注意：
        default 由调用方决定，本函数不校验其合法性；只读注册表，无副作用。
    """
    algo = get_algorithm(index)
    return algo.count if algo else default


def run_algorithm(predictor, index, count=None, enhanced=False, reverse=False):
    """按编号执行预测算法（主窗口/预测页/回测的统一入口）

    功能：
        用 get_algorithm 取条目，未知编号静默回退到 DEFAULT_ALGORITHM_INDEX
        （综合推荐），再委托条目自身的 invoke 完成调用。

    参数:
        predictor: PredictionAlgorithms 实例。
        index: 算法编号；未知编号回退到 DEFAULT_ALGORITHM_INDEX。
        count: 覆盖输出数量；None 表示使用条目默认值。
        enhanced: 综合推荐增强模式开关（其它算法忽略该参数）。
        reverse: 综合推荐反向模式开关（其它算法忽略该参数）。
    返回:
        list[int]: 预测号码列表。
    注意：
        编号非法时回退是静默的，调用方无法得知传入编号是否有效；
        本函数不做输入校验，也不捕获算法内部异常。
    异常:
        算法内部异常原样抛出，调用方负责降级。
    """
    algo = get_algorithm(index)
    if algo is None:
        algo = ALGORITHM_DEFS[DEFAULT_ALGORITHM_INDEX]
    return algo.invoke(predictor, count=count, enhanced=enhanced, reverse=reverse)
