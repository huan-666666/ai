# -*- coding: utf-8 -*-
"""
===========================================================================
lib/report_builder.py - HTML 报告构造（纯逻辑，无 Qt）
===========================================================================
模块职责：
    为「批量导出报告」提供算法说明页的 HTML 模板与批量写盘能力。
    本模块只处理字符串与文件，不依赖 Qt、不弹窗、不读写数据库。

为什么单独新建：
    lib/ 下原先没有报告构造函数，报告 HTML 直接写在 plugins/彩票预测.py 里；
    本次迁移要求把报告生成下沉到 lib。为避免与 TAB/prediction.py 的
    「单份分析报告」模板混在一起（两份模板结构不同），单独设立本模块，
    后续新增报告类型也集中在此维护。

在架构中的位置：
    位于 lib/ 纯逻辑层，被 plugins/彩票预测.py 的「批量导出报告」调用；
    lib/data_process.LotteryConfig.ALGORITHMS 作为算法清单来源。

依赖：
    仅标准库 datetime、os（不依赖 numpy/pandas 等重型库）。

约束：禁止任何 Qt 界面代码；不弹窗，失败由调用方决定如何提示。
===========================================================================
"""

import datetime  # 作用说明：生成报告时取当前本地时间（默认格式 %Y-%m-%d %H:%M:%S）
import os        # 作用说明：用 os.path.join 拼装导出目录与 HTML 文件名（跨平台）


def build_algorithm_report_html(algo_name, description, generated_at=None):
    """构造单个算法的简易 HTML 报告

    功能：
        按既有模板输出一份算法说明页，正文包含算法名、算法描述与生成时间。

    参数：
        algo_name (str): 算法名称，用于标题与正文标题。
        description (str): 算法描述文本。
        generated_at (str | None): 生成时间字符串；None 时取当前本地时间
            （格式 %Y-%m-%d %H:%M:%S），保证与迁移前输出一致。

    返回：
        str: 完整 HTML 文本（单行，UTF-8 由调用方负责写盘）。

    注意：
        无副作用（纯字符串拼接，不写盘、不读全局状态）；
        algo_name/description 原样拼入 HTML、不做转义，调用方需保证内容可信。
    """
    if generated_at is None:
        generated_at = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return ("<html><head><meta charset='utf-8'><title>算法报告 - " + algo_name
            + "</title></head><body><h1>算法报告: " + algo_name + "</h1>"
            + "<p>算法描述: " + description + "</p>"
            + "<p>生成时间: " + generated_at + "</p></body></html>")


def write_algorithm_reports(dir_path, algorithms):
    """把算法清单逐项写成 HTML 报告文件

    功能：
        遍历 (算法名, 描述) 列表，在 dir_path 下生成
        report_{索引}_{算法名}.html；单个文件写入失败时跳过，不影响其余算法。

    参数：
        dir_path (str): 导出目录（调用方保证已存在且用户已确认）。
        algorithms (list[tuple[str, str]]): 算法清单，元素为 (算法名, 描述)。

    返回：
        int: 尝试导出的算法数量（与迁移前提示的“已导出 N 个算法”一致，
            不因个别文件写入失败而减少）。

    注意：
        写盘：在 dir_path 创建/覆盖 HTML 文件，以 UTF-8 编码保存；
        写入异常被本函数吞掉并继续下一项，不会向调用方抛出。
    """
    for idx, (algo_name, description) in enumerate(algorithms):
        try:
            file_name = os.path.join(dir_path, "report_" + str(idx) + "_" + algo_name + ".html")
            html_content = build_algorithm_report_html(algo_name, description)
            with open(file_name, 'w', encoding='utf-8') as f:
                f.write(html_content)
        except Exception:
            continue
    return len(algorithms)
