# -*- coding: utf-8 -*-
"""
===========================================================================
UI/control_picker.py - 控件拾取 / 查看器（开发调试工具）
===========================================================================
功能说明：
    1. 在运行中的主窗口上开启「拾取模式」，点击任意控件即可查看：
       类名、objectName、相对父控件/屏幕/主窗口坐标与尺寸、父级控件链、
       所属 TAB/UI 模块，以及该控件在源码中的创建/配置行（可直接照着改）。
    2. 拾取模式下点击不会触发控件原动作（按钮不点、下拉不展开），
       命中控件用橙色橡皮筋框高亮，信息面板支持一键复制。
    3. 开关方式：顶栏「控件拾取」按钮，或快捷键 Ctrl+Shift+C；
       开关状态持久化到 SQLite app_config（key=control_picker_ui），
       并备份到 系统v7.5/控件拾取器.json。

使用方式：
    python tools/控件拾取器.py      # 独立启动器，不改 run.py
    或在任意启动入口中调用：install_control_picker(window)

约束：
    - 本文件属于 UI 层，只通过 `from .UI import *` 获取 Qt 控件
    - 不修改 run.py；不把 Qt 代码写入 lib/
===========================================================================
"""

import ast  # 作用说明：把 UI/TAB/plugins 源码解析成 AST，静态定位控件创建行、setObjectName 与属性挂载
import json  # 作用说明：把拾取器开关状态与面板尺寸序列化写入 SQLite app_config 和 JSON 备份，读取时反序列化
import os  # 作用说明：拼接源码路径、列目录遍历、把相对路径换算成绝对路径，并创建 系统v7.5 状态备份目录
import re  # 作用说明：压缩连续空白、校验变量名是否符合标识符、以及按界面文字归一化后精确匹配

from .UI import *  # 作用说明：经界面层唯一导入中心获取 QObject/QDialog/QLabel/QRubberBand 等 Qt 控件，本文件不直接 from PyQt6 import

# 持久化：SQLite app_config 键 + JSON 备份文件
_STATE_KEY = "control_picker_ui"
_STATE_FILENAME = "控件拾取器.json"

# 源码扫描范围（只扫界面相关文件，避免把 docs/生成索引.py 等工具混进来）
_SCAN_FOLDERS = ("UI", "TAB", "plugins")


def _short(text, limit=200):
    """功能：把长文本压成单行并截断
    注意：纯展示用途，会把所有连续空白压成一个空格；None 视为空串，
          非字符串先经 str() 转换；limit 很小时按切片截断，不抛异常。
    参数:
        text: 原始文本
        limit: 最大字符数
    返回:
        str 处理后的文本
    """
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _widget_text(widget):
    """功能：读取控件上最适合展示的文字
    注意：只读不写，不触发控件任何动作；getter 抛异常或不存在时静默跳过，
          继续试下一个属性，不会中断整份报告的生成。
    参数:
        widget: 目标控件
    返回:
        str 文字（没有则空串）
    """
    for name in ("text", "currentText", "placeholderText", "windowTitle", "toolTip"):
        getter = getattr(widget, name, None)
        if not callable(getter):
            continue
        try:
            value = getter()
        except Exception:
            continue
        if value:
            return str(value)
    return ""


def _call_name(func_node):
    """功能：从 AST 调用节点取出被调用的类/函数名
    注意：只识别 ast.Name（直接调用）与 ast.Attribute（模块/对象方法）两种形式，
          其余调用形式（下标、lambda 等）一律返回空串，调用方据此跳过该节点。
    参数:
        func_node: ast.Call 的 func 节点
    返回:
        str 名称（无法识别返回空串）
    """
    if isinstance(func_node, ast.Name):
        return func_node.id
    if isinstance(func_node, ast.Attribute):
        return func_node.attr
    return ""


def _const_str(node):
    """功能：从 AST 节点取出字符串常量
    注意：只认 ast.Constant 里的 str；f-string、拼接表达式等返回 None，
          因此动态生成的界面文字不会被登记进源码索引。
    参数:
        node: ast 节点
    返回:
        str 或 None
    """
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _assignment_target(node, parents):
    """功能：判断调用节点是否直接赋值给某个变量
    注意：parents 必须是调用方预先构建好的「子节点 -> 父节点」完整映射，
          缺失时直接返回 None；依赖 ast.unparse（Python 3.9+），
          返回的是源码文本而非对象，仅供报告展示。
    参数:
        node: ast.Call 节点
        parents: 子节点 -> 父节点 映射
    返回:
        str 赋值目标（如 self.font_combo / host.number_panel / btn / return），无则 None
    """
    parent = parents.get(node)
    if isinstance(parent, ast.Assign) and parent.value is node:
        return ast.unparse(parent.targets[0])
    if isinstance(parent, ast.AnnAssign) and parent.value is node:
        return ast.unparse(parent.target)
    if isinstance(parent, ast.Return):
        return "return"
    return None


class _SourceIndex:
    """功能：静态扫描 UI/TAB/plugins 源码，建立控件创建行、objectName、属性挂载索引"""

    def __init__(self, root):
        """功能：初始化源码索引容器（只登记路径与空缓存，不读磁盘）
        注意：构造阶段零 I/O；真正的源码扫描在第一次 build() 时发生，
              因此拾取器挂载到主窗口不会拖慢启动。
        参数:
            root: 项目根目录绝对路径（用于拼接 UI/TAB/plugins/run.py）
        返回:
            无
        """
        self.root = root
        self.entries = []       # 控件构造调用：rel / line / cls / target / text / source
        self.object_names = []  # setObjectName 调用：rel / line / name / receiver / source
        self.aliases = []       # host.x = local_var 挂载：rel / line / name / rhs / source
        self.class_defs = {}    # 类名 -> [{rel, line, source}]
        self._lines = {}
        self._built = False

    def build(self):
        """功能：构建索引（首次拾取时调用，结果缓存）
        注意：结果缓存在 self._built，重复调用不会再扫描磁盘；
              单个文件语法错误（SyntaxError/ValueError）只跳过该文件，
              读盘失败（OSError）同样跳过，整体不抛异常。
        参数: 无
        返回: 无
        """
        if self._built:
            return
        self._built = True
        for rel in self._iter_files():
            path = os.path.join(self.root, rel)
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                    source = fh.read()
            except OSError:
                continue
            lines = source.splitlines()
            self._lines[rel] = lines
            try:
                tree = ast.parse(source)
            except (SyntaxError, ValueError):
                continue
            parents = {}
            for parent in ast.walk(tree):
                for child in ast.iter_child_nodes(parent):
                    parents[child] = parent
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    self.class_defs.setdefault(node.name, []).append({
                        "rel": rel, "line": node.lineno, "cls": node.name,
                        "source": self._line(rel, node.lineno),
                    })
                    continue
                if isinstance(node, ast.Call):
                    func = node.func
                    # setObjectName("xxx") 单独登记
                    if isinstance(func, ast.Attribute) and func.attr == "setObjectName":
                        name = _const_str(node.args[0]) if node.args else None
                        if name:
                            self.object_names.append({
                                "rel": rel, "line": node.lineno, "name": name,
                                "receiver": ast.unparse(func.value),
                                "source": self._line(rel, node.lineno),
                            })
                        continue
                    cls = _call_name(func)
                    if not cls or not cls[:1].isupper():
                        continue
                    self.entries.append({
                        "rel": rel, "line": node.lineno, "cls": cls,
                        "target": _assignment_target(node, parents),
                        "text": _const_str(node.args[0]) if node.args else None,
                        "source": self._line(rel, node.lineno),
                    })
                    continue
                if isinstance(node, ast.Assign):
                    if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Attribute):
                        continue
                    target_text = ast.unparse(node.targets[0])
                    if not (target_text.startswith("self.") or target_text.startswith("host.")):
                        continue
                    rhs = ast.unparse(node.value)
                    # 只登记「host.x = local_var」这类纯转挂载，构造函数由 entries 负责
                    if not re.match(r"^[A-Za-z_][A-Za-z0-9_.]*$", rhs):
                        continue
                    self.aliases.append({
                        "rel": rel, "line": node.lineno,
                        "name": target_text.split(".", 1)[1],
                        "rhs": rhs, "source": self._line(rel, node.lineno),
                    })
        self.entries.sort(key=lambda item: (item["rel"], item["line"]))
        self.object_names.sort(key=lambda item: (item["rel"], item["line"]))
        self.aliases.sort(key=lambda item: (item["rel"], item["line"]))

    def _iter_files(self):
        """功能：遍历需要扫描的源码文件（相对项目根目录的路径）
        注意：生成器惰性产出，调用方在循环中才真正读目录；
              跳过 __ 前缀文件与本文件自身，避免拾取器面板按钮污染源码定位；
              run.py 仅在存在时才追加，缺失不影响其它文件。
        参数: 无
        返回:
            generator[str]
        """
        for folder in _SCAN_FOLDERS:
            directory = os.path.join(self.root, folder)
            if not os.path.isdir(directory):
                continue
            for name in sorted(os.listdir(directory)):
                if not name.endswith(".py") or name.startswith("__"):
                    continue
                # 不扫描本文件自身，避免面板按钮污染源码定位结果
                if folder == "UI" and name == "control_picker.py":
                    continue
                yield folder + "/" + name
        if os.path.exists(os.path.join(self.root, "run.py")):
            yield "run.py"

    def _line(self, rel, line_no):
        """功能：取源码指定行（去掉首尾空白）
        注意：行号越界或文件未收录时返回空串而不是抛异常；
              返回值已 strip 首尾空白，报告里不会出现缩进抖动。
        参数:
            rel: 相对路径
            line_no: 行号（从1开始）
        返回:
            str
        """
        lines = self._lines.get(rel) or []
        if 1 <= line_no <= len(lines):
            return lines[line_no - 1].strip()
        return ""

    def prefer(self, items, module_rel):
        """功能：优先返回与当前模块同文件的条目
        注意：返回的是原 dict 引用（不做拷贝），调用方若要追加 note 必须先 dict(...)
              复制；列表为空时返回 None。
        参数:
            items: 索引条目列表
            module_rel: 当前 TAB/UI 模块的相对路径
        返回:
            dict 或 None
        """
        if not items:
            return None
        same = [item for item in items if item.get("rel") == module_rel]
        return (same or items)[0]

    def class_range(self, rel, cls):
        """功能：取某个类在指定文件中的行范围
        注意：结束行取「同文件下一个类定义行」而不是真实类体末行，
              因此范围可能偏大；依赖 build() 已执行，未收录类名返回 None。
        参数:
            rel: 相对路径
            cls: 类名
        返回:
            (起始行, 结束行) 或 None
        """
        defs = self.class_defs.get(cls) or []
        target = None
        for item in defs:
            if item["rel"] == rel:
                target = item
                break
        if not target:
            return None
        starts = sorted(item["line"] for item in defs if item["rel"] == rel)
        later = [line for line in starts if line > target["line"]]
        end = later[0] if later else len(self._lines.get(rel) or []) + 1
        return target["line"], end


class ControlPicker(QObject):
    """功能：控件拾取/查看器控制器（挂在主窗口上，不修改主窗口源码）"""

    def __init__(self, host):
        """功能：初始化拾取器（建面板、加顶栏按钮与快捷键、装事件过滤器、恢复开关状态）
        注意：构造即产生主窗口副作用——向 TopBar 追加按钮、注册应用级快捷键、
              安装应用级事件过滤器，并读取持久化状态；host 需已有 tabs/TopBar
              才走标准挂载分支，否则退化为浮动按钮。
        参数:
            host: 主窗口（LotteryPredictionWindow）
        返回:
            无（构造函数）
        """
        super().__init__(host)
        self.host = host
        self._app = QApplication.instance()
        self.root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self._index = _SourceIndex(self.root)
        self._enabled = False
        self._swallow_release = False
        self._band = None
        self._last_report = ""
        self._last_location = ""
        self._attr_map = {}
        self._tab_info = {}
        self._tab_rel = {}
        self._collect_tabs()
        self._build_panel()
        self._install_toggle_button()
        self._install_shortcut()
        if self._app is not None:
            self._app.installEventFilter(self)
        self._load_state()

    # 初始化：选项卡映射 / 面板 / 顶栏按钮 / 快捷键

    def _collect_tabs(self):
        """功能：收集 TAB_INFO（顺序、标题、源码文件）
        注意：依赖 TAB.iter_tab_pages() 的自动发现；导入或遍历失败只打印提示，
              拾取器其余功能照常可用（只是无法显示「[序号] 标题」）。
        参数: 无
        返回: 无
        """
        try:
            from TAB import iter_tab_pages  # 作用说明：按 TAB_INFO 顺序遍历选项卡模块，取出标题与源码文件路径
            for order, title, module in iter_tab_pages():
                rel = os.path.relpath(os.path.abspath(module.__file__), self.root).replace("\\", "/")
                self._tab_info[title] = (order, rel)
                self._tab_rel[rel] = (order, title)
        except Exception as exc:
            print("[控件拾取器] 读取 TAB_INFO 失败: " + str(exc))

    def _build_panel(self):
        """功能：创建信息面板（非模态对话框）
        注意：面板及其子控件、样式表均属本工具私有，不写回主窗口 QSS；
              非模态是为了拾取时仍能点击主窗口控件。
        参数: 无
        返回: 无
        """
        self._panel = QDialog(self.host)
        self._panel.setWindowTitle("控件拾取器")
        self._panel.setModal(False)
        self._panel.resize(980, 680)

        outer = QVBoxLayout(self._panel)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(8)

        self._title_label = QLabel("控件拾取器 · 未开启")
        self._title_label.setWordWrap(True)
        self._title_label.setStyleSheet("font-size: 20px; font-weight: bold; color: #1565C0;")
        outer.addWidget(self._title_label)

        self._hint_label = QLabel(
            "开启方式：顶栏「控件拾取」按钮或 Ctrl+Shift+C。开启后点击任意控件即可查看信息，"
            "控件原动作不会触发；命中控件会用橙色框高亮。"
        )
        self._hint_label.setWordWrap(True)
        self._hint_label.setStyleSheet("font-size: 20px; color: #666666;")
        outer.addWidget(self._hint_label)

        self._text_view = QTextEdit()
        self._text_view.setReadOnly(True)
        self._text_view.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        info_font = QFont("Consolas")
        info_font.setPixelSize(20)  # 项目默认文字 20px
        self._text_view.setFont(info_font)
        self._text_view.setStyleSheet("QTextEdit { background: #FFFFFF; border: 1px solid #90CAF9; }")
        outer.addWidget(self._text_view, 1)

        button_row = QHBoxLayout()
        button_row.setSpacing(8)

        self._copy_all_btn = QPushButton("复制全部")
        self._copy_all_btn.setMinimumSize(100, 60)  # 20px 字号下 4 个汉字需要 100px 宽
        self._copy_all_btn.setMaximumSize(300, 300)
        self._copy_all_btn.clicked.connect(self._copy_all)
        button_row.addWidget(self._copy_all_btn)

        self._copy_loc_btn = QPushButton("复制定位")
        self._copy_loc_btn.setMinimumSize(100, 60)
        self._copy_loc_btn.setMaximumSize(300, 300)
        self._copy_loc_btn.clicked.connect(self._copy_location)
        button_row.addWidget(self._copy_loc_btn)

        self._close_btn = QPushButton("关闭面板")
        self._close_btn.setMinimumSize(100, 60)
        self._close_btn.setMaximumSize(300, 300)
        self._close_btn.clicked.connect(self._panel.hide)
        button_row.addWidget(self._close_btn)
        button_row.addStretch(1)
        outer.addLayout(button_row)

        self._status_label = QLabel("等待拾取…")
        self._status_label.setWordWrap(True)
        self._status_label.setStyleSheet("font-size: 20px; color: #2E7D32;")
        outer.addWidget(self._status_label)

    def _install_toggle_button(self):
        """功能：把「控件拾取」开关按钮挂到主窗口顶栏（UI 层挂载，不改插件源码）
        注意：会向主窗口 TopBar 布局追加一个 checkable 按钮，属于运行时对主窗口的
              结构改动（重启即消失）；找不到顶栏时退化为 host 上的浮动按钮并 show()。
        参数: 无
        返回: 无
        """
        self._toggle_btn = QPushButton("控件拾取")
        self._toggle_btn.setObjectName("ControlPickerToggleBtn")
        self._toggle_btn.setCheckable(True)
        self._toggle_btn.setMinimumSize(100, 60)  # 4 个汉字 @20px
        self._toggle_btn.setMaximumSize(300, 300)
        self._toggle_btn.setToolTip("开启后点击任意控件查看信息（快捷键 Ctrl+Shift+C）")
        self._toggle_btn.setStyleSheet(
            "QPushButton { background-color: #E3F2FD; color: #0D47A1; border: 1px solid #90CAF9; "
            "border-radius: 6px; font-weight: bold; }"
            "QPushButton:hover { background-color: #BBDEFB; }"
            "QPushButton:checked { background-color: #FB8C00; color: #FFFFFF; border-color: #EF6C00; }"
        )
        self._toggle_btn.toggled.connect(self.set_enabled)
        top_bar = self.host.findChild(QWidget, "TopBar")
        if top_bar is not None and top_bar.layout() is not None:
            top_bar.layout().addWidget(self._toggle_btn)
        else:
            # 找不到顶栏时退化为独立小窗按钮，保证功能可用
            self._toggle_btn.setParent(self.host)
            self._toggle_btn.move(10, 10)
            self._toggle_btn.show()

    def _install_shortcut(self):
        """功能：注册全局快捷键 Ctrl+Shift+C
        注意：ApplicationShortcut 是应用级快捷键，会优先于控件的普通快捷键，
              主窗口内其它控件收不到该组合；重复安装会产生多个同键 QShortcut。
        参数: 无
        返回: 无
        """
        self._shortcut = QShortcut(QKeySequence("Ctrl+Shift+C"), self.host)
        self._shortcut.setContext(Qt.ShortcutContext.ApplicationShortcut)
        self._shortcut.activated.connect(lambda: self.set_enabled(not self._enabled))

    # 开关状态：持久化到 SQLite + JSON 备份

    def _state_file(self):
        """功能：状态备份文件路径（程序目录/系统v7.5/控件拾取器.json）
        注意：只计算路径，不创建目录（目录由 _save_state 里的 makedirs 负责）；
              优先使用主窗口的 _data_dir，避免与主窗口数据目录分叉。
        参数: 无
        返回:
            str
        """
        data_dir = getattr(self.host, "_data_dir", None) or os.path.join(self.root, "系统v7.5")
        return os.path.join(data_dir, _STATE_FILENAME)

    def _load_state(self):
        """功能：读取上次开关状态（SQLite 优先，JSON 兜底）
        注意：恢复尺寸时下限钳到 600×400；最后以 save=False 调用 set_enabled，
              保证「加载状态」不反过来触发写盘（避免启动即写脏配置）。
        参数: 无
        返回: 无
        """
        state = {}
        try:
            from lib.db_helper import get_db  # 作用说明：取嵌入式数据库单例，从 app_config 读回开关状态
            raw = get_db().get_config(_STATE_KEY)
            if raw:
                state = json.loads(raw)
        except Exception:
            state = {}
        if not state:
            try:
                with open(self._state_file(), "r", encoding="utf-8") as fh:
                    state = json.load(fh)
            except (OSError, ValueError):
                state = {}
        try:
            width = int(state.get("panel_w", 980))
            height = int(state.get("panel_h", 680))
            self._panel.resize(max(600, width), max(400, height))
        except (TypeError, ValueError):
            pass
        self.set_enabled(bool(state.get("enabled", False)), save=False)

    def _save_state(self):
        """功能：保存开关状态与面板尺寸（SQLite + JSON）
        注意：会创建 系统v7.5 目录并写两个存储（SQLite app_config + JSON 备份）；
              任一失败只打印提示，不向上抛，避免关闭面板时报错。
        参数: 无
        返回: 无
        """
        state = {
            "enabled": bool(self._enabled),
            "panel_w": int(self._panel.width()),
            "panel_h": int(self._panel.height()),
        }
        try:
            from lib.db_helper import get_db  # 作用说明：取嵌入式数据库单例，把开关状态写入 app_config
            get_db().set_config(_STATE_KEY, json.dumps(state, ensure_ascii=False))
        except Exception as exc:
            print("[控件拾取器] 写入 SQLite 状态失败: " + str(exc))
        try:
            path = self._state_file()
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(state, fh, ensure_ascii=False, indent=2)
        except OSError as exc:
            print("[控件拾取器] 写入 JSON 状态失败: " + str(exc))

    def set_enabled(self, enabled, save=True):
        """功能：开启/关闭拾取模式（同步按钮状态、面板与高亮框）
        注意：回写开关按钮时用 blockSignals 阻断 toggled 信号，防止与按钮回调互相递归；
              save=False 用于初始化恢复（只改内存不落盘）；关闭时会隐藏并销毁高亮框。
        参数:
            enabled: True=开启，False=关闭
            save: 是否立即持久化（初始化恢复时传 False）
        返回: 无
        """
        self._enabled = bool(enabled)
        if self._toggle_btn is not None:
            self._toggle_btn.blockSignals(True)
            self._toggle_btn.setChecked(self._enabled)
            self._toggle_btn.blockSignals(False)
        if self._enabled:
            self._title_label.setText("控件拾取器 · 拾取模式已开启")
            self._status_label.setText("拾取中：点击任意控件查看信息，原控件动作已被拦截。")
            self._panel.show()
            self._panel.raise_()
        else:
            self._title_label.setText("控件拾取器 · 未开启")
            self._status_label.setText("已关闭拾取模式，控件恢复原来的点击行为。")
            self._hide_band()
        if save:
            self._save_state()

    def _hide_band(self):
        """功能：隐藏高亮框
        注意：调用 deleteLater 后立即把 _band 置 None（避免悬空引用）；
              高亮框所属窗口已被销毁时吞掉 RuntimeError，不向外抛。
        参数: 无
        返回: 无
        """
        if self._band is not None:
            try:
                self._band.hide()
                self._band.deleteLater()
            except RuntimeError:
                pass
            self._band = None

    # 事件拦截：拾取模式下吞掉鼠标按下/释放，避免触发原动作

    def eventFilter(self, obj, event):
        """功能：应用级事件过滤器
        说明：只在鼠标按下时拾取，并吞掉随后的释放事件；
              点击拾取器自身面板/开关按钮时不拦截，保证面板可操作。
        参数:
            obj: 事件接收对象
            event: QEvent
        返回:
            bool True=事件已被消费
        """
        event_type = event.type()
        if event_type not in (QEvent.Type.MouseButtonPress,
                              QEvent.Type.MouseButtonRelease,
                              QEvent.Type.MouseButtonDblClick):
            return False
        if not isinstance(obj, QWidget) or self._is_own_widget(obj):
            return False

        if event_type == QEvent.Type.MouseButtonPress:
            if event.button() != Qt.MouseButton.LeftButton:
                return False
            ctrl_click = bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier)
            if not self._enabled and not ctrl_click:
                return False
            self._swallow_release = True
            self._pick(obj)
            return True

        if self._swallow_release:
            if event_type == QEvent.Type.MouseButtonRelease:
                self._swallow_release = False
            return True
        return False

    def _is_own_widget(self, widget):
        """功能：判断控件是否属于拾取器自身（面板、开关按钮）
        注意：只判断这两个自身窗口；控件或其祖先已被销毁时吞掉 RuntimeError，
              按「不属于自身」处理，保证事件过滤器不会因对象消失而崩溃。
        参数:
            widget: 控件
        返回:
            bool
        """
        for own in (self._panel, self._toggle_btn):
            if own is None:
                continue
            try:
                if widget is own or own.isAncestorOf(widget):
                    return True
            except RuntimeError:
                pass
        return False

    def _normalize_target(self, widget):
        """功能：把 viewport / 输入框内部子控件归一化为有意义的控件
        注意：只做「向上取一级父控件」的归一化（视口→滚动区、内部行编辑→输入框）；
              不修改原事件对象，也未识别到特征父控件时原样返回接收控件。
        参数:
            widget: 事件接收控件
        返回:
            QWidget 用于展示的目标控件
        """
        parent = widget.parentWidget()
        if parent is not None:
            try:
                if hasattr(parent, "viewport") and parent.viewport() is widget:
                    return parent
            except RuntimeError:
                pass
            if type(parent).__name__ in (
                    "QComboBox", "QSpinBox", "QDoubleSpinBox", "QDateEdit",
                    "QTimeEdit", "QTextEdit", "QPlainTextEdit"):
                return parent
        return widget

    # 拾取与信息面板渲染

    def _pick(self, receiver):
        """功能：拾取一个控件并刷新面板/高亮框
        注意：一次性产生多处副作用——写面板文本、改状态栏、建橙色高亮框、
              移动并置顶面板；同时把报告与定位文本缓存到 self._last_*，
              供「复制全部 / 复制定位」按钮使用。
        参数:
            receiver: 鼠标事件实际接收控件
        返回:
            str 报告文本
        """
        target = self._normalize_target(receiver)
        self._refresh_host_maps()
        module_label, module_rel = self._module_for(target)
        report, location = self._build_report(target, receiver, module_label, module_rel)
        self._last_report = report
        self._last_location = location
        self._text_view.setPlainText(report)
        self._status_label.setText("已拾取：" + type(target).__name__ +
                                   ("#" + target.objectName() if target.objectName() else "#(未命名)"))
        self._show_band(target)
        self._show_panel_near(target)
        return report

    def _refresh_host_maps(self):
        """功能：刷新「控件对象 -> 主窗口属性名」映射
        注意：每次拾取都重建，因此主窗口新增/改名控件后无需重新挂载拾取器；
              用 id() 作键，控件被销毁期间可能命中失效 id（只用于展示，不持有引用）。
        参数: 无
        返回: 无
        """
        self._attr_map = {}
        for name, value in vars(self.host).items():
            if isinstance(value, QWidget):
                self._attr_map[id(value)] = name

    def _nearest_host_attr(self, target):
        """功能：找目标控件在 host 上的属性名
        注意：会跳过名为 tabs 的公共祖先（它属于所有页面，会掩盖页面来源）；
              返回第二项 True 表示命中的只是祖先容器，控件本身没挂 host。
        参数:
            target: 控件
        返回:
            (属性名, 是否仅为祖先容器) 或 (None, False)
        """
        direct = self._attr_map.get(id(target))
        if direct:
            return direct, False
        parent = target.parentWidget()
        while parent is not None and parent is not self.host:
            name = self._attr_map.get(id(parent))
            # tabs 是所有页面控件的公共祖先，跳过以免掩盖页面来源
            if name and name != "tabs":
                return name, True
            parent = parent.parentWidget()
        return None, False

    def _module_for(self, target):
        """功能：判断控件所属 TAB/UI 模块
        注意：QTabBar 被归类为顶栏特殊页；控件或其祖先已销毁时吞掉 RuntimeError，
              最后返回 (None, None)，报告里标注「未识别到模块」而不是报错。
        参数:
            target: 控件
        返回:
            (模块标签, 相对源码路径) 或 (None, None)
        """
        tabs = getattr(self.host, "tabs", None)
        try:
            if isinstance(tabs, QTabWidget) and tabs.isAncestorOf(target):
                child = target
                while child.parentWidget() is not None and child.parentWidget() is not tabs:
                    child = child.parentWidget()
                if isinstance(child, QTabBar):
                    return "顶部选项卡栏（QTabWidget 内置 QTabBar）", "plugins/彩票预测.py"
                index = tabs.indexOf(child)
                if index >= 0:
                    title = tabs.tabText(index)
                    if title in self._tab_info:
                        order, rel = self._tab_info[title]
                        return "[%s] %s" % (order, title), rel
                    return "选项卡：" + title, None
        except RuntimeError:
            pass
        top_bar = self.host.findChild(QWidget, "TopBar")
        try:
            if top_bar is not None and (top_bar is target or top_bar.isAncestorOf(target)):
                return "主窗口顶栏（plugins/彩票预测.py）", "plugins/彩票预测.py"
        except RuntimeError:
            pass
        return None, None

    def _build_report(self, target, receiver, module_label, module_rel):
        """功能：生成控件信息报告与源码定位文本
        注意：全程只读取控件属性（几何、文字、样式表），不修改控件；
              报告为多行文本，另单独返回「仅定位文本」供复制定位按钮使用，
              源码匹配不到时明确写「Qt 内部控件无创建行」而不是留空。
        参数:
            target: 展示控件
            receiver: 实际事件接收控件
            module_label: 所属模块标签
            module_rel: 所属模块源码相对路径
        返回:
            (完整报告, 仅定位文本)
        """
        cls_name = type(target).__name__
        cls_module = type(target).__module__
        obj_name = target.objectName()
        text = _widget_text(target)
        geo = target.geometry()
        global_pos = target.mapToGlobal(QPoint(0, 0))
        host_pos = self.host.mapFromGlobal(global_pos)
        parent = target.parentWidget()
        parent_geo = parent.geometry() if parent is not None else QRect()
        hint = target.sizeHint()

        report = []
        report.append("控件拾取结果")
        report.append("=" * 72)
        report.append("类名：%s" % cls_name)
        report.append("  Python 模块：%s" % cls_module)
        report.append("objectName：%s" % (obj_name if obj_name else "（空）"))
        if text:
            report.append("显示文字：%s" % _short(text, 80))
        report.append("可见：%s    启用：%s" % ("是" if target.isVisible() else "否",
                                              "是" if target.isEnabled() else "否"))
        if receiver is not None and receiver is not target:
            report.append("实际接收事件：%s#%s（已归一化为上面的控件）"
                          % (type(receiver).__name__, receiver.objectName() or "(未命名)"))

        # 几何信息
        report.append("")
        report.append("【几何信息】")
        report.append("  相对父控件：x=%d  y=%d  w=%d  h=%d"
                      % (geo.x(), geo.y(), geo.width(), geo.height()))
        report.append("  绝对坐标：  x=%d  y=%d  （屏幕全局左上角）"
                      % (global_pos.x(), global_pos.y()))
        report.append("  主窗口内：  x=%d  y=%d" % (host_pos.x(), host_pos.y()))
        report.append("  父控件尺寸：w=%d  h=%d；sizeHint：%d×%d"
                      % (parent_geo.width(), parent_geo.height(), hint.width(), hint.height()))

        # 父级控件链
        report.append("")
        report.append("【父级控件链】")
        chain = []
        node = target
        depth = 0
        while node is not None and depth < 14:
            try:
                n_geo = node.geometry()
                attr = self._attr_map.get(id(node))
                label = "%s#%s%s  (%d,%d  %d×%d)" % (
                    type(node).__name__, node.objectName() or "(未命名)",
                    " [host.%s]" % attr if attr else "",
                    n_geo.x(), n_geo.y(), n_geo.width(), n_geo.height())
            except RuntimeError:
                label = "%s#(已销毁)" % type(node).__name__
            chain.append(("  " * depth) + ("↑ " if depth else "[0] ") + label)
            if node is self.host:
                break
            node = node.parentWidget()
            depth += 1
        report.extend(chain)

        # 所属模块
        report.append("")
        report.append("【所属模块】")
        if module_label:
            report.append("  %s" % module_label)
            if module_rel:
                report.append("  源码文件：%s" % module_rel)
        else:
            report.append("  未识别到 TAB/UI 模块（可能是 Qt 内部控件或独立弹窗）")

        # 源码定位
        report.append("")
        report.append("【源码定位（怎么改）】")
        loc = self._locate_source(target, module_rel)
        primary = loc.get("primary")
        related = loc.get("related") or []
        method = loc.get("method") or "未匹配"
        confidence = loc.get("confidence") or "低"
        report.append("  匹配方式：%s（置信度：%s）" % (method, confidence))
        if primary:
            report.append("  创建/配置：%s:%d" % (primary["rel"], primary["line"]))
            report.append("    %s" % _short(primary.get("source", ""), 180))
        else:
            report.append("  未在 UI/TAB/plugins 源码中匹配到创建行。")
            report.append("  Qt 内部控件（如滚动区 viewport、QTabBar）由 Qt 自动创建，无源码创建行。")
        seen = set()
        if primary:
            seen.add((primary["rel"], primary["line"]))
        for item in related[:6]:
            key = (item["rel"], item["line"])
            if key in seen:
                continue
            seen.add(key)
            note = item.get("note", "关联")
            report.append("  %s：%s:%d" % (note, item["rel"], item["line"]))
            report.append("    %s" % _short(item.get("source", ""), 180))
        for note in loc.get("notes") or []:
            report.append("  说明：%s" % note)

        # 修改建议 / objectName
        report.append("")
        report.append("【怎么修改 / objectName】")
        attr_name = self._attr_map.get(id(target))
        reference = attr_name or (primary.get("target") if primary else None) or "控件变量"
        if reference == "return":
            reference = "控件变量"
        if obj_name:
            report.append("  objectName 已设置，可直接用于样式表 #%s、findChild 与记忆键。" % obj_name)
        else:
            suggested = self._suggest_object_name(target, attr_name, primary, module_rel)
            report.append("  objectName 为空：在上面的创建行之后补一行")
            report.append("    %s.setObjectName(\"%s\")" % (reference, suggested))
            report.append("  命名建议：页面/区域前缀 + 用途，小写加下划线，如 num_panel_font_spin。")
        if attr_name:
            report.append("  该控件挂在主窗口属性 host.%s 上，下拉框/数字框/复选框/表格状态"
                          "会被 [WidgetState] 记忆机制自动保存。" % attr_name)
        report.append("  直接编辑上面的源码行即可；改动后运行 python docs/生成索引.py 更新行号索引。")

        # 额外属性
        style = target.styleSheet()
        if style:
            report.append("")
            report.append("样式表：%s" % _short(style, 160))

        location_text = self._location_text(primary, related)
        return "\n".join(report), location_text

    def _locate_source(self, target, module_rel):
        """功能：把运行时控件映射回源码创建/配置行
        注意：首次调用触发全量源码扫描（index.build()，较慢），之后走缓存；
              按 objectName → host 属性 → 祖先容器 → 类名+文字 → 类名+模块 → 仅类名
              逐级降级匹配，匹配不到时不抛异常，只把 method 标为「未匹配」。
        参数:
            target: 控件
            module_rel: 所属模块相对路径
        返回:
            dict: primary / related / method / confidence / notes
        """
        index = self._index
        index.build()
        cls_name = type(target).__name__
        obj_name = target.objectName()
        attr_name, is_container = self._nearest_host_attr(target)
        text = _widget_text(target)
        primary = None
        related = []
        notes = []
        method = "未匹配"
        confidence = "低"

        # 1) objectName 精确匹配（最高优先级）
        if obj_name:
            names = [item for item in index.object_names if item["name"] == obj_name]
            if names:
                chosen = index.prefer(names, module_rel)
                ref = chosen["receiver"]
                ctors = [item for item in index.entries
                         if item["rel"] == chosen["rel"] and item["cls"] == cls_name
                         and item["line"] <= chosen["line"]]
                exact = [item for item in ctors if item.get("target") == ref]
                primary = (max(exact, key=lambda item: item["line"]) if exact
                           else (ctors[-1] if ctors else chosen))
                if primary is chosen:
                    related.append(dict(chosen, note="objectName 配置"))
                else:
                    related.append(dict(chosen, note="objectName 配置"))
                    related.extend(self._config_refs(primary["rel"], primary["line"], ref))
                method = "objectName 精确匹配"
                confidence = "高"

        # 2) hold 属性精确匹配（控件直接挂在主窗口上）
        if primary is None and attr_name and not is_container:
            refs = ("self." + attr_name, "host." + attr_name)
            ctors = [item for item in index.entries
                     if item.get("target") in refs and item["cls"] == cls_name]
            if not ctors:
                ctors = [item for item in index.entries if item.get("target") in refs]
            if ctors:
                primary = index.prefer(ctors, module_rel)
                related.extend(self._config_refs(primary["rel"], primary["line"], primary["target"]))
                method = "主窗口属性 host.%s" % attr_name
                confidence = "高"
            else:
                aliases = [item for item in index.aliases if item["name"] == attr_name]
                if aliases:
                    alias = index.prefer(aliases, module_rel)
                    rhs = alias["rhs"]
                    ctors = [item for item in index.entries
                             if item["rel"] == alias["rel"] and item.get("target") == rhs
                             and item["line"] <= alias["line"]]
                    primary = ctors[-1] if ctors else alias
                    related.append(dict(alias, note="挂载到 host.%s" % attr_name))
                    related.extend(self._config_refs(alias["rel"], alias["line"], rhs))
                    method = "局部变量创建 → 挂载到 host.%s" % attr_name
                    confidence = "高"

        # 3) 祖先容器属性（控件是某个 host 容器的子控件）
        if primary is None and attr_name and is_container:
            refs = ("self." + attr_name, "host." + attr_name)
            ctors = [item for item in index.entries if item.get("target") in refs]
            if ctors:
                primary = index.prefer(ctors, module_rel)
                related.extend(self._config_refs(primary["rel"], primary["line"], primary["target"]))
                method = "容器属性 host.%s 的子控件" % attr_name
                confidence = "中"
                notes.append("点击的控件本身未单独挂到 host 上，它是 host.%s 内部创建的子控件。" % attr_name)

        # 4) 类名 + 显示文字
        if primary is None and text:
            normalized = re.sub(r"\s+", " ", text).strip()
            hits = [item for item in index.entries
                    if item["cls"] == cls_name and item.get("text")
                    and re.sub(r"\s+", " ", item["text"]).strip() == normalized]
            if hits:
                primary = index.prefer(hits, module_rel)
                related.extend(dict(item, note="同类同文字候选")
                               for item in hits if item is not primary)
                method = "类名 + 显示文字匹配"
                confidence = "中"

        # 5) 类名 + 所属模块
        if primary is None:
            hits = [item for item in index.entries
                    if item["cls"] == cls_name and (item.get("rel") == module_rel)]
            if hits:
                primary = hits[0]
                related.extend(dict(item, note="同类控件候选") for item in hits[1:4])
                method = "类名 + 所属模块匹配（同类控件较多）"
                confidence = "中低"

        # 6) 仅类名
        if primary is None:
            hits = [item for item in index.entries if item["cls"] == cls_name]
            if hits:
                primary = hits[0]
                related.extend(dict(item, note="同类控件候选") for item in hits[1:4])
                method = "仅类名匹配（无法唯一定位）"
                confidence = "低"

        # 自定义控件类：补充类定义与类内创建行
        class_def = None
        defs = index.class_defs.get(cls_name) or []
        if defs:
            class_def = index.prefer(defs, module_rel)
            related.append(dict(class_def, note="控件类定义"))
            rng = index.class_range(class_def["rel"], cls_name)
            if rng:
                start, end = rng
                inner = [item for item in index.entries
                         if item["rel"] == class_def["rel"] and start <= item["line"] < end
                         and item["cls"] != cls_name and item["cls"].startswith("Q")]
                for item in inner[:3]:
                    related.append(dict(item, note="类内部创建控件"))
                # 该类在其他类体中的实例化行（如 NumberButton 在 NumberPanel 中循环创建）
                sites = [item for item in index.entries
                         if item["cls"] == cls_name and item["rel"] == class_def["rel"]
                         and item["line"] >= end]
                for item in sites[:2]:
                    related.append(dict(item, note="该类实例化位置"))
        if primary is None and class_def is not None:
            primary = class_def
            method = "控件类定义（运行时实例由布局代码创建）"
            confidence = "中低"

        return {
            "primary": primary,
            "related": related,
            "method": method,
            "confidence": confidence,
            "notes": notes,
        }

    def _config_refs(self, rel, start_line, reference, limit=3):
        """功能：取创建行之后对该控件的配置行（setObjectName/setStyleSheet/setRange 等）
        注意：只在创建行之后 70 行内查找，超出视为无关配置；reference 为空或为
              "return" 时直接返回空列表；最多返回 limit 条，不做去重。
        参数:
            rel: 相对源码路径
            start_line: 创建行
            reference: 控件变量名（如 self.font_combo / theme_btn）
            limit: 最多返回条数
        返回:
            list[dict]
        """
        index = self._index
        lines = index._lines.get(rel) or []
        out = []
        if not reference or reference == "return":
            return out
        for line_no in range(start_line + 1, min(len(lines) + 1, start_line + 70)):
            stripped = lines[line_no - 1].strip()
            if stripped.startswith(reference + ".") or stripped.startswith(reference + " ."):
                out.append({
                    "rel": rel, "line": line_no, "source": stripped,
                    "note": "配置行",
                })
                if len(out) >= limit:
                    break
        return out

    @staticmethod
    def _location_text(primary, related):
        """功能：生成「可复制」的定位文本
        注意：静态方法，不依赖实例状态；未匹配时返回固定提示文本（不是空串），
              复制后贴到聊天里也能说明「确实没匹配到」。
        参数:
            primary: 主定位条目
            related: 关联条目
        返回:
            str
        """
        if not primary:
            return "未匹配到源码定位"
        lines = ["%s:%d  %s" % (primary["rel"], primary["line"], primary.get("source", ""))]
        for item in related[:6]:
            lines.append("%s:%d  %s" % (item["rel"], item["line"], item.get("source", "")))
        return "\n".join(lines)

    @staticmethod
    def _suggest_object_name(target, attr_name, primary, module_rel):
        """功能：为 objectName 为空的控件生成推荐命名
        注意：只生成建议字符串，不修改控件；优先用 host 属性名，其次用局部变量名，
              都没有时退回「模块名_类名小写」，非法字符统一替换为下划线。
        参数:
            target: 控件
            attr_name: host 属性名
            primary: 主定位条目
            module_rel: 所属模块路径
        返回:
            str
        """
        if attr_name:
            return attr_name
        target_name = (primary or {}).get("target") or ""
        if target_name and target_name != "return" and "." not in target_name:
            return target_name
        prefix = os.path.splitext(os.path.basename(module_rel or "ui"))[0]
        prefix = re.sub(r"[^0-9a-zA-Z_]", "_", prefix).lower()
        return "%s_%s" % (prefix, type(target).__name__.lower())

    # 高亮框 / 面板定位 / 复制

    def _show_band(self, target):
        """功能：用橙色橡皮筋框标出命中控件
        注意：橡皮筋挂在目标所在顶层窗口上，并设 WA_TransparentForMouseEvents
              以免遮挡点击；多次拾取会先销毁旧框；异常只打印，不中断拾取流程。
        参数:
            target: 控件
        返回: 无
        """
        self._hide_band()
        try:
            window = target.window()
            band = QRubberBand(QRubberBand.Shape.Rectangle, window)
            origin = window.mapFromGlobal(target.mapToGlobal(QPoint(0, 0)))
            band.setGeometry(QRect(origin, target.size()))
            band.setStyleSheet(
                "QRubberBand { border: 3px solid #FF6B00; background-color: rgba(255,107,0,40); }")
            band.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
            band.show()
            self._band = band
        except Exception as exc:
            print("[控件拾取器] 高亮框显示失败: " + str(exc))

    def _show_panel_near(self, target):
        """功能：把信息面板显示在点击位置附近（不遮挡屏幕边缘）
        注意：会按「点击点所在屏幕」的可用区域夹紧坐标，并移动 + 置顶面板；
              多屏或缩放到高 DPI 时会跟随当前屏幕，不会跑到主屏。
        参数:
            target: 控件
        返回: 无
        """
        point = target.mapToGlobal(QPoint(0, 0))
        screen = QApplication.screenAt(point) or QApplication.primaryScreen()
        area = screen.availableGeometry() if screen is not None else QRect(0, 0, 1280, 800)
        width = self._panel.width()
        height = self._panel.height()
        x = point.x() + 28
        y = point.y() + 28
        if x + width > area.right():
            x = point.x() - width - 28
        if y + height > area.bottom():
            y = point.y() - height - 28
        x = max(area.left(), min(x, max(area.left(), area.right() - width)))
        y = max(area.top(), min(y, max(area.top(), area.bottom() - height)))
        self._panel.move(x, y)
        self._panel.show()
        self._panel.raise_()

    def _copy_all(self):
        """功能：复制完整报告
        注意：直接写系统剪贴板（会覆盖用户原有剪贴板内容）；尚未拾取过时
              复制的是占位提示文本，而不是空字符串。
        参数: 无
        返回: 无
        """
        QApplication.clipboard().setText(self._last_report or "（尚未拾取控件）")
        self._status_label.setText("已复制完整报告（%d 字符）" % len(self._last_report))

    def _copy_location(self):
        """功能：只复制源码定位
        注意：只复制「文件:行号 + 源码文本」的定位片段，不含完整报告；
              直接覆盖系统剪贴板，未拾取过时复制占位提示。
        参数: 无
        返回: 无
        """
        QApplication.clipboard().setText(self._last_location or "（尚未拾取控件）")
        self._status_label.setText("已复制源码定位")


# 预留：控件拾取器安装入口（调试工具，当前未接入主流程）
def install_control_picker(host):
    """功能：在指定主窗口上挂载控件拾取器（幂等）
    注意：幂等——host 上已有 _control_picker 时直接返回旧实例，不会重复装
          事件过滤器/快捷键/顶栏按钮；会向 host 注入私有属性 _control_picker。
    参数:
        host: 主窗口（LotteryPredictionWindow）
    返回:
        ControlPicker 单例
    """
    existing = getattr(host, "_control_picker", None)
    if existing is not None:
        return existing
    picker = ControlPicker(host)
    host._control_picker = picker
    return picker
