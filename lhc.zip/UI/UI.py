# -*- coding: utf-8 -*-
"""
============================================================================
UI/UI.py - 全局 PyQt6 控件统一导入中心
============================================================================
功能说明：
    集中管理项目所需的全部 PyQt6 控件导入。
    - 插件层（plugins/）禁止直接 from PyQt6 import xxx，
      统一通过 `from UI import *` 获取控件
    - 需要新增 Qt 控件时，只在本文件中添加导入

为什么必须「唯一入口」：
    PyQt6 的三个子模块（QtWidgets / QtCore / QtGui）各自持有同名类型的不同引用，
    一旦业务代码也直接 from PyQt6 import，就会出现两套导入路径、升级或替换版本时
    需要改几十处；集中到这里后，全项目只有本文件与 PyQt6 耦合。
    同时 `UI/__init__.py` 以 `from .UI import *` 转发，使 `from UI import (QPushButton, ...)`
    在 14 个选项卡页面里都能成立。

导出约定：
    本文件没有定义 `__all__`，因此 `from .UI import *` 会导出所有不以 `_` 开头的名字
    （即下面三个 import 的全部控件）。新增控件只需加在第 20/48/61 行的括号里，
    对外导出的名字数量会随之增加——这是唯一正确的扩展方式。

技术约束：
    本文件只允许导入 PyQt6，禁止导入 numpy/pandas 等科学计算库。
    （否则会把重型依赖拖到「启动即加载」的路径上，破坏 lib 的懒加载策略。）
============================================================================
"""

# ============================================================================
# QtWidgets：界面控件
# ============================================================================
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget,  # 作用：应用单例（事件循环/剪贴板）、主窗口基类、所有可视控件基类——缺任一，窗口建不起来
    # 布局
    QVBoxLayout, QHBoxLayout, QGridLayout,  # 作用：垂直/水平/网格布局；不用布局时控件按绝对坐标堆叠，窗口缩放即重叠
    # 容器与分组
    QTabWidget, QTabBar, QScrollArea, QSplitter, QStackedWidget,  # 作用：选项卡容器（tabs.count()==14）、标签条、页面滚动壳（小窗口防截断）、可拖动分隔条（尺寸记忆）、页堆栈（addTab 内部使用）
    QFrame, QGroupBox, QToolBar, QStatusBar, QMenuBar, QMenu,  # 作用：分隔线/卡片外框、分组框、顶部工具栏、底部状态栏、菜单栏与下拉菜单
    # 基础控件
    QPushButton, QRadioButton, QCheckBox, QLabel, QLineEdit, QTextEdit,  # 作用：按钮、单选、复选、文本标签、单行输入、多行文本（预测结果/复制导出都落在 QTextEdit）
    QComboBox, QSpinBox, QSlider, QProgressBar, QScrollBar,  # 作用：下拉框（分隔符/筛选）、整数微调（期数/字号/权重）、滑块、进度条、滚动条（滚动区域内部件）
    # 列表与表格
    QListWidget, QListWidgetItem, QTableWidget, QTableWidgetItem,  # 作用：列表与表格控件及其条目——历史记录、明细表、控件拾取器列表都用它们
    QHeaderView, QAbstractItemView,  # 作用：表头伸缩策略、单元格选择/编辑行为常量——设置表格交互方式时使用
    # 对话框
    QDialog, QDialogButtonBox, QMessageBox, QFileDialog, QInputDialog,  # 作用：自定义对话框、标准按钮盒、提示/确认框、文件选择、文本输入
    QColorDialog, QFontDialog,  # 作用：颜色选择、字体选择——自定义号码配色与字体设置入口
    # 样式与委托
    QSizePolicy, QStyleFactory, QStyle, QStyledItemDelegate,  # 作用：尺寸策略、界面风格工厂、标准图标/像素度量、自定义绘制委托（表格着色）
    QStyleOptionViewItem, QStyleOptionFocusRect,  # 作用：委托绘制时传入的样式选项结构（选中态、焦点框），自定义 delegate 必备
    # 分组与特效
    QButtonGroup, QGraphicsOpacityEffect,  # 作用：互斥按钮分组、透明度特效（禁用态/淡出提示）
    # 控件拾取器（UI/control_picker.py）：高亮框
    QRubberBand,  # 作用：橡皮筋高亮框，控件拾取时圈出鼠标框选区域
)

# ============================================================================
# QtCore：核心非GUI功能（信号、线程、动画、定时器等）
# ============================================================================
from PyQt6.QtCore import (
    Qt, QSize, QPoint, QRect,  # 作用：全局枚举（对齐/焦点/滚轮策略）、尺寸、坐标、矩形——几乎所有 setFixedSize/geometry 计算
    QTimer, QThread, QObject,  # 作用：单次/周期定时器（首帧后延迟恢复分隔条尺寸）、工作线程（长任务不冻结界面）、QObject 基类（信号宿主）
    pyqtSignal, pyqtSlot,  # 作用：声明跨线程信号、槽装饰器——Worker 线程把进度/完成事件送回 GUI 线程
    QPropertyAnimation, QParallelAnimationGroup, QEasingCurve,  # 作用：属性动画、并行动画组、缓动曲线——展开/收起与提示淡出
    QDateTime, QDate, QUrl,  # 作用：日期时间（记录保存时间）、日期、URL（QDesktopServices 打开本地/网页链接）
    # 控件拾取器（UI/control_picker.py）：事件类型判断
    QEvent,  # 作用：事件类型枚举，控件拾取器据此过滤鼠标移动/按键事件
)

# ============================================================================
# QtGui：字体、颜色、绘图、动作等
# ============================================================================
from PyQt6.QtGui import (
    QFont, QFontDatabase, QColor, QPalette, QBrush, QPen, QPainter,  # 作用：字体对象、系统字体族枚举（FontUtils 缓存）、颜色、调色板、画刷、画笔、绘图器——全局字体与自绘控件基础
    QPixmap, QImage, QIcon, QAction, QKeySequence, QShortcut, QCursor,  # 作用：位图（截图/图标）、图像、图标、动作（菜单项）、快捷键序列、快捷键对象、鼠标指针形状
    QFontMetrics, QStandardItemModel, QStandardItem, QDesktopServices,  # 作用：字体度量（按显示宽度自适应控件宽度）、标准项模型/条目（下拉与列表数据）、打开文件/网址的系统服务
)
