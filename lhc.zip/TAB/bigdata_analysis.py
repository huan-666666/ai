# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/bigdata_analysis.py - 「大数据分析」选项卡页面构建模块
===========================================================================
模块职责：
    [16] 大数据分析页的全部界面构建、结果渲染与交互回调：
        1) 顶部横幅（标题 + 数据源徽标 + 开始分析/复制/导出按钮）
        2) 响应式「KPI + 参数」排（宽时 8 项单行，窄时 4 KPI + 4 参数两行）
        3) 推荐生肖卡片、推荐数字号码球矩阵、红/绿/蓝波色评分卡
        4) 评分明细表与统计检验文本
        5) 三段式可拖动分栏（顶部参数 / 中部结果 / 底部明细）及尺寸记忆

在架构中的位置：
    TAB/ 界面层的一个页面。run.py 按 TAB_INFO（order=16）调用 install(host)，
    install 把三个按钮回调挂到主窗口 LotteryPredictionWindow 的 host._xxx 属性
    （host 即主窗口），build(host) 返回页面 QWidget。
    分析计算不在本模块，统一调用 lib.math_algo.BigDataAnalyzer。

数据流：
    host._analysis_records(window)（优先 DuckDB，失败回退内存）
        → BigDataAnalyzer.analyze()（频率 / 遗漏 / 转移三维评分）
        → result 写入 host._bigdata_result（供复制 / 导出复用）
        → render_result(host, result) 刷新 KPI / 卡片 / 号码球 / 明细表 / 统计文本

依赖：
    - host._analysis_records / host._safe_write_file / host._apply_splitter_sizes /
      host.tabs（均由主窗口提供）
    - lib.math_algo.BigDataAnalyzer（analyze / format_result_text / format_stats_text）
    - lib.data_process.LotteryConfig（NUMBER_ELEMENTS 五行映射）
    - TAB.widgets.NumberBallWithZodiac（号码球渲染）
    - UI/UI.py 统一导出的 Qt 控件（禁止直接 from PyQt6 import xxx）

导出对象：
    TAB_INFO        —— 选项卡声明（title=大数据分析, order=16, enabled=True）
    install(host)   —— 绑定 host._on_bigdata_* 回调，返回 build 的页面控件
    build(host)     —— 构建页面控件（三段式 QSplitter）
    其余模块级函数均为页面内部实现（_card / _kpi_card / _render_* 等）。

约束：
    - 除 _ResponsiveStatusRow 类外，全部为“自由函数 + host 显式传参”，不使用类 self
    - 分析失败只弹框提示，不向主循环抛出；渲染异常不得破坏已有界面
    - 字号下限 15px、KPI/参数块高度 30px、列间距 6px 等视觉基线不得随意改动
===========================================================================
"""

import os as _os_boot  # 作用说明：提供路径拼接与存在性判断，供启动引导向上定位项目根目录
import sys as _sys_boot  # 作用说明：提供 sys.path 操作能力，把定位到的项目根目录加入模块搜索路径

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

import datetime  # 作用说明：提供当前时间，用于生成带秒级时间戳的默认导出文件名

from UI import (  # 作用说明：统一导出 Qt 控件/信号/枚举，集中依赖并避免直接 from PyQt6 import
                QApplication, QEvent, QFileDialog, QFrame, QGridLayout,
                QHBoxLayout, QLabel, QMessageBox, QObject, QProgressBar, QPushButton,
                QScrollArea, QSizePolicy, QSpinBox, QSplitter,
                QThread, QTimer, QVBoxLayout, QWidget, Qt, pyqtSignal, pyqtSlot)
from lib.data_process import LotteryConfig  # 作用说明：提供 NUMBER_ELEMENTS 五行映射，号码球展示需要
from lib.math_algo import BigDataAnalyzer  # 作用说明：提供三维评分分析、结果文本与统计文本格式化能力
from TAB.widgets import NumberBallWithZodiac, apply_spin_style  # 作用说明：号码球控件 + 全项目统一数字框样式（内边距/高度/箭头定位）


# 横幅副标题默认文案：分析前展示功能说明，分析中临时替换为进度提示，
# 分析失败/取消时用它回退（render_result 会用结果摘要覆盖）。
BANNER_SUBTITLE_DEFAULT = (
    "按「频率 · 遗漏 · 转移」三维评分，从历史开奖中挖掘更合适的 7 个生肖与 7 个数字")


def _summary_text(result):
    """生成横幅副标题里的结果摘要文本

    功能:
        把 analyze() 结果里的 meta 字段拼成一行中文摘要，供横幅副标题复用；
        无结果时回退到默认说明文案，保证成功/失败/取消三种状态文案格式一致。

    参数:
        result (dict|None): BigDataAnalyzer.analyze() 的结果；None/空字典视为“暂无结果”。

    返回:
        str: 有结果时返回「分析完成 · 数据源 … · 参与 … 期 · 最新期号 … · 波色倾向 …」；
             无结果时返回 BANNER_SUBTITLE_DEFAULT（与页面初始副标题完全一致）。

    副作用/异常:
        纯字符串拼装，不访问控件，不抛异常。

    线程约束:
        可在任意线程调用；本模块只在 GUI 线程使用（render_result / 失败回退）。
    """
    if not result:
        return BANNER_SUBTITLE_DEFAULT
    meta = result.get('meta', {})
    return "分析完成 · 数据源 %s · 参与 %s 期 · 最新期号 %s · 波色倾向 %s" % (
        meta.get('source', '内存'), meta.get('used', ''), meta.get('latest_period', ''),
        meta.get('top_wave', '-'))


# ╔══════════════════════════════════════════════════════════════════╗
# ║  [大数据分析：后台 Worker 与页面控制器]
# ╚══════════════════════════════════════════════════════════════════╝

class _BigDataAnalyzeWorker(QObject):
    """大数据分析后台工作对象：在线程里只做纯计算，绝不创建/更新 Qt 控件

    职责:
        在 QThread 内依次完成三件事：
            1) 取分析用历史记录（host._analysis_records，优先 DuckDB、失败回退内存）；
            2) 调用 lib.math_algo.BigDataAnalyzer.analyze() 做三维评分；
            3) 通过信号把「进度 / 结果 / 错误 / 已取消」回抛给 GUI 线程。

    参数:
        host: 主窗口实例。仅读取 historical_data / zodiac_binding / _db 等数据属性，
              不读写任何控件；_analysis_records 内部由 lib.db_helper 的锁保证
              SQLite/DuckDB 的跨线程串行访问安全。
        window (int): 参与分析的期数（从最新一期往前取）。
        weights (dict): {'freq','gap','trans'} 三项权重，构造时做一份浅拷贝快照，
                        避免分析期间用户在界面上改数字框影响本次结果。

    返回:
        无（QObject 子类，通过信号输出）。

    线程安全:
        - run() 只允许被 QThread.started 触发，运行在 worker 线程；
        - 信号与 GUI 侧槽通过 Qt 的 AutoConnection 自动排队（queued），
          保证渲染/弹窗全部发生在主线程；
        - 中断只做「协作式」检查：analyze 是单个不可分割的函数调用，
          无法在内部打断，因此只在取数前后、计算完成后检查
          isInterruptionRequested()，被中断时不再 emit 结果。

    异常:
        run() 内部捕获全部异常并通过 failed 信号回传，不会让线程因异常静默退出。
    """

    # 进度提示：由 GUI 线程的控制器显示到横幅副标题/状态栏
    progress = pyqtSignal(str)
    # 已取消：页面切走或窗口关闭时发出，GUI 线程据此恢复按钮并提示「已取消」
    cancelled = pyqtSignal()
    # 计算完成：只传纯 dict（BigDataAnalyzer.analyze 的返回值），不传控件引用
    finished = pyqtSignal(dict)
    # 失败：(级别, 标题, 正文)。级别 'warning'=数据不足（原逻辑弹 warning），
    # 'critical'=计算异常（原逻辑弹 critical）
    failed = pyqtSignal(str, str, str)

    def __init__(self, host, window, weights):
        """保存本次分析的参数快照（必须在 GUI 线程构造，再 moveToThread）

        功能:
            在 GUI 线程构造时保存 host 引用、分析期数与三项权重快照，供 run()
            在 worker 线程读取；构造本身不启动线程、不访问任何控件。

        参数:
            host: 主窗口实例（仅作为数据源使用）。
            window (int): 分析期数。
            weights (dict): 三项特征权重。

        返回: None。

        副作用:
            仅保存引用/快照，不启动计算。

        异常: 无。
        """
        super().__init__()
        self._host = host
        self._window = int(window)
        self._weights = dict(weights)  # 快照，避免运行期间界面改值影响本次结果

    @staticmethod
    def _is_interrupted():
        """判断当前 worker 线程是否收到了中断请求

        功能:
            读取当前 QThread 的 isInterruptionRequested() 标志，供 run() 在取数
            前后与计算完成后判断是否需要放弃回填结果。

        参数: 无。

        返回:
            bool: True=调用方（页面切换/关闭窗口）已请求中断。

        说明:
            为什么用 QThread.currentThread()：worker 自身不知道自己挂在哪个线程上，
            从当前线程对象读取中断标志是最直接、且不跨线程访问 GUI 对象的方式。

        注意:
            只读取线程中断标志，不触碰任何 Qt 控件；本方法必须在 worker 线程内调用，
            若在 GUI 线程调用会读到主线程的标志，语义不符。
        """
        return QThread.currentThread().isInterruptionRequested()

    @pyqtSlot()
    def run(self):
        """线程入口：取数 → 计算 → emit 结果

        功能:
            在 worker 线程内依次读取历史记录、调用 BigDataAnalyzer.analyze()
            做三维评分，并通过 progress/cancelled/finished/failed 信号回传结果；
            任何异常都转为 failed 信号，避免线程因异常静默退出。

        参数: 无。
        返回: None（通过 progress/cancelled/finished/failed 信号输出）。

        副作用:
            读取 host.historical_data / host._db（均有锁或只读），调用
            _analysis_records 时可能触发 DuckDB 同步；不写任何界面控件。

        异常:
            全部捕获；失败时 emit failed('critical', '分析失败', '大数据分析执行出错：…')，
            与改造前同步版本的弹窗文案一致。
        """
        # 线程刚启动就已被要求中断（例如启动瞬间用户就切页/关窗），直接取消
        if self._is_interrupted():
            self.cancelled.emit()
            return

        self.progress.emit("正在读取历史数据…")
        try:
            # 为什么把取数也放进后台：实测首轮 DuckDB 同步耗时约 3.9s，
            # 比 analyze 本身（约 7ms）高两个数量级，留在 GUI 线程仍会假死。
            records, data_source = self._host._analysis_records(self._window)
        except Exception as exc:
            self.failed.emit('critical', '分析失败', "大数据分析执行出错：%s" % exc)
            return

        if self._is_interrupted():
            self.cancelled.emit()
            return
        if not records:
            # 与改造前一致：数据不足只弹 warning，不当作计算异常
            self.failed.emit('warning', '数据不足', "请先导入历史开奖数据后再分析")
            return

        self.progress.emit("正在计算推荐结果…")
        try:
            result = BigDataAnalyzer.analyze(
                records,
                zodiac_binding=self._host.zodiac_binding,
                window=self._window,
                weights=self._weights,
                pick=7,
            )
        except Exception as exc:
            self.failed.emit('critical', '分析失败', "大数据分析执行出错：%s" % exc)
            return

        # 数据来源写入 meta.source，与改造前 result.setdefault('meta', {})['source'] 等价
        result.setdefault('meta', {})['source'] = data_source

        # 计算完成后再检查一次中断：关窗时即使计算已跑完，也不再回填界面
        if self._is_interrupted():
            self.cancelled.emit()
            return
        self.finished.emit(result)


class _BigDataPageController(QObject):
    """大数据分析页的线程生命周期与界面状态控制器（常驻 GUI 线程）

    职责:
        1) 启动后台线程（持有 QThread / Worker 引用，防止被 GC）；
        2) 接收 Worker 的进度/完成/失败/取消信号，在 GUI 线程更新界面；
        3) 页面切走、窗口关闭时请求中断；关闭时做「有界」等待，
           避免 Qt 报 "QThread: Destroyed while thread is still running"。

    参数:
        host: 主窗口实例。控制器会被设为其子对象，生命周期跟随窗口。

    线程安全:
        - 本类的所有槽都在 GUI 线程执行（Worker 信号跨线程自动排队）；
        - request_interrupt() 只是设置线程的中断标志，不触碰控件；
        - shutdown() 会在 GUI 线程内阻塞等待线程结束，因此等待必须有时限。

    异常:
        控件可能在关窗流程中已被销毁，所有界面访问都用 RuntimeError 兜底。
    """

    def __init__(self, host):
        """初始化控制器并安装关闭事件过滤器

        功能:
            以 host 为父对象创建控制器，并把自身安装为 host 的 Close 事件过滤器；
            用于在窗口关闭前请求中断并等待后台线程结束。

        参数:
            host: 主窗口实例（QObject 子类，必须是 QWidget/QMainWindow 才能装过滤器）。

        返回: None。

        副作用:
            host.installEventFilter(self)：用于在 closeEvent 之前请求中断并等待线程，
            不修改主窗口 closeEvent（本任务约束只允许改本文件）。

        异常: 无。
        """
        super().__init__(host)  # 以 host 为父对象：随窗口销毁，信号连接自动断开
        self._host = host
        host.installEventFilter(self)

    # 启动与中断
    def start(self):
        """启动一次后台分析（含重入保护与界面置忙）

        功能:
            从界面读取分析期数与三项权重，创建 QThread + Worker 并启动；
            同时把按钮置忙、横幅显示进度，并把线程/Worker 引用挂到 host 防止 GC。

        参数: 无（从 host 读取 bd_window_spin / 权重数字框 / historical_data）。

        返回: None。

        副作用:
            - 创建 QThread 与 Worker，把 Worker.moveToThread；
            - 禁用「开始分析」按钮并改文案，横幅副标题显示进度提示；
            - host._bd_thread / host._bd_worker / host._bd_busy 写入运行状态。

        异常:
            数据为空时弹 warning 并返回；线程创建异常不在本函数捕获（属编程错误）。

        说明:
            为什么要把 thread/worker 存到 host：Qt 只持有 C++ 侧对象，Python 包装对象
            若没有引用会被 GC 回收，导致底层 QThread 被提前析构并崩溃。
        """
        host = self._host
        if getattr(host, '_bd_busy', False):
            # 运行中再次点击：直接提示并返回，禁止并发重复触发
            host.statusBar().showMessage("大数据分析正在进行中，请稍候…", 3000)
            return
        if not host.historical_data:
            QMessageBox.warning(host, "数据不足", "请先导入历史开奖数据后再分析")
            return

        window = host.bd_window_spin.value()
        weights = {
            'freq': host.bd_w_freq_spin.value(),
            'gap': host.bd_w_gap_spin.value(),
            'trans': host.bd_w_trans_spin.value(),
        }

        thread = QThread(host)  # 父对象=host：即使 Python 引用被清空，C++ 对象仍归窗口管理
        worker = _BigDataAnalyzeWorker(host, window, weights)
        worker.moveToThread(thread)  # 关键：run() 将在线程里执行，而不是 GUI 线程

        # 线程启动/结束与 Worker 信号连接（全部经 Qt 自动排队回 GUI 线程）
        thread.started.connect(worker.run)
        worker.progress.connect(self.on_worker_progress)
        worker.cancelled.connect(self.on_worker_cancelled)
        worker.finished.connect(self.on_worker_finished)
        worker.failed.connect(self.on_worker_failed)
        # 三种终止路径都要让线程事件循环退出，否则 QThread 会一直保持运行
        worker.cancelled.connect(thread.quit)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        # 为什么在这里 deleteLater：线程结束信号发出后，Worker 已不再需要；
        # 交给各自所属线程的事件循环销毁，避免跨线程直接 delete 造成崩溃
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(self.on_thread_finished)

        host._bd_thread = thread
        host._bd_worker = worker
        host._bd_busy = True

        self._set_start_button_busy(True)
        self._safe_set_subtitle("正在分析…（后台计算中，界面可继续操作）")
        host.statusBar().showMessage("大数据分析已开始：后台计算中…", 5000)

        thread.start()

    def request_interrupt(self):
        """请求中断当前分析（页面切走 / 窗口关闭时调用，不阻塞）

        功能:
            对 host._bd_thread 调用 requestInterruption() 与 quit()，让 Worker
            在下一个检查点放弃 emit；本函数立即返回，不阻塞 GUI 线程。

        参数: 无。

        返回:
            None。

        副作用:
            对运行中的线程调用 requestInterruption()；Worker 会在下一个检查点
            放弃 emit 结果。注意：analyze 本身不可中途打断，最长需等待其自然结束。

        异常:
            线程对象已被销毁时忽略 RuntimeError。
        """
        thread = getattr(self._host, '_bd_thread', None)
        if thread is None:
            return
        try:
            if thread.isRunning():
                thread.requestInterruption()
                thread.quit()  # 让线程事件循环退出；Worker.run 返回后线程即结束
        except RuntimeError:
            pass

    def shutdown(self, timeout_ms=8000):
        """窗口关闭前同步收尾：请求中断并「有界」等待线程结束

        功能:
            关窗前先请求中断，再以 timeout_ms 为上限等待线程退出；
            线程结束后清空 host 上的线程/Worker 引用。

        参数:
            timeout_ms (int): 最长等待毫秒数，默认 8000ms（覆盖首轮 DuckDB 同步约 4s）。
                              必须是有限值，禁止无限 wait，否则关窗会永久卡死。

        返回:
            None。

        副作用:
            - requestInterruption + quit；
            - thread.wait(timeout_ms) 期间 GUI 线程阻塞（发生在关闭流程，可接受）；
            - 线程已结束时清空 host._bd_thread / _bd_worker 引用。

        异常:
            RuntimeError（对象已销毁）时忽略。
        """
        thread = getattr(self._host, '_bd_thread', None)
        if thread is None:
            return
        try:
            if thread.isRunning():
                thread.requestInterruption()
                thread.quit()
                if not thread.wait(timeout_ms):
                    # 超时不再无限等待：打印现场后退出，交由进程退出回收
                    print("[大数据分析] 后台线程未在 %d ms 内结束，已放弃等待" % timeout_ms)
            if not thread.isRunning():
                self._host._bd_thread = None
                self._host._bd_worker = None
        except RuntimeError:
            self._host._bd_thread = None
            self._host._bd_worker = None

    def eventFilter(self, obj, event):
        """窗口 Close 事件过滤器：在 closeEvent 之前完成线程收尾

        功能:
            拦截 host 自身的 Close 事件，在 closeEvent 之前调用 shutdown()，
            保证后台线程结束时窗口与控件仍然有效。

        参数:
            obj (QObject): 被过滤对象（只关心 host 自己）。
            event (QEvent): 事件对象；只处理 Close。

        返回:
            bool: 恒为 False —— 不吞掉关闭事件，照常交给主窗口 closeEvent。

        说明:
            为什么用事件过滤器而不是改 closeEvent：本任务只允许修改本文件，
            主窗口的 closeEvent 在 plugins/彩票预测.py 中；过滤器能在它之前执行，
            从而保证线程结束时窗口/控件仍然有效。

        注意:
            过滤器只处理 host 自身的 Close，且恒返回 False；不得吞掉关闭事件，
            否则主窗口无法正常关闭。
        """
        if obj is self._host and event.type() == QEvent.Type.Close:
            self.shutdown()
        return False

    # Worker 信号槽（全部在 GUI 线程执行）
    @pyqtSlot(str)
    def on_worker_progress(self, text):
        """显示后台进度（横幅副标题 + 状态栏）

        功能:
            把 Worker 发来的进度文案同时写到横幅副标题与状态栏，让用户知道
            后台仍在运行；控件已销毁时静默跳过。

        参数:
            text (str): Worker 发来的进度文案（如「正在读取历史数据…」）。

        返回: None。

        副作用: 更新两个标签/状态栏；控件已销毁时静默跳过。
        """
        self._safe_set_subtitle("正在分析 · %s（后台计算中，界面可继续操作）" % text)
        try:
            self._host.statusBar().showMessage("大数据分析：%s" % text, 3000)
        except RuntimeError:
            pass

    @pyqtSlot(dict)
    def on_worker_finished(self, result):
        """后台计算成功：把结果回填到 host 缓存并刷新整页

        功能:
            把结果写入 host._bigdata_result 缓存，并调用 render_result 刷新
            KPI、卡片、号码球与评分明细；渲染异常单独弹窗，不抛回事件循环。

        参数:
            result (dict): BigDataAnalyzer.analyze() 的返回值（纯数据，不含控件）。

        返回: None。

        副作用:
            覆盖 host._bigdata_result（复制/导出复用）；调用 render_result 重建
            生肖卡片、号码球、波色卡片、明细表、KPI 与统计文本。

        异常:
            渲染异常单独捕获并弹 critical，避免把异常抛回 Qt 事件循环；
            按钮恢复留给 on_thread_finished，保证线程完全退出前仍处于置忙状态。
        """
        host = self._host
        try:
            host._bigdata_result = result
            render_result(host, result)
            host.statusBar().showMessage(
                "大数据分析完成：推荐 %d 个生肖 / %d 个数字" % (
                    len(result.get('zodiacs', [])), len(result.get('numbers', [])),), 5000)
        except Exception as exc:
            QMessageBox.critical(host, "分析失败", "分析结果渲染出错：%s" % exc)

    @pyqtSlot(str, str, str)
    def on_worker_failed(self, level, title, message):
        """后台失败：在 GUI 线程弹窗（不静默吞掉异常）

        功能:
            按 level 选择 warning/critical 弹窗提示失败原因，并把横幅副标题
            回退到上一次结果摘要或默认说明。

        参数:
            level (str): 'warning' 或 'critical'，分别对应改造前的数据不足/执行出错。
            title (str): 弹窗标题。
            message (str): 弹窗正文（异常文本）。

        返回: None。

        副作用:
            弹出模态提示框；横幅副标题回退到上一次结果摘要或默认说明。
        """
        host = self._host
        try:
            if level == 'warning':
                QMessageBox.warning(host, title, message)
            else:
                QMessageBox.critical(host, title, message)
            self._safe_set_subtitle(_summary_text(getattr(host, '_bigdata_result', None)))
        except RuntimeError:
            # 关窗过程中控件已销毁：不再弹窗，错误信息已由信号送达
            pass

    @pyqtSlot()
    def on_worker_cancelled(self):
        """后台任务被取消（页面切走或关窗）：恢复提示，不覆盖旧结果

        功能:
            在状态栏提示「已取消」，并把横幅副标题回退到旧结果摘要；
            取消不覆盖 host._bigdata_result 中的旧结果。

        参数: 无。
        返回: None。
        副作用: 状态栏提示 3 秒；横幅副标题回退到旧结果摘要/默认说明。
        """
        host = self._host
        try:
            host.statusBar().showMessage("大数据分析已取消", 3000)
            self._safe_set_subtitle(_summary_text(getattr(host, '_bigdata_result', None)))
        except RuntimeError:
            pass

    @pyqtSlot()
    def on_thread_finished(self):
        """线程完全结束：清空引用并恢复「开始分析」按钮

        功能:
            线程完全结束后清空 host._bd_thread/_bd_worker 引用、复位 _bd_busy，
            并恢复「开始分析」按钮的可用态与文案。

        参数: 无。
        返回: None。
        副作用:
            host._bd_thread / _bd_worker 置 None（此时 C++ 对象已由 deleteLater 安排销毁）；
            host._bd_busy 置 False；按钮重新可用、文案复原。

        说明:
            为什么把「恢复按钮」放在这里而不是 on_worker_finished：
            Worker 发完结果后线程还要执行 quit/cleanup，若此时就允许再次点击，
            新线程会覆盖 host._bd_thread，旧线程的 finished 回调可能误清新线程引用。
        """
        host = self._host
        host._bd_thread = None
        host._bd_worker = None
        host._bd_busy = False
        self._set_start_button_busy(False)

    @pyqtSlot(int)
    def on_tab_changed(self, index):
        """页面切换：离开本页时请求中断（满足“页面切换可请求中断”要求）

        功能:
            当本页不再是当前页且分析仍在运行时调用 request_interrupt，
            避免用户切走后后台继续占用资源。

        参数:
            index (int): 切换后的选项卡索引（未使用，靠 currentWidget 判断）。

        返回: None。
        副作用: 请求中断运行中的线程。切走期间计算会在下一个检查点取消。
        """
        host = self._host
        page = getattr(host, '_bd_page', None)
        if not getattr(host, '_bd_busy', False) or page is None:
            return
        if hasattr(host, 'tabs') and host.tabs.currentWidget() is not page:
            self.request_interrupt()

    # 界面小工具
    def _set_start_button_busy(self, busy):
        """切换「开始分析」按钮的禁用态与文案

        功能:
            根据 busy 切换 bd_start_btn 的 enabled 与文案（分析中…/开始分析）；
            控件不存在或已销毁时直接返回。

        参数:
            busy (bool): True=分析中（禁用并显示“分析中…”）；False=恢复可用。

        返回: None。
        副作用: 修改按钮 enabled/text；控件已销毁时忽略。
        """
        btn = getattr(self._host, 'bd_start_btn', None)
        if btn is None:
            return
        try:
            btn.setEnabled(not busy)
            btn.setText("分析中…" if busy else "开始分析")
        except RuntimeError:
            pass

    def _safe_set_subtitle(self, text):
        """安全设置横幅副标题（关窗后控件可能已销毁）

        功能:
            通过 getattr 取 bd_banner_subtitle 并 setText，控件已销毁时静默忽略；
            供进度、失败、取消等路径安全更新横幅副标题。

        参数:
            text (str): 要显示的文本。

        返回: None。
        副作用: 修改 QLabel 文本；RuntimeError 时静默。
        """
        label = getattr(self._host, 'bd_banner_subtitle', None)
        if label is None:
            return
        try:
            label.setText(text)
        except RuntimeError:
            pass


# ╔══════════════════════════════════════════════════════════════════╗
# ║  [大数据分析：执行分析、复制结果、导出TXT]
# ╚══════════════════════════════════════════════════════════════════╝

def on_bigdata_analyze_clicked(host):
    """「开始分析」按钮入口：把分析交给后台线程，立即返回

    功能:
        校验数据 → 由 _BigDataPageController 启动 QThread + Worker，
        取数与三维评分全部在后台完成，GUI 线程只负责渲染结果。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。读取 historical_data /
            bd_window_spin / bd_w_freq_spin / bd_w_gap_spin / bd_w_trans_spin，
            并通过 host._bd_controller 启动线程。

    返回:
        None。函数毫秒级返回；结果异步写入 host._bigdata_result 并刷新界面。

    副作用:
        - 运行期间禁用「开始分析」按钮，重复点击被 host._bd_busy 拦截；
        - 进度显示在横幅副标题与状态栏；
        - 完成后覆盖 host._bigdata_result（复制 / 导出读取该缓存）。

    异常:
        数据为空时弹 warning 后返回；后台异常由 Worker 回传并弹 critical，
        不会向 Qt 事件循环抛出。

    线程约束:
        本函数只能在 GUI 线程调用（会读写控件状态并启动 QThread）；
        Qt 控件只在控制器槽（GUI 线程）里更新，Worker 线程只做纯计算。
    """
    controller = getattr(host, '_bd_controller', None)
    if controller is None:
        # 兜底：install(host) 未执行时也能工作（正常流程不会走到这里）
        controller = _BigDataPageController(host)
        host._bd_controller = controller
    controller.start()


def on_bigdata_copy_clicked(host):
    """把最近一次大数据分析结果以纯文本复制到系统剪贴板

    功能:
        读取 host._bigdata_result 缓存，调用 format_result_text 生成纯文本
        并写入系统剪贴板；无缓存时提示先分析。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读取 _bigdata_result 缓存。

    返回:
        None。

    副作用:
        写入系统剪贴板；状态栏提示 3 秒。无缓存时弹 information 提示先分析。

    异常:
        读取缓存用 getattr 兜底（属性可能尚未创建），不抛异常。
    """
    result = getattr(host, '_bigdata_result', None)
    if not result:
        QMessageBox.information(host, "暂无结果", "请先点击「开始分析」生成推荐结果")
        return
    QApplication.clipboard().setText(BigDataAnalyzer.format_result_text(result))
    host.statusBar().showMessage("大数据分析结果已复制到剪贴板", 3000)


def on_bigdata_export_clicked(host):
    """把最近一次大数据分析结果导出为 TXT 文本文件

    功能:
        读取缓存并经 format_result_text 转文本，弹出保存对话框后用
        host._safe_write_file 写盘；用户取消对话框则不写文件。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读取 _bigdata_result，
            并调用 host._safe_write_file(filepath, text) 写盘。

    返回:
        None。

    副作用:
        弹出保存对话框（默认文件名带秒级时间戳）；写盘成功后弹 information 提示；
        用户取消时直接返回，不写文件。

    异常:
        写盘异常被捕获并弹 critical（不向外抛出）。
    """
    result = getattr(host, '_bigdata_result', None)
    if not result:
        QMessageBox.information(host, "暂无结果", "请先点击「开始分析」生成推荐结果")
        return
    default_name = "大数据分析结果_%s.txt" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath, _ = QFileDialog.getSaveFileName(
        host, "导出大数据分析结果", default_name, "文本文件 (*.txt)")
    if not filepath:
        return
    try:
        host._safe_write_file(filepath, BigDataAnalyzer.format_result_text(result))
    except Exception as e:
        QMessageBox.critical(host, "导出失败", "写入文件出错：%s" % e)
        return
    QMessageBox.information(host, "导出成功", "结果已保存至：\n%s" % filepath)


def install(host):
    """安装「大数据分析」选项卡：绑定事件入口、初始化线程状态并构建界面

    功能:
        1) 创建页面控制器（常驻 GUI 线程，负责 QThread 生命周期与结果回填）；
        2) 把三个按钮回调包装成已绑定 host 的零参 lambda，挂到主窗口属性上；
        3) 调用 build(host) 构建页面，并把页面控件引用交给控制器
           （用于判断「页面切走 → 请求中断」）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。要求已提供 _apply_splitter_sizes、
            _analysis_records、_safe_write_file、tabs、statusBar 等基础设施。

    返回:
        QWidget: build(host) 构建完成的选项卡页面控件。

    副作用:
        向 host 挂载 _bd_controller / _bd_thread / _bd_worker / _bd_busy / _bd_page，
        以及 _on_bigdata_* 回调与 bd_* 控件引用；
        控制器会向 host 安装 Close 事件过滤器（用于关窗时有界等待后台线程）。

    异常:
        无（构建异常由 Qt/调用方处理，本函数不额外捕获）。
    """
    # 线程状态必须在 build 之前初始化：按钮点击可能在页面显示后立刻发生
    host._bd_controller = _BigDataPageController(host)
    host._bd_thread = None
    host._bd_worker = None
    host._bd_busy = False

    host._on_bigdata_analyze_clicked = lambda: on_bigdata_analyze_clicked(host)
    host._on_bigdata_copy_clicked = lambda: on_bigdata_copy_clicked(host)
    host._on_bigdata_export_clicked = lambda: on_bigdata_export_clicked(host)

    page = build(host)
    host._bd_page = page
    if hasattr(host, 'tabs'):
        # 页面切走时请求中断（currentChanged 在切换完成后发出，用 currentWidget 判断）
        host.tabs.currentChanged.connect(host._bd_controller.on_tab_changed)
    return page


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "大数据分析",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 16,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}

# 页面配色（仪表盘风格：白卡片 + 浅灰底 + 蓝色主操作）
COLOR_TEXT = "#1F2D3D"     # 正文深蓝灰：比纯黑柔和，长时间阅读不刺眼
COLOR_MUTED = "#7A8798"    # 次要文字灰：用于 KPI 标题、数量、提示语等弱信息
COLOR_BORDER = "#E5EAF2"   # 卡片描边浅灰蓝：保证白底卡片在浅灰背景上仍有轮廓
COLOR_PRIMARY = "#2563EB"  # 主操作蓝：开始分析按钮、选中态、进度条强调色
COLOR_BG = "#F5F7FB"       # 页面底色：比纯白略灰，让白卡片层次可辨

# 卡片统一样式（objectName=BdCard 时才命中，避免影响卡片内子控件）
#   background-color: #FFFFFF  白色卡片底
#   border: 1px solid #E5EAF2  1px 浅灰蓝描边（COLOR_BORDER）
#   border-radius: 10px        10px 圆角
CARD_STYLE = "QFrame#BdCard { background-color: #FFFFFF; border: 1px solid %s; border-radius: 10px; }" % COLOR_BORDER

# 分隔条把手样式：加宽并着色，避免在浅色卡片背景上看不见、拖不动
#   QSplitter::handle background-color: #9FB4D2        常态浅蓝灰，保证可见
#   QSplitter::handle:hover background-color: #2563EB  悬停主操作蓝，提示可拖动
SPLITTER_STYLE = (
    "QSplitter::handle { background-color: #9FB4D2; }"
    "QSplitter::handle:hover { background-color: %s; }" % COLOR_PRIMARY)


def _card():
    """创建一个统一样式的白色圆角卡片

    功能:
        创建 objectName=BdCard 的空 QFrame，并套用 CARD_STYLE，供各区块
        作为统一的白色圆角卡片容器使用。

    参数: 无。

    返回:
        QFrame: objectName 设为 BdCard 的空卡片，样式由 CARD_STYLE 统一提供；
        调用方自行设置布局与内容。

    说明:
        objectName 必须与 CARD_STYLE 中的 #BdCard 选择器一致，
        否则样式不会命中（Qt 按 objectName 匹配 QSS 选择器）。

    注意:
        只创建控件，不加入任何布局；objectName 必须保持 BdCard，
        改名时需同步修改 CARD_STYLE 的 #BdCard 选择器。
    """
    frame = QFrame()
    frame.setObjectName("BdCard")
    frame.setStyleSheet(CARD_STYLE)
    return frame


def _section_title(text, color=COLOR_TEXT):
    """创建卡片内的小节标题

    功能:
        创建 15px 加粗、透明背景的 QLabel 作为卡片小节标题；
        颜色由入参决定，便于统计区用绿色标题与普通区块区分。

    参数:
        text (str): 标题文字。
        color (str): 文字颜色，默认 COLOR_TEXT；统计检验区传 "#0F766E" 作区分。

    返回:
        QLabel: 15px、加粗的小节标题，背景透明以透出卡片底色。

    副作用/异常:
        纯控件创建，无副作用、不抛异常。
    """
    label = QLabel(text)
    # 样式说明：font-size 15px（字号下限，保证可读）；font-weight bold（标题层级）；
    # color 由入参决定（默认 #1F2D3D）；background transparent（不遮挡卡片圆角底色）
    label.setStyleSheet(
        "QLabel { font-size: 15px; font-weight: bold; color: %s; background: transparent; }" % color)
    return label


def _kpi_card(caption):
    """创建紧凑 KPI 指标块（标签与数值同一行，与右侧参数框同高对齐）

    功能:
        创建固定 30px 高、最小宽 96px 的「标题 + 数值」水平 KPI 块，
        数值标签默认显示「—」，由 render_result 更新。

    参数:
        caption (str): KPI 名称（参与期数 / 总记录数 / 最新期号 / 波色倾向）。

    返回:
        tuple[QWidget, QLabel]: (整块容器, 数值标签)；数值标签由调用方 setText 更新。

    副作用/异常:
        只创建控件并挂到返回值上（未加入布局），无副作用、不抛异常。

    说明:
        宽度使用最小宽度而非固定宽度：数值（如最新期号）变长时允许自动加宽，
        避免固定 96px 装不下内容导致文字被裁切（AI_RULES 第 9 条）。
    """
    frame = QWidget()
    frame.setMinimumWidth(96)  # 统一 96px 视觉基线，内容更长时可按 sizeHint 增长
    frame.setFixedHeight(30)  # 与右侧参数框同高；30px 高于 10/16px 文字所需高度
    frame.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
    # 整块透明：KPI 块嵌在白卡片里，不能再画一层背景，否则圆角处会出现色块
    frame.setStyleSheet("QWidget { background: transparent; }")
    row = QHBoxLayout(frame)
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(4)  # 标题与数值间距 4px：视觉上仍属同一组，又不至于粘连
    cap = QLabel(caption)
    # 标题样式：font-size 15px（下限字号）；color #7A8798（COLOR_MUTED 次要信息灰）；
    # background transparent（透出卡片白底）
    cap.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % COLOR_MUTED)
    value = QLabel("—")
    # 数值样式：font-size 16px（比标题大 1px 形成层级）；font-weight bold（强调数值）；
    # color #1F2D3D（COLOR_TEXT 正文色）；background transparent（透出卡片白底）
    value.setStyleSheet(
        "QLabel { font-size: 16px; font-weight: bold; color: %s; background: transparent; }" % COLOR_TEXT)
    row.addWidget(cap, 0, Qt.AlignmentFlag.AlignVCenter)
    row.addWidget(value, 0, Qt.AlignmentFlag.AlignVCenter)
    return frame, value


def _action_button(text, primary=False):
    """创建统一风格的操作按钮

    功能:
        创建 34px 高、手型光标的主/次操作按钮；primary=True 时为蓝底白字，
        否则为白底描边，clicked 信号由调用方连接。

    参数:
        text (str): 按钮文字（开始分析 / 复制结果 / 导出结果）。
        primary (bool): True=蓝色实心主操作；False=白底描边次操作。

    返回:
        QPushButton: 最小高度 34px、手型光标的按钮（未连接信号）。

    副作用/异常:
        只创建控件，无副作用、不抛异常。
    """
    btn = QPushButton(text)
    btn.setMinimumHeight(34)  # 34px：15px 字号 + 上下内边距 6px + 边框，点击区域舒适
    btn.setCursor(Qt.CursorShape.PointingHandCursor)  # 手型光标提示可点击
    if primary:
        # 主按钮（蓝色实心）
        #   background-color: #2563EB  主操作蓝（COLOR_PRIMARY）
        #   color: #FFFFFF             白字，与蓝底对比度足够
        #   border: none               无边框，与次按钮形成实心/描边区分
        #   border-radius: 8px         8px 圆角
        #   font-size: 15px            字号下限
        #   font-weight: bold          主操作用加粗强调
        #   padding: 6px 22px          上下 6px / 左右 22px，主按钮更宽
        #   hover:   background #1D4ED8 悬停加深
        #   pressed: background #1E40AF 按下再加深，提供点击反馈
        btn.setStyleSheet(
            "QPushButton { background-color: %s; color: #FFFFFF; border: none; border-radius: 8px; "
            "font-size: 15px; font-weight: bold; padding: 6px 22px; }"
            "QPushButton:hover { background-color: #1D4ED8; }"
            "QPushButton:pressed { background-color: #1E40AF; }" % COLOR_PRIMARY)
    else:
        # 次按钮（白底描边）
        #   background-color: #FFFFFF     白底
        #   color: #374151                深灰字，比正文略浅
        #   border: 1px solid #CBD5E1     1px 灰蓝描边
        #   border-radius: 8px            8px 圆角（与主按钮一致）
        #   font-size: 15px               字号下限
        #   padding: 6px 16px             左右 16px，比主按钮窄
        #   hover: background #F1F5F9 / border-color #94A3B8 悬停时浅灰底 + 加深描边
        btn.setStyleSheet(
            "QPushButton { background-color: #FFFFFF; color: #374151; border: 1px solid #CBD5E1; "
            "border-radius: 8px; font-size: 15px; padding: 6px 16px; }"
            "QPushButton:hover { background-color: #F1F5F9; border-color: #94A3B8; }")
    return btn


def _build_banner(host):
    """构建顶部横幅：标题、副标题、数据源徽标与操作按钮

    功能:
        创建顶部横幅（标题、可折行副标题、数据源胶囊徽标与三个按钮），
        并把副标题、徽标与按钮引用挂到 host 供后续更新。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；本函数向其挂载
            bd_banner_subtitle / bd_source_label / bd_start_btn /
            bd_copy_btn / bd_export_btn。

    返回:
        QFrame: 横幅控件（已连接三个按钮的 clicked 信号）。

    副作用:
        读取 host._on_bigdata_analyze_clicked 等回调并 connect；
        subtitle 会被 render_result 复用为结果摘要，因此必须保留引用。

    异常:
        无（host 未安装回调时会在 connect 处抛 AttributeError，属调用顺序错误）。
    """
    banner = QFrame()
    banner.setObjectName("BdBanner")
    # 横幅样式（#BdBanner）
    #   background-color: #EEF4FF  极浅蓝底，与页面灰底区分并暗示“信息区”
    #   border: 1px solid #D7E4FF  1px 浅蓝描边
    #   border-radius: 12px        12px 圆角（比普通卡片 10px 略大）
    banner.setStyleSheet(
        "QFrame#BdBanner { background-color: #EEF4FF; border: 1px solid #D7E4FF; border-radius: 12px; }")
    box = QHBoxLayout(banner)
    box.setContentsMargins(16, 10, 16, 10)  # 左右 16px / 上下 10px：横幅内留白
    box.setSpacing(12)                      # 文字区、徽标、按钮之间 12px

    text_box = QVBoxLayout()
    text_box.setSpacing(1)  # 标题与副标题仅 1px，二者视觉上属于同一文字块
    title = QLabel("大数据分析")
    # 标题样式：font-size 18px（页面主标题，比小节 15px 大）；font-weight bold；
    # color #16324F（深蓝，与浅蓝横幅底协调）；background transparent（透出横幅底色）
    title.setStyleSheet(
        "QLabel { font-size: 18px; font-weight: bold; color: #16324F; background: transparent; }")
    subtitle = QLabel(BANNER_SUBTITLE_DEFAULT)
    subtitle.setWordWrap(True)  # 窗口变窄时副标题折行，避免撑宽横幅
    # 副标题样式：font-size 15px（下限字号）；color #5B6B7F（中灰蓝，弱于标题）；
    # background transparent（透出横幅底色）
    subtitle.setStyleSheet(
        "QLabel { font-size: 15px; color: #5B6B7F; background: transparent; }")
    host.bd_banner_subtitle = subtitle  # 分析完成后复用此行显示结果摘要，避免额外状态条占高度
    text_box.addWidget(title)
    text_box.addWidget(subtitle)
    box.addLayout(text_box, 1)

    host.bd_source_label = QLabel("数据源 · 待分析")
    # 数据源徽标样式（胶囊形）
    #   background-color: #FFFFFF     白底，在浅蓝横幅上形成反差
    #   color: #2563EB                主操作蓝文字
    #   border: 1px solid #BFD3FF     1px 浅蓝描边
    #   border-radius: 11px           11px 圆角（配合上下 3px 内边距形成胶囊）
    #   padding: 3px 12px             上下 3px / 左右 12px
    #   font-size: 15px               下限字号
    #   font-weight: bold             强调数据来源
    host.bd_source_label.setStyleSheet(
        "QLabel { background-color: #FFFFFF; color: #2563EB; border: 1px solid #BFD3FF; "
        "border-radius: 11px; padding: 3px 12px; font-size: 15px; font-weight: bold; }")
    box.addWidget(host.bd_source_label, 0, Qt.AlignmentFlag.AlignVCenter)

    host.bd_start_btn = _action_button("开始分析", primary=True)
    host.bd_start_btn.clicked.connect(host._on_bigdata_analyze_clicked)
    box.addWidget(host.bd_start_btn)

    host.bd_copy_btn = _action_button("复制结果")
    host.bd_copy_btn.clicked.connect(host._on_bigdata_copy_clicked)
    box.addWidget(host.bd_copy_btn)

    host.bd_export_btn = _action_button("导出结果")
    host.bd_export_btn.clicked.connect(host._on_bigdata_export_clicked)
    box.addWidget(host.bd_export_btn)
    return banner


def _style_spin(spin):
    """统一参数区数字框样式（白底、6px 圆角、32px 固定高度）

    功能:
        复用 TAB.widgets.apply_spin_style：32px 高（32→125% 为 40、150% 为 48，
        不落半像素），左内边距 8px、右侧 24px 给箭头；上下按钮分别定位，
        30px 内容高下箭头各按 14px 收缩，保证不叠置。

    参数:
        spin (QSpinBox): 待美化的数字框（调用方已固定宽 80）。

    返回:
        None。

    副作用:
        修改入参控件的高度与样式表（原地修改，不返回新控件）。

    异常:
        无。

    注意: 主窗口全局样式表给 QSpinBox 设了 min-height:45px，共享样式的
    min/max-height 会显式覆盖它，避免整排被撑高。
    """
    apply_spin_style(spin, border_color='#D1D9E6', bg='#FFFFFF', fg='#333333',
                     height=32, font_px=15, fixed_width=80,
                     focus_border=COLOR_PRIMARY, arrow_w=18, arrow_h=14)


class _ResponsiveStatusRow(QFrame):
    """指标 / 参数行（v0.0.36 响应式）

    职责:
        把 4 个 KPI 与 4 个参数（含 1 条竖分隔线）放进同一个卡片，
        按可用宽度自动决定单行还是两行排布。

    排布规则:
        宽度充足时 8 项单行显示（4 KPI + 分隔线 + 4 参数）；
        宽度不足时自动折成两行（第一行 4 个 KPI、第二行 4 个参数），
        保证字号抬到 15px 后仍不裁字、不重叠、不溢出。
        判定阈值 = 单行所需最小宽度 + 24px 余量，避免「刚好塞下但很挤」。

    关键属性:
        _kpis (list[QWidget])    —— 4 个 KPI 块，按登记顺序摆放。
        _params (list[QWidget])  —— 4 个参数组容器（标签 + 数字框）。
        _divider (QFrame|None)   —— 单行时显示在 KPI 与参数之间的 1px 竖线。
        _wrapped (bool|None)     —— 当前是否折行；None 表示尚未布局，用于避免重复重排。

    生命周期/线程约束:
        由 _build_status_row 一次性创建，随后 set_items 登记控件；
        之后只在 UI 线程的 resizeEvent 中重排，不涉及后台线程。
    """

    EXTRA_SLACK = 24  # 单行额外留白（px）：小于该余量即折行，避免拥挤

    def __init__(self):
        """初始化空的状态排（网格布局 + 8 项占位属性）

        功能:
            初始化响应式指标/参数排：创建 QGridLayout、设置卡片外观与
            14/8/14/8 边距，并清空 KPI/参数/分隔线/折行状态属性。

        参数: 无。
        返回: None。
        副作用: 创建内部 QGridLayout 并把边距设为 14/8/14/8、行列间距均 6px；
                控件本身使用 CARD_STYLE 的卡片外观。
        异常: 无。
        """
        super().__init__()
        self.setObjectName("BdCard")
        self.setStyleSheet(CARD_STYLE)
        self._grid = QGridLayout(self)
        self._grid.setContentsMargins(14, 8, 14, 8)  # 左右 14px、上下 8px：不贴卡片边缘
        self._grid.setHorizontalSpacing(6)            # 列间距 6px：紧凑但不拥挤
        self._grid.setVerticalSpacing(6)              # 行间距 6px：折行后两行不粘连
        self._kpis = []        # 4 个 KPI 块
        self._params = []      # 4 个参数组（标签 + 数字框容器）
        self._divider = None   # 单行时显示的竖分隔线
        self._wrapped = None   # 当前是否已折行（None=尚未布局）
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)

    def set_items(self, kpis, divider, params):
        """登记 8 项控件与分隔线（构建期调用一次）

        功能:
            把 4 个 KPI 块、1 条分隔线与 4 个参数组登记到本排，
            供 resizeEvent 首次布局时使用；登记后不立即重排。

        参数:
            kpis (list[QWidget]): 4 个 KPI 块。
            divider (QFrame): KPI 与参数之间的 1px 竖分隔线。
            params (list[QWidget]): 4 个参数组容器（标签 + 数字框）。

        返回:
            None。

        副作用:
            覆盖 _kpis / _divider / _params；不立即重排（首次排布由 resizeEvent 触发）。

        异常:
            无。
        """
        self._kpis = kpis
        self._divider = divider
        self._params = params

    def _one_row_need(self):
        """计算单行排布所需的最小宽度（含外边距与间距）

        功能:
            按当前控件的最小宽度累加外边距与间距，算出 8 项单行排布所需宽度，
            作为 resizeEvent 判断是否折行的阈值。

        参数: 无。

        返回:
            int: 单行放下全部 8 项 + 分隔线所需的像素宽度；
            未登记分隔线（尚未 set_items）时返回当前宽度，等价于“不折行”。

        算法:
            左右外边距 14+14 + 相邻间距 6*(项数-1) + 每项 max(minimumSizeHint, minimumWidth)。
            取 max 是因为 KPI 块显式 setMinimumWidth(96)，仅看 sizeHint 会低估。

        异常:
            无。
        """
        if self._divider is None:
            return self.width()
        items = list(self._kpis) + [self._divider] + list(self._params)
        need = 14 + 14  # 左右外边距
        need += 6 * (len(items) - 1)  # 相邻控件间距
        for w in items:
            # 同时考虑 minimumSizeHint 与显式最小宽度（KPI 块 setMinimumWidth(96)）
            need += max(w.minimumSizeHint().width(), w.minimumWidth())
        return need

    def _relayout(self, wrapped):
        """按单行 / 两行重新摆放控件（仅在状态变化时执行，避免反复重排）

        功能:
            在折行状态变化时，从网格移除全部已登记控件后按单行/两行重新
            addWidget，并调整列 stretch、分隔线可见性与 updateGeometry。

        参数:
            wrapped (bool): True=两行（KPI 一行、参数一行）；False=8 项单行。

        返回:
            None。

        副作用:
            - 从网格中移除全部已登记控件后重新 addWidget；
            - 清零 9 列的 stretch，再把行末列设为 1 吸收多余宽度；
            - 折行时隐藏分隔线，单行时显示；
            - updateGeometry() 通知父布局尺寸已变。

        异常:
            无（未登记控件时直接返回）。
        """
        if wrapped == self._wrapped or self._divider is None:
            return
        self._wrapped = wrapped
        for w in list(self._kpis) + [self._divider] + list(self._params):
            self._grid.removeWidget(w)
        for col in range(9):
            self._grid.setColumnStretch(col, 0)
        if wrapped:
            # 第一行：4 个 KPI；第二行：4 个参数；分隔线折行后隐藏
            for col, w in enumerate(self._kpis):
                self._grid.addWidget(w, 0, col)
            for col, w in enumerate(self._params):
                self._grid.addWidget(w, 1, col)
            self._divider.setVisible(False)
            self._grid.setColumnStretch(4, 1)  # 行末吸收多余宽度
        else:
            col = 0
            for w in self._kpis:
                self._grid.addWidget(w, 0, col)
                col += 1
            self._grid.addWidget(self._divider, 0, col)
            col += 1
            self._divider.setVisible(True)
            for w in self._params:
                self._grid.addWidget(w, 0, col)
                col += 1
            self._grid.setColumnStretch(col, 1)  # 行末吸收多余宽度
        self.updateGeometry()

    def resizeEvent(self, event):
        """窗口宽度变化时决定单行还是两行

        功能:
            比较当前宽度与 _one_row_need()+EXTRA_SLACK，决定单行或两行，
            仅在折行状态变化时触发 _relayout。

        参数:
            event (QResizeEvent): Qt 传入的尺寸变化事件（转交父类处理）。

        返回:
            None。

        副作用:
            可能触发 _relayout 重排（仅当折行状态发生变化时）。

        说明:
            阈值不是写死的常量，而是 _one_row_need() 实时计算值 + EXTRA_SLACK(24px)：
            换字号、换字体或“最新期号”变长时，单行所需宽度会自动变化，避免误判；
            24px 余量用于避免“刚好塞下但很挤”的临界状态。
            15px 字号下单行需求约为一千像素量级（随字体、DPI 与“最新期号”长度浮动），
            因此不使用 1180/1600 之类的固定阈值：换字号或换机器后固定值会误判。
        """
        super().resizeEvent(event)
        self._relayout(self.width() < self._one_row_need() + self.EXTRA_SLACK)


def _build_status_row(host):
    """构建「指标 + 参数」卡片（响应式：宽时单行 8 项，窄时两行 4+4）

    功能:
        创建响应式卡片并登记 4 个 KPI、分隔线与 4 个参数组
        （分析期数/频率/遗漏/转移权重），把数值标签与数字框挂到 host。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；本函数向其挂载
            bd_kpi_used_label / bd_kpi_total_label / bd_kpi_period_label /
            bd_kpi_wave_label 以及 bd_window_spin / bd_w_freq_spin /
            bd_w_gap_spin / bd_w_trans_spin。

    返回:
        _ResponsiveStatusRow: 已登记 4 KPI + 分隔线 + 4 参数组的卡片。

    副作用:
        覆盖 host 上 8 个控件属性；未连接信号（数值由分析回调读取）。

    异常:
        无。

    排布:
        参与期数 / 总记录数 / 最新期号 / 波色倾向 / 分析期数 / 频率权重 / 遗漏权重 / 转移权重
        KPI 块以 96px 为最小宽度基线，内容变长时自动加宽，不再写死宽度。
    """
    card = _ResponsiveStatusRow()

    kpi_items = [
        ("参与期数", "bd_kpi_used_label"),
        ("总记录数", "bd_kpi_total_label"),
        ("最新期号", "bd_kpi_period_label"),
        ("波色倾向", "bd_kpi_wave_label"),
    ]
    kpis = []
    for caption, attr in kpi_items:
        block, value = _kpi_card(caption)
        setattr(host, attr, value)
        kpis.append(block)

    divider = QFrame()
    divider.setObjectName("BdDivider")
    divider.setFixedWidth(1)
    divider.setFixedHeight(30)
    # 分隔线样式：1px 宽的浅灰蓝竖线，border 置空避免再画一层边框
    divider.setStyleSheet("QFrame#BdDivider { background-color: %s; border: none; }" % COLOR_BORDER)

    def _group(caption, spin):
        """标签与输入框紧密排列，不随窗口拉宽产生空隙

        功能:
            创建「参数标签 + 数字框」的紧凑水平容器，标签采用 Fixed 水平策略
            随当前字体取宽，避免 15px 字号下文字被裁或产生空隙。

        参数:
            caption (str): 参数名称（分析期数 / 频率权重 / 遗漏权重 / 转移权重）。
            spin (QSpinBox): 已设好范围与样式的数字框。

        返回:
            QWidget: 水平排列「标签 + 数字框」的容器，水平策略 Fixed。

        副作用/异常:
            只创建控件，无副作用、不抛异常。

        说明:
            标签不写死宽度：固定宽度是在构建期按默认字体算出的，随后全局样式表
            把字号提升到 15px 以上，导致「分析期数 / 频率权重 / 遗漏权重 / 转移权重」
            实际文字被裁。改用水平 Fixed 策略，让标签始终按当前字体的 sizeHint 取宽，
            文字既不会截断，也不会被拉伸产生空隙。
        """
        container = QWidget()
        container.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        group = QHBoxLayout(container)
        group.setContentsMargins(0, 0, 0, 0)  # 无内边距：宽度完全由标签与数字框决定
        group.setSpacing(6)                   # 标签与数字框间距 6px，不拥挤
        label = QLabel(caption)
        # Fixed 水平策略：宽度跟随文字 sizeHint 自动变化（字体/字号改变后一起更新）
        label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        label.setMinimumHeight(30)  # 与参数框同高；字号变大时允许纵向增长，不裁切文字
        label.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        group.addWidget(label, 0, Qt.AlignmentFlag.AlignVCenter)
        group.addWidget(spin, 0, Qt.AlignmentFlag.AlignVCenter)
        return container

    host.bd_window_spin = QSpinBox()
    host.bd_window_spin.setRange(10, 2000)
    host.bd_window_spin.setValue(100)
    host.bd_window_spin.setToolTip("从最新一期往前取多少期历史记录参与分析")
    # 参数框统一 80px：显示 3~4 位期数或 0~100% 权重（实测“100 / 55%”文本约 24~36px，
    # 加箭头 16px 与内边距 12px 后约 64~76px），80px 不会小于内容所需；同宽保证整排对齐。
    host.bd_window_spin.setFixedWidth(80)
    _style_spin(host.bd_window_spin)

    params = [_group("分析期数", host.bd_window_spin)]
    weight_items = [
        ("频率权重", "bd_w_freq_spin", 55, "出现频率特征的权重，近期出现越多得分越高（三项权重自动归一化）"),
        ("遗漏权重", "bd_w_gap_spin", 25, "遗漏特征的权重，越久未出得分越高（三项权重自动归一化）"),
        ("转移权重", "bd_w_trans_spin", 20, "转移特征的权重，与最近一期号码关联越强得分越高（三项权重自动归一化）"),
    ]
    for caption, attr, value, tip in weight_items:
        spin = QSpinBox()
        spin.setRange(0, 100)
        spin.setValue(value)
        spin.setSuffix("%")
        spin.setToolTip(tip)
        spin.setFixedWidth(80)  # 与「分析期数」同宽，80px 足以显示 0~100% 与上下箭头
        _style_spin(spin)
        params.append(_group(caption, spin))
        setattr(host, attr, spin)

    card.set_items(kpis, divider, params)
    return card


def _empty_hint(text):
    """创建结果区空状态提示

    功能:
        创建居中、可换行、上下留白的浅灰提示标签，用于结果区空状态；
        文字可含 \n 手动断行。

    参数:
        text (str): 提示文字，可含 \n 换行（QLabel 需开启 wordWrap 才能正常断行）。

    返回:
        QLabel: 居中、可换行、上下留 24px 的浅灰提示标签。

    副作用/异常:
        只创建控件，无副作用、不抛异常。
    """
    label = QLabel(text)
    label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    label.setWordWrap(True)
    # 空状态样式：font-size 15px（下限字号）；color #7A8798（次要灰）；
    # background transparent（透出卡片底）；padding 24px 8px（上下留白让提示不贴边）
    label.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; padding: 24px 8px; }" % COLOR_MUTED)
    return label


def _build_result_area(host):
    """构建结果区分栏：左推荐生肖、右推荐数字

    功能:
        构建左右两栏可拖动分栏：左侧推荐生肖卡片列表、右侧推荐数字
        号码球矩阵，两栏均带标题、计数与滚动区空状态。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；本函数挂载
            bd_mid_splitter / bd_zodiac_count_label / bd_zodiac_layout /
            bd_number_count_label / bd_number_layout。

    返回:
        QSplitter: 左右两栏的分隔条（栏数=2），尺寸由 _apply_splitter_sizes 恢复。

    副作用:
        读取 host._apply_splitter_sizes 恢复 'bd_mid_splitter' 的 INI 记忆；
        构建布局时向两个网格加入空状态提示控件。

    异常:
        无。
    """
    splitter = QSplitter(Qt.Orientation.Horizontal)
    splitter.setHandleWidth(6)  # 把手 6px：比 3px 更容易用鼠标抓住
    splitter.setStyleSheet(SPLITTER_STYLE)
    splitter.setMinimumHeight(160)  # 结果区最低 160px，保证生肖/号码球至少可见一行
    host.bd_mid_splitter = splitter  # 挂到主窗口，分隔条位置可记忆

    # 左：推荐生肖（卡片列表，可滚动）
    left_card = _card()
    left_box = QVBoxLayout(left_card)
    left_box.setContentsMargins(14, 12, 14, 12)
    left_box.setSpacing(8)
    left_header = QHBoxLayout()
    left_header.addWidget(_section_title("推荐生肖"))
    left_header.addStretch(1)
    host.bd_zodiac_count_label = QLabel("0 / 7")
    # 计数标签样式：font-size 15px（下限字号）；color #7A8798（次要灰，弱于标题）；
    # background transparent（透出卡片白底）
    host.bd_zodiac_count_label.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % COLOR_MUTED)
    left_header.addWidget(host.bd_zodiac_count_label)
    left_box.addLayout(left_header)

    zodiac_scroll = QScrollArea()
    zodiac_scroll.setWidgetResizable(True)
    zodiac_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
    zodiac_content = QWidget()
    # 内容容器透明：滚动区内的承载控件不画底色，避免在卡片白底上叠一层灰
    zodiac_content.setStyleSheet("QWidget { background: transparent; }")
    host.bd_zodiac_layout = QGridLayout(zodiac_content)
    host.bd_zodiac_layout.setSpacing(8)
    host.bd_zodiac_layout.setContentsMargins(0, 0, 0, 0)
    host.bd_zodiac_layout.setColumnStretch(0, 1)
    host.bd_zodiac_layout.setColumnStretch(1, 1)
    host.bd_zodiac_layout.addWidget(
        _empty_hint("尚未分析\n点击右上角「开始分析」查看推荐生肖"), 0, 0, 1, 2)
    zodiac_scroll.setWidget(zodiac_content)
    left_box.addWidget(zodiac_scroll, 1)
    splitter.addWidget(left_card)

    # 右：推荐数字（号码球矩阵，可滚动）
    right_card = _card()
    right_box = QVBoxLayout(right_card)
    right_box.setContentsMargins(14, 12, 14, 12)
    right_box.setSpacing(8)
    right_header = QHBoxLayout()
    right_header.addWidget(_section_title("推荐数字"))
    right_header.addStretch(1)
    host.bd_number_count_label = QLabel("0 / 7")
    # 计数标签样式：font-size 15px（下限字号）；color #7A8798（次要灰，弱于标题）；
    # background transparent（透出卡片白底）
    host.bd_number_count_label.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % COLOR_MUTED)
    right_header.addWidget(host.bd_number_count_label)
    right_box.addLayout(right_header)

    number_scroll = QScrollArea()
    number_scroll.setWidgetResizable(True)
    number_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
    number_content = QWidget()
    # 内容容器透明：滚动区内的承载控件不画底色，避免在卡片白底上叠一层灰
    number_content.setStyleSheet("QWidget { background: transparent; }")
    host.bd_number_layout = QGridLayout(number_content)
    host.bd_number_layout.setSpacing(12)
    host.bd_number_layout.setContentsMargins(4, 4, 4, 4)
    host.bd_number_layout.addWidget(
        _empty_hint("尚未分析\n点击「开始分析」生成推荐号码"), 0, 0, 1, 4)
    number_scroll.setWidget(number_content)
    right_box.addWidget(number_scroll, 1)
    splitter.addWidget(right_card)

    # 左右按 2:3 分配多余宽度：右侧号码球矩阵 4 列，天然比左侧生肖双列更宽
    splitter.setStretchFactor(0, 2)
    splitter.setStretchFactor(1, 3)
    # 默认 560:840，供无 INI 记忆时使用；校验规则同主窗口 _apply_splitter_sizes
    host._apply_splitter_sizes(splitter, 'bd_mid_splitter', [560, 840])
    return splitter


def _build_wave_area(host):
    """构建波色分析卡片区：标题与红波 / 绿波 / 蓝波单行并排

    功能:
        构建波色分析卡片：左侧标题、右侧红/绿/蓝波色评分卡容器，
        初始放入空状态提示，分析后由 render_result 替换。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；本函数挂载 bd_wave_layout。

    返回:
        QFrame: 波色卡片（内部先放空状态提示，分析后由 render_result 替换）。

    副作用:
        无（只创建控件并挂载到 host）。

    异常:
        无。
    """
    card = _card()
    box = QHBoxLayout(card)
    box.setContentsMargins(16, 8, 16, 8)
    box.setSpacing(10)
    box.addWidget(_section_title("波色分析"))

    host.bd_wave_layout = QHBoxLayout()
    host.bd_wave_layout.setSpacing(10)
    host.bd_wave_layout.addWidget(_empty_hint("尚未分析\n点击「开始分析」查看波色倾向"), 1)
    box.addLayout(host.bd_wave_layout, 1)
    return card


def _build_detail_area(host):
    """构建评分明细控件区（名次徽标 + 等级标签 + 综合分进度条 + 分项进度条）

    功能:
        构建评分明细卡：标题行、图例、可纵向滚动的行容器，并立即渲染
        空状态；分析后按数字/生肖/波色三组重建评分卡。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；本函数挂载
            bd_detail_card / bd_detail_title / bd_detail_legend /
            bd_detail_scroll / bd_detail_content / bd_detail_layout。

    返回:
        QFrame: 明细卡（标题行 + 可纵向滚动的评分行列表）。

    副作用:
        - 创建 QScrollArea 与行容器 QVBoxLayout，并立即渲染空状态；
        - 行控件在 render_result 中按「数字 / 生肖 / 波色」三组重建；
        - 明细卡使用固定的浅色表面（与本页其余白卡一致），所有文字色显式指定，
          不依赖全局 QSS 继承，因此亮/暗主题下都可读（详见 _detail_theme）。

    异常:
        无。

    说明:
        为什么不用 QTableWidget：评分明细的信息密度是「分数高低与差距」，
        表格只能平铺数值，无法表达进度与档位。这里改为一行一张评分卡，
        左侧名次徽标、中部综合分进度条、右侧频率/遗漏/转移三条小进度条；
        数据仍由 _detail_row_models() 从 analyze() 结果原样取值，
        分类顺序与旧表默认展示顺序（数字 → 生肖 → 波色，组内按分降序）一致。
    """
    card = _card()
    card.setMinimumHeight(160)  # 最低 160px：保证标题 + 至少两行评分可见
    host.bd_detail_card = card
    box = QVBoxLayout(card)
    box.setContentsMargins(16, 12, 16, 12)
    box.setSpacing(8)

    header = QHBoxLayout()
    header.setSpacing(10)
    title = QLabel("评分明细")
    host.bd_detail_title = title
    header.addWidget(title)
    header.addStretch(1)
    legend = QLabel("综合分 0–1｜优秀 ≥0.75 · 良好 ≥0.65 · 一般 ≥0.55 · 偏低 <0.55｜三组各自排名")
    legend.setToolTip("综合分是频率 / 遗漏 / 转移三项归一化特征的加权平均；"
                      "三组评分口径不同，因此名次在组内独立计算，不做跨组横比。")
    host.bd_detail_legend = legend
    header.addWidget(legend, 0, Qt.AlignmentFlag.AlignVCenter)
    box.addLayout(header)

    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QScrollArea.Shape.NoFrame)
    # 横向滚动一律关闭：行内用伸缩进度条吸收多余宽度，避免出现横向滚动条
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    host.bd_detail_scroll = scroll

    content = QWidget()
    content.setObjectName("BdDetailContent")
    host.bd_detail_content = content
    layout = QVBoxLayout(content)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(4)
    host.bd_detail_layout = layout
    scroll.setWidget(content)
    box.addWidget(scroll, 1)

    # 构建期就填充空状态，避免出现“只有表头、下面一片空白”的区块
    _render_detail(host, None)
    return card


def _build_stats_area(host):
    """构建统计检验与趋势卡片（紧凑高度，内容超出时内部滚动）

    功能:
        构建固定 78px 高的统计检验卡：绿色小节标题 + 内部可滚动文本区，
        初始显示未分析提示。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；本函数挂载 bd_stats_label。

    返回:
        QFrame: 固定 78px 高的统计卡（标题 + 可滚动文本区）。

    副作用:
        创建 QLabel 并挂到 host；初始显示“尚未分析”提示。

    异常:
        无。

    说明:
        卡片高度写死 78px，是为了让顶部区不随统计文本长度膨胀；文本超长时靠
        内部 QScrollArea 滚动，而不是把整页撑高。
    """
    card = _card()
    card.setFixedHeight(78)
    box = QVBoxLayout(card)
    box.setContentsMargins(14, 6, 14, 6)
    box.setSpacing(2)
    box.addWidget(_section_title("统计检验与趋势", "#0F766E"))

    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QScrollArea.Shape.NoFrame)
    # 滚动区透明、无边框：避免在卡片里再出现一层白底与边框
    scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
    content = QWidget()
    # 内容容器透明：统计卡已经是白底，内层不能再画底色
    content.setStyleSheet("QWidget { background: transparent; }")
    inner = QVBoxLayout(content)
    inner.setContentsMargins(0, 0, 0, 0)
    inner.setSpacing(0)

    host.bd_stats_label = QLabel("尚未分析：点击「开始分析」后展示和值趋势、信息熵、卡方检验、置信区间等")
    host.bd_stats_label.setWordWrap(True)
    # 统计文本样式：font-size 15px（下限字号）；color #34495E（深灰蓝，与绿色标题协调）；
    # background transparent（透出卡片白底）
    host.bd_stats_label.setStyleSheet(
        "QLabel { font-size: 15px; color: #34495E; background: transparent; }")
    inner.addWidget(host.bd_stats_label)
    inner.addStretch(1)
    scroll.setWidget(content)
    box.addWidget(scroll, 1)
    return card


def build(host):
    """构建「大数据分析」选项卡页面

    功能:
        自上而下拼装三个区块（顶部参数 / 中部结果 / 底部明细），
        再套进可拖动的三段式竖向 QSplitter，并恢复分隔条尺寸。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，控件与状态挂载在此对象上；
            读取 margin_left / margin_top / margin_right / margin_bottom、
            _splitter_sizes、_apply_splitter_sizes，并连接 tabs.currentChanged。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        - 向 host 挂载 bd_main_splitter 与各 _build_* 产生的控件引用；
        - 连接 host.tabs.currentChanged → _restore_bd_sizes；
        - 通过 QTimer.singleShot(0, ...) 在事件循环空闲时恢复分隔条尺寸；
        - 向 host._splitter_sizes 读取（不写入）bd_main_splitter 的已存尺寸。

    异常:
        无。
    """
    widget = QWidget()
    # 页面底色 #F5F7FB（COLOR_BG）：铺满整个选项卡，衬托白色卡片
    widget.setStyleSheet("QWidget { background-color: %s; }" % COLOR_BG)
    layout = QVBoxLayout(widget)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)
    layout.setSpacing(10)

    # 顶部区：横幅 + 指标/参数单行 + 统计检验（高度随内容，不参与拉伸）
    top_panel = QWidget()
    # 三个分区容器统一透明：分区只负责排版，底色由页面 widget 提供
    top_panel.setStyleSheet("QWidget { background: transparent; }")
    top_layout = QVBoxLayout(top_panel)
    top_layout.setContentsMargins(0, 0, 0, 0)
    top_layout.setSpacing(10)
    top_layout.addWidget(_build_banner(host))
    # 指标与参数合并为同一排：参与期数/总记录数/最新期号/波色倾向 + 四个分析参数
    top_layout.addWidget(_build_status_row(host))
    top_layout.addWidget(_build_stats_area(host))

    # 中部区：推荐生肖 / 推荐数字 / 波色分析
    mid_panel = QWidget()
    # 分区容器透明（同顶部区说明）
    mid_panel.setStyleSheet("QWidget { background: transparent; }")
    mid_layout = QVBoxLayout(mid_panel)
    mid_layout.setContentsMargins(0, 0, 0, 0)
    mid_layout.setSpacing(10)
    mid_layout.addWidget(_build_result_area(host), 1)
    mid_layout.addWidget(_build_wave_area(host))

    # 底部区：评分明细 + 统计检验 + 状态提示
    bottom_panel = QWidget()
    # 分区容器透明（同顶部区说明）
    bottom_panel.setStyleSheet("QWidget { background: transparent; }")
    bottom_layout = QVBoxLayout(bottom_panel)
    bottom_layout.setContentsMargins(0, 0, 0, 0)
    bottom_layout.setSpacing(10)

    bottom_layout.addWidget(_build_detail_area(host), 1)

    # 三段式上下分栏：顶部参数 / 中部结果 / 底部明细可分别拖动调整占比，位置记忆到 INI
    main_splitter = QSplitter(Qt.Orientation.Vertical)
    main_splitter.setHandleWidth(6)  # 把手 6px：易于抓取拖动
    main_splitter.setStyleSheet(SPLITTER_STYLE)
    main_splitter.setChildrenCollapsible(False)  # 禁止拖到 0 隐藏某一区，保证三段始终可见
    host.bd_main_splitter = main_splitter
    main_splitter.addWidget(top_panel)
    main_splitter.addWidget(mid_panel)
    main_splitter.addWidget(bottom_panel)
    # 注意：不设置 setStretchFactor。QSplitter 在页面首次显示时会按 stretchFactor 重新分配，
    # 会把保存/默认的三段尺寸改写（评分明细会被压到最小高度）；不设 stretch 时
    # setSizes 的结果原样保留，用户拖动后的位置也能准确恢复。
    host._apply_splitter_sizes(main_splitter, 'bd_main_splitter', [230, 320, 267])

    # 构建期 setSizes 会被 QSplitter 首次布局按 sizeHint 重排（实测三段变成 239/416/162），
    # 因此切到本页（已可见）时延迟一帧再恢复一次；同时记录本次会话内用户拖动后的尺寸，
    # 来回切换选项卡仍能保持用户拖动的位置。
    _bd_sizes = [list(host._splitter_sizes.get('bd_main_splitter') or [230, 320, 267])]
    _bd_ready = [False]  # 初始化阶段的布局变化会触发 splitterMoved，不能当成用户拖动

    def _remember_bd_sizes(*_args):
        """记录用户拖动后的三段尺寸（splitterMoved 回调，局部函数）

        功能:
            在 splitterMoved 后把 main_splitter.sizes() 记入 _bd_sizes[0]；
            仅当 _bd_ready 为 True（初始化完成）时记录，避免误存构建期尺寸。

        参数:
            *_args: splitterMoved 附带的 (pos, index)，此处不用。

        返回:
            None。

        副作用:
            初始化完成（_bd_ready=True）后，把 main_splitter.sizes() 写入 _bd_sizes[0]；
            _bd_ready 为 False 时忽略，避免把构建期/首次布局的重排误当用户拖动。

        异常:
            无。
        """
        if _bd_ready[0]:
            _bd_sizes[0] = main_splitter.sizes()

    def _apply_bd_sizes():
        """把记录的三段尺寸真正写入 QSplitter（局部函数）

        功能:
            当 main_splitter 已可见且有实际高度时，把 _bd_sizes[0] 写入
            setSizes 并标记初始化完成；否则等待下一次延迟恢复。

        参数: 无。
        返回: None。
        副作用: 若 splitter 已可见且高度 > 0，则 setSizes(_bd_sizes[0]) 并把
                _bd_ready 置 True；否则不做任何事，等待下一次延迟恢复。
        异常: 无。

        说明: 只有可见且有实际高度时 setSizes 才生效；隐藏（其他选项卡）时写入会被忽略。
        """
        if main_splitter.isVisible() and main_splitter.height() > 0:
            main_splitter.setSizes(_bd_sizes[0])
            _bd_ready[0] = True

    def _restore_bd_sizes(*_args):
        """选项卡切换后恢复三段尺寸（currentChanged 回调，局部函数）

        功能:
            选项卡切换后通过 QTimer.singleShot(0, _apply_bd_sizes) 延迟一帧
            恢复三段尺寸，避免新页面尚未完成布局时写入被覆盖。

        参数:
            *_args: currentChanged 附带的索引，此处不用。

        返回:
            None。

        副作用:
            用 QTimer.singleShot(0, _apply_bd_sizes) 把恢复动作排到事件循环下一轮，
            因为 currentChanged 发出时新页面尚未完成显示与布局，立即 setSizes 会被覆盖。

        异常:
            无。
        """
        # 延迟一帧，等选项卡完成显示和布局后再写入尺寸
        QTimer.singleShot(0, _apply_bd_sizes)

    main_splitter.splitterMoved.connect(_remember_bd_sizes)
    if hasattr(host, 'tabs'):
        host.tabs.currentChanged.connect(_restore_bd_sizes)
    # 启动时若就停在本页（窗口尚未 show 时 currentChanged 不会触发恢复），补一次延迟恢复
    QTimer.singleShot(0, _apply_bd_sizes)
    layout.addWidget(main_splitter, 1)

    return widget


def _clear_layout(layout):
    """清空布局中的全部子控件（用于刷新结果前重置展示区）

    功能:
        循环 takeAt 取出布局项，控件 setParent(None) 后用 deleteLater
        延迟销毁，用于刷新前清空结果布局。

    参数:
        layout (QLayout): 目标布局对象（QVBoxLayout / QGridLayout 等）。

    返回:
        None。

    副作用:
        逐个 takeAt 取出布局项；控件先 setParent(None) 解除父子关系，
        再用 deleteLater() 交给事件循环销毁（立即 delete 可能仍在绘制中）。

    异常:
        无（布局为空时循环不执行）。
    """
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w is not None:
            w.setParent(None)
            w.deleteLater()


# 评分明细：配色、档位与行模型
# 档位阈值：综合分是「频率 / 遗漏 / 转移」三项归一化特征（各自 0~1）的加权平均，
# 因此 0.75 表示多数维度接近组内最高水平。阈值是展示口径，不参与任何评分计算。
_DETAIL_GRADE_STEPS = ((0.75, '优秀'), (0.65, '良好'), (0.55, '一般'))
_DETAIL_GRADE_FALLBACK = '偏低'


def _detail_grade(score):
    """按综合分返回展示档位（优秀 / 良好 / 一般 / 偏低）

    功能:
        把综合分按 0.75/0.65/0.55 阈值映射为优秀/良好/一般/偏低；
        非数值或越界按 0 处理。

    参数:
        score (float): analyze() 产出的综合分，理论范围 0~1。

    返回:
        str: 档位名称；score 非数值或越界时按 0 处理（返回「偏低」）。

    副作用/异常:
        纯函数，无副作用、不抛异常。
    """
    try:
        value = float(score)
    except (TypeError, ValueError):
        value = 0.0
    for threshold, label in _DETAIL_GRADE_STEPS:
        if value >= threshold:
            return label
    return _DETAIL_GRADE_FALLBACK


def _detail_theme():
    """返回评分明细控件的配色表（浅色表面，亮/暗主题下保持一致）

    功能:
        返回评分明细使用的固定浅色配色表，包含卡片/行/徽标/档位/进度条/
        分项/波色与空态等颜色，保证亮暗主题下文字与底色成对可读。

    参数:
        无。

    返回:
        dict: 键包括 card（卡片底/描边）、row（常态行底/描边）、row_top（Top3 行底/描边）、
              text / muted / track、grade（档位前景/背景）、badge（名次前景/背景）、
              chunk（综合分条颜色）、metric（分项条颜色）、kind（分组强调色）、
              wave（红/绿/蓝波文字色）、empty（空态）、scroll（滚动条）。

    副作用/异常:
        纯函数，无副作用、不抛异常。

    说明:
        为什么不做暗色反色：本页整体是固定浅色仪表盘（页面自身 QSS 固定 #F5F7FB 底
        与白色卡片），主窗口暗色主题只影响全局文字色；若明细卡单独反色，会在同页
        其余白卡之间形成一块深色孤岛。这里固定使用浅色表面，并把所有文字/底色成对
        显式给出（不依赖全局 QSS 继承），因此亮色与暗色主题下都能得到同一份 AA 对比度。
        若收口批次给本页做整体暗色适配，只需在本函数返回另一套同结构取值。
    """
    return {
        'card_bg': '#FFFFFF', 'card_border': '#E5EAF2',
        'row_bg': '#F8FAFD', 'row_border': '#E5EAF2',
        'row_top_bg': '#FFFBEB', 'row_top_border': '#F3D9A4',
        'text': '#1F2D3D', 'muted': '#4B5563', 'track': '#E3EAF4',
        'grade': {
            '优秀': ('#92400E', '#FEF3C7'),
            '良好': ('#166534', '#DCFCE7'),
            '一般': ('#1E40AF', '#DBEAFE'),
            '偏低': ('#475569', '#E2E8F0'),
        },
        'badge': {
            1: ('#78350F', '#FDE68A'),
            2: ('#1F2937', '#E5E7EB'),
            3: ('#7C2D12', '#FED7AA'),
        },
        'badge_other': ('#334155', '#EEF2F7'),
        'chunk': {'优秀': '#D97706', '良好': '#16A34A', '一般': '#2563EB', '偏低': '#64748B'},
        'metric': {'freq': '#2563EB', 'gap': '#D97706', 'trans': '#7C3AED'},
        'kind': {'数字': '#1D4ED8', '生肖': '#6D28D9', '波色': '#0F766E'},
        'wave': {'红波': '#DC2626', '绿波': '#15803D', '蓝波': '#1D4ED8'},
        'empty_bg': '#F8FAFD', 'empty_border': '#C9D4E3',
        'scroll_track': '#F2F5FA', 'scroll_handle': '#B9C7DA',
    }


def _detail_row_models(result):
    """把 analyze() 结果整理成评分明细行模型（展示层唯一取数入口）

    功能:
        从 analyze() 结果读取 numbers/zodiacs/waves，按组生成评分明细行模型
        （名称、名次、综合分、三项分项、补充说明与旧表对比文本）；
        缺字段的单条跳过，不中断其余行。

    参数:
        result (dict|None): BigDataAnalyzer.analyze() 的返回值；None/空字典视为无数据。

    返回:
        list[dict]: 逐行模型，键为
            kind         —— '数字' / '生肖' / '波色'
            name         —— 展示名称（数字两位补零）
            rank         —— 组内名次，从 1 开始
            group_count  —— 本组条数
            score/freq/gap/gap_periods/trans —— 原始数值（不做任何加工）
            note         —— 补充说明（生肖归属 / 成员数等）
            metrics      —— [(单字标签, 全名, 0~1 数值或 None, 提示文案)] 三项分项
            cells        —— 与旧表 7 列逐格对应的文本，用于回归比对

    副作用/异常:
        只读 result，不修改；缺少字段时按空列表/空值兜底，不抛异常。

    顺序:
        与旧表默认展示顺序一致：数字 → 生肖 → 波色；每组内按 analyze() 已排好的
        综合分降序原样保留，不重新排序，因此改造前后分数与名次可逐值对上。
    """
    result = result or {}
    models = []

    def _add(kind, key, name_of, note_of, cells_of, metrics_of):
        """按组追加行模型（内部辅助函数，避免三组重复样板）

        功能:
            读取 result[key] 列表，按 analyze() 已排好的顺序逐条生成行模型，
            并统一补齐 kind/rank/group_count/note/metrics/cells 字段。

        参数:
            kind (str): 组名，'数字' / '生肖' / '波色'。
            key (str): result 中的列表键，'numbers' / 'zodiacs' / 'waves'。
            name_of (callable): item -> str，生成展示名称。
            note_of (callable): item -> str，生成补充说明。
            cells_of (callable): item -> list[str]，生成与旧表 7 列对应的文本。
            metrics_of (callable): item -> list[tuple]，生成三项分项（标签/全名/数值/提示）。

        返回:
            无（行模型直接 append 到外层 models 列表）。

        注意:
            单条数据缺关键字段时捕获 KeyError/TypeError/ValueError 并跳过该行，
            不会影响其他组；本函数只读 result，不修改源数据。
        """
        items = list(result.get(key, []) or [])
        for rank, item in enumerate(items, 1):
            try:
                models.append({
                    'kind': kind,
                    'name': name_of(item),
                    'rank': rank,
                    'group_count': len(items),
                    'score': item['score'],
                    'freq': item['freq'],
                    'gap': item.get('gap'),
                    'gap_periods': item.get('gap_periods'),
                    'trans': item.get('trans'),
                    'note': note_of(item),
                    'metrics': metrics_of(item),
                    'cells': cells_of(item),
                })
            except (KeyError, TypeError, ValueError):
                # 单条数据缺字段时跳过该行，不影响其余行的展示
                continue

    _add('数字', 'numbers',
         lambda i: '%02d' % i['number'],
         lambda i: '生肖 %s · 遗漏 %s 期' % (i['zodiac'], i.get('gap_periods', '-')),
         lambda i: ['数字', '%02d' % i['number'], '%.4f' % i['score'], '%.4f' % i['freq'],
                    '%.4f' % i.get('gap', 0), '%.4f' % i.get('trans', 0), '生肖 %s' % i['zodiac']],
         lambda i: [('频', '频率分', i['freq'], '频率特征：近期出现次数（时间衰减加权）'),
                    ('漏', '遗漏分', i.get('gap'), '遗漏特征：距上次出现的期数（越久越接近回补）'),
                    ('转', '转移分', i.get('trans'), '转移特征：与最新一期号码环境的马尔可夫强度')])

    _add('生肖', 'zodiacs',
         lambda i: i['zodiac'],
         lambda i: '成员号码 %s 个' % i.get('count', '-'),
         lambda i: ['生肖', i['zodiac'], '%.4f' % i['score'], '%.4f' % i['freq'],
                    '-', '-', '成员号码 %s 个' % i.get('count', '-')],
         lambda i: [('频', '频率分', i['freq'], '生肖整体出现强度（成员命中次数的时间衰减加权）'),
                    ('漏', '遗漏分', None, '生肖按成员均值评分，本组不单独统计遗漏'),
                    ('转', '转移分', None, '生肖按成员均值评分，本组不单独统计转移')])

    _add('波色', 'waves',
         lambda i: i['wave'],
         lambda i: '成员号码 %s 个（场均 %.2f 个）' % (i.get('count', '-'), i.get('avg_per_draw', 0.0)),
         lambda i: ['波色', i['wave'], '%.4f' % i['score'], '%.4f' % i['freq'],
                    '%.4f/%s期' % (i.get('gap', 0), i.get('gap_periods', '-')),
                    '%.4f' % i.get('trans', 0),
                    '成员号码 %s 个（场均 %.2f 个）' % (i.get('count', '-'), i.get('avg_per_draw', 0.0))],
         lambda i: [('频', '频率分', i['freq'], '波色成员命中次数的时间衰减加权'),
                    ('漏', '遗漏分', i.get('gap'), '波色整体距上次出现的期数（越久越接近回补）'),
                    ('转', '转移分', i.get('trans'), '与最新一期号码环境的波色转移强度')])

    return models


def _apply_detail_chrome(host, theme):
    """把明细卡的卡片底、标题、图例与滚动条切换为当前主题配色

    功能:
        按 theme 覆盖明细卡、标题、图例、内容容器与滚动条的 QSS；
        不重建行控件，控件已销毁时静默跳过。

    参数:
        host (LotteryPredictionWindow): 需已有 bd_detail_card / bd_detail_title /
            bd_detail_legend / bd_detail_scroll / bd_detail_content。
        theme (dict): _detail_theme() 的返回值。

    返回:
        None。

    副作用:
        覆盖上述控件的局部 QSS；不重建行控件，不读取业务数据。

    异常:
        RuntimeError（控件已销毁）时静默跳过，不影响渲染主流程。
    """
    try:
        card = getattr(host, 'bd_detail_card', None)
        if card is not None:
            card.setStyleSheet(
                "QFrame#BdCard { background-color: %s; border: 1px solid %s; border-radius: 10px; }"
                % (theme['card_bg'], theme['card_border']))
        title = getattr(host, 'bd_detail_title', None)
        if title is not None:
            title.setStyleSheet(
                "QLabel { font-size: 15px; font-weight: bold; color: %s; background: transparent; }"
                % theme['text'])
        legend = getattr(host, 'bd_detail_legend', None)
        if legend is not None:
            legend.setStyleSheet(
                "QLabel { font-size: 15px; color: %s; background: transparent; }" % theme['muted'])
        content = getattr(host, 'bd_detail_content', None)
        if content is not None:
            content.setStyleSheet("QWidget#BdDetailContent { background: transparent; }")
        scroll = getattr(host, 'bd_detail_scroll', None)
        if scroll is not None:
            # 滚动条：亮色浅槽 + 灰蓝滑块；暗色深槽 + 灰紫滑块，宽度 10px 便于抓取
            scroll.setStyleSheet(
                "QScrollArea { background: transparent; border: none; }"
                "QScrollBar:vertical { background: %s; width: 10px; margin: 0; border: none; }"
                "QScrollBar::handle:vertical { background: %s; min-height: 28px; "
                "border-radius: 5px; }"
                "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }"
                "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }"
                % (theme['scroll_track'], theme['scroll_handle']))
    except RuntimeError:
        return


def _detail_empty_widget(theme):
    """创建评分明细的空状态控件（未分析 / 数据不足 / 结果为空时复用）

    功能:
        创建虚线描边的空态卡（16px 标题 + 15px 可换行说明），
        用于未分析/数据不足/结果为空时的明细区占位。

    参数:
        theme (dict): _detail_theme() 的返回值。

    返回:
        QFrame: 虚线描边的空态卡，内含 16px 标题与 15px 说明，居中且可换行。

    副作用/异常:
        只创建控件，无副作用、不抛异常。
    """
    frame = QFrame()
    frame.setObjectName("BdDetailEmpty")
    frame.setStyleSheet(
        "QFrame#BdDetailEmpty { background-color: %s; border: 1px dashed %s; border-radius: 8px; }"
        % (theme['empty_bg'], theme['empty_border']))
    frame.setMinimumHeight(116)
    box = QVBoxLayout(frame)
    box.setContentsMargins(18, 16, 18, 16)
    box.setSpacing(6)

    title = QLabel("暂无评分明细")
    title.setAlignment(Qt.AlignmentFlag.AlignCenter)
    title.setStyleSheet(
        "QLabel { font-size: 16px; font-weight: bold; color: %s; background: transparent; }"
        % theme['text'])
    desc = QLabel("点击右上角「开始分析」后，这里会按「数字 / 生肖 / 波色」三组展示：\n"
                  "名次徽标 · 等级标签 · 综合分进度条 · 频率 / 遗漏 / 转移分项进度条")
    desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
    desc.setWordWrap(True)
    desc.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % theme['muted'])
    box.addStretch(1)
    box.addWidget(title)
    box.addWidget(desc)
    box.addStretch(1)
    return frame


def _detail_group_header(kind, count, theme):
    """创建分组标题行（彩色竖条 + 组名 + 条数 + 排序说明）

    功能:
        创建 26px 高的分组标题行：4px 彩色竖条 + 「X评分」+ 条数 +
        右对齐的「按综合分降序 · 组内排名」提示。

    参数:
        kind (str): '数字' / '生肖' / '波色'。
        count (int): 本组条数。
        theme (dict): _detail_theme() 的返回值。

    返回:
        QWidget: 固定 26px 高的分组标题，透明底。

    副作用/异常:
        只创建控件，无副作用、不抛异常。
    """
    holder = QWidget()
    holder.setFixedHeight(26)
    row = QHBoxLayout(holder)
    row.setContentsMargins(2, 4, 2, 0)
    row.setSpacing(8)

    accent = QLabel()
    accent.setFixedSize(4, 16)
    accent.setStyleSheet(
        "QLabel { background-color: %s; border-radius: 2px; }" % theme['kind'].get(kind, theme['muted']))
    title = QLabel("%s评分" % kind)
    title.setStyleSheet(
        "QLabel { font-size: 15px; font-weight: bold; color: %s; background: transparent; }"
        % theme['text'])
    count_label = QLabel("%d 项" % count)
    count_label.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % theme['muted'])
    hint = QLabel("按综合分降序 · 组内排名")
    hint.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % theme['muted'])

    row.addWidget(accent)
    row.addWidget(title)
    row.addWidget(count_label)
    row.addStretch(1)
    row.addWidget(hint)
    return holder


def _detail_metric_block(label, full_name, value, tooltip, color, theme):
    """创建单个分项指标块（15px 单字标签 + 细进度条 + 四位小数）

    功能:
        创建 20px 高的单分项块：单字标签 + 38×8px 细进度条 + 四位小数；
        value 为 None 时显示「—」且进度条使用轨道色。

    参数:
        label (str): 进度条左侧单字标签（频 / 漏 / 转），与表头图例对应。
        full_name (str): 完整指标名（用于 tooltip）。
        value (float|None): 归一化后的 0~1 分数；None 表示本组不统计该维度。
        tooltip (str): 指标口径说明。
        color (str): 进度条填充色。
        theme (dict): _detail_theme() 的返回值。

    返回:
        QWidget: 固定 20px 高的「标签 + 8px 细条 + 数值」块。

    副作用/异常:
        只创建控件，无副作用；value 非数值时按 None 渲染，不抛异常。
    """
    holder = QWidget()
    holder.setFixedHeight(20)
    holder.setToolTip(tooltip)
    row = QHBoxLayout(holder)
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(4)

    tag = QLabel(label)
    tag.setToolTip("%s（%s）" % (full_name, tooltip))
    tag.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % theme['muted'])
    row.addWidget(tag)

    bar = QProgressBar()
    bar.setObjectName("BdMiniBar")
    bar.setFixedSize(38, 8)
    bar.setRange(0, 1000)
    num = None
    try:
        if value is not None:
            num = max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        num = None
    bar.setValue(int(round((num or 0.0) * 1000)))
    bar.setTextVisible(False)
    bar.setStyleSheet(
        "QProgressBar#BdMiniBar { background-color: %s; border: none; border-radius: 4px; }"
        "QProgressBar#BdMiniBar::chunk { background-color: %s; border-radius: 4px; }"
        % (theme['track'], color if num is not None else theme['track']))
    row.addWidget(bar)

    text = QLabel('%.4f' % num if num is not None else '—')
    text.setMinimumWidth(52)
    text.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    text.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }"
        % (theme['text'] if num is not None else theme['muted']))
    row.addWidget(text)
    return holder


def _detail_row_widget(host, row, theme):
    """创建单行评分卡（名次徽标 + 名称 + 档位 + 综合分条 + 三条分项条）

    功能:
        创建单行评分卡：名次徽标、组名/名称/说明、档位标签、综合分与
        综合条，以及频率/遗漏/转移三条分项条；Top3 使用暖色底强调。

    参数:
        host (LotteryPredictionWindow): 主窗口实例（用于读取主题，当前不读写其他属性）。
        row (dict): _detail_row_models() 的单行模型。
        theme (dict): _detail_theme() 的返回值。

    返回:
        QFrame: 固定 46px 高的评分行；Top3 使用暖色底 + 档位色左边条。

    副作用/异常:
        只创建控件；行上设置完整数值 tooltip，不抛异常。
    """
    score = row.get('score', 0.0)
    grade = _detail_grade(score)
    is_top3 = row['rank'] <= 3
    accent = theme['chunk'][grade]
    bg = theme['row_top_bg'] if is_top3 else theme['row_bg']
    border = theme['row_top_border'] if is_top3 else theme['row_border']

    frame = QFrame()
    frame.setObjectName("BdDetailRow")
    frame.setFixedHeight(46)
    frame.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
    frame.setStyleSheet(
        "QFrame#BdDetailRow { background-color: %s; border: 1px solid %s; "
        "border-left: 3px solid %s; border-radius: 8px; }"
        % (bg, border, accent))
    frame.setToolTip(
        "第 %d 名 · %s\n综合分 %.4f（%s）\n频率分 %s\n遗漏分 %s\n转移分 %s\n%s" % (
            row['rank'], row['name'], score, grade,
            '%.4f' % row['freq'] if row.get('freq') is not None else '—',
            '%.4f' % row['gap'] if row.get('gap') is not None else '—',
            '%.4f' % row['trans'] if row.get('trans') is not None else '—',
            row.get('note', '')))

    outer = QHBoxLayout(frame)
    outer.setContentsMargins(10, 5, 10, 5)
    outer.setSpacing(8)

    badge_fg, badge_bg = theme['badge'].get(row['rank'], theme['badge_other'])
    badge = QLabel(str(row['rank']))
    badge.setFixedSize(26, 26)
    badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
    badge.setToolTip("组内第 %d 名（共 %d 项）" % (row['rank'], row.get('group_count', 0)))
    badge.setStyleSheet(
        "QLabel { background-color: %s; color: %s; border-radius: 13px; "
        "font-size: 15px; font-weight: bold; }" % (badge_bg, badge_fg))
    outer.addWidget(badge, 0, Qt.AlignmentFlag.AlignVCenter)

    body = QVBoxLayout()
    body.setContentsMargins(0, 0, 0, 0)
    body.setSpacing(2)

    top = QHBoxLayout()
    top.setContentsMargins(0, 0, 0, 0)
    top.setSpacing(8)

    kind = QLabel(row['kind'])
    kind.setStyleSheet(
        "QLabel { font-size: 15px; font-weight: bold; color: %s; background: transparent; }"
        % theme['kind'].get(row['kind'], theme['muted']))
    top.addWidget(kind, 0, Qt.AlignmentFlag.AlignVCenter)

    name = QLabel(row['name'])
    name.setMinimumWidth(34)
    name_color = theme['wave'].get(row['name'], theme['text'])
    name.setStyleSheet(
        "QLabel { font-size: 16px; font-weight: bold; color: %s; background: transparent; }"
        % name_color)
    top.addWidget(name, 0, Qt.AlignmentFlag.AlignVCenter)

    note = QLabel(row.get('note', ''))
    # 说明文字按当前字体计算最小宽度：1180 宽下仍完整显示，不靠省略号截断
    note.setMinimumWidth(note.fontMetrics().horizontalAdvance(row.get('note', '')) + 2)
    note.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % theme['muted'])
    top.addWidget(note, 0, Qt.AlignmentFlag.AlignVCenter)
    top.addStretch(1)

    chip_fg, chip_bg = theme['grade'][grade]
    grade_chip = QLabel(grade)
    grade_chip.setFixedHeight(24)
    grade_chip.setAlignment(Qt.AlignmentFlag.AlignCenter)
    grade_chip.setStyleSheet(
        "QLabel { background-color: %s; color: %s; border-radius: 12px; padding: 0 10px; "
        "font-size: 15px; font-weight: bold; }" % (chip_bg, chip_fg))
    top.addWidget(grade_chip, 0, Qt.AlignmentFlag.AlignVCenter)

    score_label = QLabel('%.4f' % score)
    score_label.setMinimumWidth(58)
    score_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    score_label.setStyleSheet(
        "QLabel { font-size: 16px; font-weight: bold; color: %s; background: transparent; }"
        % theme['text'])
    top.addWidget(score_label, 0, Qt.AlignmentFlag.AlignVCenter)
    body.addLayout(top)

    bottom = QHBoxLayout()
    bottom.setContentsMargins(0, 0, 0, 0)
    bottom.setSpacing(8)

    bar_caption = QLabel("综合")
    bar_caption.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % theme['muted'])
    bottom.addWidget(bar_caption, 0, Qt.AlignmentFlag.AlignVCenter)

    bar = QProgressBar()
    bar.setObjectName("BdScoreBar")
    bar.setRange(0, 1000)
    bar.setValue(int(round(max(0.0, min(1.0, float(score))) * 1000)))
    bar.setTextVisible(False)
    bar.setFixedHeight(10)
    bar.setMinimumWidth(140)
    bar.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
    bar.setStyleSheet(
        "QProgressBar#BdScoreBar { background-color: %s; border: none; border-radius: 5px; }"
        "QProgressBar#BdScoreBar::chunk { background-color: %s; border-radius: 5px; }"
        % (theme['track'], accent))
    bottom.addWidget(bar, 1)

    metric_colors = {'频': theme['metric']['freq'],
                     '漏': theme['metric']['gap'],
                     '转': theme['metric']['trans']}
    for tag, full_name, value, tip in row.get('metrics', []):
        bottom.addWidget(_detail_metric_block(
            tag, full_name, value, tip, metric_colors.get(tag, theme['metric']['freq']), theme),
            0, Qt.AlignmentFlag.AlignVCenter)

    body.addLayout(bottom)
    outer.addLayout(body, 1)
    return frame


def _render_detail(host, result):
    """重建评分明细区（有结果时渲染 17 行评分卡，无结果时渲染空状态）

    功能:
        清空明细行布局后，按 row models 重建「分组标题 + 评分卡」或空态；
        同时刷新配色、恢复滚动位置并延迟校准内容高度。

    参数:
        host (LotteryPredictionWindow): 需已有 bd_detail_layout / bd_detail_scroll。
        result (dict|None): analyze() 结果；None 表示未分析/数据不足。

    返回:
        None。

    副作用:
        - 清空并重建 bd_detail_layout 的全部行控件（旧控件 deleteLater）；
        - 刷新卡片、标题、图例与滚动条配色（固定浅色表面，亮/暗主题一致）；
        - 重建后恢复原滚动位置（再次分析或重绘时不跳回顶部）。

    异常:
        控件已销毁（RuntimeError）时静默返回；单行模型缺失字段已在
        _detail_row_models 内跳过，不向 Qt 事件循环抛异常。
    """
    layout = getattr(host, 'bd_detail_layout', None)
    if layout is None:
        return
    theme = _detail_theme()
    _apply_detail_chrome(host, theme)

    scroll = getattr(host, 'bd_detail_scroll', None)
    old_pos = 0
    try:
        if scroll is not None:
            old_pos = scroll.verticalScrollBar().value()
    except RuntimeError:
        scroll = None

    _clear_layout(layout)
    models = _detail_row_models(result)
    if not models:
        # 前后各留一个弹性间隔：内容被 QScrollArea 撑到视口高度时，
        # 空态框居中而不是贴着卡片顶部、下方留一大块空白。
        layout.addStretch(1)
        layout.addWidget(_detail_empty_widget(theme))
        layout.addStretch(1)
    else:
        current_kind = None
        for row in models:
            if row['kind'] != current_kind:
                if current_kind is not None:
                    layout.addSpacing(6)
                layout.addWidget(_detail_group_header(row['kind'], row['group_count'], theme))
                current_kind = row['kind']
            layout.addWidget(_detail_row_widget(host, row, theme))
        layout.addStretch(1)

    _fit_detail_content(host)
    # 首次渲染时行控件可能尚未完成 polish，立即读取的 sizeHint 仍是旧值；
    # 排到下一轮事件循环再校准一次，保证滚动区拿到真实内容高度。
    QTimer.singleShot(0, lambda: _fit_detail_content(host))
    try:
        if scroll is not None:
            scroll.verticalScrollBar().setValue(old_pos)
    except RuntimeError:
        pass


def _fit_detail_content(host):
    """把明细内容控件的最小高度对齐到行布局的真实高度

    功能:
        强制激活明细行布局，取其 sizeHint 高度写入内容控件最小高度，
        让 QScrollArea 获得正确的纵向滚动范围。

    参数:
        host (LotteryPredictionWindow): 需已有 bd_detail_content / bd_detail_layout。

    返回:
        None。

    副作用:
        layout.activate() 强制重算一次 sizeHint，再把内容最小高度设为该值；
        QScrollArea 随即可给出正确的纵向滚动范围，不再沿用上一轮（空态）的高度。

    异常:
        RuntimeError（控件已销毁）时静默返回。
    """
    try:
        content = getattr(host, 'bd_detail_content', None)
        if content is None:
            return
        layout = content.layout()
        if layout is None:
            return
        layout.activate()
        content.setMinimumHeight(layout.sizeHint().height())
    except RuntimeError:
        return



def _render_zodiac_card(host, idx, item):
    """渲染单个推荐生肖卡片（两行紧凑布局：名称+得分 / 成员号码）

    功能:
        创建单个生肖卡片：圆形名次徽标 + 生肖名 + 综合分/成员数 +
        成员号码文本（自动折行），由 render_result 放入双列网格。

    参数:
        host (LotteryPredictionWindow): 主窗口实例（当前未读取属性，保持签名一致）。
        idx (int): 排名序号，从 1 开始，显示在左侧圆形徽标中。
        item (dict): BigDataAnalyzer 产出的生肖项，含 zodiac / score / count / numbers。

    返回:
        QFrame: 未加入布局的生肖卡片，由 render_result 放入网格。

    副作用:
        无（只创建控件）。

    异常:
        item 缺字段时抛 KeyError（调用方应保证字段齐全）。
    """
    card = QFrame()
    # 生肖卡片样式
    #   background-color: #F8FAFD         极浅灰蓝底，与白卡片区分
    #   border: 1px solid #E5EAF2         1px 浅灰蓝描边（COLOR_BORDER）
    #   border-left: 4px solid #2563EB    左侧 4px 蓝色强调条（排名视觉锚点）
    #   border-radius: 8px                8px 圆角
    card.setStyleSheet(
        "QFrame { background-color: #F8FAFD; border: 1px solid %s; border-left: 4px solid %s; "
        "border-radius: 8px; }" % (COLOR_BORDER, "#2563EB"))
    row = QHBoxLayout(card)
    row.setContentsMargins(10, 6, 10, 6)
    row.setSpacing(8)

    rank = QLabel(str(idx))
    rank.setFixedSize(24, 24)
    rank.setAlignment(Qt.AlignmentFlag.AlignCenter)
    # 排名徽标样式
    #   background-color: #2563EB  主操作蓝底
    #   color: #FFFFFF             白字
    #   border-radius: 12px        12px 圆角（24×24 正方形 → 正圆）
    #   font-size: 15px            下限字号
    #   font-weight: bold          突出名次
    rank.setStyleSheet(
        "QLabel { background-color: #2563EB; color: #FFFFFF; border-radius: 12px; "
        "font-size: 15px; font-weight: bold; }")
    row.addWidget(rank)

    text_box = QVBoxLayout()
    text_box.setSpacing(1)
    head = QHBoxLayout()
    head.setSpacing(8)
    name = QLabel(item['zodiac'])
    # 生肖名称样式：font-size 16px（比正文大 1px 形成层级）；font-weight bold；
    # color #1F2D3D（COLOR_TEXT 正文色）；background transparent（透出卡片底色）
    name.setStyleSheet(
        "QLabel { font-size: 16px; font-weight: bold; color: #1F2D3D; background: transparent; }")
    head.addWidget(name)
    head.addStretch(1)
    score = QLabel("综合分 %.4f · 成员 %d" % (item['score'], item['count']))
    # 得分文字样式：font-size 15px（下限字号）；color #7A8798（次要灰）；
    # background transparent（透出卡片底色）
    score.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % COLOR_MUTED)
    head.addWidget(score)
    numbers = QLabel(' '.join('%02d' % n for n in item['numbers']))
    numbers.setWordWrap(True)  # 成员号码较多时自动折行，避免撑破卡片
    # 成员号码样式：font-size 15px（下限字号）；color #334155（中深灰蓝）；
    # background transparent（透出卡片底色）
    numbers.setStyleSheet(
        "QLabel { font-size: 15px; color: #334155; background: transparent; }")
    text_box.addLayout(head)
    text_box.addWidget(numbers)
    row.addLayout(text_box, 1)
    return card


def _render_number_cell(host, idx, item):
    """渲染单个推荐数字（号码球 + 综合分）

    功能:
        创建单个数字单元格：NumberBallWithZodiac 号码球（含生肖与五行）
        + 居中综合分文本，tooltip 展示频率/遗漏/转移细项。

    参数:
        host (LotteryPredictionWindow): 主窗口实例（当前未读取属性，保持签名一致）。
        idx (int): 数字在结果中的序号（用于 4 列网格定位，不在单元格内显示）。
        item (dict): 数字项，含 number / zodiac / score / freq / gap_periods / trans。

    返回:
        QWidget: 竖向排列「号码球 + 综合分」的容器。

    副作用:
        无（只创建控件；号码球 tooltip 展示四项细分得分）。

    异常:
        item 缺字段时抛 KeyError。
    """
    holder = QWidget()
    # 单个号码球容器透明：单元格只做居中排版，不额外画底色
    holder.setStyleSheet("QWidget { background: transparent; }")
    box = QVBoxLayout(holder)
    box.setContentsMargins(0, 0, 0, 0)
    box.setSpacing(3)

    num = item['number']
    element = LotteryConfig.NUMBER_ELEMENTS.get(num, '')
    ball = NumberBallWithZodiac(
        num, zodiac=item.get('zodiac', ''), element=element,
        is_special=False, font_size=15)  # 生肖/五行标签 15px：与卡内综合分文字一致，守住全局字号下限
    ball.setToolTip("综合分 %.4f\n频率分 %.4f\n遗漏 %d 期\n转移分 %.4f" % (
        item['score'], item['freq'], item['gap_periods'], item['trans']))
    box.addWidget(ball, 0, Qt.AlignmentFlag.AlignHCenter)

    score = QLabel("%.4f" % item['score'])
    score.setAlignment(Qt.AlignmentFlag.AlignCenter)
    # 综合分样式：font-size 15px（下限字号）；color #7A8798（次要灰）；
    # background transparent（透出卡片白底）
    score.setStyleSheet(
        "QLabel { font-size: 15px; color: %s; background: transparent; }" % COLOR_MUTED)
    box.addWidget(score)
    return holder


def _render_wave_card(item):
    """渲染单个波色评分卡片

    功能:
        创建单个波色评分卡：波色名称 + 综合分 + 细进度条，
        红/绿/蓝各用对应主色与浅底，未知波色回退灰色。

    参数:
        item (dict): 波色项，含 wave（红波/绿波/蓝波）/ score / freq /
            gap / gap_periods / trans / count / avg_per_draw。

    返回:
        QFrame: 带左侧色条、右上得分与底部进度条的波色卡片。

    副作用:
        无（只创建控件；tooltip 展示细分指标）。

    异常:
        item 缺字段时抛 KeyError；未知波色名回退灰色 (#64748B / #F8FAFC)。
    """
    wave_style = {
        '红波': ('#EF4444', '#FFF5F5'),
        '绿波': ('#16A34A', '#F0FDF4'),
        '蓝波': ('#2563EB', '#EFF6FF'),
    }
    accent, bg = wave_style.get(item['wave'], ('#64748B', '#F8FAFC'))

    card = QFrame()
    # 波色卡片样式
    #   background-color: 波色浅底（红 #FFF5F5 / 绿 #F0FDF4 / 蓝 #EFF6FF / 兜底 #F8FAFC）
    #   border: 1px solid #E5EAF2              1px 浅灰蓝描边（COLOR_BORDER）
    #   border-left: 4px solid 波色主色        左侧 4px 色条（红 #EF4444 / 绿 #16A34A / 蓝 #2563EB）
    #   border-radius: 8px                     8px 圆角
    card.setStyleSheet(
        "QFrame { background-color: %s; border: 1px solid %s; border-left: 4px solid %s; "
        "border-radius: 8px; }" % (bg, COLOR_BORDER, accent))
    card.setToolTip("频率 %.3f　遗漏 %d 期　转移 %.3f\n成员 %d 个（场均 %.2f 个）" % (
        item['freq'], item['gap_periods'], item['trans'], item['count'], item['avg_per_draw']))
    box = QVBoxLayout(card)
    box.setContentsMargins(12, 7, 12, 7)
    box.setSpacing(4)

    top = QHBoxLayout()
    name = QLabel(item['wave'])
    # 波色名称样式：font-size 15px（下限字号）；font-weight bold；color=波色主色；
    # background transparent（透出波色浅底）
    name.setStyleSheet(
        "QLabel { font-size: 15px; font-weight: bold; color: %s; background: transparent; }" % accent)
    top.addWidget(name)
    top.addStretch(1)
    score = QLabel("%.4f" % item['score'])
    # 得分样式：font-size 15px（下限字号）；font-weight bold；color=波色主色；
    # background transparent（透出波色浅底）
    score.setStyleSheet(
        "QLabel { font-size: 15px; font-weight: bold; color: %s; background: transparent; }" % accent)
    top.addWidget(score)
    box.addLayout(top)

    bar = QProgressBar()
    bar.setRange(0, 100)
    bar.setValue(max(0, min(100, int(round(item['score'] * 100)))))
    bar.setTextVisible(False)
    bar.setFixedHeight(6)
    # 进度条样式
    #   QProgressBar background-color: #FFFFFF  白色槽底
    #   border: none                            无边框
    #   border-radius: 3px                      3px 圆角（配合 6px 高形成细条）
    #   chunk background-color: 波色主色        已完成部分用波色强调
    #   chunk border-radius: 3px                圆角与槽一致
    bar.setStyleSheet(
        "QProgressBar { background-color: #FFFFFF; border: none; border-radius: 3px; }"
        "QProgressBar::chunk { background-color: %s; border-radius: 3px; }" % accent)
    box.addWidget(bar)
    return card


def render_result(host, result):
    """把分析结果渲染到界面（生肖卡片、号码球、波色、明细表、KPI）

    功能:
        先清空三个结果布局，再按 result 重建：生肖双列卡片、数字 4 列号码球、
        波色三卡、评分明细控件（名次徽标 + 等级标签 + 综合分/分项进度条），
        最后更新 KPI / 数据源徽标 / 统计文本 / 横幅摘要。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已有 build 阶段创建的全部
            bd_* 控件（bd_zodiac_layout / bd_number_layout / bd_wave_layout /
            bd_detail_layout / bd_kpi_* / bd_source_label / bd_banner_subtitle）。
        result (dict): BigDataAnalyzer.analyze() 的返回值，含 meta / zodiacs /
            numbers / waves / stats；字段缺失时按空列表处理。

    返回:
        None。

    副作用:
        销毁并重建三个布局与评分明细区内的全部子控件（旧控件 deleteLater）；
        覆盖明细行内容与 KPI 文本；不改变任何分数或排序（分值原样取自 result）。

    异常:
        format_stats_text 的异常被单独捕获并降级为空文本；
        其余字段访问由 .get 兜底，正常不抛出。
    """
    meta = result.get('meta', {})

    # 0. KPI 与数据源
    host.bd_kpi_used_label.setText(str(meta.get('used', '—')))
    host.bd_kpi_total_label.setText(str(meta.get('total', '—')))
    host.bd_kpi_period_label.setText(str(meta.get('latest_period', '—')))
    host.bd_kpi_wave_label.setText(str(meta.get('top_wave', '—')))
    host.bd_source_label.setText("数据源 · %s" % meta.get('source', '内存'))
    host.bd_zodiac_count_label.setText("%d / 7" % len(result.get('zodiacs', [])))
    host.bd_number_count_label.setText("%d / 7" % len(result.get('numbers', [])))

    # 1. 生肖卡片（双列排布，7 项尽量一屏显示）
    _clear_layout(host.bd_zodiac_layout)
    for r in range(host.bd_zodiac_layout.rowCount()):
        host.bd_zodiac_layout.setRowStretch(r, 0)
    zodiacs = result.get('zodiacs', [])
    for idx, item in enumerate(zodiacs, 1):
        host.bd_zodiac_layout.addWidget(
            _render_zodiac_card(host, idx, item), (idx - 1) // 2, (idx - 1) % 2)
    if not zodiacs:
        host.bd_zodiac_layout.addWidget(_empty_hint("暂无推荐生肖"), 0, 0, 1, 2)
    else:
        # 末尾补一行伸缩，避免卡片被纵向拉伸变形
        host.bd_zodiac_layout.setRowStretch((len(zodiacs) - 1) // 2 + 1, 1)

    # 2. 数字号码球
    _clear_layout(host.bd_number_layout)
    for idx, item in enumerate(result.get('numbers', [])):
        host.bd_number_layout.addWidget(
            _render_number_cell(host, idx, item), idx // 4, idx % 4)
    if not result.get('numbers'):
        host.bd_number_layout.addWidget(_empty_hint("暂无推荐数字"), 0, 0, 1, 4)

    # 3. 波色卡片
    _clear_layout(host.bd_wave_layout)
    for item in result.get('waves', []):
        host.bd_wave_layout.addWidget(_render_wave_card(item), 1)
    if not result.get('waves'):
        host.bd_wave_layout.addWidget(_empty_hint("暂无波色分析结果"), 1)

    # 4. 评分明细（名次徽标 + 等级标签 + 综合分/分项进度条）
    _render_detail(host, result)

    # 5. 统计检验与趋势
    stats_text = ''
    try:
        stats_text = BigDataAnalyzer.format_stats_text(result.get('stats'))
    except Exception:
        stats_text = ''
    if hasattr(host, 'bd_stats_label'):
        host.bd_stats_label.setText(stats_text or '暂无统计数据')

    # 6. 横幅副标题复用为结果摘要
    # 与失败/取消时的回退共用 _summary_text，保证三种路径文案格式一致
    host.bd_banner_subtitle.setText(_summary_text(result))
