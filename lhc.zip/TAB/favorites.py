# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/favorites.py - 「收藏」选项卡页面构建模块
===========================================================================
功能说明：
    构建主窗口「收藏」选项卡的全部界面控件，并挂载到主窗口实例上。

TAB_INFO（供 TAB/__init__.py 自动发现）：
    title   = "收藏"
    order   = 12（排在预测相关页面之后，用于保存/对比预测结果）
    enabled = True

依赖：
    - UI/UI.py：QWidget/QVBoxLayout/QHBoxLayout/QLabel/QPushButton/QListWidget，
      禁止直接 from PyQt6 import
    - 无 lib/ 业务依赖；收藏数据的读写、持久化与对比逻辑均在主窗口
      LotteryPredictionWindow 中，本页只负责界面与信号接线

数据流：
    主窗口维护收藏数据 → build(host) 创建 host.favorites_list 并连接 6 个按钮
    回调 → 用户操作时进入主窗口 _on_*_saved_prediction → 主窗口更新数据后
    回填 favorites_list 与 favorites_count_label（本页不直接改数据）。

职责边界：
    - 本模块只负责界面构建（布局、控件、初始样式）
    - 事件处理函数保留在主窗口 LotteryPredictionWindow 中，通过信号连接
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import os as _os_boot  # 作用说明：提供路径拼接/存在性判断/绝对路径解析能力，用于向上查找 run.py 所在的项目根目录
import sys as _sys_boot  # 作用说明：提供 sys.path 列表操作能力，把项目根目录插入模块搜索路径，使 UI 包可直接导入

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QHBoxLayout, QLabel, QListWidget, QPushButton, QVBoxLayout, QWidget)  # 作用说明：提供本页所需 Qt 控件（水平/垂直布局、标题与统计标签、支持多选的收藏列表、操作按钮、页面容器），统一由 UI/UI.py 导出


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "收藏",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 12,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def get_favorites_list(host):
    """取得当前可用的收藏列表控件（供多页安全访问）

    功能:
        原主窗口 `_get_favorites_list` 迁入本页。收藏列表由本页 build() 创建为
        `host.favorites_list`；历史版本曾使用 `host.saved_predictions_list`，
        这里保留同名兜底，避免旧调用方在控件尚未创建时崩溃。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。

    返回:
        QListWidget | None: 已创建的收藏列表控件；两个候选属性都不存在时返回 None。

    注意:
        只读访问，不修改列表内容和选择状态（增删改仍由主窗口负责）；控件由
        build() 创建，未构建或已被销毁时返回 None，调用方必须判空后再使用。

    降级:
        使用 hasattr 探测，不抛 AttributeError；调用方需自行处理 None
        （原实现的调用方均先判空或仅遍历选中项，行为不变）。
    """
    if hasattr(host, 'favorites_list') and host.favorites_list is not None:
        return host.favorites_list
    if hasattr(host, 'saved_predictions_list') and host.saved_predictions_list is not None:
        return host.saved_predictions_list
    return None


def install(host):
    """挂载收藏列表访问器并构建页面

    功能:
        由主窗口创建选项卡时调用；先把收藏列表的只读访问器挂到 host
        （host._get_favorites_list），再调用 build(host) 构建并返回页面控件。

    参数:
        host: 主窗口实例。

    返回:
        QWidget: build(host) 构建完成的页面控件。

    副作用:
        host._get_favorites_list → get_favorites_list(host)
        供预测页等跨页只读访问收藏列表，不改变收藏数据归属。

    说明:
        必须先绑定再 build：build 内部会 connect 多个主窗口回调，
        但本页自身不直接使用该访问器，绑定顺序对 build 无影响。
    """
    host._get_favorites_list = lambda: get_favorites_list(host)
    return build(host)


def build(host):
    """构建「收藏」选项卡页面

    功能:
        创建标题、6 个操作按钮、收藏列表与条数统计，并完成信号接线。

    参数:
        host: 主窗口实例（LotteryPredictionWindow），控件与状态挂载在此对象上。
            本函数写入：
                host.favorites_list         —— QListWidget，收藏条目列表（支持多选）；
                host.favorites_count_label  —— QLabel，底部“共 N 条收藏”统计。
            读取/连接主窗口的 6 个按钮回调：
                _on_save_current_prediction      保存当前预测
                _on_load_saved_prediction        加载选中预测
                _on_show_saved_prediction_detail 查看详情
                _on_compare_saved_predictions    多选对比
                _on_delete_saved_prediction      删除选中
                _on_clear_saved_predictions      清空全部
            另连接 favorites_list.itemDoubleClicked 到查看详情（第 7 个信号入口）。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        1) 在 host 上创建列表与统计标签，列表 stretch=1 占据剩余高度；
        2) 绑定上述 6 个 clicked 与 1 个 itemDoubleClicked 信号；
        3) 本页不读取收藏数据、不刷新列表内容（由主窗口在数据变化后调用）。

    说明:
        列表选择模式为 ExtendedSelection，才能按住 Ctrl/Shift 多选做对比；
        按钮文案中的 emoji 与颜色仅作操作语义区分，不影响业务逻辑。
    """
    widget = QWidget()
    # 主垂直布局
    layout = QVBoxLayout(widget)
    layout.setSpacing(8)
    layout.setContentsMargins(10, 10, 10, 10)

    # 标题
    title = QLabel("收藏预测结果")
    # 收藏页标题样式：18px字号，粗体，深蓝灰文字
    title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2C3E50;")
    layout.addWidget(title)

    # 操作按钮行
    btn_layout = QHBoxLayout()

    # 保存当前预测按钮：将当前预测结果加入收藏列表
    save_btn = QPushButton("💾 保存当前预测")
    # 保存按钮样式 - 绿色系（安全/保存操作）
    #   QPushButton {       常态样式
    #     background-color: #2ECC71;  背景色：绿色
    #     color: white;               文字颜色：白色
    #     border: none;               无边框
    #     border-radius: 6px;         圆角
    #     padding: 8px 20px;          内边距
    #     font-weight: bold;          粗体
    #     font-size: 15px;            字号
    #   }
    #   QPushButton:hover {  悬停样式
    #     background-color: #27AE60;  悬停背景加深
    #   }
    save_btn.setStyleSheet("""
        QPushButton { background-color: #2ECC71; color: white; border: none; 
            border-radius: 6px; padding: 8px 20px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #27AE60; }
    """)
    # 信号连接：点击保存按钮将当前预测保存到收藏
    save_btn.clicked.connect(host._on_save_current_prediction)
    btn_layout.addWidget(save_btn)

    # 加载选中预测按钮：从收藏列表中加载选中的预测结果
    load_btn = QPushButton("📂 加载选中预测")
    # 加载按钮样式 - 蓝色系（加载/读取操作）
    #   QPushButton {       常态样式
    #     background-color: #3498DB;  背景色：蓝色
    #     color: white;               文字颜色：白色
    #     border: none;               无边框
    #     border-radius: 6px;         圆角
    #     padding: 8px 20px;          内边距
    #     font-weight: bold;          粗体
    #     font-size: 15px;            字号
    #   }
    #   QPushButton:hover {  悬停样式
    #     background-color: #2980B9;  悬停背景加深
    #   }
    load_btn.setStyleSheet("""
        QPushButton { background-color: #3498DB; color: white; border: none; 
            border-radius: 6px; padding: 8px 20px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #2980B9; }
    """)
    # 信号连接：点击加载按钮加载选中的预测
    load_btn.clicked.connect(host._on_load_saved_prediction)
    btn_layout.addWidget(load_btn)

    # 查看详情按钮：查看选中收藏的详细信息
    detail_btn = QPushButton("📋 查看详情")
    # 查看详情按钮样式 - 紫色系（查看/信息操作）
    #   QPushButton {       常态样式
    #     background-color: #9B59B6;  背景色：紫色
    #     color: white;               文字颜色：白色
    #     border: none;               无边框
    #     border-radius: 6px;         圆角
    #     padding: 8px 20px;          内边距
    #     font-weight: bold;          粗体
    #     font-size: 15px;            字号
    #   }
    #   QPushButton:hover {  悬停样式
    #     background-color: #8E44AD;  悬停背景加深
    #   }
    detail_btn.setStyleSheet("""
        QPushButton { background-color: #9B59B6; color: white; border: none; 
            border-radius: 6px; padding: 8px 20px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #8E44AD; }
    """)
    # 信号连接：点击查看详情按钮显示选中收藏的详细信息
    detail_btn.clicked.connect(host._on_show_saved_prediction_detail)
    btn_layout.addWidget(detail_btn)

    # 对比预测按钮：选择多个收藏进行对比分析
    compare_btn = QPushButton("⚖️ 对比预测")
    # 对比预测按钮样式 - 橙色系（对比/分析操作）
    #   QPushButton {       常态样式
    #     background-color: #E67E22;  背景色：橙色
    #     color: white;               文字颜色：白色
    #     border: none;               无边框
    #     border-radius: 6px;         圆角
    #     padding: 8px 20px;          内边距
    #     font-weight: bold;          粗体
    #     font-size: 15px;            字号
    #   }
    #   QPushButton:hover {  悬停样式
    #     background-color: #D35400;  悬停背景加深
    #   }
    compare_btn.setStyleSheet("""
        QPushButton { background-color: #E67E22; color: white; border: none; 
            border-radius: 6px; padding: 8px 20px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #D35400; }
    """)
    # 信号连接：点击对比预测按钮对比选中的收藏
    compare_btn.clicked.connect(host._on_compare_saved_predictions)
    btn_layout.addWidget(compare_btn)

    # 删除按钮：删除选中的收藏项
    del_btn = QPushButton("🗑️ 删除")
    # 删除按钮样式 - 红色系（危险/删除操作）
    #   QPushButton {       常态样式
    #     background-color: #E74C3C;  背景色：红色
    #     color: white;               文字颜色：白色
    #     border: none;               无边框
    #     border-radius: 6px;         圆角
    #     padding: 8px 20px;          内边距
    #     font-weight: bold;          粗体
    #     font-size: 15px;            字号
    #   }
    #   QPushButton:hover {  悬停样式
    #     background-color: #C0392B;  悬停背景加深
    #   }
    del_btn.setStyleSheet("""
        QPushButton { background-color: #E74C3C; color: white; border: none; 
            border-radius: 6px; padding: 8px 20px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #C0392B; }
    """)
    # 信号连接：点击删除按钮删除选中的收藏项
    del_btn.clicked.connect(host._on_delete_saved_prediction)
    btn_layout.addWidget(del_btn)

    # 清空全部按钮：清除所有收藏记录
    clear_btn = QPushButton("🧹 清空全部")
    # 清空全部按钮样式 - 灰色系（中性/批量操作）
    #   QPushButton {       常态样式
    #     background-color: #95A5A6;  背景色：灰色
    #     color: white;               文字颜色：白色
    #     border: none;               无边框
    #     border-radius: 6px;         圆角
    #     padding: 8px 20px;          内边距
    #     font-weight: bold;          粗体
    #     font-size: 15px;            字号
    #   }
    #   QPushButton:hover {  悬停样式
    #     background-color: #7F8C8D;  悬停背景加深
    #   }
    clear_btn.setStyleSheet("""
        QPushButton { background-color: #95A5A6; color: white; border: none; 
            border-radius: 6px; padding: 8px 20px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #7F8C8D; }
    """)
    # 信号连接：点击清空全部按钮清除所有收藏
    clear_btn.clicked.connect(host._on_clear_saved_predictions)
    btn_layout.addWidget(clear_btn)

    btn_layout.addStretch()
    layout.addLayout(btn_layout)

    # 已保存预测列表
    list_title = QLabel("已保存的预测（双击查看详情，按住Ctrl/Shift多选可对比）")
    # 列表标题样式：14px字号，粗体，深灰文字，上边距5px
    list_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555; margin-top: 5px;")
    layout.addWidget(list_title)

    # 收藏列表控件：支持多选，双击查看详情
    host.favorites_list = QListWidget()
    host.favorites_list.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
    # 收藏列表样式 - 蓝色系（列表展示）
    #   QListWidget {             列表整体样式
    #     background-color: #FFFFFF;  背景白色
    #     border: 1px solid #DDDDDD;  边框：1px 浅灰
    #     border-radius: 6px;         圆角
    #   }
    #   QListWidget::item {      列表项样式
    #     padding: 10px;              内边距
    #     border-bottom: 1px solid #EEEEEE;  底部分隔线
    #     font-size: 15px;            字号
    #   }
    #   QListWidget::item:selected { 选中项样式
    #     background-color: #D6EAF8;    浅蓝背景
    #     color: #000000;               黑色文字
    #   }
    #   QListWidget::item:hover {  悬停项样式
    #     background-color: #F0F8FF;    极浅蓝背景
    #   }
    host.favorites_list.setStyleSheet("""
        QListWidget { background-color: #FFFFFF; border: 1px solid #DDDDDD; border-radius: 6px; }
        QListWidget::item { padding: 10px; border-bottom: 1px solid #EEEEEE; font-size: 15px; }
        QListWidget::item:selected { background-color: #D6EAF8; color: #000000; }
        QListWidget::item:hover { background-color: #F0F8FF; }
    """)
    # 信号连接：双击收藏项查看详细信息
    host.favorites_list.itemDoubleClicked.connect(host._on_show_saved_prediction_detail)
    # 列表 stretch=1：窗口变高时由列表吃掉多余空间，顶部按钮行保持原始高度
    layout.addWidget(host.favorites_list, 1)

    # 底部统计
    host.favorites_count_label = QLabel("共 0 条收藏")
    # 底部统计标签样式：13px字号，灰色文字，4px内边距
    host.favorites_count_label.setStyleSheet("color: #666666; font-size: 15px; padding: 4px;")
    layout.addWidget(host.favorites_count_label)

    return widget
