# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/prediction_history.py - 「预测记录」选项卡页面构建模块
===========================================================================
功能说明：
    构建主窗口「预测记录」选项卡的全部界面控件，并挂载到主窗口实例上。

TAB_INFO（供 TAB/__init__.py 自动发现）：
    title   = "预测记录"
    order   = 8（排在公告说明之前、回测分析等功能页之后）
    enabled = True

依赖：
    - UI/UI.py：QTableWidget/QHeaderView/QTableWidgetItem/QColor 等控件的唯一来源
    - TAB/widgets.py 的 PreserveColorDelegate：保留单元格自定义前景色
    - 标准库 json / os：预测记录 JSON 的读取与存在性判断
    - 无 lib/ 业务依赖；持久化写入统一走主窗口 _safe_write_json

数据流（JSON 持久化）：
    启动 → load_prediction_history 读取 host.prediction_history_file
    （系统v7.5/预测记录.json）→ 填充 host.prediction_history 列表
    → refresh_prediction_history_table 逐行写入 4 列表格；
    新增预测时主窗口把记录放进 host.prediction_history → save_prediction_history
    调用 _safe_write_json 落盘；清空时 clear 内存列表后刷新表格并再次落盘。
    写盘失败不会回滚内存状态（本页不负责重试）。

职责边界：
    - 本模块只负责界面构建（布局、控件、初始样式）
    - 事件处理函数保留在主窗口 LotteryPredictionWindow 中，通过信号连接
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import os as _os_boot  # 作用说明：提供 dirname/abspath/exists/join 等路径能力，用于向上定位项目根目录
import sys as _sys_boot  # 作用说明：提供 sys.path 访问，用于把项目根目录加入模块搜索路径以支持直接运行本文件

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

import json  # 作用说明：提供预测记录 JSON 的读取与解析，加载时校验顶层必须是 list
import os  # 作用说明：提供 os.path.exists 判断预测记录文件是否存在，避免对缺失文件直接 open 报错

from UI import (QColor, QFileDialog, QHBoxLayout, QHeaderView, QLabel, QMessageBox, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, Qt)  # 作用说明：统一获取本页所需的 Qt 控件（颜色/文件对话框/布局/表头/消息框/按钮/表格）及 Qt 枚举，避免直接 import PyQt6
from TAB.widgets import (PreserveColorDelegate)  # 作用说明：提供保留单元格自定义前景色的表格代理，防止刷新时颜色被默认代理覆盖



# ╔══════════════════════════════════════════════════════════════════╗
# ║  [预测记录：表格刷新、持久化、导出CSV、清空]
# ╚══════════════════════════════════════════════════════════════════╝

def refresh_prediction_history_table(host):
    """刷新预测记录表格（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        按 host.prediction_history 的顺序重建表格行，4 列依次为
        时间 / 算法 / 正码 / 特别码，并统一设置居中与前景色。

    参数:
        host: 主窗口实例。读取：
            host.prediction_history_table —— 目标 QTableWidget（4 列）；
            host.prediction_history       —— list[dict]，每条含
                timestamp / algorithm / numbers / special；
            host.is_dark_mode             —— bool，决定前景色。

    返回:
        无。

    调用方:
        install(host) 绑定为 host._refresh_prediction_history_table；
        主窗口在加载、保存、新增预测或清空记录后调用。

    副作用:
        1) setRowCount 重建全部行（不保留旧单元格对象，避免残留旧数据）；
        2) 深色模式前景色用 #CDD6F4（浅灰蓝，保证深底可读），
           浅色模式用 #000000；
        3) 正码按 2 位补零、以两个空格连接，特别码同样补零，
           与历史记录页的号码显示规范保持一致。

    异常:
        未挂载 prediction_history_table 时直接返回，不抛异常。
    """
    if not hasattr(host, 'prediction_history_table'):
        return
    fg_color = "#CDD6F4" if host.is_dark_mode else "#000000"
    host.prediction_history_table.setRowCount(len(host.prediction_history))
    for i, entry in enumerate(host.prediction_history):
        ts_item = QTableWidgetItem(entry.get('timestamp', ''))
        ts_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        ts_item.setForeground(QColor(fg_color))
        host.prediction_history_table.setItem(i, 0, ts_item)

        algo_item = QTableWidgetItem(entry.get('algorithm', ''))
        algo_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        algo_item.setForeground(QColor(fg_color))
        host.prediction_history_table.setItem(i, 1, algo_item)

        nums = entry.get('numbers', [])
        nums_str = '  '.join(str(n).zfill(2) for n in nums)
        nums_item = QTableWidgetItem(nums_str)
        nums_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        nums_item.setForeground(QColor(fg_color))
        host.prediction_history_table.setItem(i, 2, nums_item)

        sp_item = QTableWidgetItem(str(entry.get('special', 0)).zfill(2))
        sp_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        sp_item.setForeground(QColor(fg_color))
        host.prediction_history_table.setItem(i, 3, sp_item)


def load_prediction_history(host):
    """加载预测记录（预测记录.json → 内存 → 刷新表格）

    功能:
        从 host.prediction_history_file 读取 JSON，把顶层 list 装入
        host.prediction_history，随后调用 _refresh_prediction_history_table 刷新表格。

    参数:
        host: 主窗口实例。读取 host.prediction_history_file（JSON 文件路径），
            写入 host.prediction_history（list[dict]）。

    返回:
        无。

    注意:
        预测记录原先只存在内存，关闭程序即丢失；v0.0.18 起落盘持久化。
        读取 host.prediction_history_file；JSON 顶层必须是 list，否则保留原内存列表。
        任何读/解析异常都降级为空列表并打印，避免坏文件导致启动失败；本函数只读文件，不写盘。
    """
    # 读取 host.prediction_history_file；JSON 顶层必须是 list，否则保留原内存列表。
    # 任何读/解析异常都降级为空列表并打印，避免坏文件导致启动失败。
    try:
        if os.path.exists(host.prediction_history_file):
            with open(host.prediction_history_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, list):
                host.prediction_history = data
    except Exception as e:
        print("加载预测记录失败: " + str(e))
        host.prediction_history = []
    host._refresh_prediction_history_table()


def save_prediction_history(host):
    """保存预测记录到预测记录.json（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        把 host.prediction_history 整份内存列表交给主窗口 _safe_write_json，
        覆盖写入预测记录 JSON 文件。

    参数:
        host: 主窗口实例。读取 host.prediction_history 与
            host.prediction_history_file；写入文件由 _safe_write_json 负责。
    返回:
        无。
    调用方:
        install(host) 绑定为 host._save_prediction_history；
        主窗口在新增预测、清空记录、关闭窗口时调用。
    副作用:
        把整份内存列表覆盖写入 JSON（非增量追加）；未挂载 prediction_history
        时静默返回。写盘采用主窗口的原子/安全写入，失败不抛出、不破坏旧文件。
    """
    if not hasattr(host, 'prediction_history'):
        return
    host._safe_write_json(host.prediction_history_file, host.prediction_history)


def on_export_prediction_history_csv(host):
    """导出预测记录为CSV（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        把内存中的预测记录整理成「时间/算法/正码/特别码」四列，弹出保存
        对话框后交给主窗口 _safe_write_csv 写成 UTF-8 CSV 文件。

    参数:
        host: 主窗口实例。读取 host.prediction_history；使用
            host._safe_write_csv 写文件。

    返回:
        无。

    调用方:
        install(host) 绑定为 host._on_export_prediction_history_csv；
        「导出CSV」按钮 clicked 时触发。

    副作用:
        1) 弹出保存文件对话框，用户取消则不写文件；
        2) 写入 UTF-8 CSV，表头固定“时间,算法,正码,特别码”，
           正码用单空格连接、号码统一补零到两位；
        3) 成功弹信息框，失败提示由 _safe_write_csv 内部处理（本函数不重复弹窗）。
    """
    if not host.prediction_history:
        QMessageBox.information(host, "提示", "没有可导出的预测记录")
        return
    file_path, _ = QFileDialog.getSaveFileName(host, "导出预测记录", "prediction_history.csv", "CSV文件 (*.csv)")
    if file_path:
        # 【需求3-更新】使用安全写入方法
        rows = [["时间", "算法", "正码", "特别码"]]
        for entry in host.prediction_history:
            nums_str = ' '.join(str(n).zfill(2) for n in entry.get('numbers', []))
            rows.append([
                entry.get('timestamp', ''),
                entry.get('algorithm', ''),
                nums_str,
                str(entry.get('special', 0)).zfill(2)
            ])
        if host._safe_write_csv(file_path, rows):
            QMessageBox.information(host, "成功", "预测记录已导出")
        # 失败信息由_safe_write_csv内部处理


def on_clear_prediction_history(host):
    """清空预测记录（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        经用户确认后原地清空 host.prediction_history，刷新表格并立即落盘。

    参数:
        host: 主窗口实例。修改 host.prediction_history，并调用
            host._refresh_prediction_history_table / host._save_prediction_history。

    返回:
        无。

    调用方:
        install(host) 绑定为 host._on_clear_prediction_history；
        「清空记录」按钮 clicked 时触发。

    副作用:
        1) 先弹确认框（默认按钮 Yes/No），用户选择“否”时不做任何修改；
        2) 确认后原地 clear 内存列表（不替换对象，保持其它页面的引用有效）；
        3) 刷新表格、立即写盘，并在状态栏提示“预测记录已清空”。
    """
    if not host.prediction_history:
        QMessageBox.information(host, "提示", "预测记录已为空")
        return
    reply = QMessageBox.question(host, "确认", "确定清空所有预测记录吗？",
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    if reply == QMessageBox.StandardButton.Yes:
        host.prediction_history.clear()
        host._refresh_prediction_history_table()
        host._save_prediction_history()
        host.statusBar().showMessage("预测记录已清空")


def install(host):
    """安装「预测记录」选项卡：绑定 4 个事件回调后构建界面（v0.0.28 起页面自包含）

    功能:
        把刷新、保存、导出 CSV、清空四个模块函数包成 lambda 挂到 host 同名
        属性，再调用 build(host) 创建并返回页面控件。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。
    返回:
        QWidget: 构建完成的页面（build 的返回值），供 addTab 使用。
    调用方:
        TAB/__init__.py 的 iter_tab_pages() 自动发现本页后由主窗口调用。
    副作用:
        在 host 上写入 4 个 lambda：_refresh_prediction_history_table / _save_... /
        _on_export_prediction_history_csv / _on_clear_prediction_history；
        它们是本页模块函数与主窗口的桥接层，主窗口其它区域统一通过这些属性调用。
    """
    host._refresh_prediction_history_table = lambda: refresh_prediction_history_table(host)
    host._save_prediction_history = lambda: save_prediction_history(host)
    host._on_export_prediction_history_csv = lambda: on_export_prediction_history_csv(host)
    host._on_clear_prediction_history = lambda: on_clear_prediction_history(host)
    return build(host)


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "预测记录",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 8,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """构建「预测记录」选项卡页面

    功能:
        创建标题、4 列预测记录表格与底部按钮行（导出CSV、清空记录），
        恢复用户保存的列宽并接线。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。本函数写入：
            host.prediction_history_table —— QTableWidget（4 列，objectName 未设）；
        读取 host._prediction_col_widths（上次保存的列宽）、host.spacing、host.margin_*；
        并连接 host._on_export_prediction_history_csv /
        host._on_clear_prediction_history 与 host._save_ini_config。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        1) 创建表格并设置 4 列表头“时间/算法/正码/特别码”；
        2) 每列优先使用已保存列宽，非法/缺失时才用默认值；
        3) 安装 PreserveColorDelegate，让 refresh 时设置的前景色不被默认代理覆盖；
        4) 拖动列宽触发 sectionResized → _save_ini_config，把列宽写入 配置.ini；
        5) 本页不主动加载数据，表格内容由 load/refresh 之后填充。

    说明:
        表格 stretch=1 占据剩余高度；setStretchLastSection(True) 让最后一列
        吃掉右侧余量，避免表格右侧出现空白带。
    """
    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)

    # 页面标题：预测记录
    title = QLabel("预测记录")
    title.setObjectName("PanelTitle")
    layout.addWidget(title)

    # 预测记录表格：展示历史预测结果（时间、算法、正码、特别码）
    host.prediction_history_table = QTableWidget()
    host.prediction_history_table.setColumnCount(4)
    host.prediction_history_table.setHorizontalHeaderLabels(["时间", "算法", "正码", "特别码"])
    host.prediction_history_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    host.prediction_history_table.horizontalHeader().setStretchLastSection(True)

    # 应用保存的列宽
    # 默认列宽依据（仅首次/无保存值时使用）：
    #   时间：由字体度量反算（时间戳完整宽度 + 16px 单元格边距），保证 1180/1600 下不裁字；
    #   算法 100px：常见算法名 4~8 个汉字，留出左右边距；
    #   正码 200px：7 个两位号码、号码间两个空格，约 7×2 字宽 + 间隔；
    #   特别码：由 setStretchLastSection 自动占满剩余宽度，不回灌 INI 中上一窗口的绝对宽度。
    # 保存值优先于默认值，因此用户拖动过的列宽不会被这里覆盖；时间列不低于完整时间戳所需宽度。
    _time_need = host.prediction_history_table.fontMetrics().horizontalAdvance('2026-11-02 19:09:52') + 16
    default_pred_col_widths = [_time_need, 100, 200, 80]
    saved_pred_widths = getattr(host, '_prediction_col_widths', [])
    for i in range(4):
        if i == 3:
            # 末列是拉伸列，INI 里存的是上一窗口“占满后的绝对宽度”，
            # 1180 窗口回灌 1600 窗口的 1104px 会直接撑出横向滚动条。
            continue
        if i < len(saved_pred_widths) and saved_pred_widths[i] is not None and saved_pred_widths[i] > 0:
            _width = saved_pred_widths[i]
        else:
            _width = default_pred_col_widths[i]
        if i == 0:
            _width = max(_width, _time_need)
        host.prediction_history_table.setColumnWidth(i, _width)

    # 设置表格代理，保留单元格颜色（PreserveColorDelegate 保持自定义颜色不变）
    host.prediction_history_table.setItemDelegate(PreserveColorDelegate(host.prediction_history_table))
    layout.addWidget(host.prediction_history_table, 1)

    # 列宽变化时保存配置
    host.prediction_history_table.horizontalHeader().sectionResized.connect(lambda idx, old, new: host._save_ini_config())

    # 按钮布局：导出CSV 和 清空记录
    btn_layout = QHBoxLayout()
    # 导出CSV按钮：将预测记录导出为CSV文件
    export_csv_btn = QPushButton("导出CSV")
    # 信号连接：点击导出CSV按钮触发导出操作
    export_csv_btn.clicked.connect(host._on_export_prediction_history_csv)
    btn_layout.addWidget(export_csv_btn)

    # 清空记录按钮：清除所有预测历史记录
    clear_ph_btn = QPushButton("清空记录")
    # 信号连接：点击清空记录按钮触发清空操作
    clear_ph_btn.clicked.connect(host._on_clear_prediction_history)
    btn_layout.addWidget(clear_ph_btn)
    btn_layout.addStretch()
    layout.addLayout(btn_layout)

    return widget
