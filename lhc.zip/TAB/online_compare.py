# -*- coding: utf-8 -*-
"""
============================================================================
TAB/online_compare.py - 抓取后「在线 / 本地」三类差异提示与冲突手工处理
============================================================================
在架构中的位置：
    TAB/ 界面层。本模块**不声明 TAB_INFO**，不会被注册成第 15 个选项卡；
    由 TAB/history.py 在「在线开奖」页抓取完成后调用 refresh_online_compare()。

职责与硬约束：
    1. 抓取完成后调用 lib/online_source.compare_with_local()，把结果分成
       在线新增 / 冲突 / 仅本地有 三类，在页面上给出数量与明细入口；
    2. **默认只提示、不写入**：抓取后不修改本地历史、不写 JSON、不写 SQLite；
    3. 只有用户在明细弹窗中显式点「采用在线」并二次确认后，才覆盖本地同日记录；
       「保留本地」「跳过」都不会写盘；
    4. 本地写入沿既有主窗口入口 host._save_data()，失败时回滚内存并提示。
============================================================================
"""

import copy

from UI import (
    QAbstractItemView, QDialog, QHBoxLayout, QHeaderView, QLabel, QMessageBox,
    QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, Qt,
)
from lib.data_process import LotteryConfig
from lib.date_utils import normalize_date
from lib.online_source import compare_with_local
from lib.same_period import validate_numbers

COMPARE_HEADERS = ['类别', '期号', '日期', '在线号码', '本地号码', '新旧判定']
COMPARE_COL_WIDTHS = [80, 215, 115, 195, 195, 165]

KIND_LABELS = {
    'conflict': '冲突',
    'online_only': '在线新增',
    'local_only': '仅本地有',
}


def _format_numbers(numbers, special):
    """把一行号码格式化为「01 05 12 28 33 45 + 09」"""
    try:
        mains = ' '.join(str(int(n)).zfill(2) for n in numbers or [])
        return '%s + %s' % (mains, str(int(special)).zfill(2))
    except (TypeError, ValueError):
        return '—'


def _compare_text(result, kept):
    """根据对比结果与本次保留项生成页面状态文案（零差异也不静默）"""
    if not result or result.get('online', 0) <= 0:
        return '未获取到在线记录，无法与本地对比。'
    online_only = result.get('online_only_count', 0)
    conflicts = result.get('conflict_count', 0)
    local_only = result.get('local_only_count', 0)
    anomaly = int(result.get('local_anomaly_count', 0) or 0)
    kept_count = len(kept or ())
    anomaly_text = (' 另有本地异常 %d 条（日期或号码不合法，未参与对齐）。' % anomaly
                    if anomaly else '')
    if online_only == 0 and conflicts == 0 and local_only == 0:
        return '与本地一致，无新增期次。默认只提示，不写入本地。' + anomaly_text
    text = ('对比本地历史（只读）：在线新增 %d 期 · 冲突 %d 期 · 仅本地有 %d 期'
            '（本地共 %d 条）。默认只提示，不写入本地；需要写入请点「查看对比明细」逐项确认。'
            % (online_only, conflicts, local_only, result.get('local', 0)))
    text += anomaly_text
    if kept_count:
        text += ' 本次已保留本地 %d 项（未写盘）。' % kept_count
    return text


def refresh_online_compare(host, online_records):
    """抓取完成后刷新对比结果与页面提示（只读，绝不写本地）

    参数:
        host: 主窗口实例；
        online_records (list[dict]): 本次抓取到的在线记录。

    返回:
        dict: compare_with_local 的返回结果。
    """
    result = compare_with_local(online_records or [], getattr(host, 'historical_data', []) or [])
    host._online_compare = result
    host._online_compare_records = list(online_records or [])
    host._online_compare_kept = set()
    label = getattr(host, 'online_compare_label', None)
    button = getattr(host, 'online_compare_btn', None)
    if label is not None:
        label.setText(_compare_text(result, host._online_compare_kept))
        label.setVisible(True)
    if button is not None:
        total = result.get('online_only_count', 0) + result.get('conflict_count', 0) \
            + result.get('local_only_count', 0)
        button.setText('查看对比明细（%d）' % total if total else '查看对比明细')
        button.setEnabled(total > 0)
    return result


class OnlineCompareDialog(QDialog):
    """在线 / 本地对比明细弹窗：三类差异 + 冲突逐项手工处理入口"""

    def __init__(self, host, parent=None):
        super().__init__(parent or host)
        self._host = host
        self._kept = set(getattr(host, '_online_compare_kept', set()))
        self.setWindowTitle('在线 / 本地对比明细（只读提示，默认不写入）')
        self.resize(1000, 620)
        self.setModal(True)
        self._build_ui()
        self._reload_rows()

    def _build_ui(self):
        """构建摘要、说明、明细表与底部操作按钮"""
        dark = bool(getattr(self._host, 'is_dark_mode', False))
        tokens = {
            'bg': '#12161F' if dark else '#FFFFFF',
            'fg': '#E6E9F2' if dark else '#222233',
            'muted': '#AAB2C8' if dark else '#555555',
            'grid': '#6E7A94' if dark else '#8A8A8A',
            'header_bg': '#161C28' if dark else '#FFFFFF',
            'btn_bg': '#1B2233' if dark else '#E3F2FD',
            'btn_fg': '#8AB4F8' if dark else '#1565C0',
            'btn_border': '#2C3A5A' if dark else '#90CAF9',
        }
        self._tokens = tokens
        self.setStyleSheet('QDialog { background-color: %s; } QWidget { color: %s; font-size: 15px; }'
                           % (tokens['bg'], tokens['fg']))
        layout = QVBoxLayout(self)
        layout.setSpacing(6)
        layout.setContentsMargins(10, 10, 10, 10)

        self.summary_label = QLabel('')
        self.summary_label.setWordWrap(True)
        self.summary_label.setStyleSheet('color: %s; font-size: 15px; font-weight: bold;'
                                         % tokens['fg'])
        layout.addWidget(self.summary_label)

        note = QLabel('「采用在线」会用在线号码覆盖本地同日记录并写盘，需二次确认；'
                      '「保留本地」「跳过」都不会写盘。抓取完成时默认不写入任何一侧。')
        note.setWordWrap(True)
        note.setStyleSheet('color: %s; font-size: 15px;' % tokens['muted'])
        layout.addWidget(note)

        self.table = QTableWidget()
        self.table.setColumnCount(len(COMPARE_HEADERS))
        self.table.setHorizontalHeaderLabels(COMPARE_HEADERS)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        for index, width in enumerate(COMPARE_COL_WIDTHS):
            self.table.setColumnWidth(index, width)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setStyleSheet(
            'QTableWidget { background-color: %s; font-size: 15px; gridline-color: %s; }'
            'QHeaderView::section { background-color: %s; color: %s; border: 1px solid %s; '
            'font-size: 15px; font-weight: bold; }'
            % (tokens['bg'], tokens['grid'], tokens['header_bg'], tokens['fg'], tokens['grid']))
        self.table.itemSelectionChanged.connect(self._update_actions)
        layout.addWidget(self.table, 1)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        self.info_label = QLabel('请选择一条「冲突」记录后再操作。')
        self.info_label.setStyleSheet('color: %s; font-size: 15px;' % tokens['muted'])
        buttons.addWidget(self.info_label)
        buttons.addStretch()
        for text, handler, name, width in (
                ('采用在线（写入本地）', self._on_apply_online, 'btnApply', 170),
                ('保留本地（不写入）', self._on_keep_local, 'btnKeep', 160),
                ('跳过', self._on_skip, 'btnSkip', 80),
                ('关闭', self.reject, 'btnClose', 80)):
            button = QPushButton(text)
            button.setObjectName(name)
            button.setMinimumSize(width, 30)
            button.setStyleSheet(
                'QPushButton { background-color: %s; color: %s; border: 1px solid %s; '
                'border-radius: 6px; font-size: 15px; font-weight: bold; padding: 2px 6px; }'
                % (tokens['btn_bg'], tokens['btn_fg'], tokens['btn_border']))
            button.clicked.connect(handler)
            buttons.addWidget(button)
        layout.addLayout(buttons)
        self._apply_btn = self.findChild(QPushButton, 'btnApply')
        self._keep_btn = self.findChild(QPushButton, 'btnKeep')
        self._skip_btn = self.findChild(QPushButton, 'btnSkip')

    def _build_items(self):
        """按冲突 → 在线新增 → 仅本地有排列明细项"""
        result = getattr(self._host, '_online_compare', {}) or {}
        items = []
        for item in result.get('conflicts', []):
            if item.get('date') in self._kept:
                continue
            items.append(('conflict', item))
        for item in result.get('online_only', []):
            items.append(('online_only', item))
        for item in result.get('local_only', []):
            items.append(('local_only', item))
        return items

    def _reload_rows(self):
        """重建明细表并更新摘要文案"""
        result = getattr(self._host, '_online_compare', {}) or {}
        items = self._build_items()
        self.table.setUpdatesEnabled(False)
        try:
            self.table.setRowCount(len(items))
            for row_index, (kind, item) in enumerate(items):
                if kind == 'conflict':
                    period = '在线 %s / 本地 #%s' % (item.get('online_period') or '—',
                                                   item.get('local_period') or '—')
                    online_text = _format_numbers(item.get('online_numbers'), item.get('online_special'))
                    local_text = _format_numbers(item.get('local_numbers'), item.get('local_special'))
                    newer = '同日（仅号码不同）'
                elif kind == 'online_only':
                    period = str(item.get('online_period') or '—')
                    online_text = _format_numbers(item.get('online_numbers'), item.get('online_special'))
                    local_text = '—'
                    newer = '在线较新（晚于本地最新）' if item.get('newer') else '在线补录（早于本地最新）'
                else:
                    period = '#%s' % (item.get('local_period') or '—')
                    online_text = '—'
                    local_text = _format_numbers(item.get('local_numbers'), item.get('local_special'))
                    newer = '仅本地有'
                values = [KIND_LABELS[kind], period, item.get('date') or '', online_text,
                          local_text, newer]
                for column, value in enumerate(values):
                    cell = QTableWidgetItem(value)
                    if column == 0:
                        cell.setData(Qt.ItemDataRole.UserRole, (kind, item))
                    self.table.setItem(row_index, column, cell)
        finally:
            self.table.setUpdatesEnabled(True)
        self.summary_label.setText(
            '在线新增 %d 期 · 冲突 %d 期 · 仅本地有 %d 期（本地共 %d 条）；'
            '本次已保留本地 %d 项。'
            % (result.get('online_only_count', 0), result.get('conflict_count', 0),
               result.get('local_only_count', 0), result.get('local', 0), len(self._kept)))
        self._update_actions()

    def _selected(self):
        """返回当前选中行的 (kind, item)，未选中返回 (None, None)"""
        indexes = self.table.selectedIndexes()
        if not indexes:
            return None, None
        cell = self.table.item(indexes[0].row(), 0)
        if cell is None:
            return None, None
        payload = cell.data(Qt.ItemDataRole.UserRole)
        if not payload:
            return None, None
        return payload[0], payload[1]

    def _update_actions(self):
        """只有选中「冲突」时才启用采用在线/保留本地"""
        kind, item = self._selected()
        is_conflict = kind == 'conflict'
        self._apply_btn.setEnabled(is_conflict)
        self._keep_btn.setEnabled(is_conflict)
        self._skip_btn.setEnabled(bool(item))
        if is_conflict:
            self.info_label.setText('将把 %s 的本地号码替换为在线号码（写盘前会二次确认）。'
                                    % (item.get('date') or ''))
        else:
            self.info_label.setText('请选择一条「冲突」记录后再操作。'
                                    '在线新增/仅本地有默认不写入。')

    def _on_apply_online(self):
        """用户显式确认后，用在线号码覆盖本地同日记录并写盘"""
        kind, item = self._selected()
        if kind != 'conflict':
            return
        answer = QMessageBox.question(
            self, '确认写入本地',
            '将用在线号码覆盖本地 %s（本地第 %s 期）的正码与特别码，并立即写盘。\n'
            '在线号码：%s\n本地号码：%s\n\n确定执行吗？'
            % (item.get('date'), item.get('local_period'),
               _format_numbers(item.get('online_numbers'), item.get('online_special')),
               _format_numbers(item.get('local_numbers'), item.get('local_special'))),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        if apply_online_conflict(self._host, item):
            self._reload_host_state()
            self._reload_rows()

    def _on_keep_local(self):
        """保留本地：只记录本次决定，不写盘"""
        kind, item = self._selected()
        if kind != 'conflict':
            return
        self._kept.add(item.get('date'))
        self._host._online_compare_kept = set(self._kept)
        self._reload_rows()

    def _on_skip(self):
        """跳过当前项，选中下一行；不写盘"""
        indexes = self.table.selectedIndexes()
        if not indexes:
            return
        next_row = indexes[0].row() + 1
        if next_row < self.table.rowCount():
            self.table.selectRow(next_row)

    def _reload_host_state(self):
        """重新计算对比结果并刷新主页面提示（本地已被用户确认修改）"""
        result = compare_with_local(getattr(self._host, '_online_compare_records', []) or [],
                                    getattr(self._host, 'historical_data', []) or [])
        self._host._online_compare = result
        label = getattr(self._host, 'online_compare_label', None)
        if label is not None:
            kept = getattr(self._host, '_online_compare_kept', set())
            label.setText(_compare_text(result, kept))
        button = getattr(self._host, 'online_compare_btn', None)
        if button is not None:
            total = result.get('online_only_count', 0) + result.get('conflict_count', 0) \
                + result.get('local_only_count', 0)
            button.setText('查看对比明细（%d）' % total if total else '查看对比明细')
            button.setEnabled(total > 0)


def open_online_compare_dialog(host):
    """打开对比明细弹窗（模态）；无对比结果时给出提示，不写盘"""
    if not getattr(host, '_online_compare', None):
        QMessageBox.information(host, '暂无对比结果', '请先在「在线列表」完成一次抓取。')
        return None
    dialog = OnlineCompareDialog(host)
    dialog.exec()
    return dialog


def apply_online_conflict(host, item):
    """用在线号码覆盖本地同日记录（唯一写盘点，需调用方已获得用户确认）

    参数:
        host: 主窗口实例；
        item (dict): compare_with_local 的冲突项。

    返回:
        bool: True=写盘成功；False=本地无对应记录或写盘失败（内存已回滚）。
    """
    date_text = str(item.get('date') or '')
    try:
        online_numbers, online_special = validate_numbers(
            item.get('online_numbers'), item.get('online_special'))
    except (TypeError, ValueError) as exc:
        QMessageBox.warning(
            host, '号码不合法',
            '在线记录未通过校验：%s。已拒绝写入，本地未做任何修改。' % exc)
        return False

    target = None
    for record in getattr(host, 'historical_data', []) or []:
        try:
            record_date = normalize_date(record.get('date'))
        except (TypeError, ValueError):
            record_date = ''
        if record_date == date_text:
            target = record
            break
    if target is None:
        QMessageBox.warning(host, '写入失败', '本地历史中找不到 %s 的记录，未做任何修改。' % date_text)
        return False

    backup = {}
    for key in ('numbers', 'special', 'all_numbers', 'zodiacs', 'special_zodiac'):
        backup[key] = copy.deepcopy(target[key]) if key in target else _MISSING

    target['numbers'] = list(online_numbers)
    target['special'] = online_special
    target['all_numbers'] = list(online_numbers) + [online_special]
    target.pop('zodiacs', None)
    target.pop('special_zodiac', None)
    LotteryConfig.attach_zodiac_snapshot(target, getattr(host, 'zodiac_binding', {}) or {})

    if not host._save_data():
        for key, value in backup.items():
            if value is _MISSING:
                target.pop(key, None)
            else:
                target[key] = value
        QMessageBox.warning(host, '写入失败', '本地数据保存失败，已回滚内存修改。')
        return False

    try:
        host._update_history_table()
    except (AttributeError, RuntimeError):
        pass
    QMessageBox.information(host, '已写入本地',
                            '已用在线号码更新本地 %s 的记录，并完成写盘。' % date_text)
    return True


class _Missing:
    """哨兵：区分「字段原本不存在」与「字段值为 None」"""

    def __bool__(self):
        return False


_MISSING = _Missing()
