# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/element.py - 「数字与五行」选项卡页面构建模块
===========================================================================
模块职责：
    1. 构建「数字与五行」选项卡的全部界面控件（标题行、五行分组条、粘贴输入区、
       下部 49 宫格号码面板、详情标签），并把控件与事件回调挂到 host；
    2. 维护号码→五行绑定（host.zodiac_elements），提供“选中一行 → 粘贴号码 →
       应用”的写入流程，写入后即时保存并全局生效；
    3. 与「数字与生肖」页共享同一份 host.zodiac_elements / zodiac_binding，
       本页只修改五行，不重新生成生肖绑定。

依赖：
    - UI/UI.py 统一导出的 Qt 控件（禁止在本页直接 import PyQt6）
    - lib/data_process.LotteryConfig：
        NUMBER_ELEMENTS   号码→五行默认表（业务给定配置，无法用简单公式推导）
        get_number_color  号码波色（详情文字里显示红/蓝/绿）
    - lib/data_process.DataUtils.parse_numbers_text()：粘贴文本统一解析
      （统计用途：dedupe=False, limit_range=False，保留重复与越界值）
    - TAB/widgets.py：ElementGridPanel（49 宫格号码面板）与 v0.0.36 角控件共用逻辑
      （CORNER_* 常量、make_corner_* 工厂），本页只调用、不重复定义规格
    - host（LotteryPredictionWindow）提供 _persist_bindings / _save_ini_config /
      _apply_splitter_sizes / _show_panel_settings_dialog 等跨页基础设施

五行映射与颜色主题：
    五行顺序固定为 金 → 木 → 水 → 火 → 土（ELEMENT_LIST / ELEMENT_LIST_LOCAL）。
    主色：金 #F1C40F、木 #27AE60、水 #3498DB、火 #E74C3C、土 #E67E22；
    选中行背景：金 #FFF8E1、木 #E8F5E9、水 #E3F2FD、火 #FFEBEE、土 #FFF3E0。
    选中态用“浅色底 + 五行色文字/加粗边框”，避免实色底把文字冲淡看不清。
    默认绑定来自 LotteryConfig.NUMBER_ELEMENTS（1~49 逐个查表，非周期规则）。

数据流：
    host.zodiac_elements（dict[int, str]，1~49 → 五行）
        → refresh_stats() 左侧五行分组条（每行号码 + 数量）
        → ElementGridPanel.update_all_elements() 下部号码面板（号码下方五行字）
    点击分组条 → on_row_selected() 设置 host._element_target
    粘贴数字 → on_input_apply() 解析并写入 zodiac_elements
        → LotteryConfig.NUMBER_ELEMENTS.update() → host._persist_bindings() 落盘
    host.zodiac_binding 只用于详情文字里的生肖字段，本页不修改它。

在架构中的位置：
    位于 TAB/ 选项卡界面层，属于“界面构建 + 页面事件”自包含模块（v0.0.28 起）；
    不导入任何重型计算库，只读取 lib 的常量与配置表。

导出对象：
    TAB_INFO                 选项卡元信息（title / order / enabled）
    install(host)            唯一安装入口：挂事件回调 + 构建页面
    build(host)              仅构建页面（由 install 内部调用）
    refresh_stats / update_detail / on_*   本页事件处理函数（host 由闭包传入）

功能说明：
    构建主窗口「数字与五行」选项卡的全部界面控件，并挂载到主窗口实例上。

页面布局（v0.0.28）：
    顶部一行：标题 +（居中留距的）数字 px / 文字 px / 尺寸 +「应用」+「恢复默认」+「保存设置」
    上部左侧：五行分组条（金 / 木 / 水 / 火 / 土 各一行，显示已分配数字与数量）
    上部右侧：粘贴输入框（高度 78px）+「应用」按钮（应用即写入、自动保存、全局即时生效）
    下部：号码面板（按钮上方数字、下方五行文字，7×7 共 49 个号码）+ 可拖动竖向分隔条

职责边界（v0.0.28 起本页自包含）：
    - 本模块负责界面构建（布局、控件、初始样式）与全部本页事件（模块函数 + install 绑定）
    - 主窗口 LotteryPredictionWindow 的同名方法仅作兼容转发
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import os as _os_boot  # 作用说明：仅在直接运行本文件调试时，向上探测含 run.py 的项目根目录
import sys as _sys_boot  # 作用说明：把探测到的项目根插入模块搜索路径，保证直接运行时可 import UI/TAB

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QHBoxLayout, QLabel, QMessageBox, QPushButton, QScrollArea, QSizePolicy, QSpinBox, QSplitter, QTextEdit, QVBoxLayout, QWidget, Qt)  # 作用说明：统一从 UI/UI.py 取 Qt 控件与枚举，本页不直接 import PyQt6
from lib.data_process import LotteryConfig, DataUtils  # 作用说明：LotteryConfig 提供号码→五行默认表与波色，DataUtils 统一解析粘贴的数字文本
from TAB.widgets import (CORNER_SECTION_GAP, ElementGridPanel, add_corner_widget,  # 作用说明：复用 49 宫格号码面板与 v0.0.36 角控件统一规格（常量/工厂/尺寸弹窗），本页不重复定义
                         make_corner_container, make_corner_label, make_corner_size_button,
                         open_panel_size_dialog, style_corner_spin)

ELEMENT_LIST_LOCAL = ["金", "木", "水", "火", "土"]


def refresh_stats(host):
    """刷新五行分组条：更新每行显示的数字与数量，并同步下部号码面板

    功能:
        按 host.zodiac_elements 把 1~49 归类到五行，重写每行按钮内的
        “五行字 / 号码 / 数量”三个 QLabel，并刷新下部 49 宫格面板。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备
            zodiac_elements、element_row_buttons、_element_panel_size。

    返回:
        None

    副作用:
        原地修改各行按钮内部 QLabel 的文本与样式，更新按钮最小高度与 ToolTip；
        若下部 element_grid_panel 已创建，则全量刷新号码面板并重设字号。

    说明:
        为什么按钮内放三个 QLabel：QPushButton 不支持富文本，直接 setText
        会把 HTML/富文本标签原样显示；拆成独立 QLabel 才能分别控制五行色、
        号码字号与数量字号。行高下限 36px 与标题行角控件（40px）接近，
        保证分组条在上部编辑区压缩时仍可点击。
    """
    if not hasattr(host, 'element_row_buttons') or not host.element_row_buttons:
        return

    element_nums = {e: [] for e in ELEMENT_LIST_LOCAL}
    for num in range(1, 50):
        elem = host.zodiac_elements.get(num, "")
        if elem in element_nums:
            element_nums[elem].append(num)

    # 字号/行高取自标题行的 px 控件（数字 px、文字 px、尺寸）
    num_px = int(host._element_panel_size.get('btn_font', 16))
    text_px = int(host._element_panel_size.get('label_font', 15))
    row_h = max(36, int(host._element_panel_size.get('height', 38)))
    selected = getattr(host, '_element_target', None)
    element_colors = {
        "金": "#F1C40F", "木": "#27AE60", "水": "#3498DB", "火": "#E74C3C", "土": "#E67E22"
    }

    for e in ELEMENT_LIST_LOCAL:
        btn = host.element_row_buttons.get(e)
        if btn is None:
            continue
        nums = element_nums[e]
        nums_text = " ".join(str(n).zfill(2) for n in nums) if nums else "（未分配）"
        color = element_colors.get(e, "#555555")
        # 选中行使用浅色底 + 五行色文字（避免实色底把文字冲淡看不清）
        text_color = color
        nums_color = color if e == selected else "#333333"
        # 三块文本用独立 QLabel 渲染（QPushButton 不支持富文本，直接 setText 会显示标签原文）
        elem_label = getattr(btn, '_elem_label', None)
        nums_label = getattr(btn, '_nums_label', None)
        count_label = getattr(btn, '_count_label', None)
        if elem_label is None or nums_label is None or count_label is None:
            continue
        elem_label.setText(e)
        elem_label.setStyleSheet(
            "QLabel { background: transparent; /* 背景透明：叠在按钮底色上 */"
            "font-size:" + str(text_px)
            + "px; /* 字号：取标题行「文字 px」 */ font-weight:bold; /* 加粗：五行字更醒目 */"
            "color:" + text_color + "; /* 文字色：五行主色，选中与否都保持可读 */ }")
        nums_label.setText(nums_text)
        nums_label.setStyleSheet(
            "QLabel { background: transparent; /* 背景透明：不遮挡按钮选中底色 */"
            "font-size:" + str(num_px)
            + "px; /* 字号：取标题行「数字 px」 */ font-weight:bold; /* 加粗：号码是主要信息 */"
            "color:" + nums_color + "; /* 号码色：选中行用五行色，未选中用深灰 */ }")
        count_label.setText("共" + str(len(nums)) + "个")
        count_label.setStyleSheet(
            "QLabel { background: transparent; /* 背景透明：叠在按钮底色上 */"
            "font-size:15px; /* 字号：15px，全局最小可读字号 */ color:"
            + ("#666666" if e == selected else "#999999") + "; /* 数量色：选中行深灰，未选中更浅 */ }")
        btn.setMinimumHeight(row_h)
        btn.setToolTip("「" + e + "」共 " + str(len(nums)) + " 个数字\n" + nums_text)

    # 下部号码面板：同步全部号码的五行文字与字号
    if getattr(host, 'element_grid_panel', None):
        host.element_grid_panel.update_all_elements(host.zodiac_elements)
        host.element_grid_panel.set_font_size(btn_font=num_px, label_font=text_px)


def on_row_selected(host, element):
    """五行分组条点击：记录当前写入目标（五行互斥选中）

    功能:
        把被点击的五行设为“下一个粘贴目标”，并保证同时只有一行处于选中态。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        element (str): 被点击的五行名称（金/木/水/火/土）。

    返回:
        None

    副作用:
        覆盖 host._element_target；遍历 element_row_buttons 调 setChecked()
        （按钮是可 checkable 的，Qt 不会自动互斥，必须手动撤销其他行）；
        重新渲染分组条（选中行文字色变化）；更新粘贴区状态标签。

    说明:
        先 setChecked 再 refresh_stats 的顺序不能反：refresh_stats 依据
        _element_target 决定号码文字是否用五行色，提前设置才能一次渲染到位。
    """
    host._element_target = element
    if hasattr(host, 'element_row_buttons'):
        for name, btn in host.element_row_buttons.items():
            btn.setChecked(name == element)
        # 富文本颜色随选中状态变化，重新渲染一次
        refresh_stats(host)
    if getattr(host, 'element_input_status', None):
        host.element_input_status.setText(
            "当前写入目标：" + element + "　（粘贴数字后点「应用」即写入并自动保存）"
        )


def on_input_apply(host):
    """解析输入框数字并写入当前选中的五行：点一次即应用、保存、全局生效

    功能:
        解析粘贴框文本（任意分隔符），过滤到 01~49，把有效号码全部改绑到
        host._element_target 指定的五行。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None

    副作用:
        覆盖 host.zodiac_elements 中相关号码的五行；更新类属性
        LotteryConfig.NUMBER_ELEMENTS；刷新分组条与详情；写 JSON/INI；
        在 element_input_status 上显示校验失败原因或成功数量。

    说明:
        校验顺序（目标 → 是否有数字 → 是否全越界）是为了给出可操作的提示：
        没选目标时先提示点击左侧，粘贴为空时提示格式，全部越界时提示范围，
        避免用户反复修改输入却不知道失败原因。成功提示只回显数量而非号码列表，
        防止长文本把状态栏撑成多行。
    """
    if not getattr(host, 'element_input_edit', None):
        return
    raw_nums = DataUtils.parse_numbers_text(
        host.element_input_edit.toPlainText(), dedupe=False, limit_range=False)
    nums = sorted({n for n in raw_nums if 1 <= n <= 49})
    target = getattr(host, '_element_target', None)

    if not target:
        host.element_input_status.setText("请先在左侧点击一行，选中要写入的五行")
        return
    if not raw_nums:
        host.element_input_status.setText("未识别到数字：请粘贴 01-49 范围内的号码")
        return
    if not nums:
        host.element_input_status.setText("识别到 " + str(len(raw_nums)) + " 个数字，但全部超出 01-49 范围")
        return

    for num in nums:
        host.zodiac_elements[num] = target

    # 同步全局常量 → 刷新分组条与详情 → 静默保存（其他页面立即生效，无需重启）
    LotteryConfig.NUMBER_ELEMENTS.update(host.zodiac_elements)
    refresh_stats(host)
    update_detail(host, nums[0])
    host._persist_bindings()
    host.element_input_status.setText(
        "已把 " + str(len(nums)) + " 个数字写入「" + target + "」，已自动保存并全局生效"
    )


def update_detail(host, num):
    """更新五行详情标签

    功能:
        把单个号码的五行、生肖与波色拼成一行文字写入详情标签。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        num (int): 1~49 的号码；越界时各查表返回空串/兜底配色，不抛异常。

    返回:
        None

    副作用:
        覆盖 host.element_detail_label 的文本，不触发表格/面板刷新，也不写盘。

    说明:
        与生肖页详情保持相同字段顺序，只是把“生肖/五行”对调，便于两页对照；
        颜色名按色值反推（#FF0000 红 / #0000FF 蓝 / 其余绿），因为 lib 只给 RGB。
    """
    element = host.zodiac_elements.get(num, "")
    zodiac = host.zodiac_binding.get(num, "")
    colors = LotteryConfig.get_number_color(num)
    color_name = "红色" if colors['text'] == '#FF0000' else ("蓝色" if colors['text'] == '#0000FF' else "绿色")
    host.element_detail_label.setText(
        "数字 " + str(num).zfill(2) + " ｜ 五行：" + element + " ｜ 生肖：" + zodiac + " ｜ 颜色：" + color_name
    )


def on_save(host):
    """手动保存五行绑定到 INI 与 JSON

    功能:
        把 host.zodiac_elements 同步进 LotteryConfig.NUMBER_ELEMENTS 后落盘。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None

    副作用:
        更新类属性 LotteryConfig.NUMBER_ELEMENTS；写 JSON/INI；
        成功/失败分别弹 information / warning 消息框。

    异常:
        保存过程中的异常在函数内捕获并转成 warning 弹窗，不向外抛出。

    说明:
        写入流程（on_input_apply）本身已经自动保存，本按钮用于用户确认或
        在其他代码改动内存绑定后补一次持久化，因此同样需要明确的成功反馈。
    """
    try:
        LotteryConfig.NUMBER_ELEMENTS.update(host.zodiac_elements)
        host._persist_bindings()
        QMessageBox.information(host, "成功", "五行绑定已保存并全局生效")
    except Exception as e:
        QMessageBox.warning(host, "错误", "保存五行绑定时出错:\n" + str(e))


def on_reset(host):
    """恢复默认五行绑定

    功能:
        二次确认后，把号码→五行绑定复制一份全局表（该表可能已被写入流程改写，
        见下方 TODO）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None

    副作用:
        仅当用户点“是”时：覆盖 host.zodiac_elements；刷新分组条与详情；
        同步刷新生肖页的号码面板；写 JSON/INI。点“否”时无任何修改。

    说明:
        deepcopy 是为避免把类属性 NUMBER_ELEMENTS 的引用直接赋给 host，
        否则后续原地修改会污染所有实例共享的默认表。这里只重置五行，
        不重置生肖绑定——与生肖页“恢复默认”会连带重置五行的语义互补。
        恢复时从 LotteryConfig.DEFAULT_NUMBER_ELEMENTS 出厂只读副本拷贝。
    """
    reply = QMessageBox.question(host, "确认", "确定恢复默认的五行绑定吗？",
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    if reply == QMessageBox.StandardButton.Yes:
        import copy  # 作用说明：深拷贝出厂五行表，避免把类属性引用直接赋给 host 后被原地改动污染
        # 从出厂只读副本恢复，避免拿到被 on_input_apply 原地改写后的全局表
        host.zodiac_elements = copy.deepcopy(LotteryConfig.DEFAULT_NUMBER_ELEMENTS)
        refresh_stats(host)
        host.element_detail_label.setText("已恢复默认五行绑定")
        # 同步更新生肖标签页
        if getattr(host, 'zodiac_panel', None):
            host.zodiac_panel.update_all_zodiacs(host.zodiac_binding)
        host._persist_bindings()


def on_num_font_changed(host, size):
    """五行分组条数字字体大小变化处理

    功能:
        记录分组条号码字号并立即刷新分组条与下部号码面板。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        size (int): 新字号（px），控件范围 15~150。

    返回:
        None

    副作用:
        写 host._element_panel_size['btn_font']；保存 INI；调用 refresh_stats()
        重排分组条并同步 ElementGridPanel 字号；更新
        host._area_font_scales['element_panel'] = size / 16.0。

    说明:
        缩放比以 16px 为基准，与主窗口“面板尺寸设置”对话框的计算方式一致；
        refresh_stats 同时负责把新字号传给下部宫格面板，因此这里无需单独调用
        set_font_size，避免两处字号来源不一致。
    """
    host._element_panel_size['btn_font'] = size
    host._save_ini_config()
    refresh_stats(host)
    host._area_font_scales['element_panel'] = size / 16.0


def on_text_font_changed(host, size):
    """五行分组条五行文字字体大小变化处理

    功能:
        记录“金/木/水/火/土”文字字号并立即刷新分组条与下部号码面板。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        size (int): 新字号（px），控件范围 15~150。

    返回:
        None

    副作用:
        写 host._element_panel_size['label_font']；保存 INI；调用 refresh_stats()
        重设三个 QLabel 的字号及宫格面板的 label_font。

    说明:
        文字字号只影响五行字，不影响号码字号；下部面板通过 refresh_stats 统一
        读取 btn_font / label_font，避免只改一处造成上下字号不同步。
    """
    host._element_panel_size['label_font'] = size
    host._save_ini_config()
    refresh_stats(host)


def show_panel_settings_dialog(host):
    """打开「五行面板尺寸」设置弹窗

    功能:
        由主窗口 `_show_panel_settings_dialog` 的 'element' 分支迁入。弹窗骨架
        使用 TAB.widgets.open_panel_size_dialog；应用后联动五行分组条行高与
        下部号码面板字号。

    参数:
        host: 主窗口实例。

    返回:
        None

    副作用:
        写 host._element_panel_size 的 width/height、host._area_font_scales
        ['element_panel']，调用本页 refresh_stats(host) 重排分组条，并同步
        elem_num_font_spin / elem_text_font_spin。

    降级:
        控件缺失时通过 hasattr 跳过；element_grid_panel 为空不绘制。
    """
    current = getattr(host, '_element_panel_size',
                      {'width': 80, 'height': 60, 'btn_font': 20, 'label_font': 20})

    def _apply(values):
        """把尺寸弹窗返回的宽高写回配置并联动刷新界面

        功能:
            将「五行面板尺寸」对话框确认的 width/height 写入
            host._element_panel_size，并立即应用到下方 49 宫格面板、
            分组条行高与两个字号 spinbox。

        参数:
            values (dict): 对话框回调值，含 'width'、'height'（int，像素）。

        返回:
            无。

        注意:
            仅在用户点确认时由 open_panel_size_dialog 回调触发；会改写
            host._element_panel_size 与 host._area_font_scales，并通过
            refresh_stats(host) 重排分组条；控件缺失时用 hasattr 跳过。
        """
        host._element_panel_size['width'] = values['width']
        host._element_panel_size['height'] = values['height']
        if hasattr(host, 'element_grid_panel') and host.element_grid_panel:
            host.element_grid_panel.set_font_size(
                width=values['width'], height=values['height'],
                btn_font=host._element_panel_size.get('btn_font', 20),
                label_font=host._element_panel_size.get('label_font', 20))
        # 分组条行高随高度联动：refresh_stats 内部会读取最新尺寸
        if hasattr(host, 'element_row_buttons'):
            refresh_stats(host)
        if hasattr(host, 'elem_num_font_spin'):
            host.elem_num_font_spin.blockSignals(True)
            host.elem_num_font_spin.setValue(host._element_panel_size.get('btn_font', 20))
            host.elem_num_font_spin.blockSignals(False)
        if hasattr(host, 'elem_text_font_spin'):
            host.elem_text_font_spin.blockSignals(True)
            host.elem_text_font_spin.setValue(host._element_panel_size.get('label_font', 20))
            host.elem_text_font_spin.blockSignals(False)
        host._area_font_scales['element_panel'] = host._element_panel_size.get('btn_font', 16) / 16.0

    open_panel_size_dialog(host, "五行面板尺寸", current, _apply)


def install(host):
    """安装「数字与五行」选项卡：先在 host 上挂本页事件，再构建界面（v0.0.28）

    功能:
        本页唯一安装入口。先把模块级事件处理函数以 lambda 挂到 host 私有属性，
        再调用 build(host) 创建并返回页面。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        QWidget: 构建完成的页面。

    副作用:
        在 host 上挂 _refresh_element_stats、_on_element_row_selected、
        _on_element_input_apply、_on_save_elements、_on_reset_elements、
        _on_elem_num_font_changed、_on_elem_text_font_changed 共 7 个回调；
        build() 还会创建本页控件。

    说明:
        必须先挂回调再 build：标题行按钮与字号框在构建时立即 connect 这些属性，
        业务逻辑留在模块内，主窗口只保留跨页共用的 _persist_bindings 等基础设施。
    """
    host._refresh_element_stats = lambda: refresh_stats(host)
    host._on_element_row_selected = lambda element: on_row_selected(host, element)
    host._on_element_input_apply = lambda: on_input_apply(host)
    host._on_save_elements = lambda: on_save(host)
    host._on_reset_elements = lambda: on_reset(host)
    host._on_elem_num_font_changed = lambda size: on_num_font_changed(host, size)
    host._on_elem_text_font_changed = lambda size: on_text_font_changed(host, size)
    return build(host)


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "数字与五行",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 11,  # 显示顺序，数字小的排前面
    "enabled": False,  # 三页合并：本页已由「号码属性表」替代，保留文件便于一键回滚
}

# 五行顺序与配色（左侧分组条使用）
ELEMENT_LIST = ["金", "木", "水", "火", "土"]
ELEMENT_COLORS = {
    "金": "#F1C40F", "木": "#27AE60", "水": "#3498DB", "火": "#E74C3C", "土": "#E67E22"
}
ELEMENT_BG = {
    "金": "#FFF8E1", "木": "#E8F5E9", "水": "#E3F2FD", "火": "#FFEBEE", "土": "#FFF3E0"
}


def _build_font_controls(host, layout):
    """构建右上角「数字 px / 文字 px / 尺寸」控件组（v0.0.36 统一规格）

    功能:
        在标题行最右侧放一组等高控件：数字字号框、文字字号框与「尺寸」按钮。
        数字框控制分组条里的号码字号，文字框控制五行字（金/木/水/火/土）字号。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。本函数在其上创建
            host.elem_num_font_spin 与 host.elem_text_font_spin 两个 QSpinBox；
            valueChanged 触发 install() 预先挂好的回调。
        layout (QHBoxLayout): 顶部标题行布局；控件组作为整体从右端加入。

    返回:
        None（控件通过 host 属性与 layout 生效）。

    副作用:
        创建 Qt 控件并挂到 host；初值读取 host._element_panel_size 的
        btn_font / label_font；改值时触发字体变更回调。

    说明:
        v0.0.36：改用 TAB/widgets.py 的统一规格——控件高 40px、组内间距 6px、
        数字组与文字组之间 12px、距右边缘 8px、字号 15px，四个页面完全一致。
        数字 px 控制分组条里的号码字号，文字 px 控制五行字（金木水火土）字号。
    """
    box, box_layout = make_corner_container()

    # 数字字号标签 + 输入框（蓝色主题）
    add_corner_widget(box_layout, make_corner_label("数字:", "#1565C0"))

    host.elem_num_font_spin = QSpinBox()
    host.elem_num_font_spin.setRange(15, 150)  # 下限 15px：与全局最小字号一致
    host.elem_num_font_spin.setValue(host._element_panel_size.get('btn_font', 20))  # 默认20px
    host.elem_num_font_spin.setSuffix(" px")
    host.elem_num_font_spin.setToolTip("调整五行分组条里号码的字体大小")
    style_corner_spin(host.elem_num_font_spin, "#90CAF9")
    host.elem_num_font_spin.valueChanged.connect(host._on_elem_num_font_changed)
    add_corner_widget(box_layout, host.elem_num_font_spin)

    box_layout.addSpacing(CORNER_SECTION_GAP)  # 数字组与文字组之间留 12px，避免拥挤

    # 文字字号标签 + 输入框（紫色主题）
    add_corner_widget(box_layout, make_corner_label("文字:", "#7B1FA2"))

    host.elem_text_font_spin = QSpinBox()
    host.elem_text_font_spin.setRange(15, 150)  # 下限 15px：与全局最小字号一致
    host.elem_text_font_spin.setValue(host._element_panel_size.get('label_font', 20))  # 默认20px
    host.elem_text_font_spin.setSuffix(" px")
    host.elem_text_font_spin.setToolTip("调整五行分组条里五行字（金/木/水/火/土）的字体大小")
    style_corner_spin(host.elem_text_font_spin, "#CE93D8")
    host.elem_text_font_spin.valueChanged.connect(host._on_elem_text_font_changed)
    add_corner_widget(box_layout, host.elem_text_font_spin)

    # 「尺寸」按钮：68×40，与同排标签/输入框同一水平基线
    add_corner_widget(box_layout, make_corner_size_button(
        lambda: show_panel_settings_dialog(host), "调整五行分组条尺寸设置"))

    layout.addWidget(box)


def _build_element_rows(host, layout):
    """构建左侧五行分组条

    功能:
        创建 金/木/水/火/土 五行可选中按钮，每行内部放三个 QLabel 承载
        “五行字 / 号码 / 数量”，并给出流程提示。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；按钮字典挂到
            host.element_row_buttons。
        layout (QVBoxLayout): 左侧列的垂直布局，按钮自上而下加入。

    返回:
        None

    副作用:
        在 host 上创建 element_row_buttons（dict[str, QPushButton]）；
        每个按钮的 clicked 信号连接到 host._on_element_row_selected；
        按钮内 QLabel 的尺寸/颜色由 refresh_stats() 后续渲染。

    说明:
        每行是一个 checkable 按钮，由 on_row_selected 手动实现互斥；
        按钮内 QLabel 设为 WA_TransparentForMouseEvents，让点击穿透到按钮，
        否则点在文字上不会触发 clicked。SizePolicy 的横向 Ignored 保证号码很长时
        只在按钮内部裁切，不把整页撑出横向滚动条。初始提示文字采用占位值，
        build() 末尾调用 refresh_stats() 后才会填入真实号码。
    """
    title = QLabel("五行分组（点击一行，选中要写入的五行）")
    # 分组标题样式：15px 粗体橙色，与页面主题一致
    title.setStyleSheet("font-size: 15px; font-weight: bold; color: #E67E22; padding: 2px 4px;")
    layout.addWidget(title)

    host.element_row_buttons = {}
    for elem in ELEMENT_LIST:
        color = ELEMENT_COLORS.get(elem, "#555555")
        bg = ELEMENT_BG.get(elem, "#F5F5F5")
        btn = QPushButton()
        btn.setCheckable(True)
        btn.setMinimumHeight(max(36, int(host._element_panel_size.get('height', 40))))
        # 忽略文本最小宽度：号码很长时只在按钮内部裁切，不把整页撑出横向滚动条
        btn.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setToolTip("点击选中「" + elem + "」，右侧粘贴数字后点「应用」即可写入本行")
        # 按钮内放三个 QLabel：五行字 / 号码 / 数量，各自字号与颜色（按钮本身不支持富文本）
        row_layout = QHBoxLayout(btn)
        row_layout.setContentsMargins(12, 4, 12, 4)
        row_layout.setSpacing(8)
        elem_label = QLabel(elem)
        elem_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        nums_label = QLabel("（未分配）")
        nums_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        count_label = QLabel("共0个")
        count_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        row_layout.addWidget(elem_label)
        row_layout.addWidget(nums_label, 1)
        row_layout.addWidget(count_label)
        btn._elem_label = elem_label
        btn._nums_label = nums_label
        btn._count_label = count_label
        # 五行分组条样式 - 每个五行一种颜色
        #   QPushButton {            常态：白底 + 五行色边框
        #     text-align: left;      文字左对齐，像一条横线分组条
        #   }
        #   QPushButton:hover {      悬停：浅色五行背景
        #   }
        #   QPushButton:checked {    选中：浅色五行背景 + 加粗边框（文字仍用五行色，保证看得清）
        #   }
        btn.setStyleSheet(
            "QPushButton { text-align: left; /* 文字左对齐：分组条按行阅读 */"
            "background-color: #FFFFFF; /* 常态背景：纯白 */"
            "border: 2px solid " + color + "; /* 边框：2px 五行主色 */"
            "border-radius: 6px; /* 圆角：6px */"
            "padding: 7px 12px; /* 内边距：上下 7px、左右 12px，文字不贴边 */ }"
            "QPushButton:hover { background-color: " + bg + "; /* 悬停背景：对应五行浅色 */ }"
            "QPushButton:checked { background-color: " + bg + "; /* 选中背景：五行浅色 */"
            "border: 3px solid " + color + "; /* 选中边框：加粗到 3px，强化当前写入目标 */ }"
        )
        # 信号连接：点击分组条 → 主窗口记录当前写入目标
        btn.clicked.connect(lambda checked, e=elem: host._on_element_row_selected(e))
        layout.addWidget(btn)
        host.element_row_buttons[elem] = btn

    hint = QLabel("流程：选中一行 → 右侧粘贴数字 → 应用（立即写入并自动保存，全局生效）")
    # 流程提示样式：15px 浅灰，换行显示
    hint.setStyleSheet("font-size: 15px; color: #999999; padding: 4px;")
    hint.setWordWrap(True)
    layout.addWidget(hint)
    layout.addStretch()


def _build_paste_panel(host, layout):
    """构建右侧「粘贴数字」面板

    功能:
        创建标题、格式说明、多行粘贴框与写入状态标签。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；输入框/状态标签挂到 host。
        layout (QVBoxLayout): 右侧列的垂直布局。

    返回:
        None

    副作用:
        在 host 上创建 element_input_edit（QTextEdit）与 element_input_status
        （QLabel）；设置占位提示与固定高度。

    说明:
        输入框支持空格、逗号、顿号、分号、冒号、换行、横线、斜杠等任意分隔符，
        混用也可识别，因为解析在 lib/data_process.DataUtils.parse_numbers_text 中统一处理；
        高度固定 78px 是为了给下方 7 行号码面板留出纵向空间，避免上下两栏
        各占一半时号码面板出现滚动条。「应用」按钮已移到顶部标题行，
        与“恢复默认/保存设置”同一排，符合“先选目标 → 粘贴 → 点应用”的阅读顺序。
    """
    title = QLabel("粘贴数字（自动识别多种格式）")
    # 右侧标题样式：15px 粗体绿色
    title.setStyleSheet("font-size: 15px; font-weight: bold; color: #2ECC71; padding: 2px 4px;")
    layout.addWidget(title)

    tip = QLabel("支持空格、逗号、顿号、分号、冒号、换行、横线、斜杠等任意分隔，可混合使用；范围 01-49")
    # 格式说明样式：15px 浅灰
    tip.setStyleSheet("font-size: 15px; color: #888888; padding: 2px 4px;")
    tip.setWordWrap(True)
    layout.addWidget(tip)

    host.element_input_edit = QTextEdit()
    host.element_input_edit.setPlaceholderText("在此粘贴数字，例如：\n01 02 03\n05，06、07\n08-09-10")
    host.element_input_edit.setFixedHeight(78)  # 输入框不再过高，节省纵向空间
    # 输入框样式 - 白底 + 浅灰边框 + 等宽字体，便于核对数字
    host.element_input_edit.setStyleSheet(
        "QTextEdit { background-color: #FFFFFF; /* 背景：纯白，便于核对号码 */"
        "border: 1px solid #CCCCCC; /* 边框：1px 浅灰 */"
        "border-radius: 6px; /* 圆角：6px */"
        "padding: 6px; /* 内边距：6px，文字不贴边 */"
        "font-size: 15px; /* 字号：15px，全局最小可读字号 */"
        "font-family: Consolas, monospace; /* 等宽字体：数字逐位对齐，便于目视核对 */ }"
    )
    layout.addWidget(host.element_input_edit)

    host.element_input_status = QLabel("当前写入目标：金")
    # 状态标签样式：15px，浅橙背景，显示当前目标与写入结果
    host.element_input_status.setStyleSheet(
        "font-size: 15px; /* 字号：15px，全局最小可读字号 */"
        "color: #E67E22; /* 文字色：五行橙，呼应页面主题 */"
        "font-weight: bold; /* 加粗：状态/结果需要醒目 */"
        "padding: 5px 8px; /* 内边距：上下 5px、左右 8px */"
        "background-color: #FFF3E0; /* 背景：浅橙，与土行同色系 */"
        "border-radius: 4px; /* 圆角：4px，小面积提示框用小圆角 */"
    )
    host.element_input_status.setWordWrap(True)
    layout.addWidget(host.element_input_status)
    layout.addStretch()


def build(host):
    """构建「数字与五行」选项卡页面

    功能:
        创建本页完整控件树：标题行（应用/恢复默认/保存设置 + 角控件组）、
        上部“五行分组条 + 粘贴区”水平分隔器、下部 49 宫格号码面板、
        竖向分隔器与详情标签。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备 spacing、margin_*、
            _element_panel_size、_detail_label_size、zodiac_elements 等状态。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        在 host 上创建 element_h_splitter、element_v_splitter、element_row_buttons、
        element_input_edit、element_input_status、element_grid_panel、
        element_detail_label；连接按钮信号；恢复分隔器记忆尺寸；
        末尾设置 _element_target="金" 并触发一次选中与统计刷新。

    说明:
        上部 3:2、下部 280:520 的默认比例是为了让 49 个号码尽量一屏可见；
        旧配置若把某一栏压到 30px 以下，_apply_splitter_sizes 会自动回退默认值。
        横向分隔器嵌在竖向分隔器里，用户既能左右调分组条/粘贴区宽度，
        也能上下调编辑区/号码面板高度。
    """
    widget = QWidget()
    # 主垂直布局
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)

    # 顶部标题行：标题 + 右侧「应用 / 恢复默认 / 保存设置」 + 最右角控件组
    top_layout = QHBoxLayout()
    top_layout.setSpacing(8)

    page_title = QLabel("数字与五行")
    page_title.setObjectName("PanelTitle")
    top_layout.addWidget(page_title)
    top_layout.addStretch(1)  # 弹性拉伸：把操作按钮与角控件组一起推到右侧

    apply_btn = QPushButton("应用")
    # 「应用」按钮 - 绿色系（解析 + 写入 + 自动保存，一次完成）；位于恢复默认左侧
    apply_btn.setStyleSheet(
        "QPushButton {"
        "background-color: #FFFFFF; /* 默认背景：白色 */"
        "color: #2ECC71; /* 默认文字：绿色（确认/应用） */"
        "border: 2px solid #2ECC71; /* 边框：2px 实线绿色 */"
        "border-radius: 5px; /* 圆角：5px */"
        "font-weight: bold; /* 文字加粗 */"
        "font-size: 15px; /* 字号：15px，满足最小字号要求 */"
        "padding: 3px 18px; /* 内边距：上下 3px、左右 18px，文字不贴边 */"
        "}"
        "QPushButton:hover {"
        "background-color: #2ECC71; /* 悬停背景：绿色填充 */"
        "color: #FFFFFF; /* 悬停文字：白色 */"
        "}"
    )
    apply_btn.clicked.connect(host._on_element_input_apply)
    top_layout.addWidget(apply_btn)

    reset_btn = QPushButton("恢复默认")
    # 恢复默认按钮样式 - 红色系（危险/重置操作）
    reset_btn.setStyleSheet(
        "QPushButton {"
        "background-color: #FFFFFF; /* 默认背景：白色 */"
        "color: #E74C3C; /* 默认文字：红色（重置/危险操作） */"
        "border: 2px solid #E74C3C; /* 边框：2px 实线红色 */"
        "border-radius: 5px; /* 圆角：5px */"
        "font-weight: bold; /* 文字加粗 */"
        "font-size: 15px; /* 字号：15px，满足最小字号要求 */"
        "padding: 3px 10px; /* 内边距：上下 3px、左右 10px，文字不贴边 */"
        "}"
        "QPushButton:hover {"
        "background-color: #E74C3C; /* 悬停背景：红色填充 */"
        "color: #FFFFFF; /* 悬停文字：白色 */"
        "}"
    )
    reset_btn.clicked.connect(host._on_reset_elements)
    top_layout.addWidget(reset_btn)

    save_btn = QPushButton("保存设置")
    # 保存设置按钮样式 - 绿色系（安全/确认操作）
    save_btn.setStyleSheet(
        "QPushButton {"
        "background-color: #FFFFFF; /* 默认背景：白色 */"
        "color: #2ECC71; /* 默认文字：绿色（保存/确认） */"
        "border: 2px solid #2ECC71; /* 边框：2px 实线绿色 */"
        "border-radius: 5px; /* 圆角：5px */"
        "font-weight: bold; /* 文字加粗 */"
        "font-size: 15px; /* 字号：15px，满足最小字号要求 */"
        "padding: 3px 10px; /* 内边距：上下 3px、左右 10px，文字不贴边 */"
        "}"
        "QPushButton:hover {"
        "background-color: #2ECC71; /* 悬停背景：绿色填充 */"
        "color: #FFFFFF; /* 悬停文字：白色 */"
        "}"
    )
    save_btn.clicked.connect(host._on_save_elements)
    top_layout.addWidget(save_btn)

    top_layout.addSpacing(12)  # 操作区与角控件组之间留 12px，避免拥挤
    # 右上角「数字 px / 文字 px / 尺寸」控件组：四个页面统一规格、固定贴右端
    _build_font_controls(host, top_layout)

    layout.addLayout(top_layout)

    # 上部左右分栏：左 = 五行分组条，右 = 粘贴输入框
    host.element_h_splitter = QSplitter(Qt.Orientation.Horizontal)
    host.element_h_splitter.setHandleWidth(3)

    left_widget = QWidget()
    left_layout = QVBoxLayout(left_widget)
    left_layout.setContentsMargins(5, 5, 5, 5)
    _build_element_rows(host, left_layout)

    right_widget = QWidget()
    right_widget.setMinimumWidth(300)
    right_layout = QVBoxLayout(right_widget)
    right_layout.setContentsMargins(5, 5, 5, 5)
    _build_paste_panel(host, right_layout)

    host.element_h_splitter.addWidget(left_widget)
    host.element_h_splitter.addWidget(right_widget)
    host.element_h_splitter.setStretchFactor(0, 3)
    host.element_h_splitter.setStretchFactor(1, 2)
    # 默认 3:2（左分组条 : 右粘贴面板），旧配置若把某一栏压成 0 则自动回退到此比例
    host._apply_splitter_sizes(host.element_h_splitter, 'element_h_splitter', [600, 400])

    # 下部：五行号码面板（上数字 / 下五行），与上部之间可拖动调整高度
    panel_holder = QWidget()
    panel_holder.setMinimumHeight(490)  # 保证 7 行号码（上数字/下五行）完整可见，不出现滚动条
    panel_layout = QVBoxLayout(panel_holder)
    panel_layout.setContentsMargins(5, 2, 5, 2)
    panel_layout.setSpacing(2)
    panel_title = QLabel("全部号码（上数字 / 下五行）")
    panel_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #E67E22; padding: 2px 4px;")
    panel_layout.addWidget(panel_title)

    panel_scroll = QScrollArea()
    panel_scroll.setWidgetResizable(True)
    panel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    panel_scroll.setStyleSheet(
        "QScrollArea { border: 1px solid #EEEEEE; /* 边框：1px 极浅灰，弱化容器边界 */"
        "border-radius: 6px; /* 圆角：6px */"
        "background-color: #FAFAFA; /* 背景：浅灰，衬托上数字/下五行的白底按钮 */ }")
    host.element_grid_panel = ElementGridPanel()
    host.element_grid_panel.update_all_elements(host.zodiac_elements)
    # 应用面板尺寸设置（宽/高/数字字号/五行字号），默认紧凑尺寸让 49 个号码尽量一屏可见
    host.element_grid_panel.set_font_size(
        width=host._element_panel_size.get('width', 54),
        height=host._element_panel_size.get('height', 38),
        btn_font=host._element_panel_size.get('btn_font', 16),
        label_font=host._element_panel_size.get('label_font', 15))
    panel_scroll.setWidget(host.element_grid_panel)
    panel_layout.addWidget(panel_scroll, 1)

    host.element_v_splitter = QSplitter(Qt.Orientation.Vertical)
    host.element_v_splitter.setHandleWidth(4)
    host.element_v_splitter.addWidget(host.element_h_splitter)
    host.element_v_splitter.addWidget(panel_holder)
    host.element_v_splitter.setStretchFactor(0, 1)
    host.element_v_splitter.setStretchFactor(1, 2)
    # 默认 280 : 520（上部编辑区 : 下部号码面板），面板足够高，49 个号码一屏可见
    host._apply_splitter_sizes(host.element_v_splitter, 'element_v_splitter', [280, 520])
    layout.addWidget(host.element_v_splitter, 1)

    # 详情标签（最近写入/点击的数字：五行、生肖、颜色）
    detail_font = host._detail_label_size.get('font', 20)
    detail_padding = host._detail_label_size.get('padding', 8)
    host.element_detail_label = QLabel("点击左侧五行分组条选择写入目标，粘贴数字后点「应用」")
    host.element_detail_label.setStyleSheet(
        "font-size: " + str(detail_font) + "px; /* 字号：取全局详情字号配置 */"
        "color: #555555; /* 文字色：深灰，弱于标题但保证可读 */"
        "padding: " + str(detail_padding) + "px; /* 内边距：取全局详情内边距配置 */"
        "background-color: #F8F9FA; /* 背景：极浅灰，形成信息块边界 */"
        "border-radius: 5px; /* 圆角：5px */"
    )
    host.element_detail_label.setWordWrap(True)
    layout.addWidget(host.element_detail_label)

    # 初始化：默认选中「金」，刷新五行分组条与号码面板
    host._element_target = "金"
    host._on_element_row_selected("金")
    host._refresh_element_stats()

    return widget
