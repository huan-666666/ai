# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/info.py - 「公告说明」选项卡页面构建模块
===========================================================================
功能说明：
    构建主窗口「公告说明」选项卡的全部界面控件，并挂载到主窗口实例上。
    页面内容为纯静态公告（版本信息、功能列表、使用说明、注意事项、
    Bug 修复记录、快捷键、代码结构指南等），不参与任何计算。

TAB_INFO（供 TAB/__init__.py 自动发现）：
    title   = "公告说明"
    order   = 9（排在预测记录之后、数字与生肖之前的说明性页面）
    enabled = True

依赖：
    - UI/UI.py：QScrollArea / QWidget / QVBoxLayout / QGroupBox / QLabel / QFrame
      的唯一导入来源，禁止直接 from PyQt6 import
    - 标准库 re：update_announcement_font 中用正则替换样式表字号
    - 无 lib/ 业务依赖（本页不读取历史数据、不参与预测）

公告内容与字体缩放的数据流：
    1) build(host) 按“标题 → 分隔线 → 版本信息 → 主要功能 → 使用说明 →
       注意事项 → Bug修复记录 → 快捷键 → 代码结构指南 → 注释总结”的顺序创建
       QGroupBox/QLabel，全部挂在 host.notice_container 下；
    2) 每个标题/正文/GroupBox 的初始字号写在各自的 setStyleSheet 字符串里；
    3) 主窗口字号缩放时调用 update_announcement_font(host, scale)，
       用正则把样式表里的 font-size 数字替换为“基准字号 × scale”，
       其余颜色/边框/粗体等属性按原字符串保留。
       正因如此，初始样式表必须写 font-size 且单位统一为 px，
       否则正则匹配不到，缩放会失效。

职责边界：
    - 本模块只负责界面构建（布局、控件、初始样式）
    - 事件处理函数保留在主窗口 LotteryPredictionWindow 中，通过信号连接
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import os as _os_boot  # 作用说明：提供路径拼接/存在性判断/绝对路径解析能力，用于向上查找 run.py 所在的项目根目录
import re as _re_boot  # 作用说明：提供正则替换能力，H54 暗色文字映射与字号缩放都依赖它
import sys as _sys_boot  # 作用说明：提供 sys.path 列表操作能力，把项目根目录插入模块搜索路径，使 UI 包可直接导入

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QEvent, QFrame, QGroupBox, QLabel, QObject, QScrollArea, QTimer, QVBoxLayout, QWidget)  # 作用说明：提供公告页所需 Qt 控件（滚动区域、分组框、文本标签、分隔线、垂直布局与页面容器），统一由 UI/UI.py 导出；QEvent/QObject/QTimer 供 H54 主题切换回套文字颜色


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）

# ╔══════════════════════════════════════════════════════════════════╗
# ║  [公告说明：公告页字体缩放]
# ╚══════════════════════════════════════════════════════════════════╝

def update_announcement_font(host, scale=None):
    """按缩放比例更新公告说明页字体（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        以 24px（页面标题）/16px（分组标题）/14px（正文）为基准，
        乘以缩放比后写入各控件样式表，实现公告页整体字号缩放。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。
            读取 host._area_font_scales['announcement'] 与 host.notice_container。
        scale: float | None。None 表示取 host._area_font_scales 中本页当前缩放比
            （缺失时按 1.0）；显式传入时直接使用该比例。

    返回:
        无。

    调用方:
        install(host) 中绑定为 host._update_announcement_font；
        主窗口在字号缩放/重置时调用 host._update_announcement_font(scale)。

    副作用:
        1) 改写页面标题 QLabel、每个 QGroupBox、每个正文 QLabel 的样式表字号；
        2) 不重建控件、不改布局，只在原样式串上替换 font-size 数值；
        3) 若 host 尚未挂载 notice_container（页面未构建），静默返回。

    说明:
        正则 re.sub 只替换样式串中「font-size: 数字px」的数字部分，
        颜色、边框、粗体、内边距等其余属性原样保留；
        因此本页所有初始样式都必须带 `font-size: NNpx` 才能被缩放命中。

    异常:
        不主动抛出；样式表为空串时 re.sub 原样返回，不会报错。
    """
    if scale is None:
        # scale 由调用方省略时回到“本页当前缩放比”，保证重复应用缩放不会叠加
        scale = host._area_font_scales.get('announcement', 1.0)

    # 页面可能尚未构建（notice_container 只由 build 创建），此时没有可缩放控件
    if not hasattr(host, 'notice_container'):
        return

    base_title_size = 24
    base_group_title_size = 16
    # 正文基准与 build() 的初始字号一致，均为 15px（v0.0.36 全局字号下限）
    base_content_size = 15

    # 统一在函数内做整数取整：字号必须是整数 px，否则 f-string 会写出 14.4px 触发 QSS 解析告警
    # v0.0.42 起对三档字号统一钳制到 15px 下限：主窗口缩放范围低至 0.5，
    # 若不钳制则正文 15*0.5=7、分组标题 16*0.5=8，都会跌破全局最小可读字号
    new_title_size = max(15, int(base_title_size * scale))
    new_group_size = max(15, int(base_group_title_size * scale))
    new_content_size = max(15, int(base_content_size * scale))

    # 更新标题
    # findChild(QLabel, "") 取容器内第一个 QLabel；build 中最先加入的正是页面标题，
    # 因此无需额外 objectName 也能定位到标题（依赖“标题先加入”的构建顺序）
    title_label = host.notice_container.findChild(QLabel, "")
    if title_label:
        # 公告页标题样式：
        #   font-size: {new_title_size}px;  字号：按缩放比例动态计算（基准24px）
        #   font-weight: bold;              字体：粗体（突出标题层级）
        #   color: #2C3E50;                 文字颜色：深蓝灰（沉稳醒目）
        title_label.setStyleSheet(f"font-size: {new_title_size}px; font-weight: bold; color: {'#F5F5F5' if getattr(host, 'is_dark_mode', False) else '#2C3E50'};")

    # 更新所有GroupBox的标题字体和内容标签
    for group in host.notice_container.findChildren(QGroupBox):
        # 更新group的标题样式（通过样式表）
        style = group.styleSheet()
        # 延迟导入 re：本页只有缩放时才需要正则，放在用到的地方可避免模块导入期依赖
        # （位于循环内属于历史写法，Python 导入有 sys.modules 缓存，重复执行开销可忽略）
        import re  # 作用说明：提供正则替换能力（re.sub），把样式串中 font-size 的像素数值批量改为当前缩放后的字号
        # 用正则替换QGroupBox中的font-size为新的分组标题字号（基准16px × 缩放比）
        style = re.sub(r'font-size:\s*\d+px', f'font-size: {new_group_size}px', style)
        # 应用更新后的样式到 GroupBox（仅字号变化，保留边框/背景等其余属性）
        group.setStyleSheet(style)

        # 更新group内的所有QLabel（用正则替换font-size为新的内容字号，基准14px × 缩放比）
        for label in group.findChildren(QLabel):
            label_style = label.styleSheet()
            label_style = re.sub(r'font-size:\s*\d+px', f'font-size: {new_content_size}px', label_style)
            # 应用更新后的样式到内容标签（仅字号变化，保留颜色/粗体等其余属性）
            label.setStyleSheet(label_style)

    # 外层滚动区域
    # 说明：滚动区域本身不设字号，字体只作用在容器内的子控件上，故此处无需处理

# ╔══════════════════════════════════════════════════════════════════╗
# ║  [H54：公告页暗色文字配色]
# ╚══════════════════════════════════════════════════════════════════╝

# 亮色正文/标题里写死的深色文字在暗色底上对比度不足，统一映射到暗色令牌：
#   #F5F5F5 = 主窗口暗色正文；#A6ADC8 = 次要文字；#FF8A8A = 危险色；#89B4FA = accent。
# 只替换颜色值，字号/边距/边框/圆角等属性原样保留。
_NOTICE_DARK_TEXT_MAP = {
    '#2C3E50': '#F5F5F5',
    '#1A1A1A': '#F5F5F5',
    '#333333': '#F5F5F5',
    '#555555': '#A6ADC8',
    '#E74C3C': '#FF8A8A',
    '#9B59B6': '#89B4FA',
}


def _notice_dark_style(style):
    """把一份亮色样式串中的深色文字替换为暗色令牌后返回"""
    result = style or ''
    for light, dark in _NOTICE_DARK_TEXT_MAP.items():
        result = _re_boot.sub(light, dark, result, flags=_re_boot.IGNORECASE)
    return result


def _apply_notice_theme(host):
    """按当前主题回套公告页文字颜色，并保持当前字号缩放比例"""
    dark = bool(getattr(host, 'is_dark_mode', False))
    for widget, original in getattr(host, '_notice_theme_widgets', ()):
        try:
            widget.setStyleSheet(_notice_dark_style(original) if dark else original)
        except RuntimeError:
            pass
    # 上面写回了构建期字号，这里再按当前缩放比校正字号（只动 font-size）
    update_announcement_font(host)


class _NoticeThemeSync(QObject):
    """监听主窗口 StyleChange（主题/字号重建样式表）并回套公告页文字颜色"""

    def __init__(self, host):
        super().__init__(host)
        self._host = host
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(lambda: _apply_notice_theme(self._host))

    def eventFilter(self, obj, event):
        if obj is self._host and event.type() == QEvent.Type.StyleChange:
            self._timer.start(0)
        return False


def _register_notice_theme(host):
    """构建结束后登记公告页全部 QLabel/QGroupBox 的原始亮色样式"""
    widgets = []
    for group in host.notice_container.findChildren(QGroupBox):
        widgets.append((group, group.styleSheet()))
        for label in group.findChildren(QLabel):
            widgets.append((label, label.styleSheet()))
    # 页面标题不在分组内，单独补登记
    title_label = host.notice_container.findChild(QLabel, "")
    if title_label is not None and all(title_label is not w for w, _ in widgets):
        widgets.append((title_label, title_label.styleSheet()))
    host._notice_theme_widgets = widgets
    host._notice_theme_filter = _NoticeThemeSync(host)
    host.installEventFilter(host._notice_theme_filter)
    _apply_notice_theme(host)


def install(host):
    """安装「公告说明」选项卡：绑定字体缩放回调后构建界面（v0.0.28 起页面自包含）

    功能:
        由主窗口创建选项卡时调用；本页 v0.0.28 起自包含，字体缩放函数由
        主窗口按需直接调用，安装阶段只执行 build(host) 并返回页面控件。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。
    返回:
        QWidget: 构建完成的页面（build 的返回值），供 addTab 使用。
    调用方:
        TAB/__init__.py 的 iter_tab_pages() 自动发现本页后由主窗口调用。
    副作用:
        build(host) 创建并挂载 host.notice_container。
    """
    return build(host)


TAB_INFO = {
    "title": "公告说明",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 9,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """构建「公告说明」选项卡页面

    功能:
        创建可滚动公告容器，按固定顺序创建标题、分组框与列表项，最后套一层
        零边距包装控件返回。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。本函数挂载：
            host.notice_container —— 公告内容容器 QWidget（objectName="NoticeContainer"），
            字体缩放函数依赖它查找标题/分组/正文标签。

    返回:
        QWidget: 外层包装控件（内含 QScrollArea），作为选项卡页面。

    副作用:
        1) 在 host 上创建 notice_container 及其全部子控件（滚动区域内）；
        2) 创建顺序决定子控件树顺序：页面标题 → 分隔线 → 版本信息 →
           主要功能 → 使用说明 → 注意事项 → Bug修复记录 → 快捷键 →
           代码结构指南 → 注释总结 → 底部拉伸；
           update_announcement_font 依赖“标题是第一个 QLabel”，顺序不可随意调整；
        3) 所有字号/颜色写在各控件样式表中，后续由字体缩放函数按 px 替换字号；
        4) 不读写业务数据、不连接任何信号（本页为纯展示）。

    说明:
        滚动区域负责承载超长公告内容，窗口缩小时出现纵向滚动条；
        外层 wrapper 边距设为 0，使滚动条紧贴页面边缘。
    """
    scroll = QScrollArea()
    # 公告内容远超一屏，widgetResizable=True 让内容容器随可视区域宽度伸缩，高度由内容撑开
    scroll.setWidgetResizable(True)
    scroll.setObjectName("NoticeScrollArea")

    # 内容容器
    host.notice_container = QWidget()
    host.notice_container.setObjectName("NoticeContainer")
    layout = QVBoxLayout(host.notice_container)
    # 分组间距 15px：比普通行距更大，便于区分各个 QGroupBox 区块
    layout.setSpacing(15)
    # 四周边距 30px：公告为长文阅读页面，留白可降低阅读压迫感
    layout.setContentsMargins(30, 30, 30, 30)

    # 标题
    title_label = QLabel("📢 公告说明")
    # 公告标题样式：24px粗体，深灰色(#2C3E50)文字
    title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #2C3E50;")
    layout.addWidget(title_label)

    # 分隔线
    line1 = QFrame()
    line1.setFrameShape(QFrame.Shape.HLine)
    # 分隔线样式：浅灰色(#DDDDDD)水平线
    line1.setStyleSheet("color: #DDDDDD;")
    layout.addWidget(line1)

    # 版本信息
    version_group = QGroupBox("版本信息")
    # 版本信息GroupBox样式 - 蓝色系（蓝色标题+灰色边框的分组容器）
    #   QGroupBox {               分组容器常态样式
    #     font-size: 16px;        标题字号
    #     font-weight: bold;      标题粗体
    #     color: #3498DB;         标题颜色：蓝色
    #     border: 2px solid #DDDDDD;  边框：2px浅灰实线
    #     border-radius: 8px;     圆角：8px
    #     margin-top: 12px;       顶部外边距（给标题留空间）
    #     padding-top: 12px;      顶部内边距
    #   }
    #   QGroupBox::title {        标题子控件
    #     subcontrol-origin: margin;  定位基准为margin区域
    #     left: 15px;             标题左偏移
    #     padding: 0 5px;         标题左右内边距
    #   }
    version_group.setStyleSheet("""
        QGroupBox {
            font-size: 16px;
            font-weight: bold;
            color: #3498DB;
            border: 2px solid #DDDDDD;
            border-radius: 8px;
            margin-top: 12px;
            padding-top: 12px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 15px;
            padding: 0 5px;
        }
    """)
    version_layout = QVBoxLayout()
    version_layout.setSpacing(8)

    version_items = [
        "• 程序名称：系统 v7.5",
        "• 程序版本：v0.0.81（蓝图真实平台渲染并生成 14 页截图；目录树 / 索引脚本 16→14 收口。已落地：生肖管理批量编辑与三态自检、暗色统一、125% 缩放实测）",
        "• 更新日期：2026年11月4日",
        "• 开发框架：PyQt6",
        "• 适用系统：Windows / macOS / Linux",
        "• 数据目录：程序目录/系统v7.5/（INI、JSON、数据存储、app_config.db、analysis.duckdb）",
    ]
    for item in version_items:
        label = QLabel(item)
        # 列表项文字加深到 #333333；版本号一行按规范用 Bold + 近纯黑
        if item.startswith("• 程序版本"):
            label.setStyleSheet(
                "font-size: 15px; color: #1A1A1A; font-weight: bold; padding: 2px 0;")
        else:
            label.setStyleSheet(
                "font-size: 15px; color: #333333; font-weight: 500; padding: 2px 0;")
        version_layout.addWidget(label)

    version_group.setLayout(version_layout)
    layout.addWidget(version_group)

    # 功能说明
    feature_group = QGroupBox("主要功能")
    # 主要功能GroupBox样式 - 绿色系（绿色标题+灰色边框的分组容器）
    #   结构与版本信息GroupBox相同，仅标题颜色改为绿色(#2ECC71)
    #   QGroupBox {
    #     font-size: 16px;            标题字号：16px（与其它分组一致）
    #     font-weight: bold;          标题粗体
    #     color: #2ECC71;             标题颜色：绿色（区分“功能”语义）
    #     border: 2px solid #DDDDDD;  边框：2px 浅灰实线
    #     border-radius: 8px;         圆角：8px
    #     margin-top: 12px;           顶部外边距：给浮动标题留出空间
    #     padding-top: 12px;          顶部内边距：避免正文贴住边框
    #   }
    #   QGroupBox::title {
    #     subcontrol-origin: margin;  标题定位基准：margin 区域
    #     left: 15px;                 标题左偏移：15px
    #     padding: 0 5px;             标题左右内边距：5px
    #   }
    feature_group.setStyleSheet("""
        QGroupBox {
            font-size: 16px;
            font-weight: bold;
            color: #2ECC71;
            border: 2px solid #DDDDDD;
            border-radius: 8px;
            margin-top: 12px;
            padding-top: 12px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 15px;
            padding: 0 5px;
        }
    """)
    feature_layout = QVBoxLayout()
    feature_layout.setSpacing(8)

    feature_items = [
        "• 📊 历史数据管理：支持导入、查看、筛选开奖历史记录",
        "• 🔮 智能预测：23+种预测算法，支持标准/反向双模式",
        "• 🎲 随机抽取：支持机选号码、随机生成",
        "• 🤖 机器学习预测：RF/GBC/LR/MLP四模型集成，支持模型缓存开关（可自主选择是否使用训练文件）",
        "• 📈 统计分析：数字频率、奇偶比、大小比、和值分布等",
        "• 📅 回测验证：历史回测，验证算法准确率",
        "• ⭐ 收藏对比：保存预测结果，多方案对比分析",
        "• 🐉 生肖五行：数字与生肖、五行属性绑定查询",
        "• 🔍 概率分析：基于历史数据计算各数字出现概率",
        "• 🐇 生肖概率：统计各生肖出现概率，支持全部号码/仅特别码模式",
        "• 🎨 波色预测：分析红/蓝/绿波色出现概率和趋势",
        "• ➕ 计算规律：两期间数字逐一加减，自动发现高频规律",
        "• 📁 多格式支持：所有导入/导出均支持JSON、CSV、TXT三种格式",
        "• 🔢 两位数字：导出CSV/TXT数字自动补零到两位（如01、08）",
        "• 📋 批量兼容：批量添加支持逗号分隔（CSV）和空格分隔（TXT）格式",
        "• 🧮 数字排序：多分隔符自动识别（中英文标点、空格、斜杠、横线、井号、竖线、波浪号等可混用），支持去重排序与缺失号码提示",
        "• 🔟 数字选尾：尾数支持多选，实时筛选匹配/未匹配数字",
        "• 🔀 结果分隔符：排序与选尾结果可选择 15 种格式（空格/英文逗号/顿号/分号/减号/斜杠/竖线/换行/中文逗号/中文句号/英文句号/加号/反斜杠/波浪号/井号）",
        "• 🧠 大数据分析：基于历史记录综合频率、遗漏、转移三项特征，推荐 7 个互不重复的生肖和 7 个互不重复的数字，并给出红波/绿波/蓝波三色波评分与倾向",
        "• 📊 大数据统计检验：numpy 计算和值均值/标准差/MA5/EMA5/趋势斜率、一阶自相关、号码频数与信息熵、Z-score 冷热号、遗漏未出概率；scipy 计算卡方均匀性检验与二项分布 95% 置信区间",
        "• 💾 控件记忆：下拉框选项、数字框数值、滑块位置、复选框状态、表格列宽、全部分隔条尺寸与配置项自动记忆，重启后恢复到上次状态",
        "• 📏 尺寸规范：文字最高 150px，按钮最大 300×300px；默认文字 20px、默认按钮 80×60px，超限自动钳制",
        "• 🧾 多格式识别：任意文本输入均兼容中文逗号、中文句号、英文逗号、英文句号、加号、减号、空格、顿号、反斜杠、正斜杠、竖线、波浪号、井号、换行符等分隔符",
        "• 🗄️ 双数据库：SQLite 保存历史记录、配置、预测记录与数据存储索引；DuckDB 负责 [6] 统计图表、[7] 回测/算法对比/命中趋势、[16] 大数据分析与报表导出的窗口取数，并支持 CSV/Parquet 直读；不可用时自动回退内存",
        "• 📐 控件自适应：参数框、字体框、下拉框按内容自动调整宽度，大字体下不再截断文字",
        "• 📦 打包友好：生成 exe 后自动在程序目录创建「系统v7.5」数据文件夹，数据随身携带",
    ]
    for item in feature_items:
        label = QLabel(item)
        # 功能列表项标签样式：14px字号，灰色文字
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        feature_layout.addWidget(label)

    feature_group.setLayout(feature_layout)
    layout.addWidget(feature_group)

    # 使用说明
    usage_group = QGroupBox("使用说明")
    # 使用说明GroupBox样式 - 橙色系（橙色标题+灰色边框的分组容器）
    #   结构与版本信息GroupBox相同，仅标题颜色改为橙色(#E67E22)
    #   font-size: 16px;            标题字号：16px
    #   font-weight: bold;          标题粗体
    #   color: #E67E22;             标题颜色：橙色（区分“说明”语义）
    #   border: 2px solid #DDDDDD;  边框：2px 浅灰实线
    #   border-radius: 8px;         圆角：8px
    #   margin-top: 12px;           顶部外边距：给浮动标题留空间
    #   padding-top: 12px;          顶部内边距
    #   QGroupBox::title: subcontrol-origin: margin；left: 15px；padding: 0 5px
    usage_group.setStyleSheet("""
        QGroupBox {
            font-size: 16px;
            font-weight: bold;
            color: #E67E22;
            border: 2px solid #DDDDDD;
            border-radius: 8px;
            margin-top: 12px;
            padding-top: 12px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 15px;
            padding: 0 5px;
        }
    """)
    usage_layout = QVBoxLayout()
    usage_layout.setSpacing(8)

    usage_items = [
        "1. 首先在「数据导入」页面导入或添加历史开奖数据（支持JSON/CSV/TXT格式）",
        "2. 在「预测与抽取」页面选择算法，点击「开始预测」生成预测结果",
        "3. 可将满意的预测结果保存到「收藏」页面，方便后续对比",
        "4. 在「历史记录」页面查看详细的开奖历史和期号详情",
        "5. 「统计分析图表」提供可视化的数字频率和分布分析",
        "6. 「回测分析」可验证算法在历史数据上的表现",
        "7. 「出现概率」页面新增「生肖概率」选项卡，可查看各生肖出现概率",
        "8. 生肖概率支持「仅限特别码」模式，可单独统计特别码的生肖分布",
        "9. 「波色预测」分析红蓝绿波色出现概率，支持前/后半段对比",
        "10. 「计算规律」通过两期间数字加减运算，自动发现高频规律并推荐号码",
        "11. 导出数据时自动补零到两位（如1→01），确保格式统一",
        "12. 批量添加支持逗号分隔（CSV格式）和空格分隔（TXT格式）两种方式",
        "13. 机器学习预测按钮下方的「使用模型训练文件」复选框，勾选=使用已有模型文件（跳过训练），取消=每次重新训练",
        "14. 「数字排序」与「数字选尾」可混合粘贴任意分隔符的数字串（如 5，12。23、35；42|7#15~25=37），自动识别",
        "15. 「数字排序」与「数字选尾」右侧「分隔符」下拉框可在 15 种格式（空格/英文逗号/顿号/分号/减号/斜杠/竖线/换行/中文逗号，/中文句号。/英文句号./加号+/反斜杠/波浪号~/井号#）间切换，选择会自动记忆",
        "16. 「数字选尾」的尾数按钮支持多选，选中几个尾数就同时筛选这几个尾数的号码",
        "17. 「大数据分析」选择分析期数与三项权重后点击「开始分析」，即可得到 7 生肖 + 7 数字 + 红波/绿波/蓝波评分，可复制或导出TXT",
        "18. 窗口缩小时选项卡内容自动出现滚动条，字体缩放限制在 0.85~1.15 倍，避免文字看不清或控件重叠",
        "19. 「预测记录」自动保存到 系统v7.5/预测记录.json，写入/清空/关窗时均落盘，重启后记录仍在",
        "20. 历史开奖数据在保存时同步镜像到 SQLite（history_records 表），彩票数据.json 丢失或损坏时自动从数据库恢复",
        "21. 所有下拉框、数字框、滑块、复选框、表格列宽与分隔条位置自动记忆到 配置.ini 的 [WidgetState] 段，重启后恢复到上次状态；新增控件挂到 host 即自动纳入记忆",
        "22. 「大数据分析」结果下方新增「统计检验与趋势」卡片，展示和值趋势、自相关、信息熵、卡方检验、95% 置信区间、Z-score 冷热号与遗漏未出概率",
    ]
    for item in usage_items:
        label = QLabel(item)
        # 使用说明列表项标签样式：14px字号，灰色文字
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        label.setWordWrap(True)
        usage_layout.addWidget(label)

    usage_group.setLayout(usage_layout)
    layout.addWidget(usage_group)

    # 注意事项
    notice_group = QGroupBox("注意事项")
    # 注意事项GroupBox样式 - 红色系（红色标题+灰色边框的分组容器，突出警示）
    #   结构与版本信息GroupBox相同，仅标题颜色改为红色(#E74C3C)
    #   font-size: 16px;            标题字号：16px
    #   font-weight: bold;          标题粗体
    #   color: #E74C3C;             标题颜色：红色（警示语义）
    #   border: 2px solid #DDDDDD;  边框：2px 浅灰实线
    #   border-radius: 8px;         圆角：8px
    #   margin-top: 12px;           顶部外边距：给浮动标题留空间
    #   padding-top: 12px;          顶部内边距
    #   QGroupBox::title: subcontrol-origin: margin；left: 15px；padding: 0 5px
    notice_group.setStyleSheet("""
        QGroupBox {
            font-size: 16px;
            font-weight: bold;
            color: #E74C3C;
            border: 2px solid #DDDDDD;
            border-radius: 8px;
            margin-top: 12px;
            padding-top: 12px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 15px;
            padding: 0 5px;
        }
    """)
    notice_layout = QVBoxLayout()
    notice_layout.setSpacing(8)

    notice_items = [
        "⚠️ 本软件仅为数据分析和娱乐工具，不构成任何投注建议",
        "⚠️ 彩票预测具有随机性，历史规律不代表未来结果",
        "⚠️ 请理性购彩，量力而行，遵守当地法律法规",
        "⚠️ 数据仅供参考，请以官方公布的开奖结果为准",
        "💡 建议定期更新历史数据，以获得更准确的预测结果",
        "💡 生肖概率和波色预测基于历史数据统计，可作为选号辅助参考",
        "💡 计算规律中加减结果自动循环到1-49范围内，确保号码有效性",
    ]
    for item in notice_items:
        label = QLabel(item)
        # 注意事项列表项标签样式：14px字号，灰色文字
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        label.setWordWrap(True)
        notice_layout.addWidget(label)

    notice_group.setLayout(notice_layout)
    layout.addWidget(notice_group)

    # Bug修复记录（2026年8月5日）
    bugfix_group = QGroupBox("Bug修复记录（2026年8月5日）")
    # Bug修复记录GroupBox样式 - 红色系（与“注意事项”一致，强调修复记录需重点关注）
    #   QGroupBox {
    #     font-size: 16px;            标题字号：16px
    #     font-weight: bold;          标题粗体
    #     color: #E74C3C;             标题颜色：红色
    #     border: 2px solid #DDDDDD;  边框：2px 浅灰实线
    #     border-radius: 8px;         圆角：8px
    #     margin-top: 12px;           顶部外边距：给浮动标题留空间
    #     padding-top: 12px;          顶部内边距
    #   }
    #   QGroupBox::title {
    #     subcontrol-origin: margin;  标题定位基准：margin 区域
    #     left: 15px;                 标题左偏移：15px
    #     padding: 0 5px;             标题左右内边距：5px
    #   }
    bugfix_group.setStyleSheet("""
        QGroupBox {
            font-size: 16px;
            font-weight: bold;
            color: #E74C3C;
            border: 2px solid #DDDDDD;
            border-radius: 8px;
            margin-top: 12px;
            padding-top: 12px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 15px;
            padding: 0 5px;
        }
    """)
    bugfix_layout = QVBoxLayout()
    bugfix_layout.setSpacing(6)

    bugfix_items = [
        "<b>【新增功能】模型缓存开关</b>：机器学习预测按钮下方新增「使用模型训练文件」复选框，勾选=使用已有ml_models.pkl跳过训练（默认），取消=每次重新训练。状态通过INI配置持久化，重启自动恢复。",
        "<b>【关键修复】X_latest取最旧10条导致预测永远重复</b>：predict_with_all_models中构建X_latest时，data_ordered = reversed(data)后取前10条→拿到的是最旧10条记录（data[0]最新，reversed后data_ordered[0]最旧），最旧10条永远不变→X_latest永远相同→预测永远重复。修复：改为取data_ordered[-10:]（最新10条），新数据加入后X_latest随之更新。",
        "<b>1. 缓存模型预测结果重复</b>：_predict_with_cached_models优先使用缓存旧X_latest（训练时的特征向量），导致缓存模型+缓存旧特征→每次预测输入相同→输出永远不变。修复：删除cached_X_latest覆盖逻辑，使用当前最新数据计算的X_latest。",
        "<b>2. 模型全部失败返回随机结果但保存指纹</b>：predict_with_all_models和_predict_with_cached_models在模型全部失败时返回random.sample(...)，但_on_ml_predict_finished无差别保存指纹，导致随机结果被当作有效预测锁定。修复：失败时返回None，_on_ml_predict_finished已有None检查不会保存指纹。",
        "<b>3. 两处指纹计算不一致</b>：MLPredictionModel._get_data_fingerprint只取前100条数据，MainWindow._compute_data_fingerprint使用全部数据。数据超100条时两处指纹永远不同，无法交叉验证。修复：统一使用全部数据。",
        "<b>4. 数据不足时返回随机结果</b>：predict_with_all_models在X<20样本时返回random.sample(...)，但caller已检查≥20，此路径仅边际触发。统一改为返回None。",
        "<b>5. 类型切换不验证指纹</b>：_on_prediction_type_changed加载缓存预测时仅检查期号，若用户修改号码但不改期号，会显示过期预测。修复：添加数据指纹验证，指纹不匹配时提示「数据已变化，请重新预测」。",
        "<b>6. 死代码_cached_X/_cached_y/cached_X_latest</b>：从load_models加载的大型numpy矩阵被解包但从未使用，浪费内存。已添加注释说明仅用于元组对齐。",
        "<b>7. 确定性种子重复设置</b>：_run_prediction_in_main_thread和_run_ml_prediction_in_main_thread中重复设置random.seed/np.random.seed，污染全局随机状态。修复：移除重复调用，种子已在_set_deterministic_seed中设置。",
        "<b>8. 指纹保存非原子操作（ML路径）</b>：_on_ml_predict_finished中指纹在_save_last_prediction之前保存，若持久化失败则指纹已锁定但预测未保存。修复：将指纹保存移至_save_last_prediction之后。",
        "<b>9. 生肖组替换后置信度不匹配</b>：_run_prediction_in_main_thread中生肖组选择替换了predictions，但confidence_info仍使用原始算法top-N计算，导致显示的号码与置信度数字不对应。修复：生肖组选择后基于all_scores重新计算置信度，确保与显示号码匹配。",
        "<b>10. ML预测缺少置信度</b>：_on_ml_predict_finished不接收概率字典，_save_last_prediction的confidence_info始终为None，ML预测结果永久丢失置信度数据。修复：将all_probs_dict传入_on_ml_predict_finished，计算置信度后传入_save_last_prediction。",
        "<b>11. _select_zodiac_group_numbers死代码</b>：49个数字分12组，每组至少4个数字，第1组始终有次高分可用，elif/else回退分支永远不可达。修复：删除死代码，简化逻辑。",
        "<b>12. 过滤后号码不足检查</b>：_on_ml_predict_finished中过滤无效号码后未检查数量，可能不足6个导致后续显示异常。修复：添加len(predictions) < 6检查并给出警告。",
        "<b>13. _get_latest_period返回最旧期号</b>：数据插入同时使用insert(0)和append()，导致顺序不一致，_get_latest_period[-1]可能返回最旧期号，影响所有过期判断。修复：改为max()按期号数值查找最大值。",
        "<b>14. _safe_write_file非原子写入</b>：直接写目标文件，写入中断可能导致文件损坏。修复：改为临时文件写入+os.replace原子替换，重试间隔从30秒缩短为2秒。",
        "<b>15. _json_default遇未知类型抛TypeError</b>：与MLPredictionModel._json_default_handler行为不一致，可能导致_compute_data_fingerprint崩溃。修复：添加fallback到str(obj)。",
        "<b>16. _classic_comprehensive缺少算法</b>：经典综合推荐只收集4种算法（缺少odd_even/big_small），与增强模式6种不一致。修复：补齐两种算法，_optimize_ensemble_weights增加w_odd_even/w_big_small权重。",
        "<b>17. _balance_selection数量不足</b>：极端情况（全奇数/全偶数）下可能返回不足count个数字。修复：添加安全补位逻辑从全量排序结果中按分数降序补充。",
        "<b>18. predict_with_all_models返回类型变更</b>：返回值从list改为(list, all_probs_dict)元组，支持生肖组选择。同步更新MLPredictionWorker.run()和_run_ml_prediction_in_main_thread的调用方。",
    ]
    for item in bugfix_items:
        label = QLabel(item)
        # Bug修复条目样式：15px字号（v0.0.36 字号下限），灰色文字，上下内边距2px
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        label.setWordWrap(True)
        bugfix_layout.addWidget(label)

    bugfix_group.setLayout(bugfix_layout)
    layout.addWidget(bugfix_group)

    # 快捷键说明
    shortcut_group = QGroupBox("快捷键")
    # 快捷键GroupBox样式 - 紫色系（紫色标题+灰色边框的分组容器）
    #   结构与版本信息GroupBox相同，仅标题颜色改为紫色(#9B59B6)
    #   font-size: 16px;            标题字号：16px
    #   font-weight: bold;          标题粗体
    #   color: #9B59B6;             标题颜色：紫色（区分“快捷键”语义）
    #   border: 2px solid #DDDDDD;  边框：2px 浅灰实线
    #   border-radius: 8px;         圆角：8px
    #   margin-top: 12px;           顶部外边距：给浮动标题留空间
    #   padding-top: 12px;          顶部内边距
    #   QGroupBox::title: subcontrol-origin: margin；left: 15px；padding: 0 5px
    shortcut_group.setStyleSheet("""
        QGroupBox {
            font-size: 16px;
            font-weight: bold;
            color: #9B59B6;
            border: 2px solid #DDDDDD;
            border-radius: 8px;
            margin-top: 12px;
            padding-top: 12px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 15px;
            padding: 0 5px;
        }
    """)
    shortcut_layout = QVBoxLayout()
    shortcut_layout.setSpacing(8)

    shortcut_items = [
        "• Ctrl + P：开始预测",
        "• Ctrl + S：保存当前预测",
        "• Ctrl + R：随机抽取号码",
        "• Ctrl + 1~9：切换对应标签页",
        "• Ctrl + 0：切换到第10个标签页",
    ]
    for item in shortcut_items:
        label = QLabel(item)
        # 快捷键列表项标签样式：14px字号，灰色文字
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        shortcut_layout.addWidget(label)

    shortcut_group.setLayout(shortcut_layout)
    layout.addWidget(shortcut_group)

    # 代码结构与可调参数指南（新增）
    guide_group = QGroupBox("代码结构与可调参数指南")
    # 代码结构指南GroupBox样式 - 青色系（青色标题+灰色边框的分组容器）
    #   结构与版本信息GroupBox相同，仅标题颜色改为青色(#1ABC9C)
    #   font-size: 16px;            标题字号：16px
    #   font-weight: bold;          标题粗体
    #   color: #1ABC9C;             标题颜色：青色（区分“开发指南”语义）
    #   border: 2px solid #DDDDDD;  边框：2px 浅灰实线
    #   border-radius: 8px;         圆角：8px
    #   margin-top: 12px;           顶部外边距：给浮动标题留空间
    #   padding-top: 12px;          顶部内边距
    #   QGroupBox::title: subcontrol-origin: margin；left: 15px；padding: 0 5px
    guide_group.setStyleSheet("""
        QGroupBox {
            font-size: 16px;
            font-weight: bold;
            color: #1ABC9C;
            border: 2px solid #DDDDDD;
            border-radius: 8px;
            margin-top: 12px;
            padding-top: 12px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 15px;
            padding: 0 5px;
        }
    """)
    guide_layout = QVBoxLayout()
    guide_layout.setSpacing(10)

    # 文件整体结构概述
    structure_title = QLabel("<b>📁 文件整体结构概述</b>")
    # 小节标题样式：14px字号，深灰色(#2C3E50)文字
    structure_title.setStyleSheet("font-size: 15px; color: #2C3E50;")
    guide_layout.addWidget(structure_title)

    # 分层结构（入口 → 主窗口 → 页面 → 逻辑层）
    infra_title = QLabel("<b>🧱 分层结构（入口 → 主窗口 → 页面 → 逻辑层）</b>")
    # 子标题样式：13px字号，深灰色文字
    infra_title.setStyleSheet("font-size: 15px; color: #2C3E50; padding: 4px 0 0 0;")
    guide_layout.addWidget(infra_title)

    structure_items = [
        "• <b>run.py</b>：程序入口。设置线程数 → 主线程预加载 sklearn/scipy → 初始化数据库 → QApplication → 直接创建主窗口 LotteryPredictionWindow → 14 个启用选项卡（3 页合并停用）由 TAB/*.py 构建 → app.exec() → finally 清理后 os._exit",
        "• <b>UI/UI.py</b>：全部 PyQt6 控件与类的唯一导入中心；主窗口与页面只能 from UI import *，禁止直接 from PyQt6 import",
        "• <b>lib/__init__.py</b>：重型库懒加载核心（numpy/pandas/scipy/sklearn/torch/matplotlib 等 16 个加载器 + HAS_* 状态变量）",
        "• <b>lib/data_process.py</b>：LotteryConfig（窗口尺寸/字体/波色/生肖/五行/区间/算法列表）、DataUtils",
        "• <b>lib/algorithms.py</b>：23 种预测算法的唯一注册表（编号 0–22 / 名称 / 描述 / 计算方法 / 正码数 / 分类；新增算法只改这一处）",
        "• <b>lib/math_algo.py</b>：MathUtils、PredictionAlgorithms（23 种算法）、BigDataAnalyzer",
        "• <b>lib/ml_model.py</b>：MLPredictionModel（RF/GBC/LR/MLP + 模型缓存）",
        "• <b>lib/plot_draw.py</b>：matplotlib/seaborn 绘图与图表对象访问器（get_figure_module / get_canvas_class 等）",
        "• <b>lib/db_helper.py</b>：SQLite + DuckDB 双库单例 get_db()（app_config / user_data / func_state / history_records / storage_items + DuckDB history_detail / read_table_file 直读 CSV·Parquet）",
        "• <b>plugins/彩票预测.py</b>：主窗口 LotteryPredictionWindow（约 3400 行，只保留布局装配、事件处理与兼容转发）",
        "• <b>TAB/*.py</b>：14 个启用选项卡（3 页合并停用），每页一个文件，统一导出 build(host)；widgets.py 存放共享控件（号码球/号码面板/图表/表格代理）",
    ]
    for item in structure_items:
        label = QLabel(item)
        # 结构说明列表项样式：13px字号（比正文略小），灰色文字
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        label.setWordWrap(True)
        guide_layout.addWidget(label)

    # 分隔线
    sep_infra = QLabel("")
    sep_infra.setFixedHeight(8)
    guide_layout.addWidget(sep_infra)

    # 主窗口 15 个代码区域（不写绝对行号，避免代码增删后失效）
    region_title = QLabel("<b>🧩 主窗口 15 个代码区域（在 plugins/彩票预测.py 内搜索「区域N」定位）</b>")
    # 子标题样式：13px字号，深灰色文字
    region_title.setStyleSheet("font-size: 15px; color: #2C3E50; padding: 4px 0 0 0;")
    guide_layout.addWidget(region_title)

    region_items = [
        "• <b>区域1</b>：初始化与全局配置 — 窗口初始化、UI主题/字体/面板尺寸、INI配置读写、选项卡切换、快捷键、关闭清理",
        "• <b>区域2</b>：数据导入与格式转换 — 数据导入/导出、手动增删改、批量操作、格式转换（本地导入 + 在线开奖抓取，数据存独立库 系统v7.5/在线开奖.db）",
        "• <b>区域3</b>：历史记录 — 历史数据表格展示、分页浏览、列排序（升序/降序）、期号详情弹窗、最新期号显示",
        "• <b>区域4</b>：预测与抽取 — 算法预测、随机抽取、概率面板（数字+生肖）、计算规律、波色预测、号码预测（七策略）、收藏对比、机器学习预测（含模型缓存开关）、生肖组选择（_select_zodiac_group_numbers）",
        "• <b>区域5</b>：数字选择 — 手动选号面板，点击数字球选择/取消号码，显示已选号码列表和大小单双统计",
        "• <b>区域6</b>：第七位预判 — 特别号码专项预测（大小/奇偶/尾数/综合），频率图/趋势图/相关性分析",
        "• <b>区域7</b>：统计分析图表 — 频率图、遗漏图、奇偶/大小/波色/区间/尾数分布、走势图、热力图、和值分布",
        "• <b>区域8</b>：回测分析 — 历史数据回测，验证算法命中率，算法对比、命中趋势图",
        "• <b>区域9</b>：预测记录 — 预测结果自动记录、表格展示、导出CSV、清除历史",
        "• <b>区域10</b>：公告说明 — 版本信息、功能介绍、使用说明、注意事项、快捷键、代码结构指南、可调参数速查",
        "• <b>区域11</b>：号码属性（合并页）— 号码矩阵、五行分布、生肖高亮、选中详情、双击改生肖、面板字体控制",
        "• <b>区域12</b>：收藏 — 收藏预测号码，添加/查看/删除收藏",
        "• <b>区域13</b>：数字排序 — 按频率、遗漏等维度对数字排序，显示排名统计",
        "• <b>区域14</b>：数字选尾 — 按尾数（0-9）筛选号码，显示对应数字列表",
        "• <b>区域15</b>：数据存储 — 拖拽上传、分类导航、卡片/列表视图、标签管理、搜索筛选、备份恢复、剪贴板粘贴",
    ]
    for item in region_items:
        label = QLabel(item)
        # 结构说明列表项样式：13px字号（比正文略小），灰色文字
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        label.setWordWrap(True)
        guide_layout.addWidget(label)

    # 分隔线
    sep_region = QLabel("")
    sep_region.setFixedHeight(5)
    guide_layout.addWidget(sep_region)

    # 缓存机制说明
    cache_title = QLabel("<b>💾 缓存机制（已有文件直接使用，无需重新计算）</b>")
    cache_title.setStyleSheet("font-size: 15px; color: #2C3E50; padding: 4px 0 0 0;")
    guide_layout.addWidget(cache_title)

    cache_items = [
        "• <b>算法预测缓存</b>：预测结果保存到JSON文件（上次预测_算法预测_本次/上次.json），启动和切换类型时自动加载已有文件，无需重新执行算法",
        "• <b>机器学习模型缓存</b>：训练后的模型保存到ml_models.pkl（四种模型：RF/GBC/LR/MLP），文件存在直接加载使用跳过训练，仅文件不存在时重新训练。每次预测使用当前最新数据计算特征向量（非缓存旧值），确保结果随数据更新而变化",
        "• <b>模型缓存开关</b>：机器学习预测按钮下方的「使用模型训练文件」复选框，勾选=使用已有ml_models.pkl（跳过训练），取消=每次重新训练。状态通过INI配置持久化，重启后自动恢复",
        "• <b>训练数据缓存</b>：已删除training_data.json生成逻辑（纯诊断参考文件，不参与预测计算，占用磁盘空间），仅保留模型文件ml_models.pkl作为缓存",
        "• <b>预测锁定（数据指纹）</b>：_compute_data_fingerprint计算全量数据MD5，指纹相同时禁止重复预测，确保没有新数据就无法预测。ML和算法预测使用独立指纹，类型切换时验证指纹确保缓存结果有效",
        "• <b>生肖组选择</b>：_select_zodiac_group_numbers()将49个数字按(num-1)%12分为12生肖组，每组选最高分数字，取前5组+第1组次高分（允许重复1组），最终6个数字来自5个唯一生肖组。算法预测和ML预测均自动应用此逻辑",
        "• <b>导入统一解析</b>：_parse_import_file()统一处理JSON/CSV/TXT格式导入，字符串数字自动转换为整数",
    ]
    for item in cache_items:
        label = QLabel(item)
        # 缓存机制条目样式：15px字号，灰色文字，上下内边距2px
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        label.setWordWrap(True)
        guide_layout.addWidget(label)

    # 分隔线
    sep = QLabel("")
    sep.setFixedHeight(5)
    guide_layout.addWidget(sep)

    # 逻辑层代码（已从主文件拆出到 lib/）
    post_title = QLabel("<b>📦 逻辑层代码（已从主文件拆出，位于 lib/ 目录）</b>")
    # 子标题样式：13px字号，深灰色文字
    post_title.setStyleSheet("font-size: 15px; color: #2C3E50; padding: 4px 0 0 0;")
    guide_layout.addWidget(post_title)

    post_items = [
        "• <b>DataUtils（lib/data_process.py）</b>：样例数据生成、原始数据解析与格式化",
        "• <b>PredictionAlgorithms（lib/math_algo.py）</b>：23 种预测算法与配套数学工具",
        "• <b>BigDataAnalyzer（lib/math_algo.py）</b>：频率/遗漏/转移三维加权 + 三色波 + numpy/scipy 统计检验",
        "• <b>MLPredictionModel（lib/ml_model.py）</b>：RF/GBC/LR/MLP 四模型训练、评估、预测与模型缓存",
        "• <b>应用入口（run.py）</b>：main() 函数 — QApplication初始化、直接创建主窗口、窗口启动、退出清理",
    ]
    for item in post_items:
        label = QLabel(item)
        # 结构说明列表项样式：13px字号（比正文略小），灰色文字
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        label.setWordWrap(True)
        guide_layout.addWidget(label)

    # 关键可调参数速查表
    param_title = QLabel("<b>🔧 关键可调参数速查表</b>")
    # 参数速查表小节标题样式：14px字号，深灰色文字
    param_title.setStyleSheet("font-size: 15px; color: #2C3E50;")
    guide_layout.addWidget(param_title)

    param_items = [
        "• <b>窗口尺寸</b>：lib/data_process.py → LotteryConfig.WINDOW_MIN_WIDTH / WINDOW_MIN_HEIGHT【可改】",
        "• <b>颜色方案</b>：由 plugins/彩票预测.py 的 _update_stylesheet 统一控制【可改】",
        "• <b>字体大小</b>：lib/data_process.py → LotteryConfig.FONT_SIZES / DEFAULT_FONT_SIZE_KEY【可改】",
        "• <b>号码颜色</b>：lib/data_process.py → LotteryConfig.RED/BLUE/GREEN_NUMBERS【可改】",
        "• <b>生肖配置</b>：lib/data_process.py → LotteryConfig.ZODIAC_CLOCKWISE / NUMBER_GROUPS【可改】",
        "• <b>五行配置</b>：lib/data_process.py → LotteryConfig.NUMBER_ELEMENTS【可改】",
        "• <b>区间划分</b>：lib/data_process.py → LotteryConfig.RANGES【可改】",
        "• <b>算法列表</b>：lib/algorithms.py 注册表（编号/名称/描述/方法/正码数/分类的唯一来源）【可改，新增算法只改这一处】",
        "• <b>模型缓存开关</b>：机器学习预测按钮下方复选框，或 配置.ini → [Display] use_model_cache（True=使用ml_models.pkl跳过训练）",
        "• <b>控件尺寸</b>：TAB/*.py 中的 setMinimumWidth / setMinimumHeight / setSizeAdjustPolicy【可改】",
        "• <b>代码定位</b>：docs/代码修改索引.md（关键词 → 文件 → 行号），代码改动后运行 python docs/生成索引.py 刷新",
        "• <b>按页面定位</b>：索引第七章按选项卡分区，搜页面标题（如「数字选尾」）即可看到该页全部控件、文字关键词、事件方法的文件:行号",
        "• <b>数据库选型</b>：SQLite 存历史记录/配置/预测/存储索引等业务状态；DuckDB 供 [6] 统计图表、[7] 回测/算法对比/命中趋势、[16] 大数据分析与报表导出按窗口取数，并可直接读 CSV/Parquet；不可用时自动回退内存（详见 docs/config.md「各功能数据库使用清单」）",
    ]
    for item in param_items:
        label = QLabel(item)
        # 参数说明列表项样式：13px字号，灰色文字
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        label.setWordWrap(True)
        guide_layout.addWidget(label)

    # 分隔线
    sep2 = QLabel("")
    sep2.setFixedHeight(5)
    guide_layout.addWidget(sep2)

    # 修改建议
    modify_title = QLabel("<b>💡 修改建议</b>")
    # 修改建议小节标题样式：14px字号，深灰色文字
    modify_title.setStyleSheet("font-size: 15px; color: #2C3E50;")
    guide_layout.addWidget(modify_title)

    modify_items = [
        "• <b>调整界面配色</b>：修改 plugins/彩票预测.py 的 _update_stylesheet 样式表",
        "• <b>修改生肖绑定</b>：在「数字与生肖」页面批量设置，或修改 lib/data_process.py → generate_zodiac_binding()",
        "• <b>添加新算法</b>：两处同步 —— lib/math_algo.py 新增 predict_* 方法、lib/algorithms.py 注册表加一条（编号追加到末尾）；下拉框名称/描述、正码数与三处调度自动同步，不再改主窗口",
        "• <b>调整按钮/控件尺寸</b>：在 TAB/*.py 中搜索 setStyleSheet / setMinimumWidth / setMinimumHeight",
        "• <b>修改字体大小</b>：lib/data_process.py → LotteryConfig.DEFAULT_FONT_SIZE_KEY 或 FONT_SIZES 字典",
        "• <b>调整窗口默认大小</b>：lib/data_process.py → WINDOW_MIN_WIDTH / WINDOW_MIN_HEIGHT，初始尺寸在 plugins/彩票预测.py 的 __init__ 中 resize()",
        "• <b>查看具体参数位置</b>：使用 Ctrl+F 搜索【可改】标注，或查 docs/代码修改索引.md",
        "• <b>添加新选项卡</b>：TAB/ 新建 xxx.py，导出 build(host) 并在文件顶部声明 TAB_INFO（title/order/enabled），保存后自动出现在选项卡栏，无需改主窗口",
        "• <b>数据存储模块</b>：TAB/data_storage.py 的 build() 及其 _on_storage_* 系列方法",
        "• <b>存储按钮样式</b>：_get_storage_btn_style 方法，可改颜色参数",
        "• <b>卡片样式</b>：_create_storage_card 方法，图片尺寸/字体/边框等全部标注【可改】",
        "• <b>拖拽提示</b>：_highlight_drop_area 方法，高亮颜色/边框样式可改",
        "• <b>分类列表</b>：categories 列表可增删分类项，格式为 (显示名称, 分类ID)",
        "• <b>存储路径</b>：_get_storage_dir 返回程序目录/系统v7.5/数据存储/，与数据库、INI 同目录",
    ]
    for item in modify_items:
        label = QLabel(item)
        # 修改建议列表项样式：13px字号，灰色文字
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 2px 0;")
        label.setWordWrap(True)
        guide_layout.addWidget(label)

    guide_group.setLayout(guide_layout)
    layout.addWidget(guide_group)

    # ========== 注释总结说明 ==========
    summary_group = QGroupBox("本次注释添加总结")
    # 注释总结GroupBox样式 - 深灰标题系（深灰色标题+灰色边框的分组容器）
    #   结构与版本信息GroupBox相同，标题颜色为深灰色(#2C3E50)
    #   font-size: 16px;            标题字号：16px
    #   font-weight: bold;          标题粗体
    #   color: #2C3E50;             标题颜色：深蓝灰
    #   border: 2px solid #DDDDDD;  边框：2px 浅灰实线
    #   border-radius: 8px;         圆角：8px
    #   margin-top: 12px;           顶部外边距：给浮动标题留空间
    #   padding-top: 12px;          顶部内边距
    #   QGroupBox::title: subcontrol-origin: margin；left: 15px；padding: 0 5px
    summary_group.setStyleSheet("""
        QGroupBox {
            font-size: 16px;
            font-weight: bold;
            color: #2C3E50;
            border: 2px solid #DDDDDD;
            border-radius: 8px;
            margin-top: 12px;
            padding-top: 12px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 15px;
            padding: 0 5px;
        }
    """)
    summary_layout = QVBoxLayout()
    summary_layout.setSpacing(8)

    summary_intro = QLabel("本次给代码添加了详细的中文注释，重点标注了所有<b>【可改】</b>的参数，方便修改代码时快速定位。")
    # 总结引言标签样式：14px字号，深灰色文字
    summary_intro.setStyleSheet("font-size: 15px; color: #2C3E50; padding: 2px 0;")
    summary_intro.setWordWrap(True)
    summary_layout.addWidget(summary_intro)

    # 1. 主窗口初始化
    sec1_title = QLabel("<b>1. 主窗口初始化（LotteryPredictionWindow.__init__）</b>")
    # 章节标题样式：14px字号，蓝色(#3498DB)文字，上下间距4px/2px
    sec1_title.setStyleSheet("font-size: 15px; color: #3498DB; padding: 4px 0 2px 0;")
    summary_layout.addWidget(sec1_title)
    sec1_items = [
        "• 窗口基本设置",
        "• 数据文件路径",
        "• 布局边距和间距",
        "• 各区域字体缩放配置",
        "• 面板尺寸设置（数字面板、生肖面板、五行面板、预测号码球等）",
        "• 预测模式配置（增强模式、反向模式、确定性模式）",
        "• 所有可修改的默认值都标注了【可改】",
    ]
    for item in sec1_items:
        label = QLabel(item)
        # 章节子项样式：13px字号，灰色文字，左侧缩进12px
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 1px 0 1px 12px;")
        label.setWordWrap(True)
        summary_layout.addWidget(label)

    # 2. 全局配置类
    sec2_title = QLabel("<b>2. 全局配置类（LotteryConfig）</b>")
    # 章节标题样式：14px字号，绿色(#2ECC71)文字
    sec2_title.setStyleSheet("font-size: 15px; color: #2ECC71; padding: 4px 0 2px 0;")
    summary_layout.addWidget(sec2_title)
    sec2_items = [
        "• 窗口设置（标题、最小尺寸）",
        "• 字体大小选项",
        "• 颜色方案（纯白主题所有颜色值）",
        "• 号码颜色分组（红波/蓝波/绿波）",
        "• 生肖配置（12生肖顺序、数字分组）",
        "• 五行配置",
        "• 区间划分",
        "• 算法列表（23种算法）",
        "• 所有方法都添加了功能说明和参数说明",
    ]
    for item in sec2_items:
        label = QLabel(item)
        # 章节子项样式：13px字号，灰色文字，左侧缩进12px
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 1px 0 1px 12px;")
        label.setWordWrap(True)
        summary_layout.addWidget(label)

    # 3. 数据存储模块
    sec3_title = QLabel("<b>3. 数据存储模块（_create_data_storage_tab）</b>")
    # 章节标题样式：14px字号，橙色(#E67E22)文字
    sec3_title.setStyleSheet("font-size: 15px; color: #E67E22; padding: 4px 0 2px 0;")
    summary_layout.addWidget(sec3_title)
    sec3_items = [
        "• 拖拽提示条样式",
        "• 左侧分类/标签/统计面板",
        "• 工具栏按钮（上传图片、新建笔记、导入文件）",
        "• 内容显示区（网格/列表视图切换）",
        "• 底部状态栏（全选、删除、视图切换）",
        "• 所有UI尺寸、颜色、文字都标注了【可改】",
    ]
    for item in sec3_items:
        label = QLabel(item)
        # 章节子项样式：13px字号，灰色文字，左侧缩进12px
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 1px 0 1px 12px;")
        label.setWordWrap(True)
        summary_layout.addWidget(label)

    # 4. 数据存储核心方法
    sec4_title = QLabel("<b>4. 数据存储核心方法</b>")
    # 章节标题样式：14px字号，红色(#E74C3C)文字
    sec4_title.setStyleSheet("font-size: 15px; color: #E74C3C; padding: 4px 0 2px 0;")
    summary_layout.addWidget(sec4_title)
    sec4_items = [
        "• <b>_get_storage_btn_style</b>：按钮样式生成",
        "• <b>_get_storage_dir</b>：存储目录获取",
        "• <b>_ensure_storage_dirs</b>：目录创建",
        "• <b>_load_storage_index / _save_storage_index</b>：索引读写",
        "• <b>_sync_storage_files</b>：文件系统同步",
        "• <b>_refresh_storage_display</b>：刷新显示",
        "• <b>_create_storage_card</b>：卡片创建",
        "• <b>_highlight_drop_area</b>：拖拽高亮效果",
        "• <b>_import_image_file / _import_data_file / _import_text_file_as_note</b>：文件导入",
        "• <b>_save_new_note / _update_note</b>：笔记保存与更新",
        "• <b>_on_storage_backup</b>：数据备份",
        "• <b>_on_storage_rename_item</b>：重命名",
        "• <b>_on_storage_paste</b>：粘贴导入",
        "• <b>_on_storage_upload_image</b>：上传图片",
        "• <b>_on_storage_new_note</b>：新建笔记",
        "• <b>_on_storage_import_file</b>：导入文件",
        "• <b>_on_storage_view_item</b>：查看项目",
        "• <b>_on_storage_delete_item</b>：删除项目",
        "• <b>_on_storage_batch_delete</b>：批量删除",
        "• <b>_on_storage_select_all</b>：全选",
        "• <b>_on_storage_search</b>：搜索过滤",
        "• <b>_on_storage_sort_changed</b>：排序切换",
        "• <b>_on_storage_category_changed</b>：分类切换",
        "• <b>_on_storage_tag_changed</b>：标签切换",
        "• <b>_on_storage_item_double_clicked</b>：双击打开",
        "• <b>_on_storage_list_context_menu</b>：右键菜单",
        "• <b>_refresh_grid_view / _refresh_list_view</b>：网格/列表视图刷新",
        "• <b>_toggle_category_panel / _toggle_tag_panel</b>：分类/标签面板显示隐藏",
        "• <b>_update_storage_stats</b>：统计面板更新",
        "• <b>_update_tag_list</b>：标签列表更新",
        "• <b>_format_file_size</b>：文件大小格式化",
        "• <b>_get_filtered_items</b>：过滤后的项目列表",
        "• <b>_handle_dropped_files</b>：拖拽文件处理",
        "• <b>_init_storage_data</b>：存储数据初始化",
        "• <b>_open_file / _view_image / _view_or_edit_note</b>：打开文件/查看图片/编辑笔记",
        "• <b>dragEnterEvent / dragLeaveEvent / dropEvent</b>：拖拽事件响应",
        "• 所有可修改的参数都用 <b>【可改】</b> 标记，搜索\"【可改】\"即可快速定位",
    ]
    for item in sec4_items:
        label = QLabel(item)
        # 章节子项样式：13px字号，灰色文字，左侧缩进12px
        label.setStyleSheet("font-size: 15px; color: #555555; padding: 1px 0 1px 12px;")
        label.setWordWrap(True)
        summary_layout.addWidget(label)

    summary_group.setLayout(summary_layout)
    layout.addWidget(summary_group)

    # 底部拉伸：内容不足一屏时把剩余空白吸到底部，避免分组被纵向拉伸变形
    layout.addStretch()

    # 将内容容器放入滚动区域
    scroll.setWidget(host.notice_container)

    # 创建包装widget（用于外层布局）
    wrapper = QWidget()
    wrapper_layout = QVBoxLayout(wrapper)
    # 包装层边距归零：让滚动区域占满整个选项卡，滚动条贴边显示
    wrapper_layout.setContentsMargins(0, 0, 0, 0)
    wrapper_layout.addWidget(scroll)

    # H54：构建完成后登记原始亮色样式并按当前主题上色（暗色文字不再看不见）
    _register_notice_theme(host)
    return wrapper
