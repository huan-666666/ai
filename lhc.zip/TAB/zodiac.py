# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/zodiac.py - 「数字与生肖」选项卡页面构建模块
===========================================================================
模块职责：
    1. 构建「数字与生肖」选项卡的全部界面控件（标题行、角控件组、号码面板、
       生肖统计表、详情区），并把控件与事件回调挂到主窗口 host 上；
    2. 展示、修改、保存号码→生肖绑定（host.zodiac_binding），并同步到生肖面板、
       统计表与详情文字；
    3. 生肖统计只做只读汇总，不承载任何预测算法。

依赖：
    - UI/UI.py 统一导出的 Qt 控件（禁止在本页直接 import PyQt6）
    - lib/data_process.LotteryConfig：
        ZODIAC_CLOCKWISE        顺时针生肖顺序（菜单顺序与一键应用的排列依据）
        NUMBER_NAMES            号码→生肖的默认映射（类属性，原地 update 后全局生效）
        generate_zodiac_binding 按起始生肖生成 1~49 的全部绑定
        get_number_color        号码波色（红/蓝/绿三色）
    - TAB/widgets.py：v0.0.36 角控件共用逻辑（CORNER_* 常量、make_corner_* 工厂、
      ZodiacNumberPanel、PreserveColorDelegate），本页只调用、不重复定义规格
    - host（LotteryPredictionWindow）提供 _persist_bindings / _save_ini_config /
      _apply_splitter_sizes / _show_panel_settings_dialog 等跨页基础设施

在架构中的位置：
    位于 TAB/ 选项卡界面层，属于“界面构建 + 页面事件”自包含模块（v0.0.28 起）。
    lib/ 只提供常量与配置，本页不导入任何重型计算库；页面间的共享状态
    （生肖绑定、五行绑定）由主窗口统一持有并落盘。

数据流：
    host.zodiac_binding（dict[int, str]，1~49 → 生肖）
        → ZodiacNumberPanel 号码球（update_all_zodiacs 全量 / update_zodiac 单点）
        → refresh_stats() 生肖统计表（每生肖一行，列出归属号码）
        → update_detail() 详情文字（生肖 / 五行 / 波色）
    点击号码 → on_number_clicked() 弹生肖菜单 → set_immediately() 改绑定
        → LotteryConfig.NUMBER_NAMES.update() → host._persist_bindings() 落盘

导出对象：
    TAB_INFO                 选项卡元信息（title / order / enabled）
    install(host)            唯一安装入口：挂事件回调 + 构建页面
    build(host)              仅构建页面（由 install 内部调用）
    refresh_stats / update_detail / on_*   本页事件处理函数（host 由闭包传入）

功能说明：
    构建主窗口「数字与生肖」选项卡的全部界面控件，并挂载到主窗口实例上。

页面布局（v0.0.28）：
    顶部一行：标题 +（默认左移约 300px 的）数字/文字 px + 尺寸 + 起始生肖 + 一键应用 + 恢复默认 + 保存绑定
    左侧：数字与生肖面板（点击任意号码 → 弹出十二生肖菜单，选中即时生效并自动保存）
    右侧：生肖统计概览 + 生肖详情

职责边界（v0.0.28 起本页自包含）：
    - 本模块负责界面构建（布局、控件、初始样式）与全部本页事件（模块函数 + install 绑定）
    - 主窗口 LotteryPredictionWindow 的同名方法仅作兼容转发
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import json  # 作用说明：读写「生肖绑定.json」备份，INI 缺失时回退加载自定义绑定
import os as _os_boot  # 作用说明：仅在直接运行本文件调试时探测 run.py 所在项目根，并判断绑定文件是否存在
import re  # 作用说明：解析批量编辑对话框的号码文本（支持逗号/顿号/空格等分隔符）
import sys as _sys_boot  # 作用说明：把探测到的项目根插入模块搜索路径，保证直接运行时可 import UI/TAB

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QCheckBox, QColor, QComboBox, QCursor, QDialog, QDialogButtonBox, QEvent, QFont, QHBoxLayout, QHeaderView, QLabel, QMenu, QMessageBox, QPushButton, QSpinBox, QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, Qt)  # 作用说明：统一从 UI/UI.py 取 Qt 控件与枚举，本页不直接 import PyQt6
from lib.data_process import (LotteryConfig, binding_from_groups, validate_zodiac_groups, zodiac_binding_groups)  # 作用说明：提供顺时针生肖顺序、默认生肖映射、绑定生成函数与号码波色；三个纯函数负责批量编辑的校验与展开
from TAB.widgets import (AttributeMatrixPanel, CORNER_SECTION_GAP, PreserveColorDelegate,  # 作用说明：提供属性矩阵面板、12 生肖高亮条、表格委托与 v0.0.36 角控件统一规格
                         ZodiacHighlightBar, add_corner_widget, make_corner_container,
                         make_corner_label, make_corner_size_button, open_panel_size_dialog,
                         style_corner_spin)


# 生肖顺序与统计表配色（生肖统计概览用）
ZODIAC_LIST = ["鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪"]
ZODIAC_COLORS = {
    "鼠": "#3498DB", "牛": "#27AE60", "虎": "#E74C3C", "兔": "#F39C12",
    "龙": "#9B59B6", "蛇": "#1ABC9C", "马": "#E67E22", "羊": "#2ECC71",
    "猴": "#3498DB", "鸡": "#F1C40F", "狗": "#95A5A6", "猪": "#E91E63",
}

# 右侧生肖统计表：字号统一 15px（全局最小可读字号），行高 34px 保证
# 15px 字形（QFontMetrics 高度约 20px）上下不压字。两列均走这一规格。
STATS_ITEM_FONT_PX = 15
STATS_ROW_HEIGHT = 34


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "数字与生肖",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 10,  # 显示顺序，数字小的排前面
    "enabled": False,  # 三页合并：本页已由「号码属性表」替代，保留文件便于一键回滚
}


# 属性矩阵接入：旧 INI 尺寸一次性迁移
# 旧 ZodiacNumberPanel 的出厂值是 80×60 / 20 / 20；新矩阵紧凑档为 90×98 / 28/15。
# 只在「值仍等于旧出厂默认」时迁移一次，并把标记键写进内存中的 [Display]；
# 主窗口 _save_ini_config 的 setdefault 回填逻辑会把它落盘（写盘闸门不变）。
ATTR_MATRIX_INI_SECTION = 'Display'
ATTR_MATRIX_INI_KEY = 'attr_matrix_v1'
ATTR_MATRIX_LEGACY_SIZE = (80, 60, 20, 20)
ATTR_MATRIX_DEFAULT_SIZE = (90, 98, 28, 15)


def migrate_attr_matrix_size(host):
    """把旧生肖面板尺寸一次性迁移到属性矩阵默认值（只改内存）

    功能:
        在用户未自定义的前提下，把旧生肖面板出厂尺寸组合一次性改写为属性
        矩阵默认尺寸，并在内存中写入迁移标记，避免下次启动重复迁移。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；读取 _zodiac_panel_size 与 _ini。
    返回:
        bool: True=本次执行了迁移；False=已有标记或值不是旧出厂默认。
    副作用:
        原地修改 host._zodiac_panel_size 的 width/height/btn_font/label_font；
        在 host._ini['Display'] 写入 attr_matrix_v1=1（内存），不直接写文件。
    说明:
        - 防重复迁移用「标记键 + 旧值精确匹配」双保险：即使标记尚未落盘，
          迁移后的 90/98/28/15 也不再等于旧出厂组合，不会二次改写；
        - 旧组合允许 label_font 为 20 或 15：本项目早期已把全局最小字号抬到 15，
          实际用户 INI 常见 80×60/20/15，只要宽高与号码字号仍是旧出厂值就迁移；
        - 只认旧出厂组合，用户曾自定义过的尺寸/字号保持不动（按显式定制处理）。
    """
    size = getattr(host, '_zodiac_panel_size', None)
    if not isinstance(size, dict):
        return False
    ini = getattr(host, '_ini', None)
    marker = False
    if ini is not None:
        try:
            marker = str(ini.get(ATTR_MATRIX_INI_SECTION, ATTR_MATRIX_INI_KEY,
                                 fallback='')).strip() == '1'
        except Exception:
            marker = False
    try:
        current = (int(size.get('width')), int(size.get('height')),
                   int(size.get('btn_font')), int(size.get('label_font')))
    except (TypeError, ValueError):
        return False
    is_legacy = (
        current[0] == ATTR_MATRIX_LEGACY_SIZE[0]
        and current[1] == ATTR_MATRIX_LEGACY_SIZE[1]
        and current[2] == ATTR_MATRIX_LEGACY_SIZE[2]
        and current[3] in (15, ATTR_MATRIX_LEGACY_SIZE[3])
    )
    if marker or not is_legacy:
        return False

    size['width'], size['height'], size['btn_font'], size['label_font'] = ATTR_MATRIX_DEFAULT_SIZE
    if ini is not None:
        if not ini.has_section(ATTR_MATRIX_INI_SECTION):
            ini.add_section(ATTR_MATRIX_INI_SECTION)
        ini.set(ATTR_MATRIX_INI_SECTION, ATTR_MATRIX_INI_KEY, '1')
        # 同步 [WidgetState] 里两个字号 spin 的恢复值，避免启动后「框里 20、实际 28」
        try:
            if ini.has_section('WidgetState'):
                ini.set('WidgetState', 's_zodiac_num_font_spin', '28')
                ini.set('WidgetState', 's_zodiac_text_font_spin', '15')
        except Exception:
            pass
    print("生肖面板尺寸一次性迁移：80×60 / 20 → 90×98 / 28/15（仅内存，写盘走既有闸门）")
    return True


def _sync_matrix_data(host):
    """把 host 上的生肖/五行绑定同步到矩阵与生肖条（页面刷新链路共用）

    功能:
        把 host.zodiac_binding / zodiac_elements 全量灌入属性矩阵，并让矩阵
        按生肖条当前选中项重新计算高亮，同时刷新生肖条的悬停提示数据。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
    返回:
        None
    注意:
        仅做同步，不写盘、不改绑定；控件缺失或类型不符时静默跳过，保证首屏
        尚未构建控件的时机也能安全调用。
    说明:
        整页刷新、切回本页、单号改绑后都走这里，确保矩阵不会显示过期数据；
        高亮目标取自生肖条当前选中项，绑定变化后重新评估命中集合。
    """
    panel = getattr(host, 'zodiac_panel', None)
    bar = getattr(host, 'zodiac_highlight_bar', None)
    if isinstance(panel, AttributeMatrixPanel):
        panel.set_zodiac_binding(getattr(host, 'zodiac_binding', {}) or {})
        panel.set_elements(getattr(host, 'zodiac_elements', {}) or {})
        active = bar.active_zodiac() if isinstance(bar, ZodiacHighlightBar) else None
        panel.set_highlight_zodiac(active)
    if isinstance(bar, ZodiacHighlightBar):
        bar.refresh_binding(getattr(host, 'zodiac_binding', {}) or {})


def _sync_highlight_after_binding(host):
    """绑定变化后刷新生肖条 tooltip，并按当前选中生肖重新评估矩阵高亮

    功能:
        绑定数据变化后刷新 12 生肖条的悬停提示，并把当前选中生肖重新交给
        属性矩阵，使命中集合与淡出状态对应新的绑定。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
    返回:
        None
    注意:
        只更新显示态，不修改绑定、不写盘；生肖条或矩阵缺失时按类型判断跳过。
    说明:
        单号改绑/一键应用/恢复默认都会改变「某生肖包含哪些号码」与命中集合；
        这里同时刷新悬停提示和高亮态，保证淡出状态不会停留在旧卡上。
    """
    bar = getattr(host, 'zodiac_highlight_bar', None)
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(bar, ZodiacHighlightBar):
        bar.refresh_binding(getattr(host, 'zodiac_binding', {}) or {})
    _refresh_clockwise_hint(host)
    if isinstance(panel, AttributeMatrixPanel):
        active = bar.active_zodiac() if isinstance(bar, ZodiacHighlightBar) else None
        panel.set_highlight_zodiac(active)


def _sync_matrix_theme(host, page):
    """把主窗口当前亮/暗主题同步到矩阵与生肖条（主题切换链路）

    功能:
        读取 host.is_dark_mode，把亮/暗模式下发给属性矩阵与 12 生肖高亮条，
        并用 page._last_dark 记录上次主题，避免同一主题重复刷新。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        page (_ZodiacPage): 本页根控件，用 _last_dark 防重复刷新。
    返回:
        None
    注意:
        仅做样式同步，不写盘；主题未变化且已初始化时直接返回，控件缺失时跳过。
    说明:
        主窗口切换主题走 _update_stylesheet()，Qt 会给子树派发 StyleChange；
        页面在 changeEvent 中调用本函数，因此无需修改主窗口主题切换代码。
    """
    dark = bool(getattr(host, 'is_dark_mode', False))
    if getattr(page, '_last_dark', None) == dark and getattr(page, '_theme_inited', False):
        return
    page._last_dark = dark
    page._theme_inited = True
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(panel, AttributeMatrixPanel):
        panel.set_dark_mode(dark)
    bar = getattr(host, 'zodiac_highlight_bar', None)
    if isinstance(bar, ZodiacHighlightBar):
        bar.set_dark_mode(dark)


def _clockwise_order(zodiac_binding):
    """按 01 号生肖旋转顺时针序列，得到表头 12 格顺序"""
    base = list(LotteryConfig.ZODIAC_CLOCKWISE)
    start = (zodiac_binding or {}).get(1)
    if start in base:
        index = base.index(start)
        return base[index:] + base[:index]
    return base


def _clockwise_hint_text(zodiac_binding):
    """顺时针提示文案：与表头顺序同源，避免提示与实际排列不一致"""
    return ("点击上方生肖 → 高亮该生肖号码（再点一次取消）；"
            "点击任意号码 → 弹出十二生肖菜单 → 选中即时生效（自动保存，无需重启）；"
            "顺时针: " + " → ".join(_clockwise_order(zodiac_binding)))


def _refresh_clockwise_hint(host):
    """绑定变化后刷新顺时针提示（表头顺序同步变化）"""
    label = getattr(host, 'zodiac_hint_label', None)
    if isinstance(label, QLabel):
        label.setText(_clockwise_hint_text(getattr(host, 'zodiac_binding', {}) or {}))


def _on_highlight_selected(host, text):
    """生肖条点击回调：高亮命中的号码卡，空字符串表示取消

    功能:
        接收生肖条选中的生肖名（空串表示取消），同步给属性矩阵与生肖条，
        让矩阵只高亮该生肖包含的号码卡。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        text (str): 生肖名；'' 表示再次点击同一格后的取消。
    返回:
        None
    注意:
        只改变高亮显示，不修改绑定、不写盘；text 为空时按 None 传给矩阵表示取消。
    说明:
        生肖条已自行更新选中态；这里只把选择转交矩阵，双击同一条目即恢复全亮。
    """
    name = text or None
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(panel, AttributeMatrixPanel):
        panel.set_highlight_zodiac(name)
    bar = getattr(host, 'zodiac_highlight_bar', None)
    if isinstance(bar, ZodiacHighlightBar):
        bar.set_active_zodiac(name)


class _ZodiacPage(QWidget):
    """生肖页根控件：在切换主题/切回本页时同步矩阵，避免显示过期数据

    职责:
        - changeEvent 捕获 StyleChange → 跟随主窗口亮/暗主题；
        - showEvent 重新读取 host.zodiac_binding / zodiac_elements
          （例如五行页保存了新的五行映射后切回本页，矩阵胶囊不过期）。
    约束:
        只做同步，不创建控件、不改业务数据、不写盘。
    """

    def __init__(self, host, parent=None):
        """记录 host 与初始主题

        功能:
            保存主窗口引用，并按 host.is_dark_mode 记录初始主题与“已初始化”
            标记，供后续 showEvent / changeEvent 判断是否需要重刷。

        参数:
            host (LotteryPredictionWindow): 主窗口实例。
            parent (QWidget | None): Qt 父控件。
        返回:
            无。
        注意:
            只保存引用与主题快照，不创建控件、不改业务数据、不写盘。
        """
        super().__init__(parent)
        self._host = host
        self._last_dark = bool(getattr(host, 'is_dark_mode', False))
        self._theme_inited = True

    def showEvent(self, event):
        """切回本页时同步主题与绑定数据

        功能:
            页面每次显示时先跟随主窗口亮/暗主题，再从 host 重新读取生肖/五行
            绑定灌入矩阵与生肖条，最后校正统计表列宽，避免显示过期数据。

        参数:
            event (QShowEvent): Qt 显示事件。
        返回:
            无。
        注意:
            只读 host 数据并刷新显示，不写盘；先调用父类实现保证 Qt 默认行为。
        """
        super().showEvent(event)
        _sync_matrix_theme(self._host, self)
        _sync_matrix_data(self._host)
        self._normalize_stats_columns()

    def _normalize_stats_columns(self):
        """切回本页时校正统计表列宽（主窗口会恢复 [WidgetState] 旧列宽）

        功能:
            把生肖统计表第 0 列（生肖）限制在 82px 固定宽，第 1 列（包含
            数字）改为拉伸，避免旧 INI 的宽列把号码列挤出视口。

        参数:
            无。
        返回:
            无。
        注意:
            仅当生肖列宽度大于 120px 时才校正；用户手动拖到 ≤120px 的设置
            不会被覆盖。统计表尚未构建时直接返回，不抛异常。
        说明:
            旧 INI 里的 zodiac_stats_table 列宽是按「右侧 390px」时期保存的
            （常见 255/383），左栏接入 12 列矩阵后右侧仅 ~230px，直接恢复会把
            「包含数字」列推到视口外。这里只在生肖列明显过宽时改回 82px，
            用户手动拖到 ≤120px 的设置不会被覆盖。
        """
        table = getattr(self._host, 'zodiac_stats_table', None)
        if table is None:
            return
        if table.columnWidth(0) <= 120:
            return
        header = table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        table.setColumnWidth(0, 82)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)

    def changeEvent(self, event):
        """主题样式变化时把亮/暗模式同步给矩阵与生肖条

        功能:
            Qt 派发 StyleChange（主窗口切换主题或全局样式表变化）时，把当前
            亮/暗模式重新下发给属性矩阵与 12 生肖高亮条。

        参数:
            event (QEvent): Qt 变更事件。
        返回:
            无。
        注意:
            仅处理 StyleChange 类型，其余事件原样交给父类；只改显示样式，
            不改绑定、不写盘。
        """
        if event.type() == QEvent.Type.StyleChange:
            _sync_matrix_theme(self._host, self)
        super().changeEvent(event)


def _build_font_controls(host, layout):
    """构建右上角「数字 px / 文字 px / 尺寸」控件组（v0.0.36 统一规格）

    功能:
        在标题行最右侧放一组等高控件：数字字号框、文字字号框与「尺寸」按钮。
        两个字号框独立控制生肖面板的号码字号与生肖标签字号，互不影响。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。本函数在其上创建
            host.zodiac_num_font_spin 与 host.zodiac_text_font_spin 两个 QSpinBox；
            两个框的 valueChanged 会触发 install() 预先挂好的回调。
        layout (QHBoxLayout): 顶部标题行布局；控件组作为整体从右端加入。

    返回:
        None（控件通过 host 属性与 layout 生效）。

    副作用:
        创建 Qt 控件并挂到 host；初始值读取 host._zodiac_panel_size 的
        btn_font / label_font；用户改值时触发字体变更回调（不会在构建期触发）。

    说明:
        v0.0.36：改用 TAB/widgets.py 的统一规格——控件高 40px、组内间距 6px、
        数字组与文字组之间 12px、距右边缘 8px、字号 15px，四个页面完全一致。
        统一由 AlignVCenter 排布，避免「尺寸」按钮比同排控件偏低的错位问题。
        为什么字号下限锁 15px：15px 是全局最小可读字号，再小在高 DPI 屏上会
        难以辨认；两个输入框的初值分别取各自配置项，避免数字/文字互相覆盖。
    """
    box, box_layout = make_corner_container()

    # 数字字号标签 + 输入框（蓝色主题，控制生肖面板里的号码字号）
    add_corner_widget(box_layout, make_corner_label("数字:", "#1565C0"))

    host.zodiac_num_font_spin = QSpinBox()
    host.zodiac_num_font_spin.setRange(15, 150)  # 下限 15px：与全局最小字号一致
    host.zodiac_num_font_spin.setValue(host._zodiac_panel_size.get('btn_font', 28))  # 默认28px（矩阵号码）
    host.zodiac_num_font_spin.setSuffix(" px")
    host.zodiac_num_font_spin.setToolTip("调整属性矩阵卡片号码字体大小\n（独立控制，不影响生肖/五行属性胶囊）")
    style_corner_spin(host.zodiac_num_font_spin, "#90CAF9")
    host.zodiac_num_font_spin.valueChanged.connect(host._on_zodiac_num_font_changed)
    add_corner_widget(box_layout, host.zodiac_num_font_spin)

    box_layout.addSpacing(CORNER_SECTION_GAP)  # 数字组与文字组之间留 12px，避免拥挤

    # 文字字号标签 + 输入框（紫色主题，控制生肖标签字号）
    add_corner_widget(box_layout, make_corner_label("文字:", "#7B1FA2"))

    host.zodiac_text_font_spin = QSpinBox()
    host.zodiac_text_font_spin.setRange(15, 150)  # 下限 15px：与全局最小字号一致
    host.zodiac_text_font_spin.setValue(host._zodiac_panel_size.get('label_font', 15))  # 默认15px（属性胶囊）
    host.zodiac_text_font_spin.setSuffix(" px")
    host.zodiac_text_font_spin.setToolTip("调整属性矩阵生肖/五行胶囊文字大小\n（独立控制，不影响号码）")
    style_corner_spin(host.zodiac_text_font_spin, "#CE93D8")
    host.zodiac_text_font_spin.valueChanged.connect(host._on_zodiac_text_font_changed)
    add_corner_widget(box_layout, host.zodiac_text_font_spin)

    # 「尺寸」按钮：68×40，与同排标签/输入框同一水平基线
    add_corner_widget(box_layout, make_corner_size_button(
        lambda: show_panel_settings_dialog(host), "调整面板尺寸设置"))

    layout.addWidget(box)


def refresh_stats(host):
    """刷新生肖统计概览表格

    功能:
        按 host.zodiac_binding 把 1~49 号码归类到十二生肖，重写统计表两列：
        第 0 列生肖名（加粗、按 ZODIAC_COLORS 着色），第 1 列归属号码（两位空格分隔）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备 zodiac_binding 与
            zodiac_stats_table（后者由 build() 创建）。

    返回:
        None

    副作用:
        重设 host.zodiac_stats_table 行数并逐格 setItem；旧单元格项由 Qt 释放，
        表格滚动位置可能随内容重建而复位。

    说明:
        为什么号码用 zfill(2)：与号码面板/开奖记录统一成 01~49 两位显示，便于对齐；
        表格设为 NoEditTriggers，并挂 PreserveColorDelegate 保留自定义文字色，
        因为默认委托在选中行时会把前景色统一改成高对比色，冲掉生肖配色。
    """
    zodiac_nums = {}
    for z in ZODIAC_LIST:
        zodiac_nums[z] = []

    for num in range(1, 50):
        zodiac = host.zodiac_binding.get(num, "")
        if zodiac in zodiac_nums:
            zodiac_nums[zodiac].append(num)

    host.zodiac_stats_table.setRowCount(len(ZODIAC_LIST))
    # 单元格字体：用 setPixelSize(15) 显式锁定像素字号（QFont 的第二参数是
    # 磅值，13/11 磅在不同 DPI 下像素高度不稳定，不能满足 15px 验收口径）。
    stats_font = QFont("Arial")
    stats_font.setPixelSize(STATS_ITEM_FONT_PX)
    stats_bold_font = QFont(stats_font)
    stats_bold_font.setWeight(QFont.Weight.Bold)
    for i, z in enumerate(ZODIAC_LIST):
        zodiac_item = QTableWidgetItem(z)
        zodiac_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        zodiac_item.setFont(stats_bold_font)
        zodiac_item.setForeground(QColor(ZODIAC_COLORS.get(z, "#333333")))
        host.zodiac_stats_table.setItem(i, 0, zodiac_item)

        nums_str = "  ".join(str(n).zfill(2) for n in zodiac_nums[z])
        nums_item = QTableWidgetItem(nums_str)
        nums_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        nums_item.setFont(stats_font)
        nums_item.setForeground(QColor("#333333"))
        host.zodiac_stats_table.setItem(i, 1, nums_item)


def update_detail(host, num):
    """更新生肖详情标签（号码 → 生肖 / 五行 / 颜色）

    功能:
        把单个号码的生肖、五行与波色拼成一行文字写入详情标签。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备 zodiac_binding、
            zodiac_elements、zodiac_detail_label。
        num (int): 1~49 的号码；越界时各查表返回空串/兜底配色，不抛异常。

    返回:
        None

    副作用:
        覆盖 host.zodiac_detail_label 的文本，不刷新号码面板与统计表，
        也不写盘（调用方负责按需保存）。

    说明:
        为什么按色值反推颜色名：LotteryConfig.get_number_color 只返回 RGB 色值，
        没有“红/蓝/绿”名称字段；这里按文字色 #FF0000 / #0000FF / 其余归绿，
        与数字选择页把未填写号码按色值归组的规则保持一致。
    """
    zodiac = host.zodiac_binding.get(num, "")
    element = host.zodiac_elements.get(num, "")
    colors = LotteryConfig.get_number_color(num)
    color_name = "红色" if colors['text'] == '#FF0000' else ("蓝色" if colors['text'] == '#0000FF' else "绿色")
    host.zodiac_detail_label.setText(
        "数字 " + str(num).zfill(2) + " ｜ 生肖：" + zodiac + " ｜ 五行：" + element + " ｜ 颜色：" + color_name
    )


def on_number_clicked(host, num):
    """点击号码 → 弹出十二生肖菜单，选中即时写入

    功能:
        在鼠标当前位置弹出十二生肖菜单，当前绑定项前加 ✓；选中后立即改绑定。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        num (int): 被点击的号码（1-49）。

    返回:
        None

    副作用:
        以模态方式执行 QMenu.exec()（阻塞到菜单关闭）；用户选择时经
        host._set_zodiac_immediately 触发绑定修改、统计/详情刷新与落盘。

    说明:
        菜单顺序取 LotteryConfig.ZODIAC_CLOCKWISE，与「一键应用」的顺时针规则同源，
        避免两个入口给出不同的生肖排列。lambda 用默认参数 zz=z 固定当前循环值：
        若直接引用 z，所有菜单项会共享循环结束后的最后一个生肖。
    """
    menu = QMenu(host)
    current = host.zodiac_binding.get(num, "")
    for z in LotteryConfig.ZODIAC_CLOCKWISE:
        action = menu.addAction(("✓ " if z == current else "") + z)
        action.triggered.connect(lambda checked=False, zz=z: host._set_zodiac_immediately(num, zz))
    menu.exec(QCursor.pos())


def set_immediately(host, num, zodiac):
    """把单个号码设为指定生肖，并立即保存、全局生效

    功能:
        单点修改 host.zodiac_binding[num]，同步号码球、统计表、详情与全局常量。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        num (int): 号码（1-49）。
        zodiac (str): 目标生肖名（来自 ZODIAC_CLOCKWISE）。

    返回:
        None

    副作用:
        原地修改 host.zodiac_binding；调用 zodiac_panel.update_zodiac() 只重绘该球；
        重建统计表、更新详情文字；更新 LotteryConfig.NUMBER_NAMES（类属性，全局生效）；
        写 JSON/INI；最后用“已即时生效并自动保存”的提示覆盖详情文字。

    说明:
        只刷单个号码球而不是 update_all_zodiacs，是为了避免 49 个按钮全部重排，
        滚动位置也不会跳；NUMBER_NAMES 必须在 _persist_bindings 之前更新，
        否则保存的仍是旧映射。
    """
    host.zodiac_binding[num] = zodiac
    if getattr(host, 'zodiac_panel', None):
        host.zodiac_panel.update_zodiac(num, zodiac)
    _sync_highlight_after_binding(host)
    refresh_stats(host)
    update_detail(host, num)
    LotteryConfig.NUMBER_NAMES.update(host.zodiac_binding)
    host._persist_bindings()
    refresh_integrity(host)
    host.zodiac_detail_label.setText(
        "数字 " + str(num).zfill(2) + " → " + zodiac + "（已即时生效并自动保存）"
    )


def on_save(host):
    """手动保存生肖绑定到文件并全局生效

    功能:
        把 host.zodiac_binding 同步进 LotteryConfig.NUMBER_NAMES 后落盘，
        并顺带刷新五行页的分组条（两页共享同一份生肖/五行数据）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None

    副作用:
        更新类属性 LotteryConfig.NUMBER_NAMES；写 JSON/INI；
        若五行页已构建则调用 host._refresh_element_stats()；
        成功/失败分别弹 information / warning 消息框。

    异常:
        保存过程中的任何异常都在函数内捕获并转成 warning 弹窗，不向调用方抛出。

    说明:
        即时生效路径（set_immediately）用详情文字反馈、不弹窗；本函数由“保存绑定”
        按钮显式触发，用户需要明确的成功反馈，因此保留模态消息框。
    """
    try:
        LotteryConfig.NUMBER_NAMES.update(host.zodiac_binding)
        host._persist_bindings()
        refresh_integrity(host)
        if getattr(host, 'element_row_buttons', None):
            host._refresh_element_stats()
        QMessageBox.information(host, "成功", "生肖绑定已保存并全局生效")
    except Exception as e:
        QMessageBox.warning(host, "错误", "保存生肖绑定时出错:\n" + str(e))


def on_start_changed(host, text):
    """起始生肖下拉变更：不自动应用，但立即记住选择

    功能:
        记录用户选择的起始生肖，供下次启动恢复；不触发绑定重排。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        text (str): 新的起始生肖文本（Qt 信号携带；本函数实际从 combo 读取）。

    返回:
        None

    副作用:
        调用 host._save_ini_config() 立即写 INI。

    说明:
        为什么不在下拉变更时自动应用：起始生肖会重排 1~49 的全部绑定，
        误触下拉就全量改写风险太大，必须由「一键应用」按钮显式确认。
    """
    host._save_ini_config()


def on_apply_start(host):
    """一键应用起始生肖：按顺时针生成全部绑定并自动保存

    功能:
        以当前下拉选中的生肖为起点，重新生成 1~49 的完整生肖绑定。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备 start_zodiac_combo。

    返回:
        None

    副作用:
        覆盖 host.zodiac_binding（包括用户手工调整的单点绑定）；全量刷新号码面板；
        重建统计表；更新 LotteryConfig.NUMBER_NAMES；写盘；改详情提示文字。

    说明:
        生成规则来自 LotteryConfig.generate_zodiac_binding：起始生肖对应
        n%12==1 的那组号码（01、13、25、37、49），之后每 12 个号码按
        ZODIAC_CLOCKWISE 顺延一位。提示文字里的 {01,13,25,37,49} 是该规则的
        固定结果，因此无需按起始生肖动态拼接。
    """
    start_zodiac = host.start_zodiac_combo.currentText()
    binding = LotteryConfig.generate_zodiac_binding(start_zodiac)
    _commit_binding(
        host, binding,
        "已应用：" + start_zodiac + "={01,13,25,37,49}，其余按顺时针排列（已自动保存）")


def on_reset(host):
    """恢复默认生肖绑定（龙 = 01,13,25,37,49），不改动五行

    功能:
        二次确认后，把生肖绑定恢复为以“龙”为起始的默认排列。
        本轮已确认：恢复默认只重置生肖，host.zodiac_elements 一行都不动。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None

    副作用:
        仅当用户点“是”时：覆盖 host.zodiac_binding；下拉框回到“龙”；
        全量刷新本页号码面板与统计表；更新 NUMBER_NAMES；写盘；改详情提示。
        点“否”时不做任何修改；不触碰 zodiac_elements，也不刷新五行页。

    说明:
        下拉框用 blockSignals 包裹，避免 setCurrentText 触发 on_start_changed
        造成一次多余的 INI 写盘；最终只由 _commit_binding 里的
        _persist_bindings() 统一落盘。
    """
    reply = QMessageBox.question(
        host, "确认",
        "确定恢复默认的生肖绑定吗？\n（仅重置生肖，不会改动五行绑定）",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    if reply == QMessageBox.StandardButton.Yes:
        host.start_zodiac_combo.blockSignals(True)
        host.start_zodiac_combo.setCurrentText("龙")
        host.start_zodiac_combo.blockSignals(False)
        binding = LotteryConfig.generate_zodiac_binding("龙")
        _commit_binding(host, binding, "已恢复默认生肖绑定（龙=01,13,25,37,49）")


def refresh_integrity(host):
    """刷新「完整性自检」标签（只读展示，不修改绑定、不写盘）

    功能:
        用 zodiac_binding_groups + validate_zodiac_groups 检查当前 49 条绑定，
        把结果写到 host.zodiac_integrity_label：
        - 覆盖性不通过（缺失/重复/越界/空生肖）→ 红色，提示未通过；
        - 覆盖通过但数量不是 5+4×11 → 橙色，提示“数量非标准（已按实际保存）”；
        - 全部通过 → 绿色。
        完整问题清单放在标签 tooltip 中，避免长文本撑高页面。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备 zodiac_binding；
            标签未构建时静默返回。

    返回:
        list[str]: 标准校验（严格 5+4×11）的问题清单；空列表表示通过。

    副作用:
        仅改标签文本/样式/tooltip，不写盘。
    """
    label = getattr(host, 'zodiac_integrity_label', None)
    if not isinstance(label, QLabel):
        return []
    binding = getattr(host, 'zodiac_binding', {}) or {}
    groups = zodiac_binding_groups(binding)
    coverage_issues = validate_zodiac_groups(groups, allow_nonstandard_counts=True)
    strict_issues = validate_zodiac_groups(groups)

    if coverage_issues:
        label.setText("完整性自检：未通过（" + str(len(coverage_issues)) + " 项问题，悬停查看详情）")
        label.setStyleSheet("QLabel { font-size: 15px; color: #C0392B; padding: 2px 5px; }")
        label.setToolTip("\n".join(coverage_issues))
        return strict_issues

    if strict_issues:
        detail = '、'.join(z + ' ' + str(len(groups.get(z, []))) for z in ZODIAC_LIST)
        label.setText("完整性自检：覆盖通过（49/49），但数量非标准：" + detail + "（已按实际绑定保存）")
        label.setStyleSheet("QLabel { font-size: 15px; color: #E67E22; padding: 2px 5px; }")
        label.setToolTip("\n".join(strict_issues))
        return strict_issues

    counts = {z: len(groups.get(z, [])) for z in LotteryConfig.ZODIAC_CLOCKWISE}
    five_names = [z for z, count in counts.items() if count == 5]
    owner = five_names[0] if five_names else ''
    label.setText("完整性自检：通过（49/49；" + owner + " 5 个，其余各 4 个）")
    label.setStyleSheet("QLabel { font-size: 15px; color: #27AE60; padding: 2px 5px; }")
    label.setToolTip("")
    return []


def _commit_binding(host, binding, detail_text, *, persist=True, allow_nonstandard=False):
    """把一份完整绑定统一写回界面、全局常量与磁盘

    功能:
        所有全量改绑入口（一键应用 / 恢复默认 / 批量编辑）的唯一提交点，
        保证“先校验 → 再改内存 → 刷新面板与统计 → 更新 NUMBER_NAMES →
        最后落盘”的顺序一致，避免各入口漏刷或先落盘后改内存。

    参数:
        host: 主窗口实例；
        binding (dict): 完整 49 条绑定（号码→生肖）；
        detail_text (str): 写进 zodiac_detail_label 的结果提示；
        persist (bool): 是否调用 host._persist_bindings()，默认 True；
        allow_nonstandard (bool): 是否允许数量非标准（仅批量编辑勾选时传 True）；
            覆盖性（12 生肖齐全、1–49 不重不漏）永远不放宽。

    返回:
        bool: True 表示已提交；False 表示校验未通过、未做任何修改。

    副作用:
        修改 host.zodiac_binding、重绘面板、刷新统计/高亮/提示/完整性标签，
        更新 LotteryConfig.NUMBER_NAMES；persist=True 时写 JSON/INI/DB 镜像。
        不触碰 host.zodiac_elements。
    """
    groups = zodiac_binding_groups(binding)
    issues = validate_zodiac_groups(groups, allow_nonstandard_counts=allow_nonstandard)
    if issues:
        return False
    host.zodiac_binding = dict(binding)
    if getattr(host, 'zodiac_panel', None):
        host.zodiac_panel.update_all_zodiacs(host.zodiac_binding)
    _sync_highlight_after_binding(host)
    refresh_stats(host)
    refresh_integrity(host)
    LotteryConfig.NUMBER_NAMES.update(host.zodiac_binding)
    if persist:
        host._persist_bindings()
    host.zodiac_detail_label.setText(detail_text)
    return True


def _parse_numbers_cell(text):
    """解析对话框一行的号码文本 → (号码列表, 行内问题列表)

    功能:
        支持逗号、中文逗号、顿号、分号、斜杠、空格等分隔符；非数字/越界号码
        转为可读问题，不抛异常。重复号码交给全局校验统一报告。

    参数:
        text (str): 用户在“号码”列输入的内容。
    返回:
        tuple[list[int], list[str]]: (号码列表, 行内问题列表)。
    """
    text = str(text or '').strip()
    if not text:
        return [], []
    tokens = [token for token in re.split(r'[,\uFF0C\u3001;；/\\\s]+', text) if token]
    numbers = []
    issues = []
    for token in tokens:
        if not token.isdigit():
            issues.append("无法识别“" + token + "”")
            continue
        number = int(token)
        if number < 1 or number > 49:
            issues.append("号码 " + token + " 超出 1–49")
            continue
        numbers.append(number)
    return numbers, issues


def _collect_batch_groups(table):
    """从 12 行表格收集「生肖 → 号码列表」与解析问题"""
    groups = {}
    issues = []
    for row in range(table.rowCount()):
        zodiac_item = table.item(row, 0)
        number_item = table.item(row, 1)
        zodiac = zodiac_item.text() if zodiac_item is not None else ''
        numbers, row_issues = _parse_numbers_cell(number_item.text() if number_item is not None else '')
        groups[zodiac] = numbers
        for message in row_issues:
            issues.append(zodiac + "：" + message)
    return groups, issues


def _refresh_batch_validation(table, status_label, ok_button, allow_checkbox, mark_rows=False):
    """重新计算批量编辑对话框的校验结果并刷新 UI

    功能:
        汇总行内解析问题与 validate_zodiac_groups 的全量问题；更新每行“个数/状态”，
        启用或禁用确定按钮，并把摘要写成绿/橙/红三态：
        - 有问题 → 红色，列出前几条；
        - 勾选“允许非标准数量”且覆盖通过 → 橙色，展示实际数量分配与标准口径；
        - 未勾选且通过 → 绿色“校验通过”。

    参数:
        table (QTableWidget): 12 行 × 4 列编辑表；
        status_label (QLabel): 底部摘要；
        ok_button (QPushButton): 确定按钮；
        allow_checkbox (QCheckBox): “允许非标准数量”复选框；
        mark_rows (bool): 是否同时刷新“个数/状态”列（编辑时 True，纯重算时 False）。

    返回:
        list[str]: 当前全部问题；空列表表示可保存。
    """
    groups, parse_issues = _collect_batch_groups(table)
    allow_nonstandard = bool(allow_checkbox.isChecked())
    issues = list(parse_issues)
    issues += validate_zodiac_groups(groups, allow_nonstandard_counts=allow_nonstandard)

    if mark_rows:
        table.blockSignals(True)
        for row in range(table.rowCount()):
            number_item = table.item(row, 1)
            numbers, row_issues = _parse_numbers_cell(number_item.text() if number_item is not None else '')
            if table.item(row, 2) is not None:
                table.item(row, 2).setText(str(len(numbers)))
            if table.item(row, 3) is not None:
                state = '✗ 格式/越界' if row_issues else ('✗ 空' if not numbers else '✓')
                table.item(row, 3).setText(state)
                table.item(row, 3).setForeground(QColor('#C0392B' if row_issues or not numbers else '#27AE60'))
        table.blockSignals(False)

    ok_button.setEnabled(not issues)
    if issues:
        preview = "；".join(issues[:3])
        if len(issues) > 3:
            preview += "；…共 " + str(len(issues)) + " 项"
        status_label.setText("校验未通过：" + preview + "（完整清单见悬停提示）")
        status_label.setStyleSheet("QLabel { font-size: 15px; color: #C0392B; }")
        status_label.setToolTip("\n".join(issues))
        return issues

    detail = '、'.join(z + ' ' + str(len(groups.get(z, []))) for z in ZODIAC_LIST)
    if allow_nonstandard:
        status_label.setText("已放宽数量校验：" + detail + " ｜标准为 1 个生肖 5 个 + 11 个各 4 个")
        status_label.setStyleSheet("QLabel { font-size: 15px; color: #E67E22; font-weight: bold; }")
    else:
        status_label.setText("校验通过（49/49；数量 5+4×11）")
        status_label.setStyleSheet("QLabel { font-size: 15px; color: #27AE60; }")
    status_label.setToolTip("")
    return []


def _fill_batch_table(table, binding):
    """把一份绑定填入 12 行表格（按 ZODIAC_LIST 固定顺序，不重排行）"""
    table.blockSignals(True)
    for row in range(table.rowCount()):
        zodiac_item = table.item(row, 0)
        zodiac = zodiac_item.text() if zodiac_item is not None else ''
        numbers = sorted(number for number in range(1, 50) if (binding or {}).get(number) == zodiac)
        if table.item(row, 1) is not None:
            table.item(row, 1).setText(','.join(str(number).zfill(2) for number in numbers))
        if table.item(row, 2) is not None:
            table.item(row, 2).setText(str(len(numbers)))
        if table.item(row, 3) is not None:
            table.item(row, 3).setText('')
    table.blockSignals(False)


def _read_batch_dialog_state(host):
    """读取批量编辑对话框记忆：预填档位、非标准开关、列宽、窗口宽高"""
    preset_index = 0
    allow_nonstandard = 0
    column_widths = [70, 380, 60, 110]
    dialog_width = 700
    dialog_height = 660
    ini = getattr(host, '_ini', None)
    try:
        if ini is not None and ini.has_section('WidgetState'):
            state = ini['WidgetState']
            preset_index = max(0, min(1, int(state.get('c_zodiac_batch_preset', '0') or 0)))
            allow_nonstandard = 1 if str(state.get('b_zodiac_batch_allow_nonstandard', '0')).strip() in ('1', 'true', 'True') else 0
            parsed = [int(part) for part in str(state.get('t_zodiac_batch_table', '')).split(',') if part.strip().isdigit()]
            if len(parsed) == 4:
                column_widths = parsed
        if ini is not None and ini.has_section('Display'):
            display = ini['Display']
            dialog_width = int(display.get('zodiac_batch_dialog_w', '700') or 700)
            dialog_height = int(display.get('zodiac_batch_dialog_h', '660') or 660)
    except Exception:
        pass
    dialog_width = max(620, min(900, dialog_width))
    dialog_height = max(560, min(700, dialog_height))
    return preset_index, allow_nonstandard, column_widths, dialog_width, dialog_height


def _save_batch_dialog_state(host, preset_index, allow_nonstandard, column_widths, dialog_width, dialog_height):
    """把批量编辑对话框记忆写入 INI（仅在用户操作过对话框后调用）"""
    try:
        extra = getattr(host, '_widget_state_extra', None)
        if not isinstance(extra, dict):
            extra = {}
            host._widget_state_extra = extra
        extra['c_zodiac_batch_preset'] = str(int(preset_index))
        extra['b_zodiac_batch_allow_nonstandard'] = '1' if allow_nonstandard else '0'
        extra['t_zodiac_batch_table'] = ','.join(str(int(width)) for width in column_widths)
        ini = getattr(host, '_ini', None)
        if ini is not None:
            if not ini.has_section('Display'):
                ini.add_section('Display')
            ini['Display']['zodiac_batch_dialog_w'] = str(int(dialog_width))
            ini['Display']['zodiac_batch_dialog_h'] = str(int(dialog_height))
        host._save_ini_config()
    except Exception:
        pass


def open_batch_edit_dialog(host):
    """打开「批量编辑生肖绑定」对话框（12 行表格 + 硬校验 + 二次确认）

    功能:
        一次编辑 12 个生肖各自的号码，保存时整体覆盖当前 49 条绑定。
        默认按 5+4×11 硬校验；勾选“允许非标准数量”只放宽数量配比，
        12 生肖齐全与 1–49 不重不漏仍死守。
        保存走 _commit_binding()，因此不会改动 zodiac_elements。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None（模态对话框关闭后返回）。

    副作用:
        仅当用户确认保存时改写 host.zodiac_binding 并落盘；
        关闭对话框时写入对话框记忆（预填档位/开关/列宽/窗口宽高）。
    """
    preset_index, allow_nonstandard, column_widths, dialog_width, dialog_height = _read_batch_dialog_state(host)
    dialog = QDialog(host)
    dialog.setWindowTitle("批量编辑生肖绑定")
    dialog.setModal(True)
    dialog.resize(dialog_width, dialog_height)

    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(16, 12, 16, 12)
    layout.setSpacing(8)

    info_label = QLabel("每行一个生肖，号码用逗号/空格分隔；共 12 行、49 个号码。保存将整体覆盖当前绑定（不会改动五行）。")
    info_label.setStyleSheet("font-size: 15px; color: #555555;")
    info_label.setWordWrap(True)
    layout.addWidget(info_label)

    toolbar = QHBoxLayout()
    toolbar.setSpacing(8)
    preset_label = QLabel("预填:")
    preset_label.setStyleSheet("font-size: 15px; color: #555555;")
    toolbar.addWidget(preset_label)

    preset_combo = QComboBox()
    preset_combo.addItems(["当前绑定", "清空"])
    preset_combo.setCurrentIndex(preset_index)
    preset_combo.setStyleSheet(
        "QComboBox { background-color: #FFFFFF; color: #9B59B6; border: 2px solid #9B59B6;"
        " border-radius: 5px; padding: 3px 8px; font-weight: bold; font-size: 15px; min-width: 88px; }"
        "QComboBox QAbstractItemView { font-size: 15px; }"
    )
    toolbar.addWidget(preset_combo)

    fill_btn = QPushButton("填充表格")
    fill_btn.setStyleSheet(
        "QPushButton { background-color: #FFFFFF; color: #8E44AD; border: 2px solid #8E44AD;"
        " border-radius: 5px; font-weight: bold; font-size: 15px; padding: 3px 10px; }"
        "QPushButton:hover { background-color: #8E44AD; color: #FFFFFF; }"
    )
    toolbar.addWidget(fill_btn)
    toolbar.addStretch(1)

    allow_checkbox = QCheckBox("允许非标准数量")
    allow_checkbox.setChecked(bool(allow_nonstandard))
    allow_checkbox.setToolTip("只放宽“数量必须 5+4×11”这一条；12 生肖齐全、1–49 不重不漏仍然强制")
    allow_checkbox.setStyleSheet("QCheckBox { font-size: 15px; color: #B9770E; }")
    toolbar.addWidget(allow_checkbox)
    layout.addLayout(toolbar)

    table = QTableWidget()
    table.setColumnCount(4)
    table.setHorizontalHeaderLabels(["生肖", "号码", "个数", "状态"])
    table.setRowCount(len(ZODIAC_LIST))
    table.verticalHeader().setVisible(False)
    table.setAlternatingRowColors(True)
    table.setStyleSheet(
        "QTableWidget { font-size: 15px; border: 1px solid #DDDDDD; gridline-color: #EEEEEE; background-color: #FFFFFF; }"
        "QTableWidget::item { padding: 4px; background-color: #FFFFFF; }"
        "QTableWidget::item:alternate { background-color: #F8F9FA; }"
        "QHeaderView::section { background-color: #9B59B6; color: white; font-weight: bold; font-size: 15px; padding: 5px; border: none; }"
    )
    table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
    table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
    table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Interactive)
    table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Interactive)
    for index, width in enumerate(column_widths):
        table.setColumnWidth(index, int(width))
    table.verticalHeader().setDefaultSectionSize(32)  # 行高 32px：15px 字高约 20px + 上下留白 12px

    for row, zodiac in enumerate(ZODIAC_LIST):
        zodiac_item = QTableWidgetItem(zodiac)
        zodiac_item.setFlags(zodiac_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        zodiac_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        table.setItem(row, 0, zodiac_item)

        number_item = QTableWidgetItem("")
        table.setItem(row, 1, number_item)

        count_item = QTableWidgetItem("0")
        count_item.setFlags(count_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        count_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        table.setItem(row, 2, count_item)

        status_item = QTableWidgetItem("")
        status_item.setFlags(status_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        table.setItem(row, 3, status_item)

    layout.addWidget(table, 1)

    status_label = QLabel("")
    status_label.setWordWrap(True)
    status_label.setMinimumHeight(44)
    status_label.setStyleSheet("font-size: 15px; color: #27AE60;")
    layout.addWidget(status_label)

    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
    ok_button = buttons.button(QDialogButtonBox.StandardButton.Ok)
    ok_button.setText("保存")
    cancel_button = buttons.button(QDialogButtonBox.StandardButton.Cancel)
    cancel_button.setText("取消")
    for button in (ok_button, cancel_button):
        button.setStyleSheet(
            "QPushButton { min-height: 30px; max-height: 30px; padding: 3px 14px; font-size: 15px; }"
        )
    layout.addWidget(buttons)

    def _refresh(mark_rows=False):
        return _refresh_batch_validation(table, status_label, ok_button, allow_checkbox, mark_rows=mark_rows)

    def _fill():
        source = host.zodiac_binding if preset_combo.currentIndex() == 0 else {}
        _fill_batch_table(table, source)
        _refresh(mark_rows=True)

    fill_btn.clicked.connect(_fill)
    table.cellChanged.connect(lambda _row, _column: _refresh(mark_rows=True))
    allow_checkbox.toggled.connect(lambda _checked: _refresh(mark_rows=False))

    def _on_ok():
        issues = _refresh(mark_rows=False)
        if issues:
            QMessageBox.warning(dialog, "校验未通过", "\n".join(issues))
            return
        groups, _parse_issues = _collect_batch_groups(table)
        binding = binding_from_groups(groups)
        allow = bool(allow_checkbox.isChecked())
        strict_issues = validate_zodiac_groups(groups)
        message = (
            "即将用表格中的 49 个号码覆盖当前生肖绑定（12 个生肖）。\n"
            "· 保存后立即生效，并写入 生肖绑定.json 与 配置.ini；\n"
            "· 不影响已有“生肖快照”的历史记录；缺少快照的旧记录会按新绑定显示；\n"
            "· 不会改动五行绑定，且无法撤销。"
        )
        if allow and strict_issues:
            message += "\n· 本次数量分配不符合标准，属性矩阵与统计按实际绑定显示。"
        message += "\n\n是否继续？"
        reply = QMessageBox.question(
            dialog, "确认覆盖生肖绑定", message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        detail = "已保存批量生肖绑定（12 个生肖 / 49 个号码）"
        if allow and strict_issues:
            detail += "；数量为非标准分配"
        if not _commit_binding(host, binding, detail, persist=True, allow_nonstandard=allow):
            QMessageBox.warning(dialog, "保存失败", "绑定未通过校验，未做任何修改。")
            return
        dialog.accept()

    buttons.accepted.connect(_on_ok)
    buttons.rejected.connect(dialog.reject)

    _fill_batch_table(table, host.zodiac_binding)
    _refresh(mark_rows=True)
    dialog.exec()

    widths = [table.columnWidth(index) for index in range(4)]
    _save_batch_dialog_state(host, preset_combo.currentIndex(), allow_checkbox.isChecked(),
                             widths, dialog.width(), dialog.height())



def on_num_font_changed(host, size):
    """生肖面板数字字体大小变化处理

    功能:
        记录号码字号并立即应用到左侧生肖号码面板。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        size (int): 新字号（px），控件范围 15~150。

    返回:
        None

    副作用:
        写 host._zodiac_panel_size['btn_font']；调用 host._save_ini_config()；
        触发 zodiac_panel.set_font_size() 重排号码球；
        更新 host._area_font_scales['zodiac_panel'] = size / 16.0。

    说明:
        set_font_size 需要同时给出宽/高/两种字号，所以这里从配置补全其余三项，
        避免只改字体导致按钮尺寸回落到类默认值。缩放比以 16px 为基准换算，
        与主窗口面板设置对话框的算法一致，供“区域字号缩放”按比例推算。
    """
    host._zodiac_panel_size['btn_font'] = size
    host._save_ini_config()
    if getattr(host, 'zodiac_panel', None):
        host.zodiac_panel.set_font_size(
            width=host._zodiac_panel_size.get('width', 90),
            height=host._zodiac_panel_size.get('height', 98),
            btn_font=size,
            label_font=host._zodiac_panel_size.get('label_font', 15)
        )
    host._area_font_scales['zodiac_panel'] = size / 16.0


def on_text_font_changed(host, size):
    """生肖面板文字字体大小变化处理

    功能:
        记录生肖标签字号并立即应用到左侧生肖号码面板。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        size (int): 新字号（px），控件范围 15~150。

    返回:
        None

    副作用:
        写 host._zodiac_panel_size['label_font']；调用 host._save_ini_config()；
        触发 zodiac_panel.set_font_size() 重排号码球（号码字号保持不变）。

    说明:
        与 on_num_font_changed 一样需要补全宽/高/号码字号，否则未显式传入的参数
        会回落到类默认尺寸，导致用户设置的宽高被意外重置。
    """
    host._zodiac_panel_size['label_font'] = size
    host._save_ini_config()
    if getattr(host, 'zodiac_panel', None):
        host.zodiac_panel.set_font_size(
            width=host._zodiac_panel_size.get('width', 90),
            height=host._zodiac_panel_size.get('height', 98),
            btn_font=host._zodiac_panel_size.get('btn_font', 28),
            label_font=size
        )


def load_binding(host):
    """加载生肖绑定数据（优先 INI，缺失时回退「生肖绑定.json」）

    功能:
        原主窗口 `_load_zodiac_binding` 原样迁入本页。启动阶段由主窗口 __init__
        直接调用本函数（此时页面尚未构建，start_zodiac_combo 通常不存在）。
        若 INI 已含 [Zodiac] 段，说明 _apply_ini_config 稍后会恢复绑定，本函数
        不再覆盖，仅在控件已存在时同步起始生肖文本。

    参数:
        host: 主窗口实例。需已具备 zodiac_file / _ini（可选）/ start_zodiac_combo
            （可选）；函数会写入 host.zodiac_binding 与 host.zodiac_elements。

    返回:
        None

    降级:
        - INI 已配置：直接返回，不在启动期覆盖既有绑定；
        - JSON 不存在或解析失败：保留默认绑定（龙=01,13,25,37,49）并打印错误，
          不抛异常，保证窗口可继续启动。

    说明:
        为什么仍由主窗口启动阶段调用：绑定数据要在 build(host) 之前就绪，
        生肖页、五行页和预测页都会读取 host.zodiac_binding / zodiac_elements。
        因此本函数只依赖 host 数据属性，不要求任何控件已创建。
    """
    import copy  # 作用说明：深拷贝出厂五行表，避免把类属性引用直接赋给 host 后被原地改动污染（仅此处使用，延迟导入避免页面顶部堆积无关依赖）
    # 优先从 INI 配置加载（_apply_ini_config 会设置绑定，不覆盖）
    ini_loaded = hasattr(host, '_ini') and host._ini.has_section('Zodiac')
    if ini_loaded:
        if hasattr(host, 'start_zodiac_combo') and hasattr(host, '_ini_start_zodiac'):
            host.start_zodiac_combo.setCurrentText(host._ini_start_zodiac)
        return
    # 默认绑定：龙=01,13,25,37,49
    host.zodiac_binding = LotteryConfig.generate_zodiac_binding("龙")
    host.zodiac_elements = copy.deepcopy(LotteryConfig.NUMBER_ELEMENTS)
    # 回退：尝试从 JSON 文件加载自定义绑定
    try:
        if _os_boot.path.exists(host.zodiac_file):
            with open(host.zodiac_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if 'names' in data:
                    host.zodiac_binding = {int(k): v for k, v in data['names'].items()}
                if 'elements' in data:
                    host.zodiac_elements = {int(k): v for k, v in data['elements'].items()}
                if hasattr(host, 'start_zodiac_combo') and 'start_zodiac' in data:
                    host.start_zodiac_combo.setCurrentText(data['start_zodiac'])
    except Exception as e:
        print("加载生肖绑定失败: " + str(e))


def show_panel_settings_dialog(host):
    """打开「生肖面板尺寸」设置弹窗

    功能:
        由主窗口 `_show_panel_settings_dialog` 的 'zodiac' 分支迁入。弹窗骨架
        使用 TAB.widgets.open_panel_size_dialog，本函数只应用宽高并同步字号
        spinbox 与字体缩放比例。

    参数:
        host: 主窗口实例。

    返回:
        None

    副作用:
        写 host._zodiac_panel_size 的 width/height、host._area_font_scales
        ['zodiac_panel']，重设 zodiac_panel 字号并同步两个字号 spinbox。

    降级:
        控件缺失时跳过对应同步（hasattr 探测），不抛异常。
    """
    current = getattr(host, '_zodiac_panel_size',
                      {'width': 90, 'height': 98, 'btn_font': 28, 'label_font': 15})

    def _apply(values):
        """把尺寸弹窗返回的宽高写回配置并联动刷新界面

        功能:
            将「生肖面板尺寸」对话框确认的 width/height 写入
            host._zodiac_panel_size，并立即应用到属性矩阵、两个字号 spinbox
            与字体缩放比例。

        参数:
            values (dict): 对话框回调值，含 'width'、'height'（int，像素）。

        返回:
            无。

        注意:
            仅在用户点确认时由 open_panel_size_dialog 回调触发；会改写
            host._zodiac_panel_size 与 host._area_font_scales，重置 spinbox
            时用 blockSignals 防止二次触发；控件缺失时用 hasattr 跳过。
        """
        host._zodiac_panel_size['width'] = values['width']
        host._zodiac_panel_size['height'] = values['height']
        if hasattr(host, 'zodiac_panel'):
            host.zodiac_panel.set_font_size(
                width=values['width'], height=values['height'],
                btn_font=host._zodiac_panel_size.get('btn_font', 28),
                label_font=host._zodiac_panel_size.get('label_font', 15))
        if hasattr(host, 'zodiac_num_font_spin'):
            host.zodiac_num_font_spin.blockSignals(True)
            host.zodiac_num_font_spin.setValue(host._zodiac_panel_size.get('btn_font', 28))
            host.zodiac_num_font_spin.blockSignals(False)
        if hasattr(host, 'zodiac_text_font_spin'):
            host.zodiac_text_font_spin.blockSignals(True)
            host.zodiac_text_font_spin.setValue(host._zodiac_panel_size.get('label_font', 15))
            host.zodiac_text_font_spin.blockSignals(False)
        host._area_font_scales['zodiac_panel'] = host._zodiac_panel_size.get('btn_font', 28) / 16.0

    open_panel_size_dialog(host, "生肖面板尺寸", current, _apply)


def install(host):
    """安装「数字与生肖」选项卡：先在 host 上挂本页事件，再构建界面（v0.0.28）

    功能:
        本页唯一安装入口。先把模块级事件处理函数以 lambda 形式挂到 host 的
        同名私有属性，再调用 build(host) 创建并返回页面。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        QWidget: 构建完成的页面。

    副作用:
        在 host 上挂以下回调：_refresh_zodiac_stats、
        _on_zodiac_number_clicked、_set_zodiac_immediately、_on_save_zodiac、
        _on_start_zodiac_changed、_on_apply_start_zodiac、_on_reset_zodiac、
        _on_zodiac_num_font_changed、_on_zodiac_text_font_changed；
        build() 还会创建本页控件并读取 host 已有状态（绑定、字体配置等）。

    说明:
        为什么用 lambda 转发：主窗口只保存无参或单参回调，而模块函数需要 host；
        闭包把 host 固定下来，既保持主窗口接口不变，也避免业务逻辑重复实现。
        必须先挂回调再 build，因为 build 中的信号连接会直接引用这些属性。
    """
    host._refresh_zodiac_stats = lambda: refresh_stats(host)
    host._on_zodiac_number_clicked = lambda num: on_number_clicked(host, num)
    host._set_zodiac_immediately = lambda num, zodiac: set_immediately(host, num, zodiac)
    host._on_save_zodiac = lambda: on_save(host)
    host._on_start_zodiac_changed = lambda text: on_start_changed(host, text)
    host._on_apply_start_zodiac = lambda: on_apply_start(host)
    host._on_reset_zodiac = lambda: on_reset(host)
    host._on_batch_edit_zodiac = lambda: open_batch_edit_dialog(host)
    host._on_zodiac_num_font_changed = lambda size: on_num_font_changed(host, size)
    host._on_zodiac_text_font_changed = lambda size: on_text_font_changed(host, size)
    return build(host)


def build(host):
    """构建「数字与生肖」选项卡页面

    功能:
        创建本页完整控件树：标题行（含操作按钮与角控件组）、顺时针提示、
        左号码面板 / 右统计详情的 3:2 水平分隔器。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备 spacing、margin_*、
        _zodiac_panel_size、zodiac_binding、zodiac_elements 等状态。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        在 host 上创建 start_zodiac_combo、zodiac_h_splitter、zodiac_highlight_bar、
        zodiac_panel（AttributeMatrixPanel）、zodiac_stats_table、zodiac_detail_label；
        连接下拉/按钮/号码球/生肖条信号；读取并恢复分隔器记忆尺寸；
        最后调用 _refresh_zodiac_stats() 初始化表格。

    说明:
        角控件组必须最后加入标题行并保持贴右：setStretch(1, 0) 让弹性空白留在
        标题与操作区之间，操作区不会被推到中间（与数字选择页的右对齐策略相反，
        本页操作按钮较多，靠左排布更紧凑）。
    """
    # 旧 INI 一次性迁移必须在字号 spin 初始化之前执行（只改内存，不直接写盘）
    migrate_attr_matrix_size(host)

    widget = _ZodiacPage(host)
    # 主垂直布局
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)

    # 顶部控制栏：标题 + 右侧操作（起始生肖/一键应用/恢复默认/保存绑定）+ 最右角控件组
    top_layout = QHBoxLayout()
    top_layout.setSpacing(8)

    title_label = QLabel("数字与生肖")
    title_label.setObjectName("PanelTitle")
    top_layout.addWidget(title_label)
    top_layout.addStretch(1)   # 弹性拉伸：把下面的操作控件与角控件组一起推到右侧

    separator1 = QLabel("|")
    separator1.setStyleSheet("color: #CCCCCC; font-size: 16px;")
    top_layout.addWidget(separator1)

    start_label = QLabel("起始生肖:")
    start_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555;")
    top_layout.addWidget(start_label)

    host.start_zodiac_combo = QComboBox()
    host.start_zodiac_combo.addItems(LotteryConfig.ZODIAC_CLOCKWISE)
    host.start_zodiac_combo.setCurrentText("龙")
    # 起始生肖下拉框样式 - 紫色系（生肖主题色）
    host.start_zodiac_combo.setStyleSheet(
        "QComboBox {"
        "background-color: #FFFFFF; /* 背景：纯白 */"
        "color: #9B59B6; /* 文字颜色：紫色（生肖主题色） */"
        "border: 2px solid #9B59B6; /* 边框：2px 实线紫色 */"
        "border-radius: 5px; /* 圆角：5px */"
        "padding: 3px 8px; /* 内边距：上下 3px、左右 8px，文字不贴边 */"
        "font-weight: bold; /* 文字加粗 */"
        "font-size: 15px; /* 字号：15px，满足最小字号要求 */"
        "min-width: 56px; /* 最小宽度：56px，容纳两字生肖 */"
        "}"
        "QComboBox::drop-down {"
        "border: none; /* 去掉下拉箭头自带边框 */"
        "width: 20px; /* 下拉箭头区域宽：20px */"
        "}"
        "QComboBox QAbstractItemView {"
        "background-color: #FFFFFF; /* 弹出列表背景：白色 */"
        "selection-background-color: #9B59B6; /* 选中项背景：紫色 */"
        "font-size: 15px; /* 字号：15px，满足最小字号要求 */"
        "}"
    )
    # 信号连接：起始生肖变更时保存配置
    host.start_zodiac_combo.currentTextChanged.connect(host._on_start_zodiac_changed)
    top_layout.addWidget(host.start_zodiac_combo)

    apply_btn = QPushButton("一键应用")
    # 一键应用按钮样式 - 蓝色系（确认/应用操作）
    apply_btn.setStyleSheet(
        "QPushButton {"
        "background-color: #FFFFFF; /* 默认背景：白色 */"
        "color: #3498DB; /* 默认文字：蓝色（确认/应用） */"
        "border: 2px solid #3498DB; /* 边框：2px 实线蓝色 */"
        "border-radius: 5px; /* 圆角：5px */"
        "font-weight: bold; /* 文字加粗 */"
        "font-size: 15px; /* 字号：15px，满足最小字号要求 */"
        "padding: 3px 10px; /* 内边距：上下 3px、左右 10px，文字不贴边 */"
        "}"
        "QPushButton:hover {"
        "background-color: #3498DB; /* 悬停背景：蓝色填充 */"
        "color: #FFFFFF; /* 悬停文字：白色 */"
        "}"
    )
    # 信号连接：点击一键应用按钮按起始生肖生成全部绑定
    apply_btn.clicked.connect(host._on_apply_start_zodiac)
    top_layout.addWidget(apply_btn)

    separator2 = QLabel("|")
    separator2.setStyleSheet("color: #CCCCCC; font-size: 16px;")
    top_layout.addWidget(separator2)

    reset_btn = QPushButton("恢复默认")
    reset_btn.setObjectName("ResetZodiacBtn")
    # 仅约束尺寸、沿用全局配色：min/max-height 30px + 上下 3px 内边距 + 2px 边框 = 40px，
    # 与同排角控件组等高，避免本按钮 46px 把整行撑高、导致控件组整体下移 3px
    reset_btn.setStyleSheet(
        "QPushButton {"
        "min-height: 30px; /* 内容最小高 30px：与角控件组对齐 */"
        "max-height: 30px; /* 内容最大高 30px：锁定实际 40px 行高 */"
        "padding: 3px 12px; /* 内边距：上下 3px、左右 12px，文字不贴边 */"
        "}"
    )
    reset_btn.clicked.connect(host._on_reset_zodiac)
    top_layout.addWidget(reset_btn)

    save_btn = QPushButton("保存绑定")
    save_btn.setObjectName("SaveZodiacBtn")
    # 同上：只锁尺寸不改配色，保证标题行高度恒为 40px
    save_btn.setStyleSheet(
        "QPushButton {"
        "min-height: 30px; /* 内容最小高 30px：与角控件组对齐 */"
        "max-height: 30px; /* 内容最大高 30px：锁定实际 40px 行高 */"
        "padding: 3px 12px; /* 内边距：上下 3px、左右 12px，文字不贴边 */"
        "}"
    )
    save_btn.clicked.connect(host._on_save_zodiac)
    top_layout.addWidget(save_btn)

    batch_btn = QPushButton("批量编辑")
    batch_btn.setObjectName("BatchZodiacBtn")
    # 与同排按钮统一 40px 行高：min/max-height 30px + 上下 3px 内边距 + 2px 边框
    batch_btn.setStyleSheet(
        "QPushButton {"
        "min-height: 30px; /* 内容最小高 30px：与角控件组对齐 */"
        "max-height: 30px; /* 内容最大高 30px：锁定实际 40px 行高 */"
        "padding: 3px 12px; /* 内边距：上下 3px、左右 12px，文字不贴边 */"
        "}"
    )
    batch_btn.clicked.connect(host._on_batch_edit_zodiac)
    top_layout.addWidget(batch_btn)

    top_layout.addSpacing(12)  # 操作区与角控件组之间留 12px，避免拥挤
    # 右上角「数字 px / 文字 px / 尺寸」控件组：四个页面统一规格、固定贴右端
    _build_font_controls(host, top_layout)

    layout.addLayout(top_layout)

    # 顺时针说明 + 点击操作提示（补充生肖条高亮用法）
    host.zodiac_hint_label = QLabel(_clockwise_hint_text(host.zodiac_binding))
    hint_label = host.zodiac_hint_label
    # 说明标签样式：15px 灰色（15px 为全局最小字号，换行显示避免截断）
    hint_label.setStyleSheet("font-size: 15px; color: #888888; padding: 2px 5px;")
    hint_label.setWordWrap(True)
    layout.addWidget(hint_label)

    # 完整性自检：只读展示 49 条绑定是否齐全、是否 5+4×11；红/橙/绿三态
    host.zodiac_integrity_label = QLabel("")
    host.zodiac_integrity_label.setStyleSheet("font-size: 15px; color: #27AE60; padding: 2px 5px;")
    host.zodiac_integrity_label.setWordWrap(True)
    layout.addWidget(host.zodiac_integrity_label)
    refresh_integrity(host)

    # 主内容区域 - 使用QSplitter
    host.zodiac_h_splitter = QSplitter(Qt.Orientation.Horizontal)
    host.zodiac_h_splitter.setHandleWidth(3)

    # 左侧：生肖页统一版正文（固定 12 生肖表头 + 圆形号码卡，表头与卡区共用列轴）
    left_widget = QWidget()
    left_layout = QVBoxLayout(left_widget)
    left_layout.setContentsMargins(5, 5, 5, 5)
    left_layout.setSpacing(8)

    host.zodiac_panel = AttributeMatrixPanel(
        zodiac_binding=host.zodiac_binding,
        elements=host.zodiac_elements,
        start_zodiac=(host.start_zodiac_combo.currentText()
                      if hasattr(host, 'start_zodiac_combo') else '龙'),
        dark_mode=bool(getattr(host, 'is_dark_mode', False)),
    )
    # 启动时把 INI 中已保存的字号/尺寸应用一次（默认 90×98/28/15 视为未定制）；
    # 卡宽仍按可用宽度反算，配置值只作为上限，保证 12 列不横向溢出。
    host.zodiac_panel.set_font_size(
        width=host._zodiac_panel_size.get('width', 90),
        height=host._zodiac_panel_size.get('height', 98),
        btn_font=host._zodiac_panel_size.get('btn_font', 28),
        label_font=host._zodiac_panel_size.get('label_font', 15),
    )
    # 生肖条已内置在面板顶部（固定一排，不随卡区滚动），页面只保留引用与信号连接
    host.zodiac_highlight_bar = host.zodiac_panel.highlight_bar
    host.zodiac_highlight_bar.zodiac_selected.connect(
        lambda text: _on_highlight_selected(host, text)
    )
    # 信号连接：点击号码 → 主窗口弹出十二生肖菜单（语义与旧面板完全一致）
    host.zodiac_panel.number_clicked.connect(host._on_zodiac_number_clicked)

    # 档位自动字号（1180 档 28/15、1600 档 34/17）同步到角控件显示：
    # 只改显示值并阻塞信号，避免反写 _zodiac_panel_size 或触发 set_font_size。
    def _sync_matrix_font_spins(profile, num_px, attr_px, _host=host):
        for attr, value in (('zodiac_num_font_spin', num_px),
                            ('zodiac_text_font_spin', attr_px)):
            spin = getattr(_host, attr, None)
            if spin is not None and int(spin.value()) != int(value):
                spin.blockSignals(True)
                spin.setValue(int(value))
                spin.blockSignals(False)

    host.zodiac_panel.profile_fonts_changed.connect(_sync_matrix_font_spins)

    # 面板占满左栏剩余高度：表头固定，卡区在面板内部纵向滚动，
    # 因此不再额外加弹性空白（否则面板只取 sizeHint 高度，底部会留空）。
    left_layout.addWidget(host.zodiac_panel, 1)

    # 左栏最小宽度 = 面板最小宽度（约 890px，对应 1180 档）：分屏器优先保证
    # 12 列完整显示，右侧统计概览退到其 225px 下限。
    panel_hint = host.zodiac_panel.sizeHint()
    # +12 抵消 left_layout 左右 5px 边距，保证面板本体不被压窄
    left_widget.setMinimumWidth(panel_hint.width() + 12)
    host.zodiac_h_splitter.addWidget(left_widget)

    # 右侧：生肖统计概览 + 详情
    right_widget = QWidget()
    right_widget.setMinimumWidth(225)  # 统计表两列在 225px 下可完整显示「包含数字」
    right_layout = QVBoxLayout(right_widget)
    right_layout.setContentsMargins(5, 5, 5, 5)
    right_title = QLabel("生肖统计概览")
    # 右侧标题样式：15px 粗体绿色（与生肖统计表表头同色系）
    right_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #2ECC71; padding: 5px;")
    right_layout.addWidget(right_title)

    host.zodiac_stats_table = QTableWidget()
    host.zodiac_stats_table.setColumnCount(2)
    host.zodiac_stats_table.setHorizontalHeaderLabels(["生肖", "包含数字"])
    # 列宽：生肖列固定 82px；「包含数字」列吃剩余宽度。
    # 左栏加入 12 列矩阵后右侧统计缩到 ~245px，若两列各 50% 则 5 个号码
    # （如「01 13 25 37 49」）会被裁掉末位，因此不能再两列均分。
    host.zodiac_stats_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
    host.zodiac_stats_table.setColumnWidth(0, 82)
    host.zodiac_stats_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
    # 行高固定 34px：两列单元格字体均为 15px，默认行高在部分 DPI 下会压住
    # 上下墨迹；34px = 15px 字形（约 20px 高）+ 上下各 7px 留白。
    host.zodiac_stats_table.verticalHeader().setDefaultSectionSize(STATS_ROW_HEIGHT)
    host.zodiac_stats_table.setAlternatingRowColors(True)
    host.zodiac_stats_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    host.zodiac_stats_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
    host.zodiac_stats_table.verticalHeader().setVisible(False)
    # 生肖统计表格样式 - 绿色系表头（与生肖区域主题一致）
    host.zodiac_stats_table.setStyleSheet("""
        QTableWidget {
            border: 1px solid #DDDDDD; /* 外边框：1px 浅灰，与浅色页面区分 */ 
            gridline-color: #EEEEEE; /* 网格线：更浅的灰，弱化表格线不抢号码 */ 
            background-color: #FFFFFF; /* 背景：纯白，保证生肖颜色可读 */ 
        }
        QTableWidget::item {
            padding: 6px; /* 单元格内边距：6px，号码与边框留白 */ 
            background-color: #FFFFFF; /* 单元格背景：纯白，避免选中时整行反色 */ 
        }
        QTableWidget::item:alternate {
            background-color: #F8F9FA; /* 交替行背景：极浅灰，便于横向读数 */ 
        }
        QHeaderView::section {
            background-color: #2ECC71; /* 表头背景：生肖主题绿色 */ 
            color: white; /* 表头文字：白色，与绿色背景保持对比 */ 
            font-weight: bold; /* 表头加粗：与数据行区分 */ 
            padding: 6px; /* 表头内边距：6px，与数据行高度协调 */ 
            border: none; /* 去掉表头默认分隔线，保持扁平风格 */ 
        }
    """)
    host.zodiac_stats_table.setItemDelegate(PreserveColorDelegate(host.zodiac_stats_table))
    right_layout.addWidget(host.zodiac_stats_table, 1)

    # 详情标签标题栏
    detail_title_layout = QHBoxLayout()
    detail_title = QLabel("生肖详情")
    detail_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #555;")
    detail_title_layout.addWidget(detail_title)
    detail_title_layout.addStretch()

    # 详情字号 A-/A+：实际增减由主窗口 _change_detail_label_font 钳制在
    # 15~24px（15px 为全局最小可读字号），按钮本身只转发 ±1 的步进方向
    zodiac_detail_font_minus = QPushButton("A-")
    zodiac_detail_font_minus.setToolTip("缩小详情字体")
    zodiac_detail_font_minus.setFixedSize(70, 24)
    # 详情字体缩小按钮样式 - 紫色系
    zodiac_detail_font_minus.setStyleSheet(
        "QPushButton { background-color: #F3E5F5; color: #6A1B9A; border: 1px solid #CE93D8; border-radius: 5px; font-weight: bold; font-size: 15px; }"
        "QPushButton:hover { background-color: #E1BEE7; }"
    )
    zodiac_detail_font_minus.clicked.connect(lambda: host._change_detail_label_font(-1))
    detail_title_layout.addWidget(zodiac_detail_font_minus)

    zodiac_detail_font_plus = QPushButton("A+")
    zodiac_detail_font_plus.setToolTip("放大详情字体")
    zodiac_detail_font_plus.setFixedSize(70, 24)
    # 详情字体放大按钮样式 - 绿色系
    zodiac_detail_font_plus.setStyleSheet(
        "QPushButton { background-color: #E8F5E9; color: #2E7D32; border: 1px solid #A5D6A7; border-radius: 5px; font-weight: bold; font-size: 15px; }"
        "QPushButton:hover { background-color: #C8E6C9; }"
    )
    zodiac_detail_font_plus.clicked.connect(lambda: host._change_detail_label_font(1))
    detail_title_layout.addWidget(zodiac_detail_font_plus)

    right_layout.addLayout(detail_title_layout)

    # 当前号码的生肖信息
    detail_font = host._detail_label_size.get('font', 13)
    detail_padding = host._detail_label_size.get('padding', 8)
    host.zodiac_detail_label = QLabel("点击左侧数字查看详情")
    # 生肖详情标签样式 - 灰色系（信息展示区）
    host.zodiac_detail_label.setStyleSheet(
        "font-size: " + str(detail_font) + "px; /* 字号：取全局详情字号配置 */"
        "color: #555555; /* 文字色：深灰，弱于标题但保证可读 */"
        "padding: " + str(detail_padding) + "px; /* 内边距：取全局详情内边距配置 */"
        "background-color: #F8F9FA; /* 背景：极浅灰，形成信息块边界 */"
        "border-radius: 5px; /* 圆角：5px */"
    )
    host.zodiac_detail_label.setWordWrap(True)
    right_layout.addWidget(host.zodiac_detail_label)

    host.zodiac_h_splitter.addWidget(right_widget)

    host.zodiac_h_splitter.setStretchFactor(0, 3)
    host.zodiac_h_splitter.setStretchFactor(1, 2)
    # 默认 3:2（左面板 : 右侧统计），旧配置若把统计栏压成 0 则自动回退到此比例
    host._apply_splitter_sizes(host.zodiac_h_splitter, 'zodiac_h_splitter', [600, 400])

    layout.addWidget(host.zodiac_h_splitter, 1)

    # 初始化生肖统计
    host._refresh_zodiac_stats()

    # 控件组保持贴左侧（原「控件位置」功能已删除，默认左对齐）
    top_layout.setStretch(1, 0)

    return widget
