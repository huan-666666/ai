# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/data_import.py - 「数据导入与格式转换」选项卡页面构建模块
===========================================================================
功能说明：
    构建主窗口「数据导入与格式转换」选项卡的全部界面控件，并挂载到主窗口实例上。

TAB_INFO（供 TAB/__init__.py 自动发现）：
    title   = "数据导入与格式转换"
    order   = 1（排在最前，因为后续所有页面都依赖这里导入的历史数据）
    enabled = True

依赖：
    - UI/UI.py：QWidget/QTextEdit/QPushButton/QSplitter/QFileDialog/QMessageBox 等
      控件的唯一导入来源，禁止直接 from PyQt6 import
    - lib.data_process.DataUtils：strip_html（去网页富文本）、parse_raw_data
      （原始文本 → 期号/日期/号码/特别码字典）、format_data（字典 → 标准文本行）

在数据流中的位置：
    原始文本（粘贴/文件） → _split_periods 按期切分 → parse_raw_data 解析
    → 「转换为标准格式」展示到 converted_text_edit；
    「添加到历史记录」把解析结果插入 host.historical_data 头部并由主窗口
    _save_data() 写 JSON；「批量导入」直接解析文件并追加到历史记录。
    本页只产生/修改历史数据，不做预测计算。

职责边界（v0.0.28 起本页自包含）：
    - 本模块负责界面构建（布局、控件、初始样式）与全部本页事件（模块函数 + install 绑定）
    - 主窗口 LotteryPredictionWindow 的同名方法仅作兼容转发
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import csv  # 作用说明：提供内置 CSV 行读取器，DuckDB 不可用时作为 .csv 文件的回退解析
import json  # 作用说明：提供 JSON 读写，用于解析记录文件及未知扩展名时的兜底尝试
import os as _os_boot  # 作用说明：提供 dirname/abspath/exists/join 等路径能力，用于向上定位项目根目录
import re  # 作用说明：提供正则匹配与切分，用于剥离网页富文本标记并按「第X期」等边界拆分期文本
import sys as _sys_boot  # 作用说明：提供 sys.path 访问，用于把项目根目录加入模块搜索路径以支持直接运行本文件

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from collections import Counter  # 作用说明：提供计数容器，用于统计同一期内重复出现的号码次数

from UI import (QFileDialog, QHBoxLayout, QLabel, QMessageBox, QPushButton, QSplitter, QTextEdit, QVBoxLayout, QWidget, Qt)  # 作用说明：统一获取本页所需的 Qt 控件（文件对话框/布局/标签/消息框/按钮/分割器/文本框）及 Qt 枚举，避免直接 import PyQt6
from lib.data_process import DataUtils, LotteryConfig  # 作用说明：DataUtils 提供去富文本、原始文本解析、标准行格式化与 TXT 行解析；LotteryConfig 提供写入时刻的生肖快照固化



def _build_input_panel(host):
    """构建「数据导入与格式转换」页左侧的输入面板

    功能:
        创建标题、格式提示、原始文本输入框与 5 个操作按钮，按垂直布局排列，
        作为分割器左半部分使用。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。
            本函数会在此对象上挂载属性：
                host.raw_text_edit —— QTextEdit，用户粘贴原始数据的输入框；
            并假定 install(host) 已提前写入以下回调（按钮在构建时立即连接）：
                host._on_convert_clicked / host._on_add_to_history_clicked /
                host._on_batch_import_clicked / host._on_clear_all_data_clicked。

    返回:
        QWidget: 输入面板控件（objectName="InputPanel"），由 build(host) 放入分割器。

    副作用:
        在 host 上创建并绑定 raw_text_edit；把按钮 clicked 信号接到 host 上的回调。
        「清空输入」按钮例外，直接连 lambda 清空 raw_text_edit，不经过主窗口。
    """
    widget = QWidget()
    widget.setObjectName("InputPanel")
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    
    title = QLabel("粘贴原始数据")
    title.setObjectName("PanelTitle")
    layout.addWidget(title)
    
    info_label = QLabel(
        "支持大量批量粘贴，每期一行或多期连续粘贴均可自动识别；日期、期号、号码的顺序可任意组合：\n"
        "• 第116期 2026年04月26日 15 46 16 10 48 33 + 22\n"
        "• 2026年04月26日 第116期 15 46 16 10 48 33 + 22（日期在前）\n"
        "• 2026-04-26 15:30 第116期 15 46 16 10 48 33 + 22（时间在前）\n"
        "• 2026年04月26日 116 15 46 16 10 48 33 + 22（日期-期号-号码）\n"
        "• 116 2026年04月26日 15 46 16 10 48 33 + 22（期号-日期-号码）\n"
        "分隔符可用空格、逗号、顿号、斜杠等；全角数字与网页富文本也能识别。")
    info_label.setObjectName("InfoLabel")
    info_label.setWordWrap(True)
    layout.addWidget(info_label)

    # 识别结果标签：判成什么格式、解析/跳过条数、首条样例；只读展示，不参与布局拉伸
    host.import_detect_label = QLabel("识别结果：尚未导入")
    host.import_detect_label.setObjectName("ImportDetectLabel")
    host.import_detect_label.setWordWrap(True)
    # 显式 15px 下限：提示行不得小于全局最小字号，颜色留给主题调色板以保证暗色对比度
    host.import_detect_label.setStyleSheet("font-size: 15px;")
    layout.addWidget(host.import_detect_label)
    
    host.raw_text_edit = QTextEdit()
    host.raw_text_edit.setObjectName("RawTextEdit")
    host.raw_text_edit.setPlaceholderText("请在此处粘贴原始数据...")
    layout.addWidget(host.raw_text_edit)
    
    button_layout = QHBoxLayout()
    
    convert_btn = QPushButton("转换为标准格式")
    # 转换按钮点击信号：将原始数据转换为标准格式
    convert_btn.clicked.connect(host._on_convert_clicked)
    button_layout.addWidget(convert_btn)
    
    add_to_history_btn = QPushButton("添加到历史记录")
    # 添加按钮点击信号：将转换后的数据添加到历史记录
    add_to_history_btn.clicked.connect(host._on_add_to_history_clicked)
    button_layout.addWidget(add_to_history_btn)
    
    batch_import_btn = QPushButton("批量导入")
    # 批量导入按钮点击信号：从文件批量导入数据
    batch_import_btn.clicked.connect(host._on_batch_import_clicked)
    button_layout.addWidget(batch_import_btn)
    
    layout.addLayout(button_layout)
    
    clear_btn = QPushButton("清空输入")
    # 清空输入按钮点击信号：清空原始数据输入框
    clear_btn.clicked.connect(lambda: host.raw_text_edit.clear())
    layout.addWidget(clear_btn)
    
    clear_data_btn = QPushButton("清除数据")
    clear_data_btn.setObjectName("ClearDataBtn")
    # 清除数据按钮点击信号：清除输入和转换结果
    clear_data_btn.clicked.connect(host._on_clear_all_data_clicked)
    layout.addWidget(clear_data_btn)
    
    return widget

def _build_result_panel(host):
    """构建「数据导入与格式转换」页右侧的结果面板

    功能:
        创建「转换结果」标题与只读文本框，作为分割器右半部分使用。

    参数:
        host: 主窗口实例。本函数会在此对象上挂载：
            host.converted_text_edit —— QTextEdit，只读，显示标准化后的文本；
        并读取 host.spacing / host.margin_left / host.margin_top /
        host.margin_right / host.margin_bottom 作为布局间距与页边距。

    返回:
        QWidget: 结果面板控件（objectName="ResultPanel"）。

    副作用:
        创建并挂载 host.converted_text_edit；把该控件设为只读，
        防止用户手改转换结果（写入只由 on_convert 负责）。
    """
    widget = QWidget()
    widget.setObjectName("ResultPanel")
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)
    
    title = QLabel("转换结果")
    title.setObjectName("PanelTitle")
    layout.addWidget(title)
    
    host.converted_text_edit = QTextEdit()
    host.converted_text_edit.setObjectName("ConvertedTextEdit")
    host.converted_text_edit.setReadOnly(True)
    layout.addWidget(host.converted_text_edit)
    
    return widget

def _line_has_date(line):
    """判断一行里是否含可解析日期（4 位年 / 2 位年，且月日范围合法）

    只看特征不看位置：兼容 2026年04月26日 / 2026-04-26 / 26-04-26；
    月/日越界（如 25-16-28 这类号码串）不会被误判成日期。
    """
    for pattern in _DATE_PATTERNS:
        for match in pattern.finditer(line):
            year = int(match.group(1))
            if len(match.group(1)) == 2:
                year = 2000 + year
            month, day = int(match.group(2)), int(match.group(3))
            if 1990 <= year <= 2099 and 1 <= month <= 12 and 1 <= day <= 31:
                return True
    return False


def _split_periods_located(raw_text):
    """把整段粘贴文本拆分为多期片段，并记录每段在原文中的起始行号

    功能:
        先剥离网页富文本并标准化「开奖记录」前缀，再按多行分组或单行期号边界
        两条路径切分，把整段文本拆成可逐期交给 parse_raw_data 的片段列表。

    参数:
        raw_text: 用户粘贴的原始文本（可含网页富文本标签、全角数字）。
    返回:
        list[tuple[str, int]]: (片段文本, 起始行号)；空文本返回 []。
        行号用于「缺少期号」时按「第几行」定位，不做展示格式转换。
    说明:
        1) 有「第X期 / 开奖记录」标记时按标记拆分，并兼容
           「开奖记录YYYY年MM月DD日第X期」这种日期在前的写法
        2) 没有标记时按「记录起始行」分组：含日期、含「X期」或以
           「期号 号码 号码」开头的行视为新记录，其余行并入上一期，
           兼容「日期-期号-号码」「期号-日期-号码」「时间-期号-号码」等写法

    为什么要分「多行分组」和「单行切分」两条路径:
        逐行分组比正则前瞻切分更宽容——一行只写一个日期/期号时不会漏期，
        号码或生肖换行写也能并入上一期；而单行连续粘贴（整段没有换行）时
        只能靠「第X期 / 开奖记录」这类强边界做前瞻切分，否则无从判断一期
        从哪里开始。两条路径都失败时原样返回整段，交给 parse_raw_data
        做最终判断（宁可返回一条解析失败记录，也不凭空丢数据）。

    副作用:
        无（纯字符串处理，不读写文件、不修改 host）。
    """
    raw_text = DataUtils.strip_html(raw_text)
    # 标准化「开奖记录YYYY年MM月DD日第X期」→「第X期 YYYY年MM月DD日」
    # 为什么要交换顺序：后续单行切分以「第X期」为前瞻边界，把期号提到最前，
    # 日期就不会被留在上一段尾部；捕获组 \1=日期、\2=期号，替换串 \2 \1 负责换位。
    raw_text = re.sub(
        r'开奖记录\s*(\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日)\s*(第\s*\d+\s*期)',
        r'\2 \1', raw_text)
    # 只带「开奖记录第X期」没有日期时，直接去掉「开奖记录」前缀，统一成「第X期」边界
    raw_text = re.sub(r'开奖记录\s*(第\s*\d+\s*期)', r'\1', raw_text)

    lines = [(idx, line.strip()) for idx, line in enumerate(raw_text.splitlines(), 1) if line.strip()]

    # 多行文本优先按「记录起始行」分组：一行一条时不会因为某行带「第X期」
    # 而把其他行误并入同一期；一行跨多行（号码/生肖分行）也会并入上一期。
    if len(lines) > 1:
        # 日期：支持 2026年4月26日 / 2026-04-26 / 2026/4/26 / 2026.4.26 四种写法，
        # 分隔符允许两三个字符（月/日）且两侧空格可选，兼容富文本转换后的松散排版
        # 日期判定统一走 _line_has_date：兼容 4 位年与 2 位年，并校验月/日范围，
        # 避免「25-04-26」这类号码串被当成日期、也避免 26-07-04 识别不到日期
        # 期号：只认「数字+期」而不认裸数字，避免把号码行（如 15 46 16）误判为新记录
        period_re = re.compile(r'\d+\s*期')
        # 无日期/期号时的兜底：行首「1~4 位期号 + 两个号码」视为一期开始。
        # 限制 1~4 位并加 (?:\s|$) 是为了区分「01 02 03」这类号码串与「116 15 46」期号行，
        # 同时要求后面紧跟空白，防止把 6 位以上长数字串当成期号
        start_re = re.compile(r'^\d{1,4}\s+\d{1,2}\s+\d{1,2}(?:\s|$)')
        # 行首就是 5~9 位纯数字期号（无「期」字、无日期）时同样视为新记录起点，
        # 否则「期号 6码 特码」这种写法会被并入上一期
        long_period_re = re.compile(r'^\d{5,9}\s+')

        groups = []
        current = []
        current_start = 0
        for line_no, line in lines:
            if line.startswith('#'):
                # 注释 / 期望条数说明行：直接跳过，不并入任何一期
                continue
            if set(line) <= set('=-_ '):
                # ==== / ---- 分隔行：跳过，不并入任何一期
                continue
            is_start = bool(_line_has_date(line) or period_re.search(line)
                            or start_re.match(line) or long_period_re.match(line))
            if is_start:
                # 竖向排版会把「第X期」与日期拆成相邻两行：两者同属一期，
                # 第二行不能再开新组，否则期号被甩成孤段、数据段丢失期号
                # 只有“单字段行”才允许与相邻行合并：当前行必须是纯期号行或纯日期行
                # （特征解析都拿不到完整记录），否则「日期 期号 号码」整行记录会被误并
                only_period = (len(current) == 1 and period_re.search(current[0])
                               and not _line_has_date(current[0])
                               and _parse_record_features(current[0])[0] is None)
                only_date = (len(current) == 1 and _line_has_date(current[0])
                             and not period_re.search(current[0])
                             and _parse_record_features(current[0])[0] is None)
                incoming_single = _parse_record_features(line)[0] is None
                if ((only_period and _line_has_date(line) and not period_re.search(line)
                     and incoming_single)
                        or (only_date and period_re.search(line) and not _line_has_date(line)
                            and incoming_single)):
                    current.append(line)
                    continue
                # 命中任一“起始行”特征才开新组：先收尾上一组，避免两期粘成一段
                if current:
                    groups.append((' '.join(current), current_start))
                current = [line]
                current_start = line_no
            elif current:
                # 非起始行视为上一期的续行（号码/生肖换行），并入而不是丢弃
                current.append(line)
        if current:
            groups.append((' '.join(current), current_start))
        if groups:
            return groups

    # 单行连续粘贴多期：按「第X期 / 开奖记录」边界拆分
    # 只有当整段确实含「第X期 / 开奖记录」时才走这条路径，避免把普通长行拆碎。
    # 正则用 (?=...) 前瞻而非捕获组：切分后「第X期」仍留在每段开头，
    # parse_raw_data 才能从段首识别期号；若把标记当分隔符吃掉，期号信息就丢了。
    if re.search(r'第\s*\d+\s*期|开奖记录', raw_text):
        segments = [s.strip() for s in re.split(r'(?=第\s*\d+\s*期|开奖记录)', raw_text) if s.strip()]
        # 只切出 1 段说明边界词在段首之外、或仅出现一次，单段结果与整段等价，
        # 此时继续往下走“原样返回”，保持与多行路径一致的兜底行为
        if len(segments) > 1:
            # 日期在前、期号在后的单行写法（2026年04月26日 第116期 ...）会在「第」处
            # 被切开，日期段自身无法成记录：把它并回下一段，保证期号与日期同组
            first = segments[0]
            date_lead = re.search(r'\d{4}\s*[年\-/.]\s*\d{1,2}\s*[月\-/.]\s*\d{1,2}', first)
            lead_nums = len(re.findall(r'\b\d{1,2}\b', re.sub(
                r'\d{4}\s*[年\-/.]\s*\d{1,2}\s*[月\-/.]\s*\d{1,2}', ' ', first)))
            if date_lead and not re.search(r'第\s*\d+\s*期', first) and lead_nums < 7:
                segments = [(first + ' ' + segments[1]).strip()] + segments[2:]
            # 单行切分后各段都在同一行内，按段首在原文中的位置换算行号
            located = []
            search_from = 0
            for segment in segments:
                pos = raw_text.find(segment, search_from)
                if pos < 0:
                    pos = search_from
                located.append((segment, raw_text.count('\n', 0, pos) + 1))
                search_from = pos + len(segment)
            return located

    # 兜底：整段原样作为一期（空白文本返回空列表，让调用方按“无数据”提示）
    return [(raw_text.strip(), 1)] if raw_text.strip() else []


def _split_periods(raw_text):
    """把整段文本拆分为多期片段（只返回片段文本，兼容既有调用）

    参数:
        raw_text: 原始文本。
    返回:
        list[str]: 每一期的文本片段；空文本返回 []。
    """
    return [segment for segment, _ in _split_periods_located(raw_text)]


# ==========================================================================
# 自动识别与导入诊断（粘贴 / 文件共用同一判定入口）
# ==========================================================================
# 记录键别名：中文键与常见英文别名统一映射到 period / date / numbers / special
_PERIOD_ALIASES = ('period', '期号', '期数', 'qihao', 'issue', 'draw', 'expect')
_DATE_ALIASES = ('date', '日期', '开奖日期', 'draw_date')
_NUMBERS_ALIASES = ('numbers', '号码', '正码', '开奖号码', 'draw_numbers', 'nums', 'number')
_SPECIAL_ALIASES = ('special', '特别码', '特码', '特别号码', 'special_number', 'sp')


def _pick(item, aliases):
    """按别名列表从 dict 中取值（键去空格、不区分大小写）；未命中返回 None"""
    if not isinstance(item, dict):
        return None
    lowered = {str(k).strip().lower(): v for k, v in item.items()}
    for alias in aliases:
        if alias.lower() in lowered:
            return lowered[alias.lower()]
    return None


def _preview(item):
    """取一条记录的前 40 字原文，用于缺期号 / 诊断定位"""
    if isinstance(item, dict):
        text = json.dumps(item, ensure_ascii=False, default=str)
    else:
        text = str(item)
    return text[:40]


def _values_conflict(period_value, date_text):
    """判断「期号自带的年份」与「日期年份」是否冲突

    参数:
        period_value: 期号原值（含年份时为 7~9 位数字）
        date_text: 该行日期文本
    返回:
        bool: 期号含合法年份且与日期年份不一致时为 True。
    """
    digits = re.sub(r'\D', '', str(period_value or ''))
    if len(digits) >= 7 and 1990 <= int(digits[:4]) <= 2099:
        date_match = re.search(r'(19\d{2}|20\d{2})', str(date_text or ''))
        if date_match and int(digits[:4]) != int(date_match.group(1)):
            return True
    return False


def _text_period_date_conflict(text):
    """从一行原始文本中抽取期号与日期，判断年份是否冲突"""
    date_match = (re.search(r'(\d{4})\s*年\s*\d{1,2}\s*月\s*\d{1,2}', text)
                  or re.search(r'(\d{4})\s*[-/.]\s*\d{1,2}\s*[-/.]\s*\d{1,2}', text))
    if not date_match:
        return False
    date_year = int(date_match.group(1))
    period_match = re.search(r'第\s*(\d+)\s*期', text) or re.search(r'(\d+)\s*期', text)
    if period_match:
        digits = re.sub(r'\D', '', period_match.group(1))
    else:
        # 无「期」字时按 parse_raw_data 的同一口径取首数字（需凑够 8 个数字才可能是期号+7码）
        tokens = list(re.finditer(r'\d{1,9}', text))
        if len(tokens) < 8:
            return False
        digits = tokens[0].group(0)
    if len(digits) >= 7 and 1990 <= int(digits[:4]) <= 2099:
        return int(digits[:4]) != date_year
    return False


# 逐记录特征判定用的正则：日期 / 时间 / 期号 / 裸期号候选
_DATE_PATTERNS = (
    re.compile(r'(?<!\d)(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日?'),
    re.compile(r'(?<!\d)(\d{4})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})(?!\d)'),
    re.compile(r'(?<!\d)(\d{2})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})(?!\d)'),
)
_TIME_RE = re.compile(r'(?:开奖时间|发布时间|时间)?\s*\d{1,2}\s*:\s*\d{1,2}(?:\s*:\s*\d{1,2})?')
_PERIOD_MARK_RE = re.compile(r'第\s*(\d+)\s*期')
_PERIOD_SUFFIX_RE = re.compile(r'(\d+)\s*期')
_BARE_PERIOD_RE = re.compile(r'(?<!\d)(\d{3,9})(?!\d)')
_NUMBER_TOKEN_RE = re.compile(r'(?<!\d)(\d{1,3})(?!\d)')
# 写法代码字符 → 中文名（识别统计面板直接拼接使用）
_STYLE_LABELS = {'D': '日期', 'P': '期号', 'N': '号码'}


def _normalize_date_text(date_text):
    """把 2026年11月04日 / 2026-11-04 / 26-04-26 统一成 YYYY-MM-DD

    参数:
        date_text: 原始日期文本（可含「开奖时间」等前后缀）。
    返回:
        str: 归一化日期；无法识别时返回空串（不拿今天兜底）。
    """
    if not date_text:
        return ''
    text = str(date_text)
    match = re.search(r'(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})', text)
    if not match:
        match = re.search(r'(?<!\d)(\d{4})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})', text)
    if match:
        return '%04d-%02d-%02d' % (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    match = re.search(r'(?<!\d)(\d{2})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})(?!\d)', text)
    if match:
        return '%04d-%02d-%02d' % (2000 + int(match.group(1)), int(match.group(2)),
                                  int(match.group(3)))
    return ''


def _blank_spans(text, spans):
    """把若干区间替换为等长空格，保持其余字符下标不变（用于特征定位）"""
    chars = list(text)
    for start, end in spans:
        for index in range(start, min(end, len(chars))):
            chars[index] = ' '
    return ''.join(chars)


def _style_code(date_pos, period_pos, number_pos):
    """按三个特征在原文中的位置生成写法代码（如 DPN / PDN / PND）"""
    features = [(date_pos, 'D'), (period_pos, 'P'), (number_pos, 'N')]
    features = [(pos, code) for pos, code in features if pos is not None and pos >= 0]
    return ''.join(code for _, code in sorted(features))


def _parse_record_features(text):
    """逐记录特征判定：不依赖字段位置，按特征识别日期 / 期号 / 7 个号码

    功能:
        对一条记录文本先做 NFKC 归一化、去序号前缀与噪音，再按「像什么」而不是
        「第几段」识别特征：
            - 日期：4 位年或 2 位年的 年-月-日 三段组合（中文年月日/横线/斜杠/点号）
            - 期号：「第X期 / X期」或 3~9 位、不落在 1~49 的纯数字
            - 号码：1~49 的整数；`+` / `特` / `特别码` 标记的为特别码，
              没有标记时取第 7 个（并标注“推定”）
        同类候选出现多个（两个日期或两个期号）时不猜，直接拒绝并给出行号定位。

    参数:
        text: 单条记录原文（可含生肖/五行、空白、分隔符、序号前缀等噪音）。

    返回:
        tuple: (record | None, preview, style_code, reason, inferred_special, evidence)
            record 为 {period=期序, period_full=完整期号, period_year=年份,
            date, numbers, special}；无法判定时 record 为 None，
            reason 为「号码不足 7 个」「号码多于 7 个」「两个期号候选」「期号与日期年份冲突」等；
            evidence 记录所有「推定」依据（特别码取第 7 个、年份取自日期、两位年补全）。
    """
    import unicodedata  # 作用说明：NFKC 把全角数字/标点、全角加号统一为半角，保证特征正则可用

    original = DataUtils.strip_html(text or '')
    raw = unicodedata.normalize('NFKC', original)
    raw = ' '.join(raw.split())
    preview = raw[:40]
    if not raw:
        return None, preview, '', '空行', False, []
    # 去序号前缀：必须带「. 、 ． ）」等标点，避免把行首期号 2026308 当成序号吃掉
    raw = re.sub(r'^\s*[（(]?\d+[）)\.、．]\s*', '', raw)
    if not raw:
        return None, preview, '', '空行', False, []

    masked = raw
    # ---------- 日期 ----------
    date_spans = []
    date_value = ''
    date_two_digit = False
    for pattern in _DATE_PATTERNS:
        matches = []
        for match in pattern.finditer(masked):
            # 月/日做范围校验：避免把用「-」分隔的号码串（如 25-04-26）误判成日期
            month, day = int(match.group(2)), int(match.group(3))
            if 1 <= month <= 12 and 1 <= day <= 31:
                matches.append(match)
        if matches:
            date_spans = [match.span() for match in matches]
            date_value = _normalize_date_text(matches[0].group(0))
            date_two_digit = len(matches[0].group(1)) == 2
            break
    if len(date_spans) > 1:
        first, second = matches[0].group(0), matches[1].group(0)
        return None, preview, '', '两个日期候选（%s 与 %s），无法判定' % (first, second), False, []
    masked = _blank_spans(masked, date_spans)

    # ---------- 期号 ----------
    period_matches = list(_PERIOD_MARK_RE.finditer(masked))
    if not period_matches:
        period_matches = list(_PERIOD_SUFFIX_RE.finditer(masked))
    if not period_matches:
        candidates = [match for match in _BARE_PERIOD_RE.finditer(masked)
                      if not (1 <= int(match.group(1)) <= 49)]
        period_matches = candidates
    if len(period_matches) > 1:
        first = period_matches[0].group(0).strip()
        second = period_matches[1].group(0).strip()
        return None, preview, '', '两个期号候选（%s 与 %s），无法判定' % (first, second), False, []
    period_pos = None
    period_raw = None
    period_spans = []
    if period_matches:
        match = period_matches[0]
        period_pos = match.start()
        period_raw = match.group(1)
        period_spans = [match.span()]
    masked = _blank_spans(masked, period_spans)

    # ---------- 时间与特别码标记 ----------
    time_spans = [match.span() for match in _TIME_RE.finditer(masked)]
    masked = _blank_spans(masked, time_spans)
    plus_marker = re.search(r'\+\s*(\d{1,2})', masked)
    text_marker = re.search(r'(?:特别码|特别号码|特码|特)\s*:\s*(\d{1,2})', masked)
    if not text_marker:
        text_marker = re.search(r'(?:特别码|特别号码|特码|特)\s*(\d{1,2})', masked)
    special_value = None
    special_span = None
    if plus_marker:
        special_value = int(plus_marker.group(1))
        special_span = plus_marker.span(1)
    if text_marker:
        value = int(text_marker.group(1))
        if special_value is not None and special_value != value:
            return None, preview, '', '特别码字段冲突，无法判定', False, []
        special_value = value
        special_span = text_marker.span(1)
    if special_span:
        masked = _blank_spans(masked, [special_span])

    # ---------- 号码 ----------
    tokens = [(match.start(), int(match.group(1)))
              for match in _NUMBER_TOKEN_RE.finditer(masked)
              if 1 <= int(match.group(1)) <= 49]
    number_pos = tokens[0][0] if tokens else None
    style = _style_code(date_spans[0][0] if date_spans else None, period_pos, number_pos)
    values = [value for _, value in tokens]

    inferred = False
    if special_value is not None:
        if len(values) != 6:
            reason = '号码不足 7 个（只有 %d 个）' % len(values) if len(values) < 6 \
                else '号码多于 7 个（共 %d 个）' % len(values)
            return None, preview, style, reason, False, []
        numbers = values
    else:
        if len(values) < 7:
            return None, preview, style, '号码不足 7 个（只有 %d 个）' % len(values), False, []
        if len(values) > 7:
            return None, preview, style, '号码多于 7 个（共 %d 个）' % len(values), False, []
        numbers = values[:6]
        special_value = values[6]
        inferred = True
    if not 1 <= special_value <= 49:
        return None, preview, style, '特别码超出 1-49', False, []

    if _values_conflict(period_raw, date_value):
        return None, preview, style, '期号与日期年份冲突', False, []
    period, period_full, period_year = _period_fields(period_raw, date_value)
    # 所有「推定」都要能在结果面板看到依据，不做静默处理
    evidence = []
    if inferred:
        evidence.append('特别码取第 7 个（原文没有 + 或「特」标记）')
    if period_raw is not None and period_full is not None:
        raw_digits = re.sub(r'\D', '', str(period_raw))
        if len(raw_digits) < 7:
            evidence.append('年份取自日期：期序 %d + %s → 完整期号 %d'
                            % (period, date_value or '无日期', period_full))
    if date_two_digit:
        evidence.append('日期是两位年，已按 20xx 补全为 %s' % date_value)
    record = {'period': period, 'period_full': period_full, 'period_year': period_year,
              'date': date_value, 'numbers': numbers, 'special': special_value}
    return record, preview, style, '', inferred, evidence


def _decode_text(raw_bytes):
    """按 UTF-8（含 BOM）→ GB18030 → GBK → UTF-16 顺序尝试解码

    参数:
        raw_bytes (bytes): 文件原始字节。
    返回:
        tuple[str | None, str | None]: (解码文本, 命中的编码名称)；全部失败返回 (None, None)。
    说明:
        先看 UTF-16 BOM（FF FE / FE FF），避免被 gb18030 抢先解出乱码；
        其余按需求顺序逐轮尝试，命中即返回，保证「编码自动尝试」可复现。
    """
    if raw_bytes[:2] in (b'\xff\xfe', b'\xfe\xff'):
        try:
            return raw_bytes.decode('utf-16'), 'UTF-16'
        except UnicodeDecodeError:
            pass
    for name, codec in (('UTF-8', 'utf-8-sig'), ('GB18030', 'gb18030'), ('GBK', 'gbk'),
                        ('UTF-16', 'utf-16')):
        try:
            return raw_bytes.decode(codec), name
        except (UnicodeDecodeError, LookupError):
            continue
    return None, None


def _period_fields(period_raw, date_text):
    """把期号原值拆成「期序 / 完整期号 / 年份」三个字段

    展示与存储用期序（如 308，不带年份前缀）；完整期号（2026308）与年份
    （2026）只作内部副字段，供批内去重与库内重复判定使用，避免 2025/2026
    的同一期序互撞。

    参数:
        period_raw: 期号原值（可能带「第」/「期」、年份前缀或纯期序）。
        date_text: 该条日期文本（纯期序补年份时使用）。
    返回:
        tuple: (期序 int | None, 完整期号 int | None, 年份 int | None)。
    """
    return DataUtils.split_period(period_raw, date_text)


def _record_full_period(record):
    """取一条记录的完整期号：优先 period_full；兼容只有期序/完整号的旧记录"""
    full = record.get('period_full')
    if full not in (None, ''):
        try:
            return int(full)
        except (TypeError, ValueError):
            pass
    period = record.get('period')
    if period is None:
        return None
    digits = re.sub(r'\D', '', str(period))
    if not digits:
        return None
    if len(digits) >= 7:
        return int(digits)
    match = re.search(r'(199\d|20\d{2})', str(record.get('date') or ''))
    if match:
        return int('%s%s' % (match.group(1), digits.zfill(3)))
    return None


def _canonicalize(item):
    """把任意键名的记录规范成 {period,date,numbers,special}

    参数:
        item (dict): 原始记录（键可能是中文、英文别名或标准键）。
    返回:
        tuple[dict | None, str, object]: (记录, 前 40 字预览, 期号原值)；
            不是 dict 时记录为 None。
    说明:
        号码支持列表或「01,02,...」字符串；期号按「年份+期序」补全；
        日期缺失时留空，不拿今天兜底造号。
    """
    if not isinstance(item, dict):
        return None, _preview(item), None
    period_raw = _pick(item, _PERIOD_ALIASES)
    date_raw = _pick(item, _DATE_ALIASES)
    date_text = '' if date_raw is None else str(date_raw)
    numbers_raw = _pick(item, _NUMBERS_ALIASES)
    numbers = []
    if isinstance(numbers_raw, (list, tuple)):
        try:
            numbers = [int(float(n)) for n in numbers_raw if str(n).strip() != '']
        except (TypeError, ValueError):
            numbers = []
    elif isinstance(numbers_raw, str) and numbers_raw.strip():
        numbers = DataUtils.parse_numbers_text(numbers_raw, dedupe=True, limit_range=True)
    special_raw = _pick(item, _SPECIAL_ALIASES)
    special = None
    if special_raw is not None and str(special_raw).strip() != '':
        try:
            special = int(float(special_raw))
        except (TypeError, ValueError):
            special = None
    evidence = []
    if special is None and len(numbers) >= 7:
        # 记录里没有单独的特别码字段时，按「第 7 个号码」推定并记录依据
        special = numbers[6]
        numbers = numbers[:6]
        evidence.append('特别码取第 7 个（记录里没有单独的特别码字段）')
    period, period_full, period_year = _period_fields(period_raw, date_text)
    if period_raw is not None and period_full is not None:
        raw_digits = re.sub(r'\D', '', str(period_raw))
        if len(raw_digits) < 7:
            evidence.append('年份取自日期：期序 %d + %s → 完整期号 %d'
                            % (period, date_text or '无日期', period_full))
    return ({'period': period, 'period_full': period_full, 'period_year': period_year,
             'date': date_text, 'numbers': numbers, 'special': special},
            _preview(item), period_raw, evidence)


def _parse_json_items(raw_text):
    """JSON 分支：数组或单对象；允许 {"data": [...]} 之类包装"""
    try:
        data = json.loads(raw_text.lstrip('\ufeff'))
    except json.JSONDecodeError as exc:
        return [], [('第%d行' % (exc.lineno or 1), raw_text.lstrip()[:40], '不是合法 JSON')], 1
    if isinstance(data, dict):
        for key in ('data', 'records', 'list', 'items', 'rows'):
            if isinstance(data.get(key), list):
                data = data[key]
                break
        else:
            data = [data]
    if not isinstance(data, list):
        return [], [('第1行', raw_text[:40], '不是合法 JSON')], 1
    items = [(item, '第%d条' % index, True, _preview(item))
             for index, item in enumerate(data, 1) if isinstance(item, dict)]
    return items, [], 0


def _sniff_delimiter(lines):
    """识别 CSV/TSV 分隔符（Tab → 逗号 → 分号）

    互斥条件:
        - 首行命中表头别名且至少 4 列 → 认为是带表头的 CSV；
        - 否则要求首行分隔符数量 >= 8（9 列数据）且首列是纯数字期号。
        这样「第X期 日期 号码」这类空格文本不会被逗号分支抢走。
    """
    for delimiter in ('\t', ',', ';'):
        cells = next(csv.reader([lines[0][1]], delimiter=delimiter), [])
        lowered = [str(c).strip().lower() for c in cells]
        if len(cells) >= 4 and any(alias in lowered for alias in
                                   _PERIOD_ALIASES + _DATE_ALIASES + _NUMBERS_ALIASES
                                   + _SPECIAL_ALIASES):
            return delimiter
        counts = [line.count(delimiter) for _, line in lines[:3]]
        if counts and max(counts) >= 8 and len(cells) >= 9 \
                and re.fullmatch(r'\d{1,12}', cells[0].strip()):
            return delimiter
    return None


def _parse_csv_items(raw_text, lines):
    """CSV/TSV 分支：表头按别名映射；无表头按前 9 列位置取值"""
    delimiter = _sniff_delimiter(lines)
    if delimiter is None:
        return [], [('第1行', lines[0][1][:40], '行里分段不足 9')], 1
    items, diagnostics, skipped = [], [], 0
    checked_header = False
    header_map = None
    reader = csv.reader(raw_text.splitlines(), delimiter=delimiter)
    for row_index, row in enumerate(reader, 1):
        cells = [str(c).strip() for c in row]
        if not any(cells):
            continue
        if not checked_header:
            checked_header = True
            lowered = [c.lower() for c in cells]
            if any(alias in lowered for alias in
                   _PERIOD_ALIASES + _DATE_ALIASES + _NUMBERS_ALIASES + _SPECIAL_ALIASES):
                header_map = _build_header_map(lowered)
                continue
        if header_map:
            record = _row_by_header(cells, header_map)
        else:
            record = _row_by_position(cells)
        if record is None:
            skipped += 1
            diagnostics.append(('第%d行' % row_index, ' '.join(cells)[:40], '行里分段不足 9'))
            continue
        items.append((record, '第%d行' % row_index, True, _preview(record)))
    return items, diagnostics, skipped


def _build_header_map(lowered):
    """把表头行映射为字段下标；同时兼容 n1..n6 / 号码1..号码6 六列式"""
    mapping = {}
    for field, aliases in (('period', _PERIOD_ALIASES), ('date', _DATE_ALIASES),
                           ('numbers', _NUMBERS_ALIASES), ('special', _SPECIAL_ALIASES)):
        for alias in aliases:
            if alias in lowered:
                mapping[field] = lowered.index(alias)
                break
    for prefix in ('n', 'num', '号码', '正码'):
        indexes = [lowered.index((prefix + str(i)).lower())
                   if (prefix + str(i)).lower() in lowered else -1 for i in range(1, 7)]
        if all(index >= 0 for index in indexes):
            mapping['six'] = indexes
            break
    return mapping


def _row_by_header(cells, mapping):
    """按表头映射组装一行记录；缺关键列返回 None"""
    record = {}
    if 'period' in mapping and mapping['period'] < len(cells):
        record['period'] = cells[mapping['period']]
    if 'date' in mapping and mapping['date'] < len(cells):
        record['date'] = cells[mapping['date']]
    if 'six' in mapping and max(mapping['six']) < len(cells):
        record['numbers'] = [cells[index] for index in mapping['six']]
    elif 'numbers' in mapping and mapping['numbers'] < len(cells):
        record['numbers'] = cells[mapping['numbers']]
    if 'special' in mapping and mapping['special'] < len(cells):
        record['special'] = cells[mapping['special']]
    if 'period' not in record or 'numbers' not in record:
        return None
    return record


def _row_by_position(cells):
    """无表头时按位置取前 9 列：期号 / 日期 / 6 正码 / 特别码"""
    if len(cells) < 9:
        return None
    return {'period': cells[0], 'date': cells[1], 'numbers': cells[2:8], 'special': cells[8]}


def _parse_txt_items(lines):
    """单行 9 段分支：逐行委托 DataUtils.parse_txt_line"""
    items, diagnostics, skipped = [], [], 0
    for line_no, line in lines:
        parts = line.split()
        if len(parts) >= 9 and _values_conflict(parts[0], parts[1]):
            skipped += 1
            diagnostics.append(('第%d行' % line_no, line[:40], '期号与日期年份冲突'))
            continue
        parsed = DataUtils.parse_txt_line(line)
        if not parsed:
            skipped += 1
            diagnostics.append(('第%d行' % line_no, line[:40], '行里分段不足 9'))
            continue
        period, date, numbers, special = parsed
        period_seq, period_full, period_year = _period_fields(period, date)
        items.append(({'period': period_seq, 'period_full': period_full,
                       'period_year': period_year, 'date': date,
                       'numbers': numbers, 'special': special},
                      '第%d行' % line_no, False, line[:40], '单行 9 段', []))
    return items, diagnostics, skipped


def _parse_segmented_items(raw_text):
    """多行/单行原始文本分支：切分后逐条按特征判定三个字段（逐记录识别）

    每条记录独立判定日期/期号/号码的位置，相邻两期写法可以不同；
    无法判定的记录按行号与前 40 字进入诊断列表，不猜、不入库。
    """
    items, diagnostics, skipped = [], [], 0
    styles = []
    for segment, line_no in _split_periods_located(raw_text):
        if set(segment.strip()) <= set('=-_ '):
            # ==== / ---- 这类纯分隔行不是数据
            continue
        record, preview, style, reason, _, evidence = _parse_record_features(segment)
        if record is None:
            skipped += 1
            diagnostics.append(('第%d行' % line_no, preview or segment[:40], reason or '无法判定'))
            continue
        if style:
            styles.append(style)
        items.append((record, '第%d行' % line_no, False, preview or segment[:40], style, evidence))
    return items, diagnostics, skipped, styles


def _detect_format(raw_text, lines):
    """单一判定入口：返回格式名（顺序固定，互斥条件见各分支注释）

    判定顺序:
        1) 首字符是 { 或 [ → JSON；解析失败记为「JSON（非法）」，不再落到其他分支
        2) 首行 Tab / 逗号 / 分号数量 >= 8 且能组成 9 列（表头别名或纯数字首列）→ CSV/TSV
        3) 多行且切段后至少 2 段可解析 → 竖排多期
        4) 任一行严格符合 9 段 TXT 网格 → 单行 9 段
        5) 其余 → 原始文本
    """
    stripped = raw_text.lstrip('\ufeff').strip()
    if stripped[:1] in ('{', '['):
        try:
            json.loads(stripped)
            return 'JSON'
        except json.JSONDecodeError:
            return 'JSON（非法）'
    if _sniff_delimiter(lines) is not None:
        return 'CSV/TSV'
    if len(lines) > 1:
        groups = _split_periods_located(raw_text)
        parsed_count = sum(1 for segment, _ in groups
                           if _parse_record_features(segment)[0] is not None)
        if len(groups) > 1 and parsed_count > 1:
            return '竖排多期'
    for _, line in lines:
        if len(line.split()) >= 9 and DataUtils.parse_txt_line(line):
            return '单行 9 段'
    return '原始文本'


def _finalize_records(host, records, locations, previews, filter_library=True):
    """缺期号拒绝 + 批内去重（保留最后一次）+ 库内期号冲突过滤

    返回 dict:
        records   可写记录（已排除缺期号；缺期号存在时由调用方决定是否整批拒绝）
        missing   [(定位, 前40字)]
        merged    批内去重丢弃条数
        conflicts 与库内已有期号重复、未写入的期号列表
    """
    missing = [(locations[index], previews[index])
               for index, record in enumerate(records) if _record_full_period(record) is None]
    result = {'records': [], 'missing': missing, 'merged': 0, 'conflicts': [], 'locations': []}
    # 缺期号条目直接排除；剩余记录仍然去重/过滤，供「跳过缺期号继续导入」使用
    valid = [(record, locations[index]) for index, record in enumerate(records)
             if _record_full_period(record) is not None]
    if not valid:
        return result
    last_index = {}
    for index, (record, _) in enumerate(valid):
        last_index[_record_full_period(record)] = index
    deduped = [pair for index, pair in enumerate(valid)
               if last_index[_record_full_period(pair[0])] == index]
    result['merged'] = len(valid) - len(deduped)
    if filter_library:
        # 去重键一律用完整期号（2026308），避免 2025/2026 的同一期序互撞
        existing = {_record_full_period(record)
                    for record in getattr(host, 'historical_data', [])
                    if _record_full_period(record) is not None}
        result['conflicts'] = [_record_full_period(record) for record, _ in deduped
                               if _record_full_period(record) in existing]
        deduped = [pair for pair in deduped
                   if _record_full_period(pair[0]) not in existing]
    result['records'] = [record for record, _ in deduped]
    result['locations'] = [location for _, location in deduped]
    return result


def _auto_parse_text(host, raw_text, encoding_label='粘贴文本', filter_library=True):
    """粘贴与文件共用的自动识别入口：判定 → 解析 → 规范化 → 去重/冲突过滤

    返回 dict:
        format / encoding / parsed / skipped / errors / missing / merged /
        conflicts / records / sample
    """
    raw_text = raw_text or ''
    lines = [(index, line.strip()) for index, line in enumerate(raw_text.splitlines(), 1)
             if line.strip()]
    format_name = '空内容'
    items, diagnostics, skipped = [], [], 0
    styles = []
    if lines:
        format_name = _detect_format(raw_text, lines)
        if format_name == 'JSON':
            items, diagnostics, skipped = _parse_json_items(raw_text)
            styles = ['JSON'] * len(items)
        elif format_name == 'JSON（非法）':
            try:
                json.loads(raw_text.lstrip('\ufeff'))
            except json.JSONDecodeError as exc:
                diagnostics = [('第%d行' % (exc.lineno or 1), raw_text.lstrip()[:40],
                                '不是合法 JSON')]
                skipped = 1
        elif format_name == 'CSV/TSV':
            items, diagnostics, skipped = _parse_csv_items(raw_text, lines)
            styles = ['CSV/TSV'] * len(items)
        elif format_name == '单行 9 段':
            items, diagnostics, skipped = _parse_txt_items(lines)
            styles = ['单行 9 段'] * len(items)
        else:
            items, diagnostics, skipped, styles = _parse_segmented_items(raw_text)

    records, locations, previews, evidences = [], [], [], []
    for item in items:
        payload, location, needs_canonical, preview = item[:4]
        style = item[4] if len(item) > 4 else ''
        evidence = item[5] if len(item) > 5 else []
        if needs_canonical:
            record, canonical_preview, period_raw, canonical_evidence = _canonicalize(payload)
            preview = preview or canonical_preview
            evidence = canonical_evidence
            if record is None:
                skipped += 1
                diagnostics.append((location, preview, '行里分段不足 9'))
                continue
            if _values_conflict(period_raw, record['date']):
                skipped += 1
                diagnostics.append((location, preview, '期号与日期年份冲突'))
                continue
        else:
            record = payload
        records.append(record)
        locations.append(location)
        previews.append(preview)
        if evidence:
            evidences.append((location, style, evidence))
    return _build_report(host, records, locations, previews, format_name, encoding_label,
                         skipped, diagnostics, filter_library, styles, evidences)


def _build_report(host, records, locations, previews, format_name, encoding_label,
                  skipped=0, diagnostics=None, filter_library=True, styles=None, evidences=None):
    """把规范化后的记录汇总成统一的识别报告（含缺期号 / 合并 / 冲突 / 首条样例 / 推定依据）"""
    diagnostics = diagnostics or []
    finalized = _finalize_records(host, records, locations, previews, filter_library)
    example = next((record for record in records if _record_full_period(record) is not None), None)
    # 推定依据只保留最终会入库的记录，避免重复期把结果面板刷满
    kept_locations = set(finalized['locations'])
    kept_evidences = [item for item in (evidences or []) if item[0] in kept_locations]
    return {
        'format': format_name, 'encoding': encoding_label,
        'parsed': len([record for record in records
                       if _record_full_period(record) is not None]),
        'skipped': skipped + len(finalized['missing']), 'errors': diagnostics,
        'missing': finalized['missing'], 'merged': finalized['merged'],
        'conflicts': finalized['conflicts'], 'records': finalized['records'],
        'locations': finalized['locations'], 'sample': example,
        'styles': dict(Counter(styles or [])),
        'evidences': kept_evidences,
    }


def _style_phrase(code):
    """把写法代码翻成人话（PDN → 期号在前、日期居中、号码在后）"""
    if code in ('JSON', 'CSV/TSV', '单行 9 段'):
        return code
    names = {'D': '日期', 'P': '期号', 'N': '号码'}
    if len(code) == 1:
        return {'D': '只有日期', 'P': '只有期号', 'N': '只有号码'}.get(code, code)
    if len(code) == 3:
        return '%s在前、%s居中、%s在后' % (names.get(code[0], code[0]),
                                        names.get(code[1], code[1]),
                                        names.get(code[2], code[2]))
    return '→'.join(names.get(ch, ch) for ch in code)


def _looks_numbers_only(preview):
    """判断一条缺期号预览是否只是「7 个号码」而没有日期/期号特征"""
    text = re.sub(r'[^\d]+', ' ', str(preview or ''))
    values = [int(part) for part in text.split() if part]
    return len(values) >= 5 and all(1 <= value <= 49 for value in values)


def _join_locations(missing, limit=8):
    """把定位拼成「第 1、9、17 行」；超过上限时用「等 N 行」收尾"""
    names = [location for location, _ in missing]
    if len(names) > limit:
        return '、'.join(names[:limit]) + ' 等 %d 行' % len(names)
    return '、'.join(names)


def _set_detect_label(host, report):
    """把识别结果写成人话标签（固定顶部总结 + 写法分布 + 跳过明细 + 推定依据提示）"""
    label = getattr(host, 'import_detect_label', None)
    if label is None:
        return
    styles = report.get('styles') or {}
    style_parts = []
    for code, count in sorted(styles.items(), key=lambda item: -item[1]):
        style_parts.append('%s（%d 条）' % (_style_phrase(code), count))
    missing = report.get('missing') or []
    errors = report.get('errors') or []
    total = report.get('parsed', 0) + report.get('skipped', 0)
    reason_parts = []
    if missing:
        reason_parts.append('缺期号 %d' % len(missing))
    if errors:
        reason_parts.append('无法判定 %d' % len(errors))
    # 顶部固定总结：共 N 条 · 成功 X · 跳过 Y（原因分类）· 合并重复 K
    lines = ['共 %d 条 · 成功 %d · 跳过 %d（%s）· 合并重复 %d'
             % (total, report.get('parsed', 0), report.get('skipped', 0),
                ' / '.join(reason_parts) if reason_parts else '无',
                report.get('merged', 0))]
    # 写法分布（人话）
    if style_parts:
        conclusion = '全部解析成功。' if not (missing or errors) else '已尽力解析，跳过项见下。'
        lines.append('识别到 %s：%s；%s' % (report.get('format'),
                                          '、'.join(style_parts), conclusion))
    else:
        lines.append('识别为 %s，未识别到可解析的记录。' % report.get('format'))
    lines.append('来源：%s（编码 %s）' % (report.get('format'), report.get('encoding')))
    # 缺期号：纯号码 / 其他缺号分开说明，行号可查
    if missing:
        numbers_only = [item for item in missing if _looks_numbers_only(item[1])]
        others = [item for item in missing if not _looks_numbers_only(item[1])]
        if numbers_only:
            lines.append('有 %d 行只有号码、没有期号和日期，默认不导入：%s。'
                         % (len(numbers_only), _join_locations(numbers_only)))
        if others:
            lines.append('有 %d 行缺期号，默认不导入：%s（可点“跳过缺期号继续”）。'
                         % (len(others), _join_locations(others)))
    # 无法判定：逐条给出行号与原因，不静默
    for location, preview, reason in errors[:3]:
        lines.append('%s %s：%s' % (location, reason, preview))
    if len(errors) > 3:
        lines.append('……另有 %d 行无法判定（见结果区明细）。' % (len(errors) - 3))
    if report.get('conflicts'):
        lines.append('库内已有 %d 期（按完整期号判定），本批不覆盖。' % len(report['conflicts']))
    sample = report.get('sample')
    if sample:
        numbers = sample.get('numbers') or []
        numbers_text = ' '.join(str(n).zfill(2) for n in numbers)
        special = sample.get('special')
        special_text = str(special).zfill(2) if special is not None else '?'
        lines.append('首条：%s / 期序 %s / %s + %s'
                     % (_normalize_date_text(sample.get('date')) or '日期未知',
                        sample.get('period'), numbers_text, special_text))
    label.setText('\n'.join(lines))
    # 推定依据放到 tooltip，鼠标悬停即可查看，不挤占主面板
    evidence_lines = ['%s：%s' % (location, '；'.join(items))
                      for location, _style, items in (report.get('evidences') or [])]
    tooltip = '\n'.join(evidence_lines)
    label.setToolTip(tooltip if tooltip else '无推定项：字段均为原文直取')


def _diagnostics_text(report, limit=20):
    """把诊断条目拼成弹窗文本（定位 + 原因 + 前 40 字）"""
    errors = report.get('errors') or []
    lines = ['%s（%s）：%s' % (location, reason, preview)
             for location, preview, reason in errors[:limit]]
    if len(errors) > limit:
        lines.append('……共 %d 条诊断' % len(errors))
    return '\n'.join(lines)


def _missing_detail(missing):
    """缺期号明细文本：第 N 行缺期号，未导入：<前 40 字>"""
    lines = ['%s缺期号，未导入：%s' % (location, preview) for location, preview in missing]
    return '\n'.join(lines)


def _append_missing_to_result(host, missing):
    """把全部缺期号行号写进右侧结果区，避免提示被关掉后无处可查"""
    edit = getattr(host, 'converted_text_edit', None)
    if edit is None:
        return
    edit.setPlainText('【缺期号】\n' + _missing_detail(missing))


def _ask_skip_missing(host, missing):
    """缺期号提示框：默认整批不导入；提供显式「跳过缺期号继续导入」按钮

    返回:
        bool: True 表示用户明确选择跳过缺期号行、继续导入其余记录。
    """
    _append_missing_to_result(host, missing)
    remain = 0
    report = getattr(host, '_last_import_report', None) or {}
    remain = len(report.get('records') or [])
    if remain <= 0:
        QMessageBox.warning(host, "缺少期号",
                            "全部 %d 条都缺期号，未导入：\n%s" % (len(missing), _missing_detail(missing)))
        return False
    box = QMessageBox(host)
    box.setIcon(QMessageBox.Icon.Warning)
    box.setWindowTitle("缺少期号")
    box.setText("以下行缺少期号，整批尚未导入：\n" + _missing_detail(missing))
    skip_button = box.addButton(
        "跳过缺期号的 %d 行，继续导入其余 %d 行" % (len(missing), remain),
        QMessageBox.ButtonRole.AcceptRole)
    cancel_button = box.addButton("取消（本次不导入）", QMessageBox.ButtonRole.RejectRole)
    box.setDefaultButton(cancel_button)
    box.exec()
    return box.clickedButton() is skip_button


def _period_is_valid(record):
    """入库前自检：期序必须非空、非 None/"None"/0；完整期号必须能拆出年份+期序

    参数:
        record (dict): 规范化后的记录。展示/存储用 period（期序），
            去重与自检用 period_full（完整期号，如 2026308）。
    """
    period = record.get('period') if isinstance(record, dict) else record
    if period is None:
        return False
    text = str(period).strip()
    if text in ('', 'None', 'null', '0'):
        return False
    try:
        value = int(float(text))
    except (TypeError, ValueError):
        return False
    if value <= 0:
        return False
    if not isinstance(record, dict):
        return True
    full = _record_full_period(record)
    if full is None:
        return False
    full_text = str(full)
    if len(full_text) < 7:
        return False
    year, sequence = int(full_text[:4]), int(full_text[4:])
    return 1990 <= year <= 2099 and sequence > 0


def _assert_batch_periods(host, records, locations):
    """写库前整批断言；返回不合规明细 [(定位, 期号)]，非空时必须整批不入"""
    invalid = []
    for index, record in enumerate(records):
        if not _period_is_valid(record):
            show = _record_full_period(record) or record.get('period')
            invalid.append((locations[index] if index < len(locations) else '第%d条' % (index + 1),
                            show))
    return invalid


def _import_notes(report):
    """拼装导入成功后的补充说明（合并重复 / 库内冲突未写入）"""
    notes = []
    if report.get('merged'):
        notes.append("已合并重复 %d 期" % report['merged'])
    if report.get('conflicts'):
        notes.append("其中 %d 期与库内已有期号重复，未写入（如需覆盖请告知后续实现）：%s"
                     % (len(report['conflicts']),
                        '、'.join(str(period) for period in report['conflicts'])))
    return notes


def _register_record(host, record):
    """写入时刻固化生肖快照（与既有导入入口保持同一口径）"""
    LotteryConfig.attach_zodiac_snapshot(record, getattr(host, 'zodiac_binding', {}))


def _format_normalized(record):
    """按「日期 - 期序 - 6 正码（两位补零） - 特别码（两位补零）」输出唯一标准顺序

    参数:
        record (dict): 规范化后的记录（period/period_full/date/numbers/special）。
    返回:
        str: 如 `2026-11-04 308 25 16 28 08 06 40 + 46`；期序不带年份前缀。
    """
    date_text = _normalize_date_text(record.get('date')) or '日期未知'
    period = record.get('period')
    numbers = record.get('numbers') or []
    special = record.get('special')
    parts = [date_text, str(period)] + [str(n).zfill(2) for n in numbers]
    if special is not None:
        parts.extend(['+', str(special).zfill(2)])
    return ' '.join(parts)


def _display_sorted(records):
    """展示排序：日期降序 → 完整期号降序（只影响展示顺序，不改变存储）"""
    return sorted(records, key=lambda record: (
        _normalize_date_text(record.get('date')) or '',
        _record_full_period(record) or 0), reverse=True)


def on_convert(host):
    """「转换为标准格式」事件：支持大量文本批量转换，自动识别多期数据

    功能:
        读取输入框文本 → _split_periods 切分 → parse_raw_data 解析 →
        format_data 生成标准行，成功的结果一次性写入结果框。

    参数:
        host: 主窗口实例。读取 host.raw_text_edit；写入 host.converted_text_edit
            与 host.statusBar()。

    返回:
        无。

    调用方:
        install(host) 中绑定为 host._on_convert_clicked，
        「转换为标准格式」按钮 clicked 时触发。

    副作用:
        1) 成功时把多行结果 setPlainText 覆盖写入 converted_text_edit；
        2) 在状态栏显示“成功 N 条 / 失败 M 条”统计；
        3) 输入为空或全部解析失败时弹 QMessageBox 提示，且不改动结果框。
        本事件不写历史数据文件（写盘只由 on_add_to_history / on_batch_import 负责）。

    异常:
        不向外抛异常；解析失败由 DataUtils 返回空结果体现。
    """
    raw_text = host.raw_text_edit.toPlainText()
    if not raw_text.strip():
        QMessageBox.warning(host, "提示", "请输入要转换的原始数据")
        return
    # 与入库入口共用同一自动识别引擎；转换只是预览，不做库内期号冲突过滤
    report = _auto_parse_text(host, raw_text, '粘贴文本', filter_library=False)
    host._last_import_report = report
    _set_detect_label(host, report)
    # 统一归一化顺序，并按「日期降序 → 期号降序」展示（排序不改变存储）
    formatted_lines = [_format_normalized(record) for record in _display_sorted(report['records'])]
    if report['missing']:
        # 缺期号行必须在结果区可见，且不会被格式化成一期（避免出现“第None期”）
        formatted_lines.append('【缺期号】')
        formatted_lines.extend(_missing_detail(report['missing']).splitlines())
    if report['errors']:
        # 无法判定的行逐条列出（行号 + 原因 + 前 40 字），不静默吞掉
        formatted_lines.append('【无法判定】')
        formatted_lines.extend(_diagnostics_text(report, limit=200).splitlines())
    if report.get('evidences'):
        # 推定依据：特别码取第 7 个 / 年份取自日期 / 两位年补全，逐条可见
        formatted_lines.append('【推定依据】')
        for location, _style, items in report['evidences']:
            formatted_lines.append('%s：%s' % (location, '；'.join(items)))
    if formatted_lines:
        host.converted_text_edit.setPlainText('\n'.join(formatted_lines))
        host.statusBar().showMessage(
            "识别 %s：成功 %d 条，失败 %d 条"
            % (report['format'], len(report['records']),
               report['skipped'] + len(report['missing'])))
    else:
        detail = _diagnostics_text(report) or '未识别到可解析的数据'
        QMessageBox.warning(host, "错误", "无法解析数据：\n" + detail)


def on_add_to_history(host):
    """「添加到历史记录」事件：支持批量添加多期数据（校验 → 插入 → 保存）

    功能:
        把输入框文本按 _split_periods 切分并逐段解析成历史记录字典，
        经主窗口校验后插入 host.historical_data 头部，然后写盘并刷新表格。

    参数:
        host: 主窗口实例。读取 host.raw_text_edit；调用本页校验函数
            validate_record / show_validation_results（install 已绑定到
            host._validate_record / host._show_validation_results），
            以及主窗口基础能力 host._save_data 与 host 上绑定的 update_history_table；
            写 host.historical_data、host.raw_text_edit、host.converted_text_edit。

    返回:
        无。

    调用方:
        install(host) 中绑定为 host._on_add_to_history_clicked，
        「添加到历史记录」按钮 clicked 时触发。

    副作用:
        1) 通过校验后修改 host.historical_data（在头部插入新记录）；
        2) 调用 _save_data() 把历史数据落盘到 JSON；
        3) 调用 update_history_table(host) 刷新历史记录页表格；
        4) 成功后清空本页输入框与转换结果框，并在状态栏提示；
        5) 校验不通过或解析失败时仅弹窗提示，不写盘、不改历史数据。
    """
    raw_text = host.raw_text_edit.toPlainText()
    if not raw_text.strip():
        QMessageBox.warning(host, "提示", "请输入要添加的原始数据")
        return
    # 粘贴与文件共用同一自动识别引擎（JSON → CSV/TSV → 竖排 → 单行 9 段 → 兜底）
    report = _auto_parse_text(host, raw_text, '粘贴文本')
    host._last_import_report = report
    _set_detect_label(host, report)

    missing_count = len(report['missing'])
    if missing_count:
        # 默认 fail-fast：只要有一行缺期号就整批不入；用户显式点“跳过继续”才继续
        if not _ask_skip_missing(host, report['missing']):
            host.statusBar().showMessage("本次未导入（%d 行缺期号）" % missing_count)
            return

    records = report['records']
    if not records:
        detail = _diagnostics_text(report)
        QMessageBox.warning(host, "错误",
                            "无法解析数据：" + ('\n' + detail if detail else '请检查格式'))
        host.statusBar().showMessage("本次未导入（0 条可写记录）")
        return

    # 写库前自检：期号必须非空且能拆出年份+期序，任一不合规整批不入
    invalid = _assert_batch_periods(host, records, report['locations'])
    if invalid:
        detail = '\n'.join('%s：%s' % (location, period) for location, period in invalid[:20])
        QMessageBox.warning(host, "期号自检失败",
                            "整批未导入：%d 条期号不合规：\n%s" % (len(invalid), detail))
        host.statusBar().showMessage("本次未导入（%d 条期号不合规）" % len(invalid))
        return

    all_issues = []
    for record in records:
        # 写入时刻固化生肖快照：之后用户改绑号码生肖，本期的历史展示不再被追溯改写
        _register_record(host, record)
        all_issues.extend(host._validate_record(record))
    # 先集中校验、再统一写入：用户若在确认框选择取消，则一条都不插入，避免只写半批数据
    if all_issues and not host._show_validation_results(all_issues):
        host.statusBar().showMessage("本次未导入（校验未通过）")
        return

    for offset, record in enumerate(records):
        # 逐条插到 0、1、2…：既保持本次粘贴的原始期序，又整体排在旧数据之前（最新在前）
        host.historical_data.insert(offset, record)
    host._save_data()
    host._update_history_table()
    host.raw_text_edit.clear()
    host.converted_text_edit.clear()
    notes = _import_notes(report)
    message = "已添加 %d 条数据到历史记录" % len(records)
    if notes:
        message += "\n" + "\n".join(notes)
    if report['errors']:
        message += "\n诊断：\n" + _diagnostics_text(report)
    QMessageBox.information(host, "成功", message)
    host.statusBar().showMessage(
        "导入 %d 条 / 跳过 %d 条（%d 条缺期号）/ 合并重复 %d 期"
        % (len(records), missing_count, missing_count, report['merged']))


def on_batch_import(host):
    """「批量导入」事件：从 JSON / CSV / TXT 文件导入历史记录

    功能:
        弹出文件选择框，交给本页 parse_import_file 统一解析，
        成功后把记录追加到 host.historical_data 并落盘、刷新表格。

    参数:
        host: 主窗口实例。调用 parse_import_file / host._save_data /
            update_history_table(host)；写 host.historical_data 与两个预测指纹字段。

    返回:
        无（用户取消文件选择时直接返回）。

    调用方:
        install(host) 中绑定为 host._on_batch_import_clicked，
        「批量导入」按钮 clicked 时触发。

    副作用:
        1) 扩展 host.historical_data（追加到末尾，与手动添加的“头部插入”不同）；
        2) _save_data() 落盘 JSON、update_history_table(host) 刷新历史表格；
        3) 把 _data_fingerprint_at_last_predict /
           _data_fingerprint_at_last_ml_predict 置 None，解除“无新数据禁止预测”锁定；
        4) 失败/无有效数据时弹窗提示，不写盘。

    异常:
        捕获解析过程中的全部异常并转成弹窗“导入失败: …”，不让异常中断界面。
    """
    file_path, _ = QFileDialog.getOpenFileName(host, "批量导入", "",
        "所有支持格式 (*.json *.csv *.txt *.parquet);;JSON文件 (*.json);;CSV文件 (*.csv);;TXT文件 (*.txt);;所有文件 (*)")
    if not file_path:
        return
    try:
        imported_data, report = parse_import_file(host, file_path, with_report=True)
    except Exception as e:
        QMessageBox.warning(host, "错误", "导入失败: " + str(e))
        return
    host._last_import_report = report
    _set_detect_label(host, report)

    missing_count = len(report['missing'])
    if missing_count:
        # 缺期号同样 fail-fast；用户明确点“跳过继续”才继续导入其余记录
        if not _ask_skip_missing(host, report['missing']):
            host.statusBar().showMessage("本次未导入（%d 行缺期号）" % missing_count)
            return

    imported_data = report['records']
    if not imported_data:
        detail = _diagnostics_text(report)
        QMessageBox.warning(host, "提示",
                            "未从文件中解析到有效数据（识别为 %s）%s"
                            % (report['format'], ('\n' + detail) if detail else ''))
        host.statusBar().showMessage("本次未导入（0 条可写记录）")
        return

    invalid = _assert_batch_periods(host, imported_data, report['locations'])
    if invalid:
        detail = '\n'.join('%s：%s' % (location, period) for location, period in invalid[:20])
        QMessageBox.warning(host, "期号自检失败",
                            "整批未导入：%d 条期号不合规：\n%s" % (len(invalid), detail))
        host.statusBar().showMessage("本次未导入（%d 条期号不合规）" % len(invalid))
        return

    # 导入同样属于“写入时刻”：逐条固化当前绑定快照（已有快照的记录不会被覆盖）
    for record in imported_data:
        _register_record(host, record)
    host.historical_data.extend(imported_data)
    host._save_data()
    host._update_history_table()
    # 数据已变化：清空算法/ML 两条“上次预测时的数据指纹”，
    # 否则指纹校验会把旧指纹当成“数据未变”，继续锁定预测按钮
    host._data_fingerprint_at_last_predict = None
    host._data_fingerprint_at_last_ml_predict = None
    notes = _import_notes(report)
    message = "成功导入 %d 条记录" % len(imported_data)
    if notes:
        message += "\n" + "\n".join(notes)
    QMessageBox.information(host, "成功", message)
    host.statusBar().showMessage(
        "导入 %d 条 / 跳过 %d 条（%d 条缺期号）/ 合并重复 %d 期"
        % (len(imported_data), missing_count, missing_count, report['merged']))


def on_clear_all(host):
    """「清除数据」事件：清空本页输入框与转换结果

    功能:
        同时清空原始数据输入框和转换结果框，只清界面内容，不动历史记录。

    参数:
        host: 主窗口实例。清空 host.raw_text_edit 与 host.converted_text_edit。

    返回:
        无。

    调用方:
        install(host) 中绑定为 host._on_clear_all_data_clicked，
        「清除数据」按钮 clicked 时触发。

    副作用:
        1) 清空两个文本框并在状态栏提示；
        2) 不删除 host.historical_data、不写盘——“清除数据”只针对本页临时输入，
           与历史记录页的删除操作用途不同。
    """
    try:
        host.raw_text_edit.clear()
    except Exception:
        pass
    host.converted_text_edit.clear()
    host.statusBar().showMessage("已清除输入和转换结果")


def validate_record(host, record, is_batch=False):
    """校验单条待导入记录，返回问题列表

    功能:
        检查期号是否与现有历史数据重复、期号/正码是否缺失、号码是否超出 1-49、
        同一期内正码是否重复。问题以 (级别, 文案) 元组返回，级别为
        'error'（阻断）或 'warning'（仅提示）。

    参数:
        host: 主窗口实例，读取 host.historical_data 做期号查重。
        record (dict): 待校验记录，读取 period / numbers / special。
        is_batch (bool): 保留的兼容参数，当前不改变校验规则。

    返回:
        list[tuple[str, str]]: 问题列表；无问题时返回 []。

    注意:
        只读 host.historical_data 做期号查重，不修改任何记录；
        号码越界与同期内号码重复只记为 warning，不阻断导入，是否继续由
        show_validation_results 决定；期号重复命中首条即 break，只报一次。
    """
    issues = []
    period = record.get('period')
    numbers = record.get('numbers', [])
    special = record.get('special')

    # 检查期号重复：按完整期号比较，避免 2025/2026 的同一期序互撞
    full_period = _record_full_period(record)
    if full_period is not None:
        for r in host.historical_data:
            if _record_full_period(r) == full_period:
                issues.append(('error', '期号重复: 第' + str(period) + '期（完整期号 '
                                + str(full_period) + '）已存在'))
                break

    # 检查数据不完整
    if period is None:
        issues.append(('error', '缺少期号'))
    if not numbers or len(numbers) < 6:
        issues.append(('error', '正码不完整，应有6个正码'))

    # 检查号码范围
    all_nums = list(numbers) + ([special] if special is not None else [])
    for n in all_nums:
        if n is not None and (n < 1 or n > 49):
            issues.append(('warning', '号码超出范围: ' + str(n) + ' (应为1-49)'))

    # 检查号码重复
    if len(numbers) != len(set(numbers)):
        dup = [n for n, c in Counter(numbers).items() if c > 1]
        issues.append(('warning', '同一期内出现重复数字: ' + ', '.join(str(d) for d in dup)))

    return issues


def show_validation_results(host, all_issues):
    """以弹窗展示校验结果，并返回用户是否继续

    功能:
        把问题按「严重问题 / 警告」分组渲染成富文本；存在严重问题时询问
        是否仍要继续，只有警告时仅提示且不影响导入。

    参数:
        host: 主窗口实例，作为弹窗父对象。
        all_issues (list[tuple[str, str]]): validate_record 汇总的问题列表。

    返回:
        bool: True 表示可以继续（无问题、仅有警告或用户确认继续）；
            False 表示用户取消导入。

    注意:
        存在 error 时用 Yes/No 询问，只有用户显式选择 Yes 才返回 True；
        只有 warning 时仅弹提示并固定返回 True；本函数只读 all_issues，
        不修改记录，也不写盘。
    """
    if not all_issues:
        return True

    errors = [iss for iss in all_issues if iss[0] == 'error']
    warnings = [iss for iss in all_issues if iss[0] == 'warning']

    msg = ""
    if errors:
        msg += '<p style="color:#E74C3C; font-weight:bold;">严重问题 (' + str(len(errors)) + '):</p>'
        msg += '<ul style="color:#E74C3C;">'
        for _, text in errors:
            msg += '<li>' + text + '</li>'
        msg += '</ul>'
    if warnings:
        msg += '<p style="color:#F39C12; font-weight:bold;">警告 (' + str(len(warnings)) + '):</p>'
        msg += '<ul style="color:#F39C12;">'
        for _, text in warnings:
            msg += '<li>' + text + '</li>'
        msg += '</ul>'

    if errors:
        msg += '<p style="font-weight:bold;">是否仍要继续？（不推荐）</p>'
        reply = QMessageBox.warning(host, "数据校验", msg,
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        return reply == QMessageBox.StandardButton.Yes
    else:
        msg += '<p>以上为警告信息，不影响数据导入。</p>'
        QMessageBox.information(host, "数据校验提示", msg)
        return True


def _report_from_records(host, raw_records, format_name, encoding_label):
    """把 DuckDB 直读（CSV / Parquet）的记录汇总成统一识别报告"""
    items = [(record, '第%d条' % index, True, _preview(record))
             for index, record in enumerate(raw_records, 1) if isinstance(record, dict)]
    records, locations, previews = [], [], []
    evidences = []
    skipped, diagnostics = 0, []
    for payload, location, _, preview in items:
        record, canonical_preview, period_raw, canonical_evidence = _canonicalize(payload)
        preview = preview or canonical_preview
        if record is None:
            skipped += 1
            diagnostics.append((location, preview, '行里分段不足 9'))
            continue
        if _values_conflict(period_raw, record['date']):
            skipped += 1
            diagnostics.append((location, preview, '期号与日期年份冲突'))
            continue
        records.append(record)
        locations.append(location)
        previews.append(preview)
        if canonical_evidence:
            evidences.append((location, '', canonical_evidence))
    return _build_report(host, records, locations, previews, format_name, encoding_label,
                         skipped, diagnostics, True, None, evidences)


def parse_import_file(host, file_path, with_report=False):
    """解析导入文件（JSON/CSV/TXT/Parquet），返回开奖记录列表

    功能:
        与粘贴入口共用 _auto_parse_text 这一套自动判定（JSON → CSV/TSV →
        竖排多期 → 单行 9 段 → 兜底），扩展名不再决定解析方式；
        文本文件先按 UTF-8（含 BOM）→ GB18030 → GBK → UTF-16 自动试编码。

    参数:
        host: 主窗口实例。读取 host._db（CSV/Parquet 优先 DuckDB 直读）与
            host.historical_data（库内期号冲突过滤）。
        file_path (str): 待解析文件路径。
        with_report (bool): True 时返回 (records, report)，report 含格式/编码/
            解析条数/跳过/缺期号/合并/冲突，供界面展示与诊断。

    返回:
        list[dict] 或 tuple[list[dict], dict]: 记录键为 period/date/numbers/special。

    异常:
        Parquet 读取失败时抛 ValueError（文案含原始错误），调用方弹窗展示原因。
    """
    ext = file_path.lower().rsplit('.', 1)[-1] if '.' in file_path else ''

    # Parquet 是二进制列式文件，无法做文本识别：仍走 DuckDB 直读
    if ext == 'parquet':
        if getattr(host, '_db', None) is None:
            raise ValueError("Parquet 文件读取失败: DuckDB 不可用")
        try:
            raw_records = host._db.read_table_file(file_path)
        except Exception as exc:
            raise ValueError("Parquet 文件读取失败: " + str(exc))
        report = _report_from_records(host, raw_records, 'Parquet（DuckDB 直读）', '二进制')
        return (report['records'], report) if with_report else report['records']

    try:
        with open(file_path, 'rb') as handle:
            raw_bytes = handle.read()
    except OSError as exc:
        raise ValueError("文件读取失败: " + str(exc))

    text, encoding = _decode_text(raw_bytes)
    if text is None:
        report = _build_report(host, [], [], [], '无法解码', '未知')
        report['skipped'] = 1
        report['errors'] = [('第1行', raw_bytes[:40].hex(),
                             '编码不是 UTF-8 / GB18030 / GBK / UTF-16')]
        return ([], report) if with_report else []

    # CSV 仍优先交给 DuckDB（对引号/多行字段更稳），失败则由文本自动识别兜底
    if ext == 'csv' and getattr(host, '_db', None) is not None:
        try:
            raw_records = host._db.read_table_file(file_path)
            report = _report_from_records(host, raw_records, 'CSV（DuckDB 直读）', encoding)
            return (report['records'], report) if with_report else report['records']
        except Exception as exc:
            print("DuckDB 直读文件失败，回退文本自动识别: " + str(exc))

    report = _auto_parse_text(host, text, encoding)
    return (report['records'], report) if with_report else report['records']


def install(host):
    """安装「数据导入与格式转换」选项卡：先挂本页事件，再构建界面（v0.0.28）

    功能:
        把 7 个模块级函数包成 lambda 挂到 host 同名属性，
        然后调用 build(host) 生成页面。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。

    返回:
        QWidget: 构建完成的页面（build 的返回值），供 addTab 使用。

    调用方:
        TAB/__init__.py 的 iter_tab_pages() 自动发现本页后，主窗口按
        “优先 install、无则 build”的规则调用本函数。

    副作用:
        在 host 上写入 7 个回调属性，供 build 里的按钮连接：
            host._on_convert_clicked        → on_convert
            host._on_add_to_history_clicked → on_add_to_history
            host._on_batch_import_clicked   → on_batch_import
            host._on_clear_all_data_clicked → on_clear_all
            host._validate_record           → validate_record
            host._show_validation_results   → show_validation_results
            host._parse_import_file         → parse_import_file（history 页跨页复用）

    说明:
        必须先绑定再 build：_build_input_panel 里按钮创建后立即 connect
        这些属性，属性不存在会直接抛 AttributeError。
        _validate_record / _show_validation_results / _parse_import_file
        已由主窗口迁入本模块；其中 parse_import_file 同时供 history 页导入
        按钮使用，因此保留 host 同名绑定。
    """
    host._on_convert_clicked = lambda: on_convert(host)
    host._on_add_to_history_clicked = lambda: on_add_to_history(host)
    host._on_batch_import_clicked = lambda: on_batch_import(host)
    host._on_clear_all_data_clicked = lambda: on_clear_all(host)
    host._validate_record = lambda record, is_batch=False: validate_record(host, record, is_batch)
    host._show_validation_results = lambda all_issues: show_validation_results(host, all_issues)
    host._parse_import_file = lambda file_path, with_report=False: parse_import_file(host, file_path, with_report)
    # 供历史记录页导入复用：识别结果展示与缺期号“跳过继续”确认，避免两处口径分叉
    host._refresh_import_report = lambda report: _set_detect_label(host, report)
    host._ask_skip_missing_import = lambda missing: _ask_skip_missing(host, missing)
    return build(host)


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "数据导入与格式转换",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 1,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """构建「数据导入与格式转换」选项卡页面

    功能:
        创建水平分割器，左半放输入面板、右半放结果面板，两侧等宽拉伸，
        再套一层带页边距的垂直布局作为页面根控件。

    参数:
        host: 主窗口实例（LotteryPredictionWindow），控件与状态挂载在此对象上。
            本函数写入 host.data_import_splitter，并通过子面板间接挂载
            host.raw_text_edit / host.converted_text_edit；
            读取 host.spacing / host.margin_* 作为布局参数。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        1) 创建 host.data_import_splitter 并设置句柄宽度 2px；
        2) 调用 host._apply_splitter_sizes 恢复上次保存的分割位置
           （配置缺失时由主窗口按默认比例处理）；
        3) 两栏 stretchFactor 均为 1，保证窗口缩放时输入/结果区域同步变化。
    """
    widget = QWidget()
    host.data_import_splitter = QSplitter(Qt.Orientation.Horizontal)
    # 分割条只占 2px：本页左右都是文本框，句柄过宽会明显压缩可读宽度
    host.data_import_splitter.setHandleWidth(2)

    left_panel = _build_input_panel(host)
    host.data_import_splitter.addWidget(left_panel)

    right_panel = _build_result_panel(host)
    host.data_import_splitter.addWidget(right_panel)

    # 两栏等宽拉伸：窗口变宽/变窄时输入区与结果区同步变化，避免单侧被挤到不可用
    host.data_import_splitter.setStretchFactor(0, 1)
    host.data_import_splitter.setStretchFactor(1, 1)
    # 恢复用户上次拖动的分割位置（键名 data_import_splitter 与 INI 段一致）
    host._apply_splitter_sizes(host.data_import_splitter, 'data_import_splitter')

    layout = QVBoxLayout(widget)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)
    layout.setSpacing(host.spacing)
    layout.addWidget(host.data_import_splitter)

    return widget
