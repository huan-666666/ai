# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/number_tail.py - 「数字选尾」选项卡页面构建模块
===========================================================================
功能说明：
    构建主窗口「数字选尾」选项卡的全部界面控件，并挂载到主窗口实例上。

TAB_INFO（供 TAB/__init__.py 自动发现）：
    title   = "数字选尾"
    order   = 14（最后一个数字工具页，紧接「数字排序」之后）
    enabled = True

依赖：
    - UI/UI.py：QWidget/QVBoxLayout/QHBoxLayout/QLabel/QPushButton/QTextEdit/QComboBox
    - lib.data_process.LotteryConfig.RESULT_SEPARATORS：15 种结果分隔符
      （显示文字, 实际连接符）的唯一数据源

数据流：
    输入框文本 → DataUtils.parse_numbers_text(dedupe=False, limit_range=False)
    解析出数字列表（lib 统一解析，统计用途保留重复与越界值）
    → 读取 host._tail_buttons 中所有“选中”的尾数（可多个）
    → 对每个数字取 abs(n) % 10 判断是否命中选中尾数
    → 命中去重升序写 tail_result_edit，未命中去重升序写 tail_unmatched_edit；
    状态标签同步显示输入数量、选中尾数与匹配数量。
    分隔符切换只重算显示，不改变输入数据。

职责边界：
    - 本模块只负责界面构建（布局、控件、初始样式）
    - 事件处理函数保留在主窗口 LotteryPredictionWindow 中，通过信号连接
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import os as _os_boot  # 作用说明：提供 dirname/abspath/exists/join 等路径能力，用于向上定位项目根目录
import sys as _sys_boot  # 作用说明：提供 sys.path 访问，用于把项目根目录加入模块搜索路径以支持直接运行本文件

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QComboBox, QHBoxLayout, QLabel, QPushButton, QTextEdit, QVBoxLayout, QWidget)  # 作用说明：统一获取本页所需的 Qt 控件（下拉框/布局/标签/按钮/文本框），避免直接 import PyQt6
from lib.data_process import LotteryConfig, DataUtils, format_tails  # 作用说明：提供分隔符选项表、号码文本解析与尾数格式化，本页不另行硬编码分隔符或解析规则


# ╔══════════════════════════════════════════════════════════════════╗
# ║  [数字选尾：尾数多选筛选、分隔符切换、清空、字号调节]
# ╚══════════════════════════════════════════════════════════════════╝

def on_tail_selected(host, tail_num):
    """尾数按钮点击处理（多选模式，v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        尾数按钮为 checkable，Qt 在 clicked 信号前已自动切换选中状态；
        本函数直接按“当前所有选中尾数”重跑一次筛选。

    参数:
        host: 主窗口实例。读取 host._tail_buttons 的选中状态，
            刷新时复用 host._on_do_number_tail。
        tail_num: int，被点击的尾数（0-9）。本函数未直接使用该值——
            多选语义下必须以全部选中按钮为准，只看 tail_num 会丢失其它已选尾数。

    返回:
        无。

    调用方:
        build(host) 中每个尾数按钮 btn.clicked 连接
        lambda checked, num=i: host._on_tail_selected(num)。

    副作用:
        仅触发一次 on_do_number_tail 的界面刷新；不修改输入文本、不写配置。

    说明:
        允许多个尾数同时选中，再次点击已选中的尾数会取消选中（由 QPushButton
        的 checkable 行为完成），因此本函数无需手动维护选中集合。
    """
    # 自动筛选（多选：不再取消其他按钮的选中状态）
    host._on_do_number_tail()


def on_do_number_tail(host):
    """执行数字选尾筛选（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        读取输入数字与所有已选尾数，把数字分成“命中尾数”和“未命中”两组，
        去重升序后分别写入两个结果框，并更新统计标签。

    参数:
        host: 主窗口实例。读取 host.tail_input_edit、host._tail_buttons、
            host.tail_stats_label、host._get_result_separator；
            写入 host.tail_stats_label / tail_result_edit / tail_unmatched_edit。

    返回:
        无。

    调用方:
        install(host) 绑定为 host._on_do_number_tail；
        「开始筛选」按钮 clicked、尾数按钮点击、分隔符切换均会触发。

    副作用:
        1) 覆盖写两个结果框与统计标签；
        2) 无输入数字或无选中尾数时清空两个结果框，并在统计标签提示原因；
        3) 不修改输入框内容，不写配置/文件。

    说明:
        匹配判定用 abs(n) % 10：尾数只由个位数决定，先取绝对值可避免负数
        （例如文本中带负号被解析成负数）得到 Python 的负数取模结果而误判。
        结果统一 zfill(2) 显示，与全站的两位号码格式一致。
    """
    text = host.tail_input_edit.toPlainText()
    nums = DataUtils.parse_numbers_text(text, dedupe=False, limit_range=False)

    # 获取选中的尾数
    selected_tails = [i for i, btn in enumerate(host._tail_buttons) if btn.isChecked()]

    if not nums:
        host.tail_stats_label.setText(f"输入 0 个数字，选中尾数：{format_tails(selected_tails)}，匹配 0 个")
        host.tail_result_edit.setPlainText("")
        host.tail_unmatched_edit.setPlainText("")
        return

    if not selected_tails:
        host.tail_stats_label.setText(f"输入 {len(nums)} 个数字，选中尾数：无，请先选择尾数")
        host.tail_result_edit.setPlainText("")
        host.tail_unmatched_edit.setPlainText("")
        return

    # 筛选匹配尾数的数字
    matched = []
    unmatched = []
    for n in nums:
        # abs(n) % 10：尾数只看个位；先取绝对值，避免负数取模得到负尾数而漏判
        if abs(n) % 10 in selected_tails:
            matched.append(n)
        else:
            unmatched.append(n)

    # 去重并排序
    matched_unique = sorted(set(matched))
    unmatched_unique = sorted(set(unmatched))

    # 更新统计
    tail_str = format_tails(selected_tails)
    host.tail_stats_label.setText(
        f"输入 {len(nums)} 个数字，选中尾数：{tail_str}，匹配 {len(matched_unique)} 个（去重后）"
    )

    # 匹配结果
    sep = host._get_result_separator('tail_sep_combo')
    if matched_unique:
        host.tail_result_edit.setPlainText(sep.join(str(n).zfill(2) for n in matched_unique))
    else:
        host.tail_result_edit.setPlainText("没有找到匹配的数字")

    # 未匹配结果
    if unmatched_unique:
        host.tail_unmatched_edit.setPlainText(sep.join(str(n).zfill(2) for n in unmatched_unique))
    else:
        host.tail_unmatched_edit.setPlainText("所有数字都匹配")


def on_tail_sep_changed(host, index):
    """结果分隔符切换时即时刷新选尾结果（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        用户切换结果分隔符后，若输入框已有内容就复用 on_do_number_tail
        按新分隔符重算并刷新匹配/未匹配两个结果框。

    参数:
        host: 主窗口实例。读取 host.tail_input_edit；刷新时复用
            host._on_do_number_tail。
        index: int，下拉框当前索引（Qt 信号参数，未使用；实际分隔符由
            host._get_result_separator 从控件当前项读取）。

    返回:
        无。

    调用方:
        build(host) 中 tail_sep_combo.currentIndexChanged 连接到
        host._on_tail_sep_changed。

    副作用:
        仅在输入框有非空文本时重算一次，避免空输入下刷新出“未识别”提示。
    """
    if host.tail_input_edit.toPlainText().strip():
        host._on_do_number_tail()


def on_clear_tail(host):
    """清空选尾输入和结果（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        清空输入框与两个结果框，取消全部尾数按钮的选中态，并把统计标签复位。

    参数:
        host: 主窗口实例。清空 host.tail_input_edit / tail_result_edit /
            tail_unmatched_edit，遍历 host._tail_buttons 取消全部选中，
            并把 tail_stats_label 复位。
    返回:
        无。
    调用方:
        install(host) 绑定为 host._on_clear_tail；「清空」按钮 clicked 时触发。
    副作用:
        1) 清空文本框与统计标签；
        2) 逐个 setChecked(False) 重置 10 个尾数按钮的选中态——
           这是必要的，否则统计文字显示“无”但按钮仍高亮，视觉矛盾；
        3) 不清除分隔符选择，也不写配置/文件。
    """
    host.tail_input_edit.clear()
    host.tail_result_edit.clear()
    host.tail_unmatched_edit.clear()
    # 取消所有尾数选中
    for btn in host._tail_buttons:
        btn.setChecked(False)
    host.tail_stats_label.setText("输入 0 个数字，选中尾数：无，匹配 0 个")


def change_tail_font(host, direction):
    """调节选尾结果区域字体大小（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        按 direction 以 2px 为一档增减结果区字号，钳制在 15~28px 后重设
        筛选结果与未匹配数字两个结果框的样式表。

    参数:
        host: 主窗口实例。读写 host._tail_font_size（首次缺失时初始化为 14），
            并改写 host.tail_result_edit / tail_unmatched_edit 的样式表。
        direction: int，1=放大一档（+2px），-1=缩小一档（-2px）。

    返回:
        无。

    调用方:
        install(host) 绑定为 host._change_tail_font；
        build 中「A-」「A+」按钮 clicked 分别传入 -1 / 1。

    副作用:
        1) 更新 host._tail_font_size 并重设两个结果框样式表；
        2) 只改字号，底色/边框/文字颜色保持初始风格；
        3) 字号钳制在 [15, 28] px：15px 为 v0.0.36 字号下限（保证可读），
           28px 为上限（防止结果框内容横向溢出）。

    说明:
        两个结果框共用同一字号；_tail_font_size 挂在 host 上，
        与「数字排序」的 _sort_font_size 相互独立，可各自调节。
    """
    if not hasattr(host, '_tail_font_size'):
        # 初始基准 15px 与 build() 中结果框初始字号一致，首次点击 A- 才会出现可见变化
        # （旧值 14 会让 14-2=12 被下限钳回 15，用户误以为按钮失效）
        host._tail_font_size = 15

    new_size = host._tail_font_size + direction * 2
    # 15px 下限（v0.0.36 规范，防止缩小后不可读）与 28px 上限（防止结果溢出）
    new_size = max(15, min(28, new_size))
    host._tail_font_size = new_size

    # 筛选结果框字体调节样式 - 浅灰底系（动态字号，保持与初始样式一致）
    #   background-color: #F8F9FA;  浅灰背景（与 build 初始样式一致）
    #   border: 1px solid #DDDDDD;  浅灰边框
    #   border-radius: 6px;         6px 圆角
    #   padding: 8px;               内边距 8px
    #   font-size: {new_size}px;    字号：随档位变化（15~28px）
    font_style = f"""
        QTextEdit {{ background-color: #F8F9FA; border: 1px solid #DDDDDD; border-radius: 6px; 
            padding: 8px; font-size: {new_size}px; }}
    """
    host.tail_result_edit.setStyleSheet(font_style)  # 筛选结果框应用新字号

    # 未匹配数字框字体调节样式 - 橙色系（动态字号，保持提醒风格一致）
    #   background-color: #FDF2E9;  浅橙背景（提醒底色）
    #   border: 1px solid #F5CBA7;  浅橙边框
    #   border-radius: 6px;         6px 圆角
    #   padding: 8px;               内边距 8px
    #   font-size: {new_size}px;    字号：与筛选结果框同步
    #   color: #D35400;             深橙文字（突出“未匹配”提醒）
    unmatched_style = f"""
        QTextEdit {{ background-color: #FDF2E9; border: 1px solid #F5CBA7; border-radius: 6px; 
            padding: 8px; font-size: {new_size}px; color: #D35400; }}
    """
    host.tail_unmatched_edit.setStyleSheet(unmatched_style)  # 未匹配数字框应用新字号


def install(host):
    """安装「数字选尾」选项卡：绑定 5 个事件回调后构建界面（v0.0.28 起页面自包含）

    功能:
        在 host 上挂好尾数点击、筛选、分隔符切换、清空与字号调节五个 lambda
        回调，再调用 build(host) 创建并返回页面控件。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。
    返回:
        QWidget: 构建完成的页面（build 的返回值），供 addTab 使用。
    调用方:
        TAB/__init__.py 的 iter_tab_pages() 自动发现本页后由主窗口调用。
    副作用:
        在 host 上写入 5 个回调，build 中对应控件创建时立即连接：
            host._on_tail_selected    ← 10 个尾数按钮 btn.clicked（checkable，多选）
            host._on_do_number_tail   ← filter_btn.clicked（🔍 开始筛选）
            host._on_tail_sep_changed ← tail_sep_combo.currentIndexChanged
            host._on_clear_tail       ← clear_btn.clicked（🧹 清空）
            host._change_tail_font    ← font_minus_btn / font_plus_btn.clicked（A- / A+）
        必须先绑定再 build，否则按钮连接信号时属性不存在会抛 AttributeError。
    """
    host._on_tail_selected = lambda tail_num: on_tail_selected(host, tail_num)
    host._on_do_number_tail = lambda: on_do_number_tail(host)
    host._on_tail_sep_changed = lambda index: on_tail_sep_changed(host, index)
    host._on_clear_tail = lambda: on_clear_tail(host)
    host._change_tail_font = lambda direction: change_tail_font(host, direction)
    return build(host)


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "数字选尾",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 14,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """构建「数字选尾」选项卡页面

    功能:
        创建标题、输入区、尾数多选按钮行、操作按钮行（筛选/清空/分隔符/字体调节）、
        统计标签与两个只读结果框（匹配/未匹配）。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。本函数写入：
            host.tail_input_edit    —— 输入 QTextEdit；
            host._tail_buttons      —— list[QPushButton]，0-9 共 10 个可选中按钮；
            host.tail_sep_combo     —— 分隔符 QComboBox（选项来自 RESULT_SEPARATORS）；
            host.tail_stats_label / host.tail_result_edit /
            host.tail_unmatched_edit —— 统计标签与两个结果框。
        读取 _ini_tail_sep_index 与 host 上的 5 个事件回调。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        1) 在 host 上挂载上述控件与 _tail_buttons 列表；
        2) 每个尾数按钮 setCheckable(True)，支持多选/再次点击取消；
        3) 恢复上次分隔符索引（越界时保持默认 0=空格）；
        4) 两个结果框设为只读，防止误改输出；
        5) 本页不读取历史数据、不持久化（分隔符索引由主窗口写入 INI）。

    说明:
        尾数按钮用 min-width/min-height 40px + 20px 圆角形成圆形触控区，
        10 种颜色循环取自 tail_colors，便于快速区分 0-9；
        索引恢复放在 connect 之前，避免启动时触发无意义刷新。
    """
    widget = QWidget()
    # 主垂直布局
    layout = QVBoxLayout(widget)
    layout.setSpacing(10)
    layout.setContentsMargins(10, 10, 10, 10)

    # 标题
    title = QLabel("数字选尾工具")
    # 标题样式 - 深色系（页面主标题，突出功能名称）
    #   font-size: 18px;        字号：18px（大标题醒目）
    #   font-weight: bold;      加粗
    #   color: #2C3E50;         深灰蓝色文字
    title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2C3E50;")
    layout.addWidget(title)

    # 输入区域
    input_label = QLabel("输入数字（自动识别多种分隔符，可混合使用）：")
    # 输入提示标签样式 - 灰色系（引导用户输入）
    #   font-size: 15px;        字号：15px
    #   font-weight: bold;      加粗
    #   color: #555555;         深灰色文字
    input_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555;")
    layout.addWidget(input_label)

    host.tail_input_edit = QTextEdit()
    host.tail_input_edit.setPlaceholderText("请输入一堆数字，例如：\n5, 12, 23, 35, 42, 7, 15, 25, 37\n或：5，12。23、35；42|7#15~25=37（中英文标点均可）")
    # 选尾输入框样式 - 白底灰边系（普通输入区域）
    #   QTextEdit {
    #     background-color: #FFFFFF;  白色背景
    #     border: 1px solid #DDDDDD;  浅灰色边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px;               内边距
    #     font-size: 15px;            字号14px
    #   }
    host.tail_input_edit.setStyleSheet("""
        QTextEdit { background-color: #FFFFFF; border: 1px solid #DDDDDD; border-radius: 6px; 
            padding: 8px; font-size: 15px; }
    """)
    host.tail_input_edit.setMaximumHeight(120)
    layout.addWidget(host.tail_input_edit)

    # 尾数选择
    tail_label = QLabel("选择尾数（可多选，再次点击取消）：")
    # 尾数选择标签样式 - 灰色系（小节标题，加粗引导选择）
    #   font-size: 15px;        字号14px
    #   font-weight: bold;      加粗
    #   color: #555555;         深灰色文字
    tail_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555;")
    layout.addWidget(tail_label)

    tail_btn_layout = QHBoxLayout()
    host._tail_buttons = []
    # 尾数按钮颜色表（0-9对应10种颜色，循环使用）
    tail_colors = ['#E74C3C', '#E67E22', '#F1C40F', '#2ECC71', '#1ABC9C', 
                   '#3498DB', '#9B59B6', '#E91E63', '#795548', '#607D8B']
    # 尾数按钮样式 - 彩色圆形系（每个数字独立配色，圆形按钮醒目易点）
    #   QPushButton {
    #     background-color: {color};  动态颜色（从tail_colors取）
    #     color: white;               白色文字
    #     border: none;               无边框
    #     border-radius: 20px;        20px圆角（形成圆形）
    #     font-weight: bold;          加粗
    #     font-size: 16px;            字号16px
    #     min-width: 40px;            最小宽度40px
    #     min-height: 40px;           最小高度40px
    #   }
    #   QPushButton:hover { opacity: 0.8; }       悬停半透明
    #   QPushButton:checked { border: 3px solid #2C3E50; }  选中时深蓝色粗边框
    for i in range(10):
        btn = QPushButton(str(i))
        btn.setCheckable(True)
        btn.setStyleSheet(f"""
            QPushButton {{ background-color: {tail_colors[i]}; color: white; border: none;
                border-radius: 20px; font-weight: bold; font-size: 16px; min-width: 40px; min-height: 40px; }}
            QPushButton:hover {{ opacity: 0.8; }}
            QPushButton:checked {{ border: 3px solid #2C3E50; }}
        """)
        btn.clicked.connect(lambda checked, num=i: host._on_tail_selected(num))
        tail_btn_layout.addWidget(btn)
        host._tail_buttons.append(btn)
    tail_btn_layout.addStretch()
    layout.addLayout(tail_btn_layout)

    # 按钮行
    btn_layout = QHBoxLayout()

    filter_btn = QPushButton("🔍 开始筛选")
    # 筛选按钮样式 - 蓝色系（主操作按钮，引导用户执行筛选）
    #   QPushButton {
    #     background-color: #3498DB;  蓝色背景（主操作色）
    #     color: white;               白色文字
    #     border: none;               无边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px 24px;          内边距
    #     font-weight: bold;          加粗
    #     font-size: 15px;            字号14px
    #   }
    #   QPushButton:hover {
    #     background-color: #2980B9;  悬停深蓝色
    #   }
    filter_btn.setStyleSheet("""
        QPushButton { background-color: #3498DB; color: white; border: none; 
            border-radius: 6px; padding: 8px 24px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #2980B9; }
    """)
    # 信号连接：点击开始筛选按钮执行尾数筛选
    filter_btn.clicked.connect(host._on_do_number_tail)
    btn_layout.addWidget(filter_btn)

    # 清空按钮：清除选尾输入和结果
    clear_btn = QPushButton("🧹 清空")
    # 清空按钮样式 - 灰色系（次要操作，不抢视觉焦点）
    #   QPushButton {
    #     background-color: #95A5A6;  灰色背景（中性/次要色）
    #     color: white;               白色文字
    #     border: none;               无边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px 20px;          内边距
    #     font-weight: bold;          加粗
    #     font-size: 15px;            字号14px
    #   }
    #   QPushButton:hover {
    #     background-color: #7F8C8D;  悬停深灰色
    #   }
    clear_btn.setStyleSheet("""
        QPushButton { background-color: #95A5A6; color: white; border: none; 
            border-radius: 6px; padding: 8px 20px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #7F8C8D; }
    """)
    # 信号连接：点击清空按钮清除所有选尾输入和结果
    clear_btn.clicked.connect(host._on_clear_tail)
    btn_layout.addWidget(clear_btn)

    # 结果分隔符选择：控制匹配/未匹配结果的显示连接方式（默认空格）
    sep_label = QLabel("分隔符：")
    # 分隔符标签样式：灰色文字（与“字体：”标签一致，作为按钮行内的说明文字）
    sep_label.setStyleSheet("color: #666666;")
    btn_layout.addWidget(sep_label)

    host.tail_sep_combo = QComboBox()
    # 多格式分隔符选项：统一取自 LotteryConfig.RESULT_SEPARATORS（显示文字, 实际连接符）
    for sep_text, sep_value in LotteryConfig.RESULT_SEPARATORS:
        host.tail_sep_combo.addItem(sep_text, sep_value)
    # 宽度随最长选项文字自适应（大字体下固定宽度会截断"中文句号（。）"等长选项）
    host.tail_sep_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
    host.tail_sep_combo.setMinimumWidth(150)
    host.tail_sep_combo.setToolTip(
        "设置选尾结果的显示分隔符：空格 / 英文逗号 / 顿号 / 分号 / 减号 / 正斜杠 / 竖线 / 换行 /"
        " 中文逗号 / 中文句号 / 英文句号 / 加号 / 反斜杠 / 波浪号 / 井号")
    # 恢复上次选择的分隔符（主窗口从 配置.ini 读取，缺失时默认索引0=空格）
    saved_sep_index = getattr(host, '_ini_tail_sep_index', 0)
    if 0 <= saved_sep_index < host.tail_sep_combo.count():
        host.tail_sep_combo.setCurrentIndex(saved_sep_index)
    # 分隔符切换信号：即时刷新选尾结果显示（放在恢复索引之后，避免启动时无谓刷新）
    host.tail_sep_combo.currentIndexChanged.connect(host._on_tail_sep_changed)
    btn_layout.addWidget(host.tail_sep_combo)

    # 字体调节
    btn_layout.addStretch()
    font_label = QLabel("字体：")
    # 字体标签样式：灰色文字，无额外装饰
    font_label.setStyleSheet("color: #666666;")
    btn_layout.addWidget(font_label)

    font_minus_btn = QPushButton("A-")
    # 字体缩小按钮样式 - 浅灰系（辅助调节按钮，低调不抢眼）
    #   QPushButton {
    #     background-color: #ECF0F1;  浅灰背景
    #     color: #333333;             深灰文字
    #     border: 1px solid #BDC3C7;  灰色边框
    #     border-radius: 4px;         4px圆角
    #     padding: 4px 10px;          内边距（紧凑）
    #     font-weight: bold;          加粗
    #   }
    #   QPushButton:hover {
    #     background-color: #BDC3C7;  悬停加深
    #   }
    font_minus_btn.setStyleSheet("""
        QPushButton { background-color: #ECF0F1; color: #333333; border: 1px solid #BDC3C7;
            border-radius: 4px; padding: 4px 10px; font-weight: bold; }
        QPushButton:hover { background-color: #BDC3C7; }
    """)
    # 信号连接：点击A-按钮缩小选尾结果字体
    font_minus_btn.clicked.connect(lambda: host._change_tail_font(-1))
    btn_layout.addWidget(font_minus_btn)

    font_plus_btn = QPushButton("A+")
    # 字体放大按钮样式 - 浅灰系（与缩小按钮保持一致风格）
    #   QPushButton {
    #     background-color: #ECF0F1;  浅灰背景
    #     color: #333333;             深灰文字
    #     border: 1px solid #BDC3C7;  灰色边框
    #     border-radius: 4px;         4px圆角
    #     padding: 4px 10px;          内边距（紧凑）
    #     font-weight: bold;          加粗
    #   }
    #   QPushButton:hover {
    #     background-color: #BDC3C7;  悬停加深
    #   }
    font_plus_btn.setStyleSheet("""
        QPushButton { background-color: #ECF0F1; color: #333333; border: 1px solid #BDC3C7;
            border-radius: 4px; padding: 4px 10px; font-weight: bold; }
        QPushButton:hover { background-color: #BDC3C7; }
    """)
    # 信号连接：点击A+按钮放大选尾结果字体
    font_plus_btn.clicked.connect(lambda: host._change_tail_font(1))
    btn_layout.addWidget(font_plus_btn)

    layout.addLayout(btn_layout)

    # 统计信息
    # 统计标签：显示输入数字总数、选中尾数和匹配数量
    host.tail_stats_label = QLabel("输入 0 个数字，选中尾数：无，匹配 0 个")
    # 统计标签样式：13px字号，灰色文字，带内边距
    host.tail_stats_label.setStyleSheet("font-size: 15px; color: #666666; padding: 4px;")
    layout.addWidget(host.tail_stats_label)

    # 结果区域
    result_title = QLabel("筛选结果（从小到大）：")
    # 筛选结果标题样式 - 灰色系（小节标题，加粗突出）
    #   font-size: 15px;        字号14px
    #   font-weight: bold;      加粗
    #   color: #555555;         深灰色文字
    #   margin-top: 5px;        上边距5px
    result_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555; margin-top: 5px;")
    layout.addWidget(result_title)

    # 筛选结果展示框：只读，显示匹配尾数的数字列表
    host.tail_result_edit = QTextEdit()
    host.tail_result_edit.setReadOnly(True)
    # 筛选结果框样式 - 浅灰底系（只读结果展示区）
    #   QTextEdit {
    #     background-color: #F8F9FA;  浅灰背景（区分可编辑区域）
    #     border: 1px solid #DDDDDD;  浅灰边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px;               内边距
    #     font-size: 15px;            字号14px
    #   }
    host.tail_result_edit.setStyleSheet("""
        QTextEdit { background-color: #F8F9FA; border: 1px solid #DDDDDD; border-radius: 6px; 
            padding: 8px; font-size: 15px; }
    """)
    host.tail_result_edit.setMaximumHeight(120)
    layout.addWidget(host.tail_result_edit)

    # 未匹配数字
    unmatched_title = QLabel("未匹配的数字：")
    # 未匹配标题样式 - 灰色系（小节标题，与筛选结果标题风格一致）
    #   font-size: 15px;        字号14px
    #   font-weight: bold;      加粗
    #   color: #555555;         深灰色文字
    #   margin-top: 5px;        上边距5px
    unmatched_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555; margin-top: 5px;")
    layout.addWidget(unmatched_title)

    # 未匹配数字展示框：只读，橙色警示框，显示不匹配尾数的数字
    host.tail_unmatched_edit = QTextEdit()
    host.tail_unmatched_edit.setReadOnly(True)
    # 未匹配数字框样式 - 橙色系（暖色警示，突出"未匹配"的提醒状态）
    #   QTextEdit {
    #     background-color: #FDF2E9;  浅橙背景（暖色提醒底色）
    #     border: 1px solid #F5CBA7;  浅橙边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px;               内边距
    #     font-size: 15px;            字号14px
    #     color: #D35400;             深橙色文字（醒目提醒）
    #   }
    host.tail_unmatched_edit.setStyleSheet("""
        QTextEdit { background-color: #FDF2E9; border: 1px solid #F5CBA7; border-radius: 6px; 
            padding: 8px; font-size: 15px; color: #D35400; }
    """)
    host.tail_unmatched_edit.setMaximumHeight(100)
    layout.addWidget(host.tail_unmatched_edit)

    layout.addStretch()
    return widget
