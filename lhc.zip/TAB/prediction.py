# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/prediction.py - 「预测与抽取」选项卡页面构建 + 页内事件处理模块
===========================================================================
功能说明：
    构建主窗口「预测与抽取」选项卡的全部界面控件，并挂载到主窗口实例上；
    同时实现本页的概率统计、计算规律、波色预测、算法/随机/机器学习预测、
    七策略号码预测、已保存预测与收藏、上次/本次对比、结果持久化等事件处理。

职责边界：
    - 本模块负责页面级界面构建与页内事件；跨页基础设施（INI 读写、
      控件记忆、通用表格刷新、线程收尾）仍保留在主窗口 LotteryPredictionWindow
    - Qt 控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库；确需 numpy 时通过
      lib.math_algo.get_numpy() 惰性获取，缺库时可走降级分支
    - 所有事件函数以 host（主窗口实例）为第一参数，控件与状态挂在 host 上，
      便于主窗口统一刷新与记忆

[WidgetState] 记忆约定（由主窗口 _save_widget_states 统一维护）：
    键名 = 前缀 + host 属性名；本页只创建控件，不手写记忆键：
        c_  QComboBox                当前索引
        s_  QSpinBox                 当前数值（含本页字号/期数控件）
        v_  QSlider                  当前值
        b_  QCheckBox / QRadioButton 是否勾选
        t_  QTableWidget             各列宽度
    恢复时主窗口会 blockSignals，因此恢复后不会自动触发槽函数；
    需要按控件当前值同步内部状态的场景由 _sync_* 函数显式处理。

字号约定：
    全项目所有文字最小 15px；本页图例说明文字与号码数字的下限统一为 15px，
    集中在 apply_legend_font_size / change_legend_font 中控制。
===========================================================================
"""

import os as _os_boot  # 作用说明：仅用于下面的「直接运行本文件」搜索路径计算
import sys as _sys_boot  # 作用说明：仅用于把项目根目录插入 sys.path

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

# 标准库：均为轻量依赖，缺任何一项都会导致模块导入失败
import datetime  # 作用说明：给已保存预测/上次预测生成时间戳（'%Y-%m-%d %H:%M:%S'），并用于报告生成时间。
import json  # 作用说明：读写 预测记录.json、上次预测_*.json、生肖绑定.json 等持久化文件。
import os  # 作用说明：拼接数据/模型缓存路径、判断文件是否存在、取目录与主文件名。
import random  # 作用说明：随机抽取、特别码频率加权抽样；确定性模式下先固定种子。
import re  # 作用说明：只替换 QSS/HTML 中的 font-size、padding、color，保留其余样式。
import traceback  # 作用说明：预测/渲染异常时打印完整调用栈，便于定位 C 扩展崩溃。
from collections import Counter  # 作用说明：加减规律、波色与概率统计的频次聚合。

# Qt 控件：统一经 UI 包转发导入
# UI/__init__.py 负责 from .UI import *，集中处理 PyQt6 兼容与控件导出；
# 若绕过 UI 直接 import PyQt6，会破坏项目的统一导入约定。
# 作用：本页全部布局、控件、定时器与动画类型都来自这里；
# 缺它则页面无法构建，整个「预测与抽取」选项卡加载失败。
from UI import (QApplication, QCheckBox, QColor, QComboBox, QDialog, QEasingCurve, QEvent, QFileDialog, QFont, QFontMetrics, QFrame, QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QListWidget, QListWidgetItem, QMessageBox, QObject, QParallelAnimationGroup, QPropertyAnimation, QPushButton, QScrollArea, QSize, QSlider, QSpinBox, QSplitter, QStackedWidget, QTabWidget, QTableWidget, QTableWidgetItem, QTextEdit, QTimer, QVBoxLayout, QWidget, Qt)  # 作用说明：统一导出 PyQt6 控件/布局/动画/对话框类型；QEvent/QObject 供 H54 主题同步过滤器使用，本页所有界面元素都从这里取，绕过 UI 直接导 PyQt6 会破坏项目约定。
# 作用：LotteryConfig 提供算法清单、红/蓝/绿波色判定、生肖与五行映射；
#       get_latest_period 取最近期号，用于「最新开奖数据」与预测记录标识。
# 缺它则算法说明、波色预测与最新期号都取不到，本页不可用。
from lib.data_process import LotteryConfig, get_latest_period  # 作用说明：LotteryConfig 提供算法清单、红/蓝/绿波色判定与生肖五行映射；get_latest_period 提供最新期号。
# 作用：lib.algorithms 是算法注册表（编号↔名称↔计算函数↔正码数↔是否用模型），
#       本页下拉、说明、预测与特殊算法判定都从这里取，禁止在界面层写死编号。
# 缺它则算法下拉为空、算法预测入口无法执行。
from lib.algorithms import (DEFAULT_ALGORITHM_INDEX, get_algorithm,  # 作用说明：算法注册表（编号↔名称↔计算函数↔正码数↔是否用模型），供下拉、说明、预测与特殊算法判定使用。
                            is_special_algorithm, iter_algorithms, run_algorithm)
# 作用：NumberStrategyPredictor 负责七策略号码预测（含机器学习策略）；
#       PredictionAlgorithms 提供加减规律/波色等页内统计；
#       get_numpy 惰性导入 numpy，缺 numpy 时由库内降级，避免本模块顶层 import 崩溃。
# 缺 lib.math_algo 则七策略与统计计算不可用（numpy 单独缺失仍可走降级分支）。
from lib.math_algo import NumberStrategyPredictor, PredictionAlgorithms, get_numpy  # 作用说明：七策略号码预测器、加减/波色统计工具与 numpy 惰性导入；numpy 缺失时由库内降级。
# 作用：MLPredictionModel 封装 sklearn 模型训练/缓存/预测；缺 sklearn 时内部走降级分支，
#       本页只负责按钮状态与结果展示，不在界面层判断依赖是否可用。
# 缺 lib.ml_model 则机器学习预测按钮不可用。
from lib.ml_model import MLPredictionModel  # 作用说明：封装 sklearn 模型训练/缓存/预测；缺 sklearn 时内部降级，界面层不判断依赖。
# 作用：TAB.widgets 提供本页复用的控件与统一规格：
#       NumberBallWithZodiac（号码球+生肖/五行）、NumberButton（数字选择按钮）、
#       PreserveColorDelegate（保留颜色的表格代理）、add_corner_widget/make_corner_*（角控件）、
#       open_panel_size_dialog（尺寸设置弹窗）、style_corner_spin（角控件数字框样式）。
# 缺它则号码球、角控件与尺寸弹窗无法创建，本页构建失败。
from TAB.widgets import (CORNER_SECTION_GAP, NumberBallWithZodiac, NumberButton, PreserveColorDelegate,  # 作用说明：本页复用的号码球、数字按钮、表格代理与角控件/尺寸弹窗统一规格构造器。
                         add_corner_widget, make_corner_container, make_corner_label,
                         make_corner_size_button, open_panel_size_dialog, style_corner_spin)


def show_panel_settings_dialog(host):
    """打开「预测号码球尺寸」设置弹窗

    功能:
        由主窗口 `_show_panel_settings_dialog` 的 'prediction' 分支迁入。弹窗骨架
        使用 TAB.widgets.open_panel_size_dialog；本页额外展示标签宽/高与加号字号
        三行（原实现 panel_type == 'prediction' 的两个 if 分支）。
    参数:
        host: 主窗口实例，提供 _prediction_ball_size 与相关字号控件。
    返回:
        None（仅弹出模态对话框，无返回值）。
    注意/副作用:
        - 写 host._prediction_ball_size（width/height/font/label_font/label_width/
          label_height/plus_size）、host.ball_label_font_size、host._area_font_scales
          ['result']；
        - 同步 pred_text_font_spin / pred_num_font_spin 时用 blockSignals 防递归；
        - 调用 apply_prediction_ball_size(host) 重绘预测球；
        - 控件缺失时通过 hasattr 跳过；label_font 为 None 时不覆盖 ball_label_font_size。
    """
    current = getattr(host, '_prediction_ball_size',
                      {'width': 80, 'height': 60, 'font': 20, 'label_font': 20})

    def _apply(values):
        # 加号/标签宽高原弹窗才有输入框，缺省值与原实现一致（24 / 0 / 0）
        """弹窗「确定」回调：合并宽/高/标签/加号参数并立即应用到预测号码球。

        功能:
            把 open_panel_size_dialog 回传的尺寸字典与已有字号合并，写回 host，
            并立即重绘预测结果区的号码球。
        参数:
            values (dict): 尺寸字典，含 width / height / plus_size / label_width /
                label_height；缺键时按 24 / 0 / 0 兜底。
        返回:
            None（仅产生界面副作用）。
        注意/副作用:
            - 重写 host._prediction_ball_size（font 与 label_font 沿用原值，不随宽高变化）；
            - 用 blockSignals 保护地同步 pred_text_font_spin / pred_num_font_spin，
              避免 setValue 再次触发字号回调造成递归；
            - 调用 apply_prediction_ball_size 重绘号码球，并刷新 _area_font_scales['result']；
            - label_font 为 None 时跳过 ball_label_font_size 同步；控件缺失时用 hasattr 静默跳过。
        """
        plus_size = values.get('plus_size', 24)
        label_width = values.get('label_width', 0)
        label_height = values.get('label_height', 0)
        # 字号由右上角 spinbox 独立控制，这里只沿用已有值，不随宽高变化
        font = host._prediction_ball_size.get('font', 18)
        label_font = host._prediction_ball_size.get('label_font', 15)  # 兜底也保持 ≥15px
        host._prediction_ball_size = {
            'width': values['width'], 'height': values['height'],
            'font': font, 'label_font': label_font,
            'label_width': label_width, 'label_height': label_height,
            'plus_size': plus_size,
        }
        # 同步标签字号到 ball_label_font_size（由 pred_text_font_spin 统一控制）
        if label_font is not None:
            host.ball_label_font_size = label_font
            if hasattr(host, 'pred_text_font_spin'):
                host.pred_text_font_spin.blockSignals(True)
                host.pred_text_font_spin.setValue(label_font)
                host.pred_text_font_spin.blockSignals(False)
        if hasattr(host, 'pred_num_font_spin'):
            host.pred_num_font_spin.blockSignals(True)
            host.pred_num_font_spin.setValue(font)
            host.pred_num_font_spin.blockSignals(False)
        # 应用新的球尺寸（本页同文件内函数，定义在下方，运行时已可见）
        apply_prediction_ball_size(host)
        host._area_font_scales['result'] = font / 18.0

    open_panel_size_dialog(host, "预测号码球尺寸", current, _apply,
                           show_label_size=True, show_plus_size=True)



def _build_left_prediction_panel(host):
    """构建左半区纵向容器：上「最新开奖数据」、下「算法选择」。

    功能:
        创建纵向 QSplitter，依次装入最新开奖数据面板与算法选择面板，并设置伸缩比例。
    参数:
        host: 主窗口实例；子面板会把控件挂到 host 上供后续刷新与 [WidgetState] 记忆。
    返回:
        QWidget: 含 host.pred_left_v_splitter 的纵向容器。
    注意/副作用:
        - 写 host.pred_left_v_splitter，并调用 host._apply_splitter_sizes 恢复分栏比例；
        - 无显式异常捕获；控件创建失败会向上抛，由主窗口装载阶段统一处理。
    """
    widget = QWidget()
    widget.setObjectName("LeftPredictionPanel")
    host.pred_left_v_splitter = QSplitter(Qt.Orientation.Vertical)
    host.pred_left_v_splitter.setHandleWidth(2)
    
    latest_panel = _build_latest_data_panel(host)
    host.pred_left_v_splitter.addWidget(latest_panel)
    
    algorithm_panel = _build_algorithm_panel(host)
    host.pred_left_v_splitter.addWidget(algorithm_panel)
    
    host.pred_left_v_splitter.setStretchFactor(0, 1)
    host.pred_left_v_splitter.setStretchFactor(1, 2)
    host._apply_splitter_sizes(host.pred_left_v_splitter, 'pred_left_v_splitter')
    
    layout = QVBoxLayout(widget)
    layout.setContentsMargins(5, 5, 5, 5)
    layout.setSpacing(host.spacing)
    layout.addWidget(host.pred_left_v_splitter)
    
    return widget

def _build_right_prediction_panel(host):
    """构建右半区：五个子选项卡 + 选项卡右上角「数字/文字/尺寸」角控件。

    功能:
        按固定顺序装配 预测结果 / 号码预测 / 出现概率 / 计算规律 / 波色预测 五个子页，
        并在标签栏右上角放置字号与尺寸控件。
    参数:
        host: 主窗口实例。
    返回:
        QWidget: 含 host.pred_right_tabs 的容器。
    注意/副作用:
        - 写 host.pred_right_tabs、pred_num_font_spin、pred_text_font_spin，
          并连接 valueChanged 到本页字号处理函数；
        - 角控件使用 TAB/widgets.py 统一规格（高 40px、组内间距 6px、
          数字组与文字组间隔 CORNER_SECTION_GAP、距右边缘 8px、字号 15px）；
        - 无显式异常捕获；_prediction_ball_size 或 ball_label_font_size 缺失时按 20px 兜底。
    """
    widget = QWidget()
    widget.setObjectName("RightPredictionPanel")
    # 使用选项卡替代原来的面板分隔，预测结果和概率分为两个独立选项卡
    host.pred_right_tabs = QTabWidget()

    result_panel = _build_prediction_result_panel(host)
    host.pred_right_tabs.addTab(result_panel, "预测结果")

    # 号码预测面板（七策略）：七种策略各出一组 6 正码 + 1 特别码，并附计算原理
    number_panel = _build_number_prediction_panel(host)
    host.pred_right_tabs.addTab(number_panel, "号码预测")

    prob_panel = _build_probability_panel(host)
    host.pred_right_tabs.addTab(prob_panel, "出现概率")

    # 计算规律面板（加减规律分析）
    calc_panel = _build_calc_method_panel(host)
    host.pred_right_tabs.addTab(calc_panel, "计算规律")

    # 波色预测面板
    wave_panel = _build_wave_color_panel(host)
    host.pred_right_tabs.addTab(wave_panel, "波色预测")

    # 数字字体 + 文字字体 + 尺寸按钮 → 放置在选项卡标签栏右侧角落
    # v0.0.36：改用 TAB/widgets.py 的统一规格（控件高 40px、组内间距 6px、
    # 数字组与文字组之间 12px、距右边缘 8px、字号 15px），与生肖/五行/数字选择页一致
    control_widget, control_layout = make_corner_container()

    # 数字字体控件
    add_corner_widget(control_layout, make_corner_label("数字:", "#1565C0"))

    host.pred_num_font_spin = QSpinBox()
    host.pred_num_font_spin.setRange(15, 150)  # 下限 15px：与全局最小字号一致
    host.pred_num_font_spin.setSingleStep(1)
    host.pred_num_font_spin.setButtonSymbols(QSpinBox.ButtonSymbols.UpDownArrows)
    host.pred_num_font_spin.setValue(host._prediction_ball_size.get('font', 20))  # 默认20px
    host.pred_num_font_spin.setSuffix(" px")
    host.pred_num_font_spin.setToolTip("调整预测结果号码球数字字体大小\n（独立控制，不影响生肖/五行标签）")
    style_corner_spin(host.pred_num_font_spin, "#90CAF9")
    # 数字字体大小变化信号：连接字体更新函数，实时调整号码球数字大小
    host.pred_num_font_spin.valueChanged.connect(host._on_pred_num_font_changed)
    add_corner_widget(control_layout, host.pred_num_font_spin)

    control_layout.addSpacing(CORNER_SECTION_GAP)  # 数字组与文字组之间留 12px，避免拥挤

    # 文字字体控件
    add_corner_widget(control_layout, make_corner_label("文字:", "#7B1FA2"))

    host.pred_text_font_spin = QSpinBox()
    host.pred_text_font_spin.setRange(15, 150)  # 下限 15px：与全局最小字号一致
    host.pred_text_font_spin.setSingleStep(1)
    host.pred_text_font_spin.setButtonSymbols(QSpinBox.ButtonSymbols.UpDownArrows)
    host.pred_text_font_spin.setValue(host.ball_label_font_size)  # 默认20px
    host.pred_text_font_spin.setSuffix(" px")
    host.pred_text_font_spin.setToolTip("调整号码球生肖/五行标签的字体大小\n（独立控制，不影响数字）")
    style_corner_spin(host.pred_text_font_spin, "#CE93D8")
    # 文字字体大小变化信号：连接标签字体更新函数，实时调整生肖/五行标签大小
    host.pred_text_font_spin.valueChanged.connect(host._on_pred_text_font_changed)
    add_corner_widget(control_layout, host.pred_text_font_spin)

    # 尺寸设置按钮
    add_corner_widget(control_layout, make_corner_size_button(
        lambda: show_panel_settings_dialog(host), "调整号码球尺寸设置"))

    # 将控件容器设为选项卡右上角角落控件
    host.pred_right_tabs.setCornerWidget(control_widget, Qt.Corner.TopRightCorner)

    layout = QVBoxLayout(widget)
    layout.setContentsMargins(5, 5, 5, 5)
    layout.setSpacing(host.spacing)
    layout.addWidget(host.pred_right_tabs)

    return widget

def _build_latest_data_panel(host):
    """构建「最新开奖数据」面板：标题 + 数据展示标签 + 刷新按钮。

    功能:
        创建标题、可换行的数据展示标签与「刷新显示」按钮，并接到主窗口刷新方法。
    参数:
        host: 主窗口实例。
    返回:
        QWidget: 面板容器。
    注意/副作用:
        - 写 host.latest_display（初始「暂无数据」、允许换行）；
        - 刷新按钮连接到 host._refresh_latest_display（跨页基础设施仍留在主窗口）；
        - 无显式异常捕获；host 缺少该方法时点击按钮会抛 AttributeError（装配不完整的编程错误）。
    """
    widget = QWidget()
    widget.setObjectName("LatestDataPanel")
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    
    title = QLabel("最新开奖数据")
    title.setObjectName("PanelTitle")
    layout.addWidget(title)
    
    host.latest_display = QLabel("暂无数据")
    host.latest_display.setObjectName("LatestDisplay")
    host.latest_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
    host.latest_display.setWordWrap(True)
    layout.addWidget(host.latest_display)
    
    refresh_btn = QPushButton("刷新显示")
    # 刷新显示按钮点击信号：重新加载最新开奖数据并刷新显示
    refresh_btn.clicked.connect(host._refresh_latest_display)
    layout.addWidget(refresh_btn)
    
    return widget

# H54 暗色补丁令牌：沿用主窗口暗色分支同一套取值，不新造色板。
PREDICTION_DARK_TOKENS = {
    'bg': '#1E1E2E',
    'card': '#313244',
    'text': '#F5F5F5',
    'secondary': '#A6ADC8',
    'border': '#7F849C',
    'hover': '#45475A',
    'pressed': '#585B70',
    'accent': '#89B4FA',
    'success': '#A6E3A1',
    'danger': '#FF8A8A',
}


def _prediction_is_dark(host):
    """读取当前主题开关；缺失属性时按亮色处理"""
    return bool(getattr(host, 'is_dark_mode', False))


def _register_prediction_theme(host, widget, light_qss, dark_qss):
    """登记一个需要随主题切换的内联样式控件（亮色原样保留，暗色补令牌）

    功能:
        顶部预测类型按钮会被主窗口 _update_stylesheet 用亮色样式覆盖，复选框/
        策略下拉/结果卡则只在构建期设一次。统一登记两套样式并监听主窗口
        StyleChange（主题切换会触发），按 is_dark_mode 回套，避免切主题后
        残留亮底。

    参数:
        host: 主窗口实例；
        widget: 目标控件；
        light_qss (str | None): 亮色样式；None 表示亮色下不设局部样式；
        dark_qss (str): 暗色样式。

    返回:
        None。
    """
    registry = getattr(host, '_prediction_theme_widgets', None)
    if registry is None:
        registry = []
        host._prediction_theme_widgets = registry
        host._prediction_theme_filter = _PredictionThemeSync(host)
        host.installEventFilter(host._prediction_theme_filter)
    registry.append((widget, light_qss, dark_qss))
    widget.setStyleSheet(dark_qss if _prediction_is_dark(host) else (light_qss or ''))


def _apply_prediction_theme(host):
    """按当前主题重新套用本页全部已登记的内联样式"""
    registry = getattr(host, '_prediction_theme_widgets', None)
    if not registry:
        return
    alive = []
    for widget, light_qss, dark_qss in list(registry):
        try:
            widget.setStyleSheet(dark_qss if _prediction_is_dark(host) else (light_qss or ''))
            alive.append((widget, light_qss, dark_qss))
        except RuntimeError:
            # 控件已销毁（预测结果重绘会重建号码球与加号标签）：从登记表剔除
            pass
    host._prediction_theme_widgets = alive


class _PredictionThemeSync(QObject):
    """监听主窗口 StyleChange（主题/字号重建样式表）并回套本页内联样式"""

    def __init__(self, host):
        super().__init__(host)
        self._host = host

    def eventFilter(self, obj, event):
        if obj is self._host and event.type() == QEvent.Type.StyleChange:
            QTimer.singleShot(0, lambda: _apply_prediction_theme(self._host))
        return False


def _build_algorithm_panel(host):
    """构建「选择预测算法」面板：算法下拉、算法说明、模式开关与权重调节。

    功能:
        创建算法下拉、算法说明、增强/确定性/策略/锁定/模型缓存开关与预测按钮，
        并统一在此注册各控件的信号连接。
    参数:
        host: 主窗口实例。
    返回:
        QWidget: 面板容器。
    注意/副作用:
        - 下拉项统一来自 lib/algorithms.py 注册表，iter_algorithms 的迭代顺序即
          算法编号 0..22，禁止重排（历史记录里的编号依赖该顺序）；
        - 写 host.algorithm_combo、strategy_combo、predict_button、model_cache_check、
          lock_predict_check 等控件，并连接 currentIndexChanged / clicked / toggled 到本页事件函数；
        - 注册表为空时下拉框无选项、currentIndex 为 -1，预测入口会提示未选择算法。
    """
    widget = QWidget()
    widget.setObjectName("AlgorithmPanel")
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    
    title = QLabel("选择预测算法")
    title.setObjectName("PanelTitle")
    layout.addWidget(title)
    
    host.algorithm_combo = QComboBox()
    host.algorithm_combo.setObjectName("AlgorithmCombo")
    # 算法下拉选项统一来自 lib/algorithms.py 注册表（顺序即编号 0..22，禁止重排）
    for algo_def in iter_algorithms():
        host.algorithm_combo.addItem(algo_def.name)
    # 算法选择下拉框变化信号：切换预测算法时更新算法描述和状态

    host.algorithm_combo.currentIndexChanged.connect(host._on_algorithm_changed)
    # 算法选择下拉框变化信号：切换预测算法时更新算法描述和状态
    layout.addWidget(host.algorithm_combo)
    
    host.algorithm_desc_label = QLabel("请选择一个预测算法")
    host.algorithm_desc_label.setObjectName("AlgorithmDescLabel")
    host.algorithm_desc_label.setWordWrap(True)
    layout.addWidget(host.algorithm_desc_label)
    
    # 增强模式开关
    host.enhanced_mode_checkbox = QCheckBox("启用增强模式 (动态权重+模式识别)")
    host.enhanced_mode_checkbox.setChecked(host.enhanced_mode)
    # 增强模式复选框状态变化信号：切换增强模式（动态权重+模式识别）
    host.enhanced_mode_checkbox.stateChanged.connect(host._on_enhanced_mode_changed)
    # 增强模式复选框样式 - 蓝色系（增强/高级功能用蓝色）
    #   QCheckBox {       复选框整体样式
    #     padding: 4px 8px;           内边距：上下4px，左右8px
    #     background-color: #F0F8FF;  背景色：淡蓝
    #     border: 1px solid #B0D0F0;  边框：1px 浅蓝实线
    #     border-radius: 4px;         圆角：4px
    #     font-size: 15px;            字体大小：15px
    #     color: #2E86C1;             文字颜色：蓝色
    #   }
    #   QCheckBox:hover {  复选框悬停样式
    #     background-color: #E0F0FF;  悬停背景色：稍深的淡蓝
    #   }
    # H54：亮色样式原样保留；暗色用 #313244 底 / #89B4FA 字 / #7F849C 边框，
    # 并补 indicator 底色，消除暗色下的白方块。
    _register_prediction_theme(host, host.enhanced_mode_checkbox, """
        QCheckBox {
            padding: 4px 8px;
            background-color: #F0F8FF;
            border: 1px solid #B0D0F0;
            border-radius: 4px;
            font-size: 15px;
            color: #2E86C1;
        }
        QCheckBox:hover {
            background-color: #E0F0FF;
        }
    """, """
        QCheckBox {
            padding: 4px 8px;
            background-color: """ + PREDICTION_DARK_TOKENS['card'] + """;
            border: 1px solid """ + PREDICTION_DARK_TOKENS['border'] + """;
            border-radius: 4px;
            font-size: 15px;
            color: """ + PREDICTION_DARK_TOKENS['accent'] + """;
        }
        QCheckBox:hover {
            background-color: """ + PREDICTION_DARK_TOKENS['hover'] + """;
        }
        QCheckBox::indicator {
            background-color: """ + PREDICTION_DARK_TOKENS['bg'] + """;
            border: 1px solid """ + PREDICTION_DARK_TOKENS['border'] + """;
            border-radius: 2px;
        }
        QCheckBox::indicator:checked {
            background-color: """ + PREDICTION_DARK_TOKENS['accent'] + """;
            border-color: """ + PREDICTION_DARK_TOKENS['accent'] + """;
        }
    """)
    layout.addWidget(host.enhanced_mode_checkbox)
    
    # 确定性模式开关
    host.deterministic_checkbox = QCheckBox("确定性预测 (相同数据结果一致)")
    host.deterministic_checkbox.setChecked(host.deterministic_mode)
    # 确定性模式复选框状态变化信号：切换确定性预测模式（相同数据结果一致）
    host.deterministic_checkbox.stateChanged.connect(host._on_deterministic_mode_changed)
    # 确定性预测复选框样式 - 绿色系（确定/稳定用绿色）
    #   QCheckBox {       复选框整体样式
    #     padding: 4px 8px;           内边距：上下4px，左右8px
    #     background-color: #F0FFF0;  背景色：淡绿
    #     border: 1px solid #90EE90;  边框：1px 浅绿实线
    #     border-radius: 4px;         圆角：4px
    #     font-size: 15px;            字体大小：15px
    #     color: #228B22;             文字颜色：森林绿
    #   }
    #   QCheckBox:hover {  复选框悬停样式
    #     background-color: #E0FFE0;  悬停背景色：稍深的淡绿
    #   }
    # H54：亮色原样保留；暗色 #313244 底 / #A6E3A1 字 / #7F849C 边框 + indicator 补底。
    _register_prediction_theme(host, host.deterministic_checkbox, """
        QCheckBox {
            padding: 4px 8px;
            background-color: #F0FFF0;
            border: 1px solid #90EE90;
            border-radius: 4px;
            font-size: 15px;
            color: #228B22;
        }
        QCheckBox:hover {
            background-color: #E0FFE0;
        }
    """, """
        QCheckBox {
            padding: 4px 8px;
            background-color: """ + PREDICTION_DARK_TOKENS['card'] + """;
            border: 1px solid """ + PREDICTION_DARK_TOKENS['border'] + """;
            border-radius: 4px;
            font-size: 15px;
            color: """ + PREDICTION_DARK_TOKENS['success'] + """;
        }
        QCheckBox:hover {
            background-color: """ + PREDICTION_DARK_TOKENS['hover'] + """;
        }
        QCheckBox::indicator {
            background-color: """ + PREDICTION_DARK_TOKENS['bg'] + """;
            border: 1px solid """ + PREDICTION_DARK_TOKENS['border'] + """;
            border-radius: 2px;
        }
        QCheckBox::indicator:checked {
            background-color: """ + PREDICTION_DARK_TOKENS['success'] + """;
            border-color: """ + PREDICTION_DARK_TOKENS['success'] + """;
        }
    """)
    layout.addWidget(host.deterministic_checkbox)
    
    # 预测策略选择
    strategy_layout = QHBoxLayout()
    strategy_label = QLabel("预测策略:")
    # 预测策略标签样式
    #   font-size: 15px;      字体大小：15px
    #   color: #666666;       文字颜色：中灰（辅助说明文字）
    # H54：亮色原样保留；暗色 #A6ADC8（对 #1E1E2E 7.1:1）。
    _register_prediction_theme(host, strategy_label,
                               "font-size: 15px; color: #666666;",
                               "font-size: 15px; color: " + PREDICTION_DARK_TOKENS['secondary'] + ";")
    strategy_layout.addWidget(strategy_label)
    
    host.strategy_combo = QComboBox()
    host.strategy_combo.addItem("标准模式 (追求准确率)", False)
    host.strategy_combo.addItem("反向模式 (追求错误率)", True)
    # 设置初始值
    host.strategy_combo.setCurrentIndex(1 if host.reverse_mode else 0)
    # 预测策略下拉框样式
    #   QComboBox {       下拉框整体样式
    #     padding: 4px 8px;           内边距：上下4px，左右8px
    #     background-color: #FFFFFF;  背景色：白色
    #     border: 1px solid #CCCCCC;  边框：1px 中灰实线
    #     border-radius: 4px;         圆角：4px
    #     font-size: 15px;            字体大小：15px
    #     min-height: 24px;           最小高度：24px
    #   }
    # H54：亮色原样保留；暗色 #313244 底 / #F5F5F5 字 / #7F849C 边框。
    _register_prediction_theme(host, host.strategy_combo, """
        QComboBox {
            padding: 4px 8px;
            background-color: #FFFFFF;
            border: 1px solid #CCCCCC;
            border-radius: 4px;
            font-size: 15px;
            min-height: 24px;
        }
    """, """
        QComboBox {
            padding: 4px 8px;
            background-color: """ + PREDICTION_DARK_TOKENS['card'] + """;
            color: """ + PREDICTION_DARK_TOKENS['text'] + """;
            border: 1px solid """ + PREDICTION_DARK_TOKENS['border'] + """;
            border-radius: 4px;
            font-size: 15px;
            min-height: 24px;
        }
        QComboBox QAbstractItemView {
            background-color: """ + PREDICTION_DARK_TOKENS['card'] + """;
            color: """ + PREDICTION_DARK_TOKENS['text'] + """;
            selection-background-color: """ + PREDICTION_DARK_TOKENS['hover'] + """;
            selection-color: """ + PREDICTION_DARK_TOKENS['text'] + """;
        }
    """)
    # 预测策略下拉框变化信号：切换标准/反向预测模式

    host.strategy_combo.currentIndexChanged.connect(host._on_strategy_changed)
    # 预测策略下拉框变化信号：切换标准/反向预测模式
    strategy_layout.addWidget(host.strategy_combo, 1)
    layout.addLayout(strategy_layout)
    
    # 策略说明
    if host.reverse_mode:
        strategy_desc = "🔴 反向模式：选择最不可能出现的号码，用于排除法策略，追求高错误率"
    else:
        strategy_desc = "💡 标准模式：选择最可能出现的号码，追求命中更多"
    host.strategy_desc_label = QLabel(strategy_desc)
    # 策略说明标签样式
    #   font-size: 15px;      字体大小：15px（满足最小字号要求）
    #   color: #888888;       文字颜色：浅灰（次要说明文字）
    #   padding: 2px 4px;     内边距：上下2px，左右4px
    host.strategy_desc_label.setStyleSheet("font-size: 15px; color: #888888; padding: 2px 4px;")
    host.strategy_desc_label.setWordWrap(True)
    layout.addWidget(host.strategy_desc_label)
    
    button_layout = QHBoxLayout()
    
    host.predict_button = QPushButton("开始预测")
    # 开始预测按钮点击信号：执行算法预测
    host.predict_button.clicked.connect(host._on_predict_clicked)
    button_layout.addWidget(host.predict_button)
    
    random_btn = QPushButton("随机抽取")
    # 随机抽取按钮点击信号：执行随机号码抽取
    random_btn.clicked.connect(host._on_random_draw_clicked)
    button_layout.addWidget(random_btn)
    
    layout.addLayout(button_layout)
    
    ml_btn = QPushButton("机器学习预测")
    # 机器学习预测按钮点击信号：执行机器学习模型预测
    ml_btn.clicked.connect(host._on_ml_predict_clicked)
    layout.addWidget(ml_btn)
    
    # 模型缓存开关：控制是否使用已有的ml_models.pkl训练文件
    # 对应区域4 [机器学习预测] 子区域，用户可自主选择是否使用模型缓存
    cache_layout = QHBoxLayout()
    cache_layout.setSpacing(6)
    host.model_cache_check = QCheckBox("使用模型训练文件")
    # 模型缓存复选框提示：勾选=使用已训练的ml_models.pkl文件（跳过训练），取消=每次重新训练模型
    host.model_cache_check.setToolTip("勾选：使用已有的ml_models.pkl模型文件预测（跳过训练）\n取消：每次重新训练模型（不使用缓存文件）")
    host.model_cache_check.setChecked(host._use_model_cache)
    # 复选框切换信号：保存选择到INI配置，下次启动自动恢复
    host.model_cache_check.toggled.connect(host._on_model_cache_toggled)
    # 复选框样式：15px字号，粗体，深灰色文字
    # H54：暗色下正文改 #F5F5F5，并补 indicator 底色消除白方块。
    _register_prediction_theme(host, host.model_cache_check,
        "font-size: 15px; color: #2C3E50; font-weight: bold;",
        "font-size: 15px; color: " + PREDICTION_DARK_TOKENS['text'] + "; font-weight: bold; "
        "QCheckBox::indicator { background-color: " + PREDICTION_DARK_TOKENS['bg']
        + "; border: 1px solid " + PREDICTION_DARK_TOKENS['border'] + "; border-radius: 2px; } "
        "QCheckBox::indicator:checked { background-color: " + PREDICTION_DARK_TOKENS['accent']
        + "; border-color: " + PREDICTION_DARK_TOKENS['accent'] + "; }")
    cache_layout.addWidget(host.model_cache_check)
    cache_layout.addStretch()
    layout.addLayout(cache_layout)
    
    # 预测锁定开关：控制"无新数据无法预测"功能
    lock_layout = QHBoxLayout()
    lock_layout.setSpacing(6)
    host.lock_predict_check = QCheckBox("无新数据锁定预测")
    # 预测锁定复选框提示：勾选=数据未更新时禁止预测，取消=允许重复预测（即使数据未变）
    host.lock_predict_check.setToolTip("勾选：数据未更新时禁止预测（防止重复预测）\n取消：允许重复预测（即使数据未变）")
    host.lock_predict_check.setChecked(host._block_no_new_data)
    # 复选框切换信号：保存选择到INI配置，下次启动自动恢复
    host.lock_predict_check.toggled.connect(host._on_lock_predict_toggled)
    # 复选框样式：15px字号，粗体，深灰色文字
    # H54：暗色下正文改 #F5F5F5，并补 indicator 底色消除白方块。
    _register_prediction_theme(host, host.lock_predict_check,
        "font-size: 15px; color: #2C3E50; font-weight: bold;",
        "font-size: 15px; color: " + PREDICTION_DARK_TOKENS['text'] + "; font-weight: bold; "
        "QCheckBox::indicator { background-color: " + PREDICTION_DARK_TOKENS['bg']
        + "; border: 1px solid " + PREDICTION_DARK_TOKENS['border'] + "; border-radius: 2px; } "
        "QCheckBox::indicator:checked { background-color: " + PREDICTION_DARK_TOKENS['accent']
        + "; border-color: " + PREDICTION_DARK_TOKENS['accent'] + "; }")
    lock_layout.addWidget(host.lock_predict_check)
    lock_layout.addStretch()
    layout.addLayout(lock_layout)
    
    weight_btn = QPushButton("权重调节")
    # 权重调节按钮点击信号：打开算法权重调节对话框
    weight_btn.clicked.connect(host._on_weight_adjust_clicked)
    layout.addWidget(weight_btn)
    
    return widget

def _build_prediction_result_panel(host):
    """构建「预测结果」页：类型切换、结果显示、历史/收藏/已保存列表与操作按钮。

    功能:
        创建三种预测类型的切换按钮、上次/本次对比区、号码球网格、统计与置信度区，
        以及收藏/对比/导出等操作按钮。
    参数:
        host: 主窗口实例。
    返回:
        QWidget: 面板容器。
    注意/副作用:
        - 仅在属性不存在时初始化 host._prediction_type / _prediction_results，
          避免覆盖 INI 或 [WidgetState] 已恢复的值；
        - 写 prediction_display、algorithm_source_label（保留但不加入布局，供内部读取）；
        - 历史表、已保存预测表、收藏表由主窗口通用表格方法刷新；
        - 缺少主窗口通用方法时对应按钮点击会抛 AttributeError。
    """
    widget = QWidget()
    widget.setObjectName("PredictionResultPanel")
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    
    # 【已删除】原"预测结果"标题标签 - 选项卡已有标题，无需重复显示

    # 预测类型切换按钮
    type_btn_layout = QHBoxLayout()
    type_btn_layout.setSpacing(2)
    
    # 【Bug修复】仅首次初始化，避免覆盖INI恢复的值
    if not hasattr(host, '_prediction_type'):
        host._prediction_type = 'algorithm'  # 当前类型: algorithm/random/ml
    if not hasattr(host, '_prediction_results'):
        host._prediction_results = {}  # 保存三种类型的预测结果
    
    # 预测类型切换按钮样式 - 灰色系（未选中态为灰色，选中态为蓝色）
    #   QPushButton {       按钮常态样式（未选中）
    #     background-color: #F0F0F0;  背景色：浅灰
    #     color: #666666;             文字颜色：中灰
    #     border: 1px solid #CCCCCC;  边框：1px 浅灰实线
    #     border-radius: 4px;         圆角：4px
    #     padding: 6px 12px;          内边距：上下6px，左右12px
    #     font-size: 15px;            字体大小：15px
    #   }
    #   QPushButton:hover {   悬停样式
    #     background-color: #E8E8E8;  悬停背景色：稍深灰
    #   }
    #   QPushButton:checked { 选中样式（当前激活的预测类型）
    #     background-color: #3498DB;  选中背景色：蓝色（表示激活）
    #     color: white;               选中文字颜色：白色
    #     border-color: #2980B9;      选中边框色：深蓝
    #   }
    # 使用当前全局字号动态计算按钮字体（small_font_size = 全局字号-4，最小10px）
    _base_font = LotteryConfig.FONT_SIZES.get(host.font_size_key, 16)
    _btn_font = max(15, _base_font - 4)
    type_button_style = """
        QPushButton {
            background-color: #F0F0F0;
            color: #666666;
            border: 1px solid #CCCCCC;
            border-radius: 4px;
            padding: 6px 12px;
            font-size: """ + str(_btn_font) + """px;
        }
        QPushButton:hover {
            background-color: #E8E8E8;
        }
        QPushButton:checked {
            background-color: #3498DB;
            color: white;
            border-color: #2980B9;
        }
    """
    
    # H54：亮色样式原样保留；暗色未选中态 #313244 底 + #A6ADC8 字（5.5:1），
    # 选中态沿用全局 accent #89B4FA，保证未选中的两枚按钮不再是 #F0F0F0 亮底。
    type_button_style_dark = """
        QPushButton {
            background-color: """ + PREDICTION_DARK_TOKENS['card'] + """;
            color: """ + PREDICTION_DARK_TOKENS['secondary'] + """;
            border: 1px solid """ + PREDICTION_DARK_TOKENS['border'] + """;
            border-radius: 4px;
            padding: 6px 12px;
            font-size: """ + str(_btn_font) + """px;
        }
        QPushButton:hover {
            background-color: """ + PREDICTION_DARK_TOKENS['hover'] + """;
        }
        QPushButton:checked {
            background-color: """ + PREDICTION_DARK_TOKENS['accent'] + """;
            color: """ + PREDICTION_DARK_TOKENS['bg'] + """;
            border-color: """ + PREDICTION_DARK_TOKENS['accent'] + """;
        }
    """
    
    # 三个预测类型按钮均使用 type_button_style 样式（灰色底+蓝色选中态，详见上方定义）
    host.type_btn_algorithm = QPushButton("🔮 算法预测")
    host.type_btn_algorithm.setCheckable(True)
    host.type_btn_algorithm.setChecked(True)
    _register_prediction_theme(host, host.type_btn_algorithm, type_button_style, type_button_style_dark)  # 应用切换按钮样式
    # 算法预测按钮点击信号：切换到算法预测类型
    host.type_btn_algorithm.clicked.connect(lambda: host._on_prediction_type_changed('algorithm'))
    type_btn_layout.addWidget(host.type_btn_algorithm)
    
    host.type_btn_random = QPushButton("🎲 随机抽取")
    host.type_btn_random.setCheckable(True)
    _register_prediction_theme(host, host.type_btn_random, type_button_style, type_button_style_dark)  # 应用切换按钮样式
    # 随机抽取按钮点击信号：切换到随机抽取类型
    host.type_btn_random.clicked.connect(lambda: host._on_prediction_type_changed('random'))
    type_btn_layout.addWidget(host.type_btn_random)
    
    host.type_btn_ml = QPushButton("🤖 机器学习")
    host.type_btn_ml.setCheckable(True)
    _register_prediction_theme(host, host.type_btn_ml, type_button_style, type_button_style_dark)  # 应用切换按钮样式
    # 机器学习按钮点击信号：切换到机器学习预测类型
    host.type_btn_ml.clicked.connect(lambda: host._on_prediction_type_changed('ml'))
    type_btn_layout.addWidget(host.type_btn_ml)
    
    layout.addLayout(type_btn_layout)
    
    # 数据状态提示
    host.data_status_label = QLabel("")
    host.data_status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    # 数据状态提示标签样式（警告提示用橙色）
    #   font-size: 15px;    字体大小：15px
    #   color: #E67E22;     文字颜色：橙色（警告/提示色）
    #   padding: 2px;       内边距：2像素
    host.data_status_label.setStyleSheet("font-size: 15px; color: #E67E22; padding: 2px;")
    host.data_status_label.hide()
    layout.addWidget(host.data_status_label)
    
    scroll = QScrollArea()
    scroll.setObjectName("PredictionScroll")
    scroll.setWidgetResizable(True)
    # 号码球按用户设置的固定球宽排列，右侧栏被拖窄或球尺寸调大时可能超出可视宽度；
    # 这里按需显示横向滚动条，保证内容不被裁切（而非强制隐藏滚动条造成溢出）。
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    
    result_widget = QWidget()
    result_layout = QVBoxLayout(result_widget)
    result_layout.setSpacing(host.spacing)
    
    # 上次结果 vs 本次结果 对比显示区
    # 每次新预测时，将当前结果存为"上次结果"，新结果显示在下方
    # 对比区用箭头连接，变化的号码高亮显示
    host.last_vs_current_widget = QWidget()
    lvc_layout = QVBoxLayout(host.last_vs_current_widget)
    lvc_layout.setSpacing(4)
    lvc_layout.setContentsMargins(4, 4, 4, 4)
    
    # 上次结果标签
    host.last_prediction_label = QLabel("上次结果：暂无")
    host.last_prediction_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    host.last_prediction_label.setWordWrap(True)
    # 上次结果标签样式 - 浅灰底（历史信息用灰色调）
    # H54：亮色原样保留；暗色 #313244 底 / #A6ADC8 字（5.5:1）/ #7F849C 边框。
    _register_prediction_theme(
        host, host.last_prediction_label,
        "font-size: 15px; color: #888888; background-color: #F5F5F5; "
        "border-radius: 6px; padding: 6px 10px; border: 1px solid #E0E0E0;",
        "font-size: 15px; color: " + PREDICTION_DARK_TOKENS['secondary'] + "; background-color: "
        + PREDICTION_DARK_TOKENS['card'] + "; border-radius: 6px; padding: 6px 10px; border: 1px solid "
        + PREDICTION_DARK_TOKENS['border'] + ";")
    host.last_prediction_label.setVisible(False)  # 初始隐藏，有上次结果时才显示
    lvc_layout.addWidget(host.last_prediction_label)
    
    # 分隔箭头
    host.lvc_arrow_label = QLabel("↓")
    host.lvc_arrow_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    host.lvc_arrow_label.setStyleSheet("font-size: 18px; color: #3498DB; font-weight: bold;")
    # H54：暗色下箭头改为 accent #89B4FA，避免 #3498DB 在深底上对比不足。
    _register_prediction_theme(
        host, host.lvc_arrow_label,
        "font-size: 18px; color: #3498DB; font-weight: bold;",
        "font-size: 18px; color: " + PREDICTION_DARK_TOKENS['accent'] + "; font-weight: bold;")
    host.lvc_arrow_label.setVisible(False)
    lvc_layout.addWidget(host.lvc_arrow_label)
    
    # 本次结果标签
    host.current_prediction_label = QLabel("本次结果：等待预测...")
    host.current_prediction_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    host.current_prediction_label.setWordWrap(True)
    # 本次结果标签样式 - 浅蓝底（当前信息用蓝色调，突出显示）
    # H54：亮色原样保留；暗色 #313244 底 / #89B4FA 字（5.4:1）/ #7F849C 边框。
    _register_prediction_theme(
        host, host.current_prediction_label,
        "font-size: 15px; color: #1565C0; background-color: #E3F2FD; "
        "border-radius: 6px; padding: 6px 10px; border: 1px solid #90CAF9; font-weight: bold;",
        "font-size: 15px; color: " + PREDICTION_DARK_TOKENS['accent'] + "; background-color: "
        + PREDICTION_DARK_TOKENS['card'] + "; border-radius: 6px; padding: 6px 10px; border: 1px solid "
        + PREDICTION_DARK_TOKENS['border'] + "; font-weight: bold;")
    lvc_layout.addWidget(host.current_prediction_label)
    
    result_layout.addWidget(host.last_vs_current_widget)
    
    # 【已移除】预测结果文字标签（原显示"算法 → 01 02 03..."的大文字）
    # 保留对象供内部逻辑读取（导出报告、收藏等功能仍需调用 .text()），但不添加到布局
    host.prediction_display = QLabel("等待预测...")
    host.prediction_display.setObjectName("PredictionDisplay")
    host.prediction_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
    host.prediction_display.setWordWrap(True)
    host.prediction_display.hide()  # 隐藏，不在界面显示

    # 【已移除】算法来源标签（原显示"来源: xxx"的胶囊形大标签）
    # 保留对象供内部逻辑使用，但不添加到布局
    host.algorithm_source_label = QLabel("")
    host.algorithm_source_label.hide()  # 隐藏，不在界面显示
    
    host.prediction_number_panel = QWidget()
    host.prediction_number_layout = QGridLayout(host.prediction_number_panel)
    host.prediction_number_layout.setSpacing(5)
    # 号码球保持「尺寸设置」里的自然大小，窗口变宽时多余空间交给末尾空白列吸收，
    # 避免「+」号所在列被拉宽，导致正码与特别码之间出现巨大空隙。
    host.prediction_number_layout.setColumnStretch(8, 1)
    result_layout.addWidget(host.prediction_number_panel)
    
    host.prediction_stats_label = QLabel("统计信息：等待预测...")
    host.prediction_stats_label.setObjectName("PredictionStatsLabel")
    host.prediction_stats_label.setWordWrap(True)
    result_layout.addWidget(host.prediction_stats_label)
    
    # 功能4：置信度分析文本框
    host.confidence_analysis_label = QLabel("置信度分析：")
    host.confidence_analysis_label.setObjectName("ConfidenceAnalysisLabel")
    result_layout.addWidget(host.confidence_analysis_label)
    
    host.confidence_analysis_text = QTextEdit()
    host.confidence_analysis_text.setReadOnly(True)
    host.confidence_analysis_text.setMaximumHeight(80)
    host.confidence_analysis_text.setPlaceholderText("预测完成后显示置信度分析...")
    # 置信度分析文本框样式 - 浅蓝色系（分析/信息展示用蓝色）
    #   QTextEdit {       文本框整体样式
    #     background-color: #F0F8FF;  背景色：淡蓝（信息展示区）
    #     border: 1px solid #3498DB;  边框：1px 蓝色实线
    #     border-radius: 4px;         圆角：4px
    #     font-size: 15px;            字体大小：15px
    #     padding: 5px;               内边距：5px
    #   }
    # H54：亮色原样保留；暗色 #313244 底 / #F5F5F5 字 / #7F849C 边框。
    _register_prediction_theme(
        host, host.confidence_analysis_text,
        "QTextEdit { background-color: #F0F8FF; border: 1px solid #3498DB; border-radius: 4px; font-size: 15px; padding: 5px; }",
        "QTextEdit { background-color: " + PREDICTION_DARK_TOKENS['card'] + "; color: "
        + PREDICTION_DARK_TOKENS['text'] + "; border: 1px solid " + PREDICTION_DARK_TOKENS['border']
        + "; border-radius: 4px; font-size: 15px; padding: 5px; }")
    result_layout.addWidget(host.confidence_analysis_text)
    
    # 收藏和导出按钮（功能1、功能7）
    collect_btn_layout = QHBoxLayout()
    collect_btn = QPushButton("收藏结果")
    collect_btn.setObjectName("CollectBtn")
    # 收藏结果按钮点击信号：收藏当前预测结果
    collect_btn.clicked.connect(host._on_collect_prediction)
    collect_btn_layout.addWidget(collect_btn)
    
    compare_btn = QPushButton("对比收藏")
    compare_btn.setObjectName("CompareBtn")
    # 对比收藏按钮点击信号：对比已收藏的多个预测结果
    compare_btn.clicked.connect(host._on_compare_collected)
    collect_btn_layout.addWidget(compare_btn)
    
    clear_collect_btn = QPushButton("清空收藏")
    clear_collect_btn.setObjectName("ClearCollectBtn")
    # 清空收藏按钮点击信号：清空所有收藏的预测结果
    clear_collect_btn.clicked.connect(host._on_clear_collected)
    collect_btn_layout.addWidget(clear_collect_btn)
    
    export_report_btn = QPushButton("导出报告")
    export_report_btn.setObjectName("ExportReportBtn")
    # 导出报告按钮点击信号：导出预测结果报告
    export_report_btn.clicked.connect(host._on_export_report)
    collect_btn_layout.addWidget(export_report_btn)
    
    result_layout.addLayout(collect_btn_layout)
    
    scroll.setWidget(result_widget)
    layout.addWidget(scroll, 1)
    
    return widget

def _build_number_prediction_panel(host):
    """构建「号码预测」页：七策略文本/卡片双视图、角控件、筛选与详情区。

    功能:
        创建视图切换、统计期数、生成/复制按钮、文本页与卡片页堆栈，以及底部详情区；
        两种视图共享同一份计算结果。
    参数:
        host: 主窗口实例；所有控件、状态与显示内容都挂到 host 上。
    返回:
        QWidget: 已加入 pred_right_tabs 的页面控件。
    注意/副作用:
        - 写 host.number_pred_stack、number_pred_text、number_pred_detail、
          number_pred_view_combo、number_pred_generate_btn 等控件，并注册信号到本页事件函数；
        - 文本页使用 QTextEdit 纯文本以保证复制格式，卡片页为滚动区 + 每策略一张卡片；
        - 控件创建顺序决定 [WidgetState] 的恢复顺序，请勿随意调整；
        - 构建末尾用 QTimer.singleShot(0, ...) 在状态恢复后同步视图（不触发生成）；
        - 数据不足时不在本函数计算，由 on_number_strategy_predict 校验并红字提示。
    """
    widget = QWidget()
    widget.setObjectName("NumberStrategyPanel")
    layout = QVBoxLayout(widget)
    layout.setSpacing(6)
    layout.setContentsMargins(5, 5, 5, 5)

    # 第一行：标题 + 视图切换 + 分析期数 + 生成按钮
    row = QHBoxLayout()
    title = QLabel("七策略号码预测")
    title.setObjectName("PanelTitle")
    row.addWidget(title)
    row.addStretch()

    # v0.0.48：文本列表 / 卡片视图切换。属性名以 c_ 开头且挂到 host，
    # 由主窗口 [WidgetState] 机制自动保存/恢复，重启后保持上次选择。
    view_label = QLabel("视图:")
    # 次要说明文字加深一档：亮色 #555 → #444，避免浅灰看不清
    view_label.setStyleSheet("font-size: 15px; color: #444; font-weight: 500;")
    host.number_pred_view_label = view_label
    row.addWidget(view_label)

    host.number_pred_view_combo = QComboBox()
    host.number_pred_view_combo.addItem("文本列表")
    host.number_pred_view_combo.addItem("卡片视图")
    host.number_pred_view_combo.setFixedWidth(104)
    host.number_pred_view_combo.setToolTip(
        "文本列表：逐行七策略纯文本，可选中复制\n"
        "卡片视图：策略 chip + 号码球 + 生肖五行 + 指标分析卡\n"
        "切换视图不会重新计算，两种视图共用同一份结果")
    host.number_pred_view_combo.setStyleSheet(
        "QComboBox { padding: 2px 6px; font-size: 15px; font-weight: 500; }")
    host.number_pred_view_combo.currentIndexChanged.connect(
        host._on_number_strategy_view_changed)
    row.addWidget(host.number_pred_view_combo)

    window_label = QLabel("分析期数:")
    window_label.setStyleSheet("font-size: 15px; color: #444; font-weight: 500;")
    host.number_pred_window_label = window_label
    row.addWidget(window_label)

    host.number_pred_window_spin = QSpinBox()
    host.number_pred_window_spin.setRange(30, 500)  # 下限与 lib 的 MIN_DRAWS 一致
    host.number_pred_window_spin.setValue(100)      # 默认最近 100 期
    host.number_pred_window_spin.setMinimumWidth(60)
    host.number_pred_window_spin.setToolTip(
        "参与七策略计算的最近 N 期（数据按期号倒序取最新 N 期）\n"
        "少于 30 期时不做预测，避免用不足样本硬凑结果")
    row.addWidget(host.number_pred_window_spin)

    host.number_pred_generate_btn = QPushButton("生成七策略")
    # 生成按钮样式 - 绿色系（执行成功/开始动作用绿色）
    host.number_pred_generate_btn.setStyleSheet("""
        QPushButton { background-color: #27AE60; color: white; border: none;
            border-radius: 4px; padding: 5px 12px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #1E8449; }
        QPushButton:disabled { background-color: #BDBDBD; }
    """)
    host.number_pred_generate_btn.clicked.connect(host._on_number_strategy_predict)
    row.addWidget(host.number_pred_generate_btn)
    layout.addLayout(row)

    # 第二行：状态提示 + 只显示号码开关 + 复制按钮
    status_row = QHBoxLayout()
    host.number_pred_status_label = QLabel("尚未生成：点击「生成七策略」开始计算。")
    host.number_pred_status_label.setObjectName("NumberPredStatusLabel")
    host.number_pred_status_label.setWordWrap(True)
    host.number_pred_status_label.setStyleSheet(
        "font-size: 15px; color: %s; font-weight: 500;"
        % ('#D0D0D8' if getattr(host, 'is_dark_mode', False) else '#444'))
    status_row.addWidget(host.number_pred_status_label, 1)

    # 文本列表在 1180×720 下若带生肖五行标签放不下，可一键退回纯号码；
    # 卡片视图的号码球下方始终保留生肖五行，因此该开关只影响文本列表。
    host.number_pred_hide_labels_check = QCheckBox("只显示号码")
    host.number_pred_hide_labels_check.setToolTip(
        "勾选后文本列表隐藏生肖五行标签（卡片视图不受影响）\n"
        "默认不勾选：标签形如 03虎·木")
    host.number_pred_hide_labels_check.setStyleSheet(
        "QCheckBox { font-size: 15px; color: #444; font-weight: 500; }")
    host.number_pred_hide_labels_check.toggled.connect(
        host._on_number_strategy_labels_toggled)
    status_row.addWidget(host.number_pred_hide_labels_check)

    # 复制按钮：文本视图复制当前七行文本；卡片视图复制等价的带标签文本
    host.number_pred_copy_btn = QPushButton("复制")
    host.number_pred_copy_btn.setToolTip("复制当前视图的七策略文本到剪贴板")
    host.number_pred_copy_btn.setStyleSheet("""
        QPushButton { background-color: #3498DB; color: white; border: none;
            border-radius: 4px; padding: 5px 12px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #2980B9; }
    """)
    host.number_pred_copy_btn.clicked.connect(host._on_number_strategy_copy)
    status_row.addWidget(host.number_pred_copy_btn)
    layout.addLayout(status_row)

    # 主体：文本页 / 卡片页共用同一份计算结果，用 QStackedWidget 切换
    host.number_pred_stack = QStackedWidget()

    # 文本页：上列表 + 下说明，可拖动分栏
    text_page = QWidget()
    text_layout = QVBoxLayout(text_page)
    text_layout.setContentsMargins(0, 0, 0, 0)
    text_layout.setSpacing(0)
    host.number_pred_splitter = QSplitter(Qt.Orientation.Vertical)
    host.number_pred_splitter.setHandleWidth(2)

    # v0.0.41 起改用「逐行纯文本」而不是三列表格，原因：
    #   1) 用户要求每行是 `策略名  正码  +  特别码`，表格复制出来是制表符分隔，
    #      无法还原这个字面量格式；QTextEdit 的 toPlainText() 可以逐字复制；
    #   2) v0.0.42：策略名与正码之间改用真正的制表符 `\t`，配合动态制表位，
    #      2~4 字策略名都跳到同一列，复制到记事本/Excel 也能按列拆开；
    #   3) 特别码用字符格式单独染红，但纯文本内容仍是两位号码，复制不受影响。
    host.number_pred_text = QTextEdit()
    host.number_pred_text.setObjectName("NumberPredText")
    host.number_pred_text.setReadOnly(True)
    host.number_pred_text.setAcceptRichText(False)
    # NoWrap：七行文本最长约 40 个等宽字符，1180 宽度下完全放得下；
    # 关闭换行与横向滚动条，避免出现第二条折行破坏「七行」结构。
    host.number_pred_text.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
    host.number_pred_text.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    host.number_pred_text.setMinimumHeight(220)
    host.number_pred_text.setPlaceholderText(
        "点击「生成七策略」后，这里按行显示 策略名  正码  +  特别码；"
        "点击任一行查看该策略的计算原理与分析说明。")
    # 字号 18px（≥15px 下限）。选 NSimSun（新宋体）而不是 Consolas：
    #   实测 NSimSun 18px 下 ASCII（空格/数字）宽 9px、一个中文宽 18px，
    #   恰好等于 2 个 ASCII 字符；而 Consolas 18px 空格 10px 但中文只有 18px，
    #   补空格会多出 4px，导致两字策略名与四字策略名的号码列错位。
    #   七个名字补到「机器学习」宽度后，正码列起点逐像素一致。
    #   该字体同时会被渲染函数写入字符格式，避免被主窗口全局字体覆盖。
    # 样式表只负责外观，不写 font-size / font-family：
    # 主窗口的全局字体自适应会覆盖控件字体（实测变成 Microsoft YaHei 20px），
    # 最终字体与字号由渲染时的字符格式统一指定（见 _number_strategy_mono_font）。
    host.number_pred_text.document().setDocumentMargin(8)
    host.number_pred_text.setStyleSheet("""
        QTextEdit { background-color: #FFFFFF; border: 1px solid #DDDDDD;
            border-radius: 4px; padding: 4px 8px; }
    """)
    host.number_pred_text.setFont(_number_strategy_mono_font())
    # v0.0.42：策略名与正码之间改用真正的制表符 \t 对齐。
    # Tab 必须留给文本排版，不能被当作焦点切换而吞掉；制表位在渲染时按字号动态换算。
    host.number_pred_text.setTabChangesFocus(False)
    # 点击文本内任一位置 → 光标落到对应行 → 下方详情区与卡片视图切换到该策略
    host.number_pred_text.cursorPositionChanged.connect(host._on_number_strategy_selected)
    host.number_pred_splitter.addWidget(host.number_pred_text)

    host.number_pred_detail = QTextEdit()
    host.number_pred_detail.setObjectName("NumberPredDetail")
    host.number_pred_detail.setReadOnly(True)
    host.number_pred_detail.setMinimumHeight(150)
    host.number_pred_detail.setPlaceholderText("选择上方任一策略行，查看该策略的计算原理与分析说明。")
    host.number_pred_detail.setStyleSheet("""
        QTextEdit { background-color: #FFFFFF; border: 1px solid #DDDDDD;
            border-radius: 4px; font-size: 15px; padding: 6px; }
    """)
    host.number_pred_splitter.addWidget(host.number_pred_detail)

    host.number_pred_splitter.setStretchFactor(0, 1)
    host.number_pred_splitter.setStretchFactor(1, 1)
    host._apply_splitter_sizes(host.number_pred_splitter, 'number_pred_splitter', [310, 300])
    text_layout.addWidget(host.number_pred_splitter)
    host.number_pred_stack.addWidget(text_page)

    # 卡片页：参考 mark_six 的策略 chip + 号码球 + 指标分析卡
    host.number_pred_stack.addWidget(_build_number_prediction_card(host))
    layout.addWidget(host.number_pred_stack, 1)

    # 初次构建即按角控件当前字号设置说明区（此时还没有结果，只同步字号与卡片主题）
    refresh_number_strategy_styles(host)
    # [WidgetState] 恢复过程会屏蔽信号，恢复后不会触发下拉/开关的槽函数；
    # 用 singleShot(0) 等主窗口完成恢复后再按控件当前值应用一次（不触发重算）。
    QTimer.singleShot(0, lambda: _sync_number_strategy_view_state(host))

    return widget


# 七策略卡片主题色：参考 mark_six 的渐变首色，保证 7 个 chip 视觉可区分；
# 仅用于选中态背景，不参与任何计算。
_NUMBER_CARD_ACCENTS = {
    'hot': '#FF6A00',
    'cold': '#36D1DC',
    'hybrid': '#7F00FF',
    'balanced': '#F2B705',
    'trend': '#11998E',
    'markov': '#2563EB',
    'ml': '#B45309',
}

# 卡片「策略名」标签列的固定宽度：四个汉字（15px 粗体）约 60px，
# 加左侧 4px 主题色条 + 8px 内边距，再留 18px 余量。所有卡片共用该常量，
# 保证卡片内与卡片间策略名列宽完全一致。
_NUMBER_CARD_NAME_WIDTH = 90


def _relative_luminance(color_hex):
    """计算颜色的 WCAG 相对亮度（0~1）

    功能:
        按 WCAG 2.x 公式把 sRGB 颜色换算为相对亮度，供对比度计算使用。
    参数:
        color_hex (str): `#RRGGBB` 形式的颜色。
    返回:
        float: 相对亮度（0~1），用于与另一颜色换算对比度。
    注意/副作用:
        - 纯函数，无写盘或信号副作用；
        - QColor 无法解析的颜色按黑色处理（亮度 0），不抛异常。
    """
    color = QColor(color_hex)
    if not color.isValid():
        color = QColor('#000000')

    def _channel(value):
        """把单个 sRGB 通道值归一化并做伽马校正（WCAG 中间步骤）。

        功能:
            将 0~255 的通道值按 WCAG 公式换算为线性光强度。
        参数:
            value (int): 0~255 的 sRGB 通道值。
        返回:
            float: 线性化后的通道强度（0~1）。
        注意/副作用:
            纯数学函数，无副作用；不校验入参范围，调用方保证 0~255。
        """
        ratio = value / 255.0
        if ratio <= 0.03928:
            return ratio / 12.92
        return ((ratio + 0.055) / 1.055) ** 2.4

    return (0.2126 * _channel(color.red()) + 0.7152 * _channel(color.green())
            + 0.0722 * _channel(color.blue()))


def _contrast_ratio(foreground, background):
    """计算两色的 WCAG 对比度（1~21）

    功能:
        用两色的相对亮度换算对比度比值，用于判断文字/背景是否达到 AA 标准。
    参数:
        foreground (str): 前景色 `#RRGGBB`。
        background (str): 背景色 `#RRGGBB`。
    返回:
        float: 对比度（1~21）；正文 AA 要求 ≥4.5。
    注意/副作用:
        纯数学计算，无副作用；非法颜色由 _relative_luminance 兜底为黑色。
    """
    first = _relative_luminance(foreground)
    second = _relative_luminance(background)
    lighter, darker = max(first, second), min(first, second)
    return (lighter + 0.05) / (darker + 0.05)


def _readable_text_color(fill):
    """在给定填充色上选择对比度更高的文字色（黑或白）

    功能:
        分别计算黑字、白字与填充色的对比度，返回较高者。
    参数:
        fill (str): 号码球填充色 `#RRGGBB`。
    返回:
        str: 纯黑 `#000000` 或白色 `#FFFFFF`。
    注意/副作用:
        - 纯函数，无副作用；选择规则是「黑/白中对比度更高者」；
        - 用纯黑而不是深灰：红球 `#FF0000` 上深灰 `#1A1A1A` 只有 4.35:1（未达 AA），
          纯黑可达 5.25:1；蓝球/绿球/特别码则白字对比度更高（8.59/5.14/4.98:1）。
    """
    return '#000000' if _contrast_ratio('#000000', fill) >= \
        _contrast_ratio('#FFFFFF', fill) else '#FFFFFF'


def _number_card_caption_font(host):
    """返回卡片号码球下方「生肖·五行」标签字体（15~18px 等宽）

    功能:
        以 NSimSun 等宽字体构造标签字体，字号取当前「文字 px」并钳制在 15~18px。
    参数:
        host: 主窗口实例，读取「文字」角控件字号。
    返回:
        QFont: NSimSun 等宽字体，像素字号钳在 15~18px。
    注意/副作用:
        不修改 host 状态；字体缺失时由 Qt 回退到默认等宽字体，字号下限 15px 不受角控件影响。
    """
    _number_px, text_px = _number_strategy_fonts(host)
    font = QFont('NSimSun')
    font.setStyleHint(QFont.StyleHint.Monospace)
    font.setPixelSize(max(15, min(text_px, 18)))
    font.setWeight(QFont.Weight.Medium)
    return font


def _number_card_ball_widths(host):
    """计算卡片视图号码球的直径与两种固定列宽（正码 / 特别码）

    功能:
        依据球直径与「生肖·五行」文本的实测宽度，算出七张卡片共用的列宽。
    参数:
        host: 主窗口实例。
    返回:
        tuple[int, int, int]: (球直径, 正码列宽, 特别码列宽)。
    注意/副作用:
        - 纯几何计算，无副作用；
        - 七张卡片共用同一组列宽，「03虎·木」与「特 40兔·土」都按各自最宽文本定宽，
          号码球之间因此逐像素对齐；1180×720 下 7 列仍在可视宽度内；
        - 字体度量缺失时按球直径兜底，不会小于球径。
    """
    diameter = _number_card_ball_diameter(host)
    metrics = QFontMetrics(_number_card_caption_font(host))
    normal_width = max(diameter, metrics.horizontalAdvance('龙·木') + 10)
    special_width = max(diameter, metrics.horizontalAdvance('特 龙·木') + 10)
    return diameter, normal_width, special_width


def _number_card_theme(host):
    """返回卡片视图当前主题的配色字典

    功能:
        按 is_dark_mode 选择亮色/暗色主题的正文、次要文字、卡片底、边框与指标块颜色。
    参数:
        host: 主窗口实例，读取 is_dark_mode 判断当前主题。
    返回:
        dict: 含 fg（正文色）、secondary（次要文字）、card（卡片底）、
            border（边框）、metric（指标块底）五个颜色值。
    注意/副作用:
        只读 host.is_dark_mode，不修改任何控件；缺少该属性时按亮色主题处理，不会抛异常。
    """
    if getattr(host, 'is_dark_mode', False):
        return {
            'fg': '#F5F5F5',
            'secondary': '#D0D0D8',
            'card': '#313244',
            'border': '#45475A',
            'metric': '#3B3B52',
        }
    return {
        'fg': '#1A1A1A',
        'secondary': '#444444',
        'card': '#FFFFFF',
        'border': '#E2E8F0',
        'metric': '#F8FAFC',
    }


def _build_number_prediction_card(host):
    """创建「卡片视图」页（策略 chip + 号码球 + 指标分析卡）

    功能:
        搭建卡片页骨架：滚动区、未生成提示、7 个策略 chip 与七张卡片的纵向容器。
    参数:
        host: 主窗口实例，所有控件挂到 host 以便后续刷新与 [WidgetState] 记忆。
    返回:
        QWidget: 卡片视图页，加入 host.number_pred_stack 的索引 1。
    注意/副作用:
        - 视觉与交互参考 mark_six 预测结果区：上方策略 chip，中部 6 正码 + 1 红色特别码，
          号码球下标生肖五行，底部卡片按「指标 + 数值」展示得分与分析文本；
        - 写 host.number_pred_card_page、number_pred_card_hint、number_pred_chip_buttons、
          number_pred_cards_host、number_pred_cards 等属性，并注册 chip 点击信号；
        - 本函数不做任何计算，数据由 render_number_strategy_results 统一注入；
        - 控件创建失败会向上抛，由主窗口装载流程统一记录。
    """
    page = QWidget()
    page.setObjectName('NumberPredCardPage')
    host.number_pred_card_page = page

    outer = QVBoxLayout(page)
    outer.setContentsMargins(0, 0, 0, 0)
    outer.setSpacing(0)

    scroll = QScrollArea(page)
    scroll.setObjectName('NumberPredCardScroll')
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.Shape.NoFrame)
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

    body = QWidget()
    body.setObjectName('NumberPredCardBody')
    body_layout = QVBoxLayout(body)
    # 外边距 12px、块间距 10px：七张卡片纵向排列，1180×720 下无横向溢出，
    # 纵向按需滚动（QScrollArea 处理）
    body_layout.setContentsMargins(12, 12, 12, 12)
    body_layout.setSpacing(10)

    # 未生成时只显示提示，避免空卡片占用高度
    host.number_pred_card_hint = QLabel('尚未生成：点击「生成七策略」后显示卡片。')
    host.number_pred_card_hint.setObjectName('NumberPredCardHint')
    host.number_pred_card_hint.setWordWrap(True)
    body_layout.addWidget(host.number_pred_card_hint)

    # 策略 chip：固定 7 项，作为「跳到对应卡片」的快捷入口，选中高亮
    chip_row = QWidget()
    chip_row.setObjectName('NumberPredChipRow')
    chip_layout = QHBoxLayout(chip_row)
    chip_layout.setContentsMargins(0, 0, 0, 0)
    # 间距 8px、chip 内边距紧凑：7 个 chip 在 1180 宽度下只占约 450px，不触发横向滚动
    chip_layout.setSpacing(8)
    host.number_pred_chip_buttons = []
    for index, (key, label) in enumerate(NumberStrategyPredictor.STRATEGIES):
        chip = QPushButton(label)
        chip.setObjectName('NumberStrategyChip')
        chip.setCheckable(True)
        chip.setMinimumHeight(32)
        chip.setCursor(Qt.CursorShape.PointingHandCursor)
        chip.setToolTip('点击跳转并高亮「%s」策略的卡片' % label)
        chip.clicked.connect(
            lambda _checked=False, i=index: on_number_strategy_chip_clicked(host, i))
        chip_layout.addWidget(chip)
        host.number_pred_chip_buttons.append((key, chip))
    chip_layout.addStretch(1)
    body_layout.addWidget(chip_row)

    # 七张策略卡片：所有卡片共用 _NUMBER_CARD_NAME_WIDTH 的标签列宽，
    #     卡片内部为「策略名 | 号码行 / 指标行 / 分析说明」的网格
    host.number_pred_cards_host = QWidget()
    host.number_pred_cards_host.setObjectName('NumberPredCardCards')
    host.number_pred_cards_layout = QVBoxLayout(host.number_pred_cards_host)
    host.number_pred_cards_layout.setContentsMargins(0, 0, 0, 0)
    host.number_pred_cards_layout.setSpacing(10)
    host.number_pred_cards = []
    body_layout.addWidget(host.number_pred_cards_host)
    body_layout.addStretch(1)

    scroll.setWidget(body)
    outer.addWidget(scroll)

    host.number_pred_card_hint.setVisible(True)
    _refresh_number_card_styles(host)
    return page


def _refresh_number_card_styles(host):
    """按当前主题与角控件字号刷新卡片页的 QSS（不重算、不改文本内容）

    功能:
        重设卡片页样式表与 7 个 chip 的内联样式，使字号与主题即时生效。
    参数:
        host: 主窗口实例。
    返回:
        None（仅刷新样式）。
    注意/副作用:
        - 重设卡片页 setStyleSheet 与 7 个 chip 的内联样式；
        - 字号全部做 15px 下限保护；
        - 只遍历已存在的卡片控件；控件已被销毁时 RuntimeError 由调用方跳过，不影响文本视图。
    """
    if not hasattr(host, 'number_pred_card_page'):
        return
    theme = _number_card_theme(host)
    _number_px, text_px = _number_strategy_fonts(host)
    hint_px = max(15, min(text_px, 18))
    body_px = max(15, min(text_px, 20))
    label_px = max(15, min(text_px, 18))
    host.number_pred_card_page.setStyleSheet(f"""
        #NumberPredCardBody {{ background-color: transparent; }}
        #NumberPredCardCards {{ background-color: transparent; }}
        #NumberPredCardScroll {{ border: none; background-color: transparent; }}
        #NumberPredCardHint {{ color: {theme['secondary']}; font-size: {hint_px}px;
            font-weight: 500; padding: 6px 2px; }}
        QFrame#NumberPredCardItem {{ background-color: {theme['card']};
            border: 2px solid {theme['border']}; border-radius: 10px; }}
        QFrame#NumberPredCardItem QLabel#NumberPredCardName {{ font-size: {label_px}px;
            font-weight: bold; background: transparent; }}
        QFrame#NumberPredCardItem QLabel#NumberPredCardMetrics {{ color: {theme['secondary']};
            font-size: {label_px}px; font-weight: 500; background: transparent; border: none; }}
        QFrame#NumberPredCardItem QLabel#NumberPredCardAnalysisText {{ color: {theme['fg']};
            font-size: {body_px}px; font-weight: 500; background: transparent; border: none; }}
    """)
    _style_number_card_chips(host)
    _apply_number_card_chip_styles(host)


def _style_number_card_chips(host):
    """为 7 个策略 chip 写入「未选中 / 悬停 / 选中」三态样式（只在主题或字号变化时调用）

    功能:
        为每个 chip 生成带策略主题色的三态 QSS，并以 WCAG 对比度自动选择选中态文字色。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 选中态用 `QPushButton:checked` 伪状态表达，因此点击切换时只需 setChecked，
          不再逐个重设 QSS（重设 QSS 会触发整棵子树重新 polish，约 100ms 卡顿）；
        - 写 chip.setStyleSheet；chip 列表缺失时静默返回，主题缺失时按浅色兜底。
    """
    if not hasattr(host, 'number_pred_chip_buttons'):
        return
    theme = _number_card_theme(host)
    _number_px, text_px = _number_strategy_fonts(host)
    chip_px = max(15, min(text_px, 24))
    base_bg = '#3B3B52' if getattr(host, 'is_dark_mode', False) else '#F7FAFC'
    for key, chip in host.number_pred_chip_buttons:
        accent = _NUMBER_CARD_ACCENTS.get(key, '#3498DB')
        text_color = _readable_text_color(accent)
        chip.setStyleSheet(
            "QPushButton { background-color: %s; color: %s; border: 1px solid %s; "
            "border-radius: 14px; padding: 3px 10px; font-size: %dpx; font-weight: 500; }"
            "QPushButton:hover { border-color: %s; }"
            "QPushButton:checked { background-color: %s; color: %s; border: 1px solid %s;"
            " font-weight: bold; }"
            % (base_bg, theme['fg'], theme['border'], chip_px, accent, accent, text_color, accent))


def _apply_number_card_chip_styles(host):
    """同步 7 个 chip 与 7 张卡片的选中态（只改 checked 与边框，不重建控件）

    功能:
        按 host._number_strategy_selected_index 更新 chip 勾选状态与卡片选中边框。
    参数:
        host: 主窗口实例；读取 _number_strategy_selected_index 与相关控件列表。
    返回:
        None（仅改变选中态外观）。
    注意/副作用:
        - chip 只 setChecked，样式由 :checked 伪状态负责；
        - 卡片边框线宽恒为 2px，未选中用主题描边色、选中用策略主题色，
          因此切换选中不会产生 1px 布局位移，卡片之间始终对齐；
        - 只重设「上一次选中」和「本次选中」两张卡片的边框，避免 7 张卡全部重新 polish；
        - 控件缺失时静默跳过，不影响号码与文本内容。
    """
    selected = int(getattr(host, '_number_strategy_selected_index', 0) or 0)
    for index, (key, chip) in enumerate(getattr(host, 'number_pred_chip_buttons', [])):
        chip.setChecked(index == selected)

    cards = getattr(host, 'number_pred_cards', []) or []
    previous = getattr(host, '_number_card_styled_index', None)
    if previous == selected:
        return
    theme = _number_card_theme(host)
    for card_index in {previous, selected}:
        if card_index is None or not (0 <= card_index < len(cards)):
            continue
        card = cards[card_index]
        frame = card.get('frame')
        if frame is None:
            continue
        accent = _NUMBER_CARD_ACCENTS.get(card.get('key', ''), '#3498DB')
        border = accent if card_index == selected else theme['border']
        frame.setStyleSheet(
            "QFrame#NumberPredCardItem { border: 2px solid %s; }" % border)
    host._number_card_styled_index = selected


def _clear_number_cards(host):
    """清空卡片视图的七张策略卡片

    功能:
        逐个移除并销毁卡片控件，同时重置卡片列表与「已上色序号」。
    参数:
        host: 主窗口实例，读取 number_pred_cards_layout。
    返回:
        None。
    注意/副作用:
        - 写 host.number_pred_cards = [] 与 host._number_card_styled_index = None；
        - 对布局项执行 deleteLater，避免切换/刷新时旧卡片残留；
        - 布局不存在时只重置卡片列表；控件已销毁时静默返回。
    """
    host.number_pred_cards = []
    # 卡片重建后需要重新给新卡片上选中边框，因此清空「已上色序号」
    host._number_card_styled_index = None
    layout = getattr(host, 'number_pred_cards_layout', None)
    if layout is None:
        return
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget()
        if widget is not None:
            widget.deleteLater()


def _number_card_ball_diameter(host):
    """计算卡片视图号码球直径

    功能:
        取「尺寸」设置中的高度作为球直径，并钳制在 44~72px。
    参数:
        host: 主窗口实例，读取 _prediction_ball_size['height']（默认 60）。
    返回:
        int: 直径像素（44~72px）；1180×720 下 7 个球加间距仍小于右侧面板宽度。
    注意/副作用:
        纯几何计算，无副作用；尺寸或字号缺失时按默认值兜底。
    """
    size = getattr(host, '_prediction_ball_size', None) or {}
    height = int(size.get('height', 60) or 60)
    return max(44, min(72, height))


def _create_number_card_ball(host, number, zodiac, element, is_special=False,
                             diameter=None, cell_width=None, caption_font=None):
    """创建单个号码球（上方圆球 + 下方「生肖·五行」）

    功能:
        按号码波色或特别码红色填充生成固定宽度的球体组件，并在下方显示生肖·五行。
    参数:
        host: 主窗口实例，读取字号与主题。
        number (int): 1~49 的号码。
        zodiac (str): 生肖字符（来自用户当前绑定）。
        element (str): 五行字符（来自用户当前绑定）。
        is_special (bool): True 表示特别码，用红色填充与红色说明文字。
        diameter (int | None): 球直径；None 时按角控件「尺寸」计算。
        cell_width (int | None): 该列固定宽度；None 时按标签实测宽度计算。
        caption_font (QFont | None): 生肖五行标签字体；None 时按当前字号构造。
    返回:
        QWidget: 固定宽度的球体组件，可直接加入横向布局。
    注意/副作用:
        - 只创建控件，不加入布局、不修改 host 状态；
        - 球内号码字号不超过「直径 - 6px」，且不低于 15px；
        - 特别码固定红色高亮，与按波色着色的正码明显区分；
        - 球内号码文字色按 WCAG 对比度自动选黑/白；字体/颜色缺失时按默认值兜底。
    """
    diameter = diameter or _number_card_ball_diameter(host)
    _number_px, text_px = _number_strategy_fonts(host)
    number_px = int(getattr(host, '_prediction_ball_size', {}).get('font', 20) or 20)
    # 球内号码字号不超过「直径 - 6px」，且全项目下限 15px
    number_px = max(15, min(max(15, number_px), diameter - 6))
    caption_font = caption_font or _number_card_caption_font(host)
    caption_px = max(15, caption_font.pixelSize())
    caption = '%s·%s' % (zodiac or '?', element or '?')
    caption_text = ('特 ' if is_special else '') + caption
    if not cell_width:
        # 标签按实测像素定宽：1180 宽度下「特 40兔·土」也不会被压边或截断
        cell_width = max(diameter, QFontMetrics(caption_font).horizontalAdvance(caption_text) + 10)

    wrapper = QWidget()
    wrapper.setObjectName('NumberPredCardBall')
    wrapper.setFixedWidth(cell_width)
    box = QVBoxLayout(wrapper)
    box.setContentsMargins(0, 0, 0, 0)
    box.setSpacing(2)

    ball = QLabel('%02d' % number)
    ball.setObjectName('NumberPredCardBallNumber')
    ball.setAlignment(Qt.AlignmentFlag.AlignCenter)
    ball.setFixedSize(diameter, diameter)
    if is_special:
        # 特别码固定红色高亮，与按波色着色的正码形成明显区分
        fill = '#D32F2F'
        stroke = '#8B0000'
        border_px = 3
    else:
        colors = LotteryConfig.get_number_color(number)
        fill = colors['text']
        stroke = colors['border']
        border_px = 2
    # 纯红/绿填充配白字只有 4.0:1 / 5.1:1，纯红不达 AA；按对比度自动选黑字后 ≥5.2:1
    text_color = _readable_text_color(fill)
    number_font = QFont('NSimSun')
    number_font.setStyleHint(QFont.StyleHint.Monospace)
    number_font.setPixelSize(number_px)
    number_font.setWeight(QFont.Weight.Bold)
    ball.setFont(number_font)
    ball.setStyleSheet(
        "QLabel { background-color: %s; color: %s; border: %dpx solid %s; "
        "border-radius: %dpx; font-size: %dpx; font-weight: bold; }"
        % (fill, text_color, border_px, stroke, diameter // 2, number_px))
    box.addWidget(ball, 0, Qt.AlignmentFlag.AlignHCenter)

    caption_label = QLabel(caption_text)
    caption_label.setObjectName('NumberPredCardBallCaption')
    caption_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    # 显式 setFont：QSS 的 font-size 在部分主题下不一定能被 fontInfo() 读到，
    # 显式字体保证实测 pixelSize ≥ 15px（用户全局字号底线）
    caption_label.setFont(caption_font)
    caption_label.setStyleSheet(
        "QLabel { color: %s; font-size: %dpx; font-weight: %s; background: transparent; }"
        % ('#FF6B6B' if (is_special and getattr(host, 'is_dark_mode', False))
           else ('#C62828' if is_special else _number_card_theme(host)['fg']),
           caption_px, 'bold' if is_special else '500'))
    box.addWidget(caption_label, 0, Qt.AlignmentFlag.AlignHCenter)
    return wrapper


def _number_card_metrics(data, meta):
    """由现有策略结果整理 8 个「指标 + 数值」

    功能:
        把策略结果中的号码、特别码、得分与分析窗口元信息聚合成 8 组展示指标。
    参数:
        data (dict): 单个策略结果（含 numbers / special / scores / label）。
        meta (dict): 本次生成的分析窗口、参与期数与最新期号。
    返回:
        list[tuple[str, str]]: 8 组（指标名, 数值），全部来自 lib 已有字段，
            仅做展示层聚合（均分/最高/最低），不新增评分算法。
    注意/副作用:
        - 纯只读计算，不修改 data / meta；
        - scores 缺失时显示「—」，不做除零；scores 的键为字符串（JSON 落盘后）也兼容。
    """
    numbers = data.get('numbers') or []
    special = data.get('special', 0)
    scores = data.get('scores') or {}
    # 保存到 JSON 后 scores 的键会变成字符串（'3'），这里同时兼容 int 与 str 键，
    # 否则卡片指标会全部显示「—」
    scored = []
    for number in numbers:
        value = scores.get(number)
        if value is None:
            value = scores.get(str(number))
        if value is not None:
            scored.append((int(number), float(value)))
    if scored:
        avg_score = sum(value for _n, value in scored) / len(scored)
        best = max(scored, key=lambda item: item[1])
        worst = min(scored, key=lambda item: item[1])
        best_text = '%02d · %.4f' % (best[0], best[1])
        worst_text = '%02d · %.4f' % (worst[0], worst[1])
        avg_text = '%.4f' % avg_score
    else:
        avg_text = best_text = worst_text = '—'
    window = int(meta.get('window', 0) or 0)
    used = int(meta.get('used_records', 0) or 0)
    latest = str(meta.get('latest_period', '') or '—')
    return [
        ('策略', str(data.get('label', '—'))),
        ('正码均分', avg_text),
        ('最高得分', best_text),
        ('最低得分', worst_text),
        ('特别码', '%02d' % special if special else '—'),
        ('分析窗口', '%d期' % window if window else '—'),
        ('参与期数', '%d期' % used if used else '—'),
        ('最新期号', latest),
    ]


def _number_card_metric_text(data, meta):
    """把 _number_card_metrics 的 8 项指标压成一行文字（供每张卡片展示）

    功能:
        抽出指标名与数值，用「｜」连接成一行，省略与卡片左侧重复的「策略」项。
    参数:
        data (dict): 单个策略结果。
        meta (dict): 本次生成的分析窗口、参与期数与最新期号。
    返回:
        str: 形如「正码均分 0.8123 ｜ 最高得分 03 · 0.9321 ｜ …」的单行文字；
            首项「策略」与卡片左侧策略名重复，因此省略。
    注意/副作用:
        纯函数，无副作用；指标为空时返回「指标不可用」，不抛异常。
    """
    pairs = _number_card_metrics(data, meta)
    if not pairs:
        return '指标不可用'
    return ' ｜ '.join('%s %s' % (label, value) for label, value in pairs[1:])


def _show_number_strategy_card(host, index, force=False):
    """把七策略全部渲染为卡片（每策略一张，顺序与文本列表一致）

    功能:
        按 host._number_strategy_results 创建七张策略卡片并同步选中高亮。
    参数:
        host: 主窗口实例。
        index (int): 当前选中的策略序号（0~6）；只影响高亮，不隐藏其他卡片。
        force (bool): True 时强制重建七张卡片（数据/主题/生肖字体变化后使用）；
            False 时若卡片已与当前结果一一对应，只更新选中高亮，避免点击文本行时卡顿。
    返回:
        None。
    注意/副作用:
        - 七张卡片同时创建并显示，顺序与文本列表一致；
        - 每张卡片为「策略名 | 六正码 + 特别码（球下生肖·五行）/ 指标行 / 分析说明」的网格，
          策略名列宽固定为 _NUMBER_CARD_NAME_WIDTH，卡片内与卡片间严格对齐；
        - 球列宽按「生肖·五行」实测像素定宽，特别码带 `+` 号且红色高亮；
        - 只读取 host._number_strategy_results，不做任何计算或模型调用；
        - 写 host._number_strategy_selected_index 与 number_pred_cards，并调用样式同步；
        - 结果为空时只显示提示标签并清空卡片；某策略缺号码时该卡片显示「未生成」。
    """
    if not hasattr(host, 'number_pred_cards_layout'):
        return
    items = getattr(host, '_number_strategy_results', []) or []
    existing = getattr(host, 'number_pred_cards', []) or []
    # 结果对象未变（同一批 dict）时无需重建 7 张卡片，只切换高亮：
    # 点击文本行会频繁调用本函数，重建约 105 个控件需 ~220ms，会造成明显卡顿
    if (not force and items and len(existing) == len(items)
            and all(card.get('data') is data for card, data in zip(existing, items))):
        host._number_strategy_selected_index = max(0, min(int(index), len(items) - 1))
        host.number_pred_card_hint.setVisible(False)
        _apply_number_card_chip_styles(host)
        return
    _clear_number_cards(host)
    if not items:
        host.number_pred_card_hint.setVisible(True)
        _apply_number_card_chip_styles(host)
        return

    index = max(0, min(int(index), len(items) - 1))
    host._number_strategy_selected_index = index
    host.number_pred_card_hint.setVisible(False)

    theme = _number_card_theme(host)
    _number_px, text_px = _number_strategy_fonts(host)
    name_px = max(15, min(text_px, 18))
    info_px = max(15, min(text_px, 20))
    diameter, normal_width, special_width = _number_card_ball_widths(host)
    caption_font = _number_card_caption_font(host)
    # 实时读取当前生肖/五行绑定；不硬编码 (num-1)%12，保证与用户手工绑定一致
    zodiac_binding, element_binding = _number_strategy_bindings(host)
    meta = getattr(host, '_number_strategy_result_meta', None) or {}

    for data in items:
        key = data.get('key', '')
        label = str(data.get('label', '') or '—')
        accent = _NUMBER_CARD_ACCENTS.get(key, '#3498DB')

        card = QFrame()
        card.setObjectName('NumberPredCardItem')
        grid = QGridLayout(card)
        grid.setContentsMargins(14, 12, 14, 12)
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(6)
        grid.setColumnMinimumWidth(0, _NUMBER_CARD_NAME_WIDTH)
        grid.setColumnStretch(1, 1)

        # 第一列：策略名（固定列宽 + 左侧主题色条），所有卡片逐像素对齐
        name_label = QLabel(label)
        name_label.setObjectName('NumberPredCardName')
        name_label.setFixedWidth(_NUMBER_CARD_NAME_WIDTH)
        # 固定 28px 高：左侧主题色条只作为「标签」出现，不会随号码行拉成长条
        name_label.setFixedHeight(28)
        name_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        name_label.setStyleSheet(
            "QLabel { color: %s; font-size: %dpx; font-weight: bold; "
            "border-left: 4px solid %s; padding-left: 8px; background: transparent; }"
            % (theme['fg'], name_px, accent))
        grid.addWidget(name_label, 0, 0)

        # 第二列第一行：六个正码 + `+` + 特别码（下方各带生肖·五行）
        ball_host = QWidget()
        ball_host.setObjectName('NumberPredCardBalls')
        ball_layout = QHBoxLayout(ball_host)
        ball_layout.setContentsMargins(0, 0, 0, 0)
        ball_layout.setSpacing(8)
        ball_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        numbers = data.get('numbers') or []
        for number in numbers:
            ball_layout.addWidget(
                _create_number_card_ball(
                    host, number, zodiac_binding.get(number, ''),
                    element_binding.get(number, ''), diameter=diameter,
                    cell_width=normal_width, caption_font=caption_font))
        special = int(data.get('special', 0) or 0)
        if special:
            plus = QLabel('+')
            plus.setObjectName('NumberPredCardPlus')
            plus.setAlignment(Qt.AlignmentFlag.AlignCenter)
            plus_font = QFont('NSimSun')
            plus_font.setStyleHint(QFont.StyleHint.Monospace)
            plus_font.setPixelSize(info_px)
            plus_font.setWeight(QFont.Weight.Bold)
            plus.setFont(plus_font)
            plus.setStyleSheet(
                "QLabel { color: %s; font-size: %dpx; font-weight: bold; background: transparent; }"
                % (theme['secondary'], info_px))
            # 特别码与六正码之间用「间距 + 加号 + 间距」分组，加号不会被吞掉
            ball_layout.addSpacing(10)
            ball_layout.addWidget(plus)
            ball_layout.addSpacing(10)
            ball_layout.addWidget(
                _create_number_card_ball(
                    host, special, zodiac_binding.get(special, ''),
                    element_binding.get(special, ''), is_special=True,
                    diameter=diameter, cell_width=special_width,
                    caption_font=caption_font))
        if not numbers and not special:
            empty = QLabel('未生成')
            empty.setObjectName('NumberPredCardMetrics')
            empty.setStyleSheet(
                "QLabel { color: %s; font-size: 15px; font-weight: 500; background: transparent; }"
                % theme['secondary'])
            ball_layout.addWidget(empty)
        ball_host.setMinimumHeight(diameter + 26)
        grid.addWidget(ball_host, 0, 1)

        # 第二列第二行：指标（保留原有 8 项数据，压成一行，避免卡片过高）
        metrics_label = QLabel(_number_card_metric_text(data, meta))
        metrics_label.setObjectName('NumberPredCardMetrics')
        metrics_label.setWordWrap(True)
        metrics_label.setTextFormat(Qt.TextFormat.PlainText)
        metrics_font = QFont()
        metrics_font.setPixelSize(max(15, min(text_px, 18)))
        metrics_label.setFont(metrics_font)
        grid.addWidget(metrics_label, 1, 1)

        # 第二列第三行：分析说明（缺失时回退到计算原理）
        analysis_text = data.get('analysis') or data.get('principle') \
            or '（该策略未生成分析说明）'
        if data.get('error'):
            analysis_text = '%s\n错误：%s' % (analysis_text, data.get('error'))
        analysis_label = QLabel(analysis_text)
        analysis_label.setObjectName('NumberPredCardAnalysisText')
        analysis_label.setWordWrap(True)
        analysis_label.setTextFormat(Qt.TextFormat.PlainText)
        analysis_font = QFont()
        analysis_font.setPixelSize(max(15, min(text_px, 20)))
        analysis_label.setFont(analysis_font)
        grid.addWidget(analysis_label, 2, 1)

        host.number_pred_cards.append({
            'key': key,
            'label': label,
            'frame': card,
            'name': name_label,
            'balls': ball_host,
            'analysis': analysis_label,
            'data': data,
        })
        host.number_pred_cards_layout.addWidget(card)

    _apply_number_card_chip_styles(host)


def on_number_strategy_chip_clicked(host, index):
    """策略 chip 点击：切换卡片视图与文本详情区

    功能:
        把选中序号写入 host，刷新详情文本，并记住上次查看的策略。
    参数:
        host: 主窗口实例。
        index (int): 被点击 chip 的序号（0~6）。
    返回:
        None。
    注意/副作用:
        - chip 切换不触发七策略重算，只切换展示；文本列表的光标位置保持不动，
          避免影响用户正在复制的文本选区；
        - 调用 show_number_strategy_detail 刷新详情，并调用 _persist_number_strategy_selection 落盘选中项；
        - 控件或结果缺失时静默返回；不触发重新计算。
    """
    host._number_strategy_selected_index = index
    # show_number_strategy_detail 会同步刷新卡片，因此这里只更新详情文本
    show_number_strategy_detail(host, index)
    # 记住上次查看的策略，重启回填后可恢复选中 chip（不重算）
    _persist_number_strategy_selection(host, index)


def _sync_number_strategy_view_state(host):
    """按控件当前值应用视图与标签开关（[WidgetState] 恢复后调用）

    功能:
        读取下拉与复选框当前值，同步 QStackedWidget 当前页与「只显示号码」状态。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 恢复过程屏蔽了信号，因此需要手动同步界面；该函数不触发生成/重算；
        - 写 host._number_strategy_hide_labels，并调用 refresh_number_strategy_styles 刷新样式；
        - 结果为空时只同步切换按钮状态；控件不存在时直接返回。
    """
    if not hasattr(host, 'number_pred_stack'):
        return
    combo = getattr(host, 'number_pred_view_combo', None)
    index = combo.currentIndex() if combo is not None else 0
    host.number_pred_stack.setCurrentIndex(0 if index <= 0 else 1)
    check = getattr(host, 'number_pred_hide_labels_check', None)
    host._number_strategy_hide_labels = bool(check.isChecked()) if check is not None else False
    if hasattr(host, 'number_pred_text'):
        refresh_number_strategy_styles(host)


def on_number_strategy_view_changed(host, index=None):
    """「视图」下拉切换：文本列表 ↔ 卡片视图（不重算）

    功能:
        按下拉索引切换 QStackedWidget 当前页；切到卡片页时按当前绑定重新渲染标签。
    参数:
        host: 主窗口实例。
        index (int | None): 下拉当前索引，0=文本列表，1=卡片视图；None 时从控件读取。
    返回:
        None。
    注意/副作用:
        - 只改可见性，不重算结果；
        - 切到卡片视图时调用 _show_number_strategy_card（优先复用已有卡片，只更新高亮）；
        - 视图控件缺失时静默返回。
    """
    if not hasattr(host, 'number_pred_stack'):
        return
    if index is None:
        index = host.number_pred_view_combo.currentIndex()
    host.number_pred_stack.setCurrentIndex(0 if index <= 0 else 1)
    if index > 0:
        # 切到卡片页时按当前生肖/五行重新渲染一次标签（不重算号码）
        _show_number_strategy_card(host,
                                   getattr(host, '_number_strategy_selected_index', 0))


def on_number_strategy_labels_toggled(host, checked):
    """「只显示号码」开关：重排文本列表，立即让生肖五行标签显示/隐藏

    功能:
        记录开关状态，并在已有结果时按新标签设置重排七行文本。
    参数:
        host: 主窗口实例。
        checked (bool): True 表示隐藏标签，只显示两位号码。
    返回:
        None。
    注意/副作用:
        - 只影响文本列表（卡片视图始终带生肖五行）；不重新计算号码；
        - 写 host._number_strategy_hide_labels，并调用 _render_number_strategy_text 重排；
        - 结果为空时只保存开关状态；刷新失败由渲染函数内部捕获。
    """
    host._number_strategy_hide_labels = bool(checked)
    strategies = getattr(host, '_number_strategy_results', None)
    if strategies and hasattr(host, 'number_pred_text'):
        _render_number_strategy_text(host, strategies)


def _set_number_pred_status(host, text, kind='info'):
    """设置号码预测状态栏文字并跟随主题着色

    功能:
        写入状态文字与状态类型，并按亮/暗主题选择普通、成功、失败三种颜色。
    参数:
        host: 主窗口实例。
        text (str): 状态文字。
        kind (str): 'info'（普通说明）、'ok'（成功）、'error'（失败）。
    返回:
        None。
    注意/副作用:
        - 写 host._number_pred_status_kind 并重设状态标签 QSS；
        - 暗色主题下普通文字用浅灰白、成功用浅绿、失败用浅红，
          避免原 #444 / #1E8449 / #C62828 在深底上对比度不足；
        - 状态标签已销毁时 RuntimeError 被捕获，保证计算流程继续。
    """
    host.number_pred_status_label.setText(text)
    host._number_pred_status_kind = kind
    dark = bool(getattr(host, 'is_dark_mode', False))
    if kind == 'ok':
        color = '#A6E3A1' if dark else '#1E8449'
    elif kind == 'error':
        color = '#FF6B6B' if dark else '#C62828'
    else:
        color = _number_card_theme(host)['secondary']
    host.number_pred_status_label.setStyleSheet(
        "font-size: 15px; color: %s; font-weight: 500;" % color)


def copy_number_strategy_text(host):
    """复制当前视图的七策略文本到剪贴板

    功能:
        按当前视图决定是否带生肖五行标签，生成七行文本并写入系统剪贴板。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 文本列表：复制当前标签开关下的七行文本；
        - 卡片视图：复制带生肖五行标签的等价文本（与卡片展示一致）；
        - 两种视图共用同一份格式化结果，不另行拼接；
        - 写系统剪贴板并调用 _set_number_pred_status 提示；
        - 无结果文本时只提示「暂无可复制内容」，不写剪贴板。
    """
    strategies = getattr(host, '_number_strategy_results', None)
    if not strategies:
        _set_number_pred_status(host, '尚未生成：没有可复制的号码预测结果。', 'error')
        return
    card_view = getattr(host, 'number_pred_stack', None) is not None and \
        host.number_pred_stack.currentIndex() == 1
    show_labels = True if card_view else not bool(
        getattr(host, '_number_strategy_hide_labels', False))
    rows = _number_strategy_line_rows(host, strategies, show_labels=show_labels)
    QApplication.clipboard().setText('\n'.join(row['text'] for row in rows))
    _set_number_pred_status(host, '已复制七策略文本（%s）。'
                            % ('卡片视图' if card_view else '文本列表'), 'ok')


def _build_probability_panel(host):
    """构建「出现概率」页：数字概率与生肖概率两个子选项卡。

    功能:
        创建统计期数、排序方式、刷新按钮与两个子选项卡，并在有历史数据时自动刷新一次。
    参数:
        host: 主窗口实例。
    返回:
        QWidget: 面板容器。
    注意/副作用:
        - 顶部公共行提供统计期数（5~500，默认 30）与排序方式（概率/号码升降序）；
        - 两个控件同时连接刷新槽与 host._save_ini_config（每次变更都会写 INI）；
        - 写 host.prob_period_spin、prob_sort_combo、probability_list、prob_sub_tabs、
          prob_stats_label 等控件；
        - 历史数据不足时由 update_probability_panel 显示占位文字。
    """
    widget = QWidget()
    widget.setObjectName("ProbabilityPanel")
    layout = QVBoxLayout(widget)
    layout.setSpacing(6)
    layout.setContentsMargins(5, 5, 5, 5)
    
    # 标题行
    title_layout = QHBoxLayout()
    title = QLabel("下一次出现概率")
    title.setObjectName("PanelTitle")
    title_layout.addWidget(title)
    title_layout.addStretch()
    
    # 期数设置
    period_label = QLabel("统计期数:")
    # 统计期数标签样式
    #   font-size: 15px;  字体大小：15px
    #   color: #666;      文字颜色：中灰（辅助文字用灰色）
    period_label.setStyleSheet("font-size: 15px; color: #666;")
    title_layout.addWidget(period_label)
    
    host.prob_period_spin = QSpinBox()
    host.prob_period_spin.setRange(5, 500)
    host.prob_period_spin.setValue(30)
    host.prob_period_spin.setMinimumWidth(60)
    # 期数选择数字框样式
    #   QSpinBox {       数字框整体样式
    #     padding: 2px;   内边距：2px
    #     font-size: 15px; 字体大小：15px
    #   }
    # 统计期数变化信号：更新概率面板数据
    host.prob_period_spin.valueChanged.connect(host._update_probability_panel)
    # 统计期数变化信号：保存期数设置到INI配置文件
    host.prob_period_spin.valueChanged.connect(lambda: host._save_ini_config())
    title_layout.addWidget(host.prob_period_spin)
    
    # 排序方式
    sort_label = QLabel("  排序:")
    # 排序方式标签样式
    #   font-size: 15px;  字体大小：15px
    #   color: #666;      文字颜色：中灰（辅助文字用灰色）
    sort_label.setStyleSheet("font-size: 15px; color: #666;")
    title_layout.addWidget(sort_label)
    
    host.prob_sort_combo = QComboBox()
    host.prob_sort_combo.addItems(["概率降序", "概率升序", "号码升序", "号码降序"])
    host.prob_sort_combo.setFixedWidth(90)
    # 排序方式下拉框样式
    #   QComboBox {      下拉框整体样式
    #     padding: 2px;   内边距：2px
    #     font-size: 15px; 字体大小：15px
    #   }
    host.prob_sort_combo.setStyleSheet("QComboBox { padding: 2px; font-size: 15px; }")
    # 排序方式变化信号：重新按新排序规则刷新概率面板
    host.prob_sort_combo.currentIndexChanged.connect(host._update_probability_panel)
    # 排序方式变化信号：保存排序设置到INI配置文件
    host.prob_sort_combo.currentIndexChanged.connect(lambda: host._save_ini_config())
    title_layout.addWidget(host.prob_sort_combo)
    
    refresh_btn = QPushButton("刷新")
    # 概率面板刷新按钮样式 - 蓝色系（刷新/操作用蓝色）
    #   QPushButton {       按钮常态样式
    #     background-color: #3498DB;  背景色：蓝色
    #     color: white;                文字颜色：白色
    #     border: none;                边框：无
    #     border-radius: 4px;          圆角：4px
    #     padding: 5px 12px;           内边距：上下5px，左右12px
    #     font-weight: bold;           字体：粗体
    #     font-size: 15px;             字体大小：15px
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #2980B9;  悬停背景色：深蓝
    #   }
    refresh_btn.setStyleSheet("""
        QPushButton { background-color: #3498DB; color: white; border: none; 
            border-radius: 4px; padding: 5px 12px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #2980B9; }
    """)
    # 刷新按钮点击信号：重新计算并刷新概率面板数据
    refresh_btn.clicked.connect(host._update_probability_panel)
    title_layout.addWidget(refresh_btn)
    
    layout.addLayout(title_layout)
    
    # 创建子选项卡：数字概率 和 生肖概率
    host.prob_sub_tabs = QTabWidget()
    host.prob_sub_tabs.setStyleSheet("QTabWidget::pane { border: 1px solid #DDDDDD; border-radius: 4px; }")
    
    # 数字概率选项卡
    num_tab = QWidget()
    num_layout = QVBoxLayout(num_tab)
    num_layout.setSpacing(4)
    num_layout.setContentsMargins(2, 4, 2, 2)
    
    host.probability_list = QListWidget()
    # 概率列表控件样式
    #   QListWidget {       列表整体样式
    #     background-color: #FFFFFF;  背景色：白色
    #     border: 1px solid #DDDDDD;  边框：1px 浅灰实线
    #     border-radius: 4px;         圆角：4px
    #   }
    #   QListWidget::item {  列表项样式
    #     padding: 8px;               内边距：8px
    #     border-bottom: 1px solid #EEEEEE;  底部分隔线：浅灰
    #     font-size: 15px;            字体大小：15px
    #   }
    #   QListWidget::item:selected {  选中项样式
    #     background-color: #D6EAF8;  选中背景色：浅蓝
    #     color: #000000;             选中文字颜色：黑色
    #   }
    host.probability_list.setStyleSheet("""
        QListWidget { background-color: #FFFFFF; border: 1px solid #DDDDDD; border-radius: 4px; }
        QListWidget::item { padding: 8px; border-bottom: 1px solid #EEEEEE; font-size: 15px; }
        QListWidget::item:selected { background-color: #D6EAF8; color: #000000; }
    """)
    # 概率列表双击信号：将双击的号码添加到数字选择面板
    host.probability_list.itemDoubleClicked.connect(host._on_probability_item_double_clicked)
    num_layout.addWidget(host.probability_list)
    
    host.prob_sub_tabs.addTab(num_tab, "数字概率")
    
    # 生肖概率选项卡（独立创建方法）
    _build_zodiac_probability_tab(host, host.prob_sub_tabs)
    
    layout.addWidget(host.prob_sub_tabs)
    
    # 统计信息行
    stats_layout = QHBoxLayout()
    host.prob_stats_label = QLabel("加载数据后显示统计")
    # 统计文字会随数据增长，必须允许换行：否则标签的 sizeHint 会把整个概率页
    # 的最小宽度顶到 1100px 以上，进而把「预测结果」所在右栏撑出窗口。
    host.prob_stats_label.setWordWrap(True)
    # 统计信息标签样式：15px字号，灰色文字，4px内边距
    host.prob_stats_label.setStyleSheet("color: #666666; font-size: 15px; padding: 4px;")
    stats_layout.addWidget(host.prob_stats_label)
    stats_layout.addStretch()
    
    # 快速操作按钮
    copy_top6_btn = QPushButton("复制前6")
    copy_top6_btn.setToolTip("复制概率最高的6个号码")
    # 复制前6按钮样式 - 绿色系（确认/操作类用绿色）
    #   QPushButton {       按钮常态样式
    #     background-color: #2ECC71;  背景色：绿色
    #     color: white;               文字颜色：白色
    #     border: none;               边框：无
    #     border-radius: 3px;         圆角：3px
    #     padding: 3px 8px;           内边距：上下3px，左右8px
    #     font-size: 15px;            字体大小：15px
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #27AE60;  悬停背景色：深绿
    #   }
    copy_top6_btn.setStyleSheet("""
        QPushButton { background-color: #2ECC71; color: white; border: none; 
            border-radius: 3px; padding: 3px 8px; font-size: 15px; }
        QPushButton:hover { background-color: #27AE60; }
    """)
    # 复制前6按钮点击信号：复制概率最高的6个号码到剪贴板
    copy_top6_btn.clicked.connect(host._on_copy_top_probability)
    stats_layout.addWidget(copy_top6_btn)
    
    layout.addLayout(stats_layout)
    
    # 初始化后自动刷新一次概率数据
    if hasattr(host, 'historical_data') and host.historical_data:
        host._update_probability_panel()
        host._update_zodiac_probability()
    
    return widget

def _build_zodiac_probability_tab(host, parent_tabs):
    """构建「生肖概率」子页：柱状/表格展示某一期数内各生肖出现次数与百分比。

    功能:
        创建「仅限特别码」复选框、生肖概率表格与统计标签，并加入父选项卡。
    参数:
        host: 主窗口实例。
        parent_tabs (QTabWidget): 「出现概率」子选项卡容器，本页会被 addTab 进去。
    返回:
        QWidget: 子页容器。
    注意/副作用:
        - 写 host.zodiac_special_only_cb、zodiac_prob_table、zodiac_prob_stats_label；
        - 「仅限特别码」勾选变化连接 host._update_zodiac_probability（立即重算）；
        - 表格列宽、字体与只读/整行选择行为在此初始化；
        - 数据刷新由 update_zodiac_probability 完成，本函数不读历史数据；
          生肖绑定缺失时由刷新函数用「?」或空字符串占位。
    """
    zodiac_tab = QWidget()
    zodiac_layout = QVBoxLayout(zodiac_tab)
    zodiac_layout.setSpacing(4)
    zodiac_layout.setContentsMargins(2, 4, 2, 2)
    
    # 配置区域：选项控件
    option_layout = QHBoxLayout()
    option_layout.setContentsMargins(0, 0, 0, 2)
    
    host.zodiac_special_only_cb = QCheckBox("仅限特别码")
    host.zodiac_special_only_cb.setToolTip("勾选后仅统计每期特别码(1个)的生肖归属，否则统计全部7个号码")
    host.zodiac_special_only_cb.setStyleSheet("font-size: 15px; color: #333;")
    # 仅限特别码复选框状态变化信号：切换统计范围（全部7个号码 或 仅特别码），刷新生肖概率
    host.zodiac_special_only_cb.toggled.connect(host._update_zodiac_probability)
    option_layout.addWidget(host.zodiac_special_only_cb)
    option_layout.addStretch()
    zodiac_layout.addLayout(option_layout)
    
    # 表格控件：生肖概率结果展示
    host.zodiac_prob_table = QTableWidget()
    # 生肖概率表格样式：白底，浅灰边框，4px圆角，交替行颜色，表头灰底粗体
    host.zodiac_prob_table.setStyleSheet("""
        QTableWidget { background-color: #FFFFFF; border: 1px solid #DDDDDD; border-radius: 4px; gridline-color: #EEEEEE; }
        QTableWidget::item { padding: 6px; font-size: 15px; }
        QTableWidget::item:selected { background-color: #D6EAF8; color: #000000; }
        QHeaderView::section { background-color: #F5F5F5; border: 1px solid #DDDDDD; padding: 6px; font-size: 15px; font-weight: bold; }
    """)
    host.zodiac_prob_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    host.zodiac_prob_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
    host.zodiac_prob_table.setAlternatingRowColors(True)
    host.zodiac_prob_table.verticalHeader().setVisible(False)
    zodiac_layout.addWidget(host.zodiac_prob_table)
    
    # 统计信息行
    host.zodiac_prob_stats_label = QLabel("加载数据后显示统计")
    # 生肖概率统计同样允许换行，避免长文本把本页最小宽度撑大
    host.zodiac_prob_stats_label.setWordWrap(True)
    host.zodiac_prob_stats_label.setStyleSheet("color: #666666; font-size: 15px; padding: 4px;")
    zodiac_layout.addWidget(host.zodiac_prob_stats_label)
    
    parent_tabs.addTab(zodiac_tab, "生肖概率")

def _build_calc_method_panel(host):
    """构建「计算规律」页：跳数/运算方式/筛选方式/TopN 等参数控件 + 结果区。

    功能:
        创建参数控件、四档字号控件、复制/导出按钮与富文本结果区，并恢复 INI 配置。
    参数:
        host: 主窗口实例。
    返回:
        QWidget: 面板容器。
    注意/副作用:
        - 参数控件的初值来自 host._calc_config（由 _apply_calc_panel_config 恢复）；
        - 写 host.calc_skip_spin、calc_op_combo、calc_filter_combo、calc_topn_spin、
          calc_result_label 等控件；
        - 各参数控件连接 _update_calc_method_panel 与 _save_ini_config（变更即重算/写盘）；
        - 点击「计算」后由 update_calc_method_panel 生成 HTML 并写入 calc_result_label；
        - 控件创建不依赖历史数据；数据不足时由计算函数显示提示文字。
    """
    widget = QWidget()
    widget.setObjectName("CalcMethodPanel")
    layout = QVBoxLayout(widget)
    layout.setSpacing(6)
    layout.setContentsMargins(5, 5, 5, 5)

    # 第一行：标题 + 跳数 + 运算方式
    row1 = QHBoxLayout()
    title = QLabel("加减规律分析")
    title.setObjectName("PanelTitle")
    row1.addWidget(title)
    row1.addStretch()

    skip_label = QLabel("跳数:")
    skip_label.setStyleSheet("font-size: 15px; color: #666;")
    row1.addWidget(skip_label)

    host.calc_skip_spin = QSpinBox()
    host.calc_skip_spin.setRange(0, 3)
    host.calc_skip_spin.setValue(0)
    host.calc_skip_spin.setMinimumWidth(50)
    host.calc_skip_spin.setToolTip("跳0=相邻期比较(需7期)\n跳1=隔1期比较(需14期)\n跳2=隔2期比较(需21期)\n跳3=隔3期比较(需28期)\n逐期滑动比较所有距离相同的期对")
    # 跳数选择框样式：2px内边距，15px字号
    # 跳数变化信号：刷新计算规律面板
    host.calc_skip_spin.valueChanged.connect(host._update_calc_method_panel)
    row1.addWidget(host.calc_skip_spin)

    op_label = QLabel("  运算:")
    op_label.setStyleSheet("font-size: 15px; color: #666;")
    row1.addWidget(op_label)

    host.calc_op_combo = QComboBox()
    host.calc_op_combo.addItems(["加法+减法", "仅加法", "仅减法"])
    host.calc_op_combo.setFixedWidth(110)
    host.calc_op_combo.setToolTip("加法+减法：同时计算加法和减法\n仅加法/仅减法：只算一种\n每一期的每个数字与另一期的每个数字逐一加减")
    # 运算方式下拉框样式：2px内边距，15px字号
    host.calc_op_combo.setStyleSheet("QComboBox { padding: 2px; font-size: 15px; }")
    # 运算方式变化信号：刷新计算规律面板
    host.calc_op_combo.currentIndexChanged.connect(host._update_calc_method_panel)
    row1.addWidget(host.calc_op_combo)

    layout.addLayout(row1)

    # 第二行：筛选 + TopN + 操作按钮
    row2 = QHBoxLayout()

    # 结果范围筛选
    filter_label = QLabel("筛选:")
    filter_label.setStyleSheet("font-size: 15px; color: #666;")
    row2.addWidget(filter_label)

    host.calc_filter_combo = QComboBox()
    host.calc_filter_combo.addItems(["全部结果", "仅1-49范围", "仅正数", "仅高频(≥3次)"])
    host.calc_filter_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
    host.calc_filter_combo.setMinimumWidth(110)
    host.calc_filter_combo.setToolTip("全部结果：显示所有计算值\n仅1-49范围：只显示1-49之间的值\n仅正数：只显示正数结果\n仅高频(≥3次)：只显示出现≥3次的结果")
    # 筛选方式下拉框样式：2px内边距，15px字号
    host.calc_filter_combo.setStyleSheet("QComboBox { padding: 2px; font-size: 15px; }")
    # 筛选方式变化信号：刷新计算规律面板
    host.calc_filter_combo.currentIndexChanged.connect(host._update_calc_method_panel)
    row2.addWidget(host.calc_filter_combo)

    # TopN显示数量
    topn_label = QLabel("  Top:")
    topn_label.setStyleSheet("font-size: 15px; color: #666;")
    row2.addWidget(topn_label)

    host.calc_topn_spin = QSpinBox()
    host.calc_topn_spin.setRange(3, 20)
    host.calc_topn_spin.setValue(5)
    host.calc_topn_spin.setMinimumWidth(50)
    host.calc_topn_spin.setToolTip("显示前N个高频结果")
    # TopN数字框样式：2px内边距，15px字号
    # TopN变化信号：刷新计算规律面板
    host.calc_topn_spin.valueChanged.connect(host._update_calc_method_panel)
    row2.addWidget(host.calc_topn_spin)

    layout.addLayout(row2)

    # 第三行：各部分字号设置
    row3 = QHBoxLayout()

    font_title = QLabel("字号:")
    font_title.setStyleSheet("font-size: 15px; color: #666; font-weight: bold;")
    row3.addWidget(font_title)

    # 运算结果字号
    r1_label = QLabel("结果")
    r1_label.setStyleSheet("font-size: 15px; color: #888;")
    row3.addWidget(r1_label)
    host.calc_result_font_spin = QSpinBox()
    host.calc_result_font_spin.setRange(10, 150)  # 字体上限150px
    host.calc_result_font_spin.setValue(20)  # 默认20px
    host.calc_result_font_spin.setMinimumWidth(50)
    host.calc_result_font_spin.setSuffix("px")
    # 运算结果字体大小输入框样式：2px内边距，15px字号

    # 结果字体大小变化信号：应用计算规律面板字号设置

    host.calc_result_font_spin.valueChanged.connect(host._apply_calc_panel_size)
    row3.addWidget(host.calc_result_font_spin)

    # 推荐号码字号
    r2_label = QLabel("推荐")
    r2_label.setStyleSheet("font-size: 15px; color: #888;")
    row3.addWidget(r2_label)
    host.calc_rec_font_spin = QSpinBox()
    host.calc_rec_font_spin.setRange(10, 150)  # 字体上限150px
    host.calc_rec_font_spin.setValue(20)  # 默认20px
    host.calc_rec_font_spin.setMinimumWidth(50)
    host.calc_rec_font_spin.setSuffix("px")
    # 推荐号码字体大小输入框样式：2px内边距，15px字号

    # 推荐字体大小变化信号：应用计算规律面板字号设置

    host.calc_rec_font_spin.valueChanged.connect(host._apply_calc_panel_size)
    row3.addWidget(host.calc_rec_font_spin)

    # 分析对比字号
    r3_label = QLabel("对比")
    r3_label.setStyleSheet("font-size: 15px; color: #888;")
    row3.addWidget(r3_label)
    host.calc_comp_font_spin = QSpinBox()
    host.calc_comp_font_spin.setRange(10, 150)  # 字体上限150px
    host.calc_comp_font_spin.setValue(20)  # 默认20px
    host.calc_comp_font_spin.setMinimumWidth(50)
    host.calc_comp_font_spin.setSuffix("px")
    # 对比字体大小输入框样式：2px内边距，15px字号

    # 对比字体大小变化信号：应用计算规律面板字号设置

    host.calc_comp_font_spin.valueChanged.connect(host._apply_calc_panel_size)
    row3.addWidget(host.calc_comp_font_spin)

    # 详细结果字号
    r4_label = QLabel("详细")
    r4_label.setStyleSheet("font-size: 15px; color: #888;")
    row3.addWidget(r4_label)
    host.calc_detail_font_spin = QSpinBox()
    host.calc_detail_font_spin.setRange(10, 150)  # 字体上限150px
    host.calc_detail_font_spin.setValue(20)  # 默认20px
    host.calc_detail_font_spin.setMinimumWidth(50)
    host.calc_detail_font_spin.setSuffix("px")
    # 详细结果字体大小输入框样式：2px内边距，15px字号

    # 详细结果字体大小变化信号：应用计算规律面板字号设置

    host.calc_detail_font_spin.valueChanged.connect(host._apply_calc_panel_size)
    row3.addWidget(host.calc_detail_font_spin)

    # 复制/导出结果按钮（连接主窗口事件处理方法）
    host.calc_copy_btn = QPushButton("复制")
    host.calc_copy_btn.setMinimumHeight(26)
    host.calc_copy_btn.setToolTip("复制计算规律分析结果到剪贴板")
    host.calc_copy_btn.clicked.connect(host._copy_calc_result)
    row3.addWidget(host.calc_copy_btn)

    host.calc_export_btn = QPushButton("导出")
    host.calc_export_btn.setMinimumHeight(26)
    host.calc_export_btn.setToolTip("把计算规律分析结果导出为TXT文件")
    host.calc_export_btn.clicked.connect(host._export_calc_result)
    row3.addWidget(host.calc_export_btn)

    row3.addStretch()
    layout.addLayout(row3)

    # 说明标签
    host.calc_info_label = QLabel("每期每个数字与另一期每个数字逐一加减，自动分析高频规律")
    host.calc_info_label.setStyleSheet("font-size: 15px; color: #888; padding: 2px 4px;")
    host.calc_info_label.setWordWrap(True)
    layout.addWidget(host.calc_info_label)

    # 结果显示区
    host.calc_scroll = QScrollArea()
    host.calc_scroll.setWidgetResizable(True)
    host.calc_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    # 计算结果滚动区域样式：无边框

    host.calc_scroll.setStyleSheet("QScrollArea { border: none; }")

    result_widget = QWidget()
    host.calc_result_layout = QVBoxLayout(result_widget)
    host.calc_result_layout.setSpacing(4)
    host.calc_result_layout.setContentsMargins(2, 2, 2, 2)

    host.calc_result_label = QLabel("等待分析...")
    host.calc_result_label.setWordWrap(True)
    host.calc_result_label.setTextFormat(Qt.TextFormat.RichText)
    # 计算结果标签样式：浅灰背景，4px圆角，8px内边距，浅灰边框

    host.calc_result_label.setStyleSheet(
        "font-size: 15px; color: #666; background-color: #FAFAFA; "
        "border-radius: 4px; padding: 8px; border: 1px solid #EEE;"
    )
    host.calc_result_layout.addWidget(host.calc_result_label)

    host.calc_scroll.setWidget(result_widget)
    layout.addWidget(host.calc_scroll)

    # 应用保存的配置到控件
    host._apply_calc_panel_config()
    # 连接控件变化信号，实时保存配置
    host.calc_skip_spin.valueChanged.connect(lambda: host._save_ini_config())
    # 运算方式变化信号：保存配置到INI

    host.calc_op_combo.currentIndexChanged.connect(lambda: host._save_ini_config())
    # 筛选方式变化信号：保存配置到INI

    host.calc_filter_combo.currentIndexChanged.connect(lambda: host._save_ini_config())
    # TopN变化信号：保存配置到INI

    host.calc_topn_spin.valueChanged.connect(lambda: host._save_ini_config())
    # 结果字体变化信号：保存配置到INI

    host.calc_result_font_spin.valueChanged.connect(lambda: host._save_ini_config())
    # 推荐字体变化信号：保存配置到INI

    host.calc_rec_font_spin.valueChanged.connect(lambda: host._save_ini_config())
    # 对比字体变化信号：保存配置到INI

    host.calc_comp_font_spin.valueChanged.connect(lambda: host._save_ini_config())
    # 详细字体变化信号：保存配置到INI

    host.calc_detail_font_spin.valueChanged.connect(lambda: host._save_ini_config())

    # 初始化自动刷新
    if hasattr(host, 'historical_data') and host.historical_data:
        host._update_calc_method_panel()

    return widget

def _build_wave_color_panel(host):
    """构建「波色预测」页：期数/模式/趋势期数/字号控件 + 结果区。

    功能:
        创建统计期数、预测模式、走势期数、三档字号、复制/导出按钮与三个富文本结果区。
    参数:
        host: 主窗口实例。
    返回:
        QWidget: 面板容器。
    注意/副作用:
        - 初值来自 host._wave_config（由 _apply_wave_panel_config 恢复）；
        - 模式用于选择红/蓝/绿波色的统计口径，「趋势期数」控制前后两段对比的分界点；
        - 写 host.wave_period_spin、wave_mode_combo、wave_trend_spin、wave_result_label、
          wave_trend_label、wave_trans_label 等控件；
        - 各控件连接 _update_wave_color_panel 与 _save_ini_config（变更即重算/写盘）；
        - 数据不足或无波色映射时由 update_wave_color_panel 显示占位提示。
    """
    widget = QWidget()
    widget.setObjectName("WaveColorPanel")
    layout = QVBoxLayout(widget)
    layout.setSpacing(6)
    layout.setContentsMargins(5, 5, 5, 5)

    # 第一行：标题 + 统计期数
    row1 = QHBoxLayout()
    title = QLabel("波色概率预测")
    title.setObjectName("PanelTitle")
    row1.addWidget(title)
    row1.addStretch()

    period_label = QLabel("统计期数:")
    period_label.setStyleSheet("font-size: 15px; color: #666;")
    row1.addWidget(period_label)

    host.wave_period_spin = QSpinBox()
    host.wave_period_spin.setRange(5, 500)
    host.wave_period_spin.setValue(30)
    host.wave_period_spin.setMinimumWidth(60)
    # 波色统计期数数字框样式：2px内边距，15px字号

    # 波色统计期数变化信号：刷新波色预测面板

    host.wave_period_spin.valueChanged.connect(host._update_wave_color_panel)
    row1.addWidget(host.wave_period_spin)

    layout.addLayout(row1)

    # 第二行：预测模式 + 走势期数
    row2 = QHBoxLayout()
    row2.setSpacing(2)

    mode_label = QLabel("预测模式:")
    mode_label.setStyleSheet("font-size: 15px; color: #666;")
    row2.addWidget(mode_label)

    host.wave_mode_combo = QComboBox()
    host.wave_mode_combo.addItems(["频率统计+号码分布", "仅频率统计", "仅号码分布", "转移概率加权"])
    host.wave_mode_combo.setFixedWidth(150)
    host.wave_mode_combo.setToolTip("频率统计+号码分布：综合两种算法\n仅频率统计：只看主波色出现次数\n仅号码分布：只看所有号码波色比例\n转移概率加权：用马尔可夫转移矩阵预测")
    # 波色模式下拉框样式：2px内边距，15px字号

    host.wave_mode_combo.setStyleSheet("QComboBox { padding: 2px; font-size: 15px; }")
    # 波色模式变化信号：刷新波色预测面板

    host.wave_mode_combo.currentIndexChanged.connect(host._update_wave_color_panel)
    row2.addWidget(host.wave_mode_combo)

    row2.addSpacing(8)

    trend_label = QLabel("走势期数:")
    trend_label.setStyleSheet("font-size: 15px; color: #666;")
    row2.addWidget(trend_label)

    host.wave_trend_spin = QSpinBox()
    host.wave_trend_spin.setRange(5, 300)
    host.wave_trend_spin.setValue(20)
    host.wave_trend_spin.setMinimumWidth(60)
    host.wave_trend_spin.setToolTip("走势显示的期数")
    # 波色趋势期数数字框样式：2px内边距，15px字号

    # 波色趋势期数变化信号：刷新波色预测面板

    host.wave_trend_spin.valueChanged.connect(host._update_wave_color_panel)
    row2.addWidget(host.wave_trend_spin)

    layout.addLayout(row2)

    # 第三行：各部分字号设置
    row3 = QHBoxLayout()

    font_title = QLabel("字号:")
    font_title.setStyleSheet("font-size: 15px; color: #666; font-weight: bold;")
    row3.addWidget(font_title)

    # 统计结果字号
    rf_label = QLabel("统计")
    rf_label.setStyleSheet("font-size: 15px; color: #888;")
    row3.addWidget(rf_label)
    host.wave_result_font_spin = QSpinBox()
    host.wave_result_font_spin.setRange(10, 150)  # 字体上限150px
    host.wave_result_font_spin.setValue(20)  # 默认20px
    host.wave_result_font_spin.setMinimumWidth(50)
    host.wave_result_font_spin.setSuffix("px")
    # 波色结果字体大小输入框样式：2px内边距，15px字号

    # 波色结果字体大小变化信号：应用波色面板字号设置

    host.wave_result_font_spin.valueChanged.connect(host._apply_wave_panel_size)
    row3.addWidget(host.wave_result_font_spin)

    # 走势字号
    tf_label = QLabel("走势")
    tf_label.setStyleSheet("font-size: 15px; color: #888;")
    row3.addWidget(tf_label)
    host.wave_trend_font_spin = QSpinBox()
    host.wave_trend_font_spin.setRange(10, 150)  # 字体上限150px
    host.wave_trend_font_spin.setValue(20)  # 默认20px
    host.wave_trend_font_spin.setMinimumWidth(50)
    host.wave_trend_font_spin.setSuffix("px")
    # 波色趋势字体大小输入框样式：2px内边距，15px字号

    # 波色趋势字体大小变化信号：应用波色面板字号设置

    host.wave_trend_font_spin.valueChanged.connect(host._apply_wave_panel_size)
    row3.addWidget(host.wave_trend_font_spin)

    # 转移概率字号
    xf_label = QLabel("转移")
    xf_label.setStyleSheet("font-size: 15px; color: #888;")
    row3.addWidget(xf_label)
    host.wave_trans_font_spin = QSpinBox()
    host.wave_trans_font_spin.setRange(10, 150)  # 字体上限150px
    host.wave_trans_font_spin.setValue(20)  # 默认20px
    host.wave_trans_font_spin.setMinimumWidth(50)
    host.wave_trans_font_spin.setSuffix("px")
    # 波色转移字体大小输入框样式：2px内边距，15px字号

    # 波色转移字体大小变化信号：应用波色面板字号设置

    host.wave_trans_font_spin.valueChanged.connect(host._apply_wave_panel_size)
    row3.addWidget(host.wave_trans_font_spin)

    # 复制/导出结果按钮（连接主窗口事件处理方法）
    host.wave_copy_btn = QPushButton("复制")
    host.wave_copy_btn.setMinimumHeight(26)
    host.wave_copy_btn.setToolTip("复制波色分析结果到剪贴板")
    host.wave_copy_btn.clicked.connect(host._copy_wave_result)
    row3.addWidget(host.wave_copy_btn)

    host.wave_export_btn = QPushButton("导出")
    host.wave_export_btn.setMinimumHeight(26)
    host.wave_export_btn.setToolTip("把波色分析结果导出为TXT文件")
    host.wave_export_btn.clicked.connect(host._export_wave_result)
    row3.addWidget(host.wave_export_btn)

    row3.addStretch()
    layout.addLayout(row3)

    # 说明标签
    host.wave_info_label = QLabel("选择预测模式和期数后点击「分析」，支持多种算法和走势对比")
    host.wave_info_label.setStyleSheet("font-size: 15px; color: #888; padding: 2px 4px;")
    host.wave_info_label.setWordWrap(True)
    layout.addWidget(host.wave_info_label)

    # 滚动区域包裹结果显示
    host.wave_scroll = QScrollArea()
    host.wave_scroll.setWidgetResizable(True)
    host.wave_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    # 波色结果滚动区域样式：无边框

    host.wave_scroll.setStyleSheet("QScrollArea { border: none; }")

    scroll_content = QWidget()
    wave_inner_layout = QVBoxLayout(scroll_content)
    wave_inner_layout.setSpacing(6)
    wave_inner_layout.setContentsMargins(2, 2, 2, 2)

    # 波色概率显示区
    host.wave_result_label = QLabel("等待分析...")
    host.wave_result_label.setWordWrap(True)
    host.wave_result_label.setAlignment(Qt.AlignmentFlag.AlignTop)
    host.wave_result_label.setTextFormat(Qt.TextFormat.RichText)
    # 波色结果标签样式：浅灰背景，4px圆角，8px内边距

    host.wave_result_label.setStyleSheet(
        "font-size: 15px; background-color: #FAFAFA; border-radius: 6px; "
        "padding: 10px; border: 1px solid #EEE;"
    )
    wave_inner_layout.addWidget(host.wave_result_label)

    # 历史波色走势
    trend_label = QLabel("近期波色走势：")
    trend_label.setStyleSheet("font-size: 15px; color: #555; font-weight: bold; padding: 4px 0;")
    wave_inner_layout.addWidget(trend_label)

    host.wave_trend_label = QLabel("")
    host.wave_trend_label.setWordWrap(True)
    host.wave_trend_label.setTextFormat(Qt.TextFormat.RichText)
    # 波色趋势标签样式：浅灰背景，4px圆角，8px内边距

    host.wave_trend_label.setStyleSheet(
        "font-size: 15px; background-color: #FFFFFF; border-radius: 4px; "
        "padding: 6px; border: 1px solid #E0E0E0;"
    )
    wave_inner_layout.addWidget(host.wave_trend_label)

    # 转移概率（上次波色→本次波色）
    trans_label = QLabel("波色转移概率：")
    trans_label.setStyleSheet("font-size: 15px; color: #555; font-weight: bold; padding: 4px 0;")
    wave_inner_layout.addWidget(trans_label)

    host.wave_trans_label = QLabel("")
    host.wave_trans_label.setWordWrap(True)
    host.wave_trans_label.setTextFormat(Qt.TextFormat.RichText)
    # 波色转移标签样式：浅灰背景，4px圆角，8px内边距

    host.wave_trans_label.setStyleSheet(
        "font-size: 15px; background-color: #FFFFFF; border-radius: 4px; "
        "padding: 6px; border: 1px solid #E0E0E0;"
    )
    wave_inner_layout.addWidget(host.wave_trans_label)

    wave_inner_layout.addStretch()
    host.wave_scroll.setWidget(scroll_content)
    layout.addWidget(host.wave_scroll)

    # 应用保存的配置到控件
    host._apply_wave_panel_config()
    # 连接控件变化信号，实时保存配置
    host.wave_period_spin.valueChanged.connect(lambda: host._save_ini_config())
    # 波色模式变化信号：保存配置到INI

    host.wave_mode_combo.currentIndexChanged.connect(lambda: host._save_ini_config())
    # 波色趋势期数变化信号：保存配置到INI

    host.wave_trend_spin.valueChanged.connect(lambda: host._save_ini_config())
    # 波色结果字体变化信号：保存配置到INI

    host.wave_result_font_spin.valueChanged.connect(lambda: host._save_ini_config())
    # 波色趋势字体变化信号：保存配置到INI

    host.wave_trend_font_spin.valueChanged.connect(lambda: host._save_ini_config())
    # 波色转移字体变化信号：保存配置到INI

    host.wave_trans_font_spin.valueChanged.connect(lambda: host._save_ini_config())

    # 初始化自动刷新
    if hasattr(host, 'historical_data') and host.historical_data:
        host._update_wave_color_panel()

    return widget

def update_probability_panel(host):
    """刷新「数字概率」页：统计窗口内每个号码的出现次数与百分比。

    功能:
        取最近 N 期正码与特别码，统计每个号码出现期数与百分比，并按排序方式写入列表。
    参数:
        host: 主窗口实例；数据来自 host.historical_data，窗口/排序来自概率页控件。
    返回:
        None。
    注意/副作用:
        - 概率 = 出现期数 / 统计期数（同号一期只计一次，口径与 lib 层一致）；
        - 结果写入列表控件与 host.probability_data，供复制/双击选号复用；
        - 历史数据为空时显示占位文字并清空列表；
        - 计算异常被捕获后以提示文字呈现，不中断其他子页。
    """
    if not hasattr(host, 'probability_list'):
        return
    if not host.historical_data or len(host.historical_data) == 0:
        host.probability_list.clear()
        if hasattr(host, 'prob_stats_label'):
            host.prob_stats_label.setText("暂无历史数据")
        return

    prob_scores = {}
    recent_counts = {}
    all_counts = {}
    stat_periods = 30
    total_draws = 0

    try:
        # 获取统计期数（从界面控件读取）
        if hasattr(host, 'prob_period_spin') and host.prob_period_spin:
            stat_periods = host.prob_period_spin.value()

        # 获取排序方式：0=概率降序 1=概率升序 2=号码升序 3=号码降序
        sort_mode = 0
        if hasattr(host, 'prob_sort_combo') and host.prob_sort_combo:
            sort_mode = host.prob_sort_combo.currentIndex()

        total_draws = len(host.historical_data)
        stat_periods = min(stat_periods, total_draws)

        # 统计全部数据中每个数字出现的次数
        for record in host.historical_data:
            numbers = record.get('numbers', [])
            for num in numbers:
                all_counts[num] = all_counts.get(num, 0) + 1

        # 统计近期（最近 N 期）出现次数
        recent_data = host.historical_data[-stat_periods:] if total_draws > 0 else []
        for record in recent_data:
            numbers = record.get('numbers', [])
            for num in numbers:
                recent_counts[num] = recent_counts.get(num, 0) + 1

        # 计算遗漏值（距离上次出现的期数）
        miss_counts = {}
        for num in range(1, 50):
            miss_counts[num] = stat_periods  # 默认最大遗漏
        for i, record in enumerate(reversed(recent_data)):
            numbers = record.get('numbers', [])
            for num in numbers:
                if miss_counts[num] == stat_periods:  # 只更新第一次遇到的（最近的）
                    miss_counts[num] = i

        # 计算综合概率得分
        for num in range(1, 50):
            all_prob = all_counts.get(num, 0) / total_draws if total_draws > 0 else 0
            recent_prob = recent_counts.get(num, 0) / stat_periods if stat_periods > 0 else 0
            miss_value = miss_counts.get(num, stat_periods) / stat_periods  # 遗漏越大分值越高
            prob_scores[num] = recent_prob * 0.5 + miss_value * 0.3 + all_prob * 0.2

        # 按选择的排序方式排序
        if sort_mode == 0:  # 概率降序
            sorted_nums = sorted(prob_scores.items(), key=lambda x: (-x[1], x[0]))
        elif sort_mode == 1:  # 概率升序
            sorted_nums = sorted(prob_scores.items(), key=lambda x: (x[1], x[0]))
        elif sort_mode == 2:  # 号码升序
            sorted_nums = sorted(prob_scores.items(), key=lambda x: x[0])
        else:  # 号码降序
            sorted_nums = sorted(prob_scores.items(), key=lambda x: -x[0])

        # 更新列表显示
        host.probability_list.clear()
        for rank, (num, score) in enumerate(sorted_nums, 1):
            colors = LotteryConfig.get_number_color(num)
            count = recent_counts.get(num, 0)
            all_count = all_counts.get(num, 0)
            miss = miss_counts.get(num, stat_periods)
            prob_percent = score * 100

            if sort_mode in [0, 1]:
                display_text = f"第{rank}名  数字 {str(num).zfill(2)}  近{stat_periods}期{count}次  共{all_count}次  遗漏{miss}期  概率 {prob_percent:.1f}%"
            else:
                display_text = f"数字 {str(num).zfill(2)}  近{stat_periods}期{count}次  共{all_count}次  遗漏{miss}期  概率 {prob_percent:.1f}%"

            item = QListWidgetItem(display_text)
            item.setForeground(QColor(colors['text']))
            item.setData(1000, num)  # 保存号码

            # 前三名加粗显示
            if sort_mode == 0 and rank <= 3:
                font = item.font()
                font.setBold(True)
                item.setFont(font)

            host.probability_list.addItem(item)

        # 更新统计信息
        if hasattr(host, 'prob_stats_label'):
            hot_nums = sorted([n for n, s in sorted(prob_scores.items(), key=lambda x: -x[1])[:10]])
            cold_nums = sorted([n for n, s in sorted(prob_scores.items(), key=lambda x: x[1])[:6]])
            hot_str = ' '.join(str(n).zfill(2) for n in hot_nums)
            cold_str = ' '.join(str(n).zfill(2) for n in cold_nums)
            host.prob_stats_label.setText(
                f"共 {total_draws}期 | 统计{stat_periods}期 | 热门: {hot_str} | 冷门: {cold_str}"
            )

        host._save_ini_config()

    except Exception as e:
        traceback.print_exc()
        if hasattr(host, 'prob_stats_label'):
            host.prob_stats_label.setText("计算失败: " + str(e))

    # 同步刷新生肖概率（与数字概率面板共用统计期数）
    host._update_zodiac_probability()


def on_probability_item_double_clicked(host, item):
    """双击概率列表项：切换到「数字选择」页并把该号码加入当前选中集合。

    功能:
        从列表项隐藏数据取号码，切到「数字选择」页，并在未选中时追加到当前选择集合。
    参数:
        host: 主窗口实例。
        item (QListWidgetItem): 被双击的列表项，控件文本由 update_probability_panel 写入。
    返回:
        None。
    注意/副作用:
        - 切换 host.tabs 当前页并调用 number_panel.set_selected_numbers（会刷新选中球）；
        - 列表项为空或隐藏数据不是 1~49 号码时直接 return，不弹窗、不改变选择；
        - 目标页或选择控件缺失时静默跳过（跨页控件由主窗口提供）。
    """
    num = item.data(1000)
    if num and hasattr(host, 'number_panel') and host.number_panel:
        if hasattr(host, 'tabs'):
            for i in range(host.tabs.count()):
                if host.tabs.tabText(i) == "数字选择":
                    host.tabs.setCurrentIndex(i)
                    break
        if num not in host.number_panel.selected_numbers:
            host.number_panel.set_selected_numbers(host.number_panel.selected_numbers + [num])


def copy_top_probability(host):
    """把概率最高的 6 个号码复制到系统剪贴板。

    功能:
        从概率列表前 6 项取号码，排序后以两位空格分隔写入剪贴板，并在状态栏提示。
    参数:
        host: 主窗口实例；读取 host.probability_data 或列表控件内容。
    返回:
        None。
    注意/副作用:
        - 写系统剪贴板，并通过 host.statusBar().showMessage 提示；
        - 无概率数据时直接返回，不写入剪贴板；
        - 剪贴板不可用（远程桌面等）时异常由 Qt 层忽略，不影响界面。
    """
    if not hasattr(host, 'probability_list') or host.probability_list.count() == 0:
        return
    top_nums = []
    for i in range(min(6, host.probability_list.count())):
        num = host.probability_list.item(i).data(1000)
        if num:
            top_nums.append(num)
    if top_nums:
        top_nums.sort()
        text = ' '.join(str(n).zfill(2) for n in top_nums)
        QApplication.clipboard().setText(text)
        if hasattr(host, 'statusBar'):
            host.statusBar().showMessage(f"已复制前{len(top_nums)}个高概率号码: {text}")


def update_zodiac_probability(host):
    """刷新「生肖概率」页：按生肖聚合出现次数并换算百分比。

    功能:
        按统计期数取最近数据，按生肖聚合出现次数并换算为百分比写入表格。
    参数:
        host: 主窗口实例；数据来自 host.historical_data。
    返回:
        None。
    注意/副作用:
        - 生肖归属由 LotteryConfig 的生肖映射给出；(num-1)%12 仅用于无绑定时兜底；
        - 「仅统计特别码」勾选时只统计每期特别码；
        - 写 zodiac_prob_table 与 zodiac_prob_stats_label；
        - 生肖绑定文件缺失时用默认顺序映射；数据不足时显示占位提示。
    """
    if not hasattr(host, 'zodiac_prob_table') or host.zodiac_prob_table is None:
        return

    table = host.zodiac_prob_table
    table.setRowCount(0)

    if not host.historical_data or len(host.historical_data) == 0:
        if hasattr(host, 'zodiac_prob_stats_label'):
            host.zodiac_prob_stats_label.setText("暂无历史数据")
        return

    try:
        if hasattr(host, 'prob_period_spin') and host.prob_period_spin:
            stat_periods = host.prob_period_spin.value()
        else:
            stat_periods = 30
        stat_periods = min(stat_periods, len(host.historical_data))
        data_to_use = host.historical_data[-stat_periods:]

        # 构建 生肖 → 包含数字列表 映射
        zodiac_to_nums = {}
        for num in range(1, 50):
            zodiac = LotteryConfig.NUMBER_NAMES.get(num, "未知")
            zodiac_to_nums.setdefault(zodiac, []).append(num)

        # 统计每个生肖的出现次数
        zodiac_counts = {}
        special_only = (hasattr(host, 'zodiac_special_only_cb') and host.zodiac_special_only_cb.isChecked())

        for record in data_to_use:
            if special_only:
                special = record.get('special', None)
                if special is not None and isinstance(special, int) and 1 <= special <= 49:
                    zodiac = LotteryConfig.NUMBER_NAMES.get(special, "未知")
                    zodiac_counts[zodiac] = zodiac_counts.get(zodiac, 0) + 1
            else:
                numbers = record.get('numbers', [])
                for num in numbers:
                    zodiac = LotteryConfig.NUMBER_NAMES.get(num, "未知")
                    zodiac_counts[zodiac] = zodiac_counts.get(zodiac, 0) + 1
                special = record.get('special', None)
                if special is not None and isinstance(special, int) and 1 <= special <= 49:
                    zodiac = LotteryConfig.NUMBER_NAMES.get(special, "未知")
                    zodiac_counts[zodiac] = zodiac_counts.get(zodiac, 0) + 1

        total_numbers = stat_periods if special_only else stat_periods * 7

        # 计算百分比并排序
        zodiac_probs = {}
        for zodiac in zodiac_to_nums:
            count = zodiac_counts.get(zodiac, 0)
            zodiac_probs[zodiac] = (count / total_numbers * 100) if total_numbers > 0 else 0
        sorted_zodiacs = sorted(zodiac_probs.items(), key=lambda x: -x[1])

        # 生肖颜色配置
        zodiac_colors = {
            "龙": "#FF6B6B", "兔": "#FF9FF3", "虎": "#FECA57", "牛": "#48DBFB",
            "鼠": "#FF9F43", "猪": "#54A0FF", "狗": "#5F27CD", "鸡": "#01A3A4",
            "猴": "#F368E0", "羊": "#2ED573", "马": "#1E90FF", "蛇": "#EE5A24"
        }

        # 写入表格
        table.setRowCount(len(sorted_zodiacs))
        table.setColumnCount(5)
        table.setHorizontalHeaderLabels(["排名", "生肖", "出现概率", "出现次数", "包含号码"])
        # 末列用显式 Stretch 模式：只开 setStretchLastSection(True) 时，末列会停留在
        # 上一布局算出的绝对宽度（实测 720px），1180 档切到「生肖概率」子页会冒出
        # 横向滚动条（50+60+100+100+720=1030 > 视口 800）。Stretch 模式保证末列
        # 始终等于剩余宽度，与窗口大小无关。
        table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        table.horizontalHeader().setStretchLastSection(False)
        table.setColumnWidth(0, 50)
        table.setColumnWidth(1, 60)
        table.setColumnWidth(2, 100)
        table.setColumnWidth(3, 100)

        for rank, (zodiac, prob_percent) in enumerate(sorted_zodiacs, 1):
            count = zodiac_counts.get(zodiac, 0)
            nums = zodiac_to_nums.get(zodiac, [])
            num_str = ' '.join(str(n).zfill(2) for n in nums)
            color = zodiac_colors.get(zodiac, "#333333")
            for col, text in enumerate([str(rank), zodiac, f"{prob_percent:.2f}%",
                                         f"{count}/{total_numbers}", num_str]):
                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if col == 1:  # 生肖名称列用颜色
                    item.setForeground(QColor(color))
                    if rank <= 3:
                        font = item.font()
                        font.setBold(True)
                        item.setFont(font)
                table.setItem(rank - 1, col, item)
            table.setRowHeight(rank - 1, 36)

        if hasattr(host, 'zodiac_prob_stats_label'):
            mode_text = "仅特别码" if special_only else "全部号码"
            host.zodiac_prob_stats_label.setText(
                f"统计 {stat_periods} 期 | {mode_text} | 共 {total_numbers} 个号码 | "
                f"最高: {sorted_zodiacs[0][0]} {sorted_zodiacs[0][1]:.2f}%"
            )

    except Exception as e:
        traceback.print_exc()
        if hasattr(host, 'zodiac_prob_stats_label'):
            host.zodiac_prob_stats_label.setText(f"计算失败: {e}")


def apply_prediction_col_widths(host):
    """应用 INI 中保存的「预测记录」表格列宽，并监听用户拖动写回。

    功能:
        按保存值逐列设置列宽，并连接 sectionResized 到 INI 保存。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 只在列数匹配时逐列 setColumnWidth；随后连接 sectionResized，
          由 _save_ini_config 统一落盘，避免每次拖动都写文件；
        - 表头不存在或列数与保存值不一致时跳过该列，不影响其余列；
        - INI 中没有列宽记录时保留控件默认宽度。
    """
    if not hasattr(host, 'prediction_history_table'):
        return
    _table = host.prediction_history_table
    _col_count = _table.columnCount()
    # 时间列至少要放得下完整时间戳；末列由 setStretchLastSection 占满，
    # 不能用 INI 中上一窗口的绝对宽度回灌，否则 1180 下会撑出横向滚动条。
    _time_need = _table.fontMetrics().horizontalAdvance('2026-11-02 19:09:52') + 16
    if hasattr(host, '_prediction_col_widths') and host._prediction_col_widths:
        for i, width in enumerate(host._prediction_col_widths):
            if not width or i >= _col_count or i == _col_count - 1:
                continue
            if i == 0:
                width = max(width, _time_need)
            try:
                _table.setColumnWidth(i, width)
            except Exception:
                pass
    # 连接列宽变化信号（只在首次连接，避免字号变更后重复调用导致槽函数叠加）
    if not getattr(host, '_prediction_col_widths_connected', False):
        host.prediction_history_table.horizontalHeader().sectionResized.connect(
            lambda logicalIndex, oldSize, newSize: host._save_ini_config()
        )
        host._prediction_col_widths_connected = True


def apply_prediction_ball_size(host):
    """按 host._prediction_ball_size 应用预测结果区号码球尺寸与字号。

    功能:
        逐个更新预测结果区号码球的球径、数字字号、标签字号与加号字号，并同步角控件。
    参数:
        host: 主窗口实例；读取 width / height / font / label_font /
            label_width / label_height / plus_size。
    返回:
        None。
    注意/副作用:
        - 逐个更新号码球（数字字号、标签字号、标签背景宽高）；
        - 加号标签用正则只替换 font-size，保留颜色等其他样式；
        - 同步字号到角控件 spinbox（blockSignals 防递归）；
        - 末尾调用 refresh_number_strategy_styles，使文本/卡片视图跟随同一份字号；
        - 布局中非 NumberBallWithZodiac 的控件（如加号 QLabel）按类型跳过；
        - 控件已被 deleteLater 时 RuntimeError 由外层刷新流程吞掉。
    """
    # 号码预测列表与号码球共用同一组角控件设置：
    # 「数字 px」作用于正码/特别码，「文字 px」作用于策略名/加号/说明区，
    # 「尺寸」里的高度决定行高。这里先刷新列表，再判断号码球布局是否存在。
    if hasattr(host, 'number_pred_text'):
        refresh_number_strategy_styles(host)
    if not hasattr(host, 'prediction_number_layout'):
        return
    w = host._prediction_ball_size.get('width', 80)
    h = host._prediction_ball_size.get('height', 60)
    f = host._prediction_ball_size.get('font', 20)
    plus_size = host._prediction_ball_size.get('plus_size', 24)
    # 生肖/五行标签字体使用 ball_label_font_size（由字号spinbox控制），而非 _prediction_ball_size['label_font']
    label_f = host.ball_label_font_size
    # 生肖/五行标签背景宽高（0=自适应不固定）
    label_w = host._prediction_ball_size.get('label_width', 0)
    label_h = host._prediction_ball_size.get('label_height', 0)

    # 遍历所有号码球并更新尺寸
    for i in range(host.prediction_number_layout.count()):
        item = host.prediction_number_layout.itemAt(i)
        if item and item.widget():
            widget = item.widget()
            # NumberBallWithZodiac控件
            if hasattr(widget, 'set_ball_size') and hasattr(widget, 'set_font_size'):
                widget.set_ball_size(width=w, height=h, font_size=f)
                widget.set_font_size(label_f)
                # 应用生肖/五行标签背景宽高
                if hasattr(widget, 'set_label_size'):
                    widget.set_label_size(width=label_w, height=label_h)
            # 加号标签（只更新字体大小，保持原有颜色）
            elif isinstance(widget, QLabel) and widget.text() == '+':
                old_style = widget.styleSheet()
                # 正则替换加号标签的 font-size，保留颜色等其他样式属性不变
                new_style = re.sub(r'font-size:\s*\d+px', f'font-size: {plus_size}px', old_style)
                # 应用更新后的样式到加号标签（仅字号变化）
                widget.setStyleSheet(new_style)


def apply_legend_font_size(host):
    """应用颜色图例字号：说明文字与号码数字分两档。

    功能:
        用正则把图例标签 QSS 中的 font-size 改为当前两档字号，并强制 15px 下限。
    参数:
        host: 主窗口实例；读取 host._legend_font_size['label'] / ['nums']。
    返回:
        None。
    注意/副作用:
        - 用正则只替换 QSS 里的 font-size，保留颜色、边距等其余属性；
        - 两档默认值均为 15px，且无论来源如何（含历史 INI=9）都强制抬到 15px 下限；
        - 写各图例标签的 setStyleSheet；host 没有 _legend_labels 时直接返回；列表里的 None 项跳过。
    """
    # 数字选择面板的图例
    if hasattr(host, '_legend_labels'):
        # 下限钳制：INI 可能存过 9px，启动首帧也不能低于全局 15px 下限
        label_size = max(15, int(host._legend_font_size.get('label', 15)))
        nums_size = max(15, int(host._legend_font_size.get('nums', 15)))
        for label in host._legend_labels.get('labels', []):
            if label:
                old_style = label.styleSheet()
                # 正则替换图例文字标签的 font-size 为目标字号，保留颜色等其余样式
                new_style = re.sub(r'font-size:\s*\d+px', f'font-size: {label_size}px', old_style)
                # 应用更新后的样式到图例文字标签（如"五行："等说明文字）
                label.setStyleSheet(new_style)
        for label in host._legend_labels.get('nums', []):
            if label:
                old_style = label.styleSheet()
                # 正则替换图例数字标签的 font-size 为目标字号，保留颜色等其余样式
                new_style = re.sub(r'font-size:\s*\d+px', f'font-size: {nums_size}px', old_style)
                # 应用更新后的样式到图例数字标签（如号码范围展示）
                label.setStyleSheet(new_style)


def change_legend_font(host, direction):
    """放大/缩小颜色图例字号并立即应用、写回 INI。

    功能:
        按方向各调整两档字号 1px，钳制范围后写回 host 并调用应用函数与 INI 保存。
    参数:
        host: 主窗口实例。
        direction (int): 1=放大，-1=缩小，步长固定 1px。
    返回:
        None。
    注意/副作用:
        - 两档字号独立记忆；说明文字限制在 15~24px，号码数字限制在 15~22px；
          下限统一为 15px，避免历史 INI 或连续缩小把图例压到不可读的 9px；
        - 写 host._legend_font_size，调用 apply_legend_font_size 与 host._save_ini_config；
        - host._legend_font_size 缺键时按 15px 兜底，不抛异常。
    """
    step = 1
    label_size = host._legend_font_size.get('label', 15) + direction * step
    nums_size = host._legend_font_size.get('nums', 15) + direction * step
    # 限制范围：说明文字 15~24px，号码数字 15~22px；
    # 下限统一 15px（原先 9px 会让图例数字在 1180×720 下不可读）
    label_size = max(15, min(24, label_size))
    nums_size = max(15, min(22, nums_size))

    host._legend_font_size['label'] = label_size
    host._legend_font_size['nums'] = nums_size

    # 应用到UI
    host._apply_legend_font_size()

    # 保存到INI
    host._save_ini_config()
    host.statusBar().showMessage(f"图例字体已调整为 {label_size}px")


def apply_legend_theme_colors(host):
    """按当前主题给颜色图例三组标签/号码重新着色（只改颜色，不动字号与布局）。

    功能:
        按亮/暗主题选择红蓝绿三色，并用正则替换图例标签 QSS 中的 color 声明。
    参数:
        host: 主窗口实例；读取 is_dark_mode 与 _legend_labels。
    返回:
        None。
    注意/副作用:
        - 亮色主题保持原有纯红/纯蓝/纯绿；暗色主题改用同色系亮色变体，
          以暗底 #1E1E2E 计算对比度（WCAG 相对亮度公式）：
          红 #FF6B6B ≈ 5.92:1、蓝 #89B4FA ≈ 7.79:1、绿 #A6E3A1 ≈ 11.0:1；
        - 只替换 `color` 声明，避免误伤 background-color 等属性；
        - 字号不在此函数处理，仍由图例字号配置独立控制；
        - 图例控件不存在时直接返回；某条样式没有 color 声明时保持原样。
    """
    labels = getattr(host, '_legend_labels', None)
    if not labels:
        return
    dark = bool(getattr(host, 'is_dark_mode', False))
    # 顺序与图例构建一致：红、蓝、绿
    colors = ('#FF6B6B', '#89B4FA', '#A6E3A1') if dark else ('#FF0000', '#0000FF', '#008000')
    for key in ('labels', 'nums'):
        for label, color in zip(labels.get(key, []) or [], colors):
            if label is None:
                continue
            style = label.styleSheet()
            # 只替换 color 声明，避免误伤 background-color 等属性
            new_style = re.sub(r'(?<![-\w])color:\s*#[0-9A-Fa-f]{3,8}',
                               'color: %s' % color, style)
            if new_style != style:
                label.setStyleSheet(new_style)


def apply_detail_label_size(host):
    """应用生肖/五行详情标签的字号与内边距。

    功能:
        用正则把两个详情标签 QSS 中的 font-size 与 padding 改为当前配置值。
    参数:
        host: 主窗口实例；读取 host._detail_label_size['font'] / ['padding']。
    返回:
        None。
    注意/副作用:
        - 正则替换 font-size 与 padding，其余样式（颜色、圆角、背景）保持不变；
        - 与角控件字号分开记忆，互不影响；
        - 标签不存在（尚未创建或已销毁）时用 hasattr 跳过。
    """
    font_size = host._detail_label_size.get('font', 15)  # 默认值即 15px，避免出现小字号
    padding = host._detail_label_size.get('padding', 8)

    # 生肖详情标签
    if hasattr(host, 'zodiac_detail_label') and host.zodiac_detail_label:
        old_style = host.zodiac_detail_label.styleSheet()
        # 正则替换字号和内边距，保留颜色、圆角等其他样式属性不变
        new_style = re.sub(r'font-size:\s*\d+px', f'font-size: {font_size}px', old_style)
        new_style = re.sub(r'padding:\s*\d+px', f'padding: {padding}px', new_style)
        # 应用更新后的样式到生肖详情标签（动态字号 + 动态内边距）
        host.zodiac_detail_label.setStyleSheet(new_style)

    # 五行详情标签
    if hasattr(host, 'element_detail_label') and host.element_detail_label:
        old_style = host.element_detail_label.styleSheet()
        # 正则替换字号和内边距，保留颜色、圆角等其他样式属性不变
        new_style = re.sub(r'font-size:\s*\d+px', f'font-size: {font_size}px', old_style)
        new_style = re.sub(r'padding:\s*\d+px', f'padding: {padding}px', new_style)
        # 应用更新后的样式到五行详情标签（动态字号 + 动态内边距）
        host.element_detail_label.setStyleSheet(new_style)


def change_detail_label_font(host, direction):
    """调整详情标签字号与内边距（背景尺寸随之变化）。

    功能:
        字号与内边距各按方向增减 1，钳制范围后写回配置、应用并保存 INI。
    参数:
        host: 主窗口实例。
        direction (int): 1=放大，-1=缩小，两者步长均为 1。
    返回:
        None。
    注意/副作用:
        - 字号夹在 15~24px、内边距夹在 4~20px；缺键时按 15px / 8px 兜底后
          立即被 clamp 抬到 15px，保证不出现小于 15px 的文字；
        - 写 host._detail_label_size，调用 apply_detail_label_size 与 host._save_ini_config，
          并在状态栏提示新字号。
    """
    step = 1
    font_size = host._detail_label_size.get('font', 15) + direction * step
    padding = host._detail_label_size.get('padding', 8) + direction * step
    # 限制范围
    font_size = max(15, min(24, font_size))
    padding = max(4, min(20, padding))

    host._detail_label_size['font'] = font_size
    host._detail_label_size['padding'] = padding

    # 应用到UI
    host._apply_detail_label_size()

    # 保存到INI
    host._save_ini_config()
    host.statusBar().showMessage(f"详情标签字体已调整为 {font_size}px")


def on_pred_num_font_changed(host, size):
    """角控件「数字 px」变化：更新号码球数字字号并记忆。

    功能:
        写入 _prediction_ball_size['font'] 与结果区字号比例，立即应用并保存 INI。
    参数:
        host: 主窗口实例。
        size (int): QSpinBox 传入的新字号（控件本身限制 15~150）。
    返回:
        None。
    注意/副作用:
        - 只改 _prediction_ball_size['font'] 与本页号码球数字，不改标签字号；
        - 随后写 INI 并刷新七策略文本/卡片，两种视图共用同一字号；
        - 写 host._area_font_scales['result'] = size/18.0，供详情区按比例缩放；
        - 旧结果控件已销毁时由号码球遍历中的 RuntimeError 保护跳过。
    """
    host._prediction_ball_size['font'] = size
    host._save_ini_config()
    host._apply_prediction_ball_size()
    host._area_font_scales['result'] = size / 18.0


def on_pred_text_font_changed(host, size):
    """角控件「文字 px」变化：更新生肖/五行标签与说明区字号并记忆。

    功能:
        同步 host.ball_label_font_size 与 _prediction_ball_size['label_font']，
        刷新结果区标签与七策略说明区字号，并保存 INI。
    参数:
        host: 主窗口实例。
        size (int): 新字号（控件限制 15~150）。
    返回:
        None。
    注意/副作用:
        - 同时写入 host.ball_label_font_size 与 _prediction_ball_size['label_font']；
        - 调用 update_prediction_balls_font_size 与 refresh_number_strategy_styles，
          保证结果区、七策略说明区字号一致；
        - 调用 host._save_ini_config 写盘；
        - 控件缺失或已销毁时对应分支静默跳过。
    """
    host.ball_label_font_size = size
    host._prediction_ball_size['label_font'] = size
    host._save_ini_config()
    # 更新当前预测结果区的所有号码球标签
    host._update_prediction_balls_font_size()
    # 「号码预测」列表的策略名/加号/说明区跟随「文字 px」
    refresh_number_strategy_styles(host)


def update_prediction_balls_font_size(host):
    """遍历预测结果区，把号码球的生肖/五行标签字号更新为当前文字字号。

    功能:
        遍历 prediction_number_layout，对每个带 set_font_size 的球控件更新标签字体。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 只调用 set_font_size，不改变球径与号码数字字号；
        - 布局项不是 NumberBallWithZodiac 时跳过；
        - 控件已销毁时 RuntimeError 被内部捕获，不影响其他号码球；
        - 布局不存在时直接返回。
    """
    if not hasattr(host, 'prediction_number_layout'):
        return
    for i in range(host.prediction_number_layout.count()):
        item = host.prediction_number_layout.itemAt(i)
        if item and item.widget():
            widget = item.widget()
            if hasattr(widget, 'set_font_size') and hasattr(widget, 'zodiac_label'):
                widget.set_font_size(host.ball_label_font_size)


def apply_probability_config(host):
    """把 INI 中的概率面板配置（统计期数、排序方式）恢复到控件。

    功能:
        读取 host._prob_config，在 blockSignals 下写回期数输入框与排序下拉。
    参数:
        host: 主窗口实例；读取 host._prob_config。
    返回:
        None。
    注意/副作用:
        - 全程 blockSignals，避免恢复过程触发 update_probability_panel 造成重复计算与写盘；
        - 恢复完成后不主动刷新，由主窗口装载时序统一调用；
        - 键缺失时保留控件默认值（30 期、概率降序）；类型非法时跳过该项。
    """
    if not hasattr(host, '_prob_config'):
        host._prob_config = {}

    # 应用统计期数
    if hasattr(host, 'prob_period_spin') and host.prob_period_spin:
        period = host._prob_config.get('period', 30)
        host.prob_period_spin.blockSignals(True)
        host.prob_period_spin.setValue(period)
        host.prob_period_spin.blockSignals(False)

    # 应用排序方式
    if hasattr(host, 'prob_sort_combo') and host.prob_sort_combo:
        sort_mode = host._prob_config.get('sort_mode', 0)
        host.prob_sort_combo.blockSignals(True)
        host.prob_sort_combo.setCurrentIndex(sort_mode)
        host.prob_sort_combo.blockSignals(False)


def apply_calc_panel_config(host):
    """把 INI 中的计算规律面板配置恢复到各控件。

    功能:
        读取 host._calc_config，在 blockSignals 下恢复跳数、运算、筛选、TopN 与四档字号。
    参数:
        host: 主窗口实例；读取 host._calc_config。
    返回:
        None。
    注意/副作用:
        - blockSignals 期间 setValue/setCurrentIndex，避免恢复时触发计算；
        - 恢复只针对已存在的控件，新增控件缺键时保留默认值；
        - 旧配置的运算方式索引 >2 时回退为 0（原 5 项已收敛为 3 项）；
        - 某项键缺失或越界时跳过该项，不影响其余控件。
    """
    if not hasattr(host, '_calc_config'):
        host._calc_config = {}

    # 跳数（0-3）：控制期对间隔，0=相邻期，3=隔3期
    if hasattr(host, 'calc_skip_spin') and host.calc_skip_spin:
        val = host._calc_config.get('skip', 0)
        host.calc_skip_spin.blockSignals(True)
        host.calc_skip_spin.setValue(val)
        host.calc_skip_spin.blockSignals(False)
    # 运算方式（0=加法+减法，1=仅加法，2=仅减法）
    if hasattr(host, 'calc_op_combo') and host.calc_op_combo:
        val = host._calc_config.get('op', 0)
        if val > 2:  # 兼容旧配置（原有5项，现仅3项）
            val = 0
        host.calc_op_combo.blockSignals(True)
        host.calc_op_combo.setCurrentIndex(val)
        host.calc_op_combo.blockSignals(False)
    # 筛选模式（0=全部，1=仅1-49，2=仅正数，3=仅高频≥3次）
    if hasattr(host, 'calc_filter_combo') and host.calc_filter_combo:
        val = host._calc_config.get('filter', 0)
        host.calc_filter_combo.blockSignals(True)
        host.calc_filter_combo.setCurrentIndex(val)
        host.calc_filter_combo.blockSignals(False)
    # TopN显示数量（3-20）
    if hasattr(host, 'calc_topn_spin') and host.calc_topn_spin:
        val = host._calc_config.get('topn', 5)
        host.calc_topn_spin.blockSignals(True)
        host.calc_topn_spin.setValue(val)
        host.calc_topn_spin.blockSignals(False)
    # 运算结果字号（10-150px，默认20px）
    if hasattr(host, 'calc_result_font_spin') and host.calc_result_font_spin:
        val = host._calc_config.get('result_font', 20)
        host.calc_result_font_spin.blockSignals(True)
        host.calc_result_font_spin.setValue(val)
        host.calc_result_font_spin.blockSignals(False)
    # 推荐号码字号（10-150px，默认20px）
    if hasattr(host, 'calc_rec_font_spin') and host.calc_rec_font_spin:
        val = host._calc_config.get('rec_font', 20)
        host.calc_rec_font_spin.blockSignals(True)
        host.calc_rec_font_spin.setValue(val)
        host.calc_rec_font_spin.blockSignals(False)
    # 分析对比字号（10-150px，默认20px）
    if hasattr(host, 'calc_comp_font_spin') and host.calc_comp_font_spin:
        val = host._calc_config.get('comp_font', 20)
        host.calc_comp_font_spin.blockSignals(True)
        host.calc_comp_font_spin.setValue(val)
        host.calc_comp_font_spin.blockSignals(False)
    # 详细结果字号（10-150px，默认20px）
    if hasattr(host, 'calc_detail_font_spin') and host.calc_detail_font_spin:
        val = host._calc_config.get('detail_font', 20)
        host.calc_detail_font_spin.blockSignals(True)
        host.calc_detail_font_spin.setValue(val)
        host.calc_detail_font_spin.blockSignals(False)


def apply_wave_panel_config(host):
    """把 INI 中的波色面板配置恢复到各控件。

    功能:
        读取 host._wave_config，在 blockSignals 下恢复期数、模式、走势期数与三档字号。
    参数:
        host: 主窗口实例；读取 host._wave_config。
    返回:
        None。
    注意/副作用:
        - 与 apply_calc_panel_config 相同：blockSignals 恢复，避免触发重算与写盘；
        - 只写已存在控件；键缺失或值越界时跳过，保留控件默认值。
    """
    if not hasattr(host, '_wave_config'):
        host._wave_config = {}

    # 统计期数（5-500，默认30）
    if hasattr(host, 'wave_period_spin') and host.wave_period_spin:
        val = host._wave_config.get('period', 30)
        host.wave_period_spin.blockSignals(True)
        host.wave_period_spin.setValue(val)
        host.wave_period_spin.blockSignals(False)
    # 显示模式（0=全部，1=前段，2=后段）
    if hasattr(host, 'wave_mode_combo') and host.wave_mode_combo:
        val = host._wave_config.get('mode', 0)
        host.wave_mode_combo.blockSignals(True)
        host.wave_mode_combo.setCurrentIndex(val)
        host.wave_mode_combo.blockSignals(False)
    # 走势期数（5-300，默认20）
    if hasattr(host, 'wave_trend_spin') and host.wave_trend_spin:
        val = host._wave_config.get('trend', 20)
        host.wave_trend_spin.blockSignals(True)
        host.wave_trend_spin.setValue(val)
        host.wave_trend_spin.blockSignals(False)
    # 波色统计结果字号（10-150px，默认20px）
    if hasattr(host, 'wave_result_font_spin') and host.wave_result_font_spin:
        val = host._wave_config.get('result_font', 20)
        host.wave_result_font_spin.blockSignals(True)
        host.wave_result_font_spin.setValue(val)
        host.wave_result_font_spin.blockSignals(False)
    # 走势图字号（10-150px，默认20px）
    if hasattr(host, 'wave_trend_font_spin') and host.wave_trend_font_spin:
        val = host._wave_config.get('trend_font', 20)
        host.wave_trend_font_spin.blockSignals(True)
        host.wave_trend_font_spin.setValue(val)
        host.wave_trend_font_spin.blockSignals(False)
    # 转移概率字号（10-150px，默认20px）
    if hasattr(host, 'wave_trans_font_spin') and host.wave_trans_font_spin:
        val = host._wave_config.get('trans_font', 20)
        host.wave_trans_font_spin.blockSignals(True)
        host.wave_trans_font_spin.setValue(val)
        host.wave_trans_font_spin.blockSignals(False)


def apply_calc_panel_size(host):
    """应用计算规律页的「结果/推荐/对比/详细」四档字号并重新生成 HTML。

    功能:
        读取四档字号设置结果区与信息栏 QSS，然后调用重算函数按新字号重绘。
    参数:
        host: 主窗口实例；读取 calc_*_font_spin 的当前值。
    返回:
        None。
    注意/副作用:
        - 字号只影响 HTML 内联样式，不改变计算结果；
        - 重新调用 update_calc_method_panel 以同一份数据按新字号重绘，避免重新执行算法；
        - 直接写 calc_result_label / calc_info_label 的 setStyleSheet；
        - 信息栏字号做 rf-1 且 15px 下限保护；
        - 数据不足时 update_calc_method_panel 显示提示文字，不抛异常。
    """
    rf = host.calc_result_font_spin.value() if hasattr(host, 'calc_result_font_spin') else 14
    # 更新结果标签字号
    host.calc_result_label.setStyleSheet(
        f"font-size: {rf}px; color: #666; background-color: #FAFAFA; "
        f"border-radius: 4px; padding: 8px; border: 1px solid #EEE;"
    )
    host.calc_info_label.setStyleSheet(f"font-size: {max(15, rf-1)}px; color: #888; padding: 2px 4px;")
    # 重新生成HTML以应用字号
    host._update_calc_method_panel()


def copy_calc_result(host):
    """把计算规律结果区文本复制到剪贴板。

    功能:
        优先取 _calc_text_result，缺失时取结果标签文本，写入剪贴板并提示。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 写系统剪贴板并设置 calc_info_label 提示；
        - 无内容时仍会写入空文本（不弹窗），信息栏显示「已复制」；
        - 剪贴板异常不阻断界面。
    """
    text = getattr(host, '_calc_text_result', '')
    if not text:
        text = host.calc_result_label.text()
    QApplication.clipboard().setText(text)
    host.calc_info_label.setText("✅ 结果已复制到剪贴板")


def export_calc_result(host):
    """把计算规律结果导出为 TXT 文件。

    功能:
        弹出保存对话框选择路径，写入带跳数/运算方式表头的 UTF-8 文本文件。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 无结果时在信息栏提示「无结果可导出」并返回；
        - 通过 QFileDialog 选择保存路径，用户取消时不写文件；
        - 直接以 `open(..., 'w', encoding='utf-8')` 写盘，失败时在信息栏显示错误文字，不弹窗；
        - 默认文件名为「计算规律分析_跳{skip}_{op_name}.txt」。
    """
    text = getattr(host, '_calc_text_result', '')
    if not text:
        host.calc_info_label.setText("无结果可导出")
        return
    skip = host.calc_skip_spin.value()
    op_names = ["加法+减法", "仅加法", "仅减法"]
    op_name = op_names[host.calc_op_combo.currentIndex()]
    default_name = f"计算规律分析_跳{skip}_{op_name}.txt"
    file_path, _ = QFileDialog.getSaveFileName(host, "导出计算结果", default_name, "文本文件 (*.txt)")
    if file_path:
        try:
            header = f"计算规律分析结果\n跳数: {skip} | 运算: {op_name}\n"
            header += "=" * 60 + "\n\n"
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(header + text)
            host.calc_info_label.setText(f"✅ 已导出到: {file_path}")
        except Exception as e:
            host.calc_info_label.setText(f"❌ 导出失败: {e}")


def apply_wave_panel_size(host):
    """应用波色页的「结果/趋势/转移」三档字号并重新生成 HTML。

    功能:
        读取三档字号设置三个结果区的 QSS，然后调用重算函数按新字号重绘。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 只改 QSS 与重新生成 HTML，不改变统计口径与结果数据；
        - 直接写 wave_result_label / wave_trend_label / wave_trans_label 的 setStyleSheet，
          信息栏字号做 rf-1 且 15px 下限保护；
        - 数据不足时由 update_wave_color_panel 输出占位提示。
    """
    rf = host.wave_result_font_spin.value() if hasattr(host, 'wave_result_font_spin') else 14
    tf = host.wave_trend_font_spin.value() if hasattr(host, 'wave_trend_font_spin') else 14
    xf = host.wave_trans_font_spin.value() if hasattr(host, 'wave_trans_font_spin') else 14
    # 更新标签字号
    host.wave_result_label.setStyleSheet(
        f"font-size: {rf}px; background-color: #FAFAFA; border-radius: 6px; "
        f"padding: 10px; border: 1px solid #EEE;"
    )
    # 波色趋势标签样式：浅灰背景，4px圆角，8px内边距
    host.wave_trend_label.setStyleSheet(
        f"font-size: {tf}px; background-color: #FFFFFF; border-radius: 4px; "
        f"padding: 6px; border: 1px solid #E0E0E0;"
    )
    # 波色转移标签样式：浅灰背景，4px圆角，8px内边距
    host.wave_trans_label.setStyleSheet(
        f"font-size: {xf}px; background-color: #FFFFFF; border-radius: 4px; "
        f"padding: 6px; border: 1px solid #E0E0E0;"
    )
    host.wave_info_label.setStyleSheet(f"font-size: {max(15, rf-1)}px; color: #888; padding: 2px 4px;")
    # 重新生成HTML以应用字号
    host._update_wave_color_panel()


def copy_wave_result(host):
    """把波色分析结果复制到剪贴板。

    功能:
        优先取 _wave_text_result，缺失时取结果标签文本，写入剪贴板并提示。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 写系统剪贴板并设置 wave_info_label 提示；
        - 无内容时仍会写入空文本（不弹窗），信息栏显示「已复制」；
        - 剪贴板异常不阻断界面。
    """
    text = getattr(host, '_wave_text_result', '')
    if not text:
        text = host.wave_result_label.text()
    QApplication.clipboard().setText(text)
    host.wave_info_label.setText("✅ 结果已复制到剪贴板")


def export_wave_result(host):
    """把波色分析结果导出为 TXT 文件。

    功能:
        弹出保存对话框选择路径，写入带模式/统计期数表头的 UTF-8 文本文件。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 无结果时在信息栏提示「无结果可导出」并返回；
        - 用户取消保存对话框时不写文件；
        - 直接以 `open(..., 'w', encoding='utf-8')` 写盘，失败时在信息栏显示错误文字；
        - 默认文件名为「波色预测_{mode_name}.txt」。
    """
    text = getattr(host, '_wave_text_result', '')
    if not text:
        host.wave_info_label.setText("无结果可导出")
        return
    mode_names = ["频率统计+号码分布", "仅频率统计", "仅号码分布", "转移概率加权"]
    mode_name = mode_names[host.wave_mode_combo.currentIndex()] if hasattr(host, 'wave_mode_combo') else "默认"
    default_name = f"波色预测_{mode_name}.txt"
    file_path, _ = QFileDialog.getSaveFileName(host, "导出波色分析", default_name, "文本文件 (*.txt)")
    if file_path:
        try:
            header = f"波色预测分析结果\n预测模式: {mode_name}\n"
            header += f"统计期数: {host.wave_period_spin.value()}\n"
            header += "=" * 60 + "\n\n"
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(header + text)
            host.wave_info_label.setText(f"✅ 已导出到: {file_path}")
        except Exception as e:
            host.wave_info_label.setText(f"❌ 导出失败: {e}")


def update_calc_method_panel(host):
    """执行「计算规律」分析：按跳数/运算/筛选参数生成 HTML 结果。

    功能:
        取最近若干期号码做跨期加减，统计高频值并按筛选方式缩圈，生成带字号样式的 HTML。
    参数:
        host: 主窗口实例；读取 _calc_config 与 historical_data。
    返回:
        None。
    注意/副作用:
        - 写 host.calc_info_label 与 host.calc_result_label（富文本）；
        - 纯展示函数，不修改历史数据，也不写 INI；
        - 数据不足（所需期数 = (跳数+1)*7）时显示「数据不足」提示；
        - 计算异常被捕获后以错误文字呈现，不影响其他子页。
    """
    if not hasattr(host, 'historical_data') or not host.historical_data:
        host.calc_info_label.setText("无历史数据")
        host.calc_result_label.setText("请先加载历史数据")
        return

    skip = host.calc_skip_spin.value()
    op_mode = host.calc_op_combo.currentIndex()  # 0=加减, 1=仅加, 2=仅减（下拉只有3项）
    filter_mode = host.calc_filter_combo.currentIndex() if hasattr(host, 'calc_filter_combo') else 0
    top_n = host.calc_topn_spin.value() if hasattr(host, 'calc_topn_spin') else 5

    # 每期 7 个号码（6 正码 + 1 特别码）；跳 skip 需要 skip+1 期的纵向窗口，
    # 再横向滑动比较所有距离为 step 的期对，所以最少要 (skip+1)*7 期
    needed = (skip + 1) * 7
    total = len(host.historical_data)

    if total < needed:
        host.calc_info_label.setText(f"跳{skip}需要至少{needed}期数据，当前仅有{total}期")
        host.calc_result_label.setText(f"数据不足：跳{skip}需{needed}期，当前{total}期")
        return

    recent = host.historical_data[-needed:]
    step = skip + 1
    pairs = []
    i = 0
    while i + step < len(recent):
        pairs.append((i, i + step))
        i += 1  # 逐期滑动，比较所有距离为step的期对

    # 判断运算类型（仅加法/减法）
    do_add = op_mode in [0, 1]
    do_sub = op_mode in [0, 2]

    mode_desc = f"跳{skip}需{needed}期"
    op_names = ["加法+减法", "仅加法", "仅减法"]
    host.calc_info_label.setText(
        f"{mode_desc} | {op_names[op_mode]} | 数据{total}期(用{needed}期) | "
        f"比较对数:{len(pairs)} | 每对7×7=49次计算"
    )

    # 收集所有计算结果
    add_results = {}
    sub_results = {}
    all_detail_lines = []

    for idx, (a_idx, b_idx) in enumerate(pairs):
        rec_a = recent[a_idx]
        rec_b = recent[b_idx]
        nums_a = rec_a.get('numbers', [])[:6] + [rec_a.get('special', 0)]
        nums_b = rec_b.get('numbers', [])[:6] + [rec_b.get('special', 0)]
        nums_a = [n for n in nums_a if 1 <= n <= 49]
        nums_b = [n for n in nums_b if 1 <= n <= 49]

        if len(nums_a) < 1 or len(nums_b) < 1:
            continue

        period_a = rec_a.get('period', '?')
        period_b = rec_b.get('period', '?')

        pair_adds = []
        pair_subs = []

        for na in nums_a:
            for nb in nums_b:
                if do_add:
                    add_val = ((na + nb - 1) % 49) + 1  # 循环到1-49
                    add_results[add_val] = add_results.get(add_val, 0) + 1
                    pair_adds.append(add_val)
                if do_sub:
                    sub_val = ((na - nb - 1) % 49) + 1  # 循环到1-49
                    sub_results[sub_val] = sub_results.get(sub_val, 0) + 1
                    pair_subs.append(sub_val)

        detail = f"第{idx+1}对: 期{period_a} ↔ 期{period_b}\n"
        if do_add:
            detail += f"  加法结果: {sorted(set(pair_adds))}\n"
        if do_sub:
            detail += f"  减法结果: {sorted(set(pair_subs))}\n"
        all_detail_lines.append(detail)

    # 筛选函数
    def filter_results(results):
        """按当前筛选模式过滤 TopN 结果。

        功能:
            依据闭包变量 filter_mode 保留全部/1~49/正数/高频项。
        参数:
            results (dict[int, int]): 值→出现次数的字典。
        返回:
            dict[int, int]: 过滤后的字典；模式未知时原样返回。
        注意/副作用:
            纯函数，不修改入参；空字典返回空字典，不做除零或索引操作。
        """
        if filter_mode == 0:  # 全部
            return results
        elif filter_mode == 1:  # 仅1-49范围
            return {v: c for v, c in results.items() if 1 <= v <= 49}
        elif filter_mode == 2:  # 仅正数
            return {v: c for v, c in results.items() if v > 0}
        elif filter_mode == 3:  # 仅高频(≥3次)
            return {v: c for v, c in results.items() if c >= 3}
        return results

    add_results = filter_results(add_results) if do_add else {}
    sub_results = filter_results(sub_results) if do_sub else {}

    # 生成HTML
    _fs = host.calc_result_font_spin.value() if hasattr(host, 'calc_result_font_spin') else 14
    _rfs = host.calc_rec_font_spin.value() if hasattr(host, 'calc_rec_font_spin') else 14
    _cfs = host.calc_comp_font_spin.value() if hasattr(host, 'calc_comp_font_spin') else 14
    _dfs = host.calc_detail_font_spin.value() if hasattr(host, 'calc_detail_font_spin') else 14
    html = f"<div style='font-size:{_fs}px; font-family: 'Microsoft YaHei', 'SimHei', 'SimSun', Arial, sans-serif;'>"

    # 辅助函数：生成高频分析区块
    def gen_result_block(title, icon, color, bg, results_dict, pairs_count):
        """生成一段带标题的 TopN 高频值 HTML 片段。

        功能:
            对结果字典降序排序取 TopN，生成带标题、占比与出现次数的 HTML 区块。
        参数:
            title (str): 区块标题（如「加法结果」）。
            icon (str): 标题前缀符号（如 ＋/－）。
            color (str): 标题与强调文字颜色。
            bg (str): 区块背景色。
            results_dict (dict[int, int]): 值→出现次数，函数内部排序取 TopN。
            pairs_count (int): 参与统计的期对数，用于标题说明与占比换算。
        返回:
            str: 可直接插入结果区的 HTML；results_dict 为空时返回空字符串。
        注意/副作用:
            - 纯字符串拼接，无写盘/信号副作用；
            - 空字典返回空串，不产生空表格；top_n 越界由切片自动收敛；
            - 占比计算使用 pairs_count，为 0 时由调用方保证不会传入。
        """
        if not results_dict:
            return ""
        sorted_items = sorted(results_dict.items(), key=lambda x: x[1], reverse=True)
        max_count = sorted_items[0][1]
        top_items = sorted_items[:top_n]
        result_html = f"<div style='background:{bg}; border-radius:6px; padding:8px; margin-bottom:6px;'>"
        if max_count >= 3:
            result_html += f"<b style='color:{color};'>{icon} {title}高频规律</b><br>"
            top_vals = [v for v, c in sorted_items if c == max_count]
            result_html += f"数值 <b style='font-size:{_fs+2}px;'>{', '.join(str(v) for v in sorted(top_vals)[:10])}</b> "
            result_html += f"出现 <b>{max_count}</b> 次（共{pairs_count}对比较）<br>"
            result_html += f"<span style='color:#666;'>这些数值在多对期间反复出现</span><br><br>"
        else:
            result_html += f"<b style='color:{color};'>{icon} {title}分析</b><br>"
            result_html += f"最高出现{max_count}次，未发现明显重复规律<br><br>"

        # TopN柱状图
        result_html += f"<b style='color:#00695C; font-size:{max(15,_fs-1)}px;'>{title} Top{len(top_items)}高频值:</b><br>"
        max_cnt = top_items[0][1] if top_items else 1
        for rank, (val, cnt) in enumerate(top_items, 1):
            bar_len = int(cnt / max_cnt * 20) if max_cnt > 0 else 0
            # 对1-49范围的值用波色着色
            val_color = "#333"
            if 1 <= val <= 49:
                if LotteryConfig.is_red(val):
                    val_color = "#FF0000"
                elif LotteryConfig.is_blue(val):
                    val_color = "#0000FF"
                elif LotteryConfig.is_green(val):
                    val_color = "#008000"
            result_html += f"<span style='color:#333;'>{rank}. </span>"
            result_html += f"<span style='color:{val_color}; font-weight:bold;'>值{val}</span>: "
            result_html += f"<span style='color:{color}; font-weight:bold;'>{'█' * bar_len}</span> "
            result_html += f"<span style='color:#666;'>({cnt}次)</span><br>"
        result_html += "</div>"
        return result_html

    # 生成各运算结果区块
    if do_add and add_results:
        html += gen_result_block("加法", "⚡", "#2E7D32", "#E8F5E9", add_results, len(pairs))
    if do_sub and sub_results:
        html += gen_result_block("减法", "⚡", "#1565C0", "#E3F2FD", sub_results, len(pairs))

    # 判断是否有规律
    has_pattern = False
    for r in [add_results, sub_results]:
        if r and max(r.values()) >= 3:
            has_pattern = True
            break

    if not has_pattern:
        html += f"<div style='background:#FFEBEE; border-radius:6px; padding:8px; margin-bottom:6px;'>"
        html += f"<b style='color:#C62828;'>结论：没有发现明显规律</b><br>"
        mode_txt = f"跳{skip}"
        html += f"<span style='color:#666;'>当前{mode_txt}设置下，各计算结果出现次数均低于3次，无显著重复模式</span>"
        html += "</div>"

    # 号码推荐（基于高频值在1-49范围的）
    rec_nums = set()
    for r in [add_results, sub_results]:
        for v, c in r.items():
            if 1 <= v <= 49 and c >= 2:
                rec_nums.add(v)
    if rec_nums:
        sorted_rec = sorted(rec_nums)
        html += f"<div style='background:#E0F7FA; border-radius:6px; padding:8px; margin-bottom:6px; font-size:{_rfs}px;'>"
        html += f"<b style='color:#006064;'>🎯 推荐号码（高频值在1-49范围内）</b><br>"
        # 按波色分组显示
        red_nums = [n for n in sorted_rec if LotteryConfig.is_red(n)]
        blue_nums = [n for n in sorted_rec if LotteryConfig.is_blue(n)]
        green_nums = [n for n in sorted_rec if LotteryConfig.is_green(n)]
        if red_nums:
            html += f"<span style='color:#FF0000; font-weight:bold;'>红: {', '.join(str(n) for n in red_nums)}</span>  "
        if blue_nums:
            html += f"<span style='color:#0000FF; font-weight:bold;'>蓝: {', '.join(str(n) for n in blue_nums)}</span>  "
        if green_nums:
            html += f"<span style='color:#008000; font-weight:bold;'>绿: {', '.join(str(n) for n in green_nums)}</span>"
        html += f"<br><span style='color:#666; font-size:{max(15,_rfs-1)}px;'>共{len(sorted_rec)}个号码 | 基于计算高频值筛选</span>"
        html += "</div>"

    # 统计分析对比（前半段 vs 后半段）
    if len(pairs) >= 4:
        half = len(pairs) // 2
        halves = [
            ('前半', [pairs[i] for i in range(half)]),
            ('后半', [pairs[i] for i in range(half, len(pairs))])
        ]
        half_stats = {}
        for hname, h_pairs in halves:
            ha, hs = {}, {}
            for a_idx2, b_idx2 in h_pairs:
                rec_a2 = recent[a_idx2]
                rec_b2 = recent[b_idx2]
                nums_a2 = rec_a2.get('numbers', [])[:6] + [rec_a2.get('special', 0)]
                nums_b2 = rec_b2.get('numbers', [])[:6] + [rec_b2.get('special', 0)]
                nums_a2 = [n for n in nums_a2 if 1 <= n <= 49]
                nums_b2 = [n for n in nums_b2 if 1 <= n <= 49]
                for na2 in nums_a2:
                    for nb2 in nums_b2:
                        if do_add:
                            av = ((na2 + nb2 - 1) % 49) + 1  # 循环到1-49
                            ha[av] = ha.get(av, 0) + 1
                        if do_sub:
                            sv = ((na2 - nb2 - 1) % 49) + 1  # 循环到1-49
                            hs[sv] = hs.get(sv, 0) + 1
            half_stats[hname] = {'加': ha, '减': hs}

        html += f"<div style='background:#F3E5F5; border-radius:6px; padding:8px; margin-bottom:6px; font-size:{_cfs}px;'>"
        html += f"<b style='color:#6A1B9A;'>📈 统计分析对比（前{half}对 vs 后{len(pairs)-half}对）</b><br>"

        for op_tag, op_do, op_color in [('加', do_add, '#2E7D32'), ('减', do_sub, '#1565C0')]:
            if not op_do:
                continue
            f1 = half_stats['前半'][op_tag]
            f2 = half_stats['后半'][op_tag]
            if not f1 or not f2:
                continue
            f1_top = sorted(f1.items(), key=lambda x: x[1], reverse=True)[:5]
            f2_top = sorted(f2.items(), key=lambda x: x[1], reverse=True)[:5]
            html += f"<span style='color:{op_color}; font-weight:bold;'>{op_tag}法前半:</span> "
            html += ", ".join(f"{v}({c}次)" for v, c in f1_top) + "<br>"
            html += f"<span style='color:{op_color}; font-weight:bold;'>{op_tag}法后半:</span> "
            html += ", ".join(f"{v}({c}次)" for v, c in f2_top) + "<br>"
            common = set(v for v, _ in f1_top) & set(v for v, _ in f2_top)
            if common:
                html += f"<span style='color:#C62828; font-weight:bold;'>{op_tag}法前后稳定值:</span> {sorted(common)}<br>"

        html += f"<span style='color:#666; font-size:{max(15,_cfs-1)}px;'>对比可发现规律是否在前后段保持一致</span>"
        html += "</div>"

    # 详细结果（折叠显示）
    html += f"<details style='margin-top:6px;'><summary style='cursor:pointer; color:#3498DB; font-size:{_dfs}px;'>查看详细计算结果</summary>"
    html += f"<div style='margin-top:4px; max-height:300px; overflow-y:auto; font-size:{_dfs}px;'>"
    for line in all_detail_lines:
        html += f"<pre style='font-size:{_dfs}px; margin:2px 0; white-space:pre-wrap;'>{line}</pre>"
    html += "</div></details>"

    # 统计汇总
    html += f"<div style='margin-top:6px; color:#888; font-size:{max(15,_fs-1)}px;'>"
    html += f"总计算: {len(pairs)}对 × 49次 = {len(pairs)*49}次 | "
    if do_add:
        html += f"加法: {len(add_results)}个 | "
    if do_sub:
        html += f"减法: {len(sub_results)}个"
    html += "</div>"

    html += "</div>"
    host.calc_result_label.setText(html)
    # 保存纯文本结果供复制/导出使用
    host._calc_text_result = "\n".join(all_detail_lines)


def update_wave_color_panel(host):
    """执行波色统计分析：按模式/期数/趋势期数生成波色概率 HTML。

    功能:
        统计红/蓝/绿波出现次数与百分比，并按「趋势期数」对比前后两段变化，写入三个结果区。
    参数:
        host: 主窗口实例；读取 _wave_config 与 historical_data。
    返回:
        None。
    注意/副作用:
        - 写 host.wave_result_label、wave_trend_label、wave_trans_label（富文本）；
        - 字号取自 wave_*_font_spin，只影响生成的 HTML，不改控件本身；
        - 不修改历史数据，不写 INI；
        - 数据不足或无波色定义时显示提示文字；异常被捕获后以错误文字呈现。
    """
    if not hasattr(host, 'historical_data') or not host.historical_data:
        host.wave_result_label.setText("请先加载历史数据")
        host.wave_trend_label.setText("")
        host.wave_trans_label.setText("")
        return

    stat_periods = host.wave_period_spin.value()
    total = len(host.historical_data)
    use_n = min(stat_periods, total)
    mode_desc = f"统计{use_n}期"

    recent = host.historical_data[-use_n:]

    # 统计每期的波色分布
    # 每期7个号码（6正码+1特别码），统计红/蓝/绿各多少个
    period_colors = []  # 每期的波色列表 [(red, blue, green, dominant)]
    color_counts = {'红波': 0, '蓝波': 0, '绿波': 0}
    # 所有号码的波色统计（包含正码和特别码）
    all_num_color_count = {'红波': 0, '蓝波': 0, '绿波': 0}

    for rec in recent:
        nums = rec.get('numbers', [])[:6] + [rec.get('special', 0)]
        nums = [n for n in nums if 1 <= n <= 49]
        r = sum(1 for n in nums if LotteryConfig.is_red(n))
        b = sum(1 for n in nums if LotteryConfig.is_blue(n))
        g = sum(1 for n in nums if LotteryConfig.is_green(n))

        # 主波色：该期出现最多的波色
        if r >= b and r >= g:
            dominant = '红波'
        elif b >= g:
            dominant = '蓝波'
        else:
            dominant = '绿波'

        period_colors.append((r, b, g, dominant, rec.get('period', '?')))
        color_counts[dominant] += 1
        all_num_color_count['红波'] += r
        all_num_color_count['蓝波'] += b
        all_num_color_count['绿波'] += g

    total_nums = sum(all_num_color_count.values())
    total_periods = len(period_colors)

    # 1. 概率显示
    _wfs = host.wave_result_font_spin.value() if hasattr(host, 'wave_result_font_spin') else 14
    _tfs = host.wave_trend_font_spin.value() if hasattr(host, 'wave_trend_font_spin') else 14
    _xfs = host.wave_trans_font_spin.value() if hasattr(host, 'wave_trans_font_spin') else 14
    html = f"<div style='font-size:{_wfs}px; font-family: 'Microsoft YaHei', 'SimHei', 'SimSun', Arial, sans-serif;'>"

    html += f"<b style='font-size:{_wfs+1}px; color:#333;'>📊 波色出现统计（主波色）</b><br><br>"

    # 三色概率条
    colors_info = [
        ('红波', '#FF0000', '#FFEBEE', color_counts['红波']),
        ('蓝波', '#0000FF', '#E3F2FD', color_counts['蓝波']),
        ('绿波', '#008000', '#E8F5E9', color_counts['绿波']),
    ]

    for name, color, bg, count in colors_info:
        pct = count / total_periods * 100 if total_periods > 0 else 0
        html += f"<div style='display:inline-block; margin:2px 6px 2px 0; "
        html += f"background:{bg}; border-radius:6px; padding:6px 12px; border:1px solid {color};'>"
        html += f"<span style='color:{color}; font-weight:bold; font-size:{_wfs+1}px;'>● {name}</span> "
        html += f"<span style='color:#333; font-size:{_wfs}px;'><b>{count}</b>期 ({pct:.1f}%)</span>"
        html += "</div>"

    html += "<br><br>"

    # 所有号码波色统计
    html += "<b style='color:#333;'>📊 号码波色分布（所有号码）</b><br>"
    for name, color, bg, _ in colors_info:
        cnt = all_num_color_count[name]
        pct = cnt / total_nums * 100 if total_nums > 0 else 0
        html += f"<span style='color:{color}; font-weight:bold;'>{name}: {cnt}个 ({pct:.1f}%)</span>  "
    html += "<br><br>"

    # 预测下一次主波色
    pred_mode = host.wave_mode_combo.currentIndex() if hasattr(host, 'wave_mode_combo') else 0
    if color_counts:
        combined = {}
        for name, _, _, _ in colors_info:
            main_pct = color_counts[name] / total_periods if total_periods > 0 else 0
            num_pct = all_num_color_count[name] / total_nums if total_nums > 0 else 0
            if pred_mode == 0:  # 频率统计+号码分布
                combined[name] = main_pct * 0.5 + num_pct * 0.5
            elif pred_mode == 1:  # 仅频率统计
                combined[name] = main_pct
            elif pred_mode == 2:  # 仅号码分布
                combined[name] = num_pct
            else:  # 转移概率加权（后续补充）
                combined[name] = main_pct * 0.3 + num_pct * 0.3  # 先给基础分，后面加转移概率

        # 转移概率加权模式：需要先计算转移矩阵
        trans = {'红波': {'红波': 0, '蓝波': 0, '绿波': 0},
                 '蓝波': {'红波': 0, '蓝波': 0, '绿波': 0},
                 '绿波': {'红波': 0, '蓝波': 0, '绿波': 0}}
        for i in range(1, len(period_colors)):
            prev = period_colors[i-1][3]
            curr = period_colors[i][3]
            trans[prev][curr] += 1
        last_dom = period_colors[-1][3] if period_colors else '红波'
        last_trans = trans[last_dom]
        last_total = sum(last_trans.values())

        if pred_mode == 3 and last_total > 0:
            # 转移概率加权：基础30%+号码30%+转移概率40%
            for name, _, _, _ in colors_info:
                trans_pct = last_trans[name] / last_total if last_total > 0 else 0
                combined[name] = combined[name] + trans_pct * 0.4

        pred_color = max(combined, key=combined.get)
        pred_pct = combined[pred_color] * 100

        color_map = {'红波': '#FF0000', '蓝波': '#0000FF', '绿波': '#008000'}
        pc = color_map.get(pred_color, '#333')

        mode_names = ["频率统计+号码分布", "仅频率统计", "仅号码分布", "转移概率加权"]
        html += f"<div style='background:#FFF8E1; border:2px solid {pc}; border-radius:8px; padding:10px; margin:4px 0;'>"
        html += f"<b style='font-size:{_wfs+1}px; color:{pc};'>🎯 预测下一次主波色: {pred_color}</b><br>"
        html += f"<span style='color:#666;'>综合概率: {pred_pct:.1f}%</span><br>"
        html += f"<span style='color:#888; font-size:{max(15, _wfs-1)}px;'>"
        for name, _, _, _ in colors_info:
            html += f"{name}={combined[name]*100:.1f}%  "
        html += "</span>"
        html += "</div>"

    html += f"<div style='color:#888; font-size:{max(15, _wfs-1)}px; margin-top:4px;'>{mode_desc} | 算法: {mode_names[pred_mode]}</div>"
    html += "</div>"

    host.wave_result_label.setText(html)
    host.wave_info_label.setText(f"{mode_desc} | 主波色统计 | 号码分布 | 转移概率分析")

    # 2. 走势显示（用户指定期数）
    trend_n = host.wave_trend_spin.value() if hasattr(host, 'wave_trend_spin') else 20
    show_trend = period_colors[-trend_n:]
    trend_html = f"<div style='font-size:{_tfs}px; line-height:1.8;'>"
    color_map = {'红波': '#FF0000', '蓝波': '#0000FF', '绿波': '#008000'}
    bg_map = {'红波': '#FFEBEE', '蓝波': '#E3F2FD', '绿波': '#E8F5E9'}

    for r, b, g, dom, period in show_trend:
        c = color_map.get(dom, '#333')
        bg = bg_map.get(dom, '#F5F5F5')
        trend_html += f"<span style='display:inline-block; margin:1px 2px; "
        trend_html += f"background:{bg}; border:1px solid {c}; border-radius:3px; "
        trend_html += f"padding:1px 5px; color:{c}; font-weight:bold;'>"
        trend_html += f"期{period}: {dom[0]}({r}红{b}蓝{g}绿)"
        trend_html += "</span>"
    trend_html += "</div>"

    host.wave_trend_label.setText(trend_html)

    # 3. 转移概率矩阵
    # 统计：上次主波色A → 本次主波色B 的次数
    trans = {'红波': {'红波': 0, '蓝波': 0, '绿波': 0},
             '蓝波': {'红波': 0, '蓝波': 0, '绿波': 0},
             '绿波': {'红波': 0, '蓝波': 0, '绿波': 0}}

    for i in range(1, len(period_colors)):
        prev = period_colors[i-1][3]
        curr = period_colors[i][3]
        trans[prev][curr] += 1

    # 上一次的主波色
    last_dom = period_colors[-1][3] if period_colors else '红波'

    trans_html = f"<div style='font-size:{_xfs}px;'>"
    trans_html += f"<b>上期主波色: <span style='color:{color_map.get(last_dom,'#333')};'>{last_dom}</span></b><br><br>"

    # 转移概率表格
    trans_html += f"<table style='border-collapse:collapse; font-size:{_xfs}px;'>"
    trans_html += "<tr style='background:#F0F0F0;'><th style='border:1px solid #CCC; padding:3px 8px;'>上期\\下期</th>"
    for name, _, _, _ in colors_info:
        trans_html += f"<th style='border:1px solid #CCC; padding:3px 8px; color:{color_map[name]};'>{name}</th>"
    trans_html += "</tr>"

    for from_name, _, _, _ in colors_info:
        row_total = sum(trans[from_name].values())
        fc = color_map[from_name]
        trans_html += f"<tr><td style='border:1px solid #CCC; padding:3px 8px; color:{fc}; font-weight:bold; background:{bg_map[from_name]};'>{from_name}</td>"
        for to_name, _, _, _ in colors_info:
            cnt = trans[from_name][to_name]
            pct = cnt / row_total * 100 if row_total > 0 else 0
            # 高亮从上期波色出发的行
            highlight = "background:#FFF8E1;" if from_name == last_dom else ""
            trans_html += f"<td style='border:1px solid #CCC; padding:3px 8px; text-align:center; {highlight}'>"
            trans_html += f"{cnt}次<br><span style='color:#888; font-size:{max(15, _xfs-1)}px;'>({pct:.0f}%)</span>"
            trans_html += "</td>"
        trans_html += "</tr>"
    trans_html += "</table>"

    # 预测下期基于转移概率
    last_trans = trans[last_dom]
    last_total = sum(last_trans.values())
    if last_total > 0:
        trans_html += f"<br><b>基于转移概率预测下期:</b><br>"
        sorted_trans = sorted(last_trans.items(), key=lambda x: x[1], reverse=True)
        for name, cnt in sorted_trans:
            pct = cnt / last_total * 100
            tc = color_map[name]
            trans_html += f"<span style='color:{tc}; font-weight:bold;'>{name}: {pct:.1f}%</span>  "
    else:
        trans_html += "<br><span style='color:#888;'>转移数据不足</span>"

    trans_html += "</div>"
    host.wave_trans_label.setText(trans_html)

    # 4. 统计分析对比（前半段 vs 后半段）
    if total_periods >= 6:
        half_w = total_periods // 2
        first_colors = period_colors[:half_w]
        second_colors = period_colors[half_w:]

        first_dom = {'红波': 0, '蓝波': 0, '绿波': 0}
        second_dom = {'红波': 0, '蓝波': 0, '绿波': 0}
        first_nums = {'红波': 0, '蓝波': 0, '绿波': 0}
        second_nums = {'红波': 0, '蓝波': 0, '绿波': 0}

        for r, b, g, dom, _ in first_colors:
            first_dom[dom] += 1
            first_nums['红波'] += r
            first_nums['蓝波'] += b
            first_nums['绿波'] += g
        for r, b, g, dom, _ in second_colors:
            second_dom[dom] += 1
            second_nums['红波'] += r
            second_nums['蓝波'] += b
            second_nums['绿波'] += g

        f_total = sum(first_dom.values()) or 1
        s_total = sum(second_dom.values()) or 1
        fn_total = sum(first_nums.values()) or 1
        sn_total = sum(second_nums.values()) or 1

        cmp_html = f"<div style='font-size:{_wfs}px; font-family: 'Microsoft YaHei', 'SimHei', 'SimSun', Arial, sans-serif; margin-top:8px;'>"
        cmp_html += f"<div style='background:#F3E5F5; border-radius:6px; padding:8px;'>"
        cmp_html += f"<b style='color:#6A1B9A;'>📈 波色统计分析对比（前{half_w}期 vs 后{total_periods-half_w}期）</b><br><br>"
        cmp_html += f"<table style='border-collapse:collapse; font-size:{_wfs}px;'>"
        cmp_html += "<tr style='background:#F0F0F0;'><th style='border:1px solid #CCC; padding:3px 8px;'>波色</th>"
        cmp_html += f"<th style='border:1px solid #CCC; padding:3px 8px;'>前半主波色</th>"
        cmp_html += f"<th style='border:1px solid #CCC; padding:3px 8px;'>后半主波色</th>"
        cmp_html += f"<th style='border:1px solid #CCC; padding:3px 8px;'>前半号码占比</th>"
        cmp_html += f"<th style='border:1px solid #CCC; padding:3px 8px;'>后半号码占比</th>"
        cmp_html += f"<th style='border:1px solid #CCC; padding:3px 8px;'>趋势变化</th></tr>"

        for name, color, _, _ in colors_info:
            f_pct = first_dom[name] / f_total * 100
            s_pct = second_dom[name] / s_total * 100
            fn_pct = first_nums[name] / fn_total * 100
            sn_pct = second_nums[name] / sn_total * 100
            diff = s_pct - f_pct
            arrow = "↑" if diff > 0 else ("↓" if diff < 0 else "→")
            diff_color = "#2E7D32" if diff > 0 else ("#C62828" if diff < 0 else "#666")
            cmp_html += f"<tr><td style='border:1px solid #CCC; padding:3px 8px; color:{color}; font-weight:bold;'>{name}</td>"
            cmp_html += f"<td style='border:1px solid #CCC; padding:3px 8px; text-align:center;'>{first_dom[name]}期({f_pct:.1f}%)</td>"
            cmp_html += f"<td style='border:1px solid #CCC; padding:3px 8px; text-align:center;'>{second_dom[name]}期({s_pct:.1f}%)</td>"
            cmp_html += f"<td style='border:1px solid #CCC; padding:3px 8px; text-align:center;'>{fn_pct:.1f}%</td>"
            cmp_html += f"<td style='border:1px solid #CCC; padding:3px 8px; text-align:center;'>{sn_pct:.1f}%</td>"
            cmp_html += f"<td style='border:1px solid #CCC; padding:3px 8px; text-align:center; color:{diff_color}; font-weight:bold;'>{arrow} {abs(diff):.1f}%</td>"
            cmp_html += "</tr>"
        cmp_html += "</table>"
        cmp_html += f"<br><span style='color:#666; font-size:{max(15, _wfs-1)}px;'>趋势变化>0表示后半段该波色出现频率上升，<0表示下降</span>"
        cmp_html += "</div></div>"

        # 追加到结果标签
        current_html = host.wave_result_label.text()
        host.wave_result_label.setText(current_html + cmp_html)

    # 5. 冷热波色分析
    if total_periods >= 5:
        # 近5期的波色作为"热"参考
        recent_5 = period_colors[-5:]
        recent_5_dom = [pc[3] for pc in recent_5]
        # 冷波色：最近5期没出现过的
        all_colors = ['红波', '蓝波', '绿波']
        hot_colors = [c for c in all_colors if c in recent_5_dom]
        cold_colors = [c for c in all_colors if c not in recent_5_dom]

        extra_html = f"<div style='font-size:{_wfs}px; font-family: 'Microsoft YaHei', 'SimHei', 'SimSun', Arial, sans-serif; margin-top:8px;'>"
        extra_html += f"<div style='background:#FFFDE7; border-radius:6px; padding:8px;'>"
        extra_html += f"<b style='color:#F57F17;'>🔥 冷热波色分析</b><br>"
        if hot_colors:
            extra_html += f"<span style='color:#E65100; font-weight:bold;'>热波色(近5期出现):</span> "
            for c in hot_colors:
                cc = color_map.get(c, '#333')
                extra_html += f"<span style='color:{cc}; font-weight:bold;'>{c}</span> "
            extra_html += "<br>"
        if cold_colors:
            extra_html += f"<span style='color:#1565C0; font-weight:bold;'>冷波色(近5期未出):</span> "
            for c in cold_colors:
                cc = color_map.get(c, '#333')
                extra_html += f"<span style='color:{cc}; font-weight:bold;'>{c}</span> "
            extra_html += "<br>"
        # 连续出现分析
        if len(period_colors) >= 3:
            streak = 1
            streak_color = period_colors[-1][3]
            for i in range(len(period_colors) - 2, -1, -1):
                if period_colors[i][3] == streak_color:
                    streak += 1
                else:
                    break
            sc = color_map.get(streak_color, '#333')
            extra_html += f"<span style='color:#666;'>当前{streak_color}已连续出现 <b style='color:{sc};'>{streak}</b> 期</span><br>"
            if streak >= 3:
                extra_html += f"<span style='color:#C62828;'>⚠ 连续{streak}期同色，下期可能反转</span><br>"
            else:
                extra_html += f"<span style='color:#2E7D32;'>连续期数较少，趋势可能延续</span><br>"
        extra_html += "</div>"

        # 6. 号码推荐（基于波色预测）
        try:
            rec_color = pred_color
        except NameError:
            rec_color = '红波'
        rc = color_map.get(rec_color, '#333')
        # 找出该波色的所有号码
        rec_nums_list = []
        for n in range(1, 50):
            if rec_color == '红波' and LotteryConfig.is_red(n):
                rec_nums_list.append(n)
            elif rec_color == '蓝波' and LotteryConfig.is_blue(n):
                rec_nums_list.append(n)
            elif rec_color == '绿波' and LotteryConfig.is_green(n):
                rec_nums_list.append(n)

        extra_html += f"<div style='background:#E0F7FA; border-radius:6px; padding:8px; margin-top:6px;'>"
        extra_html += f"<b style='color:#006064;'>🎯 {rec_color}推荐号码</b><br>"
        extra_html += f"<span style='color:{rc}; font-weight:bold; font-size:{_wfs+1}px;'>"
        extra_html += ", ".join(str(n) for n in rec_nums_list)
        extra_html += "</span><br>"
        extra_html += f"<span style='color:#666; font-size:{max(15,_wfs-1)}px;'>共{len(rec_nums_list)}个号码 | 基于预测波色{rec_color}筛选</span>"
        extra_html += "</div></div>"

        # 追加到结果标签
        current_html2 = host.wave_result_label.text()
        host.wave_result_label.setText(current_html2 + extra_html)

    # 保存纯文本结果供复制/导出使用
    host._wave_text_result = host.wave_result_label.text()


# ╔══════════════════════════════════════════════════════════════════╗
# ║  [已保存预测] 保存 / 加载 / 删除 / 清空 / 详情 / 对比 / 收藏            ║
# ╚══════════════════════════════════════════════════════════════════╝

def load_saved_predictions(host):
    """从磁盘加载「已保存的预测」并刷新三个相关列表/表格。

    功能:
        读取 JSON（缺失时回退 SQLite 镜像），生成倒序列表项并填充已保存/收藏列表。
    参数:
        host: 主窗口实例；读取 host.saved_predictions_file。
    返回:
        None。
    注意/副作用:
        - 写 host._saved_predictions_data，并清空/重建 saved_predictions_list 与 favorites_list；
        - 按当前最新期号比对 data_period，过期项标「⚠已过期」并置灰；
        - 更新收藏计数标签；
        - 文件不存在时按空列表处理；JSON 损坏或字段缺失时回退为空列表并打印错误，不弹窗阻塞启动。
    """
    try:
        if os.path.exists(host.saved_predictions_file):
            with open(host.saved_predictions_file, 'r', encoding='utf-8') as f:
                saved_list = json.load(f)
            if not isinstance(saved_list, list):
                saved_list = []
        else:
            # JSON缺失时从 SQLite 读取预测记录镜像
            saved_list = []
            if host._db is not None:
                try:
                    raw = host._db.get_config('saved_predictions')
                    if raw:
                        saved_list = json.loads(raw)
                        if not isinstance(saved_list, list):
                            saved_list = []
                except Exception as db_err:
                    print("从数据库读取预测记录失败: " + str(db_err))

        host._saved_predictions_data = saved_list
        latest_period = get_latest_period(host.historical_data)

        # 生成列表项（用于多个列表）
        items = []
        for i, item in enumerate(reversed(saved_list)):
            numbers = item.get('numbers', [])
            special = item.get('special', 0)
            algorithm = item.get('algorithm', '未知')
            timestamp = item.get('timestamp', '')
            data_period = item.get('data_period', '')

            is_expired = False
            if latest_period and data_period and latest_period != data_period:
                is_expired = True

            num_str = ' '.join(str(n).zfill(2) for n in sorted(numbers))
            if special and special > 0:
                num_str += ' + ' + str(special).zfill(2)

            expired_tag = " ⚠已过期" if is_expired else ""
            display_text = f"{algorithm}{expired_tag}\n  {num_str}\n  {timestamp}"

            items.append({
                'text': display_text,
                'is_expired': is_expired,
                'data_index': len(saved_list) - 1 - i
            })

        # 更新所有已保存预测列表
        for list_widget in [getattr(host, 'saved_predictions_list', None),
                            getattr(host, 'favorites_list', None)]:
            if list_widget is not None:
                list_widget.clear()
                for item_data in items:
                    list_item = QListWidgetItem(item_data['text'])
                    if item_data['is_expired']:
                        list_item.setForeground(QColor("#999999"))
                    list_item.setData(1000, item_data['data_index'])
                    list_widget.addItem(list_item)

        # 更新收藏计数
        if hasattr(host, 'favorites_count_label'):
            host.favorites_count_label.setText(f"共 {len(saved_list)} 条收藏")

    except Exception as e:
        print("加载已保存预测失败: " + str(e))
        host._saved_predictions_data = []


def save_saved_predictions(host):
    """把 host.saved_predictions_list 写回 JSON 文件。

    功能:
        把内存中的已保存预测列表写入 JSON，并同步镜像到 SQLite 配置表。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 调用 host._safe_write_json 写盘（原子写）；
        - 同步调用 host._db.set_config('saved_predictions', ...)，JSON 丢失时可恢复；
        - 写盘失败仅打印错误，内存中的列表保持不变，避免用户操作丢失。
    """
    try:
        if hasattr(host, '_saved_predictions_data'):
            host._safe_write_json(host.saved_predictions_file, host._saved_predictions_data)
            # 【数据库同步】预测记录同时镜像到 SQLite，JSON丢失时可恢复
            if host._db is not None:
                host._db.set_config(
                    'saved_predictions',
                    json.dumps(host._saved_predictions_data, ensure_ascii=False))
    except Exception as e:
        print("保存预测列表失败: " + str(e))


def on_save_current_prediction(host):
    """把当前预测结果加入「已保存预测」列表并落盘。

    功能:
        组装号码/特别码/置信度/算法/数据指纹/时间戳记录，追加到列表后保存并刷新界面。
    参数:
        host: 主窗口实例；读取 host.current_prediction_result。
    返回:
        None。
    注意/副作用:
        - 消息框提示：无结果或号码为空时直接返回；
        - 追加到 host._saved_predictions_data，调用 save_saved_predictions（JSON + SQLite）与
          load_saved_predictions（重建列表）；
        - 每条记录包含 numbers、special、confidence_info、algorithm、data_period、
          is_reverse、is_enhanced 与秒级时间戳；
        - 保存异常被捕获后弹窗「保存失败」，不中断界面。
    """
    if not hasattr(host, 'current_prediction_result') or not host.current_prediction_result:
        QMessageBox.information(host, "提示", "没有可保存的预测结果，请先进行预测")
        return

    try:
        numbers = host.current_prediction_result.get('numbers', [])
        if not numbers:
            QMessageBox.information(host, "提示", "预测结果为空，无法保存")
            return

        # 构造保存数据
        save_item = {
            'id': int(datetime.datetime.now().timestamp()),
            'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'algorithm': host.current_prediction_result.get('algorithm', '未知'),
            'numbers': [int(n) for n in numbers],
            'special': int(host.current_prediction_result.get('special', 0)),
            'confidence_info': host.current_prediction_result.get('confidence_info', {}),
            'data_period': get_latest_period(host.historical_data),
            'is_reverse': host.reverse_mode,
            'is_enhanced': host.enhanced_mode,
        }

        if not hasattr(host, '_saved_predictions_data'):
            host._saved_predictions_data = []
        host._saved_predictions_data.append(save_item)
        save_saved_predictions(host)
        load_saved_predictions(host)

        QMessageBox.information(host, "成功", "预测结果已保存")
    except Exception as e:
        traceback.print_exc()
        QMessageBox.warning(host, "错误", "保存失败: " + str(e))


def on_load_saved_prediction(host):
    """把选中的已保存预测回填到结果展示区。

    功能:
        按列表项隐藏索引取出记录，调用 _display_predictions 展示号码，并更新算法来源标签。
    参数:
        host: 主窗口实例；读取当前选中的表格行。
    返回:
        None。
    注意/副作用:
        - 调用 host._display_predictions 重绘结果区（不改变当前算法设置）；
        - 写 host.algorithm_source_label 文本与胶囊样式（颜色随算法/模式变化）；
        - 状态栏提示加载时间；
        - 索引做上下界校验（修复负数从末尾访问的越界 bug）；
        - 未选中行时弹窗「请先选择」；记录字段损坏时弹窗「加载失败」，不改变当前结果区。
    """
    fav_list = host._get_favorites_list()
    if not fav_list:
        QMessageBox.information(host, "提示", "收藏列表不可用")
        return
    current_item = fav_list.currentItem()
    if not current_item:
        QMessageBox.information(host, "提示", "请先选择要加载的预测")
        return

    try:
        idx = current_item.data(1000)
        # 【修复索引越界bug】原代码只检查idx is None，未检查上下界，负数idx会从列表末尾访问
        if idx is None or not hasattr(host, '_saved_predictions_data') or not (0 <= idx < len(host._saved_predictions_data)):
            return

        item = host._saved_predictions_data[idx]
        numbers = item.get('numbers', [])
        confidence_info = item.get('confidence_info', {})
        algorithm = item.get('algorithm', '')

        # 直接显示，不改变当前算法设置
        host._display_predictions(numbers, confidence_info)

        # 更新算法标签为保存时的信息
        mode_suffix = ""
        if item.get('is_reverse'):
            mode_suffix = " (反向模式)"
        elif item.get('is_enhanced'):
            mode_suffix = " (增强版)"

        label_color = "#E74C3C" if item.get('is_reverse') else "#2ECC71"
        if "机器学习" in algorithm:
            label_color = "#3498DB"
        elif "随机" in algorithm:
            label_color = "#E67E22"

        host.algorithm_source_label.setText("已加载: " + algorithm + mode_suffix)
        # 算法来源标签样式（加载已保存预测时）- 胶囊形标签，颜色随算法/模式变化
        host.algorithm_source_label.setStyleSheet(
            "font-size: 15px; font-weight: bold; padding: 4px 12px; "
            "border-radius: 12px; background-color: #FFFFFF; color: " + label_color + "; "
            "border: 1px solid " + label_color + ";"
        )

        host.statusBar().showMessage(f"已加载保存的预测 ({item.get('timestamp', '')})")

    except Exception as e:
        traceback.print_exc()
        QMessageBox.warning(host, "错误", "加载失败: " + str(e))


def on_delete_saved_prediction(host):
    """删除选中的已保存预测（支持多选），确认后落盘。

    功能:
        收集选中项索引并按降序删除，保存后重新加载列表。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 二次确认框，选择「否」时直接返回；
        - 索引按降序删除，避免删除后下标错乱；
        - 调用 save_saved_predictions（JSON + SQLite）与 load_saved_predictions（重建列表），
          并在状态栏提示删除条数；
        - 未选中时弹窗提示；删除异常弹窗「删除失败」，不中断界面。
    """
    fav_list = host._get_favorites_list()
    if not fav_list:
        QMessageBox.information(host, "提示", "收藏列表不可用")
        return
    selected_items = fav_list.selectedItems()
    if not selected_items:
        QMessageBox.information(host, "提示", "请先选择要删除的预测")
        return

    count = len(selected_items)
    msg = f"确定要删除这 {count} 条预测记录吗？" if count > 1 else "确定要删除这条预测记录吗？"
    reply = QMessageBox.question(host, "确认删除", msg,
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    if reply != QMessageBox.StandardButton.Yes:
        return

    try:
        # 获取所有要删除的索引（降序排列，避免删除后索引错乱）
        indices_to_delete = []
        for item in selected_items:
            idx = item.data(1000)
            if idx is not None:
                indices_to_delete.append(idx)

        indices_to_delete.sort(reverse=True)

        if hasattr(host, '_saved_predictions_data'):
            for idx in indices_to_delete:
                if idx < len(host._saved_predictions_data):
                    del host._saved_predictions_data[idx]

        save_saved_predictions(host)
        load_saved_predictions(host)
        host.statusBar().showMessage(f"已删除 {len(indices_to_delete)} 条预测记录")
    except Exception as e:
        QMessageBox.warning(host, "错误", "删除失败: " + str(e))


def on_clear_saved_predictions(host):
    """清空全部已保存预测，二次确认后落盘。

    功能:
        二次确认后把内存列表置空，保存并重新加载列表。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 二次确认框，选择「否」时不执行；
        - 写 host._saved_predictions_data = []，调用 save_saved_predictions（JSON + SQLite）
          与 load_saved_predictions；
        - 列表本来就为空时弹窗「没有可清空的预测记录」；
        - 清空异常弹窗「清空失败」，不中断界面。
    """
    if not hasattr(host, '_saved_predictions_data') or len(host._saved_predictions_data) == 0:
        QMessageBox.information(host, "提示", "没有可清空的预测记录")
        return

    reply = QMessageBox.question(host, "确认清空", "确定要清空所有已保存的预测吗？此操作不可恢复！",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    if reply != QMessageBox.StandardButton.Yes:
        return

    try:
        host._saved_predictions_data = []
        save_saved_predictions(host)
        load_saved_predictions(host)
    except Exception as e:
        QMessageBox.warning(host, "错误", "清空失败: " + str(e))


def on_show_saved_prediction_detail(host):
    """弹窗显示某条已保存预测的明细（号码、特别码、算法、置信度、时间）。

    功能:
        按列表项隐藏索引取出记录，构建只读详情对话框（号码球、号码属性、置信度）。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 模态 dialog.exec() 阻塞到用户关闭；
        - 号码球按 LotteryConfig 波色着色，特别码带「+」与深色边框；
        - 号码属性含和值、跨度、单双比、大小比（由本节现有号码计算）；
        - 未选中行时弹窗提示；字段缺失时用「—」/0 占位，不抛 KeyError；
        - 详情构建异常弹窗「查看详情失败」。
    """
    fav_list = host._get_favorites_list()
    if not fav_list:
        QMessageBox.information(host, "提示", "收藏列表不可用")
        return
    current_item = fav_list.currentItem()
    if not current_item:
        QMessageBox.information(host, "提示", "请先选择一条预测记录")
        return

    try:
        idx = current_item.data(1000)
        if idx is None or not hasattr(host, '_saved_predictions_data'):
            return

        item = host._saved_predictions_data[idx]
        numbers = sorted(item.get('numbers', []))
        special = item.get('special', 0)
        algorithm = item.get('algorithm', '未知')
        timestamp = item.get('timestamp', '')
        data_period = item.get('data_period', '')
        confidence_info = item.get('confidence_info', {})
        is_reverse = item.get('is_reverse', False)
        is_enhanced = item.get('is_enhanced', False)

        # 构建详情对话框
        dialog = QDialog(host)
        dialog.setWindowTitle("预测详情 - " + algorithm)
        dialog.resize(550, 500)

        layout = QVBoxLayout(dialog)

        # 基本信息
        info_html = '<div style="font-size: 15px; line-height: 1.8;">'
        info_html += '<p><b>算法：</b><span style="color: #3498DB; font-weight: bold;">' + algorithm + '</span>'
        if is_reverse:
            info_html += ' <span style="color: #E74C3C; font-weight: bold;">(反向模式)</span>'
        if is_enhanced:
            info_html += ' <span style="color: #2ECC71; font-weight: bold;">(增强版)</span>'
        info_html += '</p>'
        info_html += '<p><b>保存时间：</b>' + timestamp + '</p>'
        info_html += '<p><b>对应期数：</b>第 ' + str(data_period) + ' 期数据</p>'
        info_html += '</div>'

        info_label = QLabel()
        info_label.setTextFormat(Qt.TextFormat.RichText)
        info_label.setText(info_html)
        layout.addWidget(info_label)

        # 号码展示
        nums_label = QLabel("预测号码")
        # 分区标题样式：16px字号，粗体，上方留10px间距
        nums_label.setStyleSheet("font-size: 16px; font-weight: bold; margin-top: 10px;")
        layout.addWidget(nums_label)

        nums_widget = QWidget()
        nums_layout = QHBoxLayout(nums_widget)
        nums_layout.setSpacing(8)

        for n in numbers:
            colors = LotteryConfig.get_number_color(n)
            btn = QPushButton(str(n).zfill(2))
            btn.setFixedSize(48, 48)
            # 正码圆形按钮样式 - 号码对应颜色填充
            btn.setStyleSheet("""
                QPushButton {
                    background-color: """ + colors['border'] + """;
                    color: #FFFFFF;
                    border: none;
                    border-radius: 24px;
                    font-size: 18px;
                    font-weight: bold;
                }
            """)
            nums_layout.addWidget(btn)

        if special and special > 0:
            plus_label = QLabel("+")
            # 特别码前的加号样式：20px字号，粗体，灰色；暗色改用次要文字令牌
            _register_prediction_theme(
                host, plus_label,
                "font-size: 20px; font-weight: bold; color: #666;",
                "font-size: 20px; font-weight: bold; color: " + PREDICTION_DARK_TOKENS['secondary'] + ";")
            nums_layout.addWidget(plus_label)

            sp_colors = LotteryConfig.get_number_color(special)
            sp_btn = QPushButton(str(special).zfill(2))
            sp_btn.setFixedSize(48, 48)
            # 特别码圆形按钮样式 - 号码颜色填充+深色边框（与正码区分）
            sp_btn.setStyleSheet("""
                QPushButton {
                    background-color: """ + sp_colors['border'] + """;
                    color: #FFFFFF;
                    border: 2px solid #333;
                    border-radius: 24px;
                    font-size: 18px;
                    font-weight: bold;
                }
            """)
            nums_layout.addWidget(sp_btn)

        nums_layout.addStretch()
        layout.addWidget(nums_widget)

        # 号码属性
        props_label = QLabel("号码属性")
        # 号码属性标题样式：16px字号，粗体，上方留15px间距
        props_label.setStyleSheet("font-size: 16px; font-weight: bold; margin-top: 15px;")
        layout.addWidget(props_label)

        sum_val = sum(numbers)
        span_val = max(numbers) - min(numbers) if numbers else 0
        odd_count = sum(1 for n in numbers if n % 2 == 1)
        big_count = sum(1 for n in numbers if n > 24)

        props_html = '<table style="border-collapse: collapse; width: 100%; font-size: 15px;">'
        props_html += '<tr><td style="padding: 6px 10px; border: 1px solid #DDD; font-weight: bold; width: 100px;">和值</td>'
        props_html += '<td style="padding: 6px 10px; border: 1px solid #DDD;">' + str(sum_val) + '</td>'
        props_html += '<td style="padding: 6px 10px; border: 1px solid #DDD; font-weight: bold;">跨度</td>'
        props_html += '<td style="padding: 6px 10px; border: 1px solid #DDD;">' + str(span_val) + '</td></tr>'
        props_html += '<tr><td style="padding: 6px 10px; border: 1px solid #DDD; font-weight: bold;">单双比</td>'
        props_html += '<td style="padding: 6px 10px; border: 1px solid #DDD;">单' + str(odd_count) + ':双' + str(len(numbers) - odd_count) + '</td>'
        props_html += '<td style="padding: 6px 10px; border: 1px solid #DDD; font-weight: bold;">大小比</td>'
        props_html += '<td style="padding: 6px 10px; border: 1px solid #DDD;">大' + str(big_count) + ':小' + str(len(numbers) - big_count) + '</td></tr>'
        props_html += '</table>'

        props_label2 = QLabel()
        props_label2.setTextFormat(Qt.TextFormat.RichText)
        props_label2.setText(props_html)
        layout.addWidget(props_label2)

        # 置信度信息
        if confidence_info:
            conf_label = QLabel("置信度分析")
            # 置信度分析标题样式：16px字号，粗体，上方留15px间距
            conf_label.setStyleSheet("font-size: 16px; font-weight: bold; margin-top: 15px;")
            layout.addWidget(conf_label)

            conf_text = QTextEdit()
            conf_text.setReadOnly(True)
            conf_text.setMaximumHeight(120)

            conf_str = ""
            for key, value in confidence_info.items():
                if isinstance(value, (int, float)):
                    conf_str += f"{key}: {value:.2f}\n"
                else:
                    conf_str += f"{key}: {value}\n"
            conf_text.setPlainText(conf_str)
            layout.addWidget(conf_text)

        # 关闭按钮
        close_btn = QPushButton("关闭")
        # 详情对话框关闭按钮样式 - 蓝色系（关闭/确认操作）
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498DB;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 24px;
                font-size: 15px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #2980B9; }
        """)
        # 关闭按钮点击信号：关闭保存预测详情对话框
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        dialog.exec()

    except Exception as e:
        traceback.print_exc()
        QMessageBox.warning(host, "错误", "查看详情失败: " + str(e))


def on_compare_saved_predictions(host):
    """对比选中的多条已保存预测，计算共同号码并高亮展示。

    功能:
        统计选中记录中各号码出现次数，构建频率区与详细对比表，重复号码加黄色边框。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 少于 2 条时提示无法对比，直接返回；
        - 模态 dialog.exec() 阻塞到用户关闭；
        - 共同号码按出现次数从高到低排列，出现≥2 次的号码在表格中加 2px 黄框；
        - 只读 host._saved_predictions_data，不修改/不写盘；
        - 记录损坏时跳过该条；对比失败弹窗提示，不影响列表数据。
    """
    fav_list = host._get_favorites_list()
    if not fav_list:
        QMessageBox.information(host, "提示", "收藏列表不可用")
        return
    selected_items = fav_list.selectedItems()
    if len(selected_items) < 2:
        QMessageBox.information(host, "提示", "请至少选择2条预测记录进行对比\n（按住Ctrl或Shift多选）")
        return

    if not hasattr(host, '_saved_predictions_data'):
        return

    try:
        # 获取选中的预测数据
        selected_data = []
        for item in selected_items:
            idx = item.data(1000)
            if idx is not None and idx < len(host._saved_predictions_data):
                selected_data.append(host._saved_predictions_data[idx])

        if len(selected_data) < 2:
            QMessageBox.information(host, "提示", "请至少选择2条有效预测记录")
            return

        # 统计号码出现次数
        num_counter = {}
        for entry in selected_data:
            for n in entry.get('numbers', []):
                num_counter[n] = num_counter.get(n, 0) + 1

        # 构建对比对话框
        dialog = QDialog(host)
        dialog.setWindowTitle(f"对比预测结果 ({len(selected_data)}条)")
        dialog.resize(700, 550)

        layout = QVBoxLayout(dialog)

        # 共识号码统计
        consensus_label = QLabel("号码出现频率")
        # 频率统计标题样式：16px字号，粗体，下方留8px间距
        consensus_label.setStyleSheet("font-size: 16px; font-weight: bold; margin-bottom: 8px;")
        layout.addWidget(consensus_label)

        # 按出现次数排序显示
        freq_widget = QWidget()
        freq_layout = QVBoxLayout(freq_widget)
        freq_layout.setSpacing(4)

        sorted_nums = sorted(num_counter.items(), key=lambda x: (-x[1], x[0]))
        for count in range(len(selected_data), 0, -1):
            nums_with_count = [n for n, c in sorted_nums if c == count]
            if nums_with_count:
                row_widget = QWidget()
                row_layout = QHBoxLayout(row_widget)
                row_layout.setContentsMargins(0, 0, 0, 0)

                count_label = QLabel(f"出现{count}次:")
                count_label.setFixedWidth(70)
                # 频率行左侧计数标签样式：粗体，灰色文字
                count_label.setStyleSheet("font-weight: bold; color: #666;")
                row_layout.addWidget(count_label)

                for n in sorted(nums_with_count):
                    colors = LotteryConfig.get_number_color(n)
                    num_btn = QPushButton(str(n).zfill(2))
                    num_btn.setFixedSize(36, 36)
                    # 频率展示号码圆形按钮样式 - 36px小圆球，号码颜色填充
                    num_btn.setStyleSheet(f"""
                        QPushButton {{
                            background-color: {colors['border']};
                            color: #FFFFFF;
                            border: none;
                            border-radius: 18px;
                            font-size: 15px;
                            font-weight: bold;
                        }}
                    """)
                    row_layout.addWidget(num_btn)

                row_layout.addStretch()
                freq_layout.addWidget(row_widget)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setMaximumHeight(180)
        scroll_area.setWidget(freq_widget)
        layout.addWidget(scroll_area)

        # 详细对比表格
        table_label = QLabel("详细对比")
        # 详细对比标题样式：16px字号，粗体，上下留间距
        table_label.setStyleSheet("font-size: 16px; font-weight: bold; margin-top: 15px; margin-bottom: 8px;")
        layout.addWidget(table_label)

        table = QTableWidget()
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(["序号", "算法/模式", "预测号码", "特别码"])
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        table.verticalHeader().setVisible(False)
        table.setAlternatingRowColors(True)

        table.setRowCount(len(selected_data))
        for i, entry in enumerate(selected_data):
            # 序号
            idx_item = QTableWidgetItem(str(i + 1))
            idx_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            table.setItem(i, 0, idx_item)

            # 算法名称
            algo_name = entry.get('algorithm', '未知')
            mode_str = ""
            if entry.get('is_reverse'):
                mode_str = " (反向)"
            elif entry.get('is_enhanced'):
                mode_str = " (增强)"
            algo_item = QTableWidgetItem(algo_name + mode_str)
            algo_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            table.setItem(i, 1, algo_item)

            # 号码（用按钮显示）
            nums_widget = QWidget()
            nums_layout = QHBoxLayout(nums_widget)
            nums_layout.setContentsMargins(4, 2, 4, 2)
            nums_layout.setSpacing(3)

            numbers = sorted(entry.get('numbers', []))
            for n in numbers:
                colors = LotteryConfig.get_number_color(n)
                count = num_counter.get(n, 1)
                border_style = "border: 2px solid #F1C40F;" if count >= 2 else "border: none;"
                num_btn = QPushButton(str(n).zfill(2))
                num_btn.setFixedSize(32, 32)
                # 对比表格内号码圆形按钮样式 - 32px小圆球
                num_btn.setStyleSheet(f"""
                    QPushButton {{
                        background-color: {colors['border']};
                        color: #FFFFFF;
                        {border_style}
                        border-radius: 16px;
                        font-size: 15px;
                        font-weight: bold;
                    }}
                """)
                nums_layout.addWidget(num_btn)

            nums_layout.addStretch()
            table.setCellWidget(i, 2, nums_widget)

            # 特别码
            special = entry.get('special', 0)
            sp_item = QTableWidgetItem(str(special).zfill(2) if special else "-")
            sp_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if special:
                sp_colors = LotteryConfig.get_number_color(special)
                sp_item.setForeground(QColor(sp_colors['border']))
                sp_font = sp_item.font()
                sp_font.setBold(True)
                sp_item.setFont(sp_font)
            table.setItem(i, 3, sp_item)

        table.resizeRowsToContents()
        layout.addWidget(table)

        # 底部提示
        tip_label = QLabel("💡 黄色边框标记的是在多条预测中重复出现的号码")
        # 底部提示标签样式：15px字号，浅灰文字，上方留5px间距
        tip_label.setStyleSheet("color: #999; font-size: 15px; padding-top: 5px;")
        layout.addWidget(tip_label)

        # 关闭按钮
        close_btn = QPushButton("关闭")
        # 对比对话框关闭按钮样式 - 蓝色系（关闭/确认操作）
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498DB;
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px 24px;
                font-size: 15px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #2980B9; }
        """)
        # 关闭按钮点击信号：关闭对比预测结果对话框
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        dialog.exec()

    except Exception as e:
        traceback.print_exc()
        QMessageBox.warning(host, "错误", "对比失败: " + str(e))


def on_collect_prediction(host):
    """把当前预测加入收藏列表。

    功能:
        从结果区读出当前算法名与号码球号码，组装一条记录追加到 host.collected_predictions。
    参数:
        host: 主窗口实例；读取 host.prediction_display 文本与 prediction_number_layout 中的号码球。
    返回:
        None。
    注意/副作用:
        - 只追加到内存列表 host.collected_predictions，并在状态栏提示条数，不写盘；
        - 号码来自 prediction_number_layout 中的 NumberButton，特别码固定记 0；
        - 没有可收藏结果时弹窗提示先预测；
        - 重复号码允许重复收藏（用于对比共识）。
    """
    display_text = host.prediction_display.text()
    if not display_text or display_text == "等待预测...":
        QMessageBox.information(host, "提示", "当前没有预测结果可收藏")
        return
    algo_name = "未知算法"
    if 0 <= host.current_algorithm_index < len(LotteryConfig.ALGORITHMS):
        algo_name = LotteryConfig.ALGORITHMS[host.current_algorithm_index][0]
    numbers = []
    for i in range(host.prediction_number_layout.count()):
        item = host.prediction_number_layout.itemAt(i)
        if item and item.widget() and isinstance(item.widget(), NumberButton):
            numbers.append(item.widget().get_number())
    entry = {
        'algorithm': algo_name,
        'numbers': sorted(numbers),
        'special': 0,
        'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    host.collected_predictions.append(entry)
    host.statusBar().showMessage("已收藏第 " + str(len(host.collected_predictions)) + " 个预测结果")


def on_compare_collected(host):
    """对比所有收藏结果，统计共识号并在界面高亮。

    功能:
        统计收藏记录中各号码出现次数，构建对比表并把出现≥2 次的共识号标绿。
    参数:
        host: 主窗口实例；读取 host.collected_predictions。
    返回:
        None。
    注意/副作用:
        - 模态 dialog.exec() 阻塞到用户关闭；
        - 只读 host.collected_predictions，不修改内存数据、不写盘；
        - 收藏为空时弹窗提示并返回；共识号在表格行内标绿并在底部汇总；
        - 表格行颜色按当前主题（暗色 #CDD6F4 / 亮色 #000000）。
    """
    if not host.collected_predictions:
        QMessageBox.information(host, "提示", "还没有收藏任何预测结果")
        return
    dialog = QDialog(host)
    dialog.setWindowTitle("对比收藏结果")
    dialog.resize(900, 500)
    layout = QVBoxLayout(dialog)

    # 统计共识号
    num_counter = Counter()
    for entry in host.collected_predictions:
        for n in entry.get('numbers', []):
            num_counter[n] += 1

    consensus_nums = {n for n, c in num_counter.items() if c >= 2}

    table = QTableWidget()
    table.setColumnCount(4)
    table.setHorizontalHeaderLabels(["时间", "算法", "正码", "特别码"])
    table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    table.setItemDelegate(PreserveColorDelegate(table))
    table.setRowCount(len(host.collected_predictions))

    fg_color = "#CDD6F4" if host.is_dark_mode else "#000000"

    for i, entry in enumerate(host.collected_predictions):
        ts_item = QTableWidgetItem(entry.get('timestamp', ''))
        ts_item.setForeground(QColor(fg_color))
        table.setItem(i, 0, ts_item)

        algo_item = QTableWidgetItem(entry.get('algorithm', ''))
        algo_item.setForeground(QColor(fg_color))
        table.setItem(i, 1, algo_item)

        nums = entry.get('numbers', [])
        nums_str = '  '.join(str(n).zfill(2) for n in nums)
        nums_item = QTableWidgetItem(nums_str)
        # 共识号绿色高亮
        if any(n in consensus_nums for n in nums):
            nums_item.setForeground(QColor("#2ECC71"))
        else:
            nums_item.setForeground(QColor(fg_color))
        table.setItem(i, 2, nums_item)

        sp_item = QTableWidgetItem(str(entry.get('special', 0)).zfill(2))
        sp_item.setForeground(QColor(fg_color))
        table.setItem(i, 3, sp_item)

    layout.addWidget(table)

    # 共识号展示
    if consensus_nums:
        consensus_str = '  '.join(str(n).zfill(2) for n in sorted(consensus_nums))
        consensus_label = QLabel("共识号（出现2次以上）: " + consensus_str)
        # 共识号标签样式：鲜绿色文字，粗体，15px字号，5px内边距
        consensus_label.setStyleSheet("color: #2ECC71; font-weight: bold; font-size: 15px; padding: 5px;")
        layout.addWidget(consensus_label)

    close_btn = QPushButton("关闭")
    # 关闭按钮点击信号：关闭收藏对比结果对话框
    close_btn.clicked.connect(dialog.accept)
    layout.addWidget(close_btn)

    dialog.exec()


def on_clear_collected(host):
    """清空收藏列表（二次确认，仅内存）。

    功能:
        二次确认后清空内存中的收藏列表，并在状态栏提示。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 只清空 host.collected_predictions 内存列表，不写盘、不刷新收藏列表控件；
        - 收藏为空时弹窗提示并返回；取消确认不执行。
    """
    if not host.collected_predictions:
        QMessageBox.information(host, "提示", "收藏已为空")
        return
    reply = QMessageBox.question(host, "确认", "确定清空所有收藏的预测结果吗？",
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    if reply == QMessageBox.StandardButton.Yes:
        host.collected_predictions.clear()
        host.statusBar().showMessage("收藏已清空")


# ╔══════════════════════════════════════════════════════════════════╗
# ║  [权重调节] 综合推荐子算法权重                                        ║
# ╚══════════════════════════════════════════════════════════════════╝

def on_weight_adjust_clicked(host):
    """打开算法权重调节对话框，保存后写回 INI。

    功能:
        为 11 个子算法各建一个 0~100 滑块（默认取 host.custom_weights），确定后写回并保存。
    参数:
        host: 主窗口实例；读取 host.custom_weights 作为滑块初值，写回 host.custom_weights。
    返回:
        None。
    注意/副作用:
        - 模态 dialog.exec() 阻塞；滑块拖动只更新旁边数值标签，不改全局权重；
        - 「确定」后逐个写 host.custom_weights 并调用 _save_ini_config（写 INI），
          状态栏提示「权重设置已更新」；
        - 「重置默认」调用 reset_weights（同样写盘）；「取消」放弃修改；
        - 用户取消时不改权重；权重表缺失时按默认权重初始化对话框。
    """
    sub_algorithms = [
        '冷热数字', '单双', '大小', '遗漏值', '连号邻号',
        '尾数分布', '区间分布', '轮盘赌', '历史相似性', '泊松分布', '玄学算法'
    ]

    dialog = QDialog(host)
    dialog.setWindowTitle("算法权重调节")
    dialog.resize(500, 500)
    layout = QVBoxLayout(dialog)

    layout.addWidget(QLabel("调整综合推荐算法中各子算法的权重（0-100）："))

    sliders = {}
    for name in sub_algorithms:
        row = QHBoxLayout()
        label = QLabel(name)
        label.setMinimumWidth(90)
        row.addWidget(label)

        slider = QSlider(Qt.Orientation.Horizontal)
        slider.setRange(0, 100)
        default_val = host.custom_weights.get(name, 50)
        slider.setValue(default_val)
        row.addWidget(slider)

        val_label = QLabel(str(default_val))
        val_label.setMinimumWidth(30)
        # 权重滑块值变化信号：实时更新旁边的数值标签
        slider.valueChanged.connect(lambda v, lbl=val_label: lbl.setText(str(v)))
        row.addWidget(val_label)

        layout.addLayout(row)
        sliders[name] = slider

    layout.addStretch()

    btn_layout = QHBoxLayout()
    ok_btn = QPushButton("确定")
    # 确定按钮点击信号：接受对话框，保存权重设置
    ok_btn.clicked.connect(dialog.accept)
    btn_layout.addWidget(ok_btn)

    reset_btn = QPushButton("重置默认")
    # 重置默认按钮点击信号：将所有算法权重恢复为默认值50
    reset_btn.clicked.connect(lambda: reset_weights(host, sliders, sub_algorithms))
    btn_layout.addWidget(reset_btn)

    cancel_btn = QPushButton("取消")
    # 取消按钮点击信号：拒绝对话框，放弃权重修改
    cancel_btn.clicked.connect(dialog.reject)
    btn_layout.addWidget(cancel_btn)

    layout.addLayout(btn_layout)

    if dialog.exec() == QDialog.DialogCode.Accepted:
        for name in sub_algorithms:
            host.custom_weights[name] = sliders[name].value()
        # 保存权重设置
        host._save_ini_config()
        host.statusBar().showMessage("权重设置已更新")


def reset_weights(host, sliders, sub_algorithms):
    """把算法权重恢复为出厂默认值并写回 INI。

    功能:
        把每个子算法滑块与 host.custom_weights 都置为 50，然后保存 INI。
    参数:
        host: 主窗口实例；权重写回 host.custom_weights。
        sliders (dict[str, QSlider]): 算法名→滑块控件，用于同步界面显示。
        sub_algorithms (list[str]): 需要重置的算法名列表。
    返回:
        None。
    注意/副作用:
        - 逐个 setValue(50) 并写 host.custom_weights，最后 _save_ini_config（写盘）；
        - 只是重置为 50，不做归一化；
        - 控件缺失会抛 KeyError（调用方保证传参来自同一对话框）。
    """
    for name in sub_algorithms:
        sliders[name].setValue(50)
        host.custom_weights[name] = 50
    # 保存重置后的权重
    host._save_ini_config()


# ╔══════════════════════════════════════════════════════════════════╗
# ║  [预测管理] 预测文件读写 / 类型切换 / 结果显示 / 弹球动画                  ║
# ╚══════════════════════════════════════════════════════════════════╝

def get_prediction_file(host, pred_type=None, variant='current'):
    """按预测类型与版本拼接结果文件名（不创建文件）。

    功能:
        以 host.last_prediction_file 的目录/主文件名为基准，按类型名与版本后缀拼路径。
    参数:
        host: 主窗口实例；以 host.last_prediction_file 的目录与主文件名作为基准。
        pred_type (str | None): algorithm / random / ml；None 时取当前预测类型。
        variant (str): 'current'=本次预测，'last'=上次预测，'old'=升级前旧格式。
    返回:
        str: 绝对路径。命名规则为「<基准名>_<类型名>[_本次|_上次].json」，
            旧格式无后缀，仅用于读取迁移。
    注意/副作用:
        - 纯字符串拼接，不创建/不检查目录；
        - 未知 pred_type 时类型名退化为「预测」，文件仍会生成但不会被正常流程读取。
    """
    if pred_type is None:
        pred_type = host._prediction_type
    base_dir = os.path.dirname(host.last_prediction_file)
    base_name = os.path.basename(host.last_prediction_file)
    name_part = base_name.replace('.json', '')
    type_names = {
        'algorithm': '算法预测',
        'random': '随机抽取',
        'ml': '机器学习',
    }
    type_name = type_names.get(pred_type, '预测')
    if variant == 'old':
        # 兼容升级前的旧格式文件名（无_本次/_上次后缀）
        return os.path.join(base_dir, f"{name_part}_{type_name}.json")
    variant_suffix = '_本次' if variant == 'current' else '_上次'
    return os.path.join(base_dir, f"{name_part}_{type_name}{variant_suffix}.json")


def save_prediction(host, predictions, confidence_info=None, algorithm_name="", special_num=0, pred_type=None):
    """保存某类型的预测结果，并把旧的「本次」滚动为「上次」。

    功能:
        规范化号码与置信度后组装记录，先把旧「本次」文件移动为「上次」，再写新结果并更新内存缓存。
    参数:
        host: 主窗口实例。
        predictions (iterable[int]): 正码；内部统一转 Python int 后排序。
        confidence_info (dict | None): 号码→置信度；兼容 numpy 整数键。
        algorithm_name (str): 算法名称，写入记录用于回溯。
        special_num (int): 特别码，0 表示无。
        pred_type (str | None): 预测类型，None 时取当前类型。
    返回:
        None（失败也只打印日志，不抛异常）。
    注意/副作用:
        - 记录含 numbers/special/confidence_info/algorithm/timestamp/data_period/
          pred_type/data_fingerprint；写盘走 host._safe_write_json（原子写）；
        - 先 move 旧「本次」到「上次」，move 失败不影响新结果写入；
        - 写 host._prediction_results[pred_type]（内存缓存）；
        - 整个函数包在 try/except 中：序列化或写盘失败只打印「保存预测结果失败」，
          内存缓存不会被更新，界面保持原状。
    """
    if pred_type is None:
        pred_type = host._prediction_type
    try:
        # 确保所有数字都是Python原生int，避免numpy int64序列化问题
        sorted_preds = [int(n) for n in sorted(predictions)]
        # 置信度key也转为int
        # 【修复numpy整数bug】原代码isinstance(k, (int,))不检查numpy整数类型，
        # numpy.int32/int64的key会原样保留，后续JSON序列化会失败
        safe_conf = {}
        if confidence_info:
            # 【规范】numpy统一由lib.math_algo导出
            _np = get_numpy()
            for k, v in confidence_info.items():
                if _np is not None and isinstance(k, _np.integer):
                    safe_conf[int(k)] = float(v) if hasattr(v, '__float__') else v
                elif isinstance(k, int):
                    safe_conf[int(k)] = float(v) if hasattr(v, '__float__') else v
                else:
                    safe_conf[k] = float(v) if hasattr(v, '__float__') else v
        # 获取当前数据最新期号，用于判断是否过期
        data_period = get_latest_period(host.historical_data)

        data = {
            'numbers': sorted_preds,
            'special': int(special_num) if special_num else 0,
            'confidence_info': safe_conf,
            'algorithm': algorithm_name,
            'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'data_period': data_period,
            'pred_type': pred_type,
            'data_fingerprint': host._compute_data_fingerprint(),
        }
        # 先将旧的"本次预测"文件移动为"上次预测"（如果存在）
        current_file = get_prediction_file(host, pred_type, variant='current')
        last_file = get_prediction_file(host, pred_type, variant='last')
        if os.path.exists(current_file):
            try:
                import shutil  # 作用说明：把旧「本次预测」文件原子移动为「上次预测」，减少磁盘 I/O。
                # 【优化】使用move代替copy2，减少磁盘I/O
                shutil.move(current_file, last_file)
            except Exception:
                pass  # 移动失败不影响新预测保存

        # 保存新的预测结果作为"本次预测"
        host._safe_write_json(current_file, data)

        # 同时保存到内存缓存
        host._prediction_results[pred_type] = data
    except Exception as e:
        print("保存预测结果失败: " + str(e))


def load_prediction(host, pred_type=None):
    """加载指定预测类型的 JSON 结果（优先新格式，回退旧格式）。

    功能:
        先读「本次」文件，无有效号码时回退升级前旧格式文件，并把结果写入内存缓存。
    参数:
        host: 主窗口实例。
        pred_type (str): algorithm / random / ml。
    返回:
        dict | None: 解析成功返回结果字典，文件不存在或损坏返回 None。
    注意/副作用:
        - 读盘但不写盘；成功时写 host._prediction_results[pred_type]；
        - JSON 解析失败时打印错误并返回 None；旧格式缺少字段时用默认值补齐；
        - 调用方需按 None 处理「尚无结果」。
    """
    if pred_type is None:
        pred_type = host._prediction_type
    try:
        # 优先加载"本次预测"
        file_path = get_prediction_file(host, pred_type, variant='current')
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if data.get('numbers'):
                host._prediction_results[pred_type] = data
                return data
        # 回退加载旧格式文件（兼容升级前数据）
        old_file = get_prediction_file(host, pred_type, variant='old')
        if os.path.exists(old_file):
            with open(old_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if data.get('numbers'):
                host._prediction_results[pred_type] = data
                return data
    except Exception as e:
        print("加载预测结果失败: " + str(e))
    return None


def load_last_prediction_for_type(host, pred_type):
    """加载指定类型的「上次预测」结果，用于上次/本次对比显示。

    功能:
        读取「上次」文件，号码非空时返回记录。
    参数:
        host: 主窗口实例。
        pred_type (str): algorithm / random / ml。
    返回:
        dict | None: 含 numbers/algorithm/special；不存在时返回 None。
    注意/副作用:
        只读盘，不写缓存；文件损坏时返回 None（对比区隐藏），不影响本次预测显示。
    """
    try:
        file_path = get_prediction_file(host, pred_type, variant='last')
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if data.get('numbers'):
                return data
    except Exception as e:
        print("加载上次预测结果失败: " + str(e))
    return None


def on_prediction_type_changed(host, pred_type):
    """切换预测类型（算法/随机/机器学习）并恢复该类型上次的结果。

    功能:
        更新三枚类型按钮与 host._prediction_type，加载该类型结果并按数据指纹判断是否失效。
    参数:
        host: 主窗口实例。
        pred_type (str): 目标类型。
    返回:
        None。
    注意/副作用:
        - 写 host._prediction_type、三枚 type_btn 的 checked 状态与 data_status_label；
        - 指纹不一致时只显示「数据已更新，请重新预测」，不展示旧结果；
        - 指纹一致时调用 display_prediction_data 渲染，并按期号差给出过期提示；
        - 无缓存结果时清空号码球布局与置信度文本并显示「等待预测...」；
        - 末尾调用 host._save_ini_config 写盘（记住类型选择）；
        - 未知类型直接忽略。
    """
    # 更新按钮状态
    host.type_btn_algorithm.setChecked(pred_type == 'algorithm')
    host.type_btn_random.setChecked(pred_type == 'random')
    host.type_btn_ml.setChecked(pred_type == 'ml')

    host._prediction_type = pred_type

    # 尝试加载对应类型的预测结果
    data = load_prediction(host, pred_type)
    if data and data.get('numbers'):
        # 【Bug修复】验证数据指纹，确保缓存预测结果与当前数据一致
        # 之前仅检查期号，若用户修改号码但不改期号，会显示过期预测
        saved_fingerprint = data.get('data_fingerprint', '')
        current_fingerprint = host._compute_data_fingerprint()
        if saved_fingerprint and current_fingerprint and saved_fingerprint != current_fingerprint:
            # 数据已变化，缓存预测结果失效，不显示
            host.prediction_display.setText("数据已更新，请重新预测")
            host.algorithm_source_label.hide()
            host.data_status_label.setText("⚠ 数据已变化，上次预测结果已失效，请重新预测")
            host.data_status_label.show()
        else:
            # 显示结果（传入pred_type以正确加载上次预测对比）
            display_prediction_data(host, data, pred_type_override=pred_type)

            # 检查数据是否过期（仅检查期号作为辅助提示）
            current_period = get_latest_period(host.historical_data)
            saved_period = data.get('data_period', '')
            if current_period and saved_period and current_period != saved_period:
                host.data_status_label.setText(f"⚠ 数据已更新（保存时期号：{saved_period}，当前期号：{current_period}），建议重新预测")
                host.data_status_label.show()
            else:
                host.data_status_label.hide()
    else:
        # 没有保存的结果，显示默认提示
        host.prediction_display.setText("等待预测...")
        host.algorithm_source_label.hide()
        while host.prediction_number_layout.count():
            item = host.prediction_number_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        host.prediction_stats_label.setText("统计信息：等待预测...")
        host.confidence_analysis_text.clear()
        host.data_status_label.hide()

    # 保存预测类型选择
    host._save_ini_config()


def display_prediction_data(host, data, pred_type_override=None):
    """把预测结果字典渲染到结果区（号码、特别码、算法、置信度与统计）。

    功能:
        生成顶部文本、号码球网格、加号/特别码与置信度标签，并刷新上次/本次对比区。
    参数:
        host: 主窗口实例。
        data (dict): 至少含 numbers；可选 special / algorithm / confidence_info。
        pred_type_override (str | None): 覆盖「上次结果」的类型，用于按类型回填展示。
    返回:
        None。
    注意/副作用:
        - 清空并重建 prediction_number_layout（旧球 deleteLater）；
        - 写 prediction_display、algorithm_source_label（随后隐藏，仅保留内部数据）、
          confidence_display_label；
        - 生肖/五行实时读取 host.zodiac_binding / zodiac_elements；
        - 末尾调用 _apply_prediction_ball_size 应用尺寸，并调用 _update_last_vs_current_display；
        - data 为空或 numbers 非法时直接返回；字段缺失用默认值补齐，不抛 KeyError。
    """
    numbers = data.get('numbers', [])
    special = data.get('special', 0)
    confidence_info = data.get('confidence_info', {})
    algorithm = data.get('algorithm', '')
    timestamp = data.get('timestamp', '')

    if not numbers:
        return

    sorted_preds = sorted(numbers)

    # 显示顶部文本
    algo_display = algorithm if algorithm else "预测"
    display_text = algo_display + " → " + ' '.join(str(n).zfill(2) for n in sorted_preds)
    if special and special > 0:
        display_text += " + " + str(special).zfill(2)
    if timestamp:
        display_text += f"  ({timestamp})"
    host.prediction_display.setText(display_text)

    # 算法来源标签
    if algorithm:
        if "机器学习" in algorithm:
            label_color = "#3498DB"
        elif "随机" in algorithm:
            label_color = "#E67E22"
        else:
            label_color = "#2ECC71"
        host.algorithm_source_label.setText("来源: " + algorithm)
        # 算法来源标签样式 - 胶囊形标签，颜色随算法类型变化
        host.algorithm_source_label.setStyleSheet(
            "font-size: 15px; font-weight: bold; padding: 4px 12px; "
            "border-radius: 12px; background-color: #FFFFFF; color: " + label_color + "; "
            "border: 1px solid " + label_color + ";"
        )
        # 【已移除界面显示】来源标签已从界面删除，仅保留内部数据
        host.algorithm_source_label.hide()
    else:
        host.algorithm_source_label.hide()

    # 清空号码球
    while host.prediction_number_layout.count():
        item = host.prediction_number_layout.takeAt(0)
        if item.widget():
            item.widget().deleteLater()
    host.confidence_display_label = None

    # 显示号码球
    for i, num in enumerate(sorted_preds):
        zodiac = host.zodiac_binding.get(num, "")
        element = host.zodiac_elements.get(num, "")
        ball = NumberBallWithZodiac(num, zodiac, element, is_special=False, font_size=host.ball_label_font_size)
        row = i // 7
        col = i % 7
        host.prediction_number_layout.addWidget(ball, row * 2, col)

    # 显示特别码
    if special and special > 0:
        zodiac = host.zodiac_binding.get(special, "")
        element = host.zodiac_elements.get(special, "")
        ball = NumberBallWithZodiac(special, zodiac, element, is_special=True, font_size=host.ball_label_font_size)
        special_col = len(sorted_preds)
        if special_col >= 7:
            special_col = 0
            special_row = (len(sorted_preds) // 7) * 2
        else:
            special_row = 0
        plus_label = QLabel("+")
        plus_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        plus_size = host._prediction_ball_size.get('plus_size', 24)
        # 正码与特别码之间的加号样式：动态字号，粗体，灰色；暗色改用次要文字令牌
        _register_prediction_theme(
            host, plus_label,
            f"font-size: {plus_size}px; font-weight: bold; color: #666666;",
            f"font-size: {plus_size}px; font-weight: bold; color: {PREDICTION_DARK_TOKENS['secondary']};")
        host.prediction_number_layout.addWidget(plus_label, special_row, special_col)
        host.prediction_number_layout.addWidget(ball, special_row, special_col + 1)

    # 置信度显示
    if confidence_info:
        confidence_text_parts = []
        for num in sorted_preds:
            conf = confidence_info.get(num, 0)
            if conf > 0:
                if conf >= 60:
                    level = "高"
                elif conf >= 30:
                    level = "中"
                else:
                    level = "低"
                confidence_text_parts.append(str(num).zfill(2) + ":" + "{:.1f}".format(conf) + "%「" + level + "」")

        if confidence_text_parts:
            host.confidence_display_label = QLabel("  ".join(confidence_text_parts))
            # 置信度条目较多时必须换行，否则单行文本会把号码球网格撑到窗口之外
            host.confidence_display_label.setWordWrap(True)
            host.confidence_display_label.setAlignment(
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            # 置信度展示标签样式：15px字号，5px内边距，浅灰背景，4px圆角
            host.confidence_display_label.setStyleSheet("font-size: 15px; padding: 5px; background-color: #F8F9FA; border-radius: 4px;")
            host.prediction_number_layout.addWidget(host.confidence_display_label, len(sorted_preds) // 6 + 1, 0, 1, 6)

    # 应用当前尺寸设置
    host._apply_prediction_ball_size()

    # 更新"上次预测 vs 本次预测"对比显示区
    pred_type = pred_type_override if pred_type_override is not None else host._prediction_type
    host._update_last_vs_current_display(
        sorted_preds, algorithm, current_special=special,
        pred_type_override=pred_type
    )


def animate_prediction_balls(host, balls):
    """播放号码球入场动画：缩放 + 透明度，逐个延迟落下。

    功能:
        为每个号码球按 120ms 间隔安排 QTimer.singleShot，延迟调用 show_ball_with_bounce。
    参数:
        host: 主窗口实例；动画组引用保存在 host._ball_animations，防止被 GC。
        balls (list[tuple]): 由 display_predictions 生成的 (号码球控件, 号码) 元组列表。
    返回:
        None。
    注意/副作用:
        - 对每个球按 120ms 间隔延迟调用 show_ball_with_bounce（首个再等 100ms，
          等 _apply_prediction_ball_size 设完固定尺寸后再读目标尺寸，避免动画被覆盖）；
        - 清空并复用 host._ball_animations 列表保存动画引用，防止 GC 提前回收；
        - 球控件已被删除时 RuntimeError 被捕获并跳过该球；无球时直接返回。
    """
    if not balls:
        return

    # 【关键】保存所有动画对象的引用到实例属性
    # QPropertyAnimation和QGraphicsOpacityEffect如果没被引用，
    # 会被Python GC提前回收，导致动画中途停止（Qt的C++对象被删除）
    if not hasattr(host, '_ball_animations'):
        host._ball_animations = []
    host._ball_animations.clear()

    delay_per_ball = 120  # 每个球之间的出现间隔（毫秒），值越大越慢

    # 延迟100ms后才开始第一个球的动画
    # 原因：_display_predictions末尾会调用_apply_prediction_ball_size()，
    # 该方法会遍历所有号码球设置固定尺寸。如果动画同时启动，
    # 尺寸设置会与动画的setFixedSize冲突，导致弹跳效果失效。
    # 等待100ms确保尺寸设置先完成，动画再读取正确的目标尺寸。
    for idx, (widget, _) in enumerate(balls):
        total_delay = 100 + idx * delay_per_ball
        QTimer.singleShot(total_delay, lambda w=widget: show_ball_with_bounce(host, w))


def show_ball_with_bounce(host, widget):
    """单个号码球的弹跳动画（缩放回弹 + 淡入）。

    功能:
        先缩到 30% 再经 115% 过冲回弹到目标尺寸，同时 400ms 淡入，结束后清理图形效果。
    参数:
        host: 主窗口实例。
        widget (QWidget): 目标号码球控件，尺寸由当前几何决定。
    返回:
        None。
    注意/副作用:
        - 使用 QGraphicsOpacityEffect + QParallelAnimationGroup（缩放 500ms、淡入 400ms）；
        - 动画结束回调 _on_finished 清除 GraphicsEffect 并恢复固定尺寸；
        - 动画对象追加到 host._ball_animations，避免中途被 GC 回收；
        - 控件为 None 或 C++ 对象已被删除（RuntimeError）时静默返回；
        - 任何异常兜底时确保 widget 可见且清除图形效果（宁可无动画也不能不显示）。
    """
    try:
        if widget is None:
            return
        # 检查widget是否还有效（可能已被清空）
        # 清空prediction_number_layout时widget的C++对象会被deleteLater删除
        try:
            widget.isVisible()
        except RuntimeError:
            return  # widget的C++对象已被删除，跳过动画

        # 第1步：记录目标尺寸
        # 此时_apply_prediction_ball_size已设置好最终尺寸，
        # 读取当前尺寸作为动画的目标值
        target_width = widget.width()
        target_height = widget.height()
        if target_width <= 0:
            target_width = 48   # 默认号码球宽度
        if target_height <= 0:
            target_height = 60  # 默认号码球高度（球+生肖+五行）

        # 第2步：设置初始小尺寸（30%），让球从"小"开始弹跳放大
        start_w = max(10, int(target_width * 0.3))
        start_h = max(10, int(target_height * 0.3))
        widget.setFixedSize(start_w, start_h)
        widget.setVisible(True)  # 从隐藏状态变为可见

        # 第3步：创建淡入效果（透明度动画）
        # QGraphicsOpacityEffect：Qt图形效果，控制widget的整体透明度
        opacity_effect = QGraphicsOpacityEffect(widget)
        widget.setGraphicsEffect(opacity_effect)
        opacity_effect.setOpacity(0.0)  # 初始完全透明

        # QPropertyAnimation：属性动画，通过插值驱动opacity属性从0→1
        # b"opacity" 是bytes格式的属性名（PyQt6要求bytes而非str）
        fade_anim = QPropertyAnimation(opacity_effect, b"opacity", widget)
        fade_anim.setDuration(400)              # 淡入持续400ms
        fade_anim.setStartValue(0.0)            # 起始：完全透明
        fade_anim.setEndValue(1.0)              # 结束：完全不透明
        # OutCubic：先快后慢的缓动曲线，淡入更自然
        fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)

        # 第4步：创建缩放回弹动画（尺寸动画）
        # QPropertyAnimation动画驱动widget的size属性（QSize）
        # 动画轨迹：30%尺寸 → 115%尺寸 → 100%目标尺寸
        size_anim = QPropertyAnimation(widget, b"size", widget)
        size_anim.setDuration(500)              # 缩放持续500ms
        size_anim.setStartValue(QSize(start_w, start_h))
        # 中间关键帧（进度50%时）：放大到115%，产生"过冲"弹跳感
        mid_w = int(target_width * 1.15)
        mid_h = int(target_height * 1.15)
        size_anim.setKeyValueAt(0.5, QSize(mid_w, mid_h))
        # 终点：回到目标尺寸
        size_anim.setEndValue(QSize(target_width, target_height))
        # OutBounce：模拟物理弹跳的缓动曲线，到终点时有回弹效果
        size_anim.setEasingCurve(QEasingCurve.Type.OutBounce)

        # 第5步：组合并行动画组（淡入+缩放同时播放）
        # QParallelAnimationGroup：并行执行多个动画
        # 对比QSequentialAnimationGroup（串行），并行动画更流畅
        group = QParallelAnimationGroup(widget)
        group.addAnimation(fade_anim)
        group.addAnimation(size_anim)

        # 第6步：动画结束回调 - 清理效果，恢复固定尺寸
        def _on_finished():
            """动画结束回调：清理图形效果并恢复号码球最终尺寸。

            功能:
                动画播完后移除 QGraphicsOpacityEffect，并把控件尺寸精确设回目标值。
            参数:
                无。
            返回:
                None。
            注意/副作用:
                - 调用 widget.setGraphicsEffect(None) 与 setFixedSize；
                - 控件已被 deleteLater 时 RuntimeError 被捕获忽略。
            """
            try:
                # 清除GraphicsEffect，避免影响后续渲染性能
                widget.setGraphicsEffect(None)
                # 确保最终尺寸精确（动画浮点插值可能有微小偏差）
                widget.setFixedSize(target_width, target_height)
            except RuntimeError:
                pass  # widget的C++对象已被删除，忽略

        # 动画完成信号：连接清理回调，清除GraphicsEffect并恢复固定尺寸
        group.finished.connect(_on_finished)

        # 第7步：保存动画引用并启动
        # 必须保存引用到host._ball_animations，否则局部变量作用域结束后
        # Python GC会回收QPropertyAnimation和QGraphicsOpacityEffect，
        # 导致其内部C++对象被析构，动画中途停止
        host._ball_animations.append(group)
        host._ball_animations.append(opacity_effect)

        group.start()

    except Exception:
        # 异常兜底：动画出错时确保widget正常显示
        # 宁可没有动画也不能让号码球不显示
        try:
            if widget is not None:
                widget.setVisible(True)
                widget.setGraphicsEffect(None)
        except RuntimeError:
            pass


def save_last_prediction(host, predictions, confidence_info=None, algorithm_name="", special_num=0):
    """保存最后一次预测结果（兼容旧接口，默认保存当前类型）。

    功能:
        直接转调 save_prediction，参数原样传递（默认 pred_type=None）。
    参数:
        host: 主窗口实例。
        predictions (iterable[int]): 正码。
        confidence_info (dict | None): 号码→置信度百分比。
        algorithm_name (str): 算法名称。
        special_num (int): 特别码，0 表示无。
    返回:
        None。
    注意/副作用:
        写盘失败由 save_prediction 内部处理；本函数不改变内存状态。
    """
    save_prediction(host, predictions, confidence_info, algorithm_name, special_num)


def load_last_prediction(host):
    """启动时加载三种类型的「上次预测」并回填到界面对应缓存。

    功能:
        依次加载 algorithm/random/ml，恢复算法与 ML 的数据指纹，然后显示当前类型结果。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 写 host._prediction_results（由 load_prediction），并按算法/ML 结果恢复
          _data_fingerprint_at_last_predict / _data_fingerprint_at_last_ml_predict；
        - 末尾调用 on_prediction_type_changed（会写 INI、重建结果区）；
        - 任一类型文件缺失/损坏时仅跳过该类型，不影响其他类型回填。
    """
    # 预加载所有类型的预测结果
    for ptype in ['algorithm', 'random', 'ml']:
        load_prediction(host, ptype)
    # 恢复数据指纹（防止没有新数据时重复预测 - 算法和机器学习各自独立）
    algo_data = host._prediction_results.get('algorithm')
    if algo_data and algo_data.get('data_fingerprint'):
        host._data_fingerprint_at_last_predict = algo_data['data_fingerprint']
    ml_data = host._prediction_results.get('ml')
    if ml_data and ml_data.get('data_fingerprint'):
        host._data_fingerprint_at_last_ml_predict = ml_data['data_fingerprint']
    # 显示当前类型的结果
    on_prediction_type_changed(host, host._prediction_type)



# ╔══════════════════════════════════════════════════════════════════╗
# ║  [预测流水线] 算法/随机/ML 预测、模式开关、结果显示、生肖组选               ║
# ╚══════════════════════════════════════════════════════════════════╝

def on_algorithm_changed(host, index):
    """算法下拉变化：更新当前算法编号、说明文字与特殊算法状态。

    功能:
        记录当前算法索引，从注册表取说明写入说明标签，并保存选择。
    参数:
        host: 主窗口实例。
        index (int): 新索引；-1 表示无选择。
    返回:
        None。
    注意/副作用:
        - 写 host.current_algorithm_index 与 algorithm_desc_label 文本；
        - 调用 host._save_ini_config 写盘（每次切换都保存算法选择）；
        - 索引越界时保持原值并提示；说明文字从注册表读取，缺失时用「未知算法」。
    """
    # 功能：algorithm changed事件处理
    host.current_algorithm_index = index
    if index < len(LotteryConfig.ALGORITHMS):
        _, desc = LotteryConfig.ALGORITHMS[index]
        host.algorithm_desc_label.setText(desc)
    # 保存算法选择
    host._save_ini_config()


def compute_data_fingerprint(host):
    """计算当前历史数据的 MD5 指纹，用于「无新数据禁止预测」判断。

    功能:
        以排序键 JSON 序列化历史数据，计算 MD5 十六进制摘要。
    参数:
        host: 主窗口实例；读取 host.historical_data。
    返回:
        str: 32 位十六进制摘要；数据为空时返回空字符串。
    注意/副作用:
        - 纯只读计算，不写盘、不改 host；
        - 使用 MLPredictionModel._json_default_handler 处理 numpy 等非标准类型；
        - 序列化异常时返回空字符串（视为「无指纹」），锁定逻辑会保守放行。
    """
    # 计算当前历史数据的MD5指纹
    #
    # 用于判断数据是否已更新：
    # - 预测锁定：指纹相同时禁止重复预测（没有新数据无法预测）
    # - 模型缓存：指纹保存到预测结果文件中作为记录
    import hashlib  # 作用说明：对排序后的历史数据计算 MD5 指纹，用于「无新数据禁止预测」判断。
    # 【修复序列化bug】添加default参数处理numpy等非标准类型，防止序列化失败
    data_str = json.dumps(host.historical_data, sort_keys=True, ensure_ascii=False, default=MLPredictionModel._json_default_handler)
    return hashlib.md5(data_str.encode('utf-8')).hexdigest()


def on_predict_clicked(host):
    """「算法预测」按钮：校验数据/锁定状态后把计算推迟到事件循环下一拍。

    功能:
        校验历史数据条数与重入/锁定状态，切到算法类型并安排主线程计算。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 预测中禁止重入（host._is_predicting）；
        - 开启「锁定」且数据指纹未变时拒绝预测；
        - 写 host._is_predicting=True、禁用 predict_button、状态栏提示，
          并调用 QApplication.processEvents 立即刷新；
        - 用 QTimer.singleShot(0, ...) 让按钮禁用状态先重绘，再在主线程执行；
        - 计算过程放在主线程是为了绕开 QThread 内 C 扩展栈溢出问题；
        - 无历史数据或算法未选择时弹提示并返回，不进入计算；
        - 启动异常时复位 _is_predicting 与按钮并弹窗。
    """
    # 功能12：性能优化 - 异步预测
    if len(host.historical_data) < 10:
        QMessageBox.warning(host, "数据不足", "历史数据不足10条，请先添加更多数据")
        return

    # 如果正在预测，则忽略新请求
    if host._is_predicting:
        QMessageBox.information(host, "请等待", "预测正在进行中，请等待完成")
        return

    # 检查数据是否已更新（仅在启用锁定时检查，没有新数据无法预测）
    current_fingerprint = host._compute_data_fingerprint()
    if host._block_no_new_data and host._data_fingerprint_at_last_predict is not None and current_fingerprint == host._data_fingerprint_at_last_predict:
        QMessageBox.warning(host, "数据未更新", "数据未更新，无法预测。\n请先更新历史数据后再进行预测。\n（可在预测面板取消「无新数据锁定预测」复选框来关闭此限制）")
        return

    # 切换到算法预测类型
    host._on_prediction_type_changed('algorithm')

    # 清理旧线程引用
    host._predict_thread = None
    host._predict_worker = None

    # 设置预测状态
    host._is_predicting = True
    host.predict_button.setEnabled(False)
    host.statusBar().showMessage("正在预测...")
    QApplication.processEvents()  # 立即更新UI

    try:
        # 计算确定性种子
        seed = host._set_deterministic_seed()

        # 【彻底修复0xC0000409】不再使用QThread执行预测，
        # sklearn/PyTorch的C扩展在QThread中运行会导致Windows栈缓冲区溢出
        # 改为在主线程中通过QTimer延迟执行，避免阻塞UI事件循环初始化
        QTimer.singleShot(0, lambda: host._run_prediction_in_main_thread(seed))
    except Exception as e:
        host._is_predicting = False
        host.predict_button.setEnabled(True)
        import traceback  # 作用说明：启动预测失败时打印完整堆栈，便于定位线程/依赖问题。
        traceback.print_exc()
        QMessageBox.warning(host, "错误", "启动预测失败:\n" + str(e))
        host.statusBar().showMessage("预测失败")


def run_prediction_in_main_thread(host, seed):
    """在主线程执行算法计算并分发完成/错误回调。

    功能:
        创建预测器、调用注册表算法（失败时降级综合推荐/随机）、应用生肖组选与置信度，
        最后调用完成回调。
    参数:
        host: 主窗口实例。
        seed (int | None): 确定性模式下的随机种子，None 表示不设置。
    返回:
        None。
    注意/副作用:
        - 设置等待光标（setOverrideCursor）并在 finally 恢复；
        - 多次调用 statusBar().showMessage + processEvents 更新进度，期间保持事件循环响应；
        - 算法异常时先降级到 DEFAULT_ALGORITHM_INDEX，再失败则用 random.sample 兜底；
        - 生肖组选择失败时保留原始预测；置信度异常时置空；
        - 成功后调用 on_predict_finished，异常时调用 on_predict_error，保证按钮状态复位；
        - 窗口关闭标志为真时直接返回。
    """
    # 【彻底修复0xC0000409】在主线程中执行预测，避免QThread中sklearn/PyTorch C扩展导致栈溢出
    if getattr(host, '_window_closing', False):
        return
    # 设置等待光标，提示用户正在计算
    QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
    try:
        host.statusBar().showMessage("预测中... 10% - 正在初始化预测器...")
        QApplication.processEvents()

        # 【Bug修复】种子已由 _set_deterministic_seed() 设置（random.seed + np.random.seed），
        # 此处不再重复调用，避免全局随机状态被二次污染
        # （seed 参数保留用于传递给子模型，但不再次设置全局种子）
        predictor = PredictionAlgorithms(host.historical_data, _light_mode=False)

        host.statusBar().showMessage("预测中... 30% - 正在执行预测算法...")
        QApplication.processEvents()

        # 执行预测算法（编号→计算方法/号码数量全部来自 lib/algorithms.py 注册表，
        # 本文件不再维护第二份 lambda 字典，避免与主窗口调度分叉）
        algorithm_index = host.current_algorithm_index
        algo = get_algorithm(algorithm_index)
        if algo is None:
            algo = get_algorithm(DEFAULT_ALGORITHM_INDEX)
        count = algo.count

        host.statusBar().showMessage("预测中... 50% - 正在计算...")
        QApplication.processEvents()

        predictions = None
        try:
            predictions = run_algorithm(predictor, algorithm_index,
                                        enhanced=host.enhanced_mode,
                                        reverse=host.reverse_mode)
        except Exception as e:
            import traceback  # 作用说明：算法执行失败时打印堆栈，随后降级到综合推荐。
            traceback.print_exc()
            print(f"[算法{algorithm_index}执行失败，降级到综合推荐] {e}")
            try:
                predictions = run_algorithm(predictor, DEFAULT_ALGORITHM_INDEX, count=count,
                                            enhanced=host.enhanced_mode,
                                            reverse=host.reverse_mode)
            except Exception:
                predictions = sorted(random.sample(range(1, 50), count))

        # 【生肖组选择】非特别码算法（注册表 is_special=False）应用12生肖组选6组逻辑
        # 特别码算法（编号 21/22）只预测1个号码，不适用生肖组选择
        zodiac_applied = False
        if not algo.is_special and predictions and len(predictions) >= 6:
            try:
                # 获取所有49个数字的原始得分
                _, all_scores = predictor.get_prediction_scores(algorithm_index, 49)
                if all_scores and len(all_scores) >= 12:
                    zodiac_predictions = host._select_zodiac_group_numbers(all_scores)
                    if zodiac_predictions and len(zodiac_predictions) == 6:
                        predictions = zodiac_predictions
                        zodiac_applied = True
            except Exception:
                pass  # 生肖选择失败时保留原始预测结果

        host.statusBar().showMessage("预测中... 80% - 正在计算置信度...")
        QApplication.processEvents()

        # 计算置信度
        confidence_info = {}
        if algo.is_special:
            confidence_info = {predictions[0]: 75.0} if predictions else {}
        else:
            try:
                if zodiac_applied and all_scores:
                    # 【Bug修复】生肖组选择后，置信度基于生肖选出的数字重新计算
                    # 而非原始算法top-N的数字，确保置信度与显示号码匹配
                    confidence_info = {}
                    for num in predictions:
                        raw_score = all_scores.get(num, 0)
                        max_score = max(all_scores.values()) if all_scores else 1
                        confidence_info[num] = max(0, min(100, (raw_score / max_score * 60) + 40)) if max_score > 0 else 50.0
                else:
                    _, confidence_info = predictor.get_prediction_scores(algorithm_index, len(predictions))
            except Exception:
                confidence_info = {}

        host.statusBar().showMessage("预测中... 100% - 预测完成")
        QApplication.processEvents()

        # 释放预测器
        del predictor

        # 直接调用完成回调
        host._on_predict_finished(predictions, confidence_info)

    except Exception as e:
        import traceback  # 作用说明：预测流程异常时打印完整堆栈，并转交错误回调。
        traceback.print_exc()
        host._on_predict_error(str(e))
    finally:
        QApplication.restoreOverrideCursor()


def on_predict_finished(host, predictions, confidence_info):
    """算法预测完成回调：恢复按钮、渲染结果并写入历史/持久化。

    功能:
        复位预测状态、过滤 1~49 号码、调用 _display_predictions 渲染并保存数据指纹。
    参数:
        host: 主窗口实例。
        predictions (list[int]): 预测正码。
        confidence_info (dict | None): 号码→置信度。
    返回:
        None。
    注意/副作用:
        - 写 host._is_predicting=False，恢复 predict_button；
        - 写 host._data_fingerprint_at_last_predict（防止无新数据重复预测）；
        - 调用 host._display_predictions（重建结果区、写预测文件/历史）；
        - 结果渲染异常被捕获后提示「预测完成但显示结果时出错」，不丢失已算出的结果；
        - finally 调用 _detach_worker 做线程引用轻量清理；
        - 窗口已关闭时直接返回。
    """
    # 预测完成回调（由主线程 QTimer.singleShot 调度，不再是线程回调）
    if getattr(host, '_window_closing', False):
        return
    host._is_predicting = False
    try:
        host.predict_button.setEnabled(True)
    except RuntimeError:
        return  # 控件已销毁
    try:
        # 输入验证：确保预测结果有效
        if not predictions or not isinstance(predictions, (list, tuple)):
            QMessageBox.warning(host, "预测失败", "算法返回了空结果，请检查历史数据是否充足")
            host.statusBar().showMessage("预测失败：结果为空")
            return
        # 过滤无效号码（确保1-49范围内的整数，支持numpy整数）
        valid_predictions = []
        for n in predictions:
            try:
                n_int = int(n)
                if 1 <= n_int <= 49:
                    valid_predictions.append(n_int)
            except (ValueError, TypeError):
                continue
        predictions = valid_predictions
        if not predictions:
            QMessageBox.warning(host, "预测失败", "算法返回的号码全部无效")
            return
        # 确保confidence_info是字典
        if not isinstance(confidence_info, dict):
            confidence_info = {}
        host._display_predictions(predictions, confidence_info)
        # 保存数据指纹，防止没有新数据时重复预测
        host._data_fingerprint_at_last_predict = host._compute_data_fingerprint()

        # 显示更详细的状态信息
        mode_text = "反向模式" if host.reverse_mode else "标准模式"
        enhanced_text = "增强版" if host.enhanced_mode else "经典版"
        host.statusBar().showMessage(f"预测完成 ({mode_text} - {enhanced_text})")
    except Exception as e:
        import traceback  # 作用说明：结果展示失败时打印堆栈，界面只提示「显示异常」，不丢失已算结果。
        traceback.print_exc()
        QMessageBox.warning(host, "显示结果错误", "预测完成但显示结果时出错:\n" + str(e))
        host.statusBar().showMessage("预测完成（显示异常）")
    finally:
        # 轻量清理：只断开信号和置空引用；预测已在主线程执行，无 QThread 需要 wait
        # 完整清理由下次预测开始时的 _safe_cleanup_thread 处理
        host._detach_worker('_predict_thread', '_predict_worker')


def on_predict_error(host, error_msg):
    """算法预测错误回调：复位状态并弹窗显示错误信息。

    功能:
        复位预测标志与按钮，打印异常堆栈并弹窗提示错误文本。
    参数:
        host: 主窗口实例。
        error_msg (str): 底层异常文本。
    返回:
        None。
    注意/副作用:
        - 写 host._is_predicting=False 并恢复 predict_button；
        - 弹窗 + 状态栏提示；finally 调用 _detach_worker 清理线程引用；
        - 窗口已关闭时直接返回；控件已销毁时 RuntimeError 被吞掉。
    """
    # 异步预测错误回调
    if getattr(host, '_window_closing', False):
        return
    host._is_predicting = False
    try:
        host.predict_button.setEnabled(True)
    except RuntimeError:
        pass
    import traceback  # 作用说明：预测错误回调中打印堆栈，便于排查底层异常。
    traceback.print_exc()
    try:
        QMessageBox.warning(host, "预测错误", f"预测过程出错:\n{error_msg}")
        host.statusBar().showMessage("预测失败")
    except RuntimeError:
        pass  # 控件已销毁
    finally:
        # 轻量清理：只断开信号和置空引用，不wait线程
        host._detach_worker('_predict_thread', '_predict_worker')


def on_random_draw_clicked(host):
    """「随机抽取」按钮：按当前配置随机生成一组号码并展示。

    功能:
        用轮盘赌抽样 6 个正码、预测特别码，重建号码球并写入历史/持久化。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 使用 random 模块抽样；确定性模式开启时先调用 set_deterministic_seed，
          保证相同数据得到相同结果；
        - 写 prediction_display / algorithm_source_label（随后隐藏）、重建号码球布局；
        - 特别码在对比显示更新之前计算，避免随机数消耗顺序不一致；
        - 写 host.prediction_history、调用 _refresh_prediction_history_table / _save_prediction_history /
          _save_last_prediction（历史与预测文件落盘）；
        - 末尾调用 _apply_prediction_ball_size；
        - 数据不足时弹窗；随机过程异常弹窗并复位状态栏。
    """
    # 功能：random draw clicked事件处理
    try:
        if len(host.historical_data) < 10:
            QMessageBox.warning(host, "数据不足", "历史数据不足10条，请先添加更多数据")
            return

        # 切换到随机抽取类型
        host._on_prediction_type_changed('random')

        # 设置确定性种子
        host._set_deterministic_seed()

        # 【修复0xC0000409】主线程中也要使用轻量模式，避免TF/PyTorch初始化导致栈溢出
        predictor = PredictionAlgorithms(host.historical_data, _light_mode=True)
        predictions = predictor.roulette_selection(6)
        sorted_preds = sorted(predictions)

        # 显示抽取结果文本
        display_text = "随机抽取 → " + ' '.join(str(n).zfill(2) for n in sorted_preds)

        # 预测特别码（必须在对比显示更新之前计算，避免随机数消耗不一致）
        special_num = host._predict_special_number(sorted_preds)

        # 更新"上次结果 vs 本次结果"对比显示区
        host._update_last_vs_current_display(sorted_preds, "随机抽取", current_special=special_num)
        host.prediction_display.setText(display_text)
        # 显示算法来源标签
        host.algorithm_source_label.setText("来源: 随机抽取")
        # 随机抽取来源标签样式 - 橙色系（随机操作标识色）
        #   font-size: 15px;              字体大小：15px
        #   font-weight: bold;            字体：粗体
        #   padding: 4px 12px;            内边距：上下4px，左右12px
        #   border-radius: 12px;          圆角：12px（胶囊形）
        #   background-color: #FFFFFF;    背景色：白色
        #   color: #E67E22;               文字颜色：橙色
        #   border: 1px solid #E67E22;    边框：1px 橙色实线
        host.algorithm_source_label.setStyleSheet(
            "font-size: 15px; font-weight: bold; padding: 4px 12px; "
            "border-radius: 12px; background-color: #FFFFFF; color: #E67E22; "
            "border: 1px solid #E67E22;"
        )
        # 【已移除界面显示】来源标签已从界面删除，仅保留内部数据
        host.algorithm_source_label.hide()

        # 特别码已在上方提前计算（special_num变量），此处不再重复计算

        # 清空并显示号码球
        while host.prediction_number_layout.count():
            item = host.prediction_number_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        # 清除已删除的置信度标签引用
        host.confidence_display_label = None

        # 更新显示文本
        if special_num > 0:
            display_text = "随机抽取 → " + ' '.join(str(n).zfill(2) for n in sorted_preds) + " + " + str(special_num).zfill(2)
            host.prediction_display.setText(display_text)

        # 正码球+生肖+五行
        for i, num in enumerate(sorted_preds):
            zodiac = host.zodiac_binding.get(num, "")
            element = host.zodiac_elements.get(num, "")
            ball = NumberBallWithZodiac(num, zodiac, element, is_special=False, font_size=host.ball_label_font_size)
            row = i // 7
            col = i % 7
            host.prediction_number_layout.addWidget(ball, row * 2, col)

        # 特别码球+生肖+五行
        if special_num > 0:
            zodiac = host.zodiac_binding.get(special_num, "")
            element = host.zodiac_elements.get(special_num, "")
            plus_label = QLabel("+")
            plus_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            plus_size = host._prediction_ball_size.get('plus_size', 24)
            # 随机抽取特别码前的加号样式：动态字号，粗体，橙色（特别码标识色）
            plus_label.setStyleSheet(f"font-size: {plus_size}px; font-weight: bold; color: #F39C12;")
            ball = NumberBallWithZodiac(special_num, zodiac, element, is_special=True, font_size=host.ball_label_font_size)
            host.prediction_number_layout.addWidget(plus_label, 0, len(sorted_preds))
            host.prediction_number_layout.addWidget(ball, 0, len(sorted_preds) + 1)

        # 记录到预测历史
        history_entry = {
            'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'algorithm': '随机抽取',
            'numbers': list(sorted_preds),
            'special': special_num
        }
        host.prediction_history.insert(0, history_entry)
        host._refresh_prediction_history_table()
        host._save_prediction_history()
        # 保存最后一次随机抽取结果（含特别码）
        host._save_last_prediction(sorted_preds, algorithm_name="随机抽取", special_num=special_num)

        # 应用当前尺寸设置
        host._apply_prediction_ball_size()

        host.statusBar().showMessage("随机抽取完成")
    except Exception as e:
        import traceback  # 作用说明：随机抽取失败时打印堆栈并在弹窗中显示错误文本。
        error_msg = str(e)
        traceback.print_exc()
        QMessageBox.warning(host, "随机抽取错误", "随机抽取过程出错:\n" + error_msg)
        host.statusBar().showMessage("随机抽取失败")


def on_lock_predict_toggled(host, checked):
    """「预测锁定」开关：控制是否禁止在数据未更新时重复预测。

    功能:
        写入 host._block_no_new_data 并保存 INI。
    参数:
        host: 主窗口实例。
        checked (bool): True=启用锁定。
    返回:
        None。
    注意/副作用:
        - 仅修改布尔状态并写 INI，不触发生效判断之外的副作用。
    """
    # 预测锁定开关切换：控制是否启用「无新数据无法预测」
    host._block_no_new_data = checked
    host._save_ini_config()


def on_model_cache_toggled(host, checked):
    """「模型缓存」开关：控制机器学习是否复用 ml_models.pkl。

    功能:
        写入 host._use_model_cache 并保存 INI。
    参数:
        host: 主窗口实例。
        checked (bool): True=使用缓存。
    返回:
        None。
    注意/副作用:
        - 仅改标志与写 INI；缓存文件损坏时由训练流程自动重建（见 ml 模块）。
    """
    # 模型缓存开关切换：控制是否使用ml_models.pkl训练文件
    host._use_model_cache = checked
    host._save_ini_config()


def on_ml_predict_clicked(host):
    """「机器学习预测」按钮：校验后创建后台线程执行预测。

    功能:
        校验数据量/重入/锁定状态，切换类型，设置种子并把训练任务延后到事件循环下一拍。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 预测中禁止重入；数据不足 20 条、锁定且指纹未变时提示并返回；
        - 写 host._is_predicting=True、禁用 predict_button、状态栏提示并 processEvents；
        - 通过 QTimer.singleShot(0) 在主线程执行（不再用 QThread，规避 sklearn C 扩展栈溢出）；
        - 创建前清空旧线程引用，异常时复位按钮并弹窗；
        - 收尾统一走 _detach_worker。
    """
    # 【需求2-BUG修复】机器学习预测按钮 - 异步执行避免界面卡顿
    if len(host.historical_data) < 20:
        QMessageBox.warning(host, "数据不足", "机器学习需要至少20条历史数据")
        return

    if host._is_predicting:
        QMessageBox.information(host, "请等待", "预测正在进行中，请等待完成")
        return

    # 检查数据是否已更新（仅在启用锁定时检查 - 机器学习独立指纹）
    current_fingerprint = host._compute_data_fingerprint()
    if host._block_no_new_data and host._data_fingerprint_at_last_ml_predict is not None and current_fingerprint == host._data_fingerprint_at_last_ml_predict:
        QMessageBox.warning(host, "数据未更新", "数据未更新，无法预测。\n请先更新历史数据后再进行预测。\n（可在预测面板取消「无新数据锁定预测」复选框来关闭此限制）")
        return

    # 切换到机器学习类型
    host._on_prediction_type_changed('ml')

    # 清理旧线程引用
    host._ml_predict_thread = None
    host._ml_predict_worker = None

    host._is_predicting = True
    host.predict_button.setEnabled(False)
    host.statusBar().showMessage("机器学习预测中，请稍候...")
    QApplication.processEvents()  # 立即更新UI

    try:
        # 计算确定性种子
        seed = host._set_deterministic_seed()

        # 【彻底修复0xC0000409】不再使用QThread执行机器学习预测，
        # sklearn的C扩展在QThread中训练模型会导致Windows栈缓冲区溢出
        # 改为在主线程中通过QTimer延迟执行
        QTimer.singleShot(0, lambda: host._run_ml_prediction_in_main_thread(seed))
    except Exception as e:
        host._is_predicting = False
        host.predict_button.setEnabled(True)
        import traceback  # 作用说明：启动机器学习预测失败时打印完整堆栈。
        traceback.print_exc()
        QMessageBox.warning(host, "错误", "启动机器学习预测失败:\n" + str(e))
        host.statusBar().showMessage("机器学习预测失败")


def run_ml_prediction_in_main_thread(host, seed):
    """在主线程执行机器学习预测计算（用于无 Qt 线程的降级路径）。

    功能:
        创建 MLPredictionModel，执行多模型预测、生肖组选与进度上报，最后调用完成回调。
    参数:
        host: 主窗口实例。
        seed (int | None): 随机种子（仅传给子模型，不在此重复设置全局种子）。
    返回:
        None。
    注意/副作用:
        - 设置等待光标并在 finally 恢复；
        - 训练期间通过 _progress_callback 更新状态栏并 processEvents；
        - 全概率 ≥12 项时调用 _select_zodiac_group_numbers，失败则保留原始预测；
        - 成功后调用 on_ml_predict_finished，异常时调用 on_ml_predict_error；
        - 窗口关闭标志为真时直接返回；
        - 缺 sklearn 时异常由 MLPredictionModel 内部降级或抛出，最终在错误回调提示。
    """
    # 【彻底修复0xC0000409】在主线程中执行机器学习预测，避免QThread中sklearn C扩展导致栈溢出
    if getattr(host, '_window_closing', False):
        return
    # 设置等待光标，提示用户正在计算
    QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
    try:
        host.statusBar().showMessage("机器学习预测中... 5% - 正在准备数据...")
        QApplication.processEvents()

        # 【Bug修复】种子已由 _set_deterministic_seed() 设置（random.seed + np.random.seed），
        # 此处不再重复调用，避免全局随机状态被二次污染
        # （seed 参数保留用于传递给子模型，但不再次设置全局种子）

        # 创建ML模型（主线程中可以安全使用sklearn）
        model = MLPredictionModel(host.historical_data, base_dir=getattr(host, '_ml_data_dir', None))

        # 定义进度回调
        def _progress_callback(percent, msg):
            """机器学习训练进度回调：更新状态栏并保持界面响应。

            功能:
                把训练进度百分比与阶段说明写入状态栏，并处理一次事件循环。
            参数:
                percent (int): 进度百分比（0~100）。
                msg (str): 当前阶段说明。
            返回:
                None。
            注意/副作用:
                - 窗口关闭时直接返回；控件已销毁时 RuntimeError 被捕获；
                - 只更新状态栏与 processEvents，不触碰其他控件。
            """
            if getattr(host, '_window_closing', False):
                return
            try:
                host.statusBar().showMessage(f"机器学习预测中... {percent}% - {msg}")
                QApplication.processEvents()
            except RuntimeError:
                pass

        host.statusBar().showMessage("机器学习预测中... 10% - 正在训练模型...")
        QApplication.processEvents()

        # 执行多模型预测（传入用户选择的缓存开关）
        # predict_with_all_models 现在返回 (predictions, all_probs_dict)
        result = model.predict_with_all_models(
            progress_callback=_progress_callback,
            use_cache=host._use_model_cache)

        if result is None:
            host._on_ml_predict_error("机器学习返回了空结果")
            return

        predictions, all_probs_dict = result

        # 【生肖组选择】应用12生肖组选6组逻辑（允许重复1组）
        if all_probs_dict and len(all_probs_dict) >= 12:
            try:
                zodiac_predictions = host._select_zodiac_group_numbers(all_probs_dict)
                if zodiac_predictions and len(zodiac_predictions) == 6:
                    predictions = zodiac_predictions
            except Exception:
                pass  # 生肖选择失败时保留原始预测结果

        host.statusBar().showMessage("机器学习预测中... 100% - 预测完成")
        QApplication.processEvents()

        # 释放模型
        del model

        # 直接调用完成回调
        host._on_ml_predict_finished(predictions, all_probs_dict)

    except Exception as e:
        import traceback  # 作用说明：机器学习预测流程异常时打印完整堆栈，并转交错误回调。
        traceback.print_exc()
        host._on_ml_predict_error(str(e))
    finally:
        QApplication.restoreOverrideCursor()


def on_ml_predict_finished(host, predictions, all_probs_dict=None):
    """机器学习预测完成回调：渲染号码球、置信度、历史记录与上次对比。

    功能:
        校验并过滤预测号码，预测特别码、换算置信度，重建结果区并写入历史与预测文件。
    参数:
        host: 主窗口实例。
        predictions (list[int]): 正码（兼容 numpy 整数）。
        all_probs_dict (dict | None): 号码→原始概率，用于换算 40~100 的置信度。
    返回:
        None。
    注意/副作用:
        - 写 host._is_predicting=False、_ml_confidence_info、current_prediction_result 相关的
          prediction_display / algorithm_source_label（随后 hide）；
        - 写 host.prediction_history 并调用 _refresh_prediction_history_table / _save_prediction_history，
          以及 _save_last_prediction（结果文件落盘）；
        - 指纹在持久化之后才更新，避免写盘失败时被误判为「已预测」；
        - 过滤后不足 6 个号码时只警告并继续展示；
        - 展示异常被捕获后提示「预测完成但显示出错」；finally 调用 _detach_worker 轻量清理线程引用。
    """
    # 机器学习预测完成回调
    #
    # Args:
    #     predictions: 预测号码列表
    #     all_probs_dict: 所有49个数字的概率字典 {num: prob}，用于计算置信度
    if getattr(host, '_window_closing', False):
        return
    host._is_predicting = False
    try:
        host.predict_button.setEnabled(True)
    except RuntimeError:
        return  # 控件已销毁
    try:
        # 输入验证：确保预测结果有效
        if not predictions or not isinstance(predictions, (list, tuple)):
            QMessageBox.warning(host, "预测失败", "机器学习返回了空结果，请检查历史数据是否充足（至少20条）")
            host.statusBar().showMessage("机器学习预测失败：结果为空")
            return
        # 过滤无效号码（确保1-49范围内的整数，支持numpy整数）
        valid_predictions = []
        for n in predictions:
            try:
                n_int = int(n)
                if 1 <= n_int <= 49:
                    valid_predictions.append(n_int)
            except (ValueError, TypeError):
                continue
        predictions = valid_predictions
        if not predictions:
            QMessageBox.warning(host, "预测失败", "机器学习返回的号码全部无效")
            return
        # 【Bug修复】过滤后检查号码数量，不足6个时给出警告
        if len(predictions) < 6:
            QMessageBox.warning(host, "预测结果不足", f"机器学习仅返回了 {len(predictions)} 个有效号码（需要6个），请检查数据质量")
            host.statusBar().showMessage(f"ML预测结果不足：{len(predictions)}/6")
        sorted_preds = sorted(predictions)
        algo_name = "机器学习预测"
        # ML预测特别码
        ml_special = host._predict_special_number(sorted_preds)

        # 【Bug修复】从all_probs_dict计算置信度，确保ML预测也有置信度信息
        ml_confidence_info = {}
        if all_probs_dict and len(all_probs_dict) == 49:
            max_prob = max(all_probs_dict.values()) if all_probs_dict else 1
            for num in sorted_preds:
                raw_prob = float(all_probs_dict.get(num, 0))
                ml_confidence_info[num] = max(0, min(100, (raw_prob / max_prob * 60) + 40)) if max_prob > 0 else 50.0

        # 显示文本
        if ml_special > 0:
            display_text = algo_name + " → " + ' '.join(str(n).zfill(2) for n in sorted_preds) + " + " + str(ml_special).zfill(2)
        else:
            display_text = algo_name + " → " + ' '.join(str(n).zfill(2) for n in sorted_preds)

        # 更新"上次结果 vs 本次结果"对比显示区
        host._update_last_vs_current_display(sorted_preds, algo_name, current_special=ml_special)

        host.prediction_display.setText(display_text)

        # 算法来源标签（蓝色）
        host.algorithm_source_label.setText("来源: " + algo_name)
        # 机器学习来源标签样式 - 蓝色系（ML/机器学习标识色）
        #   font-size: 15px;              字体大小：15px
        #   font-weight: bold;            字体：粗体
        #   padding: 4px 12px;            内边距：上下4px，左右12px
        #   border-radius: 12px;          圆角：12px（胶囊形）
        #   background-color: #FFFFFF;    背景色：白色
        #   color: #3498DB;               文字颜色：蓝色
        #   border: 1px solid #3498DB;    边框：1px 蓝色实线
        host.algorithm_source_label.setStyleSheet(
            "font-size: 15px; font-weight: bold; padding: 4px 12px; "
            "border-radius: 12px; background-color: #FFFFFF; color: #3498DB; "
            "border: 1px solid #3498DB;"
        )
        # 【已移除界面显示】来源标签已从界面删除，仅保留内部数据
        host.algorithm_source_label.hide()

        # 清空并显示号码球
        while host.prediction_number_layout.count():
            item = host.prediction_number_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        host.confidence_display_label = None

        # 正码球+生肖+五行
        for i, num in enumerate(sorted_preds):
            zodiac = host.zodiac_binding.get(num, "")
            element = host.zodiac_elements.get(num, "")
            ball = NumberBallWithZodiac(num, zodiac, element, is_special=False, font_size=host.ball_label_font_size)
            host.prediction_number_layout.addWidget(ball, 0, i)

        # 特别码球+生肖+五行
        if ml_special > 0:
            zodiac = host.zodiac_binding.get(ml_special, "")
            element = host.zodiac_elements.get(ml_special, "")
            plus_label = QLabel("+")
            plus_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            plus_size = host._prediction_ball_size.get('plus_size', 24)
            # 机器学习特别码前的加号样式：动态字号，粗体，橙色（特别码标识色）
            plus_label.setStyleSheet(f"font-size: {plus_size}px; font-weight: bold; color: #F39C12;")
            ball = NumberBallWithZodiac(ml_special, zodiac, element, is_special=True, font_size=host.ball_label_font_size)
            host.prediction_number_layout.addWidget(plus_label, 0, len(sorted_preds))
            host.prediction_number_layout.addWidget(ball, 0, len(sorted_preds) + 1)

        # 记录到预测历史
        history_entry = {
            'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'algorithm': algo_name,
            'numbers': list(sorted_preds),
            'special': ml_special
        }
        host.prediction_history.insert(0, history_entry)
        host._refresh_prediction_history_table()
        host._save_prediction_history()

        # 保存最后一次ML预测结果（含置信度）
        host._save_last_prediction(sorted_preds, confidence_info=ml_confidence_info, algorithm_name=algo_name, special_num=ml_special)
        # 【Bug修复】指纹保存在预测结果持久化之后，避免非原子操作：
        # 若_save_last_prediction失败（磁盘满），指纹不会保存，用户可重新预测
        host._data_fingerprint_at_last_ml_predict = host._compute_data_fingerprint()

        # 应用当前尺寸设置
        host._apply_prediction_ball_size()

        host.statusBar().showMessage("机器学习预测完成")
    except Exception as e:
        import traceback  # 作用说明：机器学习结果展示失败时打印堆栈，界面提示「显示异常」。
        traceback.print_exc()
        QMessageBox.warning(host, "显示结果错误", "机器学习预测完成但显示结果时出错:\n" + str(e))
        host.statusBar().showMessage("机器学习预测完成（显示异常）")
    finally:
        # 轻量清理：只断开信号和置空引用；机器学习预测同样在主线程执行，无 QThread 需要 wait
        host._detach_worker('_ml_predict_thread', '_ml_predict_worker')


def on_ml_predict_error(host, error_msg):
    """机器学习预测错误回调：复位按钮并提示错误。

    功能:
        复位预测标志与按钮，打印堆栈并弹窗显示错误信息。
    参数:
        host: 主窗口实例。
        error_msg (str): 错误文本。
    返回:
        None。
    注意/副作用:
        - 写 host._is_predicting=False 并恢复 predict_button；
        - 弹窗 + 状态栏提示；控件已销毁时 RuntimeError 被吞掉；
        - 窗口已关闭时直接返回；finally 调用 _detach_worker 释放线程引用。
    """
    # 机器学习预测错误回调
    if getattr(host, '_window_closing', False):
        return
    host._is_predicting = False
    try:
        host.predict_button.setEnabled(True)
    except RuntimeError:
        pass
    import traceback  # 作用说明：机器学习错误回调中打印堆栈，便于排查底层异常。
    traceback.print_exc()
    try:
        QMessageBox.warning(host, "机器学习预测错误", f"机器学习预测过程出错:\n{error_msg}")
        host.statusBar().showMessage("机器学习预测失败")
    except RuntimeError:
        pass  # 控件已销毁
    finally:
        # 轻量清理：只断开信号和置空引用，不wait线程
        host._detach_worker('_ml_predict_thread', '_ml_predict_worker')


def select_zodiac_group_numbers(host, scores_dict, count=6):
    """从 12 个生肖组中选取得分最高的号码，输出 6 个号码。

    功能:
        按 (num-1)%12 分 12 组，每组取最高分，前 5 组各取 1 个，第 6 个取最高分组的次高分。
    参数:
        host: 主窗口实例（本实现不读取 host，保持统一签名）。
        scores_dict (dict[int, float]): 1~49 每个号码的得分。
        count (int): 需要输出的号码个数，默认 6（当前实现固定取 6）。
    返回:
        list[int]: 升序排列的 6 个号码。
    注意/副作用:
        - 纯函数，不读写 host、不写盘；
        - 第 6 个重复最高分组取其组内次高分，因此 6 个号码来自 5 个唯一组
          （49 个数分 12 组，每组至少 4 个，次高分必然存在）；
        - scores_dict 为空时每组得分按 0 处理，仍返回 6 个号码；
        - 组内不足 2 个号码的极端情况会抛 IndexError（正常 1~49 分组不会发生）。
    """
    # 【生肖组选择】从12生肖组中各选最优数字，最终输出6组，允许重复1组
    #
    # 核心逻辑：
    # 1. 将49个数字按 (num-1)%12 分为12生肖组
    # 2. 每组选取得分最高的数字
    # 3. 按组最高分降序排列，取前5组（每组1个数字）
    # 4. 第6组允许重复：取第1组（最高分组）的次高分数字
    # 5. 最终6个数字来自5个唯一生肖组，1组贡献2个数字
    #
    # 参数：
    #     scores_dict: {数字: 得分} 字典，包含1-49所有数字的得分
    #     count: 需要输出的组数（默认6）
    #
    # 返回：
    #     list: 选中的数字列表（6个）
    # 12生肖分组：按 (num-1) % 12 分组
    groups = {i: [] for i in range(12)}
    for num in range(1, 50):
        gid = (num - 1) % 12
        score = scores_dict.get(num, 0)
        groups[gid].append((num, score))

    # 每组取最高分数字，保留完整列表（用于重复选择）
    best_per_group = []
    for gid in range(12):
        nums = groups[gid]
        if nums:
            nums.sort(key=lambda x: x[1], reverse=True)
            best_num, best_score = nums[0]
            best_per_group.append({
                'group_id': gid,
                'best_num': best_num,
                'best_score': best_score,
                'all_nums': nums  # 保留完整排序列表，用于取次高分
            })

    # 按分数降序排列
    best_per_group.sort(key=lambda x: x['best_score'], reverse=True)

    # 选前5组（每组1个数字）
    selected = []
    for i in range(min(5, len(best_per_group))):
        selected.append(best_per_group[i]['best_num'])

    # 第6组：允许重复第1组，取其次高分数字
    # 49个数字分12组，每组至少4个数字，第1组始终有次高分可用
    # 因此取 best_per_group[0] 的次高分数字即可，无需回退分支
    second_num = best_per_group[0]['all_nums'][1][0]
    selected.append(second_num)

    return sorted(selected[:6])


def predict_special_number(host, predictions):
    """按历史特别码的频率加权随机选一个特别码（且不与正码重复）。

    功能:
        统计历史特别码频率并排除正码后做频率加权随机；无频率时等概率随机。
    参数:
        host: 主窗口实例；读取 host.historical_data。
        predictions (iterable[int]): 已预测正码，用于排除。
    返回:
        int: 1~49 的特别码；无可用号码时返回 0。
    注意/副作用:
        - 会消耗全局 random 的随机数状态（影响随机/确定性预测的复现顺序）；
        - 历史数据为空、无候选或异常时返回 0，由调用方决定是否展示；
        - 候选为空时退化为在 1~49 中排除正码后等概率随机。
    """
    # 从历史数据预测特别码（基于频率加权随机）
    try:
        if not host.historical_data:
            return 0
        # 统计历史特别码频率
        special_freq = {}
        for record in host.historical_data:
            sp = record.get('special', 0)
            if sp and 1 <= sp <= 49 and sp not in predictions:
                special_freq[sp] = special_freq.get(sp, 0) + 1
        # 排除已预测的正码
        candidates = {n: c for n, c in special_freq.items() if n not in predictions}
        if not candidates:
            # 无历史频率数据，随机选一个不在正码中的
            available = [n for n in range(1, 50) if n not in predictions]
            import random  # 作用说明：无历史频率时在可用号码中等概率抽取一个特别码。
            return random.choice(available) if available else 0
        # 频率加权随机选择
        import random  # 作用说明：按历史频次做加权抽样，决定特别码候选。
        total = sum(candidates.values())
        r = random.uniform(0, total)
        cumulative = 0
        for num, freq in candidates.items():
            cumulative += freq
            if cumulative >= r:
                return num
        return list(candidates.keys())[-1]
    except Exception:
        return 0


def on_enhanced_mode_changed(host, state):
    """「增强模式」开关：记录状态、写 INI 并在状态栏提示。

    功能:
        按复选状态写入 host.enhanced_mode，保存 INI 并提示当前状态。
    参数:
        host: 主窗口实例。
        state (int): Qt 复选状态；2（Qt.Checked）视为启用。
    返回:
        None。
    注意/副作用:
        - 写 host.enhanced_mode 与 INI；状态栏提示「动态权重+模式识别」；
        - 写盘失败由 _save_ini_config 内部处理。
    """
    # 增强模式开关变化处理
    host.enhanced_mode = state == 2  # Qt.Checked = 2
    host._save_ini_config()
    status = "已启用" if host.enhanced_mode else "已关闭"
    host.statusBar().showMessage("增强模式" + status + " (动态权重+模式识别)")


def on_strategy_changed(host, index):
    """「反选策略」下拉变化：把 currentData 转成布尔并写回 INI。

    功能:
        读取下拉绑定的数据转为 reverse_mode，写 INI 并更新策略说明与状态栏。
    参数:
        host: 主窗口实例。
        index (int): 下拉索引（未使用，仅信号签名需要）。
    返回:
        None。
    注意/副作用:
        - 写 host.reverse_mode 并 _save_ini_config（写盘）；
        - 更新 strategy_desc_label 文案与状态栏提示；
        - currentData() 返回 None 时用 bool(None)=False 兜底，避免 None 参与计算。
    """
    # 预测策略切换处理
    # 【修复None值bug】currentData()可能返回None，需转为bool确保类型安全
    host.reverse_mode = bool(host.strategy_combo.currentData())
    host._save_ini_config()

    if host.reverse_mode:
        desc = "🔴 反向模式：选择最不可能出现的号码，用于排除法策略，追求高错误率"
        status = "反向模式 (追求高错误率)"
    else:
        desc = "💡 标准模式：选择最可能出现的号码，追求命中更多"
        status = "标准模式 (追求准确率)"

    host.strategy_desc_label.setText(desc)
    host.statusBar().showMessage("已切换到" + status)


def on_deterministic_mode_changed(host, state):
    """「确定性模式」开关：记录状态并写 INI。

    功能:
        按复选状态写入 host.deterministic_mode，保存 INI 并提示当前状态。
    参数:
        host: 主窗口实例。
        state (int): Qt 复选状态。
    返回:
        None。
    注意/副作用:
        - 只改布尔标志并写 INI；下一次预测时由 set_deterministic_seed 生效；
        - 状态栏提示「相同数据结果一致」。
    """
    # 确定性模式开关变化处理
    host.deterministic_mode = state == 2  # Qt.Checked = 2
    host._save_ini_config()
    status = "已启用" if host.deterministic_mode else "已关闭"
    host.statusBar().showMessage("确定性预测" + status + " (相同数据结果一致)")


def set_deterministic_seed(host):
    """根据「当前数据 + 预测类型」生成固定随机种子，保证同数据同结果。

    功能:
        拼接期号与全部号码做 MD5，取模 2**31 后同时播种 random 与 numpy.random。
    参数:
        host: 主窗口实例；读取 host.deterministic_mode 与 host.historical_data。
    返回:
        int | None: 0~2**31-1 的种子；未启用确定性模式或生成失败时返回 None。
    注意/副作用:
        - 修改全局 random 与 numpy.random 的随机状态；
        - 种子输入 = 所有期号 + 所有正码/特别码 + 数据条数 的 MD5，
          同一份数据必得同一结果，新增一期数据即得到不同种子；
        - 取模 2**31 兼容 random 与 numpy.random 的种子范围；
        - 不设置 TensorFlow 种子（避免主线程加载 TF 触发 C 运行时问题）；
        - numpy 未安装时 get_numpy() 抛异常并被捕获，最终返回 None（random 已播种）。
    """
    # 设置确定性随机种子（基于数据内容），确保相同数据得到相同预测结果
    # 返回计算出的种子值，如果未启用则返回 None
    if not host.deterministic_mode:
        return None

    try:
        # 基于历史数据生成一个确定性的种子
        # 使用数据的哈希值作为种子，确保相同数据得到相同结果
        if host.historical_data and len(host.historical_data) > 0:
            # 提取所有期号拼接成字符串，然后计算哈希
            period_str = ''.join(str(item.get('period', '')) for item in host.historical_data)
            # 也加入号码数据，确保数据内容变化时种子也变化
            numbers_str = ''
            for item in host.historical_data:
                nums = item.get('numbers', [])
                numbers_str += ''.join(str(n) for n in nums)
                special = item.get('special', 0)
                if special:
                    numbers_str += str(special)

            # 计算哈希值作为种子
            import hashlib  # 作用说明：对期号+号码+数据条数计算 MD5，得到确定性随机种子。
            hash_input = period_str + numbers_str + str(len(host.historical_data))
            # 取模 2**31 把 128 位 MD5 压到 32 位非负整数范围，
            # 与 random / numpy.random 支持的种子区间一致，跨平台可复现
            seed = int(hashlib.md5(hash_input.encode()).hexdigest(), 16) % (2**31)

            # 设置所有随机数生成器的种子
            import random  # 作用说明：用确定性种子重置全局 random 状态，保证同数据同结果。
            random.seed(seed)
            get_numpy().random.seed(seed)

            # 【修复0xC0000409】不在主线程中import tensorflow，
            # 因为PredictWorker使用轻量模式不使用TF，设置TF种子无意义且会触发C运行时初始化
            # TF种子设置改为在_prepare_tensorflow_model中完成（仅完整模式触发）

            # 注意：sklearn 的 random_state 已经在各个模型中设置为 42
            return seed
    except Exception as e:
        print("设置确定性种子失败: " + str(e))

    return None


def update_last_vs_current_display(host, current_numbers, current_algo_name, current_special=None, pred_type_override=None):
    """刷新「上次 vs 本次」对比标签。

    功能:
        加载同类型上次预测，与本次做集合差，并用红删除线/绿加粗/蓝保留三色渲染两行 HTML。
    参数:
        host: 主窗口实例。
        current_numbers (list[int]): 本次预测号码（已排序）。
        current_algo_name (str): 本次使用的算法名称，写入「本次」标签。
        current_special (int | None): 本次特别码；None 时按算法规则现场推导。
        pred_type_override (str | None): 覆盖预测类型，用于切换类型时显示对应对比。
    返回:
        None。
    注意/副作用:
        - 写 host.last_prediction_label / lvc_arrow_label / current_prediction_label 的文本与可见性；
        - 只读上次预测文件，不写盘、不改变预测数据；
        - 上次有/本次无 → 红色删除线；本次新增 → 绿色加粗；两次保留 → 蓝色；
          任一侧无数据时隐藏「上次」行与箭头；
        - 整体 try/except：文件损坏或控件缺失时静默跳过，绝不影响本次结果显示。
    """
    # 更新"上次结果 vs 本次结果"对比显示区
    #
    # 每次新预测完成时调用：
    #   1. 从文件加载"上次预测"数据（上次保存的"本次预测"已被移为"上次"）
    #   2. 将新预测设为"本次结果"
    #   3. 对比两次结果，高亮变化的号码（新增=绿色，消失=红色，保留=灰色）
    #
    # 参数:
    #     current_numbers: 本次预测的号码列表（已排序）
    #     current_algo_name: 本次预测使用的算法名称
    #     current_special: 本次预测的特别码（可选，None时内部计算）
    #     pred_type_override: 覆盖预测类型（用于切换类型时显示正确类型的对比）
    try:
        # 从文件加载"上次预测"数据（当前pred_type对应的上次预测）
        pred_type = pred_type_override if pred_type_override is not None else getattr(host, '_prediction_type', 'algorithm')
        last_data = host._load_last_prediction_for_type(pred_type)

        prev_numbers = None
        prev_algo = ''
        prev_special = 0

        if last_data and last_data.get('numbers'):
            prev_numbers = last_data.get('numbers', [])
            prev_algo = last_data.get('algorithm', '')
            prev_special = last_data.get('special', 0)

        # 如果有上次结果，更新"上次结果"标签
        if prev_numbers is not None and len(prev_numbers) > 0:
            # 高亮对比：与本次结果比较，标注变化
            current_set = set(current_numbers)
            prev_set = set(prev_numbers)
            removed = prev_set - current_set  # 上次有、本次没有
            colored_nums = []
            for n in prev_numbers:
                if n in removed:
                    # 红色删除线表示已消失的号码
                    colored_nums.append(f'<span style="color:#E74C3C; text-decoration:line-through;">{str(n).zfill(2)}</span>')
                else:
                    # 灰色表示保留的号码
                    colored_nums.append(f'<span style="color:#888888;">{str(n).zfill(2)}</span>')
            prev_html = "上次: " + prev_algo + " → " + ' '.join(colored_nums)
            if prev_special > 0:
                prev_html += f' + <span style="color:#888888;">{str(prev_special).zfill(2)}</span>'

            host.last_prediction_label.setText(prev_html)
            host.last_prediction_label.setVisible(True)
            host.lvc_arrow_label.setVisible(True)
        else:
            # 没有上次结果，隐藏上次结果区和箭头
            host.last_prediction_label.setVisible(False)
            host.lvc_arrow_label.setVisible(False)

        # 计算本次特别码（如果调用者未传入）
        if current_special is None:
            is_special_algo = is_special_algorithm(host.current_algorithm_index)
            if not is_special_algo and len(current_numbers) == 6:
                current_special = host._predict_special_number(current_numbers)
            else:
                current_special = 0

        # 构建本次结果显示，高亮新增的号码
        prev_set = set(prev_numbers) if prev_numbers else set()
        colored_current = []
        for n in current_numbers:
            if n not in prev_set and prev_numbers is not None:
                # 绿色表示新增的号码（上次没有的）
                colored_current.append(f'<span style="color:#27AE60; font-weight:bold;">{str(n).zfill(2)}</span>')
            else:
                # 蓝色表示保留的号码
                colored_current.append(f'<span style="color:#1565C0;">{str(n).zfill(2)}</span>')
        cur_html = "本次: " + current_algo_name + " → " + ' '.join(colored_current)
        if current_special > 0:
            cur_html += f' + <span style="color:#F39C12; font-weight:bold;">{str(current_special).zfill(2)}</span>'

        host.current_prediction_label.setText(cur_html)

        # 上次/本次对比数据已通过文件系统持久化，无需内存变量

    except Exception:
        # 对比显示出错不影响主流程
        pass


def display_predictions(host, predictions, confidence_info=None):
    """把一组预测号码渲染为号码球、置信度汇总与统计文字。

    功能:
        注入结果区文本与号码球（含特别码），生成置信度分档说明，并刷新上次/本次对比。
    参数:
        host: 主窗口实例。
        predictions (iterable[int]): 正码（内部排序并统一转 int）。
        confidence_info (dict | None): 号码→置信度百分比；None 时不显示置信度。
    返回:
        None。
    注意/副作用:
        - 先清空旧球，再按升序创建 NumberBallWithZodiac（每行 6 个），
          末尾把置信度分级文案放到号码球下方；
        - 写 prediction_display 与 algorithm_source_label（后者随后隐藏、仅保留内部数据）；
        - 非特别码算法且正码恰为 6 个时，调用 host._predict_special_number；
        - 本函数只负责展示，不写盘；空结果时清空并显示「暂无预测结果」；
        - 控件已销毁时 RuntimeError 被捕获。
    """
    # 显示预测结果
    #
    # 功能4增强：添加置信度信息显示
    #
    # 参数：
    #     predictions: 预测号码列表
    #     confidence_info: 置信度字典，格式为 {number: confidence_percentage}
    sorted_preds = sorted(predictions)
    # 功能3：记录预测历史
    algo_name = "未知算法"
    if 0 <= host.current_algorithm_index < len(LotteryConfig.ALGORITHMS):
        algo_name = LotteryConfig.ALGORITHMS[host.current_algorithm_index][0]
    display_text = algo_name + " → " + ' '.join(str(n).zfill(2) for n in sorted_preds)

    # 判断是否为特别码算法（统一由注册表判定，避免散落的 21/22 硬编码）
    is_special_algo = is_special_algorithm(host.current_algorithm_index)

    # 预测特别码（非特别码算法时额外生成）
    # 【注意】必须在_update_last_vs_current_display之前计算，避免随机数消耗导致两次结果不一致
    special_num = 0
    if not is_special_algo and len(sorted_preds) == 6:
        special_num = host._predict_special_number(sorted_preds)

    # 更新"上次结果 vs 本次结果"对比显示区
    # 如果当前已有预测结果，先将它存为"上次结果"，再显示新的"本次结果"
    # 传入已计算的special_num避免重复调用_predict_special_number导致结果不一致
    host._update_last_vs_current_display(sorted_preds, algo_name, current_special=special_num)

    # 显示格式：01 02 03 04 05 06 + 07
    if not is_special_algo and len(sorted_preds) == 6 and special_num > 0:
        display_text = algo_name + " → " + ' '.join(str(n).zfill(2) for n in sorted_preds) + " + " + str(special_num).zfill(2)

    host.prediction_display.setText(display_text)
    # 显示算法来源标签
    mode_suffix = ""
    label_color = "#2ECC71"
    if host.current_algorithm_index == 0:  # 综合推荐才有模式区分
        if host.reverse_mode:
            mode_suffix = " (反向模式)"
            label_color = "#E74C3C"  # 红色表示反向
        elif host.enhanced_mode:
            mode_suffix = " (增强版)"

    host.algorithm_source_label.setText("算法: " + algo_name + mode_suffix)
    # 算法来源标签样式（算法预测时）- 胶囊形标签，颜色随模式变化
    #   font-size: 15px;              字体大小：15px
    #   font-weight: bold;            字体：粗体
    #   padding: 4px 12px;            内边距：上下4px，左右12px
    #   border-radius: 12px;          圆角：12px（胶囊形）
    #   background-color: #FFFFFF;    背景色：白色
    #   color: label_color;           文字颜色：绿=标准/红=反向/蓝=增强
    #   border: 1px solid label_color; 边框：同色边框
    host.algorithm_source_label.setStyleSheet(
        "font-size: 15px; font-weight: bold; padding: 4px 12px; "
        "border-radius: 12px; background-color: #FFFFFF; color: " + label_color + "; "
        "border: 1px solid " + label_color + ";"
    )
    # 【已移除界面显示】来源标签已从界面删除，仅保留内部数据
    host.algorithm_source_label.hide()
    # 特别码已在上方提前计算（special_num变量），此处不再重复计算

    history_entry = {
        'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'algorithm': algo_name,
        'numbers': list(sorted_preds),
        'special': special_num
    }
    host.prediction_history.insert(0, history_entry)
    host._refresh_prediction_history_table()
    host._save_prediction_history()
    # 保存最后一次预测结果（含特别码）
    host._save_last_prediction(predictions, confidence_info, algo_name, special_num)
    # 保存当前预测结果到内存（用于"保存当前"功能）
    host.current_prediction_result = {
        'numbers': list(sorted_preds),
        'special': special_num,
        'confidence_info': confidence_info if confidence_info else {},
        'algorithm': algo_name,
    }
    # 更新已保存预测列表的过期状态（数据可能变化）
    if hasattr(host, 'saved_predictions_list') or hasattr(host, 'favorites_list'):
        host._load_saved_predictions()
    # 预测结果号码球展示
    # 清空旧号码球，创建新号码球直接显示
    while host.prediction_number_layout.count():
        item = host.prediction_number_layout.takeAt(0)
        if item.widget():
            item.widget().deleteLater()
    # 清除已删除的置信度标签引用
    host.confidence_display_label = None

    # 正码球 + 生肖 + 五行
    _anim_balls = []  # 收集号码球控件，用于入场动画
    for i, num in enumerate(sorted_preds):
        zodiac = host.zodiac_binding.get(num, "")
        element = host.zodiac_elements.get(num, "")
        ball = NumberBallWithZodiac(num, zodiac, element, is_special=False, font_size=host.ball_label_font_size)
        row = i // 7  # 每行7个号码球，超过换行
        col = i % 7
        host.prediction_number_layout.addWidget(ball, row * 2, col)  # row*2留出生肖/五行标签的空间
        _anim_balls.append(ball)

    # 特别码球 + 生肖 + 五行
    # 特别码跟在正码后面，用"+"号分隔，视觉上区分正码和特别码
    if special_num > 0 and not is_special_algo:
        zodiac = host.zodiac_binding.get(special_num, "")
        element = host.zodiac_elements.get(special_num, "")
        ball = NumberBallWithZodiac(special_num, zodiac, element, is_special=True, font_size=host.ball_label_font_size)
        special_row = 0
        special_col = len(sorted_preds)  # 紧跟正码后面
        if special_col >= 7:
            special_col = 0
            special_row = (len(sorted_preds) // 7) * 2
        # 加号标签 - 特别码分隔符
        plus_label = QLabel("+")
        plus_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        plus_size = host._prediction_ball_size.get('plus_size', 24)
        # 加号分隔符样式：字号跟随尺寸设置，粗体橙色（#F39C12）
        plus_label.setStyleSheet(f"font-size: {plus_size}px; font-weight: bold; color: #F39C12;")
        host.prediction_number_layout.addWidget(plus_label, special_row, special_col)
        host.prediction_number_layout.addWidget(ball, special_row, special_col + 1)
        _anim_balls.append(ball)
    elif is_special_algo:
        # 特别码算法只显示1个号码（无正码）
        for i, num in enumerate(sorted_preds):
            zodiac = host.zodiac_binding.get(num, "")
            element = host.zodiac_elements.get(num, "")
            ball = NumberBallWithZodiac(num, zodiac, element, is_special=True, font_size=host.ball_label_font_size)
            host.prediction_number_layout.addWidget(ball, 0, i)
            _anim_balls.append(ball)

    # 功能4：预测结果置信度显示
    # 【修复布局bug】原代码将confidence_labels_layout设为prediction_number_layout，
    # 导致清空置信度标签时误删刚添加的号码球。改为始终使用confidence_display_label管理，
    # 不再复用prediction_number_layout作为置信度布局
    if hasattr(host, 'confidence_labels_layout') and host.confidence_labels_layout is not None:
        # 只清空confidence_display_label，不清空整个prediction_number_layout
        pass
    else:
        host.confidence_labels_layout = None  # 标记为已初始化，但不指向prediction_number_layout

    # 添加置信度标签
    if confidence_info and not is_special_algo:
        confidence_text_parts = []
        for num in sorted_preds:
            conf = confidence_info.get(num, 0)
            # 置信度分档阈值（业务口径）：≥70% 强烈推荐，40%~69% 一般推荐，
            # <40% 谨慎参考；只影响提示文案与颜色，不改变号码本身
            if conf >= 70:
                level = "强烈推荐"
            elif conf >= 40:
                level = "一般推荐"
            else:
                level = "谨慎参考"
            confidence_text_parts.append(str(num).zfill(2) + ":" + "{:.1f}".format(conf) + "%「" + level + "」")

        # 更新或创建置信度显示标签
        if hasattr(host, 'confidence_display_label') and host.confidence_display_label is not None:
            try:
                conf_text = "  ".join(confidence_text_parts)
                host.confidence_display_label.setText(conf_text)
                # 置信度标签样式 - 浅灰底（#F8F9FA）：常规信息显示，15px字号，圆角4px
                style = "font-size: 15px; padding: 5px; background-color: #F8F9FA; border-radius: 4px;"
    # 置信度展示标签样式：15px字号，5px内边距，浅灰背景，4px圆角

                host.confidence_display_label.setStyleSheet(style)
            except RuntimeError:
                # QLabel已被删除，重新创建
                host.confidence_display_label = QLabel("  ".join(confidence_text_parts))
                # 换行显示长置信度文本，避免撑宽号码球网格
                host.confidence_display_label.setWordWrap(True)
                host.confidence_display_label.setAlignment(
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
                # 置信度标签样式 - 浅灰底（#F8F9FA）：常规信息显示，15px字号，圆角4px
                host.confidence_display_label.setStyleSheet("font-size: 15px; padding: 5px; background-color: #F8F9FA; border-radius: 4px;")
                host.prediction_number_layout.addWidget(host.confidence_display_label, len(sorted_preds) // 6 + 1, 0, 1, 6)
        else:
            host.confidence_display_label = QLabel("  ".join(confidence_text_parts))
            # 换行显示长置信度文本，避免撑宽号码球网格
            host.confidence_display_label.setWordWrap(True)
            host.confidence_display_label.setAlignment(
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            # 置信度标签样式 - 浅灰底（#F8F9FA）：常规信息显示，15px字号，圆角4px
            host.confidence_display_label.setStyleSheet("font-size: 15px; padding: 5px; background-color: #F8F9FA; border-radius: 4px;")
            host.prediction_number_layout.addWidget(host.confidence_display_label, len(sorted_preds) // 6 + 1, 0, 1, 6)

    # 特别码算法特殊显示
    if is_special_algo:
        if hasattr(host, 'confidence_display_label') and host.confidence_display_label is not None:
            try:
                host.confidence_display_label.setText("特别码预测: " + str(sorted_preds[0]) if sorted_preds else "无")
                # 特别码置信度标签样式 - 黄底橙边（#FFF3CD/#F39C12）：突出显示特别码预测结果
                #   font-size: 15px;              字体大小：15px（比常规大）
                #   padding: 8px;                 内边距：8px
                #   background-color: #FFF3CD;    背景色：浅黄（醒目提示）
                #   border: 2px solid #F39C12;    边框：2px 橙色实线（强调）
                #   border-radius: 6px;           圆角：6px
                #   font-weight: bold;            字体：粗体
                host.confidence_display_label.setStyleSheet("font-size: 15px; padding: 8px; background-color: #FFF3CD; border: 2px solid #F39C12; border-radius: 6px; font-weight: bold;")
            except RuntimeError:
                host.confidence_display_label = QLabel("特别码预测: " + str(sorted_preds[0]) if sorted_preds else "无")
                # 特别码提示同样允许换行，避免窄窗口下被裁切
                host.confidence_display_label.setWordWrap(True)
                # 特别码置信度标签样式 - 黄底橙边（#FFF3CD/#F39C12）：突出显示特别码预测结果
                host.confidence_display_label.setStyleSheet("font-size: 15px; padding: 8px; background-color: #FFF3CD; border: 2px solid #F39C12; border-radius: 6px; font-weight: bold;")
                host.prediction_number_layout.addWidget(host.confidence_display_label, len(sorted_preds) // 6 + 1, 0, 1, 6)
        else:
            host.confidence_display_label = QLabel("特别码预测: " + str(sorted_preds[0]) if sorted_preds else "无")
            # 特别码提示同样允许换行，避免窄窗口下被裁切
            host.confidence_display_label.setWordWrap(True)
            # 特别码置信度标签样式 - 黄底橙边（#FFF3CD/#F39C12）：突出显示特别码预测结果
            host.confidence_display_label.setStyleSheet("font-size: 15px; padding: 8px; background-color: #FFF3CD; border: 2px solid #F39C12; border-radius: 6px; font-weight: bold;")
            host.prediction_number_layout.addWidget(host.confidence_display_label, len(sorted_preds) // 6 + 1, 0, 1, 6)

    # 功能4：置信度分析汇总
    if hasattr(host, 'confidence_analysis_text') and confidence_info and not is_special_algo:
        strong_rec = [n for n in sorted_preds if confidence_info.get(n, 0) >= 70]
        normal_rec = [n for n in sorted_preds if 40 <= confidence_info.get(n, 0) < 70]
        cautious = [n for n in sorted_preds if confidence_info.get(n, 0) < 40]

        analysis = "置信度分析汇总：\n"
        if strong_rec:
            analysis += "  ● 强烈推荐(" + str(len(strong_rec)) + "个): " + " ".join(str(n).zfill(2) for n in strong_rec) + "\n"
        if normal_rec:
            analysis += "  ● 一般推荐(" + str(len(normal_rec)) + "个): " + " ".join(str(n).zfill(2) for n in normal_rec) + "\n"
        if cautious:
            analysis += "  ● 谨慎参考(" + str(len(cautious)) + "个): " + " ".join(str(n).zfill(2) for n in cautious)

        host.confidence_analysis_text.setPlainText(analysis)
    elif hasattr(host, 'confidence_analysis_text') and is_special_algo:
        host.confidence_analysis_text.setPlainText("特别码预测结果\n建议结合正码预测综合参考")

    # 统计信息（仅对非特别码算法）
    if not is_special_algo:
        red_count = sum(1 for n in predictions if LotteryConfig.is_red(n))
        blue_count = sum(1 for n in predictions if LotteryConfig.is_blue(n))
        green_count = sum(1 for n in predictions if LotteryConfig.is_green(n))
        odd_count = sum(1 for n in predictions if n % 2 == 1)
        # 【修复硬编码bug】原代码硬编码6，当predictions数量不为6时统计错误，改为len(predictions)
        even_count = len(predictions) - odd_count
        big_count = sum(1 for n in predictions if n > 25)
        small_count = len(predictions) - big_count
        stats_text = ("颜色分布: 红" + str(red_count) + "个 蓝" + str(blue_count) + "个 绿" + str(green_count) + "个\n"
                     + "单双分布: 单" + str(odd_count) + "个 双" + str(even_count) + "个\n"
                     + "大小分布: 大" + str(big_count) + "个 小" + str(small_count) + "个")
        host.prediction_stats_label.setText(stats_text)
    else:
        host.prediction_stats_label.setText("特别码预测\n（仅返回1个特别码）")

    # 应用当前尺寸设置
    host._apply_prediction_ball_size()
    # 【动画】号码球依次弹出（动画内部延迟100ms启动，避免与尺寸设置冲突）
    if _anim_balls:
        host._animate_prediction_balls([(w, i) for i, w in enumerate(_anim_balls)])


def on_number_strategy_predict(host):
    """「生成七策略」按钮：校验数据量后把计算延后到事件循环下一拍。

    功能:
        校验历史数据条数，设置运行标志与状态文字，然后安排主线程计算。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 正在计算（_number_strategy_running）时直接返回，避免重入；
        - 无数据或少于 MIN_DRAWS 期时红字提示并弹窗，不进入计算；
        - 写 host._number_strategy_running=True、禁用按钮、刷新状态文字并 processEvents；
        - 用 QTimer.singleShot(0) 调 run_number_strategy_prediction，保证「计算中」先被看到；
        - 计算留在主线程，规避 QThread 内 sklearn C 扩展的栈溢出问题。
    """
    if getattr(host, '_number_strategy_running', False):
        return
    if not getattr(host, 'historical_data', None):
        host.number_pred_status_label.setText("数据不足：尚未导入历史开奖数据。")
        host.number_pred_status_label.setStyleSheet("font-size: 15px; color: #C62828;")
        QMessageBox.warning(host, "数据不足", "请先在 [1] 数据导入页导入历史开奖数据。")
        return
    if len(host.historical_data) < NumberStrategyPredictor.MIN_DRAWS:
        message = ("数据不足：七策略预测至少需要 %d 期历史数据，当前仅 %d 期。"
                   % (NumberStrategyPredictor.MIN_DRAWS, len(host.historical_data)))
        host.number_pred_status_label.setText(message)
        host.number_pred_status_label.setStyleSheet("font-size: 15px; color: #C62828;")
        QMessageBox.warning(host, "数据不足", message)
        return

    host._number_strategy_running = True
    host.number_pred_generate_btn.setEnabled(False)
    host.number_pred_status_label.setText("正在计算七策略...（机器学习首次运行需训练模型，请稍候）")
    host.number_pred_status_label.setStyleSheet("font-size: 15px; color: #E67E22;")
    QApplication.processEvents()
    QTimer.singleShot(0, lambda: run_number_strategy_prediction(host))


def _number_strategy_progress(host, percent, message):
    """七策略计算的进度回调：刷新状态标签并让界面保持响应。

    功能:
        把百分比与步骤说明写入状态标签，并处理一次事件循环。
    参数:
        host: 主窗口实例。
        percent (float): 0~100 的进度。
        message (str): 当前步骤说明。
    返回:
        None。
    注意/副作用:
        - 只更新状态标签与 processEvents，不触碰结果控件；
        - 窗口已关闭时静默返回；状态标签已销毁时 RuntimeError 被捕获。
    """
    if getattr(host, '_window_closing', False):
        return
    try:
        host.number_pred_status_label.setText(
            "正在计算七策略... %d%% - %s" % (int(percent), message))
        QApplication.processEvents()
    except RuntimeError:
        pass


def run_number_strategy_prediction(host):
    """在主线程执行七策略计算并渲染结果。

    功能:
        创建 NumberStrategyPredictor 并调用 predict_all，渲染文本/卡片并落盘结果。
    参数:
        host: 主窗口实例；读取历史数据、窗口期数与模型缓存配置。
    返回:
        None。
    注意/副作用:
        - 设置等待光标，训练期间通过进度回调显示阶段；
        - 调用 render_number_strategy_results（内部写 host._number_strategy_results 并落盘）；
        - 无论成功失败都在 finally 复位 _number_strategy_running 与按钮，
          避免用户被永久锁在「计算中」；
        - 计算异常时状态标签红字显示错误并弹窗；缺 sklearn 时由 predictor
          返回机器学习策略为「不可用」，其余策略照常输出。
    """
    if getattr(host, '_window_closing', False):
        return
    error_message = ''
    QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
    try:
        predictor = NumberStrategyPredictor(
            host.historical_data,
            zodiac_binding=getattr(host, 'zodiac_binding', None),
            window=host.number_pred_window_spin.value(),
            ml_base_dir=getattr(host, '_ml_data_dir', None),
            ml_use_cache=getattr(host, '_use_model_cache', True),
            progress_callback=lambda percent, msg: _number_strategy_progress(host, percent, msg),
        )
        result = predictor.predict_all(include_ml=True)
        render_number_strategy_results(host, result)
        if not result.get('ok'):
            error_message = result.get('error') or '七策略未能生成有效结果'
    except Exception as exc:
        traceback.print_exc()
        error_message = "七策略计算失败：%s" % str(exc)
        host.number_pred_status_label.setText(error_message)
        host.number_pred_status_label.setStyleSheet("font-size: 15px; color: #C62828;")
    finally:
        QApplication.restoreOverrideCursor()
        host._number_strategy_running = False
        host.number_pred_generate_btn.setEnabled(True)
    if error_message:
        QMessageBox.warning(host, "号码预测", error_message)


def _number_strategy_mono_font(pixel_size=18, bold=False):
    """返回七策略列表专用的等宽字体（NSimSun / 新宋体，Windows 自带）

    功能:
        构造 NSimSun 等宽字体并设置像素字号与字重，保证 ASCII:中文 = 1:2 的严格对齐。
    参数:
        pixel_size (int): 字体像素大小，下限由本函数钳制为 15px。
        bold (bool): 是否使用加粗（v0.0.48 起策略名与号码要求 Bold）。
    返回:
        QFont: 指定像素大小、字重的 NSimSun 等宽字体。
    注意/副作用:
        - 主窗口全局字体自适应会把控件字体改成 Microsoft YaHei 20px，
          其空格 6px、中文 80px，不是严格 2:1，用空格补位会出现 2px 级错位；
          NSimSun 下 ASCII 宽 = 字号/2、中文宽 = 字号，补位空格可精确对齐；
        - 渲染时会把该字体写入字符格式，字符格式优先于控件字体，不受全局字体缩放影响；
        - 非粗体不能调用 setBold(False)，否则会把字重从 Medium 重置回 Normal(400)；
        - 只设置字体族/字号/粗细，不改其他样式；字体缺失时由 Qt 回退默认字体。
    """
    font = QFont("NSimSun")
    font.setStyleHint(QFont.StyleHint.Monospace)
    font.setPixelSize(max(15, int(pixel_size)))
    # QFont 与 QSS 各设一处：只改 QSS 的 font-weight 对字符格式无效
    # 非粗体不能调用 setBold(False)，否则会把字重从 Medium 重置回 Normal(400)
    if bold:
        font.setWeight(QFont.Weight.Bold)
        font.setBold(True)
    else:
        font.setWeight(QFont.Weight.Medium)
    return font


def _number_strategy_fonts(host):
    """从角控件读取号码预测面板使用的两档字号。

    功能:
        读取号码字号与文字字号，并统一做 15px 下限保护。
    参数:
        host: 主窗口实例。
    返回:
        tuple[int, int]: (数字字号, 文字字号)。数字取自 _prediction_ball_size['font']，
            文字取自 ball_label_font_size。
    注意/副作用:
        只读 host 状态，不修改控件；属性缺失时分别回退到 20 / 20，
        再经 max(15, ...) 保证不会出现小于 15px 的文字。
    """
    number_px = int(getattr(host, '_prediction_ball_size', {}).get('font', 20) or 20)
    text_px = int(getattr(host, 'ball_label_font_size', 20) or 20)
    return max(15, number_px), max(15, text_px)


def _number_strategy_bindings(host):
    """实时读取当前的生肖与五行绑定（每次刷新调用，不做导入期快照）

    功能:
        先取 host 内存绑定，再用生肖 JSON 与 LotteryConfig.NUMBER_ELEMENTS 覆盖为最新值。
    参数:
        host: 主窗口实例，读取 zodiac_file / zodiac_binding / zodiac_elements。
    返回:
        tuple[dict[int, str], dict[int, str]]: (生肖绑定, 五行绑定)。
    注意/副作用:
        - 生肖：优先读 系统v7.5/生肖绑定.json 的 names 字段（[10] 页改动会立即写入该文件），
          再用 host.zodiac_binding 补齐缺失号码；
        - 五行：读 LotteryConfig.NUMBER_ELEMENTS（[11] 页改动会原地更新该类属性），
          再用 host.zodiac_elements 补齐；
        - 禁止用 (number-1)%12 推算生肖，保证与用户手工绑定一致；
        - 只读文件与内存，不写盘；文件损坏或格式变化时静默退回内存绑定。
    """
    zodiac = {}
    fallback = getattr(host, 'zodiac_binding', None) or {}
    for key, value in fallback.items():
        try:
            zodiac[int(key)] = str(value)
        except (TypeError, ValueError):
            continue

    json_path = getattr(host, 'zodiac_file', None)
    if json_path and os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as handle:
                payload = json.load(handle)
            names = payload.get('names') or {}
            for key, value in names.items():
                try:
                    zodiac[int(key)] = str(value)
                except (TypeError, ValueError):
                    continue
        except (OSError, ValueError, TypeError):
            # 文件损坏或格式变化时退回 host.zodiac_binding，不影响预测结果展示
            pass

    elements = {}
    host_elements = getattr(host, 'zodiac_elements', None) or {}
    for key, value in host_elements.items():
        try:
            elements[int(key)] = str(value)
        except (TypeError, ValueError):
            continue
    for key, value in (LotteryConfig.NUMBER_ELEMENTS or {}).items():
        try:
            elements[int(key)] = str(value)
        except (TypeError, ValueError):
            continue
    return zodiac, elements


def _number_strategy_token(number, zodiac, elements):
    """生成单个号码的紧凑标签：两位号码 + 生肖 + `·` + 五行

    功能:
        按两位号码与生肖/五行绑定拼出 `03虎·木` 形式的标签。
    参数:
        number (int): 1~49 的号码。
        zodiac (dict[int, str]): 生肖绑定。
        elements (dict[int, str]): 五行绑定。
    返回:
        str: 形如 `03虎·木` 的标签；绑定缺失时用 `?` 占位。
    注意/副作用:
        纯查表函数，无异常路径、无副作用；未知键原样返回输入 token。
    """
    return '%02d%s·%s' % (number, zodiac.get(number, '') or '?',
                          elements.get(number, '') or '?')


def _number_strategy_gap_text(number_px, text_px):
    """按字号选择号内/号间细空格间距，保证 1180×720 文本区不横向滚动

    功能:
        按号码字号与文字字号档位，返回号内与号间两层 U+2009 细空格串。
    参数:
        number_px (int): 号码字号（像素）。
        text_px (int): 文字字号（像素）。
    返回:
        tuple[str, str]: (号码与生肖五行之间的细空格串, 号码之间的细空格串)。
    注意/副作用:
        - NSimSun 15px 下一个 U+2009 细空格约 3px、普通半角空格 8px；
          默认 15/20px 档用 2 个细空格（约 6px）+ 4 个细空格（约 12px），
          比原来的单个半角空格（8px）明显更宽；22px 以上档位按可用宽度收窄；
        - 24px 号码 + 24px 文字档最紧，用 1+2 个细空格；
        - 至少保留 1 个空格，避免出现零宽补位；纯函数，无异常路径。
    """
    if number_px >= 22 and text_px > 20:
        return '\u2009', '\u2009\u2009'
    if number_px >= 22:
        return '\u2009\u2009', '\u2009\u2009\u2009'
    return '\u2009\u2009', '\u2009' * 4


def _number_strategy_line_rows(host, strategies, show_labels=None):
    """把七策略结果格式化成逐行文本，并记录着色/缩小标签所需的字符偏移

    功能:
        为每条策略生成「策略名 + 制表符 + 正码 + `+` + 特别码」的完整行文本，
        并计算上色与制表位所需的字符区间。
    参数:
        host: 主窗口实例，读取字号、生肖/五行绑定与「只显示号码」开关。
        strategies (list[dict]): lib 返回的七策略结果。
        show_labels (bool | None): 是否输出生肖五行标签；None 时读取开关状态。
    返回:
        list[dict]: 每项含 text（完整行文本）、offset（该行在全文中的字符起点）、
            label（策略名）、numbers_start（正码相对行首的字符偏移）、
            numbers_len（正码文本字符数）、plus_pos（加号相对行首的字符偏移）、
            special_pos（特别码相对行首的字符偏移）、
            special_len（特别码标签字符数，无特码时为 0）、
            tag_spans（正码段内需要 15px 标签格式的 (起点, 长度) 列表）、
            special_tag_span（特别码内标签的 (起点, 长度)，无标签时为 None）。
    注意/副作用:
        - 行格式为「策略名 \\t 六正码   +   特别码」，复制出来制表符与空格原样保留；
        - 制表位在 _apply_number_strategy_formats 中按加粗策略名像素宽 + 2 个半角空格
          动态换算，2~4 字名都跳到同一列；
        - 每个号码由「两位数字（数字 px 粗体）」+「号内细空格」+「生肖·五行（15px）」
          + 定宽补位 +「号间细空格」构成，49 个号码按最宽标签统一补位，
          6 个 token 像素总宽恒定，`+` 列与特别码列因此严格对齐；
        - 标签固定 15px（全项目字号下限）；实测 1180×720 下右侧文本区 viewport 802px，
          20px/24px 号码三档均无横向滚动；
        - 纯计算不写盘；结果缺少某策略时该策略返回空行，整份结果为空时返回空列表。
    """
    if show_labels is None:
        show_labels = not bool(getattr(host, '_number_strategy_hide_labels', False))
    number_px, text_px = _number_strategy_fonts(host)
    tag_font = _number_strategy_mono_font(15)
    tag_metrics = QFontMetrics(tag_font)
    zodiac, elements = _number_strategy_bindings(host)
    # 号内（数字↔标签）与号间（标签↔下一号码）用细空格拉开距离；
    # 细空格宽度由 QFontMetrics 实测，所有行使用同一串，保证四列像素对齐
    inner_gap, outer_gap = _number_strategy_gap_text(number_px, text_px)

    # 正码数字宽度固定（两位），标签按 49 个号码中的最宽组合统一补位
    max_tag_width = 0
    if show_labels:
        max_tag_width = max(
            tag_metrics.horizontalAdvance(
                (zodiac.get(n, '') or '?') + '·' + (elements.get(n, '') or '?'))
            for n in range(1, 50))
    # 补位也用细空格：15px NSimSun 下约 3px，避免普通空格回退造成宽度跳变
    gap_width = tag_metrics.horizontalAdvance('\u2009')

    rows = []
    offset = 0
    for item in strategies:
        label = item.get('label', '')
        numbers = item.get('numbers', [])
        special = item.get('special', 0)
        tag_spans = []
        if numbers:
            if show_labels:
                parts = []
                numbers_pos = 0
                for number in numbers:
                    digits = '%02d' % number
                    tag_text = _number_strategy_token(number, zodiac, elements)[2:]
                    tag_width = tag_metrics.horizontalAdvance(tag_text)
                    pad = max(0, int((max_tag_width - tag_width) // gap_width)) \
                        if gap_width else 0
                    # 号内细空格 + 标签 + 定宽补位 + 号间细空格（全部 15px 等宽细空格）
                    tag_block = inner_gap + tag_text + ('\u2009' * pad) + outer_gap
                    tag_spans.append((numbers_pos + len(digits), len(tag_block)))
                    parts.append(digits + tag_block)
                    numbers_pos += len(digits) + len(tag_block)
                numbers_text = ''.join(parts).rstrip('\u2009')
                # rstrip 会去掉最后一个号间细空格，末尾标签 span 需要同步截断
                if tag_spans:
                    start, length = tag_spans[-1]
                    tag_spans[-1] = (start, max(0, min(length, len(numbers_text) - start)))
            else:
                # 只显示号码时用 2 个半角空格拉开号码距离（当前 1 个过密）
                numbers_text = '  '.join('%02d' % number for number in numbers)
        else:
            numbers_text = '未生成'
            numbers_pos = 0
        special_tag_span = None
        if special:
            digits = '%02d' % special
            if show_labels:
                tag_text = _number_strategy_token(special, zodiac, elements)[2:]
                # 特别码同样在号码与生肖五行之间留号内细空格
                special_text = digits + inner_gap + tag_text
                special_tag_span = (len(digits), len(inner_gap) + len(tag_text))
            else:
                special_text = digits
            special_len = len(special_text)
        else:
            special_text = '—'
            special_len = 0

        # 用户指定结构：策略名 + 制表符 + 六正码 + 3 空格 + `+` + 3 空格 + 特别码
        text = label + '\t' + numbers_text + '   +   ' + special_text
        numbers_start = len(label) + 1
        plus_pos = numbers_start + len(numbers_text) + 3
        rows.append({
            'text': text,
            'offset': offset,
            'label': label,
            'numbers_start': numbers_start,
            'numbers_len': len(numbers_text),
            'plus_pos': plus_pos,
            'special_pos': plus_pos + 4,  # `+` 后再 3 个空格，共跨 4 个字符
            'special_len': special_len,
            'tag_spans': tag_spans,
            'special_tag_span': special_tag_span,
        })
        offset += len(text) + 1  # +1 是行尾换行符

    return rows


def _apply_number_strategy_formats(host, rows):
    """给七策略纯文本逐段上色/上字号，并按「尺寸」设置行高。

    功能:
        用 QTextCursor + mergeCharFormat 按行设置策略名、正码、标签、加号与特别码的
        字体/颜色，并设置动态制表位与固定行高。
    参数:
        host: 主窗口实例。
        rows (list[dict]): _number_strategy_line_rows 生成的行字典，
            每项含 text / 正码与特别码在文本中的起止下标 / strategy 数据。
    返回:
        None。
    注意/副作用:
        - 行高 = 「尺寸」高度 × 0.6（下限 max(两档字号)+4，上限 60）；
        - 只改字符格式不改文本，保证复制出来仍是 7 行、制表位与空格原样保留；
        - 特别码用红色系，暗色 #FF6B6B / 亮色 #C62828；
        - 制表位按「文字 px」粗体策略名动态换算，字号变化时正码列仍严格对齐；
        - 末尾把光标复位到首行开头并清除选区，避免残留选区影响复制；
        - 文本为空时只清空格式列表；控件不存在时由调用方（refresh_*）提前返回。
    """
    view = host.number_pred_text
    cursor = view.textCursor()
    number_px, text_px = _number_strategy_fonts(host)
    text_font = _number_strategy_mono_font(text_px)
    # v0.0.48：号码与策略名按要求改为粗体；加粗后字宽变大，
    # 标签补位与制表位都用同一份粗体字体的 QFontMetrics 重新换算
    number_font = _number_strategy_mono_font(number_px, bold=True)
    label_font = _number_strategy_mono_font(text_px, bold=True)
    dark = bool(getattr(host, 'is_dark_mode', False))
    label_color = '#E5E7EB' if dark else '#2C3E50'
    number_color = '#F5F5F5' if dark else '#1A1A1A'
    plus_color = '#D1D5DB' if dark else '#34495E'
    tag_color = '#D1D5DB' if dark else '#333333'
    special_color = '#FF6B6B' if dark else '#C62828'

    # charFormat() 返回当前格式副本，避免额外导入 QTextCharFormat / QTextBlockFormat
    # （TAB 层只能从 UI/UI.py 取控件，UI 未导出这些类，故用实例方法取得格式对象）
    # 先给全文写入「文字 px」字体，字符格式优先于控件字体，
    # 这样即使主窗口把控件字体改成 YaHei 20px，补位宽度仍与测量结果一致。
    base_format = cursor.charFormat()
    base_format.setFont(text_font)
    cursor.setPosition(0)
    cursor.setPosition(len(view.toPlainText()), cursor.MoveMode.KeepAnchor)
    cursor.mergeCharFormat(base_format)

    label_format = cursor.charFormat()
    label_format.setFont(label_font)
    label_format.setForeground(QColor(label_color))
    # 策略名用 Bold；制表位按同一粗体字体测量，粗体变宽也不会错列
    label_format.setFontWeight(QFont.Weight.Bold)
    numbers_format = cursor.charFormat()
    numbers_format.setFont(number_font)
    # 亮色正文接近纯黑、暗色接近纯白（v0.0.48）
    numbers_format.setForeground(QColor(number_color))
    plus_format = cursor.charFormat()
    plus_format.setFont(text_font)
    plus_format.setForeground(QColor(plus_color))
    special_format = cursor.charFormat()
    special_format.setFont(number_font)
    special_format.setForeground(QColor(special_color))
    special_format.setFontWeight(QFont.Weight.Bold)
    # 生肖五行标签固定 15px（下限），避免六标签 + 特别码在 1180 宽度下溢出；
    # 该格式只覆盖标签与补位空格，数字仍保持「数字 px」粗体
    tag_font = _number_strategy_mono_font(15)
    tag_format = cursor.charFormat()
    tag_format.setFont(tag_font)
    tag_format.setForeground(QColor(tag_color))
    tag_format.setFontWeight(QFont.Weight.Medium)
    special_tag_format = cursor.charFormat()
    special_tag_format.setFont(tag_font)
    special_tag_format.setForeground(QColor(special_color))
    special_tag_format.setFontWeight(QFont.Weight.Bold)

    for row in rows:
        start = row['offset']
        # 策略名区间：文字 px + 深蓝色
        cursor.setPosition(start)
        cursor.setPosition(start + len(row['label']), cursor.MoveMode.KeepAnchor)
        cursor.mergeCharFormat(label_format)
        # 正码区间：数字 px + 黑色（含号码之间的分隔空格，保证整段等宽）
        numbers_start = start + row['numbers_start']
        cursor.setPosition(numbers_start)
        cursor.setPosition(numbers_start + row['numbers_len'], cursor.MoveMode.KeepAnchor)
        cursor.mergeCharFormat(numbers_format)
        # 正码里的生肖五行小标签：固定 15px、常规字重，保持号码数字醒目
        for span_start, span_len in row.get('tag_spans', []):
            if span_len <= 0:
                continue
            cursor.setPosition(numbers_start + span_start)
            cursor.setPosition(numbers_start + span_start + span_len,
                              cursor.MoveMode.KeepAnchor)
            cursor.mergeCharFormat(tag_format)
        # 加号：文字 px + 深灰蓝，保持与正码列/特别码列的固定位置
        plus_start = start + row['plus_pos']
        cursor.setPosition(plus_start)
        cursor.setPosition(plus_start + 1, cursor.MoveMode.KeepAnchor)
        cursor.mergeCharFormat(plus_format)
        # 特别码区间：数字 px + 红色加粗（只改两位数字，不碰加号与间隔空格）
        if row['special_len']:
            special_start = start + row['special_pos']
            cursor.setPosition(special_start)
            cursor.setPosition(special_start + row['special_len'], cursor.MoveMode.KeepAnchor)
            cursor.mergeCharFormat(special_format)
            tag_span = row.get('special_tag_span')
            if tag_span:
                tag_start, tag_len = tag_span
                cursor.setPosition(special_start + tag_start)
                cursor.setPosition(special_start + tag_start + tag_len,
                                  cursor.MoveMode.KeepAnchor)
                cursor.mergeCharFormat(special_tag_format)

    # 制表位：按「文字 px」粗体策略名动态换算，不写死像素。
    # 取「最长策略名宽度 + 2 个半角空格余量」，2~4 字策略名都会跳到同一列；
    # 字号变化时制表位随字号缩放，正码列保持严格对齐。
    if rows:
        label_metrics = QFontMetrics(label_font)
        max_label_width = max(
            (label_metrics.horizontalAdvance(row['label']) for row in rows), default=0)
        tab_margin = max(4, label_metrics.horizontalAdvance(' ') * 2)
        view.setTabStopDistance(float(max_label_width + tab_margin))

    # 行高：由「尺寸」高度推导，固定像素行高让七行等距且不因字号变化而抖动
    size_height = int(getattr(host, '_prediction_ball_size', {}).get('height', 60) or 60)
    line_height = max(max(number_px, text_px) + 4,
                      min(60, int(round(size_height * 0.6))))
    block_format = cursor.blockFormat()
    # PyQt6 的枚举不能直接 int()，需取 .value 传入 setLineHeight 的 int 参数
    block_format.setLineHeight(
        float(line_height), block_format.LineHeightTypes.FixedHeight.value)
    for row in rows:
        cursor.setPosition(row['offset'])
        cursor.setBlockFormat(block_format)

    # 光标复位到第一行开头，避免残留选区影响复制整段文本
    cursor.setPosition(0)
    cursor.clearSelection()
    view.setTextCursor(cursor)


def _apply_number_strategy_detail_font(host, text_px):
    """设置「计算原理/分析说明」文本区的字号与间距。

    功能:
        按当前主题与文字字号重设详情区 QSS（背景、边框、前景、字号、内边距）。
    参数:
        host: 主窗口实例；详情控件为 host.number_pred_detail。
        text_px (int): 文字档位字号（来自角控件「文字 px」），内部再按 15px 下限钳制。
    返回:
        None。
    注意/副作用:
        - 只改 setStyleSheet，不改文本内容与计算结果；
        - 暗色主题 #1E1E2E 底 / #45475A 边框 / #F5F5F5 字，亮色为白底深字；
        - 详情控件不存在时静默返回；主题切换后再调用即可刷新。
    """
    dark = bool(getattr(host, 'is_dark_mode', False))
    bg = '#1E1E2E' if dark else '#FFFFFF'
    border = '#45475A' if dark else '#DDDDDD'
    fg = '#F5F5F5' if dark else '#1A1A1A'
    host.number_pred_detail.setStyleSheet(f"""
        QTextEdit {{ background-color: {bg}; border: 1px solid {border};
            border-radius: 4px; color: {fg}; font-size: {max(15, int(text_px))}px;
            font-weight: 500; padding: 6px; }}
    """)


def _render_number_strategy_text(host, strategies):
    """把七策略结果渲染成 7 行纯文本（策略名 + 正码 + 特别码）。

    功能:
        生成逐行文本写入结果控件，再交给 _apply_number_strategy_formats 上色与排版。
    参数:
        host: 主窗口实例；结果写入 host.number_pred_text。
        strategies (list[dict]): 预测器返回的 7 条策略结果，每条含 label/numbers/special。
    返回:
        None。
    注意/副作用:
        - 每行格式固定为「策略名 + 制表符 + 6 正码 + 加号 + 特别码」，特别码单独红色；
        - 文本先 setPlainText 再上色，保证复制出来的纯文本格式与界面完全一致；
        - 渲染期间关闭控件重绘并置 host._number_strategy_rendering=True，
          避免 cursorPositionChanged 回调 on_number_strategy_selected 刷屏；
        - finally 中恢复重绘与标志位；
        - 结果为空时由调用方决定占位提示，本函数输出空文本。
    """
    view = host.number_pred_text
    # 渲染期间 setPlainText / setTextCursor 会触发 cursorPositionChanged，
    # 用标志位阻止它回调 on_number_strategy_selected，避免说明区被半成品文本刷屏
    host._number_strategy_rendering = True
    try:
        view.setUpdatesEnabled(False)
        rows = _number_strategy_line_rows(host, strategies)
        view.setPlainText('\n'.join(row['text'] for row in rows))
        _apply_number_strategy_formats(host, rows)
    finally:
        view.setUpdatesEnabled(True)
        host._number_strategy_rendering = False


def refresh_number_strategy_styles(host):
    """角控件字号/尺寸变化后，同步刷新七策略文本与卡片两种视图的样式。

    功能:
        按当前主题与字号重设文本区/说明区的 QSS，并重排文本、强制重建卡片。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 只重排样式与行高，不重新计算；两种视图共用同一份计算结果；
        - 先按主题为颜色图例重新着色（字号独立不受影响）；
        - 写 number_pred_text / 标签 / 复选框 / 状态标签的 QSS，并调用 _refresh_number_card_styles；
        - 已有结果时调用 _render_number_strategy_text 与 _show_number_strategy_card(force=True)；
        - number_pred_text 或 number_pred_detail 不存在（页面尚未构建）时直接返回。
    """
    # 主题切换会调用本函数：先按当前主题为颜色图例重新着色（字号独立，不受影响）
    apply_legend_theme_colors(host)
    if not hasattr(host, 'number_pred_text') or not hasattr(host, 'number_pred_detail'):
        return
    _number_px, text_px = _number_strategy_fonts(host)
    theme = _number_card_theme(host)
    dark = bool(getattr(host, 'is_dark_mode', False))
    # 文本列表与说明区跟随主题：暗色深底浅字，亮色白底近纯黑
    host.number_pred_text.setStyleSheet(f"""
        QTextEdit {{ background-color: {'#1E1E2E' if dark else '#FFFFFF'};
            border: 1px solid {'#45475A' if dark else '#DDDDDD'};
            border-radius: 4px; padding: 4px 8px; color: {theme['fg']}; }}
    """)
    for label_attr in ('number_pred_view_label', 'number_pred_window_label'):
        label = getattr(host, label_attr, None)
        if label is not None:
            label.setStyleSheet(
                "font-size: 15px; color: %s; font-weight: 500;" % theme['secondary'])
    check = getattr(host, 'number_pred_hide_labels_check', None)
    if check is not None:
        check.setStyleSheet(
            "QCheckBox { font-size: 15px; color: %s; font-weight: 500; }"
            % theme['secondary'])
    if hasattr(host, 'number_pred_status_label'):
        _set_number_pred_status(host, host.number_pred_status_label.text(),
                                getattr(host, '_number_pred_status_kind', 'info'))
    _apply_number_strategy_detail_font(host, text_px)
    _refresh_number_card_styles(host)
    strategies = getattr(host, '_number_strategy_results', None)
    if strategies:
        _render_number_strategy_text(host, strategies)
        # 主题/字号/生肖变化后卡片里的内联颜色与字体需要重建，不能走「只换高亮」的快路径
        _show_number_strategy_card(
            host, getattr(host, '_number_strategy_selected_index', 0), force=True)


def render_number_strategy_results(host, result):
    """把 lib 返回的七策略结果渲染为逐行文本与卡片，并默认显示第一行说明

    功能:
        写入结果缓存与元信息，渲染文本/卡片，设置状态文字并在成功时落盘。
    参数:
        host: 主窗口实例。
        result (dict): NumberStrategyPredictor.predict_all 的返回值。
    返回:
        None。
    注意/副作用:
        - 写 host._number_strategy_results / _number_strategy_result_meta / _number_strategy_selected_index；
        - 每行严格为「策略名 + 制表符 + 正码 + `+` + 特别码」，策略名与正码列严格左对齐；
        - 卡片视图与文本视图共用这份 strategies，不重复计算；
        - 某策略失败时仍保留该行（正码显示「未生成」），错误原因在说明区展示；
        - result.ok 为真时写入「系统v7.5/上次预测_号码预测.json」并显示第一行说明，
          写盘失败不影响本次显示；失败时以状态文字提示，不丢失预测数据。
    """
    strategies = result.get('strategies', [])
    host._number_strategy_results = strategies
    host._number_strategy_result_meta = {
        'window': result.get('window', 0),
        'used_records': result.get('used_records', 0),
        'latest_period': result.get('latest_period', '') or '—',
    }
    host._number_strategy_selected_index = 0
    _render_number_strategy_text(host, strategies)
    _refresh_number_card_styles(host)
    if not strategies:
        # 空结果时清空卡片，避免上一轮号码球残留
        _show_number_strategy_card(host, 0)
    # 说明区字号与列表策略名共用「文字 px」
    _apply_number_strategy_detail_font(host, _number_strategy_fonts(host)[1])

    if result.get('ok'):
        _set_number_pred_status(
            host,
            "分析窗口 %d 期（参与 %d 期）｜最新期号 %s｜生成时间 %s"
            % (result.get('window', 0), result.get('used_records', 0),
               result.get('latest_period', ''), datetime.datetime.now().strftime('%H:%M:%S')),
            'ok')
        # 默认展示第一行说明，保持与旧版「默认选中第一行」的体验一致
        if strategies:
            show_number_strategy_detail(host, 0)
            # v0.0.49：生成成功后立即落盘，与主预测页「生成即保存」的时机一致，
            # 避免出现「界面上有结果、重启后为空」；写盘失败不影响本次显示。
            save_number_strategy_result(host, result)
    else:
        _set_number_pred_status(host, result.get('error') or '七策略未能生成有效结果', 'error')


def number_strategy_record_file(host):
    """返回号码预测（七策略）结果持久化文件路径

    功能:
        以主预测文件所在目录为基准，拼出「上次预测_号码预测.json」的绝对路径。
    参数:
        host: 主窗口实例，沿用 last_prediction_file 所在目录。
    返回:
        str: 「系统v7.5/上次预测_号码预测.json」的绝对路径。
    注意/副作用:
        - 只做路径拼接，不检查目录/文件是否存在，不创建文件；
        - 与既有「上次预测_算法预测_本次/上次.json」保持同一命名体系，
          不另建目录，也不复用主预测页的「上次预测.json」，避免两套结果覆盖。
    """
    base_dir = os.path.dirname(host.last_prediction_file)
    return os.path.join(base_dir, '上次预测_号码预测.json')


def save_number_strategy_result(host, result):
    """把七策略结果写入「系统v7.5/上次预测_号码预测.json」

    功能:
        组装生成时间/数据指纹/窗口/期号/策略明细，调用安全写入落盘。
    参数:
        host: 主窗口实例。
        result (dict): NumberStrategyPredictor.predict_all 的返回值。
    返回:
        bool: True 表示已成功写盘；False 表示未写入（数据不足/失败/异常）。
    注意/副作用:
        - 只在 ok 且有策略条目时落盘，避免数据不足或计算失败覆盖上一次可用结果；
        - 写盘沿用主窗口 _safe_write_json（重试 + 原子替换），不直接 open() 裸写；
        - 成功时写 host._number_strategy_persisted_index 与 _number_strategy_result_stale=False；
        - 写盘异常被捕获后打印日志并返回 False，不影响本次界面显示。
    """
    if not result or not result.get('ok'):
        return False
    strategies = result.get('strategies') or []
    if not strategies:
        return False
    try:
        payload = {
            'generated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'data_fingerprint': host._compute_data_fingerprint(),
            'window': int(result.get('window', 0) or 0),
            'used_records': int(result.get('used_records', 0) or 0),
            'latest_period': str(result.get('latest_period', '') or ''),
            'selected_index': int(getattr(host, '_number_strategy_selected_index', 0) or 0),
            'strategies': [],
        }
        for item in strategies:
            scores = item.get('scores') or {}
            payload['strategies'].append({
                'key': item.get('key', ''),
                'label': item.get('label', ''),
                'numbers': [int(n) for n in (item.get('numbers') or [])],
                'special': int(item.get('special') or 0),
                'scores': {int(k): float(v) for k, v in scores.items()},
                'principle': item.get('principle', ''),
                'analysis': item.get('analysis', ''),
                'error': item.get('error', ''),
            })
        if host._safe_write_json(number_strategy_record_file(host), payload):
            host._number_strategy_persisted_index = payload['selected_index']
            host._number_strategy_result_stale = False
            return True
    except Exception as e:
        print("保存号码预测结果失败: " + str(e))
    return False


def load_number_strategy_prediction(host):
    """启动时回填上次生成的七策略结果（不重算）

    功能:
        读取结果 JSON，恢复策略缓存、选中项与两种视图，并按数据指纹标注是否过期。
    参数:
        host: 主窗口实例。
    返回:
        bool: True 表示已回填，False 表示无文件/文件损坏/无有效策略。
    注意/副作用:
        - 写 host._number_strategy_results / _number_strategy_result_meta /
          _number_strategy_selected_index / _number_strategy_persisted_index /
          _number_strategy_result_stale；
        - 指纹一致：恢复文本列表 + 卡片视图 + 上次选中的 chip 与说明区；
        - 指纹不一致：保留旧结果用于对照，红字标注「数据已变化，需重新生成」；
        - 全程只读 JSON 并复用既有渲染函数，不调用 predict_all（不自动重算）；
        - 文件不存在、JSON 损坏或字段缺失时返回 False，不抛异常。
    """
    path = number_strategy_record_file(host)
    if not os.path.exists(path):
        return False
    try:
        with open(path, 'r', encoding='utf-8') as f:
            payload = json.load(f)
    except Exception as e:
        print("加载号码预测结果失败: " + str(e))
        return False

    raw_items = payload.get('strategies') or []
    if not raw_items:
        return False
    strategies = []
    for item in raw_items:
        scores = {}
        for key, value in (item.get('scores') or {}).items():
            try:
                # JSON 对象的键一律是字符串，这里转回 int，卡片指标按 int 查分
                scores[int(key)] = float(value)
            except (TypeError, ValueError):
                continue
        strategies.append({
            'key': item.get('key', ''),
            'label': item.get('label', ''),
            'numbers': [int(n) for n in (item.get('numbers') or [])],
            'special': int(item.get('special') or 0),
            'scores': scores,
            'principle': item.get('principle', ''),
            'analysis': item.get('analysis', ''),
            'error': item.get('error', ''),
        })

    host._number_strategy_results = strategies
    host._number_strategy_result_meta = {
        'window': int(payload.get('window', 0) or 0),
        'used_records': int(payload.get('used_records', 0) or 0),
        'latest_period': str(payload.get('latest_period', '') or '—'),
    }
    index = int(payload.get('selected_index', 0) or 0)
    index = max(0, min(index, len(strategies) - 1))
    host._number_strategy_selected_index = index
    host._number_strategy_persisted_index = index

    _render_number_strategy_text(host, strategies)
    _refresh_number_card_styles(host)
    _apply_number_strategy_detail_font(host, _number_strategy_fonts(host)[1])
    if hasattr(host, 'number_pred_cards_layout'):
        # 从文件恢复的是新一批 dict，强制重建，避免沿用上一轮的卡片
        _show_number_strategy_card(host, index, force=True)
    show_number_strategy_detail(host, index)

    saved_fp = payload.get('data_fingerprint') or ''
    current_fp = host._compute_data_fingerprint()
    generated_at = payload.get('generated_at') or '—'
    if saved_fp and saved_fp == current_fp:
        host._number_strategy_result_stale = False
        _set_number_pred_status(
            host,
            "已恢复上次生成结果（生成时间 %s｜分析窗口 %d 期｜最新期号 %s）"
            % (generated_at, host._number_strategy_result_meta['window'],
               payload.get('latest_period') or '—'),
            'ok')
    else:
        host._number_strategy_result_stale = True
        _set_number_pred_status(
            host,
            "⚠ 上次结果的数据已变化，需重新生成（旧结果已过期，仅供参考）"
            "｜上次期号 %s｜生成时间 %s"
            % (payload.get('latest_period') or '—', generated_at),
            'error')
    return True


def _persist_number_strategy_selection(host, index):
    """把当前选中的策略序号写回已落盘结果（不重算）

    功能:
        读取结果 JSON、更新 selected_index 字段并用安全写入落盘，同时更新已保存索引。
    参数:
        host: 主窗口实例。
        index (int): 当前选中的策略序号（0~6）。
    返回:
        None。
    注意/副作用:
        - chip/文本行切换只改变展示；结果文件存在时仅更新 selected_index，重启后可恢复；
        - 写 host._number_strategy_persisted_index；
        - 未生成（无文件）或索引未变化时静默跳过；
        - 写盘失败只打印日志，不影响当前会话的选中状态。
    """
    path = number_strategy_record_file(host)
    if not os.path.exists(path):
        return
    index = int(index)
    if index == getattr(host, '_number_strategy_persisted_index', None):
        return
    try:
        with open(path, 'r', encoding='utf-8') as f:
            payload = json.load(f)
        payload['selected_index'] = index
        if host._safe_write_json(path, payload):
            host._number_strategy_persisted_index = index
    except Exception as e:
        print("更新号码预测选中策略失败: " + str(e))


def on_number_strategy_selected(host):
    """点击某条策略结果：记录选中项并在详情区展示计算原理与分析说明。

    功能:
        读取文本光标所在行，更新选中索引后刷新详情与卡片，并持久化选中项。
    参数:
        host: 主窗口实例。
    返回:
        None。
    注意/副作用:
        - 写 host._number_strategy_selected_index；
        - 调用 show_number_strategy_detail（内部同步刷新卡片，避免重复重建球体）；
        - 调用 _persist_number_strategy_selection 写回 selected_index（写盘）；
        - 渲染中（_number_strategy_rendering）时直接返回，避免半成品文本触发回调；
        - 光标所在行越界时不改变选中项。
    """
    if getattr(host, '_number_strategy_rendering', False):
        return
    items = getattr(host, '_number_strategy_results', [])
    row = host.number_pred_text.textCursor().blockNumber()
    if 0 <= row < len(items):
        host._number_strategy_selected_index = row
        # show_number_strategy_detail 内已同步刷新卡片，避免重复重建球体
        show_number_strategy_detail(host, row)
        # 记住上次查看的策略，重启回填后可恢复选中 chip（不重算）
        _persist_number_strategy_selection(host, row)


def show_number_strategy_detail(host, row):
    """在详情区展示指定策略的计算原理、命中分析与号码来源。

    功能:
        取该策略的 principle/analysis 文本拼成说明区内容，并同步卡片选中态。
    参数:
        host: 主窗口实例。
        row (int): 策略在 host._number_strategy_results 中的下标；越界时清空详情。
    返回:
        None。
    注意/副作用:
        - 写 host.number_pred_detail 文本并把光标复位到开头；
        - 写 host._number_strategy_selected_index，并在卡片页存在时仅更新高亮；
        - 文本来自预测器结果中的 principle/analysis 字段；缺失时用固定模板说明口径；
        - 有 error 字段时追加错误段落；
        - 结果为空时显示「请先生成七策略」，控件不存在时直接返回。
    """
    items = getattr(host, '_number_strategy_results', [])
    if row < 0 or row >= len(items):
        host.number_pred_detail.clear()
        return
    data = items[row]
    principle = data.get('principle') or '（该策略未提供计算原理）'
    analysis = data.get('analysis') or '（该策略未生成分析说明）'
    lines = [
        '【%s】怎么计算（计算原理）' % data.get('label', ''),
        principle,
        '',
        '【分析说明】',
        analysis,
    ]
    if data.get('error'):
        lines.extend(['', '【错误】', data['error']])
    host.number_pred_detail.setPlainText('\n'.join(lines))
    cursor = host.number_pred_detail.textCursor()
    cursor.setPosition(0)
    host.number_pred_detail.setTextCursor(cursor)
    host._number_strategy_selected_index = row
    if hasattr(host, 'number_pred_cards_layout'):
        _show_number_strategy_card(host, row)


def on_export_report(host):
    """导出 HTML 分析报告（v0.0.46 自主窗口迁入本页）

    功能:
        收集当前预测号码球与历史数据，生成一份含「预测结果 / 算法说明 /
        最近5期历史 / 基本统计摘要」的 HTML 报告并写盘。
    参数:
        host: 主窗口实例。读取 host.prediction_number_layout、
            host.current_algorithm_index、host._analysis_records()；
            调用 host._safe_write_file 做原子写入。
    返回:
        None（用户取消保存对话框时直接返回）。
    注意/副作用:
        - 在用户选择的路径创建/覆盖 HTML 文件，故会写盘；
        - 成功弹「导出成功」、失败弹「导出失败」；_safe_write_file 失败时由其内部提示；
        - 报告 HTML 结构与文案与迁移前主窗口实现逐项一致；
        - 号码球为空时仍会导出报告，只是预测结果区没有号码；用户取消对话框不写文件。
    """
    file_path, _ = QFileDialog.getSaveFileName(host, "导出报告", "lottery_report.html", "HTML文件 (*.html)")
    if not file_path:
        return

    try:
        algo_name = "未知算法"
        if 0 <= host.current_algorithm_index < len(LotteryConfig.ALGORITHMS):
            algo_name = LotteryConfig.ALGORITHMS[host.current_algorithm_index][0]

        numbers = []
        for i in range(host.prediction_number_layout.count()):
            item = host.prediction_number_layout.itemAt(i)
            if item and item.widget() and isinstance(item.widget(), NumberButton):
                numbers.append(item.widget().get_number())
        numbers = sorted(numbers)

        # 号码带颜色HTML
        nums_html = ""
        for n in numbers:
            color = "#000000"
            if LotteryConfig.is_red(n):
                color = "#FF0000"
            elif LotteryConfig.is_blue(n):
                color = "#0000FF"
            else:
                color = "#008000"
            nums_html += '<span style="color:' + color + '; font-size:24px; font-weight:bold; margin:0 4px;">' + str(n).zfill(2) + '</span>'

        # 统计/报表统一取数：优先 DuckDB，失败回退内存
        records = host._analysis_records()[0]

        # 最近5期历史
        history_rows = ""
        for record in records[:5]:
            period = record.get('period', '?')
            nums = record.get('numbers', [])
            special = record.get('special', 0)
            date_str = record.get('date', '')
            nums_str = ' '.join(str(n).zfill(2) for n in nums)
            history_rows += '<tr><td>' + str(period) + '</td><td>' + str(date_str) + '</td><td>' + nums_str + '</td><td>' + str(special).zfill(2) + '</td></tr>'

        # 基本统计
        stats_html = ""
        if records:
            all_nums = []
            for r in records:
                all_nums.extend(r.get('numbers', []))
            counter = Counter(all_nums)
            hot = counter.most_common(5)
            cold = counter.most_common()[-5:]
            hot_str = ', '.join(str(n).zfill(2) + '(' + str(c) + ')' for n, c in hot)
            cold_str = ', '.join(str(n).zfill(2) + '(' + str(c) + ')' for n, c in cold)

            odd_total = sum(1 for n in all_nums if n % 2 == 1)
            even_total = len(all_nums) - odd_total
            big_total = sum(1 for n in all_nums if n > 24)
            small_total = len(all_nums) - big_total

            stats_html = (
                '<p>热门号码: ' + hot_str + '</p>'
                '<p>冷门号码: ' + cold_str + '</p>'
                '<p>单双比: ' + str(odd_total) + ':' + str(even_total) + '</p>'
                '<p>大小比: ' + str(big_total) + ':' + str(small_total) + '</p>'
                '<p>总数据量: ' + str(len(records)) + ' 期</p>'
            )

        report_html = (
            '<!DOCTYPE html><html><head><meta charset="utf-8"><title>彩票预测系统分析报告</title>'
            '<style>'
            'body { font-family: "Microsoft YaHei", "SimHei", "SimSun", Arial, sans-serif; background: #FFFFFF; color: #333; padding: 40px; }'
            'h1 { color: #3498DB; border-bottom: 2px solid #3498DB; padding-bottom: 10px; }'
            'h2 { color: #3498DB; margin-top: 30px; }'
            'table { border-collapse: collapse; width: 100%; margin: 10px 0; }'
            'th, td { border: 1px solid #DDD; padding: 8px 12px; text-align: center; }'
            'th { background-color: #F8F9FA; color: #333; }'
            '.prediction-box { background: #FFFFFF; border: 2px solid #2ECC71; border-radius: 8px; padding: 20px; margin: 15px 0; text-align: center; }'
            '.section { margin: 20px 0; padding: 15px; border: 1px solid #DDD; border-radius: 6px; background: #FFFFFF; }'
            '</style></head><body>'
            '<h1>彩票预测系统分析报告</h1>'
            '<p>生成时间: ' + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + '</p>'
            '<div class="section"><h2>预测结果</h2>'
            '<div class="prediction-box">' + nums_html + '</div>'
            '<p>使用算法: ' + algo_name + '</p></div>'
            '<div class="section"><h2>使用算法说明</h2>'
            '<p>' + algo_name + ': '
        )

        if 0 <= host.current_algorithm_index < len(LotteryConfig.ALGORITHMS):
            report_html += LotteryConfig.ALGORITHMS[host.current_algorithm_index][1]
        else:
            report_html += "综合多种算法得出最优预测"
        report_html += '</p></div>'

        report_html += (
            '<div class="section"><h2>最近5期历史数据</h2>'
            '<table><tr><th>期号</th><th>日期</th><th>正码</th><th>特别码</th></tr>'
            + history_rows +
            '</table></div>'
            '<div class="section"><h2>基本统计摘要</h2>'
            + stats_html +
            '</div></body></html>'
        )

        # 使用安全写入方法保存HTML报告
        if host._safe_write_file(file_path, report_html):
            QMessageBox.information(host, "导出成功", "分析报告已保存到:\n" + file_path)
        # 失败信息由_safe_write_file内部处理
    except Exception as e:
        QMessageBox.warning(host, "导出失败", "报告生成失败: " + str(e))


def install(host):
    """安装「预测与抽取」选项卡：先挂本页事件，再构建界面（v0.0.28 分批迁移）

    功能:
        把本页函数以 lambda 形式绑定到主窗口实例，然后调用 build 构建页面。
    参数:
        host: 主窗口实例。
    返回:
        QWidget: 构建完成的页面。
    注意/副作用:
        - 一次性写大量 host._xxx 方法（事件绑定），是主窗口与 TAB 页的桥接层；
        - 已迁移「概率统计」4 个事件与「字号/列宽/图例/详情标签」9 个事件；
          跨页基础设施仍保留在主窗口；「导出报告」事件（v0.0.46）也由本页负责；
        - lambda 延迟绑定 host，避免模块导入期依赖主窗口；
        - 本函数只重绑事件并调用 build，不销毁/重建已有页面；控件或注册表缺失时异常向外抛，由启动流程记录。
    """
    host._update_probability_panel = lambda: update_probability_panel(host)
    host._on_probability_item_double_clicked = lambda item: on_probability_item_double_clicked(host, item)
    host._on_copy_top_probability = lambda: copy_top_probability(host)
    host._update_zodiac_probability = lambda: update_zodiac_probability(host)
    host._apply_prediction_ball_size = lambda: apply_prediction_ball_size(host)
    host._apply_legend_font_size = lambda: apply_legend_font_size(host)
    host._change_legend_font = lambda direction: change_legend_font(host, direction)
    host._apply_detail_label_size = lambda: apply_detail_label_size(host)
    host._change_detail_label_font = lambda direction: change_detail_label_font(host, direction)
    host._on_pred_num_font_changed = lambda size: on_pred_num_font_changed(host, size)
    host._on_pred_text_font_changed = lambda size: on_pred_text_font_changed(host, size)
    host._update_prediction_balls_font_size = lambda: update_prediction_balls_font_size(host)
    host._apply_calc_panel_config = lambda: apply_calc_panel_config(host)
    host._apply_wave_panel_config = lambda: apply_wave_panel_config(host)
    host._apply_calc_panel_size = lambda: apply_calc_panel_size(host)
    host._copy_calc_result = lambda: copy_calc_result(host)
    host._export_calc_result = lambda: export_calc_result(host)
    host._apply_wave_panel_size = lambda: apply_wave_panel_size(host)
    host._copy_wave_result = lambda: copy_wave_result(host)
    host._export_wave_result = lambda: export_wave_result(host)
    host._update_calc_method_panel = lambda: update_calc_method_panel(host)
    host._update_wave_color_panel = lambda: update_wave_color_panel(host)
    host._load_saved_predictions = lambda: load_saved_predictions(host)
    host._on_save_current_prediction = lambda: on_save_current_prediction(host)
    host._on_load_saved_prediction = lambda: on_load_saved_prediction(host)
    host._on_delete_saved_prediction = lambda: on_delete_saved_prediction(host)
    host._on_clear_saved_predictions = lambda: on_clear_saved_predictions(host)
    host._on_show_saved_prediction_detail = lambda: on_show_saved_prediction_detail(host)
    host._on_compare_saved_predictions = lambda: on_compare_saved_predictions(host)
    host._on_collect_prediction = lambda: on_collect_prediction(host)
    host._on_compare_collected = lambda: on_compare_collected(host)
    host._on_clear_collected = lambda: on_clear_collected(host)
    host._on_weight_adjust_clicked = lambda: on_weight_adjust_clicked(host)
    host._load_last_prediction_for_type = lambda pred_type: load_last_prediction_for_type(host, pred_type)
    host._on_prediction_type_changed = lambda pred_type: on_prediction_type_changed(host, pred_type)
    host._animate_prediction_balls = lambda balls: animate_prediction_balls(host, balls)
    host._save_last_prediction = lambda predictions, confidence_info=None, algorithm_name="", special_num=0: save_last_prediction(host, predictions, confidence_info, algorithm_name, special_num)
    host._on_algorithm_changed = lambda index: on_algorithm_changed(host, index)
    host._compute_data_fingerprint = lambda: compute_data_fingerprint(host)
    host._on_predict_clicked = lambda: on_predict_clicked(host)
    host._run_prediction_in_main_thread = lambda seed: run_prediction_in_main_thread(host, seed)
    host._on_predict_finished = lambda predictions, confidence_info: on_predict_finished(host, predictions, confidence_info)
    host._on_predict_error = lambda error_msg: on_predict_error(host, error_msg)
    host._on_random_draw_clicked = lambda: on_random_draw_clicked(host)
    host._on_lock_predict_toggled = lambda checked: on_lock_predict_toggled(host, checked)
    host._on_model_cache_toggled = lambda checked: on_model_cache_toggled(host, checked)
    host._on_ml_predict_clicked = lambda: on_ml_predict_clicked(host)
    host._run_ml_prediction_in_main_thread = lambda seed: run_ml_prediction_in_main_thread(host, seed)
    host._on_ml_predict_finished = lambda predictions, all_probs_dict=None: on_ml_predict_finished(host, predictions, all_probs_dict)
    host._on_ml_predict_error = lambda error_msg: on_ml_predict_error(host, error_msg)
    host._select_zodiac_group_numbers = lambda scores_dict, count=6: select_zodiac_group_numbers(host, scores_dict, count)
    host._predict_special_number = lambda predictions: predict_special_number(host, predictions)
    host._on_enhanced_mode_changed = lambda state: on_enhanced_mode_changed(host, state)
    host._on_strategy_changed = lambda index: on_strategy_changed(host, index)
    host._on_deterministic_mode_changed = lambda state: on_deterministic_mode_changed(host, state)
    host._set_deterministic_seed = lambda: set_deterministic_seed(host)
    host._update_last_vs_current_display = lambda current_numbers, current_algo_name, current_special=None, pred_type_override=None: update_last_vs_current_display(host, current_numbers, current_algo_name, current_special, pred_type_override)
    host._display_predictions = lambda predictions, confidence_info=None: display_predictions(host, predictions, confidence_info)
    # 号码预测（七策略）：按钮点击与表格选中行 → 详情区
    host._on_number_strategy_predict = lambda: on_number_strategy_predict(host)
    host._on_number_strategy_selected = lambda: on_number_strategy_selected(host)
    # v0.0.48：文本列表 / 卡片视图切换、生肖五行标签开关、复制当前视图
    host._on_number_strategy_view_changed = lambda index=0: on_number_strategy_view_changed(host, index)
    host._on_number_strategy_labels_toggled = lambda checked=False: on_number_strategy_labels_toggled(host, checked)
    host._on_number_strategy_copy = lambda: copy_number_strategy_text(host)
    host._on_export_report = lambda: on_export_report(host)
    return build(host)


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "预测与抽取",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 3,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """组装「预测与抽取」选项卡页面：左右分栏 + 拉伸比例 + 外边距。

    功能:
        创建页面与横向 QSplitter，依次装配左右面板，设置 1:2 拉伸并恢复分栏尺寸。
    参数:
        host: 主窗口实例（LotteryPredictionWindow）。
    返回:
        QWidget: 可直接加入主窗口 QTabWidget 的页面控件。
    注意/副作用:
        - 写 host.pred_h_splitter；左栏为数据/算法区，右栏为五个子选项卡；
        - 通过 host._apply_splitter_sizes 读取 INI 恢复分栏比例（只读 INI，不写盘）；
        - 外边距使用 host.margin_left/top/right/bottom 与 spacing；
        - 子面板构建异常会向上抛，由主窗口加载流程统一记录；本函数不吞异常。
    """
    widget = QWidget()
    host.pred_h_splitter = QSplitter(Qt.Orientation.Horizontal)
    host.pred_h_splitter.setHandleWidth(2)

    left_panel = _build_left_prediction_panel(host)
    host.pred_h_splitter.addWidget(left_panel)

    right_panel = _build_right_prediction_panel(host)
    host.pred_h_splitter.addWidget(right_panel)

    host.pred_h_splitter.setStretchFactor(0, 1)
    host.pred_h_splitter.setStretchFactor(1, 2)
    host._apply_splitter_sizes(host.pred_h_splitter, 'pred_h_splitter')

    layout = QVBoxLayout(widget)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)
    layout.setSpacing(host.spacing)
    layout.addWidget(host.pred_h_splitter)

    return widget
