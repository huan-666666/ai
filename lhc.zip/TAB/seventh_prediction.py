# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/seventh_prediction.py - 「第七位预判」选项卡页面构建模块
===========================================================================
模块职责：
    1. 构建「第七位预判」选项卡：上方“大小/单双/尾数/综合预判”按钮区与
       特别码专项分析按钮区，下方只读结果文本框，中间竖向分隔器；
    2. 实现第七位（特别码）的统计型预判：大小、单双、尾数大小、综合；
    3. 实现特别码频率图、走势图、正码关联度分析三个 matplotlib 弹窗。

依赖：
    - UI/UI.py 统一导出的 Qt 控件（禁止在本页直接 import PyQt6）
    - lib/data_process.LotteryConfig：
        is_red / is_blue / is_green   频率图柱色分波
        NUMBER_NAMES                  关联分析结果里的生肖列
    - lib/plot_draw：_get_mpl / get_figure_module / get_canvas_class，
      统一获取 matplotlib 对象（插件层禁止直接 import matplotlib）
    - host.historical_data：开奖记录列表，每条至少含 numbers / special / period
    - host（LotteryPredictionWindow）提供 _apply_splitter_sizes 等基础设施

在架构中的位置：
    位于 TAB/ 选项卡界面层，属于“界面构建 + 页面事件”自包含模块（v0.0.28 起）。
    统计与绘图都在本页完成，不进入 lib 的算法层；matplotlib 仅经 lib/plot_draw
    访问，以便缺失时统一降级。

数据流：
    host.historical_data → 逐条读取 special 字段
        → predict_seventh_*() 统计并拼装文本 → host.seventh_result_text
        → show_special_*() 绘图 → 模态对话框展示（关闭时释放 Figure）
    关联分析：正码集合 × 特别码 → 共现计数 → 每个特别码的总得分 → Top 10 文本

预判口径（详见各函数说明）：
    大小：1~24 小、25~49 大（special > 24 记大）
    单双：special % 2，奇数为单
    尾数：tail = special % 10，0~4 为小尾、5~9 为大尾
    综合：三个维度分别取历史占比高的一方，再按三维条件筛候选号码
    置信度：直接取占优一方的历史占比（不是模型概率），单维度函数才会输出

导出对象：
    TAB_INFO                 选项卡元信息（title / order / enabled）
    install(host)            唯一安装入口：挂事件回调 + 构建页面
    build(host)              仅构建页面（由 install 内部调用）
    show_special_* / predict_seventh_*   本页分析与预判函数（host 由闭包传入）

功能说明：
    构建主窗口「第七位预判」选项卡的全部界面控件，并挂载到主窗口实例上。

职责边界（v0.0.28 起本页自包含）：
    - 本模块负责界面构建（布局、控件、初始样式）与本页事件处理函数
    - 主窗口 LotteryPredictionWindow 的同名方法仅作兼容转发（lambda 已挂到 host）
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import os as _os_boot  # 作用说明：提供 dirname/abspath/exists/join 等路径能力，用于向上定位项目根目录
import sys as _sys_boot  # 作用说明：提供 sys.path 访问，用于把项目根目录加入模块搜索路径以支持直接运行本文件

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QDialog, QHBoxLayout, QLabel, QMessageBox, QPushButton, QSplitter, QTextEdit, QVBoxLayout, QWidget, Qt)  # 作用说明：统一获取本页所需的 Qt 控件（对话框/布局/标签/消息框/按钮/分割器/文本框）及 Qt 枚举，避免直接 import PyQt6
# 第七位的特别码频率/走势/关联得分/三维预判全部由 lib/data_process.py 计算
from lib.data_process import (  # 作用说明：引入三色判定/生肖名与特别码频率、走势、关联、大小/单双/尾数/综合预判的统计实现，本页只负责取数与拼装文本
    LotteryConfig, build_special_frequency, build_special_trend,
    compute_special_correlation, compute_seventh_size,
    compute_seventh_odd_even, compute_seventh_tail, compute_seventh_all,
)
from lib.plot_draw import _get_mpl, get_canvas_class, get_figure_module  # 作用说明：提供 matplotlib 的惰性加载与 Figure/Canvas 访问器，避免插件层直接 import matplotlib，缺失时统一降级



# ╔══════════════════════════════════════════════════════════════════╗
# ║  [第七位预判：大小/单双/尾数/综合预判与特别码图表]
# ╚══════════════════════════════════════════════════════════════════╝

def show_special_frequency_chart(host):
    """显示特别码频率分布图（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        统计全部历史记录中 1~49 特别码的出现次数，弹出对话框绘制柱状图，
        柱色按红/蓝/绿波色区分，并在每根柱顶标注次数。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；读取 host.historical_data
            中每条记录的 'special' 字段。

    返回:
        None

    副作用:
        创建并 exec() 一个 900×600 的模态对话框（阻塞到用户关闭）；
        缺少历史数据/特别码数据/ matplotlib 时弹提示并提前返回；
        对话框 finished 时调用 fig.clf() 释放图表资源。

    说明:
        为什么过滤 1 <= sp <= 49：缺失或异常的 special 常被写成 0，
        若不剔除会在 x 轴出现 0 号柱，误导阅读；过滤后只画有效号码。
        matplotlib 对象必须经 lib.plot_draw 获取，不能直接 import，
        这样 matplotlib 缺失时本页只降级提示，不影响程序启动。
    """
    if not host.historical_data:
        QMessageBox.information(host, "提示", "没有历史数据，请先导入数据！")
        return

    # 统计特别码频率（1~49 过滤口径由 lib.data_process 统一实现）
    special_freq = build_special_frequency(host.historical_data)

    if not special_freq:
        QMessageBox.information(host, "提示", "没有特别码数据")
        return

    # 创建对话框显示图表
    dialog = QDialog(host)
    dialog.setWindowTitle("特别码频率分布图")
    dialog.setFixedSize(900, 600)

    layout = QVBoxLayout(dialog)

    # 创建matplotlib图表
    _get_mpl()
    # 【规范】matplotlib对象经lib.plot_draw访问器函数获取，无需global声明
    if get_figure_module() is None or get_canvas_class() is None:
        QMessageBox.warning(host, "错误", "无法加载matplotlib库")
        dialog.close()
        return

    fig = get_figure_module()(figsize=(10, 6))
    canvas = get_canvas_class()(fig)
    ax = fig.add_subplot(111)

    numbers = sorted(special_freq.keys())
    counts = [special_freq[n] for n in numbers]

    colors = []
    for num in numbers:
        if LotteryConfig.is_red(num):
            colors.append('#FF0000')
        elif LotteryConfig.is_blue(num):
            colors.append('#0000FF')
        else:
            colors.append('#008000')

    bars = ax.bar(numbers, counts, color=colors, edgecolor='white', linewidth=0.5)
    ax.set_xlabel('号码', fontsize=15)
    ax.set_ylabel('出现次数', fontsize=15)
    ax.set_title('特别码频率分布图', fontsize=15, fontweight='bold')
    ax.set_xticks(numbers)
    ax.grid(axis='y', alpha=0.3)

    # 添加数值标签
    for bar, count in zip(bars, counts):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2., height, str(int(height)), ha='center', va='bottom', fontsize=15)

    fig.tight_layout()
    canvas.draw()

    layout.addWidget(canvas)

    close_btn = QPushButton("关闭")
    # 关闭按钮点击信号：关闭当前对话框

    close_btn.clicked.connect(dialog.accept)
    layout.addWidget(close_btn)

    # 【修复资源泄漏bug】对话框关闭时释放matplotlib图表资源
    dialog.finished.connect(lambda: fig.clf())

    dialog.exec()


def show_special_trend_chart(host):
    """显示特别码走势图（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        取最近 30 期的有效特别码，按时间顺序画折线图并叠加均值虚线。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；读取 host.historical_data
            中每条记录的 'special' 与 'period'。

    返回:
        None

    副作用:
        创建并 exec() 一个 900×500 的模态对话框；数据不足或 matplotlib
        不可用时给提示并返回；对话框 finished 时调用 fig.clf() 释放图表资源。

    说明:
        recent = list(reversed(historical_data[:30]))：假定历史记录按时间倒序
        （最新在前），反转后图表从左到右才是时间正序。
        TODO(待确认): 若导入逻辑实际按正序存储，走势方向与期号会颠倒，
        需与数据导入端确认排序约定。
        30 期窗口：TODO(待确认) 代码未说明为何取 30，按经验只展示近期趋势；
        期号标签每 5 期显示一个，避免 x 轴文字挤在一起。
    """
    if not host.historical_data:
        QMessageBox.information(host, "提示", "没有历史数据，请先导入数据！")
        return

    # 获取最近30期特别码（lib 负责反转成时间正序并过滤无效值）
    periods, specials = build_special_trend(host.historical_data, 30)

    if not specials:
        QMessageBox.information(host, "提示", "没有特别码数据")
        return

    # 创建对话框显示图表
    dialog = QDialog(host)
    dialog.setWindowTitle("特别码走势图")
    dialog.setFixedSize(900, 500)

    layout = QVBoxLayout(dialog)

    _get_mpl()
    # 【规范】matplotlib对象经lib.plot_draw访问器函数获取，无需global声明
    if get_figure_module() is None or get_canvas_class() is None:
        QMessageBox.warning(host, "错误", "无法加载matplotlib库")
        dialog.close()
        return

    fig = get_figure_module()(figsize=(12, 5))
    canvas = get_canvas_class()(fig)
    ax = fig.add_subplot(111)

    x = range(len(specials))
    ax.plot(x, specials, 'o-', color='#F39C12', markersize=8, linewidth=2, markeredgecolor='#E67E22')

    # 添加均值线
    avg_val = sum(specials) / len(specials)
    ax.axhline(y=avg_val, color='#3498DB', linestyle='--', linewidth=1.5, label='均值: ' + "{:.1f}".format(avg_val))

    ax.set_xlabel('期数', fontsize=15)
    ax.set_ylabel('特别码', fontsize=15)
    ax.set_title('特别码走势图（最近' + str(len(specials)) + '期）', fontsize=15, fontweight='bold')
    ax.set_xticks(x[::5])
    ax.set_xticklabels([periods[i] for i in range(0, len(periods), 5)], rotation=45)
    ax.set_ylim(0, 50)
    ax.grid(True, alpha=0.3)
    ax.legend(loc='upper right')

    fig.tight_layout()
    canvas.draw()

    layout.addWidget(canvas)

    close_btn = QPushButton("关闭")
    # 关闭按钮点击信号：关闭当前对话框

    close_btn.clicked.connect(dialog.accept)
    layout.addWidget(close_btn)

    # 【修复资源泄漏bug】对话框关闭时释放matplotlib图表资源
    dialog.finished.connect(lambda: fig.clf())

    dialog.exec()


def show_special_correlation_analysis(host):
    """正码与特别码关联度分析（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        统计每个特别码与正码的共现次数，按总分排序取前 10 名，
        在结果文本框输出“排名/特别码/得分/颜色/生肖”。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；读取 host.historical_data
            中每条记录的 'numbers'（正码列表）与 'special'。

    返回:
        None

    副作用:
        覆盖 host.seventh_result_text 的纯文本（不弹窗、不写盘）；
        无数据时弹 information 并返回。

    说明:
        cooccurrence[正码][特别码] 逐期累加；某特别码的得分 = 它在各正码
        计数下的总和，等价于“该特别码出现时，同期的正码共现总次数”，
        得分越高说明它与正码组合越常见。
        Top 10：TODO(待确认) 10 是展示截断值，代码未给出业务依据。
        颜色判定先判 is_blue / is_green，其余一律记“红”，与 lib 的三色
        定义顺序一致（默认红为基准色）。
    """
    if not host.historical_data:
        QMessageBox.information(host, "提示", "没有历史数据，请先导入数据！")
        return

    # 共现矩阵、1~49 特别码得分与 Top10 排序全部由 lib 计算
    _special_scores, sorted_specials = compute_special_correlation(
        host.historical_data, 10)

    # 改造前的判空口径是「没有任何正码-特别码共现」；lib 始终返回 1~49 的
    # 全量得分，因此以「Top10 得分全为 0」作为等价的无数据条件
    if not any(score for _, score in sorted_specials):
        QMessageBox.information(host, "提示", "没有足够的关联数据")
        return

    # 显示结果
    result_text = "正码与特别码关联度分析（Top 10）\n"
    result_text += "=" * 50 + "\n\n"
    result_text += "排名  特别码  关联得分  颜色  生肖\n"
    result_text += "-" * 50 + "\n"

    for rank, (sp, score) in enumerate(sorted_specials, 1):
        color_name = "红"
        if LotteryConfig.is_blue(sp):
            color_name = "蓝"
        elif LotteryConfig.is_green(sp):
            color_name = "绿"
        zodiac = LotteryConfig.NUMBER_NAMES.get(sp, "")
        result_text += str(rank) + "    " + str(sp).zfill(2) + "     " + str(score) + "     " + color_name + "    " + zodiac + "\n"

    result_text += "\n" + "=" * 50 + "\n"
    result_text += "说明：关联得分越高，说明该特别码与正码共同出现的频率越高\n"
    result_text += "建议关注这些高关联度的特别码\n"

    host.seventh_result_text.setPlainText(result_text)


def predict_seventh_size(host):
    """第七位大小预判（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        统计历史特别码中“大号(25-49)”与“小号(1-24)”的次数，取占优一方作为预判。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；读取 host.historical_data
            中每条记录的 'special'。

    返回:
        None

    副作用:
        覆盖 host.seventh_result_text 的纯文本；无数据时写入提示文本；
        异常时弹 warning 并把堆栈打印到控制台，不向外抛出。

    说明:
        口径：special > 24 记大，其余（含 0）记小。
        置信度直接取占优一方的历史占比（不是模型概率），平局时因判断用的是
        “>”，会落到“小”。
        v0.0.42：先过滤 1~49 的有效特别码，缺失/异常值不再计入小号。
    """
    try:
        if not host.historical_data:
            host.seventh_result_text.setPlainText("没有历史数据，请先导入数据！")
            return
        # 计数、比例、平局口径（> 比较落到「小」）由 lib 统一计算
        stats = compute_seventh_size(host.historical_data)
        if stats is None:
            host.seventh_result_text.setPlainText("没有有效的特别码数据")
            return
        big_count = stats['big_count']
        small_count = stats['small_count']
        big_ratio = stats['big_ratio']
        small_ratio = stats['small_ratio']
        prediction = stats['prediction']
        confidence = stats['confidence']
        result = "第七位大小预判结果\n" + "="*40 + "\n\n"
        result += "历史数据统计：\n"
        result += "   大号(25-49)出现次数：" + str(big_count) + " 次 (" + "{:.1f}".format(big_ratio) + "%)\n"
        result += "   小号(1-24)出现次数：" + str(small_count) + " 次 (" + "{:.1f}".format(small_ratio) + "%)\n\n"
        result += "预判结果：" + prediction + "\n"
        result += "   置信度：" + "{:.1f}".format(confidence) + "%\n\n"
        result += "建议：下一期第七位号码倾向于「" + prediction + "」范围"
        host.seventh_result_text.setPlainText(result)
    except Exception as e:
        QMessageBox.warning(host, "预判错误", "大小预判时发生错误：\n" + str(e))
        import traceback  # 作用说明：提供 print_exc 打印完整异常堆栈到控制台，弹窗之外便于排查预判失败原因
        traceback.print_exc()


def predict_seventh_odd_even(host):
    """第七位单双预判（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        统计历史特别码中单号与双号的次数，取占优一方作为预判。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；读取 host.historical_data
            中每条记录的 'special'。

    返回:
        None

    副作用:
        覆盖 host.seventh_result_text 的纯文本；无数据时写入提示文本。

    说明:
        口径：special % 2 == 1 记单，其余记双。总数按有效特别码计算；
        若 total 为 0，比例兜底为 50%，因判断用“>”会预判“双”。
        v0.0.42：先过滤 1~49 的有效特别码，缺失/为 0 的记录不再计入双号。
    """
    if not host.historical_data:
        host.seventh_result_text.setPlainText("没有历史数据，请先导入数据！")
        return
    # 计数、比例兜底 50%（无样本时平局落到「双」）由 lib 统一计算
    stats = compute_seventh_odd_even(host.historical_data)
    odd_count = stats['odd_count']
    even_count = stats['even_count']
    odd_ratio = stats['odd_ratio']
    even_ratio = stats['even_ratio']
    prediction = stats['prediction']
    confidence = stats['confidence']
    result = "第七位单双预判结果\n" + "="*40 + "\n\n"
    result += "历史数据统计：\n"
    result += "   单号出现次数：" + str(odd_count) + " 次 (" + "{:.1f}".format(odd_ratio) + "%)\n"
    result += "   双号出现次数：" + str(even_count) + " 次 (" + "{:.1f}".format(even_ratio) + "%)\n\n"
    result += "预判结果：" + prediction + "\n"
    result += "   置信度：" + "{:.1f}".format(confidence) + "%\n\n"
    result += "建议：下一期第七位号码倾向于「" + prediction + "」数"
    host.seventh_result_text.setPlainText(result)


def predict_seventh_tail(host):
    """第七位尾数大小预判（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        按特别码个位数（tail = special % 10）统计大尾(5-9)与小尾(0-4)次数，
        取占优一方作为预判。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；读取 host.historical_data
            中每条记录的 'special'。

    返回:
        None

    副作用:
        覆盖 host.seventh_result_text 的纯文本；无数据时写入提示文本。

    说明:
        尾数只看个位，与号码大小无关；总数为 0 时比例兜底 50%，
        平局同样因“>”落到“小尾(0-4)”。
        v0.0.42：先过滤 1~49 的有效特别码，缺失为 0 时不再计入小尾。
    """
    if not host.historical_data:
        host.seventh_result_text.setPlainText("没有历史数据，请先导入数据！")
        return
    # 尾数 0~4 小尾、5~9 大尾；比例兜底与平局口径由 lib 统一计算
    stats = compute_seventh_tail(host.historical_data)
    big_tail_count = stats['big_tail_count']
    small_tail_count = stats['small_tail_count']
    big_ratio = stats['big_ratio']
    small_ratio = stats['small_ratio']
    prediction = stats['prediction']
    confidence = stats['confidence']
    result = "第七位尾数大小预判结果\n" + "="*40 + "\n\n"
    result += "历史数据统计：\n"
    result += "   大尾(5-9)出现次数：" + str(big_tail_count) + " 次 (" + "{:.1f}".format(big_ratio) + "%)\n"
    result += "   小尾(0-4)出现次数：" + str(small_tail_count) + " 次 (" + "{:.1f}".format(small_ratio) + "%)\n\n"
    result += "预判结果：" + prediction + "\n"
    result += "   置信度：" + "{:.1f}".format(confidence) + "%\n\n"
    result += "建议：下一期第七位号码尾数倾向于「" + prediction + "」范围"
    host.seventh_result_text.setPlainText(result)


def predict_seventh_all(host):
    """第七位综合预判（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        同时统计大小、单双、尾数三个维度，取各自占优特征后，筛出同时满足
        三维条件的候选号码并输出综合预判文本。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；读取 host.historical_data
            中每条记录的 'special'。

    返回:
        None

    副作用:
        覆盖 host.seventh_result_text 的纯文本；无历史数据时写入提示文本。

    说明:
        候选号码按 1~49 逐个检查 size_ok / odd_ok / tail_ok 三个条件，
        输出最多 10 个（recommended[:10]），超出时追加总数提示。
        三个维度平局时都会落到“小/双/小尾”（判断统一用 “>”）。
        v0.0.42：先过滤 1~49 的有效特别码，样本数只统计有效记录，
        缺失/为 0 的记录不再被归入小、双、小尾。
        建议“关注号码范围”只是三维条件的交集，不涉及概率排序。
    """
    if not host.historical_data:
        host.seventh_result_text.setPlainText("没有历史数据，请先导入数据！")
        return
    # 三维计数、预判标签与候选号码交集全部由 lib 计算
    stats = compute_seventh_all(host.historical_data)
    big_count = stats['big_count']
    small_count = stats['small_count']
    odd_count = stats['odd_count']
    even_count = stats['even_count']
    big_tail_count = stats['big_tail_count']
    small_tail_count = stats['small_tail_count']
    total = stats['total']  # 有效特别码期数（大小统计覆盖全部有效值）
    size_pred = stats['size_pred']
    odd_even_pred = stats['odd_even_pred']
    tail_pred = stats['tail_pred']
    result = "第七位综合预判结果\n" + "="*40 + "\n\n"
    result += "数据样本：" + str(total) + " 期\n\n"
    result += "大小分析：大号" + str(big_count) + "次 小号" + str(small_count) + "次 -> 预判：" + size_pred + "\n"
    result += "单双分析：单数" + str(odd_count) + "次 双数" + str(even_count) + "次 -> 预判：" + odd_even_pred + "\n"
    result += "尾数分析：大尾" + str(big_tail_count) + "次 小尾" + str(small_tail_count) + "次 -> 预判：" + tail_pred + "\n\n"
    result += "综合预判结果：\n"
    result += "   第七位号码特征：" + size_pred + " + " + odd_even_pred + " + " + tail_pred + "\n\n"
    result += "建议关注号码范围："
    recommended = stats['recommended']
    if recommended:
        result += "\n   " + ', '.join(str(n) for n in recommended[:10])
        if len(recommended) > 10:
            result += " ... 等共" + str(len(recommended)) + "个号码"
    host.seventh_result_text.setPlainText(result)


def install(host):
    """安装本选项卡：绑定事件处理函数后构建界面（v0.0.28 起页面自包含）

    功能:
        本页唯一安装入口。把七个分析与预判函数以 lambda 挂到 host 私有属性，
        再调用 build(host) 创建并返回页面。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        QWidget: 构建完成的页面。

    副作用:
        在 host 上挂 _show_special_frequency_chart、_show_special_trend_chart、
        _show_special_correlation_analysis、_predict_seventh_size、
        _predict_seventh_odd_even、_predict_seventh_tail、
        _predict_seventh_all 共 7 个回调；build() 会创建本页控件并连接信号。

    说明:
        必须先挂回调再 build：按钮在 build 时立即 connect 这些属性；
        lambda 闭包把 host 固定进处理函数，主窗口的同名方法仅保留兼容转发。
    """
    host._show_special_frequency_chart = lambda: show_special_frequency_chart(host)
    host._show_special_trend_chart = lambda: show_special_trend_chart(host)
    host._show_special_correlation_analysis = lambda: show_special_correlation_analysis(host)
    host._predict_seventh_size = lambda: predict_seventh_size(host)
    host._predict_seventh_odd_even = lambda: predict_seventh_odd_even(host)
    host._predict_seventh_tail = lambda: predict_seventh_tail(host)
    host._predict_seventh_all = lambda: predict_seventh_all(host)
    return build(host)


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "第七位预判",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 5,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """构建「第七位预判」选项卡页面

    功能:
        创建上下两段式页面：上段为预判按钮组与特别码专项分析按钮组，
        下段为只读结果文本框，中间用竖向分隔器隔离。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备 spacing、margin_*、
            _apply_splitter_sizes 等基础设施。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        在 host 上创建 seventh_pred_splitter 与 seventh_result_text；
        连接 4 个预判按钮与 3 个图表按钮到 install() 挂好的回调；
        恢复分隔器记忆尺寸（未保存时按 1:2 分配）。

    说明:
        seventh_result_text 设为只读，所有输出由分析函数整体 setPlainText 覆盖，
        避免用户在结果区误输入。上段按钮分两组：预判组用全局按钮样式，
        图表组用内联彩色样式（蓝/紫/橙）区分“统计/趋势/关联”三类分析。
    """
    widget = QWidget()
    host.seventh_pred_splitter = QSplitter(Qt.Orientation.Vertical)
    host.seventh_pred_splitter.setHandleWidth(2)

    # ======================================================================== #
    # 功能8：特别码专项分析 - 顶部分析按钮
    # ======================================================================== #
    top_panel = QWidget()
    top_layout = QVBoxLayout(top_panel)
    top_layout.setSpacing(15)
    top_layout.setContentsMargins(10, 10, 10, 10)

    title = QLabel("第七位数字预判")
    title.setObjectName("PanelTitle")
    top_layout.addWidget(title)

    desc = QLabel("根据历史数据分析第七位特别号码的大小、单双、尾数特征")
    desc.setObjectName("DescLabel")
    top_layout.addWidget(desc)

    btn_group = QWidget()
    btn_layout = QHBoxLayout(btn_group)
    btn_layout.setSpacing(20)

    size_btn = QPushButton("大小预判")
    # 大小预判按钮点击信号：预测第七位的大小属性

    size_btn.clicked.connect(host._predict_seventh_size)
    btn_layout.addWidget(size_btn)

    odd_even_btn = QPushButton("单双预判")
    # 单双预判按钮点击信号：预测第七位的单双属性

    odd_even_btn.clicked.connect(host._predict_seventh_odd_even)
    btn_layout.addWidget(odd_even_btn)

    tail_btn = QPushButton("尾数大小预判")
    # 尾数预判按钮点击信号：预测第七位的尾数属性

    tail_btn.clicked.connect(host._predict_seventh_tail)
    btn_layout.addWidget(tail_btn)

    all_btn = QPushButton("综合预判")
    # 综合预判按钮点击信号：预测第七位的所有属性

    all_btn.clicked.connect(host._predict_seventh_all)
    btn_layout.addWidget(all_btn)

    top_layout.addWidget(btn_group)

    # ======================================================================== #
    # 功能8：特别码专项分析 - 新增分析按钮
    # ======================================================================== #
    special_btn_group = QWidget()
    special_btn_layout = QHBoxLayout(special_btn_group)
    special_btn_layout.setSpacing(20)

    special_freq_btn = QPushButton("特别码频率图")
    # 特别码频率图按钮样式 - 蓝色系（频率分析用蓝色表示"数据/统计"）
    #   QPushButton {       按钮常态样式
    #     background-color: #3498DB;  背景色：蓝色（数据/统计主题色）
    #     color: white;               文字颜色：白色
    #     border: none;               边框：无边框（现代扁平风格）
    #     border-radius: 6px;         圆角：6px
    #     padding: 8px 16px;          内边距：上下8px，左右16px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #2980B9;  悬停背景色：深蓝（交互反馈）
    #   }
    special_freq_btn.setStyleSheet("QPushButton { background-color: #3498DB; color: white; border: none; border-radius: 6px; padding: 8px 16px; font-weight: bold; } QPushButton:hover { background-color: #2980B9; }")
    # 特别码频率图表按钮点击信号：显示特别码出现频率统计

    special_freq_btn.clicked.connect(host._show_special_frequency_chart)
    special_btn_layout.addWidget(special_freq_btn)

    special_trend_btn = QPushButton("特别码走势图")
    # 特别码走势图按钮样式 - 紫色系（走势/趋势分析用紫色表示"分析/洞察"）
    #   QPushButton {       按钮常态样式
    #     background-color: #9B59B6;  背景色：紫色（趋势分析主题色）
    #     color: white;               文字颜色：白色
    #     border: none;               边框：无边框（现代扁平风格）
    #     border-radius: 6px;         圆角：6px
    #     padding: 8px 16px;          内边距：上下8px，左右16px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #8E44AD;  悬停背景色：深紫（交互反馈）
    #   }
    special_trend_btn.setStyleSheet("QPushButton { background-color: #9B59B6; color: white; border: none; border-radius: 6px; padding: 8px 16px; font-weight: bold; } QPushButton:hover { background-color: #8E44AD; }")
    # 特别码趋势图表按钮点击信号：显示特别码走势趋势

    special_trend_btn.clicked.connect(host._show_special_trend_chart)
    special_btn_layout.addWidget(special_trend_btn)

    special_correlation_btn = QPushButton("正码关联分析")
    # 正码关联分析按钮样式 - 橙色系（关联分析用橙色表示"关联/交叉"）
    #   QPushButton {       按钮常态样式
    #     background-color: #E67E22;  背景色：橙色（关联分析主题色）
    #     color: white;               文字颜色：白色
    #     border: none;               边框：无边框（现代扁平风格）
    #     border-radius: 6px;         圆角：6px
    #     padding: 8px 16px;          内边距：上下8px，左右16px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #D35400;  悬停背景色：深橙（交互反馈）
    #   }
    special_correlation_btn.setStyleSheet("QPushButton { background-color: #E67E22; color: white; border: none; border-radius: 6px; padding: 8px 16px; font-weight: bold; } QPushButton:hover { background-color: #D35400; }")
    # 特别码相关性分析按钮点击信号：显示特别码与正码相关性

    special_correlation_btn.clicked.connect(host._show_special_correlation_analysis)
    special_btn_layout.addWidget(special_correlation_btn)

    top_layout.addWidget(special_btn_group)
    top_layout.addStretch()

    host.seventh_pred_splitter.addWidget(top_panel)

    bottom_panel = QWidget()
    bottom_layout = QVBoxLayout(bottom_panel)
    bottom_layout.setContentsMargins(10, 10, 10, 10)

    result_title = QLabel("预判结果")
    result_title.setObjectName("ResultTitleLabel")
    bottom_layout.addWidget(result_title)

    host.seventh_result_text = QTextEdit()
    host.seventh_result_text.setReadOnly(True)
    host.seventh_result_text.setPlaceholderText("点击上方按钮进行预判...")
    bottom_layout.addWidget(host.seventh_result_text)

    host.seventh_pred_splitter.addWidget(bottom_panel)
    host.seventh_pred_splitter.setStretchFactor(0, 1)
    host.seventh_pred_splitter.setStretchFactor(1, 2)
    host._apply_splitter_sizes(host.seventh_pred_splitter, 'seventh_pred_splitter')

    layout = QVBoxLayout(widget)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)
    layout.setSpacing(host.spacing)
    layout.addWidget(host.seventh_pred_splitter)

    return widget
