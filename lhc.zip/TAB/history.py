# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/history.py - 「历史记录」选项卡页面构建模块
===========================================================================
模块职责：
    1. 构建「历史记录」页全部界面：左侧“最新开奖数据 + 九列分页表格”，
       右侧“快捷操作网格 + 期号详情富文本面板”
    2. 实现本页全部交互：排序/分页、列宽记忆、详情 HTML 渲染与字号缩放、
       批量添加/删除/修改、JSON/CSV/TXT 导入导出
    3. v0.0.28 起本页自包含：实现全部在本模块；历史表格渲染也已迁入本模块

在架构中的位置：
    界面层 TAB/ 的一个页面模块，由主窗口在创建选项卡时调用 install(host)；
    数据与跨页共用设施（_save_data、_parse_import_file、
    _on_clear_data_clicked、_save_ini_config）仍留在 plugins/彩票预测.py。

依赖：
    - UI：Qt 控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import ...
    - HistoryBallDelegate（本模块内定义）：本地历史表整表委托，自绘号码球与
      生肖/五行，选中时只改背景不改文字，且不创建任何 QWidget
    - lib.data_process.DataUtils：批量添加时解析原始开奖文本
    - lib.data_process.LotteryConfig：号码颜色（border/text）、红蓝绿分组、
      生肖五行名称等只读配置
    - 本模块不直接 import numpy/pandas/matplotlib，表格渲染无需重型库

数据流：
    JSON 历史文件 --(主窗口加载/导入)--> host.historical_data
        list[dict]，约定“最新在前”，每项含 period/date/numbers/special
    -> 本模块 update_history_table 按 history_page / history_page_size 切片
    -> 本页九列渲染：期号/日期/正码/特别码/和值/单双比/大小比/颜色分布/跨度
    -> 用户点「显示选中」后，on_show_period_detail 生成号码球 HTML 存入
       host._original_detail_html，再由 _apply_detail_font_scale 统一缩放
    -> 批量编辑、导入、导出最终写回 JSON（host._save_data / _safe_write_json）

导出对象：
    TAB_INFO            选项卡声明（title=历史记录，order=2）
    install(host)       挂载 16 个 host._xxx 回调，再调用 build 构建页面
    build(host)         纯界面构建，返回页面 QWidget
    其余函数            可由 install 绑定，也可被主窗口兼容方法转发调用

约束：
    - 只做界面与交互，不实现数据抓取、预测算法
    - v0.0.36 已完成的角控件 40px 共用逻辑、_ResponsiveStatusRow、
      15px 字号下限与既有逐属性样式注释均保持原样
===========================================================================
"""

import csv  # 作用说明：导出 CSV 时按列写表头与号码，由标准库处理逗号/引号转义
import datetime  # 作用说明：站点模板示例年份与日期偏移计算
import json  # 作用说明：解析在线库 meta 中保存的警告 JSON（只读展示，不参与本地数据）
import re  # 作用说明：详情 HTML 的字号缩放需批量匹配并替换 font-size:Npx/pt
import threading  # 作用说明：在线抓取用锁保护“关闭连接”回调，供取消时跨线程打断阻塞读取
import time  # 作用说明：自动抓取会话缓存用 monotonic 计时（30 分钟 TTL）
import os as _os_boot  # 作用说明：仅在直接运行本文件调试时，向上探测含 run.py 的项目根目录
import sys as _sys_boot  # 作用说明：把探测到的项目根插入模块搜索路径，保证直接运行时可 import UI/TAB

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QAbstractItemView, QButtonGroup, QCheckBox, QColor, QComboBox, QEvent, QFileDialog, QFont, QFontMetrics, QGridLayout, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QMessageBox, QObject, QPainter, QPen, QPoint, QPushButton, QRect, QSpinBox, QSplitter, QStackedWidget, QStyle, QStyledItemDelegate, QStyleOptionFocusRect, QTableWidget, QTableWidgetItem, QTextEdit, QThread, QTimer, QVBoxLayout, QWidget, Qt, pyqtSignal, pyqtSlot)  # 作用说明：统一从 UI/UI.py 取 Qt 控件与枚举，本页不直接 import PyQt6；QStyle/QStyleOptionFocusRect 供自绘委托保留键盘焦点框；QButtonGroup 供在线页「列表/同期对照」视图切换
from UI import QDialog  # 作用说明：站点编辑对话框（新增/编辑站点与 url_template）
from lib.data_process import DataUtils, LotteryConfig  # 作用说明：DataUtils 解析批量添加的文本，LotteryConfig 提供号码波色/红蓝绿分组与生肖五行只读配置
from lib.online_source import (OnlineSourceError, dedupe_records, detect_source, fetch_url, host_is_registered, normalize_url_input, parse_payload, summarize, unknown_site_detail, unsupported_site_detail)  # 作用说明：在线抓取/识别/解析/去重/摘要（纯逻辑，无 Qt）；normalize_url_input 负责粘贴网址归一化
from lib import online_sites  # 作用说明：站点注册表只来自 系统v7.5/在线站点.json，代码内不预置任何站点/域名/网址
from lib import online_store  # 作用说明：独立在线库 系统v7.5/在线开奖.db 的建表、增量写入、keyset 分页与清空
from TAB.online_compare import open_online_compare_dialog, refresh_online_compare  # 作用说明：抓取后在线/本地三类差异提示与冲突手工处理（默认只提示不写入）
from TAB.same_period_view import build_same_period_view, ensure_same_period_loaded  # 作用说明：在线页第二视图「同期对照」，不声明 TAB_INFO，不新增第 15 个选项卡


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "历史记录",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 2,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def apply_detail_font_scale(host):
    """以原始详情 HTML 为基准，按 detail_font_scale 重新缩放全部内联字号

    功能：
        详情面板的 A+/A- 按钮只改变缩放比例，不重新计算统计内容。本函数用
        正则替换 HTML 中所有 `font-size:Npx/pt`，把 N 乘以当前比例后写回
        QTextEdit，并强制下限 15px（遵循全局最小字号约定）。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。读取
            host._original_detail_html（未缩放的基准 HTML）与
            host.detail_font_scale（float，1.0 为原始大小）；写入
            host.period_detail_edit（QTextEdit，只读富文本框）。

    返回:
        None。

    副作用:
        - 直接改写 period_detail_edit 的显示内容；
        - 始终以 _original_detail_html 重算，多次缩放不会累积误差；
        - 页面尚未构建（无基准 HTML 或详情框）时静默跳过，不抛异常。

    异常:
        内部不抛出；re.sub 的替换回调只在匹配到纯数字时执行，不会产生 ValueError。
    """
    if not hasattr(host, '_original_detail_html') or not host._original_detail_html:
        return
    scale = getattr(host, 'detail_font_scale', 1.0)
    scaled_html = re.sub(
        r'font-size:(\d+)(px|pt)',
        lambda m: 'font-size:' + str(max(15, int(int(m.group(1)) * scale))) + m.group(2),
        host._original_detail_html
    )
    host.period_detail_edit.setHtml(scaled_html)


def change_detail_font_size(host, delta):
    """调节期号详情字体缩放比例并立即重绘

    功能：
        由详情面板的 A-/A+ 按钮调用；缩放比例钳制在 0.5~2.0，变化量小于
        0.01 时视为无变化（避免数值抖动反复重绘）。改变后立即刷新详情并把
        新比例写入配置，重启后保持。

    参数:
        host: 主窗口实例，读写 host.detail_font_scale；
        delta: float，缩放变化量（A- 传 -0.1，A+ 传 +0.1），正数放大、负数缩小。

    返回:
        None。

    副作用:
        - 修改 host.detail_font_scale；首次调用时若属性不存在则先置 1.0；
        - 调用 host._apply_detail_font_scale() 重写详情框 HTML；
        - 状态栏显示百分比提示，并调用 host._save_ini_config() 持久化。

    异常:
        未捕获异常；host 缺少 statusBar 时不提示（正常主窗口均有）。
    """
    if not hasattr(host, 'detail_font_scale'):
        host.detail_font_scale = 1.0
    new_scale = host.detail_font_scale + delta
    # 限制缩放范围 0.5 ~ 2.0
    new_scale = max(0.5, min(2.0, new_scale))
    if abs(new_scale - host.detail_font_scale) < 0.01:
        return
    host.detail_font_scale = new_scale
    host._apply_detail_font_scale()
    host.statusBar().showMessage("字体缩放: " + str(int(host.detail_font_scale * 100)) + "%")
    # 保存字体缩放设置
    host._save_ini_config()


def on_history_col_resized(host, index, old_size, new_size):
    """历史记录表列宽变化回调：合并连续拖动，延迟 500ms 保存

    功能:
        QHeaderView.sectionResized 在拖动过程中每像素都会触发；若每次都写
        INI 会造成大量磁盘 I/O 与卡顿，因此用单次 QTimer 做防抖，停止拖动
        500ms 后才真正落盘。

    参数:
        host: 主窗口实例；
        index: int，被调整的列索引（当前仅信号签名需要，不参与保存逻辑）；
        old_size: int，调整前宽度（像素，未使用）；
        new_size: int，调整后宽度（像素，未使用）。

    返回:
        None。

    副作用:
        - 首次调用时在 host 上创建 host._col_resize_timer（QTimer，父对象为
          host，setSingleShot(True)，timeout 连接 host._save_history_col_widths）；
        - 之后每次触发都重新 start(500)，实现防抖；
        - 记录 host._history_col_user_touched / _history_col_base_widths，供运行时
          跨档自适应保留用户拖拽比例（程序内 setColumnWidth 触发的一律忽略）。
    """
    # 程序内自适应/启动恢复触发的列宽变化不算用户手动调整：
    # 启动阶段（布局未稳定、_history_col_ready 仍为 False）一律不记基准、不排保存，
    # 否则恢复/校正算出的列宽会被当成用户拖拽写进 [Display] 记忆键。
    if getattr(host, '_history_cols_applying', False):
        return
    if not getattr(host, '_history_col_ready', False):
        return
    table = getattr(host, 'history_table', None)
    if table is not None:
        host._history_col_user_touched = True
        host._history_col_base_widths = [table.columnWidth(i) for i in range(table.columnCount())]
    # 使用定时器延迟保存，避免拖动时频繁写文件
    if not hasattr(host, '_col_resize_timer'):
        host._col_resize_timer = QTimer(host)
        host._col_resize_timer.setSingleShot(True)
        host._col_resize_timer.timeout.connect(host._save_history_col_widths)
    host._col_resize_timer.start(500)  # 500ms后保存


def save_history_col_widths(host):
    """把历史记录表 9 列当前宽度写入 INI 并落盘

    功能:
        遍历 history_table 的全部列，生成键 history_col_0 ... history_col_8，
        写入 [Display] 段后调用主窗口保存；下次启动 build 时优先读取这些宽度。

    参数:
        host: 主窗口实例。读取 host.history_table（QTableWidget）、
            host._ini（ConfigParser）、调用 host._save_ini_config()。

    返回:
        None。

    副作用:
        - 修改 host._ini['Display'] 的多个键；
        - 调用 host._save_ini_config() 触发实际写文件；
        - 表格尚未构建（无 history_table 或 _ini 无 Display 段）时静默返回。
    """
    if not hasattr(host, 'history_table'):
        return
    for i in range(host.history_table.columnCount()):
        width = host.history_table.columnWidth(i)
        key = 'history_col_' + str(i)
        if hasattr(host, '_ini') and host._ini.has_section('Display'):
            host._ini['Display'][key] = str(width)
    host._save_ini_config()


def on_history_sort(host, order):
    """按日期对历史记录原地排序并刷新表格

    功能:
        以每条记录的 date 字段为键排序。日期统一为 YYYY-MM-DD 定长格式，
        字符串字典序等价于时间序，因此直接按字符串比较；排序后回到第 1 页。

    参数:
        host: 主窗口实例，读取/改写 host.historical_data（list[dict]）；
        order: str，'asc' 表示按日期从旧到新，其余值一律按从新到旧。

    返回:
        None。

    副作用:
        - 原地重排 host.historical_data；
        - 重置 host.history_page = 1，并调用 update_history_table(host) 重新
          切片渲染（分页标签、统计摘要、最新期展示随之更新）；
        - 状态栏提示当前排序方向；
        - 异常仅打印堆栈（不弹窗），避免排序失败打断用户操作。
    """
    if not host.historical_data or len(host.historical_data) == 0:
        return

    try:
        if order == 'asc':
            # 升序：按日期从旧到新
            host.historical_data.sort(key=lambda x: str(x.get('date', '')), reverse=False)
        else:
            # 降序：按日期从新到旧
            host.historical_data.sort(key=lambda x: str(x.get('date', '')), reverse=True)

        # 重置到第一页
        host.history_page = 1
        host._update_history_table()

        order_text = "升序" if order == 'asc' else "降序"
        if hasattr(host, 'statusBar'):
            host.statusBar().showMessage(f"历史记录已按日期{order_text}排列")
    except Exception:
        import traceback  # 作用说明：排序异常时打印完整调用栈，便于定位而不弹窗打断用户
        traceback.print_exc()


def on_prev_page(host):
    """翻到上一页（第 1 页时不动）

    功能:
        页码大于 1 时减 1，并通过 host._update_history_table() 按新的页码
        重新切片渲染；已在第 1 页时保持不动，避免无效重绘。

    参数:
        host: 主窗口实例，读写 host.history_page。

    返回:
        None。

    副作用:
        - 页码大于 1 时减 1，并调用 update_history_table(host) 重新渲染；
        - 已在第 1 页时直接返回，不触发重绘。
    """
    if host.history_page > 1:
        host.history_page -= 1
        host._update_history_table()


def on_next_page(host):
    """翻到下一页（末页时不动）

    功能:
        先按总条数与每页条数算出总页数（向上取整且至少 1 页），未到末页时
        页码加 1 并调用 host._update_history_table() 重新渲染；已到末页时
        保持不动，避免越界。

    参数:
        host: 主窗口实例，读取 host.historical_data、host.history_page_size，
            读写 host.history_page。

    返回:
        None。

    副作用:
        - 总页数按 ceil(总条数/每页条数) 计算且至少为 1；
        - 未到末页时页码加 1 并调用 update_history_table(host) 重新渲染。
    """
    total_pages = max(1, (len(host.historical_data) + host.history_page_size - 1) // host.history_page_size)
    if host.history_page < total_pages:
        host.history_page += 1
        host._update_history_table()


def on_page_jump(host, page):
    """跳转到指定页码（越界时忽略）

    功能:
        由分页 QSpinBox 的 valueChanged 触发；先按总条数重算总页数，只在
        [1, total_pages] 范围内接受跳转，避免页码输入框与数据量不同步时越界。

    参数:
        host: 主窗口实例；
        page: int，目标页码。

    返回:
        None。

    副作用:
        - 合法时写 host.history_page 并调用 update_history_table(host)；
        - 随后调用 host._save_ini_config() 记忆当前页码；
        - 越界时不产生任何界面变化。
    """
    total_pages = max(1, (len(host.historical_data) + host.history_page_size - 1) // host.history_page_size)
    if 1 <= page <= total_pages:
        host.history_page = page
        host._update_history_table()
        # 保存当前页码
        host._save_ini_config()


def update_pagination(host, total_count):
    """按总条数刷新分页标签与页码输入框

    功能:
        由 update_history_table 在每次渲染后调用；计算总页数，把当前
        页钳制到合法范围，并同步“第 X 页 / 共 Y 页”文本与 SpinBox 范围/值。

    参数:
        host: 主窗口实例，读写 host.history_page；
        total_count: int，当前筛选/排序后的历史记录总条数。

    返回:
        None。

    副作用:
        - 修改 host.history_page（只向下钳制，不会改变合法页码）；
        - 更新 host.history_page_label 文本、host.history_page_spin 的
          setRange(1, total_pages) 与 setValue；
        - 页面尚未构建（分页控件不存在）时直接返回：update_history_table
          可能在历史页构建之前就被其它页触发。
    """
    # 兼容历史页尚未构建的时机（update_history_table 可能更早被调用，如首屏 install 前）
    if not hasattr(host, 'history_page_label') or not hasattr(host, 'history_page_spin'):
        return
    total_pages = max(1, (total_count + host.history_page_size - 1) // host.history_page_size)
    host.history_page = min(host.history_page, total_pages)
    host.history_page_label.setText("第 " + str(host.history_page) + " 页 / 共 " + str(total_pages) + " 页")
    # 同步页码时屏蔽 valueChanged：否则 setValue 会回调 on_page_jump，再触发一次
    # update_history_table，使每次翻页/刷新都被重复渲染两遍（实测耗时翻倍）
    previous = host.history_page_spin.blockSignals(True)
    try:
        host.history_page_spin.setRange(1, total_pages)
        host.history_page_spin.setValue(host.history_page)
    finally:
        host.history_page_spin.blockSignals(previous)


def refresh_latest_display(host):
    """把最新一期开奖渲染到“最新开奖数据”标签

    功能:
        读取 host.historical_data[0]（约定列表最新在前），拼成“期号|日期 /
        正码 / 特别码”三段文本并写入标签；无数据时显示“暂无数据”。

    参数:
        host: 主窗口实例，读取 host.historical_data。

    返回:
        None。

    副作用:
        - 同时修改 host.history_latest_display 与 host.latest_display 的文本；
        - 两个标签都缺失时静默返回（兼容页面尚未构建的时机）。

    说明:
        历史页控件名为 history_latest_display，预测页控件名为 latest_display；
        两个控件存在时都刷新，避免只更新其中一个而导致另一页显示过期。
    """
    targets = [getattr(host, name, None) for name in
               ('history_latest_display', 'latest_display')]
    targets = [label for label in targets if label is not None]
    # 两个页面都尚未构建时静默返回
    if not targets:
        return
    if not host.historical_data:
        for label in targets:
            label.setText("暂无数据")
        return
    latest = host.historical_data[0]
    numbers = latest.get('numbers', [])
    special = latest.get('special', 0)
    numbers_text = ' '.join(str(n).zfill(2) for n in numbers)
    text = "第" + str(latest.get('period', '?')) + "期 | " + latest.get('date', '?') + "\n"
    text += "正码: " + numbers_text + "\n"
    text += "特别码: " + str(special).zfill(2)
    for label in targets:
        label.setText(text)


# [本地历史表：号码球 + 生肖/五行 委托渲染]

# 两档几何参数（键 False=1180 档，True=1600 档）
# ball=球径，num_px=号码字号，sub_px=球下生肖/五行字号，slot=每个号码占位宽，
# gap=号码槽间距，row=行高。与 docs/设计稿/历史记录-号码球/设计方案.md 3.2/3.4 一致。
HISTORY_BALL_SPECS = {
    False: {"ball": 24, "num_px": 16, "sub_px": 15, "slot": 38, "gap": 10, "row": 46},
    True: {"ball": 28, "num_px": 18, "sub_px": 15, "slot": 44, "gap": 8, "row": 52},
}

# 九列默认宽度：1180 档合计 748，1600 档合计 1000（设计稿 3.3）
HISTORY_COL_WIDTHS_SMALL = [50, 96, 284, 54, 38, 54, 54, 80, 38]
HISTORY_COL_WIDTHS_LARGE = [64, 110, 400, 72, 54, 72, 72, 104, 52]

# 九列最小宽（合计 742，同时满足内容与 15px 表头不省略）
# 分期号 44 / 日期 97（16px 日期字 89px + 单元格 8px 边距）/ 正码 280（6×38 槽位+5×10 间距）/
# 特别码 55 / 和值 40 / 单双比 55 / 大小比 55 / 颜色分布 76 / 跨度 40。
# 三字表头（特别码/单双比/大小比）15px 字宽 45 + 表头内边距 10，故最小 55；
# 左栏最小宽 762 扣除滚动条与边框后表体视口 748，恰好容纳 742 的九列最小宽，1180 档不出横滚。
HISTORY_COL_MIN_WIDTHS = [44, 97, 280, 55, 40, 55, 55, 76, 40]

# 两套主题令牌（取值见设计稿 5.1；对比度自查见 5.2）
HISTORY_BALL_TOKENS = {
    False: {
        'row0': '#FFFFFF', 'row1': '#F8F9FA', 'sel': '#D6EAF8', 'grid': '#EEEEEE', 'text': '#1A1A1A',
        'ball_bg': '#FFFFFF', 'special_bg': '#23262F', 'special_text': '#FFFFFF',
        'red': ('#C62828', '#FF0000'), 'blue': ('#1557B0', '#0000FF'), 'green': ('#1B6E34', '#008000'),
        'snap': '#1E7A46', 'live': '#A35200', 'missing': '#6B7280',
    },
    True: {
        'row0': '#1E1E2E', 'row1': '#24243A', 'sel': '#45475A', 'grid': '#45475A', 'text': '#F5F5F5',
        'ball_bg': '#313244', 'special_bg': '#F5F5F5', 'special_text': '#1E1E2E',
        'red': ('#FF8A8A', '#FF6B6B'), 'blue': ('#89B4FA', '#89B4FA'), 'green': ('#A6E3A1', '#A6E3A1'),
        'snap': '#A6E3A1', 'live': '#FAB387', 'missing': '#8A91A8',
    },
}

# H54 暗色补丁令牌：与主窗口 QSS 暗色分支保持同一套取值，不新造色板。
# bg/card/text/secondary/border 分别对应主窗口的 bg/card/fg/#A6ADC8/#7F849C；
# border 相对 #313244 实测 3.4:1，满足边框 ≥3:1 的验收线。
HISTORY_DARK_TOKENS = {
    'bg': '#1E1E2E',
    'card': '#313244',
    'text': '#F5F5F5',
    'secondary': '#A6ADC8',
    'border': '#7F849C',
    'hover': '#45475A',
    'pressed': '#585B70',
    'accent': '#89B4FA',
    'success': '#A6E3A1',
    'danger': '#FF8A8A',
}


def _history_is_dark(host):
    """读取当前主题开关；缺失属性时按亮色处理"""
    return bool(getattr(host, 'is_dark_mode', False))


def _register_history_theme(host, widget, light_qss, dark_qss):
    """登记一个需要随主题切换的内联样式控件

    功能:
        暗色主题下本页若干控件在构建期写死了亮色内联样式，主窗口切换主题时
        不会重新执行本页构建代码。这里统一登记 light/dark 两套样式，并安装
        一个事件过滤器：主窗口每次 setStyleSheet（含主题切换）后，按当前
        is_dark_mode 重新套用对应样式，亮色分支保持原字符串逐字节不变。

    参数:
        host: 主窗口实例；
        widget: 目标控件；
        light_qss (str | None): 亮色样式；None 表示亮色下不设局部样式（继承全局）；
        dark_qss (str): 暗色样式。

    返回:
        None。
    """
    registry = getattr(host, '_history_theme_widgets', None)
    if registry is None:
        registry = []
        host._history_theme_widgets = registry
        host._history_theme_filter = _HistoryThemeSync(host)
        host.installEventFilter(host._history_theme_filter)
    registry.append((widget, light_qss, dark_qss))
    widget.setStyleSheet(dark_qss if _history_is_dark(host) else (light_qss or ''))


def _apply_history_theme(host):
    """按当前主题重新套用本页全部已登记的内联样式"""
    for widget, light_qss, dark_qss in getattr(host, '_history_theme_widgets', ()):
        try:
            widget.setStyleSheet(dark_qss if _history_is_dark(host) else (light_qss or ''))
        except RuntimeError:
            # 控件已随父级销毁：忽略，避免切换主题时抛异常
            pass


class _HistoryThemeSync(QObject):
    """监听主窗口 StyleChange（主题/字号重建样式表）并回套本页内联样式"""

    def __init__(self, host):
        super().__init__(host)
        self._host = host

    def eventFilter(self, obj, event):
        if obj is self._host and event.type() == QEvent.Type.StyleChange:
            QTimer.singleShot(0, lambda: _apply_history_theme(self._host))
        return False


def history_ball_is_large(host):
    """判断当前窗口属于哪一档几何（宽 ≥1500 视为 1600 档）

    参数:
        host: 主窗口实例（QWidget）。
    返回:
        bool: True=1600 档，False=1180 档。
    """
    try:
        width = int(host.width())
    except Exception:
        width = 0
    if width <= 0:
        width = 1180
    return width >= 1500


def _fit_history_col_widths(widths, available):
    """把九列宽度收进可用宽：等比收缩、每列不低于最小内容宽、合计不超视口

    功能:
        运行时窗口跨档缩放后，列宽必须保证 `horizontalScrollBar().maximum()==0`。
        若候选合计本就 ≤ 可用宽，原样返回（右侧留白，不强行拉伸）；
        若超出，则按比例收缩并对每列保底 HISTORY_COL_MIN_WIDTHS；
        仅当连最小宽都放不下（可用宽 < 700）时才允许出现横向滚动条并返回最小宽。

    参数:
        widths: list[int]，候选九列宽（档位默认值或用户拖拽后的基准宽）；
        available: int，表格视口可用宽（已扣除纵向滚动条与边框）。

    返回:
        list[int]: 收缩后的九列宽。
    """
    widths = [max(1, int(w)) for w in widths]
    if available <= 0 or len(widths) != len(HISTORY_COL_MIN_WIDTHS):
        return widths
    total = sum(widths)
    if total <= available:
        return widths
    mins = HISTORY_COL_MIN_WIDTHS
    if sum(mins) >= available:
        # 极限窗口：九列最小宽都放不下，只能允许横向滚动（1180 最小窗口不会到达）
        return list(mins)
    k = float(available) / float(total)
    out = [max(mins[i], int(widths[i] * k)) for i in range(len(widths))]
    # 取整后可能仍多出几像素：只从“大于最小宽”的列回收，保证合计恰好等宽
    over = sum(out) - available
    guard = 0
    while over > 0 and guard < 200:
        idx = max(range(len(out)), key=lambda j: out[j] - mins[j])
        room = out[idx] - mins[idx]
        if room <= 0:
            break
        cut = min(room, over)
        out[idx] -= cut
        over -= cut
        guard += 1
    return out


def _fill_history_col_widths(widths, available):
    """把九列按比例铺满可用宽（不足时退回收进视口），右侧不留空白

    功能:
        启动时磁盘上可能留着历史遗留的压缩列宽（例如合计 702），本函数把它
        等比放大到恰好等于视口宽；若候选本身就超出视口，则交给
        `_fit_history_col_widths` 等比收缩。全程只改列宽，不写盘、不记为用户拖拽。

    参数:
        widths: list[int]，候选九列宽；
        available: int，表格视口可用宽（已扣除纵向滚动条与边框）。

    返回:
        list[int]: 恰好等于 available 的九列宽（可用宽 ≤0 或列数不符时原样返回）。
    """
    widths = [max(1, int(w)) for w in widths]
    if available <= 0 or len(widths) != len(HISTORY_COL_MIN_WIDTHS):
        return widths
    total = sum(widths)
    if total >= available:
        return _fit_history_col_widths(widths, available)
    mins = HISTORY_COL_MIN_WIDTHS
    k = float(available) / float(total)
    out = [max(mins[i], int(round(widths[i] * k))) for i in range(len(widths))]
    diff = available - sum(out)
    if diff > 0:
        # 取整损耗全部补到正码列（该列本就是最宽列，加几像素不影响其它列）
        out[2] += diff
    guard = 0
    while diff < 0 and guard < 200:
        idx = max(range(len(out)), key=lambda j: out[j] - mins[j])
        room = out[idx] - mins[idx]
        if room <= 0:
            break
        cut = min(room, -diff)
        out[idx] -= cut
        diff += cut
        guard += 1
    return out


def _history_col_available_width(table):
    """取表格可供九列使用的宽度（视口宽；纵向滚动条隐藏时预留其宽度）

    参数:
        table (QTableWidget): 历史记录表。
    返回:
        int: 可用宽，≤0 表示布局尚未完成。
    """
    available = int(table.viewport().width())
    vbar = table.verticalScrollBar()
    if not vbar.isVisible():
        # 纵向滚动条尚未出现时也预留其宽度，避免翻页后出现滚动条把列挤成横向滚动
        available -= max(0, int(vbar.sizeHint().width()))
    return available


def _normalize_history_col_widths(host):
    """启动校正：把九列铺满视口一次（不写盘、不计用户拖拽）

    功能:
        磁盘上的历史列宽可能是旧版压缩值（如合计 702），启动布局完成后按视口
        宽等比铺满；合计超出则等比收起。只改内存列宽，INI 原值不动。

    参数:
        host: 主窗口实例。
    返回:
        bool: True=校正已执行或列宽本已等宽（布局可用）；False=布局未完成，需重试。
    """
    table = getattr(host, 'history_table', None)
    if table is None or getattr(host, '_window_closing', False):
        return True
    current = [table.columnWidth(i) for i in range(table.columnCount())]
    if len(current) != len(HISTORY_COL_MIN_WIDTHS):
        return True
    # 页面隐藏/布局未稳定时视口宽不可信，宁可等下一轮，也不要把列宽压成最小值
    if not table.isVisible():
        return False
    available = _history_col_available_width(table)
    if available < 400:
        return False
    widths = _fill_history_col_widths(current, available)
    if widths == current:
        return True
    host._history_cols_applying = True
    table.setUpdatesEnabled(False)
    try:
        for i, w in enumerate(widths):
            table.setColumnWidth(i, w)
    finally:
        table.setUpdatesEnabled(True)
        host._history_cols_applying = False
    table.viewport().update()
    return True


def _finish_history_col_layout(host, attempts=0):
    """布局完成后收尾：做一次铺满校正，然后才把列宽变化认定为用户拖拽

    参数:
        host: 主窗口实例；
        attempts: int，已重试次数（布局未完成时最多重试 12 次，每次 50ms）。
    返回:
        None。
    """
    if getattr(host, '_window_closing', False):
        return
    if not _normalize_history_col_widths(host):
        if attempts < 40:
            QTimer.singleShot(50, lambda: _finish_history_col_layout(host, attempts + 1))
        return
    host._history_col_ready = True


def _on_history_tab_changed(host, index):
    """切到历史记录页签时重判档位并做一次铺满校正（页面隐藏期间视口宽不可信）

    参数:
        host: 主窗口实例；
        index: int，当前页签索引。
    返回:
        None。
    """
    if getattr(host, '_window_closing', False):
        return
    try:
        if host.tabs.tabText(index) != '历史记录':
            return
    except Exception:
        return
    timer = getattr(host, '_history_ball_timer', None)
    if timer is not None:
        timer.start(0)
    QTimer.singleShot(0, lambda: _finish_history_col_layout(host))


class _HistoryBallResizeFilter(QObject):
    """监听主窗口 Resize，去抖 200ms 后重判几何档（只改列宽/字号，不重建表格）"""

    def __init__(self, host):
        super().__init__(host)
        self._host = host

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.Resize and obj is self._host:
            if getattr(self._host, '_window_closing', False):
                return False
            timer = getattr(self._host, '_history_ball_timer', None)
            if timer is not None:
                timer.start(200)
        return False


def apply_history_ball_tier(host):
    """窗口尺寸稳定后重判几何档并就地调整列宽/行高，不重建表格

    规则:
        - 窗口宽 ≥1500 → 1600 档（28 球径 / 18 Bold / 52 行高），否则 1180 档（24/16/46）；
        - 当前列宽等于旧档默认值（用户未手动拖过）→ 直接换成新档默认宽；
        - 用户手动拖过列宽 → 保留基准比例，仅当合计超出视口时等比收缩，
          保证 `horizontalScrollBar().maximum()==0`；
        - 只改列宽、委托字号与行高；不动分页、选中行与表格内容，不触发重填。

    参数:
        host: 主窗口实例；读取 host.width() 与 history_table，写
            host._history_ball_large 与各列宽。

    返回:
        None。
    """
    table = getattr(host, 'history_table', None)
    if table is None or getattr(host, '_window_closing', False):
        return
    old_large = bool(getattr(host, '_history_ball_large', history_ball_is_large(host)))
    new_large = history_ball_is_large(host)
    current = [table.columnWidth(i) for i in range(table.columnCount())]
    if len(current) != len(HISTORY_COL_MIN_WIDTHS):
        return
    defaults_old = HISTORY_COL_WIDTHS_LARGE if old_large else HISTORY_COL_WIDTHS_SMALL
    defaults_new = HISTORY_COL_WIDTHS_LARGE if new_large else HISTORY_COL_WIDTHS_SMALL
    base = getattr(host, '_history_col_base_widths', None)
    user_widths = bool(current != defaults_old and base and len(base) == len(current))
    if user_widths:
        # 用户手动改过列宽：以拖拽基准按比例适配，不强行回到档位默认
        candidate = [int(w) for w in base]
    else:
        candidate = list(defaults_new)
    # 页面隐藏或布局未稳定时视口宽不可信，等 Show 事件后再判档（避免压成最小值）
    if not table.isVisible():
        return
    available = _history_col_available_width(table)
    if available < 400:
        return
    if user_widths:
        widths = _fit_history_col_widths(candidate, available)
    else:
        # 程序算出来的宽度：铺满视口，右侧不留空白（也不写盘、不算用户拖拽）
        widths = _fill_history_col_widths(candidate, available)
    if widths == current and new_large == old_large:
        return
    delegate = table.itemDelegate()
    host._history_cols_applying = True
    table.setUpdatesEnabled(False)
    try:
        for i, w in enumerate(widths):
            table.setColumnWidth(i, w)
        if new_large != old_large:
            host._history_ball_large = new_large
            # 委托按 large 取球径/字号，切档后下一帧即生效，无需重设委托
            if isinstance(delegate, HistoryBallDelegate):
                delegate.large = new_large
            row_h = HISTORY_BALL_SPECS[new_large]['row']
            table.verticalHeader().setDefaultSectionSize(row_h)
            for r in range(table.rowCount()):
                table.setRowHeight(r, row_h)
    finally:
        table.setUpdatesEnabled(True)
        host._history_cols_applying = False
    if new_large != old_large:
        table.viewport().update()


def install_history_ball_autosize(host):
    """安装运行时自适应：主窗口 Resize 去抖 200ms → apply_history_ball_tier

    参数:
        host: 主窗口实例；在 host 上挂 host._history_ball_timer、
            host._history_ball_resize_filter 与列宽跟踪状态。

    返回:
        None。
    """
    if getattr(host, 'history_table', None) is None or hasattr(host, '_history_ball_timer'):
        return
    host._history_col_user_touched = False
    host._history_col_base_widths = None
    host._history_cols_applying = False
    # 布局稳定前不把列宽变化记为用户拖拽（restore/migration/校正都会触发 sectionResized）
    host._history_col_ready = False
    timer = QTimer(host)
    timer.setSingleShot(True)
    timer.timeout.connect(lambda: apply_history_ball_tier(host))
    host._history_ball_timer = timer
    host._history_ball_resize_filter = _HistoryBallResizeFilter(host)
    host.installEventFilter(host._history_ball_resize_filter)
    # 页面切到历史记录（表首次可见）时重判档位并做铺满校正；
    # 校正成功后 _history_col_ready 才置 True，之后才把 sectionResized 记为用户拖拽
    tabs = getattr(host, 'tabs', None)
    if tabs is not None:
        try:
            tabs.currentChanged.connect(lambda idx: _on_history_tab_changed(host, idx))
        except Exception:
            pass
    # 左右分隔条拖动后视口宽变化：去抖 200ms 重新铺满/收起，保证两端都不出横向滚动条
    splitter = getattr(host, 'history_h_splitter', None)
    if splitter is not None:
        splitter.splitterMoved.connect(lambda pos, idx: timer.start(200))
    QTimer.singleShot(0, lambda: _finish_history_col_layout(host))


def _font_pixel_size(font, default=15):
    """把 QFont 换算为实际像素字号（A+ 用 setPointSize 时会返回 -1）

    参数:
        font (QFont): 待换算字体；
        default (int): 既无像素字号也无点字号时的兜底值。
    返回:
        int: 像素字号。
    """
    px = font.pixelSize()
    if px > 0:
        return px
    pt = font.pointSizeF()
    if pt > 0:
        # Qt 逻辑 DPI 默认 96：1pt = 96/72 px
        return int(round(pt * 96.0 / 72.0))
    return default


def _wave_tokens(number):
    """返回号码所属波色的令牌键（red/blue/green），其余归绿波"""
    if number in LotteryConfig.RED_NUMBERS:
        return 'red'
    if number in LotteryConfig.BLUE_NUMBERS:
        return 'blue'
    return 'green'


class HistoryBallDelegate(QStyledItemDelegate):
    """本地历史表整表委托：背景/网格/文字/号码球全部自绘，不创建任何 QWidget

    职责:
        - 第 2 列（正码 6 个）与第 3 列（特别码 1 个）：画圆球 + 号码 + 球下生肖/五行；
        - 其余七列：画主题背景、网格线、主题文字（过长自动省略号）；
        - 选中行只换背景，号码/球下文字颜色不变；末尾保留键盘焦点框。

    数据约定:
        第 2/3 列的 UserRole 存 list[tuple]：
        [(号码|None, 生肖|'', 五行|'', 状态)]，状态 ∈ {'snap','live','missing'}。
        由 update_history_table 预计算，paint() 内只读缓存，复杂度只与可见行数相关。

    性能:
        0 个 QWidget、0 个样式表解析；100 行只写 item 数据，painter 立即模式绘制。
    """

    def __init__(self, parent, large=False):
        super().__init__(parent)
        self.large = bool(large)
        # 球内号码/球下文字字体按档位缓存，避免每个单元格都新建 QFont/QFontMetrics
        self._ball_fonts_key = None
        self._ball_fonts_value = None
        # 其余七列文字字体按“像素字号”缓存，A+ 放大时换键即可，不累积
        self._text_fonts = {}

    def _dark(self, option):
        """从视图所在窗口读取当前主题（不在委托里持有 host 引用）"""
        widget = option.widget
        if widget is None:
            return False
        try:
            return bool(getattr(widget.window(), 'is_dark_mode', False))
        except Exception:
            return False

    def paint(self, painter, option, index):
        """绘制单个单元格（背景 → 网格 → 文字/号码球 → 焦点框）"""
        tokens = HISTORY_BALL_TOKENS[self._dark(option)]
        rect = option.rect
        selected = bool(option.state & QStyle.StateFlag.State_Selected)

        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        # 1) 背景：选中优先，未选中按奇偶斑马底
        if selected:
            bg = tokens['sel']
        else:
            bg = tokens['row1'] if index.row() % 2 == 1 else tokens['row0']
        painter.fillRect(rect, QColor(bg))

        # 2) 网格：只画右/下边框，避免与视图默认网格叠加
        painter.setPen(QPen(QColor(tokens['grid']), 1))
        painter.drawLine(rect.right(), rect.top(), rect.right(), rect.bottom())
        painter.drawLine(rect.left(), rect.bottom(), rect.right(), rect.bottom())

        # 3) 内容：号码列自绘球，其余列画文字。整行数据只存在第 0 列 item 的
        #    UserRole 里（{'text': [...9], 'balls': (正码, 特别码)}），其余列为空 item，
        #    委托通过 sibling 读取同一份数据，避免为 8 个空列各建一个 QTableWidgetItem
        col = index.column()
        row_payload = index.sibling(index.row(), 0).data(Qt.ItemDataRole.UserRole)
        if col in (2, 3):
            if isinstance(row_payload, dict):
                balls = row_payload.get('balls') or ([], [])
                payload = balls[0] if col == 2 else balls[1]
            else:
                payload = index.data(Qt.ItemDataRole.UserRole)
            self._paint_balls(painter, rect, payload, col == 3, tokens)
        else:
            if isinstance(row_payload, dict):
                texts = row_payload.get('text') or []
                text = str(texts[col]) if 0 <= col < len(texts) and texts[col] is not None else ''
            else:
                raw = index.data(Qt.ItemDataRole.DisplayRole)
                text = '' if raw is None else str(raw)
            font = QFont(option.font)
            # 固定行高 46/52 与列宽预算下，正文最多 17px；下限 15px（A+ 放大时省略号）
            px = max(15, min(17, _font_pixel_size(font)))
            cached = self._text_fonts.get(px)
            if cached is None:
                font.setPixelSize(px)
                if len(self._text_fonts) >= 6:
                    self._text_fonts.clear()
                cached = (font, QFontMetrics(font))
                self._text_fonts[px] = cached
            font, metrics = cached
            painter.setFont(font)
            painter.setPen(QColor(tokens['text']))
            avail = max(1, rect.width() - 8)
            elided = metrics.elidedText(text, Qt.TextElideMode.ElideRight, avail)
            painter.drawText(rect.adjusted(4, 0, -4, 0), int(Qt.AlignmentFlag.AlignCenter), elided)

        # 4) 焦点框：保留键盘可达性
        if option.state & QStyle.StateFlag.State_HasFocus and option.widget is not None:
            focus = QStyleOptionFocusRect()
            focus.rect = rect
            focus.state = option.state
            option.widget.style().drawPrimitive(
                QStyle.PrimitiveElement.PE_FrameFocusRect, focus, painter, option.widget)

        painter.restore()

    def _ball_fonts(self):
        """按当前档位返回 (球下字体, 球下度量, 号码字体, 号码度量)，切档后自动重建"""
        if self._ball_fonts_key != self.large:
            spec = HISTORY_BALL_SPECS[self.large]
            sub_font = QFont()
            sub_font.setPixelSize(spec['sub_px'])
            num_font = QFont()
            num_font.setPixelSize(spec['num_px'])
            num_font.setBold(True)
            self._ball_fonts_value = (sub_font, QFontMetrics(sub_font),
                                      num_font, QFontMetrics(num_font))
            self._ball_fonts_key = self.large
        return self._ball_fonts_value

    def _paint_balls(self, painter, rect, payload, is_special, tokens):
        """在单元格内绘制 1~6 个号码球与球下文字

        参数:
            painter (QPainter): 已保存状态的绘图器；
            rect (QRect): 单元格矩形；
            payload (list|None): UserRole 中的 [(号码, 生肖, 五行, 状态)]；
            is_special (bool): True=特别码（反色实心 + 双描边）；
            tokens (dict): 当前主题令牌。
        """
        spec = HISTORY_BALL_SPECS[self.large]
        ball, slot, gap = spec['ball'], spec['slot'], spec['gap']
        sub_font, sub_metrics, num_font, num_metrics = self._ball_fonts()
        # 球下文字按字体行高留位（15px 字行高 19px），矩形高度必须等于行高，
        # 否则 AlignVCenter 会把字的下半截裁掉
        sub_h = max(1, int(sub_metrics.height()))

        if not payload:
            # 空号码：不画球，居中画灰色破折号（与旧实现 '?' 兜底语义一致）
            painter.setFont(sub_font)
            painter.setPen(QColor(tokens['missing']))
            painter.drawText(rect, int(Qt.AlignmentFlag.AlignCenter), '—')
            return

        balls = list(payload)
        block = len(balls) * slot + (len(balls) - 1) * gap
        left = rect.x() + (rect.width() - block) // 2
        # 行内垂直：球 + 字体行高（46 档 24+20=44，52 档 28+20=48），整体居中留 1~2px 边距；
        # 字体行高自带上下留白，球与文字不必再加间距，否则会顶满行高
        sub_gap = 0
        content_h = ball + sub_gap + sub_h
        top = rect.y() + (rect.height() - content_h) // 2
        sub_top = top + ball + sub_gap

        for i, item in enumerate(balls):
            if not item:
                continue
            number, zodiac, element, state = item
            center_x = left + i * (slot + gap) + slot // 2
            state_color = tokens.get(state, tokens['missing'])

            if number is None:
                painter.setFont(sub_font)
                painter.setPen(QColor(tokens['missing']))
                painter.drawText(QRect(center_x - slot // 2, top, slot, ball),
                                 int(Qt.AlignmentFlag.AlignCenter), '—')
            else:
                wave = _wave_tokens(number)
                num_text, border = tokens[wave][0], tokens[wave][1]
                # 24/28 为含描边的外径：内缩 1px 画 2px 描边，笔宽居中后正好回到外径
                inner = QRect(center_x - (ball - 2) // 2, top + 1, ball - 2, ball - 2)

                if is_special:
                    # 外侧 1px 副描边 + 反色实心 + 2px 波色主描边（灰度/色盲也能区分）
                    painter.setBrush(Qt.BrushStyle.NoBrush)
                    painter.setPen(QPen(QColor(border), 1))
                    painter.drawEllipse(inner.adjusted(-2, -2, 2, 2))
                    fill = tokens['special_bg']
                    num_color = tokens['special_text']
                else:
                    fill = tokens['ball_bg']
                    num_color = num_text

                painter.setPen(QPen(QColor(border), 2))
                painter.setBrush(QColor(fill))
                painter.drawEllipse(inner)

                # 号码按墨迹居中（不用 AlignCenter 的字身框居中，避免视觉偏上）
                painter.setFont(num_font)
                painter.setPen(QColor(num_color))
                text = str(number).zfill(2)
                ink = num_metrics.boundingRect(text)
                ink_x = center_x - ink.width() / 2.0 - ink.x()
                ink_y = top + ball / 2.0 - ink.height() / 2.0 - ink.y()
                painter.drawText(QPoint(int(round(ink_x)), int(round(ink_y))), text)

            # 球下文字：生肖/五行，三态只改文字颜色，不改整格背景
            sub_text = (zodiac or '—') + '/' + (element or '—')
            painter.setFont(sub_font)
            painter.setPen(QColor(state_color))
            painter.drawText(QRect(center_x - slot // 2, sub_top, slot, sub_h),
                             int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter),
                             sub_text)


def _history_ball_payload(record, binding, elements):
    """把一条开奖记录预计算成 正码/特别码 两组委托绘制数据

    参数:
        record (dict): 历史记录（含 numbers / special / 可选生肖快照）；
        binding (dict): 当前生肖绑定，仅在缺快照时用于实时推算；
        elements (dict): 号码→五行 固定表。
    返回:
        tuple[list, list]: (正码 payload, 特别码 payload)。
        每项为 (号码|None, 生肖|'', 五行|'', 状态)；状态 snap=快照、live=实时推算、
        missing=缺值。
    """
    raw_numbers = record.get('numbers', []) or []
    numbers = []
    for n in raw_numbers:
        try:
            numbers.append(int(n))
        except (TypeError, ValueError):
            numbers.append(None)

    zodiacs, special_zodiac, from_snapshot = LotteryConfig.resolve_record_zodiacs(record, binding)
    zodiacs = list(zodiacs or [])

    def make_item(index, number):
        """构造历史详情中单个号码的展示元组（号码、生肖、五行、来源状态）。

        参数: index (int): 号码在当期列表中的序号，用于取生肖快照；
              number (int|None): 号码值，None 表示解析失败的占位。
        返回: tuple(int|None, str, str, str): (号码, 生肖, 五行, state)，
              state 为 'missing'（缺生肖/五行）、'snap'（历史快照）、'live'（当前绑定）。
        副作用: 无；纯读取闭包中的 zodiacs/elements/from_snapshot。
        """
        zodiac = zodiacs[index] if index < len(zodiacs) else ''
        element = elements.get(number, '') if number is not None else ''
        if not zodiac or not element:
            state = 'missing'
        else:
            state = 'snap' if from_snapshot else 'live'
        return (number, zodiac or '', element or '', state)

    numbers_payload = [make_item(i, n) for i, n in enumerate(numbers)]

    special = record.get('special')
    try:
        special = int(special)
    except (TypeError, ValueError):
        special = None
    if special is None:
        special_payload = []
    else:
        element = elements.get(special, '')
        if not special_zodiac or not element:
            state = 'missing'
        else:
            state = 'snap' if from_snapshot else 'live'
        special_payload = [(special, special_zodiac or '', element or '', state)]

    return numbers_payload, special_payload


def _history_sort_date(date_text):
    """把日期文本归一成 YYYY-MM-DD 供展示排序；无法识别时返回空串（排在最后）"""
    text = str(date_text or '')
    match = re.search(r'(\d{4})\s*[-/.年]\s*(\d{1,2})\s*[-/.月]\s*(\d{1,2})', text)
    if match:
        return '%04d-%02d-%02d' % (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    match = re.search(r'(?<!\d)(\d{2})\s*[-/.]\s*(\d{1,2})\s*[-/.]\s*(\d{1,2})(?!\d)', text)
    if match:
        return '%04d-%02d-%02d' % (2000 + int(match.group(1)), int(match.group(2)),
                                  int(match.group(3)))
    return ''


def update_history_table(host):
    """按分页切片渲染历史记录表格，并同步刷新分页、统计与概率面板

    功能:
        本函数是「历史记录」页的核心渲染入口（与迁移前主窗口实现逐行等价）。
        每次调用都会：
        1) 按 host.history_page / host.history_page_size 计算当前页切片
           [start_idx, end_idx)，并把页码向下钳制到总页数；
        2) 重填 host.history_table 的九列内容（期号/日期/正码/特别码/和值/
           单双比/大小比/颜色分布/跨度），行数只等于当前页条数；
        3) 刷新分页标签与页码框、状态栏条数、页面条数、统计摘要；
        4) 同时刷新历史页与预测页的「最新开奖数据」，并刷新概率面板。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。读取
            host.historical_data（list[dict]，约定“最新在前”，字段
            period/date/numbers/special）、host.history_page、
            host.history_page_size、host.is_dark_mode、
            host._area_font_scales；写入 host.history_page（仅钳制）。

    返回:
        None。

    副作用:
        - 写 host.history_page（只在超过总页数时下调，不会把合法页码改大）；
        - 重设 host.history_table 的行数并重填单元格（列数、列宽、隐藏列
          一律不动；选中行与滚动位置沿用 Qt 在重填时的默认行为，与旧实现一致）；
        - 更新 host.data_count_label / history_count_label / 分页控件 /
          history_stats_label / history_latest_display / latest_display /
          probability_list（后两者分别经 refresh_latest_display 与
          prediction.update_probability_panel 完成）。

    异常与降级:
        - 本函数不主动抛出异常：首屏时序（install 之前、控件尚未构建）或跨页
          早期调用时，缺失的属性/控件一律按“跳过”处理；
        - history_table 不存在时仍会刷新分页、条数、最新期、统计与概率面板，
          保证状态栏与其它页面不会停留在旧值；
        - 若控件对象已存在但底层 C++ 对象已销毁（如窗口关闭过程中），Qt 调用
          产生的 RuntimeError 会照常向上传播，不静默吞掉（与旧实现一致）。

    说明:
        `history_stats_label` 的口径是“当前历史数据全集”（本函数不做额外筛选），
        热门/冷门按出现次数统计；特别码不参与正码统计，与旧实现一致。
    """
    # 历史数据源：存储顺序不变；展示副本按「日期降序 → 期号降序」排序
    data_to_show = list(getattr(host, 'historical_data', None) or [])
    # 排序只作用于渲染副本：写回 JSON / 预测取数仍使用 historical_data 原始顺序
    data_to_show.sort(key=lambda record: (
        _history_sort_date(record.get('date')), record.get('period') or 0), reverse=True)
    total_count = len(data_to_show)

    # 每页条数：默认 100（与主窗口 __init__ 一致）；0/None/负数作为损坏配置
    # 回退到 100，避免下面的向上取整除法出现除零
    page_size = getattr(host, 'history_page_size', 100) or 100
    if page_size < 1:
        page_size = 100

    # 分页计算：总页数=ceil(总条数/每页条数)，且至少 1 页（空数据也显示“第 1 页”）
    total_pages = max(1, (total_count + page_size - 1) // page_size)
    history_page = getattr(host, 'history_page', 1) or 1
    # 当前页只向下钳制：数据变少时回到末页，数据变多时不会自动跳页
    history_page = min(history_page, total_pages)
    host.history_page = history_page

    # 当前页在 historical_data 中的半开区间 [start_idx, end_idx)
    # 例：第 2 页、每页 100 条 → start=100；最后一页 end 截断到 total_count
    start_idx = (history_page - 1) * page_size
    end_idx = min(start_idx + page_size, total_count)

    # 先刷新分页控件（内部自带“控件未构建则跳过”的兼容判断）
    update_pagination(host, total_count)

    # 表格可能在首屏尚未构建：缺失时跳过重填，但后续状态栏/最新期仍要刷新
    history_table = getattr(host, 'history_table', None)
    if history_table is not None:
        # 当前几何档：1600 档行高 52，1180 档行高 46（不随 A+ 缩放）
        large = getattr(host, '_history_ball_large', None)
        if large is None:
            large = history_ball_is_large(host)
        spec = HISTORY_BALL_SPECS[bool(large)]
        row_height = spec['row']
        # 生肖/五行取数：沿用现有快照解析 + 号码→五行固定表
        binding = getattr(host, 'zodiac_binding', None) or {}
        elements = getattr(LotteryConfig, 'NUMBER_ELEMENTS', {}) or {}

        # 表格只渲染当前页，行号是页内相对索引（绝对索引=相对索引+start_idx）
        if history_table.rowCount() != end_idx - start_idx:
            history_table.setRowCount(end_idx - start_idx)
        # 批量填充期间关闭重绘，避免逐格触发 paint（100 行构建耗时的关键）
        history_table.setUpdatesEnabled(False)
        try:
            for i, record in enumerate(data_to_show[start_idx:end_idx]):
                table_row = i
                numbers = record.get('numbers', []) or []

                # 正码/特别码：预计算 [(号码, 生肖, 五行, 状态)]，委托立即模式绘制
                nums_payload, spec_payload = _history_ball_payload(record, binding, elements)

                # 和值：6 个正码求和；无正码时记 0
                sum_val = sum(numbers) if numbers else 0
                # 单双比：奇数个数:偶数个数（如 3:3）
                odd_count = sum(1 for n in numbers if n % 2 == 1) if numbers else 0
                even_count = len(numbers) - odd_count
                # 大小比：大于 24 记“大”，其余记“小”（六合彩 1~49 的常用分界）
                big_count = sum(1 for n in numbers if n > 24) if numbers else 0
                small_count = len(numbers) - big_count
                # 颜色分布：红蓝绿波数量；未命中红/蓝的一律计入绿
                red_count = sum(1 for n in numbers if n in LotteryConfig.RED_NUMBERS) if numbers else 0
                blue_count = sum(1 for n in numbers if n in LotteryConfig.BLUE_NUMBERS) if numbers else 0
                green_count = len(numbers) - red_count - blue_count
                # 跨度：最大正码 - 最小正码；无正码时记 0
                span_val = (max(numbers) - min(numbers)) if numbers else 0

                # 每行只建 1 个 item（第 0 列），其余 8 列由委托读取同一份行数据：
                # 900 个 QTableWidgetItem 降到 100 个，setItem 调用下降 89%
                row_payload = {
                    'text': [
                        str(record.get('period', '?')), record.get('date', '?'), '',
                        '', str(sum_val), str(odd_count) + ':' + str(even_count),
                        str(big_count) + ':' + str(small_count),
                        '红' + str(red_count) + '蓝' + str(blue_count) + '绿' + str(green_count),
                        str(span_val),
                    ],
                    'balls': (nums_payload, spec_payload),
                }
                item_row = QTableWidgetItem('')
                item_row.setData(Qt.ItemDataRole.UserRole, row_payload)
                history_table.setItem(table_row, 0, item_row)

                # 行高按档位固定：46 / 52（不随 A+ 缩放，保证一屏行数稳定）
                history_table.setRowHeight(table_row, row_height)
        finally:
            history_table.setUpdatesEnabled(True)

    # 状态栏“历史记录: N 条”（控件可能尚未创建，缺失则跳过）
    data_count_label = getattr(host, 'data_count_label', None)
    if data_count_label is not None:
        data_count_label.setText("历史记录: " + str(total_count) + " 条")

    # 页面标题旁的“显示第 a-b 条 / 共 N 条”；空数据时保持旧实现的 1-0 文案
    history_count_label = getattr(host, 'history_count_label', None)
    if history_count_label is not None:
        history_count_label.setText(
            "显示第 " + str(start_idx + 1) + "-" + str(end_idx) + " 条 / 共 " + str(total_count) + " 条")

    # 最新一期由 refresh_latest_display 统一刷新（同时覆盖历史页与预测页），
    # 避免此处用当前页 data_to_show[0] 再次覆盖，导致显示的不是真正最新一期
    refresh_latest_display(host)

    # 统计摘要：基于历史数据全集（热门/冷门取出现次数前 5 / 后 5）
    history_stats_label = getattr(host, 'history_stats_label', None)
    if history_stats_label is not None and data_to_show:
        from collections import Counter  # 作用说明：用计数器一次统计全量号码出现次数，供热门/冷门前 5 展示
        all_nums = []
        for r in data_to_show:
            all_nums.extend(r.get('numbers', []))
        counter = Counter(all_nums)
        hot = counter.most_common(5)  # 出现次数最多的 5 个号码
        hot_str = '  '.join(str(n).zfill(2) + '(' + str(c) + ')' for n, c in hot)
        cold = counter.most_common()[-5:]  # 升序排最后 5 个 = 出现次数最少的号码
        cold_str = '  '.join(str(n).zfill(2) + '(' + str(c) + ')' for n, c in cold)

        sums = [sum(r.get('numbers', [])) for r in data_to_show]
        dates = [r.get('date', '') for r in data_to_show if r.get('date')]

        stats_text = '总期数: ' + str(len(data_to_show)) + ' 期\n'
        if dates:
            # 日期按列表顺序展示：dates[-1] 最早、dates[0] 最新（约定最新在前）
            stats_text += '日期范围: ' + dates[-1] + ' ~ ' + dates[0] + '\n'
        if sums:
            stats_text += '和值范围: ' + str(min(sums)) + ' ~ ' + str(max(sums)) + '\n'
            stats_text += '和值均值: ' + str(int(sum(sums) / len(sums))) + '\n'
        stats_text += '热门号码: ' + hot_str + '\n'
        stats_text += '冷门号码: ' + cold_str
        history_stats_label.setText(stats_text)

    # 概率面板：仅当预测页已构建 probability_list 时刷新；
    # 函数级导入避免 TAB 包初始化期的循环依赖（history 与 prediction 同属 TAB）
    if hasattr(host, 'probability_list'):
        from TAB import prediction as _tab_prediction_module  # 作用说明：延迟导入预测页模块以调用概率面板刷新，避免 TAB 包初始化期循环依赖
        _tab_prediction_module.update_probability_panel(host)


def on_show_period_detail(host):
    """生成并显示选中期的完整详情富文本（号码球 + 属性表）

    功能:
        把当前页选中行换算为绝对索引，读取对应记录后拼出 HTML：
        期号/日期标题、正码与特别码的彩色号码球、和值/跨度/单双比/大小比/
        颜色分布/号码详情（生肖五行）/区间分布/尾数分布/连号。
        结果暂存到 host._original_detail_html，再由 _apply_detail_font_scale
        统一按用户字号缩放。

    参数:
        host: 主窗口实例。读取 host.history_page、host.history_page_size、
            host.history_table、host.historical_data、host._area_font_scales。

    返回:
        None。

    副作用:
        - 写 host._current_detail_row（绝对索引）与 host._original_detail_html；
        - 通过 host._apply_detail_font_scale() 改写 period_detail_edit；
        - 未选中记录时在详情框内显示红色提示文字。

    异常:
        未捕获异常；调用方需保证 history_table 已构建且数据字段完整
        （numbers 为空、缺失 date/period 时均已有默认值兜底）。

    说明（号码球尺寸与配色的依据）:
        基准字号/内边距/圆角均以 base_* 常量为 1.0 缩放时的像素值，
        再乘以 _area_font_scales['detail']（菜单中的详情字号比例）：
        正码球底色取 LotteryConfig.get_number_color(n)['border']，
        文字固定白色以保证对比度；号码详情文字色取同函数的 ['text']。
        特别码的红/蓝/绿归属由 RED_NUMBERS / BLUE_NUMBERS 集合判定，
        未命中视为绿，与主窗口表格的着色规则一致。
    """
    if not hasattr(host, 'period_detail_edit'):
        return
    # 【修复分页索引bug】表格行号是页内相对索引，需加上分页偏移量转为绝对索引
    page_offset = (host.history_page - 1) * host.history_page_size
    row = host.history_table.currentRow() + page_offset
    if row < 0 or row >= len(host.historical_data):
        host.period_detail_edit.setHtml('<p style="color:#E74C3C;">请先在表格中选择一期记录</p>')
        return

    host._current_detail_row = row
    record = host.historical_data[row]
    numbers = record.get('numbers', [])
    special = record.get('special', 0)
    period = record.get('period', '?')
    date = record.get('date', '?')

    # 生肖来源：优先读记录里固化的历史快照；旧数据无快照时才回退当前绑定实时推算。
    # 第三项 zodiac_from_snapshot 用于界面如实标注来源，避免把“实时推算”伪装成历史快照。
    snapshot_zodiacs, snapshot_special, zodiac_from_snapshot = LotteryConfig.resolve_record_zodiacs(
        record, LotteryConfig.NUMBER_NAMES
    )

    # 获取详情区域字体缩放
    detail_scale = host._area_font_scales.get('detail', 1.0)

    # 基础尺寸（原始尺寸，detail 缩放为 1.0 时的像素值；标题 30/小标题 22/
    # 球面 30/表格 18/彩色数字 20/号码详情 17，按信息层级递减排布）
    base_title_size = 30
    base_section_size = 22
    base_ball_size = 30
    base_table_size = 18
    base_small_size = 20
    base_tiny_size = 17

    # 缩放后的尺寸（统一 int 截断，保证 HTML 只出现整数 px）
    # v0.0.42：详情缩放范围 0.5~2.0，统一钳制到 15px 下限（如 tiny 17*0.5=8）
    title_size = max(15, int(base_title_size * detail_scale))
    section_size = max(15, int(base_section_size * detail_scale))
    ball_size = max(15, int(base_ball_size * detail_scale))
    table_size = max(15, int(base_table_size * detail_scale))
    small_size = max(15, int(base_small_size * detail_scale))
    tiny_size = max(15, int(base_tiny_size * detail_scale))

    # 球的 padding 和 margin 也按同一比例缩放，避免字号变大后球体被压扁
    # （左右 18/上下 10 使两位数字形成横向胶囊形，圆角 12 保证足够圆润）
    ball_padding_h = int(18 * detail_scale)
    ball_padding_v = int(10 * detail_scale)
    ball_margin = int(5 * detail_scale)
    ball_radius = int(12 * detail_scale)

    # 构建HTML完整显示 - 减小行高和间隔
    html = f'<div style="font-size:{table_size}px; line-height:1.6;">'
    html += f'<p style="font-size:{title_size}px; font-weight:bold; color:#3498DB; margin:2px 0;">第{str(period)}期  {str(date)}</p>'

    # 正码大按钮显示
    html += f'<p style="font-size:{section_size}px; margin:8px 0 2px 0;"><b>正码：</b></p>'
    html += f'<p style="margin-left:10px; margin-top:0;">'
    for n in numbers:
        colors = LotteryConfig.get_number_color(n)
        html += f'<span style="display:inline-block; background-color:{colors["border"]}; color:#FFFFFF; font-size:{ball_size}px; font-weight:bold; border-radius:{ball_radius}px; padding:{ball_padding_v}px {ball_padding_h}px; margin:{ball_margin}px;">{str(n).zfill(2)}</span> '
    html += '</p>'

    # 特别码
    html += f'<p style="margin:4px 0;"><b>特别码：</b>'
    sp_colors = LotteryConfig.get_number_color(special)
    sp_name = snapshot_special
    sp_elem = LotteryConfig.NUMBER_ELEMENTS.get(special, '')
    sp_color_name = ''
    if special in LotteryConfig.RED_NUMBERS:
        sp_color_name = '红'
    elif special in LotteryConfig.BLUE_NUMBERS:
        sp_color_name = '蓝'
    else:
        sp_color_name = '绿'
    html += f'<span style="display:inline-block; background-color:{sp_colors["border"]}; color:#FFFFFF; font-size:{ball_size}px; font-weight:bold; border-radius:{ball_radius}px; padding:{ball_padding_v}px {ball_padding_h}px; margin:{ball_margin}px;">{str(special).zfill(2)}</span>'
    html += '</p>'

    # 详细属性表
    html += f'<table style="border-collapse:collapse; width:100%; margin-top:8px; font-size:{table_size}px;">'

    # 和值
    sum_val = sum(numbers)
    html += f'<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold; width:90px;">和值</td><td style="padding:6px 10px; border:1px solid #DDD; font-size:{section_size}px; font-weight:bold;">{str(sum_val)}</td></tr>'

    # 跨度
    span_val = max(numbers) - min(numbers) if numbers else 0
    html += f'<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold;">跨度</td><td style="padding:6px 10px; border:1px solid #DDD; font-size:{section_size}px; font-weight:bold;">{str(span_val)}</td></tr>'

    # 单双比
    odd_count = sum(1 for n in numbers if n % 2 == 1)
    even_count = len(numbers) - odd_count
    html += f'<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold;">单双比</td><td style="padding:6px 10px; border:1px solid #DDD;">单{str(odd_count)}:双{str(even_count)}</td></tr>'

    # 大小比
    big_count = sum(1 for n in numbers if n > 24)
    small_count = len(numbers) - big_count
    html += f'<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold;">大小比</td><td style="padding:6px 10px; border:1px solid #DDD;">大{str(big_count)}:小{str(small_count)}</td></tr>'

    # 颜色分布
    red_c = sum(1 for n in numbers if n in LotteryConfig.RED_NUMBERS)
    blue_c = sum(1 for n in numbers if n in LotteryConfig.BLUE_NUMBERS)
    green_c = len(numbers) - red_c - blue_c
    html += f'<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold;">颜色分布</td><td style="padding:6px 10px; border:1px solid #DDD;"><span style="color:#FF0000; font-size:{small_size}px;">红{str(red_c)}</span> <span style="color:#0000FF; font-size:{small_size}px;">蓝{str(blue_c)}</span> <span style="color:#008000; font-size:{small_size}px;">绿{str(green_c)}</span></td></tr>'

    # 每个号码详细属性
    html += '<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold;">号码详情</td><td style="padding:6px 10px; border:1px solid #DDD;">'
    for idx, n in enumerate(numbers):
        # 生肖优先取快照（旧数据无快照时 resolve_record_zodiacs 已回退为当前绑定推算）
        cn = snapshot_zodiacs[idx] if idx < len(snapshot_zodiacs) else ''
        el = LotteryConfig.NUMBER_ELEMENTS.get(n, '')
        c = LotteryConfig.get_number_color(n)
        cn2 = ''
        if n in LotteryConfig.RED_NUMBERS:
            cn2 = '红'
        elif n in LotteryConfig.BLUE_NUMBERS:
            cn2 = '蓝'
        else:
            cn2 = '绿'
        html += f'<span style="color:{c["text"]}; font-size:{small_size}px; font-weight:bold;">{str(n).zfill(2)}</span><span style="font-size:{tiny_size}px;">({cn2}/{cn}/{el})</span> '
    # 特别码详情
    sp_c = LotteryConfig.get_number_color(special)
    html += f'<br>特别码: <span style="color:{sp_c["text"]}; font-size:{small_size}px; font-weight:bold;">{str(special).zfill(2)}</span><span style="font-size:{tiny_size}px;">({sp_color_name}/{sp_name}/{sp_elem})</span>'
    html += '</td></tr>'

    # 生肖数据来源（如实标注，避免把实时推算伪装成历史快照）
    if zodiac_from_snapshot:
        source_color = '#2E7D32'
        source_text = '历史快照（写入时固化，后续改绑不会改变本期生肖）'
    else:
        source_color = '#E67E22'
        source_text = '当前生肖绑定实时推算（该期无历史快照，改绑后会随绑定变化）'
    html += f'<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold;">生肖来源</td><td style="padding:6px 10px; border:1px solid #DDD; color:{source_color}; font-size:{table_size}px;">{source_text}</td></tr>'

    # 区间分布
    zones = {'01-10': 0, '11-20': 0, '21-30': 0, '31-40': 0, '41-49': 0}
    for n in numbers:
        if n <= 10: zones['01-10'] += 1
        elif n <= 20: zones['11-20'] += 1
        elif n <= 30: zones['21-30'] += 1
        elif n <= 40: zones['31-40'] += 1
        else: zones['41-49'] += 1
    zone_str = '  '.join(k + ':' + str(v) for k, v in zones.items())
    html += f'<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold;">区间分布</td><td style="padding:6px 10px; border:1px solid #DDD; font-size:{table_size}px;">{zone_str}</td></tr>'

    # 尾数分布
    tails = [n % 10 for n in numbers]
    tail_counter = {}
    for t in tails:
        tail_counter[t] = tail_counter.get(t, 0) + 1
    tail_str = '  '.join('尾' + str(k) + ':' + str(v) for k, v in sorted(tail_counter.items()))
    # 字号跟随详情缩放（v0.0.42 修复写死 18px 导致缩放不生效）
    html += f'<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold;">尾数分布</td><td style="padding:6px 10px; border:1px solid #DDD; font-size:{table_size}px;">{tail_str}</td></tr>'

    # 连号
    sorted_nums = sorted(numbers)
    # 【修复空数组bug】numbers为空时sorted_nums[0]会IndexError
    consec = []
    if sorted_nums:
        temp = [sorted_nums[0]]
        for j in range(1, len(sorted_nums)):
            if sorted_nums[j] == sorted_nums[j-1] + 1:
                temp.append(sorted_nums[j])
            else:
                if len(temp) >= 2:
                    consec.append(temp[:])
                temp = [sorted_nums[j]]
        if len(temp) >= 2:
            consec.append(temp[:])
    consec_str = '  '.join('-'.join(str(x).zfill(2) for x in c) for c in consec) if consec else '无'
    # 字号跟随详情缩放（v0.0.42 修复写死 18px 导致缩放不生效）
    html += f'<tr><td style="padding:6px 10px; border:1px solid #DDD; font-weight:bold;">连号</td><td style="padding:6px 10px; border:1px solid #DDD; font-size:{table_size}px;">{consec_str}</td></tr>'

    html += '</table>'
    html += '</div>'

    host._original_detail_html = html
    host._apply_detail_font_scale()


def on_batch_add(host):
    """弹出多行输入框，批量追加开奖记录并保存

    功能:
        逐行解析用户输入（跳过空行、# 注释与“期号”表头），按优先级尝试：
        1) DataUtils.parse_txt_line：空格分隔的 TXT 导出格式（严格 9 段）；
        2) DataUtils.parse_raw_data：原始格式“第X期... 年/月/日 号码 生肖/五行”；
        3) 逗号分隔的 CSV 导出格式（至少 9 段）。
        先走严格 9 段解析可与数据导入、顶栏“添加数据”保持同一口径。
        解析成功的记录追加到 host.historical_data，最后统一保存与重绘。

    参数:
        host: 主窗口实例，读写 host.historical_data；
            调用 host._save_data()、update_history_table(host)。

    返回:
        None。

    副作用:
        - 追加数据到 host.historical_data（不排序、不查重）；
        - 有成功记录时保存 JSON、刷新表格，并把
          _data_fingerprint_at_last_predict / _data_fingerprint_at_last_ml_predict
          置 None，使下次预测重新计算数据指纹（避免用旧指纹命中缓存）；
        - 弹窗汇总成功/失败条数；全部失败时弹警告。

    异常:
        外层 try 捕获所有异常并弹窗提示文本；单行解析失败仅计入 fail_count。
    """
    text, ok = QInputDialog.getMultiLineText(host, "批量添加",
        "请输入多条开奖数据，每行一条\n"
        "空格格式：117 2026-04-27 05 12 23 34 45 06 08（9 段：期号+日期+6 正码+特别码）\n"
        "逗号格式：117,2026-04-27,05,12,23,34,45,06,08（同样 9 段）\n"
        "原始格式：第117期最新开奖结果 2026年04月27日 05 龙/水 12 鸡/木 ...")
    if not ok or not text.strip():
        return

    try:
        lines = text.strip().split('\n')
        count = 0
        fail_count = 0
        snapshot_binding = getattr(host, 'zodiac_binding', {})
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#') or line.startswith('期号'):  # 跳过注释和表头
                continue
            # 1) 优先按「空格分隔 TXT 导出格式」解析：与 data_import.py 的 TXT 导入、
            # plugins 顶栏「添加数据」共用 DataUtils.parse_txt_line，保证三处对同一
            # 行文本的期号/日期/正码/特别码逐字段一致；非 9 段、表头、乱码返回 None。
            parsed = DataUtils.parse_txt_line(line)
            if parsed:
                period, date, numbers, special = parsed
                # 期号统一口径：存储期序 + 完整期号/年份副字段，展示用期序
                period_seq, period_full, period_year = DataUtils.split_period(period, date)
                record = {
                    'period': period_seq,
                    'period_full': period_full,
                    'period_year': period_year,
                    'date': date,
                    'numbers': numbers,
                    'special': special,
                }
                # 写入时刻固化生肖快照（后续改绑不追溯改写本期历史）
                LotteryConfig.attach_zodiac_snapshot(record, snapshot_binding)
                host.historical_data.append(record)
                count += 1
                continue
            # 2) 非严格 9 段数字行，再按原始格式解析（如"第X期…生肖/五行…+特别码"）
            result = DataUtils.parse_raw_data(line)
            if result:
                period = result.get('period')
                date = result.get('date')
                period_seq, period_full, period_year = DataUtils.split_period(period, date)
                record = {
                    'period': period_seq,
                    'period_full': period_full,
                    'period_year': period_year,
                    'date': date,
                    'numbers': result.get('numbers'),
                    'special': result.get('special'),
                }
                # 写入时刻固化生肖快照（后续改绑不追溯改写本期历史）
                LotteryConfig.attach_zodiac_snapshot(record, snapshot_binding)
                host.historical_data.append(record)
                count += 1
                continue
            # 3) 逗号分隔格式（CSV导出格式），路径保持原样
            if ',' in line:
                parts = [p.strip() for p in line.split(',')]
                if len(parts) >= 9:
                    try:
                        period_seq, period_full, period_year = DataUtils.split_period(
                            parts[0], parts[1])
                        record = {
                            'period': period_seq,
                            'period_full': period_full,
                            'period_year': period_year,
                            'date': parts[1],
                            'numbers': [int(parts[i]) for i in range(2, 8)],
                            'special': int(parts[8]),
                        }
                        # 写入时刻固化生肖快照（后续改绑不追溯改写本期历史）
                        LotteryConfig.attach_zodiac_snapshot(record, snapshot_binding)
                        host.historical_data.append(record)
                        count += 1
                        continue
                    except (ValueError, IndexError):
                        pass
            # 三种格式都不匹配才计入失败，由汇总提示统一告知
            fail_count += 1

        if count > 0:
            host._save_data()
            host._update_history_table()
            host._data_fingerprint_at_last_predict = None
            host._data_fingerprint_at_last_ml_predict = None
            msg = f"成功添加 {count} 条记录"
            if fail_count > 0:
                msg += f"，失败 {fail_count} 条"
            QMessageBox.information(host, "成功", msg)
        else:
            QMessageBox.warning(host, "错误", "没有成功解析的数据，请检查格式")
    except Exception as e:
        QMessageBox.warning(host, "错误", "批量添加失败: " + str(e))


def on_batch_delete(host):
    """删除表格中选中的记录（支持 Ctrl 多选）

    功能:
        收集 selectedItems 的行号（页内相对索引），加上分页偏移转为绝对索引；
        确认后从大到小删除，避免删除前面的行导致后面索引整体前移。

    参数:
        host: 主窗口实例，读取 host.history_table / host.history_page /
            host.history_page_size，改写 host.historical_data。

    返回:
        None。

    副作用:
        - 修改 host.historical_data；调用 host._save_data() 落盘并
          update_history_table(host) 刷新；
        - 未选中时仅提示、不做任何修改；
        - 确认对话框使用 Yes/No 标准按钮。
    """
    selected_rows = set()
    for item in host.history_table.selectedItems():
        selected_rows.add(item.row())
    if not selected_rows:
        QMessageBox.information(host, "提示", "请先选择要删除的记录（可按住Ctrl多选）")
        return
    reply = QMessageBox.question(host, "确认批量删除", "确定要删除选中的 " + str(len(selected_rows)) + " 条记录吗？", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    if reply == QMessageBox.StandardButton.Yes:
        # 【修复分页索引bug】批量删除需加上分页偏移量转为绝对索引
        page_offset = (host.history_page - 1) * host.history_page_size
        for row in sorted(selected_rows, reverse=True):
            abs_row = row + page_offset
            if 0 <= abs_row < len(host.historical_data):
                del host.historical_data[abs_row]
        host._save_data()
        host._update_history_table()
        QMessageBox.information(host, "成功", "已删除 " + str(len(selected_rows)) + " 条记录")


def on_batch_modify(host):
    """对选中记录（或全部记录）执行批量修改

    功能:
        提供三种模式：
        1) 期号批量偏移：给每条记录的 period 加上整数偏移（仅处理 int/float 类型）；
        2) 批量修改日期：支持“+7/-3”天偏移或直接替换为指定日期字符串；
        3) 批量修正期号格式：按选中顺序从指定起始期号连续重编号。
        修改后统一保存并刷新表格。

    参数:
        host: 主窗口实例，读取 host.history_table / host.historical_data；
            改写记录的 period、date 字段。

    返回:
        None。

    副作用:
        - 原地修改 host.historical_data 中记录字段；
        - 调用 host._save_data() 与 update_history_table(host)；
        - 每个模式结束弹成功提示；异常时打印堆栈并弹警告。

    说明:
        未选中记录时走“全部数据”分支，此时行号已是绝对索引；
        只有选中记录时才叠加分页偏移。
    """
    options = ["批量修改日期", "期号批量偏移", "批量修正期号格式"]
    choice, ok = QInputDialog.getItem(host, "批量修改", "选择修改类型:", options, 0, False)
    if not ok:
        return

    selected_rows = set()
    for item in host.history_table.selectedItems():
        selected_rows.add(item.row())

    if not selected_rows:
        reply = QMessageBox.question(host, "提示", "未选中记录，是否对全部数据执行批量修改？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
        rows_to_modify = list(range(len(host.historical_data)))
    else:
        rows_to_modify = sorted(selected_rows)

    try:
        # 只有选中记录才需要把分页行号换算成绝对索引；
        # “全部数据”分支已经是绝对索引，不能再用空的 selected_rows 覆盖
        if selected_rows:
            page_offset = (host.history_page - 1) * host.history_page_size
            rows_to_modify = [r + page_offset for r in sorted(selected_rows)]

        if not rows_to_modify:
            QMessageBox.information(host, "提示", "没有可修改的记录")
            return
        if choice == "期号批量偏移":
            offset, ok = QInputDialog.getInt(host, "期号偏移", "输入偏移量（正数增加，负数减少）:", 0, -99999, 99999)
            if not ok:
                return
            for row in rows_to_modify:
                if 0 <= row < len(host.historical_data):
                    old_period = host.historical_data[row].get('period', 0)
                    if isinstance(old_period, (int, float)):
                        host.historical_data[row]['period'] = int(old_period) + offset
            QMessageBox.information(host, "成功", f"已修改 {len(rows_to_modify)} 条记录的期号")

        elif choice == "批量修改日期":
            date_text, ok = QInputDialog.getText(host, "批量修改日期",
                "输入日期计算表达式，例如：\n+7 表示日期加7天\n-3 表示日期减3天\n2025-01-01 表示替换为指定日期")
            if not ok or not date_text.strip():
                return

            date_text = date_text.strip()
            import datetime  # 作用说明：批量日期偏移（+7/-3 天）需 strptime/timedelta 做日期运算

            if date_text.startswith('+') or date_text.startswith('-'):
                # 日期偏移
                days = int(date_text)
                for row in rows_to_modify:
                    if 0 <= row < len(host.historical_data):
                        old_date = host.historical_data[row].get('date', '')
                        if old_date:
                            try:
                                dt = datetime.datetime.strptime(old_date, '%Y-%m-%d')
                                dt += datetime.timedelta(days=days)
                                host.historical_data[row]['date'] = dt.strftime('%Y-%m-%d')
                            except Exception:
                                pass
                QMessageBox.information(host, "成功", f"已修改 {len(rows_to_modify)} 条记录的日期")
            else:
                # 替换为指定日期
                for row in rows_to_modify:
                    if 0 <= row < len(host.historical_data):
                        host.historical_data[row]['date'] = date_text
                QMessageBox.information(host, "成功", f"已将 {len(rows_to_modify)} 条记录的日期设为 {date_text}")

        elif choice == "批量修正期号格式":
            # 自动按顺序重新编号
            start_num, ok = QInputDialog.getInt(host, "修正期号", "输入起始期号:", 1, 1, 999999)
            if not ok:
                return
            # 按当前顺序重新编号
            for i, row in enumerate(rows_to_modify):
                if 0 <= row < len(host.historical_data):
                    host.historical_data[row]['period'] = start_num + i
            QMessageBox.information(host, "成功", f"已修正 {len(rows_to_modify)} 条记录的期号")

        host._save_data()
        host._update_history_table()

    except Exception as e:
        import traceback  # 作用说明：批量修改异常时同时打印堆栈与弹窗，便于排查数据格式问题
        traceback.print_exc()
        QMessageBox.warning(host, "错误", "批量修改失败: " + str(e))


def on_export_history(host):
    """导出全部历史记录为 JSON / CSV / TXT

    功能:
        弹出保存对话框，按用户选择的过滤器自动补全扩展名：
        - JSON：调用 host._safe_write_json（原子写，避免中途失败损坏文件）；
        - CSV：写表头“期号,日期,正码1..6,特别码”，使用 utf-8-sig 保证 Excel 直接打开不乱码；
        - TXT：首行写 # 注释表头，每行“期号 日期 六正码 特别码”，与批量添加的空格格式一致。
        号码统一 zfill(2) 补零，numbers 不足 6 个时补 0 占位。

    参数:
        host: 主窗口实例，读取 host.historical_data。

    返回:
        None。

    副作用:
        - 在用户选择的路径创建/覆盖文件；
        - 成功/失败均通过 QMessageBox 提示；
        - 无数据时直接提示并返回，不打开文件对话框。

    异常:
        文件写入异常被捕获并弹窗（"导出失败: ..."）。
    """
    if not host.historical_data:
        QMessageBox.information(host, "提示", "没有可导出的历史记录")
        return
    file_path, selected_filter = QFileDialog.getSaveFileName(
        host, "导出历史记录", "彩票历史记录导出.json",
        "JSON文件 (*.json);;CSV文件 (*.csv);;TXT文件 (*.txt)"
    )
    if file_path:
        try:
            # 根据用户选择的格式自动补全扩展名
            if selected_filter.startswith("CSV") and not file_path.lower().endswith('.csv'):
                file_path += '.csv'
            elif selected_filter.startswith("TXT") and not file_path.lower().endswith('.txt'):
                file_path += '.txt'
            elif selected_filter.startswith("JSON") and not file_path.lower().endswith('.json'):
                file_path += '.json'

            if file_path.lower().endswith('.json'):
                if host._safe_write_json(file_path, host.historical_data):
                    QMessageBox.information(host, "成功", f"已导出 {len(host.historical_data)} 条历史记录（JSON格式）")
                else:
                    QMessageBox.warning(host, "错误", "导出失败")
            elif file_path.lower().endswith('.csv'):
                with open(file_path, 'w', encoding='utf-8-sig', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(['期号', '日期', '正码1', '正码2', '正码3', '正码4', '正码5', '正码6', '特别码'])
                    for rec in host.historical_data:
                        nums = rec.get('numbers', [0]*6)
                        while len(nums) < 6:
                            nums.append(0)
                        writer.writerow([
                            rec.get('period', 0), rec.get('date', ''),
                            str(nums[0]).zfill(2), str(nums[1]).zfill(2), str(nums[2]).zfill(2),
                            str(nums[3]).zfill(2), str(nums[4]).zfill(2), str(nums[5]).zfill(2),
                            str(rec.get('special', 0)).zfill(2)
                        ])
                QMessageBox.information(host, "成功", f"已导出 {len(host.historical_data)} 条历史记录（CSV格式）")
            elif file_path.lower().endswith('.txt'):
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write("# 期号 日期 正码1 正码2 正码3 正码4 正码5 正码6 特别码\n")
                    for rec in host.historical_data:
                        nums = rec.get('numbers', [0]*6)
                        while len(nums) < 6:
                            nums.append(0)
                        f.write(f"{rec.get('period', 0)} {rec.get('date', '')} "
                                f"{' '.join(str(n).zfill(2) for n in nums)} {str(rec.get('special', 0)).zfill(2)}\n")
                QMessageBox.information(host, "成功", f"已导出 {len(host.historical_data)} 条历史记录（TXT格式）")
            else:
                QMessageBox.warning(host, "错误", "不支持的文件格式，请选择 .json / .csv / .txt")
        except Exception as e:
            QMessageBox.warning(host, "错误", "导出失败: " + str(e))


def on_import_history(host):
    """从 JSON / CSV / TXT 文件导入历史记录并追加

    功能:
        用户选择文件后交给主窗口 _parse_import_file 统一解析（不在本页重复
        实现各格式细节）；解析成功的记录追加到现有数据末尾。

    参数:
        host: 主窗口实例，读取 host.historical_data，
            调用 host._parse_import_file(file_path)。

    返回:
        None。

    副作用:
        - 追加解析结果到 host.historical_data，随后保存并刷新表格；
        - 把 _data_fingerprint_at_last_predict / _data_fingerprint_at_last_ml_predict
          置 None，使预测缓存失效；
        - 无有效数据时弹提示；解析/保存异常时弹错误框。
    """
    file_path, _ = QFileDialog.getOpenFileName(
        host, "导入历史记录", "",
        "所有支持格式 (*.json *.csv *.txt);;JSON文件 (*.json);;CSV文件 (*.csv);;TXT文件 (*.txt);;所有文件 (*)"
    )
    if file_path:
        try:
            imported_data, report = host._parse_import_file(file_path, with_report=True)
            host._last_import_report = report
            if hasattr(host, '_refresh_import_report'):
                host._refresh_import_report(report)
            missing_count = len(report.get('missing') or [])
            if missing_count:
                ask = getattr(host, '_ask_skip_missing_import', None)
                if ask is None or not ask(report['missing']):
                    host.statusBar().showMessage("本次未导入（%d 行缺期号）" % missing_count)
                    return
            imported_data = report.get('records') or []
            if imported_data:
                # 导入属于“写入时刻”：逐条固化当前绑定快照（已有快照的记录不覆盖）
                binding = getattr(host, 'zodiac_binding', {})
                for record in imported_data:
                    LotteryConfig.attach_zodiac_snapshot(record, binding)
                host.historical_data.extend(imported_data)
                host._save_data()
                host._update_history_table()
                host._data_fingerprint_at_last_predict = None
                host._data_fingerprint_at_last_ml_predict = None
                notes = []
                if report.get('merged'):
                    notes.append("已合并重复 %d 期" % report['merged'])
                if report.get('conflicts'):
                    notes.append("其中 %d 期与库内已有期号重复，未写入：%s"
                                 % (len(report['conflicts']),
                                    '、'.join(str(p) for p in report['conflicts'])))
                QMessageBox.information(host, "成功", f"已导入 {len(imported_data)} 条历史记录"
                                        + (("\n" + "\n".join(notes)) if notes else ""))
                host.statusBar().showMessage(
                    "导入 %d 条 / 跳过 %d 条（%d 条缺期号）/ 合并重复 %d 期"
                    % (len(imported_data), report.get('skipped', 0) + missing_count,
                       missing_count, report.get('merged', 0)))
            else:
                QMessageBox.warning(host, "提示", "未从文件中解析到有效数据")
        except Exception as e:
            QMessageBox.warning(host, "错误", "导入失败: " + str(e))


def backfill_zodiac_snapshots(host, persist=True, show_message=False):
    """一次性回填历史记录的生肖快照（幂等、可重复运行、有统计输出）

    功能:
        用当前生效的生肖绑定（host.zodiac_binding）给所有“缺快照”的历史记录
        补写 record['zodiacs'] / record['special_zodiac']。
        已有完整快照的记录一律跳过，绝不覆盖；取不到生肖的记录保持缺快照，
        展示时继续走“当前绑定实时推算”的回退路径并如实标注来源。

    参数:
        host: 主窗口实例，读取 host.historical_data 与 host.zodiac_binding。
        persist (bool): True 时在有补写的情况下调用 host._save_data() 落盘。
        show_message (bool): True 时弹窗展示统计结果（供「回填快照」按钮使用）。

    返回:
        dict: ensure_zodiac_snapshots() 的统计信息
              （total/filled/skipped_existing/skipped_incomplete/remaining）。

    口径限制:
        写入的是“当前绑定”的快照，不是“开奖日期所在农历年的当年映射”；
        因此它能保证“改绑定不追溯改写历史”，但不保证历史记录按当年规则正确。
    """
    binding = getattr(host, 'zodiac_binding', {}) or {}
    records = getattr(host, 'historical_data', []) or []
    stats = LotteryConfig.ensure_zodiac_snapshots(records, binding)
    if persist and stats['filled'] > 0:
        host._save_data()
        host._update_history_table()
    if show_message:
        QMessageBox.information(
            host, "回填生肖快照",
            f"共 {stats['total']} 条记录\n"
            f"本次补写 {stats['filled']} 条\n"
            f"已有快照跳过 {stats['skipped_existing']} 条\n"
            f"绑定不完整无法补写 {stats['skipped_incomplete']} 条\n\n"
            "说明：快照记录的是“写入时刻”的生肖绑定，不是开奖当年的生肖映射。"
        )
    return stats


def install(host):
    """安装「历史记录」选项卡：先在 host 上挂本页事件，再构建界面（v0.0.28）

    功能:
        由主窗口创建选项卡时调用。把本模块的 16 个事件实现以 lambda 形式绑定
        到 host，供 build 内部信号连接与外部（菜单/快捷键）调用，最后返回页面。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。

    返回:
        QWidget: build(host) 构建完成的页面控件。

    副作用（挂载的 host 属性）:
        - _apply_detail_font_scale / _change_detail_font_size：详情字号缩放；
        - _on_history_col_resized / _save_history_col_widths：列宽防抖保存；
        - _on_history_sort / _on_prev_page / _on_next_page / _on_page_jump：排序与分页；
        - _refresh_latest_display：最新一期展示；
        - _update_history_table：历史表格渲染（本模块 update_history_table 的实例包装）；
        - _on_show_period_detail：生成选中期详情；
        - _on_batch_add_clicked / _on_batch_delete_clicked /
          _on_batch_modify_clicked：批量增删改；
        - _on_export_history_clicked / _on_import_history_clicked：导入导出。

    说明:
        本页全部事件实现都在本模块内（v0.0.28 起页面自包含）；
        历史表格渲染 update_history_table 已迁入本模块，并以
        host._update_history_table 实例属性保持既有调用方式；
        _save_data / _parse_import_file / _on_clear_data_clicked
        等跨页共用设施仍保留在主窗口。
    """
    host._apply_detail_font_scale = lambda: apply_detail_font_scale(host)
    host._change_detail_font_size = lambda delta: change_detail_font_size(host, delta)
    host._on_history_col_resized = lambda index, old_size, new_size: on_history_col_resized(host, index, old_size, new_size)
    host._save_history_col_widths = lambda: save_history_col_widths(host)
    host._on_history_sort = lambda order: on_history_sort(host, order)
    host._on_prev_page = lambda: on_prev_page(host)
    host._on_next_page = lambda: on_next_page(host)
    host._on_page_jump = lambda page: on_page_jump(host, page)
    host._refresh_latest_display = lambda: refresh_latest_display(host)
    host._on_show_period_detail = lambda: on_show_period_detail(host)
    host._on_batch_add_clicked = lambda: on_batch_add(host)
    host._on_batch_delete_clicked = lambda: on_batch_delete(host)
    host._on_batch_modify_clicked = lambda: on_batch_modify(host)
    host._on_export_history_clicked = lambda: on_export_history(host)
    host._on_import_history_clicked = lambda: on_import_history(host)
    host._backfill_zodiac_snapshots = lambda: backfill_zodiac_snapshots(host, persist=True, show_message=True)
    # 历史表格渲染迁入本模块：用 *a 吸收 clicked(bool) 等信号参数（渲染函数只接收 host），
    # 保持实例属性调用方式不变
    host._update_history_table = lambda *a, **kw: update_history_table(host)
    return build(host)


def build(host):
    """构建「历史记录」选项卡页面（纯界面，不执行业务逻辑）

    功能:
        按“顶部工具栏 → 左列（最新数据/表格+分页） → 右列（快捷操作/详情）”
        的顺序创建控件并挂到 host，最后返回页面 QWidget。控件顺序即界面视觉
        顺序，新增按钮应追加，避免打乱既有布局与用户肌肉记忆。

    参数:
        host: 主窗口实例（LotteryPredictionWindow），控件与状态挂载在此对象上。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用（挂载的 host 属性）:
        - host.history_count_label：筛选后条数提示；
        - host.history_h_splitter / history_left_v_splitter /
          history_right_v_splitter：供 _apply_splitter_sizes 记忆比例；
        - host.history_latest_display：最新一期展示；
        - host.history_table：九列分页表格（Interactive 列宽、行高 46/52、
          HistoryBallDelegate 整表委托、逐像素滚动）；
        - host.history_page_label / history_page_spin：分页标签与跳转框；
        - host.period_detail_edit：只读详情富文本框；
        - host.history_stats_label：统计摘要标签；
        - 读取 host._history_col_widths（INI 恢复的列宽）与
          host._on_xxx（install 挂载的回调）。

    说明:
        左右比例 8:2，左列上下 2:8，右列上下 6:4；三处分隔条位置均交给
        host._apply_splitter_sizes 恢复/保存。v0.0.36 的角控件共用逻辑与
        15px 字号下限在 UI 层统一样式中，本页不重复实现。
    """
    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.setSpacing(0)
    layout.setContentsMargins(5, 5, 5, 5)

    # 标题行
    header_layout = QHBoxLayout()
    title = QLabel("历史记录")
    title.setObjectName("PanelTitle")
    header_layout.addWidget(title)

    host.history_count_label = QLabel("")
    # 历史记录数量标签样式
    #   color: #555555;     文字颜色：深灰（统计信息用灰色）
    #   font-size: 15px;    字体大小：15px
    _register_history_theme(host, host.history_count_label,
                            "color: #555555; font-size: 15px;",
                            "color: " + HISTORY_DARK_TOKENS['secondary'] + "; font-size: 15px;")
    header_layout.addWidget(host.history_count_label)
    header_layout.addStretch()

    # 字体调节 - 表格字体
    table_font_label = QLabel("📊 表格字体:")
    # 表格字体调节标签样式
    #   color: #555555;         文字颜色：深灰
    #   font-size: 15px;        字体大小：15px
    #   font-weight: bold;      字体：粗体（强调标签）
    _register_history_theme(host, table_font_label,
                            "color: #555555; font-size: 15px; font-weight: bold;",
                            "color: " + HISTORY_DARK_TOKENS['secondary'] + "; font-size: 15px; font-weight: bold;")
    header_layout.addWidget(table_font_label)

    table_font_minus = QPushButton("A-")
    table_font_minus.setFixedSize(75, 28)
    # 历史表格字体缩小按钮样式 - 绿色系（缩小/减少操作用绿色）
    #   QPushButton {       按钮常态样式
    #     background-color: #E8F5E9;  背景色：浅绿
    #     color: #2E7D32;             文字颜色：深绿
    #     border: 1px solid #A5D6A7;  边框：1px 绿色实线
    #     border-radius: 6px;         圆角：6px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #C8E6C9;  悬停背景色：稍深的浅绿
    #   }
    _register_history_theme(
        host, table_font_minus,
        "QPushButton { background-color: #E8F5E9; color: #2E7D32; border: 1px solid #A5D6A7; border-radius: 6px; font-weight: bold; } QPushButton:hover { background-color: #C8E6C9; }",
        "QPushButton { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: " + HISTORY_DARK_TOKENS['success']
        + "; border: 1px solid " + HISTORY_DARK_TOKENS['border'] + "; border-radius: 6px; font-weight: bold; } "
        "QPushButton:hover { background-color: " + HISTORY_DARK_TOKENS['hover'] + "; }")
    # 表格字体缩小按钮点击信号：缩小历史记录表格字体
    table_font_minus.clicked.connect(lambda: host._change_area_font_size('table', -1))
    header_layout.addWidget(table_font_minus)

    table_font_plus = QPushButton("A+")
    table_font_plus.setFixedSize(75, 28)
    # 历史表格字体放大按钮样式 - 红色系（放大/增加操作用红色警示色）
    #   QPushButton {       按钮常态样式
    #     background-color: #FFEBEE;  背景色：浅红（提示增加操作）
    #     color: #C62828;             文字颜色：深红
    #     border: 1px solid #EF9A9A;  边框：1px 浅红实线
    #     border-radius: 6px;         圆角：6px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #FFCDD2;  悬停背景色：稍深的浅红
    #   }
    _register_history_theme(
        host, table_font_plus,
        "QPushButton { background-color: #FFEBEE; color: #C62828; border: 1px solid #EF9A9A; border-radius: 6px; font-weight: bold; } QPushButton:hover { background-color: #FFCDD2; }",
        "QPushButton { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: " + HISTORY_DARK_TOKENS['danger']
        + "; border: 1px solid " + HISTORY_DARK_TOKENS['border'] + "; border-radius: 6px; font-weight: bold; } "
        "QPushButton:hover { background-color: " + HISTORY_DARK_TOKENS['hover'] + "; }")
    # 表格字体放大按钮点击信号：放大历史记录表格字体
    table_font_plus.clicked.connect(lambda: host._change_area_font_size('table', 1))
    header_layout.addWidget(table_font_plus)

    refresh_btn = QPushButton("刷新")
    # 刷新按钮点击信号：刷新历史记录表格
    refresh_btn.clicked.connect(host._update_history_table)
    header_layout.addWidget(refresh_btn)

    # 排序按钮 - 升序
    sort_asc_btn = QPushButton("升序")
    sort_asc_btn.setToolTip("按表格数据升序排列")
    sort_asc_btn.setFixedSize(75, 28)
    # 升序排序按钮样式 - 蓝色系（排序/操作用蓝色）
    #   QPushButton {       按钮常态样式
    #     background-color: #E3F2FD;  背景色：浅蓝
    #     color: #1565C0;             文字颜色：深蓝
    #     border: 1px solid #90CAF9;  边框：1px 蓝色实线
    #     border-radius: 6px;         圆角：6px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #BBDEFB;  悬停背景色：稍深的浅蓝
    #   }
    _register_history_theme(
        host, sort_asc_btn,
        "QPushButton { background-color: #E3F2FD; color: #1565C0; border: 1px solid #90CAF9; border-radius: 6px; font-weight: bold; } QPushButton:hover { background-color: #BBDEFB; }",
        "QPushButton { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: " + HISTORY_DARK_TOKENS['accent']
        + "; border: 1px solid " + HISTORY_DARK_TOKENS['border'] + "; border-radius: 6px; font-weight: bold; } "
        "QPushButton:hover { background-color: " + HISTORY_DARK_TOKENS['hover'] + "; }")
    # 升序排序按钮点击信号：按日期升序排列历史记录
    sort_asc_btn.clicked.connect(lambda: host._on_history_sort('asc'))
    header_layout.addWidget(sort_asc_btn)

    # 排序按钮 - 降序
    sort_desc_btn = QPushButton("降序")
    sort_desc_btn.setToolTip("按表格数据降序排列")
    sort_desc_btn.setFixedSize(75, 28)
    # 降序排序按钮样式 - 红色系（降序/反向操作用红色警示色）
    #   QPushButton {       按钮常态样式
    #     background-color: #FFEBEE;  背景色：浅红
    #     color: #C62828;             文字颜色：深红
    #     border: 1px solid #EF9A9A;  边框：1px 浅红实线
    #     border-radius: 6px;         圆角：6px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #FFCDD2;  悬停背景色：稍深的浅红
    #   }
    _register_history_theme(
        host, sort_desc_btn,
        "QPushButton { background-color: #FFEBEE; color: #C62828; border: 1px solid #EF9A9A; border-radius: 6px; font-weight: bold; } QPushButton:hover { background-color: #FFCDD2; }",
        "QPushButton { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: " + HISTORY_DARK_TOKENS['danger']
        + "; border: 1px solid " + HISTORY_DARK_TOKENS['border'] + "; border-radius: 6px; font-weight: bold; } "
        "QPushButton:hover { background-color: " + HISTORY_DARK_TOKENS['hover'] + "; }")
    # 降序排序按钮点击信号：按日期降序排列历史记录
    sort_desc_btn.clicked.connect(lambda: host._on_history_sort('desc'))
    header_layout.addWidget(sort_desc_btn)

    # 视图切换：本地 / 在线（只切换内容区，本地表格本身不做任何改动）
    #   color: #555555;     文字颜色：深灰
    #   font-size: 15px;    字体大小：15px
    #   font-weight: bold;  字体：粗体（与相邻标签一致）
    header_layout.addSpacing(12)
    view_label = QLabel("视图:")
    _register_history_theme(host, view_label,
                            "color: #555555; font-size: 15px; font-weight: bold;",
                            "color: " + HISTORY_DARK_TOKENS['secondary'] + "; font-size: 15px; font-weight: bold;")
    header_layout.addWidget(view_label)

    # 属性名即记忆键：主窗口 _save_widget_states 会自动写成 [WidgetState] c_online_view_combo，
    # 启动时由 _restore_widget_states 恢复；因此下拉框不要改名
    host.online_view_combo = QComboBox()
    host.online_view_combo.addItems(["本地", "在线"])
    host.online_view_combo.setFixedWidth(96)
    host.online_view_combo.setToolTip("切换本地历史与在线开奖数据；在线表只读")
    # 切换信号：0=本地（默认），1=在线；切换只换视图，绝不触发抓取
    host.online_view_combo.currentIndexChanged.connect(lambda index: switch_history_view(host, index))
    header_layout.addWidget(host.online_view_combo)

    layout.addLayout(header_layout)

    # 外层水平Splitter（左右分隔）
    host.history_h_splitter = QSplitter(Qt.Orientation.Horizontal)
    host.history_h_splitter.setHandleWidth(4)

    # 左半部分：垂直Splitter（上下分隔）
    host.history_left_v_splitter = QSplitter(Qt.Orientation.Vertical)
    host.history_left_v_splitter.setHandleWidth(4)

    # 上方：最新开奖数据
    latest_widget = QWidget()
    latest_layout = QVBoxLayout(latest_widget)
    latest_layout.setSpacing(5)

    latest_title = QLabel("最新开奖数据")
    latest_title.setObjectName("PanelTitle")
    latest_layout.addWidget(latest_title)

    host.history_latest_display = QLabel("暂无数据")
    host.history_latest_display.setObjectName("LatestDisplay")
    host.history_latest_display.setAlignment(Qt.AlignmentFlag.AlignCenter)
    host.history_latest_display.setWordWrap(True)
    latest_layout.addWidget(host.history_latest_display)

    host.history_left_v_splitter.addWidget(latest_widget)

    # 下方：历史记录表格
    table_widget = QWidget()
    table_layout = QVBoxLayout(table_widget)
    table_layout.setSpacing(0)
    table_layout.setContentsMargins(0, 0, 0, 0)

    host.history_table = QTableWidget()
    host.history_table.setObjectName("HistoryTable")
    host.history_table.setColumnCount(9)
    host.history_table.setHorizontalHeaderLabels(["期号", "日期", "正码", "特别码", "和值", "单双比", "大小比", "颜色分布", "跨度"])
    # 表头字号固定 15px（全项目最小字号）：表头默认继承全局 20px 字号时，
    # 窄档九列表头会被省略号截断；15px 下三字表头需 55px、四字需 76px。
    # 必须用控件级样式表，QSS 的 font-size 优先级高于 setFont()，setFont 会被覆盖
    # H54：暗色主题额外补底色/文字/边框；亮色只保留原来的字号规则，像素不变。
    _register_history_theme(
        host, host.history_table.horizontalHeader(),
        "QHeaderView { font-size: 15px; }",
        "QHeaderView { font-size: 15px; background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: "
        + HISTORY_DARK_TOKENS['text'] + "; } "
        "QHeaderView::section { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: "
        + HISTORY_DARK_TOKENS['text'] + "; border: none; }")

    # 几何档：宽 ≥1500 用 1600 档（52 行高/28 球径），否则 1180 档（46/24）
    host._history_ball_large = history_ball_is_large(host)
    ball_spec = HISTORY_BALL_SPECS[host._history_ball_large]
    default_col_widths = (HISTORY_COL_WIDTHS_LARGE if host._history_ball_large
                          else HISTORY_COL_WIDTHS_SMALL)

    # 一次性迁移：旧版九列合计约 780（正码 160 只够放 QLabel），新版按档位重排。
    # [Display] history_ball_v1=1 为防重复标记；标记只写内存 INI，随下一次正常保存
    # 落盘，启动阶段不产生任何写盘。迁移同时忽略旧 history_h_splitter 比例，
    # 避免 1180 下沿用 1600 的旧尺寸把表格撑出横向滚动条。
    ini = getattr(host, '_ini', None)
    migrated = False
    if ini is not None and hasattr(ini, 'has_section') and ini.has_section('Display'):
        migrated = str(ini['Display'].get('history_ball_v1', '0')).strip().lower() in ('1', 'true', 'yes')
    saved_widths = list(getattr(host, '_history_col_widths', []) or [])
    if not migrated:
        saved_widths = []
        splitter_sizes = getattr(host, '_splitter_sizes', None)
        if isinstance(splitter_sizes, dict):
            splitter_sizes.pop('history_h_splitter', None)
        if ini is not None and hasattr(ini, 'has_section'):
            if ini.has_section('Display'):
                ini['Display']['history_ball_v1'] = '1'
            # 启动末尾的 _restore_widget_states 会回放 [WidgetState] t_history_table，
            # 必须同步改写，否则旧 780 列宽会在构建后被重新套回
            if ini.has_section('WidgetState'):
                ini['WidgetState']['t_history_table'] = ','.join(str(w) for w in default_col_widths)

    # 列宽设置：Interactive 模式支持用户拖拽调整列宽（不随窗口自动伸缩）
    host.history_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    for i in range(9):
        # 恢复校验：列表长度足够、值非 None 且为正数才采用，否则回退档位默认宽度，
        # 避免 INI 损坏（空值/0/负数）导致列被隐藏或不可见
        if i < len(saved_widths) and saved_widths[i] is not None and saved_widths[i] > 0:
            host.history_table.setColumnWidth(i, saved_widths[i])
        else:
            host.history_table.setColumnWidth(i, default_col_widths[i])

    # 列宽变化时自动保存
    host.history_table.horizontalHeader().sectionResized.connect(host._on_history_col_resized)
    host.history_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
    # 确保水平和垂直滚动条都能正常出现
    host.history_table.setVerticalScrollMode(QTableWidget.ScrollMode.ScrollPerPixel)
    host.history_table.setHorizontalScrollMode(QTableWidget.ScrollMode.ScrollPerPixel)
    host.history_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    # 整表委托：号码球/生肖五行/背景/网格全部立即模式绘制，不创建任何 QWidget；
    # 选中行只换背景，球与球下文字颜色不变
    host.history_table.setItemDelegate(HistoryBallDelegate(host.history_table, host._history_ball_large))
    host.history_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    # 网格与斑马底由委托自绘，关闭视图默认网格避免双线
    host.history_table.setShowGrid(False)
    # H54：表体空白区（行不足一屏）默认取 QTableWidget 底色；亮色继承全局 QSS，
    # 暗色显式补底/字/边框，避免表格视口露出系统白色。
    _register_history_theme(
        host, host.history_table, None,
        "QTableWidget { background-color: " + HISTORY_DARK_TOKENS['bg'] + "; color: "
        + HISTORY_DARK_TOKENS['text'] + "; border: 1px solid " + HISTORY_DARK_TOKENS['border'] + "; } "
        "QTableWidget::item { background-color: transparent; }")
    # 隐藏行号表头：设计稿视口预算 748=760-12，不预留行号列宽
    host.history_table.verticalHeader().setVisible(False)
    # 行高按档位固定（46 / 52），不允许 A+ 放大改行高
    host.history_table.verticalHeader().setDefaultSectionSize(ball_spec['row'])
    # 球下文字与号码都在委托内绘制，禁用自动换行避免行高被撑开
    host.history_table.setWordWrap(False)

    table_layout.addWidget(host.history_table)

    # 功能12：历史记录分页控件
    pagination_widget = QWidget()
    pagination_layout = QHBoxLayout(pagination_widget)
    pagination_layout.setContentsMargins(0, 5, 0, 0)

    host.history_page_label = QLabel("第 1 页 / 共 1 页")
    pagination_layout.addWidget(host.history_page_label)

    pagination_layout.addStretch()

    prev_btn = QPushButton("上一页")
    prev_btn.setMaximumWidth(80)
    # 上一页按钮点击信号：翻到上一页
    prev_btn.clicked.connect(host._on_prev_page)
    pagination_layout.addWidget(prev_btn)

    pagination_layout.addWidget(QLabel("跳转至"))
    host.history_page_spin = QSpinBox()
    host.history_page_spin.setRange(1, 1)
    host.history_page_spin.setMinimumWidth(60)
    # 页码跳转输入框变化信号：跳转到指定页码
    host.history_page_spin.valueChanged.connect(host._on_page_jump)
    pagination_layout.addWidget(host.history_page_spin)

    pagination_layout.addWidget(QLabel("页"))

    next_btn = QPushButton("下一页")
    next_btn.setMaximumWidth(80)
    # 下一页按钮点击信号：翻到下一页
    next_btn.clicked.connect(host._on_next_page)
    pagination_layout.addWidget(next_btn)

    table_layout.addWidget(pagination_widget)

    host.history_left_v_splitter.addWidget(table_widget)

    # 左半部分比例：最新数据20%，表格80%
    host.history_left_v_splitter.setStretchFactor(0, 2)
    host.history_left_v_splitter.setStretchFactor(1, 8)
    # 左栏最小宽度 762：保证表格视口 ≥748（748 列宽 + 12 纵向滚动条 + 2 边框），
    # 1180 窗口下九列不出现横向滚动条
    host.history_left_v_splitter.setMinimumWidth(762)
    host._apply_splitter_sizes(host.history_left_v_splitter, 'history_left_v_splitter')

    host.history_h_splitter.addWidget(host.history_left_v_splitter)

    # 右半部分：垂直Splitter（上下分隔）
    host.history_right_v_splitter = QSplitter(Qt.Orientation.Vertical)
    host.history_right_v_splitter.setHandleWidth(4)

    # 上方：快捷操作面板（小按钮网格布局）
    action_widget = QWidget()
    action_layout = QVBoxLayout(action_widget)
    action_layout.setSpacing(6)
    action_layout.setContentsMargins(4, 4, 4, 4)

    action_title = QLabel("快捷操作")
    action_title.setObjectName("PanelTitle")
    action_layout.addWidget(action_title)

    # 网格布局：4列小按钮
    grid_widget = QWidget()
    grid_layout = QGridLayout(grid_widget)
    grid_layout.setSpacing(3)
    grid_layout.setContentsMargins(0, 0, 0, 0)

    # 快捷操作按钮样式 - 普通操作（白色系，用于添加/修改等非破坏性操作）
    #   QPushButton {       按钮常态样式
    #     background-color: #FFFFFF;  背景色：白色（简洁干净）
    #     color: #333333;             文字颜色：深灰
    #     border: 1px solid #DDDDDD;  边框：1px 浅灰实线
    #     border-radius: 4px;         圆角：4px
    #     padding: 4px 6px;           内边距：上下4px，左右6px
    #     font-size: 15px;            字体大小：15px
    #     font-weight: bold;          字体：粗体
    #     min-height: 26px;           最小高度：26px
    #   }
    #   QPushButton:hover {   悬停样式
    #     background-color: #F0F0F0;  悬停背景色：浅灰
    #     border-color: #BBBBBB;      悬停边框色：中灰
    #   }
    #   QPushButton:pressed { 按下样式
    #     background-color: #E0E0E0;  按下背景色：更深灰色（反馈感）
    #   }
    small_btn_style = (
        "QPushButton { background-color: #FFFFFF; color: #333333; border: 1px solid #DDDDDD; "
        "border-radius: 4px; padding: 4px 6px; font-size: 15px; font-weight: bold; min-height: 26px; } "
        "QPushButton:hover { background-color: #F0F0F0; border-color: #BBBBBB; } "
        "QPushButton:pressed { background-color: #E0E0E0; }"
    )
    # H54：暗色分支沿用 #313244 卡片底 / #F5F5F5 字 / #7F849C 边框（3.4:1）。
    small_btn_style_dark = (
        "QPushButton { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: "
        + HISTORY_DARK_TOKENS['text'] + "; border: 1px solid " + HISTORY_DARK_TOKENS['border']
        + "; border-radius: 4px; padding: 4px 6px; font-size: 15px; font-weight: bold; min-height: 26px; } "
        "QPushButton:hover { background-color: " + HISTORY_DARK_TOKENS['hover'] + "; border-color: "
        + HISTORY_DARK_TOKENS['accent'] + "; } "
        "QPushButton:pressed { background-color: " + HISTORY_DARK_TOKENS['pressed'] + "; }"
    )
    # 快捷操作按钮样式 - 危险操作（红色系，用于删除/清空等破坏性操作）
    #   QPushButton {       按钮常态样式
    #     background-color: #FFFFFF;  背景色：白色
    #     color: #E74C3C;             文字颜色：红色（警示）
    #     border: 1px solid #E74C3C;  边框：1px 红色实线（强调危险）
    #     border-radius: 4px;         圆角：4px
    #     padding: 4px 6px;           内边距：上下4px，左右6px
    #     font-size: 15px;            字体大小：15px
    #     font-weight: bold;          字体：粗体
    #     min-height: 26px;           最小高度：26px
    #   }
    #   QPushButton:hover {   悬停样式
    #     background-color: #FDF0EF;  悬停背景色：极浅红
    #   }
    #   QPushButton:pressed { 按下样式
    #     background-color: #FADBD8;  按下背景色：浅红（加强反馈）
    #   }
    danger_btn_style = (
        "QPushButton { background-color: #FFFFFF; color: #E74C3C; border: 1px solid #E74C3C; "
        "border-radius: 4px; padding: 4px 6px; font-size: 15px; font-weight: bold; min-height: 26px; } "
        "QPushButton:hover { background-color: #FDF0EF; } "
        "QPushButton:pressed { background-color: #FADBD8; }"
    )
    # H54：危险按钮暗色用 #FF8A8A（对 #313244 ≈ 6.0:1），不再出现 3.82:1。
    danger_btn_style_dark = (
        "QPushButton { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: "
        + HISTORY_DARK_TOKENS['danger'] + "; border: 1px solid " + HISTORY_DARK_TOKENS['border']
        + "; border-radius: 4px; padding: 4px 6px; font-size: 15px; font-weight: bold; min-height: 26px; } "
        "QPushButton:hover { background-color: " + HISTORY_DARK_TOKENS['hover'] + "; } "
        "QPushButton:pressed { background-color: " + HISTORY_DARK_TOKENS['pressed'] + "; }"
    )

    # 文案统一 4 字内、去掉 emoji：按钮最小宽 74px，四列网格最小约 319px，
    # 右栏最小宽从 393 降到约 319，1180 档水平分隔条可用行程约 81px（原先仅 7px）
    quick_actions = [
        ("批量添加", small_btn_style, host._on_batch_add_clicked),
        ("批量删除", danger_btn_style, host._on_batch_delete_clicked),
        ("批量修改", small_btn_style, host._on_batch_modify_clicked),
        ("清空", danger_btn_style, host._on_clear_data_clicked),
        ("导出记录", small_btn_style, host._on_export_history_clicked),
        ("导入记录", small_btn_style, host._on_import_history_clicked),
        ("回填快照", small_btn_style, host._backfill_zodiac_snapshots),
    ]

    cols = 4
    for i, (text, style, callback) in enumerate(quick_actions):
        btn = QPushButton(text)
        # 为快捷操作按钮应用对应的样式（批量添加/删除用绿色/红色系，批量修改用蓝色系）
        dark_style = danger_btn_style_dark if style is danger_btn_style else small_btn_style_dark
        _register_history_theme(host, btn, style, dark_style)
        # 快捷操作按钮点击信号：连接对应的批量处理回调函数
        btn.clicked.connect(callback)
        grid_layout.addWidget(btn, i // cols, i % cols)

    action_layout.addWidget(grid_widget)
    action_layout.addStretch()

    host.history_right_v_splitter.addWidget(action_widget)

    # 下方：期号详情显示面板
    detail_widget = QWidget()
    detail_layout = QVBoxLayout(detail_widget)
    detail_layout.setSpacing(5)

    detail_title_row = QHBoxLayout()
    detail_title = QLabel("期号详情")
    detail_title.setObjectName("PanelTitle")
    detail_title_row.addWidget(detail_title)
    detail_title_row.addStretch()

    # 字体大小调节按钮
    font_down_btn = QPushButton("A-")
    font_down_btn.setToolTip("减小字体")
    font_down_btn.setFixedSize(60, 26)
    # 期号详情字体缩小按钮样式 - 绿色系（缩小/减少操作用绿色）
    #   QPushButton {       按钮常态样式
    #     background-color: #E8F5E9;  背景色：浅绿
    #     color: #2E7D32;             文字颜色：深绿
    #     border: 1px solid #A5D6A7;  边框：1px 绿色实线
    #     border-radius: 6px;         圆角：6px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #C8E6C9;  悬停背景色：稍深的浅绿
    #   }
    _register_history_theme(
        host, font_down_btn,
        "QPushButton { background-color: #E8F5E9; color: #2E7D32; border: 1px solid #A5D6A7; border-radius: 6px; font-weight: bold; } QPushButton:hover { background-color: #C8E6C9; }",
        "QPushButton { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: " + HISTORY_DARK_TOKENS['success']
        + "; border: 1px solid " + HISTORY_DARK_TOKENS['border'] + "; border-radius: 6px; font-weight: bold; } "
        "QPushButton:hover { background-color: " + HISTORY_DARK_TOKENS['hover'] + "; }")
    # 字体缩小按钮点击信号：缩小期号详情字体
    font_down_btn.clicked.connect(lambda: host._change_detail_font_size(-0.1))
    detail_title_row.addWidget(font_down_btn)

    font_up_btn = QPushButton("A+")
    font_up_btn.setToolTip("增大字体")
    font_up_btn.setFixedSize(60, 26)
    # 期号详情字体放大按钮样式 - 红色系（放大/增加操作用红色警示色）
    #   QPushButton {       按钮常态样式
    #     background-color: #FFEBEE;  背景色：浅红（提示增加操作）
    #     color: #C62828;             文字颜色：深红
    #     border: 1px solid #EF9A9A;  边框：1px 浅红实线
    #     border-radius: 6px;         圆角：6px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #FFCDD2;  悬停背景色：稍深的浅红
    #   }
    _register_history_theme(
        host, font_up_btn,
        "QPushButton { background-color: #FFEBEE; color: #C62828; border: 1px solid #EF9A9A; border-radius: 6px; font-weight: bold; } QPushButton:hover { background-color: #FFCDD2; }",
        "QPushButton { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: " + HISTORY_DARK_TOKENS['danger']
        + "; border: 1px solid " + HISTORY_DARK_TOKENS['border'] + "; border-radius: 6px; font-weight: bold; } "
        "QPushButton:hover { background-color: " + HISTORY_DARK_TOKENS['hover'] + "; }")
    # 字体放大按钮点击信号：放大期号详情字体
    font_up_btn.clicked.connect(lambda: host._change_detail_font_size(0.1))
    detail_title_row.addWidget(font_up_btn)

    # 文案由「显示选中」缩为「查看」：详情标题行曾是右栏最小宽瓶颈（343→约 301），
    # 1180 档左右分隔条行程由 57px 提到约 99px；功能与顺序不变
    show_btn = QPushButton("查看")
    # 显示选中按钮点击信号：显示选中期的完整信息
    show_btn.clicked.connect(host._on_show_period_detail)
    # 显示选中期号详情按钮样式 - 绿色系（确认/显示操作用绿色）
    #   QPushButton {       按钮常态样式
    #     background-color: #2ECC71;  背景色：鲜绿
    #     color: white;                文字颜色：白色
    #     border: none;                边框：无
    #     border-radius: 4px;          圆角：4px
    #     padding: 5px 12px;           内边距：上下5px，左右12px
    #     font-weight: bold;           字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #27AE60;  悬停背景色：深绿
    #   }
    _register_history_theme(
        host, show_btn,
        "QPushButton { background-color: #2ECC71; color: white; border: none; border-radius: 4px; padding: 5px 12px; font-weight: bold; } QPushButton:hover { background-color: #27AE60; }",
        "QPushButton { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: "
        + HISTORY_DARK_TOKENS['success'] + "; border: 1px solid " + HISTORY_DARK_TOKENS['border']
        + "; border-radius: 4px; padding: 5px 12px; font-weight: bold; } "
        "QPushButton:hover { background-color: " + HISTORY_DARK_TOKENS['hover'] + "; }")
    detail_title_row.addWidget(show_btn)

    detail_layout.addLayout(detail_title_row)

    host.period_detail_edit = QTextEdit()
    host.period_detail_edit.setReadOnly(True)
    # 期号详情文本框样式
    #   QTextEdit {       文本框整体样式
    #     background-color: #FFFFFF;  背景色：白色
    #     color: #000000;             文字颜色：黑色
    #     border: 1px solid #DDDDDD;  边框：1px 浅灰实线
    #     border-radius: 4px;         圆角：4px
    #     font-size: 15px;            字体大小：15px
    #     padding: 8px;               内边距：8px
    #   }
    _register_history_theme(
        host, host.period_detail_edit,
        "QTextEdit { background-color: #FFFFFF; color: #000000; border: 1px solid #DDDDDD; border-radius: 4px; font-size: 15px; padding: 8px; }",
        "QTextEdit { background-color: " + HISTORY_DARK_TOKENS['card'] + "; color: " + HISTORY_DARK_TOKENS['text']
        + "; border: 1px solid " + HISTORY_DARK_TOKENS['border']
        + "; border-radius: 4px; font-size: 15px; padding: 8px; }")
    host.period_detail_edit.setPlaceholderText("在表格中选择一期，然后点击「查看」按钮查看完整信息...")
    detail_layout.addWidget(host.period_detail_edit)

    # 统计摘要
    host.history_stats_label = QLabel("加载数据后显示统计信息")
    host.history_stats_label.setWordWrap(True)
    # 历史统计摘要标签样式
    #   color: #333333;     文字颜色：深灰（主要内容文字）
    #   font-size: 15px;    字体大小：15px
    #   line-height: 1.5;   行高：1.5倍（提高可读性）
    _register_history_theme(host, host.history_stats_label,
                            "color: #333333; font-size: 15px; line-height: 1.5;",
                            "color: " + HISTORY_DARK_TOKENS['text'] + "; font-size: 15px; line-height: 1.5;")
    detail_layout.addWidget(host.history_stats_label)

    host.history_right_v_splitter.addWidget(detail_widget)

    # 右半部分比例：操作60%，统计40%
    host.history_right_v_splitter.setStretchFactor(0, 6)
    host.history_right_v_splitter.setStretchFactor(1, 4)
    host._apply_splitter_sizes(host.history_right_v_splitter, 'history_right_v_splitter')

    host.history_h_splitter.addWidget(host.history_right_v_splitter)

    # 左右比例：65:35（1180 约 762:404，1600 约 1020:566），左栏另有 762 最小宽度
    host.history_h_splitter.setStretchFactor(0, 13)
    host.history_h_splitter.setStretchFactor(1, 7)
    _avail = max(900, int(host.width()) - 10)
    _left_default = 1020 if host._history_ball_large else 762
    host._apply_splitter_sizes(host.history_h_splitter, 'history_h_splitter',
                               [_left_default, max(320, _avail - 4 - _left_default)])

    layout.addWidget(host.history_h_splitter)

    # 本地 / 在线视图容器：本地页保持原样（index 0），在线页为只读委托表格（index 1）
    # 启动时默认本地；主窗口 _restore_widget_states() 恢复 c_online_view_combo 后，
    # 由 apply_restored_view() 决定是否切到在线（只读库，绝不发网络请求）
    host.history_view_stack = QStackedWidget()
    host.history_view_stack.addWidget(host.history_h_splitter)
    host.history_online_page = build_online_page(host)
    host.history_view_stack.addWidget(host.history_online_page)
    host.history_view_stack.setCurrentIndex(0)
    layout.addWidget(host.history_view_stack)

    # 在线抓取的线程控制器：安装在 host 与在线页上的事件过滤器用于
    # 「切页中断」和「关窗 3 秒内有界退出」
    host._online_controller = OnlineFetchController(host, host.history_online_page)

    # 启动恢复视图：单次 0ms 投递，保证在主窗口 _restore_widget_states() 之后执行；
    # 恢复失败/无库时静默回落到本地，不影响启动
    QTimer.singleShot(0, lambda: apply_restored_view(host))

    # 运行时自适应：主窗口 Resize 去抖 200ms 后重判 1180/1600 档（≥1500 判大档），
    # 只改列宽/行高/委托字号，不重建表格、不重置分页与选中；跨档缩小时自动收进视口
    install_history_ball_autosize(host)

    return widget


# [在线开奖：委托渲染 + 页面构建]

ONLINE_PAGE_SIZE = 100  # 在线表每页期数（与本地历史表一致）

# 在线表九列：期号为源站期号（如 2026307），不是本地自增序号
ONLINE_HEADERS = ["期号", "日期", "正码", "特别码", "和值", "单双比", "大小比", "颜色分布", "跨度"]
ONLINE_COL_WIDTHS = [90, 120, 190, 90, 60, 65, 65, 110, 60]


class OnlineNumbersDelegate(QStyledItemDelegate):
    """在线表号码列委托：白底圆球 + 波色数字，整表不创建任何 QLabel 子控件

    职责:
        只接管第 2 列（正码 6 个）与第 3 列（特别码 1 个）的绘制；其余列交给
        QStyledItemDelegate 的标准绘制（文字、选中背景、焦点框均保持系统样式）。

    性能:
        100 行只需 paint 调用，不创建 QWidget；实测构建 + 首帧 ≤ 30ms。

    约束:
        本委托只用于在线表；本地历史表使用 HistoryBallDelegate（同样无子控件）。
    """

    BALL_SIZE = 22   # 号码球直径（像素）
    BALL_GAP = 4     # 号码球间距（像素）

    def paint(self, painter, option, index):
        """先画标准单元格背景，再在号码列上绘制号码球

        参数:
            painter (QPainter): 表格传入的绘图器；
            option (QStyleOptionViewItem): 含矩形、选中态、字体；
            index (QModelIndex): 当前单元格索引，UserRole 存号码列表。
        返回:
            None。
        """
        super().paint(painter, option, index)
        if index.column() not in (2, 3):
            return
        numbers = index.data(Qt.ItemDataRole.UserRole)
        if not numbers:
            return
        if isinstance(numbers, int):
            numbers = [numbers]
        try:
            numbers = [int(n) for n in numbers]
        except (TypeError, ValueError):
            return
        if not numbers:
            return

        font = QFont(option.font)
        font.setBold(True)
        font.setPixelSize(14)
        painter.save()
        painter.setFont(font)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        count = len(numbers)
        total_width = count * self.BALL_SIZE + (count - 1) * self.BALL_GAP
        start_x = option.rect.x() + max(0, (option.rect.width() - total_width) // 2)
        top_y = option.rect.y() + (option.rect.height() - self.BALL_SIZE) // 2

        for offset, number in enumerate(numbers):
            colors = LotteryConfig.get_number_color(number)
            ball_rect = QRect(start_x + offset * (self.BALL_SIZE + self.BALL_GAP),
                              top_y, self.BALL_SIZE, self.BALL_SIZE)
            painter.setPen(QPen(QColor(colors['border'])))
            painter.setBrush(QColor(colors['bg']))
            painter.drawEllipse(ball_rect)
            painter.setPen(QPen(QColor(colors['text'])))
            painter.drawText(ball_rect, Qt.AlignmentFlag.AlignCenter, str(number).zfill(2))

        painter.restore()


def _current_registry(host):
    """读取并缓存站点注册表（只读，不写盘）"""
    registry = online_sites.load_registry()
    host._online_registry = registry
    return registry


def _registry_sites(host):
    """取当前缓存的站点列表（没有缓存时现读注册表）"""
    registry = getattr(host, '_online_registry', None)
    if not registry:
        registry = _current_registry(host)
    return registry.get('sites') or []


def _site_status_text(site):
    """站点状态文案：启用/已停用 + 备注"""
    if not site:
        return '未配置'
    state = '启用' if site.get('enabled') else '已停用'
    note = site.get('note') or ''
    return '%s%s' % (state, '（%s）' % note if note else '')


def _site_item_text(site):
    """站点下拉项文案：名称 · 彩种与开奖时间 · 状态"""
    lottery = site.get('lottery') or '—'
    draw_time = site.get('draw_time') or '—'
    return '%s · %s %s · %s' % (site.get('name') or site.get('id'), lottery, draw_time,
                                _site_status_text(site))


def _update_site_detail(host, index):
    """站点详情：彩种与开奖时间、模板生成的实际网址（当前年）、状态"""
    label = getattr(host, 'online_site_detail', None)
    if label is None:
        return
    sites = _registry_sites(host)
    if not sites:
        label.setText('尚未配置站点：请点「站点编辑」新增（id / 名称 / 彩种与开奖时间 / '
                      'url_template（含 {year}）/ 启用），或点「新增站点」开始。')
        return
    if not (0 <= int(index) < len(sites)):
        return
    site = sites[int(index)]
    text = '%s · %s %s · %s' % (site.get('name') or site.get('id'),
                                site.get('lottery') or '—', site.get('draw_time') or '—',
                                _site_status_text(site))
    url = online_sites.site_url(site)
    if url:
        text += ' · 实际网址：%s' % url
    try:
        label.setText(text)
    except RuntimeError:
        pass


def _on_site_selected(host, index):
    """点选站点：把「模板 + 当前年」生成的网址填入网址框（不自动发起抓取）"""
    sites = _registry_sites(host)
    if not (0 <= int(index) < len(sites)):
        return
    edit = getattr(host, 'online_url_edit', None)
    url = online_sites.site_url(sites[int(index)])
    if edit is not None and url:
        edit.setText(url)
    _update_site_detail(host, index)


def _update_auto_label(host, registry=None):
    """刷新主行「自动抓取」状态文案"""
    registry = registry or _current_registry(host)
    label = getattr(host, 'online_auto_label', None)
    if label is None:
        return
    site = online_sites.default_site(registry)
    if site:
        text = '自动抓取：%s · %s %s' % (site.get('name') or site.get('id'),
                                        site.get('lottery') or '—', site.get('draw_time') or '—')
    else:
        text = '自动抓取：未配置站点（请展开高级区新增站点）'
    try:
        label.setText(text)
    except RuntimeError:
        pass


def _refresh_site_combo(host, registry=None):
    """重新填充站点下拉（保存注册表后即时生效，不需重启）"""
    registry = registry or _current_registry(host)
    combo = getattr(host, 'online_site_combo', None)
    if combo is not None:
        sites = registry.get('sites') or []
        combo.blockSignals(True)
        combo.clear()
        for site in sites:
            combo.addItem(_site_item_text(site))
        default_site = online_sites.default_site(registry)
        if default_site is not None:
            ids = [site.get('id') for site in sites]
            combo.setCurrentIndex(ids.index(default_site.get('id')))
        elif sites:
            combo.setCurrentIndex(0)
        combo.blockSignals(False)
        combo.setEnabled(bool(sites))
        _update_site_detail(host, combo.currentIndex() if sites else -1)
    _update_auto_label(host, registry)
    return registry


def _set_advanced_panel(host, expanded):
    """展开/收起「高级 / 自定义站点」面板（默认收起）"""
    panel = getattr(host, 'online_advanced_panel', None)
    button = getattr(host, 'online_advanced_btn', None)
    if panel is not None:
        panel.setVisible(bool(expanded))
    if button is not None:
        button.setText('高级 / 自定义站点 ▾' if expanded else '高级 / 自定义站点 ▸')


def build_online_page(host):
    """构建「在线」视图页（URL 抓取 + 摘要/警告 + 只读委托表格 + 分页）

    参数:
        host: 主窗口实例，控件与状态挂到 host 的 online_* / _online_* 属性。

    返回:
        QWidget: 在线视图页控件。

    说明:
        本函数不读在线库、不创建库文件；只有用户切换到在线视图时才由
        _restore_online_state() 按需读取。
    """
    page = QWidget()
    outer = QVBoxLayout(page)
    outer.setSpacing(4)
    outer.setContentsMargins(5, 5, 5, 5)

    # 第 0 行：视图切换（在线列表 / 同期对照）；本页仍是一个选项卡
    view_row = QHBoxLayout()
    view_row.setSpacing(6)
    view_label = QLabel("视图:")
    _register_history_theme(host, view_label,
                            "color: #555555; font-size: 15px; font-weight: bold;",
                            "color: #AAB2C8; font-size: 15px; font-weight: bold;")
    view_row.addWidget(view_label)

    host.online_list_view_btn = QPushButton("在线列表")
    host.online_same_view_btn = QPushButton("同期对照")
    for button, tooltip in ((host.online_list_view_btn, "查看在线抓取列表与分页"),
                            (host.online_same_view_btn, "按同年同期号并排对照在线库与本地历史（只读）")):
        button.setCheckable(True)
        button.setMinimumHeight(30)
        button.setMinimumWidth(96)
        button.setToolTip(tooltip)
        _register_history_theme(
            host, button,
            "QPushButton { background-color: #FFFFFF; color: #555555; border: 1px solid #CCCCCC; "
            "border-radius: 4px; padding: 4px 14px; font-size: 15px; font-weight: bold; } "
            "QPushButton:hover { background-color: #F5F5F5; } "
            "QPushButton:checked { background-color: #E3F2FD; color: #1565C0; border-color: #90CAF9; }",
            "QPushButton { background-color: #1B2233; color: #AAB2C8; border: 1px solid #2C3A5A; "
            "border-radius: 4px; padding: 4px 14px; font-size: 15px; font-weight: bold; } "
            "QPushButton:hover { background-color: #24304A; } "
            "QPushButton:checked { background-color: #1E2A3A; color: #8AB4F8; border-color: #3B5A8A; }")
        view_row.addWidget(button)
    host._online_subview_group = QButtonGroup(host)
    host._online_subview_group.setExclusive(True)
    host._online_subview_group.addButton(host.online_list_view_btn, 0)
    host._online_subview_group.addButton(host.online_same_view_btn, 1)
    host.online_list_view_btn.setChecked(True)
    host.online_list_view_btn.clicked.connect(lambda: switch_online_subview(host, 0))
    host.online_same_view_btn.clicked.connect(lambda: switch_online_subview(host, 1))
    view_row.addStretch()
    outer.addLayout(view_row)

    host.online_inner_stack = QStackedWidget()
    content = QWidget()
    layout = QVBoxLayout(content)
    layout.setSpacing(6)
    layout.setContentsMargins(0, 0, 0, 0)

    # 第一行：自动抓取状态 + 刷新/取消 + 高级折叠入口（网址输入已降级到高级区）
    main_row = QHBoxLayout()
    main_row.setSpacing(8)
    host.online_auto_label = QLabel('自动抓取：未配置站点')
    host.online_auto_label.setWordWrap(True)
    _register_history_theme(host, host.online_auto_label,
                            "color: #555555; font-size: 15px; font-weight: bold;",
                            "color: #AAB2C8; font-size: 15px; font-weight: bold;")
    main_row.addWidget(host.online_auto_label, 1)

    host.online_refresh_btn = QPushButton("刷新")
    host.online_refresh_btn.setMinimumHeight(30)
    host.online_refresh_btn.setToolTip("强制重新抓取（忽略 30 分钟缓存）")
    # 刷新按钮样式 - 绿色系（确认/执行操作用绿色）
    host.online_refresh_btn.setStyleSheet(
        "QPushButton { background-color: #2ECC71; color: white; border: none; border-radius: 4px; "
        "padding: 5px 14px; font-weight: bold; font-size: 15px; } "
        "QPushButton:hover { background-color: #27AE60; } "
        "QPushButton:disabled { background-color: #B7C9BE; color: #EEEEEE; }")
    host.online_refresh_btn.clicked.connect(lambda: start_online_fetch(host, force=True))
    main_row.addWidget(host.online_refresh_btn)

    host.online_cancel_btn = QPushButton("取消")
    host.online_cancel_btn.setMinimumHeight(30)
    host.online_cancel_btn.setEnabled(False)
    # 取消按钮样式 - 灰色系（运行中才可点的次要操作）
    host.online_cancel_btn.setStyleSheet(
        "QPushButton { background-color: #FFFFFF; color: #666666; border: 1px solid #CCCCCC; "
        "border-radius: 4px; padding: 5px 12px; font-weight: bold; font-size: 15px; } "
        "QPushButton:hover { background-color: #F0F0F0; } "
        "QPushButton:disabled { color: #BBBBBB; border-color: #E0E0E0; }")
    host.online_cancel_btn.clicked.connect(lambda: cancel_online_fetch(host))
    main_row.addWidget(host.online_cancel_btn)

    host.online_advanced_btn = QPushButton("高级 / 自定义站点 ▸")
    host.online_advanced_btn.setMinimumHeight(30)
    host.online_advanced_btn.setCheckable(True)
    host.online_advanced_btn.setChecked(False)
    host.online_advanced_btn.setToolTip("展开后可见站点清单与自定义网址（默认收起）")
    _register_history_theme(
        host, host.online_advanced_btn,
        "QPushButton { background-color: #FFFFFF; color: #555555; border: 1px solid #CCCCCC; "
        "border-radius: 4px; padding: 4px 12px; font-size: 15px; font-weight: bold; } "
        "QPushButton:hover { background-color: #F5F5F5; } "
        "QPushButton:checked { background-color: #E3F2FD; color: #1565C0; border-color: #90CAF9; }",
        "QPushButton { background-color: #1B2233; color: #AAB2C8; border: 1px solid #2C3A5A; "
        "border-radius: 4px; padding: 4px 12px; font-size: 15px; font-weight: bold; } "
        "QPushButton:hover { background-color: #24304A; } "
        "QPushButton:checked { background-color: #1E2A3A; color: #8AB4F8; border-color: #3B5A8A; }")
    host.online_advanced_btn.toggled.connect(lambda checked: _set_advanced_panel(host, checked))
    main_row.addWidget(host.online_advanced_btn)
    layout.addLayout(main_row)

    # 高级 / 自定义站点面板：站点清单 + 实际网址 + 记住抓取 + 清空（默认收起）
    host.online_advanced_panel = QWidget()
    advanced_layout = QVBoxLayout(host.online_advanced_panel)
    advanced_layout.setContentsMargins(0, 2, 0, 2)
    advanced_layout.setSpacing(4)

    site_row = QHBoxLayout()
    site_row.setSpacing(6)
    site_label = QLabel("站点:")
    _register_history_theme(host, site_label,
                            "color: #555555; font-size: 15px; font-weight: bold;",
                            "color: #AAB2C8; font-size: 15px; font-weight: bold;")
    site_row.addWidget(site_label)

    host.online_site_combo = QComboBox()
    host.online_site_combo.setMinimumHeight(30)
    host.online_site_combo.setStyleSheet("QComboBox { font-size: 15px; padding: 2px 6px; }")
    host.online_site_combo.setToolTip("站点清单来自 系统v7.5/在线站点.json；点选后自动填入模板网址")
    host.online_site_combo.currentIndexChanged.connect(lambda index: _on_site_selected(host, index))
    site_row.addWidget(host.online_site_combo, 1)

    host.online_add_site_btn = QPushButton("新增站点")
    host.online_add_site_btn.setMinimumHeight(30)
    host.online_add_site_btn.clicked.connect(lambda: open_online_sites_dialog(host, new=True))
    _register_history_theme(
        host, host.online_add_site_btn,
        "QPushButton { background-color: #E3F2FD; color: #1565C0; border: 1px solid #90CAF9; "
        "border-radius: 4px; padding: 4px 12px; font-size: 15px; font-weight: bold; } "
        "QPushButton:hover { background-color: #BBDEFB; }",
        "QPushButton { background-color: #1B2233; color: #8AB4F8; border: 1px solid #2C3A5A; "
        "border-radius: 4px; padding: 4px 12px; font-size: 15px; font-weight: bold; } "
        "QPushButton:hover { background-color: #24304A; }")
    site_row.addWidget(host.online_add_site_btn)

    host.online_edit_sites_btn = QPushButton("站点编辑")
    host.online_edit_sites_btn.setMinimumHeight(30)
    host.online_edit_sites_btn.setToolTip("新增/编辑/停用站点与模板；点「保存」后才写入配置文件")
    _register_history_theme(
        host, host.online_edit_sites_btn,
        "QPushButton { background-color: #FFFFFF; color: #555555; border: 1px solid #CCCCCC; "
        "border-radius: 4px; padding: 4px 12px; font-size: 15px; font-weight: bold; } "
        "QPushButton:hover { background-color: #F5F5F5; }",
        "QPushButton { background-color: #1B2233; color: #AAB2C8; border: 1px solid #2C3A5A; "
        "border-radius: 4px; padding: 4px 12px; font-size: 15px; font-weight: bold; } "
        "QPushButton:hover { background-color: #24304A; }")
    host.online_edit_sites_btn.clicked.connect(lambda: open_online_sites_dialog(host, new=False))
    site_row.addWidget(host.online_edit_sites_btn)
    advanced_layout.addLayout(site_row)

    host.online_site_detail = QLabel('')
    host.online_site_detail.setWordWrap(True)
    _register_history_theme(host, host.online_site_detail,
                            "color: #555555; font-size: 15px;",
                            "color: #AAB2C8; font-size: 15px;")
    advanced_layout.addWidget(host.online_site_detail)

    # 自定义网址行：仅作为高级项，自动抓取默认使用注册表的默认站点模板
    url_row = QHBoxLayout()
    url_label = QLabel("开奖网址:")
    _register_history_theme(host, url_label,
                            "color: #555555; font-size: 15px; font-weight: bold;",
                            "color: #AAB2C8; font-size: 15px; font-weight: bold;")
    url_row.addWidget(url_label)

    host.online_url_edit = QLineEdit()
    host.online_url_edit.setPlaceholderText(
        "可留空：默认使用注册表的默认站点；也可粘贴自定义网址（url_template 需含 {year}）")
    host.online_url_edit.setStyleSheet("QLineEdit { font-size: 15px; padding: 4px 8px; }")
    host.online_url_edit.setMinimumHeight(30)
    host.online_url_edit.setClearButtonEnabled(True)
    # 回车等同点「抓取」：减少一次鼠标操作
    host.online_url_edit.returnPressed.connect(lambda: start_online_fetch(host))
    url_row.addWidget(host.online_url_edit, 1)

    host.online_fetch_btn = QPushButton("抓取")
    host.online_fetch_btn.setMinimumHeight(30)
    host.online_fetch_btn.setToolTip("按当前网址抓取一次（不再限制缓存）")
    host.online_fetch_btn.setStyleSheet(
        "QPushButton { background-color: #2ECC71; color: white; border: none; border-radius: 4px; "
        "padding: 5px 14px; font-weight: bold; font-size: 15px; } "
        "QPushButton:hover { background-color: #27AE60; } "
        "QPushButton:disabled { background-color: #B7C9BE; color: #EEEEEE; }")
    host.online_fetch_btn.clicked.connect(lambda: start_online_fetch(host, force=True))
    url_row.addWidget(host.online_fetch_btn)

    # 属性名即记忆键：自动写成 [WidgetState] b_online_cache_checkbox（勾选状态跨重启保留）
    host.online_cache_checkbox = QCheckBox("记住抓取数据")
    host.online_cache_checkbox.setChecked(False)  # 保守默认：不落盘，只保留本次运行
    host.online_cache_checkbox.setToolTip(
        "勾选后把本次手动抓取结果写入 系统v7.5/在线开奖.db（写后自动 checkpoint）；"
        "自动抓取永不写库；不勾选则只在本次运行内查看，不创建任何文件")
    host.online_cache_checkbox.setStyleSheet("QCheckBox { font-size: 15px; color: #555555; }")
    url_row.addWidget(host.online_cache_checkbox)

    host.online_clear_btn = QPushButton("清空在线数据")
    host.online_clear_btn.setMinimumHeight(30)
    # 清空按钮样式 - 红色系（破坏性操作）
    host.online_clear_btn.setStyleSheet(
        "QPushButton { background-color: #FFFFFF; color: #E74C3C; border: 1px solid #E74C3C; "
        "border-radius: 4px; padding: 5px 12px; font-weight: bold; font-size: 15px; } "
        "QPushButton:hover { background-color: #FDF0EF; } "
        "QPushButton:disabled { color: #E7A9A0; border-color: #F3C9C3; }")
    host.online_clear_btn.clicked.connect(lambda: clear_online_data(host))
    url_row.addWidget(host.online_clear_btn)
    advanced_layout.addLayout(url_row)

    host.online_advanced_panel.setVisible(False)
    layout.addWidget(host.online_advanced_panel)

    # 第二行：摘要条（成功/失败文案统一写在这里；自动抓取失败也只写一行）
    host.online_summary_label = QLabel("尚未抓取在线数据")
    host.online_summary_label.setWordWrap(True)
    host.online_summary_label.setStyleSheet("color: #555555; font-size: 15px;")
    layout.addWidget(host.online_summary_label)

    # 第三行：警告条（默认隐藏）
    host.online_warning_label = QLabel("")
    host.online_warning_label.setWordWrap(True)
    host.online_warning_label.setStyleSheet("color: #B26B00; font-size: 15px;")
    host.online_warning_label.setVisible(False)
    layout.addWidget(host.online_warning_label)

    # 抓取后的「在线 / 本地」三类差异提示：默认只提示、不写入
    compare_row = QHBoxLayout()
    compare_row.setSpacing(8)
    host.online_compare_label = QLabel("")
    host.online_compare_label.setWordWrap(True)
    host.online_compare_label.setVisible(False)
    _register_history_theme(host, host.online_compare_label,
                            "color: #555555; font-size: 15px;",
                            "color: #AAB2C8; font-size: 15px;")
    compare_row.addWidget(host.online_compare_label, 1)

    host.online_compare_btn = QPushButton("查看对比明细")
    host.online_compare_btn.setMinimumHeight(28)
    host.online_compare_btn.setFixedWidth(170)
    host.online_compare_btn.setEnabled(False)
    host.online_compare_btn.setToolTip("打开对比明细；只有点「采用在线」并二次确认才会写本地")
    host.online_compare_btn.clicked.connect(lambda: open_online_compare_dialog(host))
    _register_history_theme(
        host, host.online_compare_btn,
        "QPushButton { background-color: #E3F2FD; color: #1565C0; border: 1px solid #90CAF9; "
        "border-radius: 4px; padding: 4px 12px; font-size: 15px; font-weight: bold; } "
        "QPushButton:hover { background-color: #BBDEFB; } "
        "QPushButton:disabled { background-color: #F5F5F5; color: #AAAAAA; border-color: #DDDDDD; }",
        "QPushButton { background-color: #1B2233; color: #8AB4F8; border: 1px solid #2C3A5A; "
        "border-radius: 4px; padding: 4px 12px; font-size: 15px; font-weight: bold; } "
        "QPushButton:hover { background-color: #24304A; } "
        "QPushButton:disabled { background-color: #171C26; color: #5A6478; border-color: #2A3244; }")
    compare_row.addWidget(host.online_compare_btn)
    layout.addLayout(compare_row)

    # 在线只读表：委托渲染，不塞 QLabel
    host.online_table = QTableWidget()
    host.online_table.setObjectName("OnlineTable")
    host.online_table.setColumnCount(9)
    host.online_table.setHorizontalHeaderLabels(ONLINE_HEADERS)
    host.online_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    for i in range(9):
        host.online_table.setColumnWidth(i, ONLINE_COL_WIDTHS[i])
    host.online_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    host.online_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    host.online_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    host.online_table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    host.online_table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    host.online_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    host.online_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    host.online_table.verticalHeader().setDefaultSectionSize(40)
    host.online_table.setWordWrap(False)
    # 委托实例挂在表格上：号码列按 UserRole 数据绘制，其余列走默认绘制
    host.online_table.setItemDelegate(OnlineNumbersDelegate(host.online_table))
    # 列宽/勾选记忆：属性名即键 [WidgetState] t_online_table / b_online_cache_checkbox。
    # 信号在 apply_restored_view() 里才连接——必须晚于主窗口 _restore_widget_states()，
    # 否则启动恢复时的 setColumnWidth/setChecked 会触发一次闸门外的多余保存调用
    host._online_col_timer = QTimer(host)
    host._online_col_timer.setSingleShot(True)
    host._online_col_timer.timeout.connect(lambda: _persist_online_col_widths(host))
    layout.addWidget(host.online_table, 1)

    # 分页行：上一页 / 页码 / 下一页（keyset 或会话切片）
    page_row = QHBoxLayout()
    page_row.setContentsMargins(0, 4, 0, 0)
    host.online_page_label = QLabel("暂无在线数据")
    page_row.addWidget(host.online_page_label)
    page_row.addStretch()

    host.online_prev_btn = QPushButton("上一页")
    host.online_prev_btn.setMaximumWidth(90)
    host.online_prev_btn.setEnabled(False)
    host.online_prev_btn.clicked.connect(lambda: _online_load_page(host, -1))
    page_row.addWidget(host.online_prev_btn)

    host.online_next_btn = QPushButton("下一页")
    host.online_next_btn.setMaximumWidth(90)
    host.online_next_btn.setEnabled(False)
    host.online_next_btn.clicked.connect(lambda: _online_load_page(host, 1))
    page_row.addWidget(host.online_next_btn)

    layout.addLayout(page_row)

    # 运行态与分页状态：启动时全为“空”，不读库、不建库
    host._online_mode = 'none'          # none / session / db
    host._online_records_session = None  # 未勾选“记住”时的本次运行数据
    host._online_total = 0
    host._online_page_index = 0
    host._online_page_rows = []
    host._online_busy = False
    host._online_thread = None
    host._online_worker = None
    host._online_last_url = ''
    host._online_compare = None
    host._online_cache = None           # 会话缓存 {url, payload, ts}，30 分钟内命中不发请求
    host._online_auto_failed = set()    # 本次运行自动抓取失败的 URL（最多自动尝试一次）
    host._online_auto_tried = set()     # 本次运行已自动尝试过的 URL

    # 站点清单来自配置文件（缺失/为空时下拉禁用并显示「新增站点」引导）
    _refresh_site_combo(host)

    # 组装两个视图：index 0 = 在线列表（原页面全部内容），index 1 = 同期对照
    host.online_inner_stack.addWidget(content)
    host.same_period_page = build_same_period_view(host)
    host.online_inner_stack.addWidget(host.same_period_page)
    host.online_inner_stack.setCurrentIndex(0)
    outer.addWidget(host.online_inner_stack, 1)
    return page


def switch_online_subview(host, index):
    """切换「在线开奖」页内部视图（0=在线列表，1=同期对照）

    参数:
        host: 主窗口实例；
        index (int): 目标视图下标。

    返回:
        None。

    说明:
        首次切到同期对照才读在线库（ensure_same_period_loaded），
        切回在线列表不做任何写操作；选项卡总数保持不变。
    """
    stack = getattr(host, 'online_inner_stack', None)
    if stack is not None:
        stack.setCurrentIndex(0 if int(index) <= 0 else 1)
    for button, button_index in ((getattr(host, 'online_list_view_btn', None), 0),
                                 (getattr(host, 'online_same_view_btn', None), 1)):
        if button is None:
            continue
        button.blockSignals(True)
        button.setChecked(button_index == int(index))
        button.blockSignals(False)
    if int(index) == 1:
        ensure_same_period_loaded(host)


def _set_online_summary(host, text, level='info'):
    """设置摘要条文案与颜色（level: info/ok/error/warn）"""
    label = getattr(host, 'online_summary_label', None)
    if label is None:
        return
    color = {'info': '#555555', 'ok': '#1E7E34', 'error': '#C62828', 'warn': '#B26B00'}.get(level, '#555555')
    try:
        label.setStyleSheet("color: %s; font-size: 15px;" % color)
        label.setText(text)
    except RuntimeError:
        pass


def _set_online_warning(host, text):
    """设置警告条文案；空串时隐藏整条"""
    label = getattr(host, 'online_warning_label', None)
    if label is None:
        return
    try:
        label.setText(text or '')
        label.setVisible(bool(text))
    except RuntimeError:
        pass


def _clear_online_compare(host):
    """抓取失败/取消时清空对比提示（不改本地数据）"""
    host._online_compare = None
    host._online_compare_records = []
    host._online_compare_kept = set()
    label = getattr(host, 'online_compare_label', None)
    if label is not None:
        label.setText('')
        label.setVisible(False)
    button = getattr(host, 'online_compare_btn', None)
    if button is not None:
        button.setEnabled(False)
        button.setText('查看对比明细')


def render_online_rows(host, rows):
    """把当前页记录渲染到在线只读表（100 行目标 ≤30ms）

    参数:
        host: 主窗口实例；
        rows (list[dict]): online_store 或会话记录中的一页（含 source_period /
            draw_date / numbers / special）。

    说明:
        正码/特别码两列不写文字，只把号码放进 UserRole 交给 OnlineNumbersDelegate
        绘制圆球；其余七列用标准 QTableWidgetItem 文本。
    """
    table = getattr(host, 'online_table', None)
    if table is None:
        return
    foreground = "#CDD3F4" if getattr(host, 'is_dark_mode', False) else "#333333"
    table.setUpdatesEnabled(False)
    try:
        # 行数不变时不要先清零再重建：两次 setRowCount 会触发两轮布局，
        # 100 行实测多出 30ms 以上；行数变化时才调整
        if table.rowCount() != len(rows):
            table.setRowCount(len(rows))
        for row_index, record in enumerate(rows):
            numbers = list(record.get('numbers') or [])
            special = record.get('special')

            item_period = QTableWidgetItem(str(record.get('source_period', '?')))
            item_period.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            item_period.setForeground(QColor(foreground))
            table.setItem(row_index, 0, item_period)

            item_date = QTableWidgetItem(str(record.get('draw_date', '?')))
            item_date.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            item_date.setForeground(QColor(foreground))
            table.setItem(row_index, 1, item_date)

            # 正码：文字留空，号码交给委托绘制
            item_numbers = QTableWidgetItem('')
            item_numbers.setData(Qt.ItemDataRole.UserRole, numbers)
            table.setItem(row_index, 2, item_numbers)

            # 特别码：单号码同样交给委托
            item_special = QTableWidgetItem('')
            item_special.setData(Qt.ItemDataRole.UserRole,
                                 [special] if isinstance(special, int) else [])
            table.setItem(row_index, 3, item_special)

            total = sum(numbers) if numbers else 0
            item_sum = QTableWidgetItem(str(total))
            item_sum.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            item_sum.setForeground(QColor(foreground))
            table.setItem(row_index, 4, item_sum)

            odd = sum(1 for n in numbers if n % 2 == 1) if numbers else 0
            item_odd = QTableWidgetItem(str(odd) + ':' + str(len(numbers) - odd))
            item_odd.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            item_odd.setForeground(QColor(foreground))
            table.setItem(row_index, 5, item_odd)

            big = sum(1 for n in numbers if n > 24) if numbers else 0
            item_big = QTableWidgetItem(str(big) + ':' + str(len(numbers) - big))
            item_big.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            item_big.setForeground(QColor(foreground))
            table.setItem(row_index, 6, item_big)

            red = sum(1 for n in numbers if n in LotteryConfig.RED_NUMBERS) if numbers else 0
            blue = sum(1 for n in numbers if n in LotteryConfig.BLUE_NUMBERS) if numbers else 0
            green = len(numbers) - red - blue
            item_color = QTableWidgetItem('红' + str(red) + '蓝' + str(blue) + '绿' + str(green))
            item_color.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            item_color.setForeground(QColor(foreground))
            table.setItem(row_index, 7, item_color)

            span = (max(numbers) - min(numbers)) if numbers else 0
            item_span = QTableWidgetItem(str(span))
            item_span.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            item_span.setForeground(QColor(foreground))
            table.setItem(row_index, 8, item_span)
    finally:
        table.setUpdatesEnabled(True)


def _update_online_pagination(host):
    """刷新在线分页标签与上一页/下一页可用状态"""
    total = int(getattr(host, '_online_total', 0) or 0)
    index = int(getattr(host, '_online_page_index', 0) or 0)
    busy = bool(getattr(host, '_online_busy', False))
    pages = (total + ONLINE_PAGE_SIZE - 1) // ONLINE_PAGE_SIZE if total else 0

    label = getattr(host, 'online_page_label', None)
    if label is not None:
        if total <= 0:
            text = "暂无在线数据"
        else:
            text = "第 %d 页 / 共 %d 页（%d 期）" % (index + 1, pages, total)
        try:
            label.setText(text)
        except RuntimeError:
            pass

    prev_btn = getattr(host, 'online_prev_btn', None)
    next_btn = getattr(host, 'online_next_btn', None)
    if prev_btn is not None:
        prev_btn.setEnabled((not busy) and total > 0 and index > 0)
    if next_btn is not None:
        next_btn.setEnabled((not busy) and total > 0 and (index + 1) * ONLINE_PAGE_SIZE < total)


def _online_load_page(host, step):
    """在线表翻页：会话模式切片，落库模式走 keyset

    参数:
        host: 主窗口实例；
        step: -1 上一页 / +1 下一页。
    """
    if getattr(host, '_online_busy', False):
        return
    mode = getattr(host, '_online_mode', 'none')
    if mode == 'session':
        records = getattr(host, '_online_records_session', None) or []
        pages = max(1, (len(records) + ONLINE_PAGE_SIZE - 1) // ONLINE_PAGE_SIZE)
        new_index = int(getattr(host, '_online_page_index', 0)) + step
        if new_index < 0 or new_index >= pages:
            return
        host._online_page_index = new_index
        rows = records[new_index * ONLINE_PAGE_SIZE:(new_index + 1) * ONLINE_PAGE_SIZE]
    elif mode == 'db':
        current = getattr(host, '_online_page_rows', None) or []
        if not current:
            return
        if step > 0:
            last = current[-1]
            rows = online_store.fetch_page_next(last['draw_date'], last['id'], ONLINE_PAGE_SIZE)
            new_index = int(getattr(host, '_online_page_index', 0)) + 1
        else:
            first = current[0]
            rows = online_store.fetch_page_prev(first['draw_date'], first['id'], ONLINE_PAGE_SIZE)
            new_index = int(getattr(host, '_online_page_index', 0)) - 1
        if not rows or new_index < 0:
            return
        host._online_page_index = new_index
    else:
        return

    host._online_page_rows = rows
    render_online_rows(host, rows)
    _update_online_pagination(host)


def _persist_online_col_widths(host):
    """在线表列宽拖动结束后落盘（键 t_online_table 由主窗口通用扫描写入）"""
    try:
        if getattr(host, '_ini_write_enabled', True):
            host._save_ini_config()
    except Exception:
        pass


def _save_view_choice(host):
    """用户真实切换视图后落盘 c_online_view_combo

    说明:
        只由 switch_history_view 调用；启动恢复阶段信号被阻塞，不会触发本函数，
        因此启动零写入不受影响。
    """
    # 若启动时因无库回落而暂存了旧值（'1'），用户一旦真实切换就交还给下拉框真实值
    extra = getattr(host, '_widget_state_extra', None)
    if isinstance(extra, dict):
        extra.pop('c_online_view_combo', None)
    try:
        if getattr(host, '_ini_write_enabled', True):
            host._save_ini_config()
    except Exception:
        pass


def _install_online_memory_hooks(host):
    """在启动恢复完成后再连接列宽/勾选信号，避免恢复动作本身触发保存调用"""
    if getattr(host, '_online_mem_hooks', False):
        return
    table = getattr(host, 'online_table', None)
    checkbox = getattr(host, 'online_cache_checkbox', None)
    timer = getattr(host, '_online_col_timer', None)
    if table is None or timer is None:
        return
    table.horizontalHeader().sectionResized.connect(
        lambda index, old_size, new_size: timer.start(500))
    if checkbox is not None:
        checkbox.stateChanged.connect(lambda state: timer.start(500))
    host._online_mem_hooks = True


def apply_restored_view(host):
    """启动时按已恢复的 c_online_view_combo 应用视图（只读库，绝不发网络请求）

    行为:
        1) 上次是「本地」→ 保持本地，不读在线库；
        2) 上次是「在线」且库有数据 → 直接切到在线页，只读库渲染第一页；
        3) 上次是「在线」但库不存在/无数据 → 回落到本地，并且不覆盖旧值
           （旧值暂存到 _widget_state_extra，后续保存仍写回 '1'）。

    异常:
        全部吞掉并回落本地，恢复失败不得影响启动。
    """
    combo = getattr(host, 'online_view_combo', None)
    stack = getattr(host, 'history_view_stack', None)
    if combo is None or stack is None:
        return
    try:
        # 连接列宽/勾选信号：此刻主窗口 _restore_widget_states() 已结束，
        # 启动恢复产生的 setColumnWidth/setChecked 不会再触发保存
        _install_online_memory_hooks(host)
        if combo.currentIndex() != 1:
            return
        if not online_store.db_exists() or online_store.count_records() <= 0:
            # 回落本地：阻塞信号避免触发 switch_history_view，也不调用保存
            combo.blockSignals(True)
            combo.setCurrentIndex(0)
            combo.blockSignals(False)
            stack.setCurrentIndex(0)
            extra = getattr(host, '_widget_state_extra', None)
            if not isinstance(extra, dict):
                extra = {}
                host._widget_state_extra = extra
            extra['c_online_view_combo'] = '1'
            return
        stack.setCurrentIndex(1)
        _restore_online_state(host)
        _update_online_pagination(host)
        _maybe_auto_fetch(host)
    except Exception as exc:  # 恢复逻辑任何异常都不得阻断启动
        print("[在线开奖] 恢复上次视图失败，已回落本地: %s" % exc)
        try:
            stack.setCurrentIndex(0)
        except Exception:
            pass


def switch_history_view(host, index):
    """切换本地/在线视图：进在线页自动抓一次，切回本地时中断在线抓取

    说明:
        切到在线（index==1）后按注册表默认站点自动抓取：30 分钟内命中会话缓存
        不再发请求；无启用站点只写一行提示，不弹窗、不写任何文件。
    """
    stack = getattr(host, 'history_view_stack', None)
    if stack is None:
        return
    if index == 1:
        stack.setCurrentIndex(1)
        _restore_online_state(host)
        _update_online_pagination(host)
        _maybe_auto_fetch(host)
    else:
        stack.setCurrentIndex(0)
        controller = getattr(host, '_online_controller', None)
        if controller is not None:
            controller.request_interrupt()
    _save_view_choice(host)


def _restore_online_state(host):
    """进入在线视图时恢复状态：优先会话数据，其次在线库，最后保持空表

    说明:
        只有本函数会读取 系统v7.5/在线开奖.db；启动与本地视图均不会调用它，
        因此库不存在时不会被创建，也不会被读取。
    """
    if getattr(host, '_online_mode', 'none') != 'none':
        return
    if not online_store.db_exists():
        return
    total = online_store.count_records()
    if total <= 0:
        return
    meta = online_store.load_meta()
    host._online_mode = 'db'
    host._online_total = total
    host._online_page_index = 0
    host._online_page_rows = online_store.fetch_page_newest(ONLINE_PAGE_SIZE)
    render_online_rows(host, host._online_page_rows)

    url = meta.get('v_url') or getattr(host, '_online_last_url', '')
    edit = getattr(host, 'online_url_edit', None)
    if edit is not None and url and not edit.text().strip():
        edit.setText(url)

    summary = "已载入在线库快照 · %d 期" % total
    if meta.get('v_range_start') and meta.get('v_range_end'):
        summary += " · %s ~ %s" % (meta['v_range_start'], meta['v_range_end'])
    if meta.get('v_fetched_at'):
        summary += " · 上次抓取 %s" % meta['v_fetched_at']
    _set_online_summary(host, summary, 'info')

    warnings = []
    try:
        warnings = json.loads(meta.get('v_warnings') or '[]')
    except ValueError:
        warnings = []
    if warnings:
        _set_online_warning(host, "上次抓取警告：%s" % '；'.join(str(w) for w in warnings[:5]))
    else:
        _set_online_warning(host, '')


AUTO_FETCH_TTL_SECONDS = 30 * 60  # 同一运行周期内成功抓取结果的复用时长


def _status_message(host, text, timeout_ms=5000):
    """写状态栏一行提示（宿主尚未建状态栏时静默跳过）"""
    try:
        host.statusBar().showMessage(text, timeout_ms)
    except RuntimeError:
        pass


def _default_site_url(host):
    """注册表默认启用站点的模板网址（无启用站点返回空串）"""
    site = online_sites.default_site(_current_registry(host))
    return online_sites.site_url(site) if site else ''


def _cache_valid(host, url):
    """会话缓存是否命中：同一 URL 且距上次成功抓取不超过 30 分钟"""
    cache = getattr(host, '_online_cache', None)
    if not cache or cache.get('url') != url:
        return False
    return (time.monotonic() - float(cache.get('ts') or 0.0)) < AUTO_FETCH_TTL_SECONDS


def _maybe_auto_fetch(host):
    """进入「在线开奖」页时自动抓一次（不阻塞界面，失败只写一行提示）

    规则:
        1. 注册表无启用站点 → 不触发抓取，状态栏与摘要条各一行提示，不弹窗；
        2. 30 分钟会话缓存命中 → 直接用缓存渲染，发送 0 次请求；
        3. 同一 URL 本次运行已自动失败过 → 不再自动重试（最多一次）。
    """
    if getattr(host, '_online_busy', False):
        return
    registry = _current_registry(host)
    _refresh_site_combo(host, registry)
    url = _default_site_url(host)
    if not url:
        _set_online_summary(host, '未配置站点：请展开「高级 / 自定义站点」并点「站点编辑」新增站点。', 'warn')
        _status_message(host, '未配置站点，请先在高级区新增站点', 6000)
        return
    if _cache_valid(host, url):
        cache = host._online_cache or {}
        _apply_fetch_payload(host, cache.get('payload') or {}, from_cache=True)
        return
    if url in getattr(host, '_online_auto_failed', set()):
        return
    controller = getattr(host, '_online_controller', None)
    if controller is not None:
        controller.start_fetch(auto=True, url=url)


def _apply_fetch_payload(host, payload, from_cache=False):
    """把一次成功抓取（或缓存快照）应用到表格/摘要/警告/对比

    参数:
        host: 主窗口实例；
        payload (dict): Worker 的 finished 载荷（records/summary/warnings/...）；
        from_cache (bool): True 表示复用 30 分钟内缓存，不发请求、不重复写库。
    """
    store = payload.get('store_result')
    if store:
        # 落库模式：只保留当前页，后续翻页走 keyset
        host._online_mode = 'db'
        host._online_total = int(store.get('total', 0) or 0)
        host._online_records_session = None
        host._online_page_index = 0
        host._online_page_rows = online_store.fetch_page_newest(ONLINE_PAGE_SIZE)
    else:
        # 会话模式：数据只在内存，不创建在线库
        host._online_mode = 'session'
        records = payload.get('records') or []
        host._online_records_session = records
        host._online_total = len(records)
        host._online_page_index = 0
        host._online_page_rows = records[:ONLINE_PAGE_SIZE]

    render_online_rows(host, host._online_page_rows)
    _update_online_pagination(host)

    data = payload.get('summary') or {}
    text = "抓取成功 · %d 期 · %s ~ %s · 来源 %s" % (
        data.get('count', 0), data.get('range_start', '') or '-',
        data.get('range_end', '') or '-', payload.get('source_type', '-'))
    if store:
        text += " · 已写入在线库（新增 %d / 更新 %d / 未变 %d · -wal %d B · %.0f ms）" % (
            store.get('inserted', 0), store.get('updated', 0), store.get('unchanged', 0),
            store.get('wal_after', 0), store.get('elapsed_ms', 0))
    elif from_cache:
        text += " · 缓存命中（30 分钟内不重复请求）· 未写入库"
    else:
        text += " · 未写入库（仅本次运行）"
    _set_online_summary(host, text, 'ok')

    warnings = payload.get('warnings') or []
    removed = int(payload.get('removed', 0) or 0)
    if warnings or removed:
        parts = []
        if removed:
            parts.append("重复期号已合并 %d 条" % removed)
        parts.extend(str(w) for w in warnings[:3])
        if len(warnings) > 3:
            parts.append("…共 %d 条警告" % len(warnings))
        _set_online_warning(host, "警告：" + "；".join(parts))
    else:
        _set_online_warning(host, '')
    # 抓取完成 → 只读对比本地历史：默认只提示，不写任何一侧
    refresh_online_compare(host, payload.get('records') or [])
    _status_message(host, "在线抓取完成：%d 期" % data.get('count', 0), 5000)


SOURCE_TYPE_OPTIONS = ('macau_json', 'generic_json', 'generic_html', 'hkjc_json', 'hkjc_html')


class OnlineSiteEditDialog(QDialog):
    """单个站点的表单对话框（字段校验后才允许确定）"""

    def __init__(self, parent, site=None):
        super().__init__(parent)
        self.setWindowTitle('站点信息')
        self.setMinimumWidth(560)
        data = dict(site or {})

        layout = QVBoxLayout(self)
        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)

        def _add_row(row, label_text, widget):
            label = QLabel(label_text)
            label.setStyleSheet('font-size: 15px; font-weight: bold;')
            grid.addWidget(label, row, 0)
            grid.addWidget(widget, row, 1)

        self.id_edit = QLineEdit(data.get('id') or '')
        self.id_edit.setPlaceholderText('唯一标识，如 macau（不可重复）')
        _add_row(0, 'id:', self.id_edit)
        self.name_edit = QLineEdit(data.get('name') or '')
        self.name_edit.setPlaceholderText('显示名，如 新澳门六合彩')
        _add_row(1, '名称:', self.name_edit)
        self.lottery_edit = QLineEdit(data.get('lottery') or '')
        self.lottery_edit.setPlaceholderText('彩种，如 六合彩')
        _add_row(2, '彩种:', self.lottery_edit)
        self.draw_time_edit = QLineEdit(data.get('draw_time') or '')
        self.draw_time_edit.setPlaceholderText('开奖时间，如 21:32')
        _add_row(3, '开奖时间:', self.draw_time_edit)
        self.url_edit = QLineEdit(data.get('url_template') or '')
        self.url_edit.setPlaceholderText('必填且含 {year} 占位，如 https://host/path/{year}')
        _add_row(4, 'url_template:', self.url_edit)
        self.source_combo = QComboBox()
        for option in SOURCE_TYPE_OPTIONS:
            self.source_combo.addItem(option)
        if data.get('source_type') in SOURCE_TYPE_OPTIONS:
            self.source_combo.setCurrentText(data['source_type'])
        _add_row(5, '解析类型:', self.source_combo)
        self.note_edit = QLineEdit(data.get('note') or '')
        self.note_edit.setPlaceholderText('备注（可选），如 证书过期 / JS 页面')
        _add_row(6, '备注:', self.note_edit)
        self.enabled_check = QCheckBox('启用（参与自动抓取）')
        self.enabled_check.setChecked(bool(data.get('enabled', True)))
        grid.addWidget(self.enabled_check, 7, 1)
        layout.addLayout(grid)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel_btn = QPushButton('取消')
        cancel_btn.clicked.connect(self.reject)
        buttons.addWidget(cancel_btn)
        ok_btn = QPushButton('确定')
        ok_btn.setStyleSheet(
            'QPushButton { background-color: #2ECC71; color: white; border: none; border-radius: 4px; '
            'padding: 5px 16px; font-weight: bold; } QPushButton:hover { background-color: #27AE60; }')
        ok_btn.clicked.connect(self._on_ok)
        buttons.addWidget(ok_btn)
        layout.addLayout(buttons)

    def _on_ok(self):
        """校验 id / url_template 后返回数据；不合法时提示并留在表单"""
        site_id = self.id_edit.text().strip()
        template = self.url_edit.text().strip()
        if not site_id:
            QMessageBox.warning(self, '站点不完整', 'id 不能为空。')
            return
        if not template:
            QMessageBox.warning(self, '站点不完整', 'url_template 不能为空。')
            return
        if '{year}' not in template:
            QMessageBox.warning(self, '模板不合法', 'url_template 必须包含 {year} 占位，例如 https://host/path/{year}。')
            return
        try:
            template.format(year=datetime.datetime.now().year)
        except (KeyError, IndexError, ValueError) as exc:
            QMessageBox.warning(self, '模板不合法', 'url_template 占位符不正确：%s' % exc)
            return
        self.site_value = {
            'id': site_id,
            'name': self.name_edit.text().strip() or site_id,
            'lottery': self.lottery_edit.text().strip(),
            'draw_time': self.draw_time_edit.text().strip(),
            'url_template': template,
            'enabled': bool(self.enabled_check.isChecked()),
            'note': self.note_edit.text().strip(),
            'source_type': self.source_combo.currentText(),
        }
        self.accept()


class OnlineSitesDialog(QDialog):
    """站点编辑对话框：新增/编辑/启停/设默认/删除，点「保存」才写配置文件"""

    COLUMNS = ('id', '名称', '彩种', '开奖时间', 'url_template', '启用', '默认')

    def __init__(self, host, new=False):
        super().__init__(host)
        self._host = host
        self.setWindowTitle('在线站点编辑')
        self.resize(960, 540)
        registry = online_sites.load_registry()
        self._sites = [dict(site) for site in (registry.get('sites') or [])]
        self._default_id = str(registry.get('default_id') or '')

        layout = QVBoxLayout(self)
        hint = QLabel(
            '站点只来自配置文件：系统v7.5/在线站点.json（本对话框仅在点「保存」时写入）。'
            'url_template 必须含 {year} 占位；保存后即时生效，不需要重启。')
        hint.setWordWrap(True)
        hint.setStyleSheet('color: #555555; font-size: 15px;')
        layout.addWidget(hint)
        if registry.get('load_error'):
            error = QLabel(registry.get('load_error'))
            error.setWordWrap(True)
            error.setStyleSheet('color: #E74C3C; font-size: 15px;')
            layout.addWidget(error)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(list(self.COLUMNS))
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        layout.addWidget(self.table, 1)

        ops = QHBoxLayout()
        for text, slot in (('新增站点', self._add_site), ('编辑选中', self._edit_selected),
                           ('启用/停用', self._toggle_selected), ('设为默认', self._set_default_selected),
                           ('删除选中', self._delete_selected)):
            button = QPushButton(text)
            button.clicked.connect(slot)
            ops.addWidget(button)
        ops.addStretch(1)
        layout.addLayout(ops)

        footer = QHBoxLayout()
        footer.addStretch(1)
        close_btn = QPushButton('关闭')
        close_btn.clicked.connect(self.reject)
        footer.addWidget(close_btn)
        save_btn = QPushButton('保存')
        save_btn.setStyleSheet(
            'QPushButton { background-color: #2ECC71; color: white; border: none; border-radius: 4px; '
            'padding: 6px 20px; font-weight: bold; font-size: 15px; } '
            'QPushButton:hover { background-color: #27AE60; }')
        save_btn.clicked.connect(self._save)
        footer.addWidget(save_btn)
        layout.addLayout(footer)

        self._refresh_table()
        if new:
            QTimer.singleShot(0, self._add_site)

    def _refresh_table(self):
        """把内存站点列表刷到表格（不写盘）"""
        self.table.setRowCount(len(self._sites))
        for row, site in enumerate(self._sites):
            values = (site.get('id') or '', site.get('name') or '', site.get('lottery') or '',
                      site.get('draw_time') or '', site.get('url_template') or '',
                      '是' if site.get('enabled') else '否',
                      '★' if site.get('id') == self._default_id else '')
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                self.table.setItem(row, col, item)

    def _selected_index(self):
        rows = self.table.selectionModel().selectedRows() if self.table.selectionModel() else []
        return rows[0].row() if rows else -1

    def _add_site(self):
        """新增站点：不预填任何地址（用户要求零内置）"""
        dialog = OnlineSiteEditDialog(self, None)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        if dialog.site_value['id'] in [site.get('id') for site in self._sites]:
            QMessageBox.warning(self, 'id 重复', '站点 id 已存在，请换一个。')
            return
        self._sites.append(dialog.site_value)
        if not self._default_id:
            self._default_id = dialog.site_value['id']
        self._refresh_table()

    def _edit_selected(self):
        """编辑选中站点（修改模板后保存即生效）"""
        index = self._selected_index()
        if index < 0:
            QMessageBox.information(self, '未选中', '请先选中一行。')
            return
        dialog = OnlineSiteEditDialog(self, self._sites[index])
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        old_id = self._sites[index].get('id')
        if dialog.site_value['id'] != old_id and dialog.site_value['id'] in [s.get('id') for s in self._sites]:
            QMessageBox.warning(self, 'id 重复', '站点 id 已存在，请换一个。')
            return
        if self._default_id == old_id:
            self._default_id = dialog.site_value['id']
        self._sites[index] = dialog.site_value
        self._refresh_table()

    def _toggle_selected(self):
        index = self._selected_index()
        if index < 0:
            QMessageBox.information(self, '未选中', '请先选中一行。')
            return
        self._sites[index]['enabled'] = not bool(self._sites[index].get('enabled'))
        self._refresh_table()

    def _set_default_selected(self):
        index = self._selected_index()
        if index < 0:
            QMessageBox.information(self, '未选中', '请先选中一行。')
            return
        self._default_id = str(self._sites[index].get('id') or '')
        self._refresh_table()

    def _delete_selected(self):
        index = self._selected_index()
        if index < 0:
            QMessageBox.information(self, '未选中', '请先选中一行。')
            return
        removed = self._sites.pop(index)
        if self._default_id == removed.get('id'):
            self._default_id = self._sites[0].get('id') if self._sites else ''
        self._refresh_table()

    def _save(self):
        """仅在点「保存」时写 系统v7.5/在线站点.json，并即时刷新/触发抓取"""
        try:
            online_sites.save_registry({'default_id': self._default_id, 'sites': self._sites})
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, '保存失败', '写入站点配置失败：%s' % exc)
            return
        host = self._host
        registry = online_sites.load_registry()
        _refresh_site_combo(host, registry)
        # 注册表变化后旧缓存/失败记录失效，允许重新自动抓取
        host._online_cache = None
        host._online_auto_failed = set()
        host._online_auto_tried = set()
        _status_message(host, '站点配置已保存并即时生效', 5000)
        stack = getattr(host, 'history_view_stack', None)
        if stack is not None and stack.currentIndex() == 1:
            _maybe_auto_fetch(host)
        self.accept()


def open_online_sites_dialog(host, new=False):
    """打开站点编辑对话框（new=True 时直接进入新增表单）"""
    dialog = OnlineSitesDialog(host, new=new)
    dialog.exec()
    return dialog


def start_online_fetch(host, force=False, auto=False):
    """「刷新 / 抓取」入口：交给控制器启动后台线程（force=True 忽略会话缓存）"""
    controller = getattr(host, '_online_controller', None)
    if controller is not None:
        controller.start_fetch(force=force, auto=auto)


def cancel_online_fetch(host):
    """「取消」按钮入口：请求中断当前抓取（不阻塞界面）"""
    controller = getattr(host, '_online_controller', None)
    if controller is not None:
        controller.request_interrupt()


def clear_online_data(host):
    """「清空在线数据」：确认后删除在线库三件套并清空表格

    说明:
        只删 系统v7.5/在线开奖.db、-wal、-shm；本地历史数据（app_config.db /
        彩票数据.json）完全不受影响。
    """
    answer = QMessageBox.question(
        host, "清空在线数据",
        "确定删除 系统v7.5/在线开奖.db 及其 -wal/-shm 吗？\n本地历史数据不会被删除。",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        QMessageBox.StandardButton.No)
    if answer != QMessageBox.StandardButton.Yes:
        return
    controller = getattr(host, '_online_controller', None)
    if controller is not None:
        controller.request_interrupt()
    try:
        result = online_store.clear_online_store()
    except OSError as exc:
        _set_online_summary(host, "清空失败：%s" % exc, 'error')
        return
    host._online_mode = 'none'
    host._online_records_session = None
    host._online_total = 0
    host._online_page_index = 0
    host._online_page_rows = []
    render_online_rows(host, [])
    _set_online_warning(host, '')
    _set_online_summary(host, "在线数据已清空（删除 %d 个文件）" % len(result['deleted']), 'info')
    _update_online_pagination(host)


# [在线开奖：后台 Worker 与控制器]

class _OnlineFetchWorker(QObject):
    """在线抓取后台对象：下载、识别、解析、去重、写库、checkpoint 全在线程内

    线程约束:
        构造在 GUI 线程，run() 在 QThread 内执行；不访问任何 Qt 控件，
        只通过信号把进度/结果/错误回抛，由控制器在 GUI 线程更新界面。

    取消:
        should_stop 读取 QThread.currentThread().isInterruptionRequested()，
        在下载分块之间与每个阶段边界检查；取消时不写库。
    """

    progress = pyqtSignal(str)
    finished = pyqtSignal(dict)
    failed = pyqtSignal(str, str)
    cancelled = pyqtSignal()

    def __init__(self, url, remember, raw_url=None):
        """保存本次抓取参数快照（不持有 host）；raw_url 仅用于无法识别时回显原文"""
        super().__init__()
        self._url = url
        self._raw_url = raw_url if raw_url is not None else url
        self._remember = bool(remember)
        self._stop_event = threading.Event()

    def abort(self):
        """请求取消下载：置位停止标志，内层下载线程在下一分块/读超时后退出"""
        self._stop_event.set()

    @staticmethod
    def _is_interrupted():
        """读取当前 worker 线程的中断标志（必须在 worker 线程内调用）"""
        return QThread.currentThread().isInterruptionRequested()

    def _download(self):
        """在守护线程里执行阻塞下载，worker 线程以 50ms 粒度轮询取消

        原因:
            requests 流式读取在服务端迟迟不发数据时只能等满 15 秒读超时，
            Windows 下从外部关闭连接也无法立即打断阻塞的 recv；把下载放到
            守护线程后，worker 可在 50ms 内响应「取消/切页/关窗」并返回，
            守护线程最多再存活到读超时（15 秒）后自行结束，且不会阻止进程退出。

        返回:
            dict: fetch_url 的结果（url/text/content_type/size/status/elapsed_ms）。

        异常:
            透传 fetch_url 抛出的 OnlineSourceError；若已请求取消则抛 cancelled。
        """
        holder = {}

        def _job():
            try:
                holder['page'] = fetch_url(self._url, should_stop=self._stop_event.is_set)
            except BaseException as exc:  # 守护线程内兜底，异常交回 worker 线程重抛
                holder['error'] = exc

        # 用守护线程包住阻塞式 HTTP 下载：主线程通过 join(0.05) 轮询，
        # 既能保持界面响应，又能在用户取消时置 _stop_event 让请求尽快退出
        downloader = threading.Thread(target=_job, name='online-download', daemon=True)
        downloader.start()
        while downloader.is_alive():
            if self._is_interrupted():
                self._stop_event.set()
                raise OnlineSourceError('cancelled')
            downloader.join(0.05)
        if 'error' in holder:
            raise holder['error']
        return holder.get('page') or {}

    @pyqtSlot()
    def run(self):
        """线程入口：抓取 → 识别 → 解析 → 去重 →（可选）写库 + checkpoint"""
        try:
            self.progress.emit("正在下载页面…")
            page = self._download()
            if self._is_interrupted():
                raise OnlineSourceError('cancelled')

            self.progress.emit("已获取 %.1f KB，正在识别站点…" % (page.get('size', 0) / 1024.0))
            source_type = detect_source(page.get('url') or self._url,
                                        page.get('content_type'), page.get('text'))
            if source_type == 'unknown':
                if host_is_registered(page.get('url') or self._url):
                    raise OnlineSourceError('unknown_site', unknown_site_detail(self._raw_url))
                raise OnlineSourceError('unsupported_site', unsupported_site_detail(self._raw_url))

            self.progress.emit("正在解析开奖记录…")
            records, warnings, parse_stats = parse_payload(
                source_type, page.get('text'), page.get('url') or self._url,
                page.get('content_type'), page.get('status'))
            if self._is_interrupted():
                raise OnlineSourceError('cancelled')

            records, removed = dedupe_records(records)
            summary = summarize(records, warnings)
            store_result = None
            if self._remember:
                self.progress.emit("正在写入在线库并 checkpoint…")
                try:
                    store_result = online_store.save_snapshot(
                        records, page.get('url') or self._url, source_type, warnings)
                except Exception as exc:
                    raise OnlineSourceError('store_failed', str(exc))
            if self._is_interrupted():
                raise OnlineSourceError('cancelled')

            self.finished.emit({
                'url': page.get('url') or self._url,
                'source_type': source_type,
                'records': records,
                'warnings': list(warnings),
                'removed': int(removed),
                'parse_stats': parse_stats,
                'summary': summary,
                'store_result': store_result,
                'elapsed_ms': page.get('elapsed_ms', 0),
            })
        except OnlineSourceError as exc:
            if exc.kind == 'cancelled':
                self.cancelled.emit()
            else:
                self.failed.emit(exc.title, exc.detail)
        except Exception as exc:  # 兜底：任何未预期异常都转成界面可读文案
            self.failed.emit('抓取失败', str(exc))


class OnlineFetchController(QObject):
    """在线抓取线程生命周期与界面状态控制器（常驻 GUI 线程）

    职责:
        1) 启动/中断/收尾后台线程（持有 QThread/Worker 引用防 GC）；
        2) 接收 Worker 的进度/完成/失败/取消信号并更新摘要、表格、分页；
        3) 在线页 Hide 时中断抓取；窗口 Close 时 3 秒内有界退出。
    """

    def __init__(self, host, page=None):
        """以 host 为父对象创建控制器，并安装事件过滤器"""
        super().__init__(host)
        self._host = host
        self._page = page
        host.installEventFilter(self)
        if page is not None:
            page.installEventFilter(self)

    def _set_busy_ui(self, busy):
        """运行中置灰抓取/刷新/站点编辑并只放开取消，防止并发抓取"""
        host = self._host
        try:
            host.online_refresh_btn.setEnabled(not busy)
            host.online_fetch_btn.setEnabled(not busy)
            host.online_cancel_btn.setEnabled(busy)
            host.online_url_edit.setEnabled(not busy)
            host.online_cache_checkbox.setEnabled(not busy)
            host.online_clear_btn.setEnabled(not busy)
            host.online_site_combo.setEnabled(not busy and bool(_registry_sites(host)))
            host.online_add_site_btn.setEnabled(not busy)
            host.online_edit_sites_btn.setEnabled(not busy)
        except RuntimeError:
            return
        _update_online_pagination(host)

    def start_fetch(self, force=False, auto=False, url=None):
        """启动一次在线抓取（含重入保护、30 分钟缓存与自动/手动区分）

        参数:
            force (bool): True 时忽略会话缓存（「刷新」按钮）。
            auto (bool): True 为进页自动抓取：不写在线库、不弹窗、失败只提示一行。
            url (str|None): 显式指定网址（自动抓取用注册表默认站点模板生成）。
        """
        host = self._host
        # 重入保护：上一线程尚未彻底结束（thread 引用未清空）时不再启动，
        # 避免旧线程的 finished 信号把新任务的繁忙状态误报为空闲
        if getattr(host, '_online_busy', False) or getattr(host, '_online_thread', None) is not None:
            _status_message(host, "在线抓取正在进行中，请稍候…", 3000)
            return

        if url:
            raw_url = url
        else:
            raw_url = host.online_url_edit.text()
        target = normalize_url_input(raw_url)
        if not target:
            # 网址为空时回落到注册表默认站点模板；没有启用站点则只提示不抓取
            target = _default_site_url(host)
        if not target:
            _set_online_summary(host, '未配置站点：请展开「高级 / 自定义站点」并点「站点编辑」新增站点。', 'warn')
            _status_message(host, '未配置站点，请先在高级区新增站点', 6000)
            _set_online_warning(host, '')
            return
        if not auto and target != raw_url and host.online_url_edit.text().strip():
            # 归一化结果回填输入框：用户看到的就是实际抓取的地址（空输入时保持空，便于下次用模板）
            host.online_url_edit.setText(target)

        # 非强制刷新时命中缓存：直接渲染，不发送任何请求
        if not force and _cache_valid(host, target):
            _apply_fetch_payload(host, (host._online_cache or {}).get('payload') or {}, from_cache=True)
            return

        # 自动抓取永不写在线库；只有用户手动抓取且勾选「记住抓取数据」才落库
        remember = False if auto else bool(host.online_cache_checkbox.isChecked())
        thread = QThread(host)
        worker = _OnlineFetchWorker(target, remember, raw_url=raw_url)
        worker.moveToThread(thread)

        self._auto = bool(auto)
        thread.started.connect(worker.run)
        worker.progress.connect(self.on_worker_progress)
        worker.finished.connect(self.on_worker_finished)
        worker.failed.connect(self.on_worker_failed)
        worker.cancelled.connect(self.on_worker_cancelled)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        worker.cancelled.connect(thread.quit)
        thread.finished.connect(worker.deleteLater)
        thread.finished.connect(thread.deleteLater)
        thread.finished.connect(self.on_thread_finished)

        host._online_thread = thread
        host._online_worker = worker
        host._online_busy = True
        host._online_last_url = target
        self._set_busy_ui(True)
        _set_online_summary(host, "正在抓取：%s" % target, 'info')
        _set_online_warning(host, '')
        _status_message(host, "在线抓取已开始：后台下载中…", 5000)
        thread.start()

    def request_interrupt(self):
        """请求中断当前抓取（切页/取消/清空时调用，立即返回）"""
        worker = getattr(self._host, '_online_worker', None)
        if worker is not None:
            # 先关闭连接：否则流式读取会一直阻塞到 15 秒读超时才检查中断标志
            worker.abort()
        thread = getattr(self._host, '_online_thread', None)
        if thread is None:
            return
        try:
            if thread.isRunning():
                thread.requestInterruption()
                thread.quit()
        except RuntimeError:
            pass

    def shutdown(self, timeout_ms=3000):
        """关窗前有界等待线程结束（默认 3 秒）"""
        thread = getattr(self._host, '_online_thread', None)
        if thread is None:
            return
        worker = getattr(self._host, '_online_worker', None)
        if worker is not None:
            worker.abort()
        try:
            if thread.isRunning():
                thread.requestInterruption()
                thread.quit()
                if not thread.wait(timeout_ms):
                    print("[在线开奖] 后台抓取线程未在 %d ms 内结束，已放弃等待" % timeout_ms)
            if not thread.isRunning():
                self._host._online_thread = None
                self._host._online_worker = None
                self._host._online_busy = False
        except RuntimeError:
            self._host._online_thread = None
            self._host._online_worker = None
            self._host._online_busy = False

    def eventFilter(self, obj, event):
        """在线页 Hide → 中断抓取；宿主窗口 Close → 3 秒内收尾"""
        if obj is self._host and event.type() == QEvent.Type.Close:
            self.shutdown(3000)
        elif obj is self._page and event.type() == QEvent.Type.Hide:
            self.request_interrupt()
        return False

    # Worker 信号槽（全部在 GUI 线程执行）
    @pyqtSlot(str)
    def on_worker_progress(self, text):
        """进度文案写入摘要条与状态栏"""
        _set_online_summary(self._host, "抓取中 · %s" % text, 'info')
        try:
            self._host.statusBar().showMessage("在线开奖：%s" % text, 3000)
        except RuntimeError:
            pass

    @pyqtSlot(dict)
    def on_worker_finished(self, payload):
        """抓取成功：渲染结果、写会话缓存、复位同期对照加载标志

        说明:
            忙碌状态与按钮恢复统一放到 on_thread_finished()，保证“线程彻底结束”
            之前不会放开抓取按钮，避免旧线程的 finished 信号干扰新任务。
        """
        host = self._host
        url = str(payload.get('url') or getattr(host, '_online_last_url', '') or '')
        # 会话缓存：同一运行周期内 30 分钟复用，命中则 0 次请求
        host._online_cache = {'url': url, 'payload': payload, 'ts': time.monotonic()}
        host._online_auto_failed.discard(url)
        _apply_fetch_payload(host, payload)

        # 在线数据已更新：同期对照必须重新加载；若当前正停在该视图则立即重载
        host._same_period_loaded = False
        inner = getattr(host, 'online_inner_stack', None)
        if inner is not None and inner.currentIndex() == 1:
            ensure_same_period_loaded(host)

    @pyqtSlot(str, str)
    def on_worker_failed(self, title, detail):
        """抓取/解析/写库失败：摘要条与状态栏各一行，不弹窗、保留上次表格数据"""
        host = self._host
        url = getattr(host, '_online_last_url', '')
        if getattr(self, '_auto', False) and url:
            # 自动抓取最多尝试一次：同一 URL 本次运行内不再自动重试
            host._online_auto_failed.add(url)
        _set_online_summary(host, "%s：%s" % (title, detail), 'error')
        _set_online_warning(host, '')
        _clear_online_compare(host)
        _status_message(host, "%s：%s" % (title, detail), 6000)

    @pyqtSlot()
    def on_worker_cancelled(self):
        """抓取被取消：恢复到可再次抓取的状态"""
        host = self._host
        _set_online_summary(host, "已取消：抓取已取消", 'warn')
        _clear_online_compare(host)

    @pyqtSlot()
    def on_thread_finished(self):
        """线程结束：恢复按钮、清空引用（此时才放开下一次抓取）"""
        host = self._host
        host._online_busy = False
        host._online_thread = None
        host._online_worker = None
        self._set_busy_ui(False)
