# -*- coding: utf-8 -*-
"""
============================================================================
TAB/same_period_view.py - 「同期对照」视图（在线开奖页的第二视图）
============================================================================
在架构中的位置：
    TAB/ 界面层。本模块**不声明 TAB_INFO**，因此不会被 TAB/__init__.py 的
    自动发现注册成第 15 个选项卡；只导出 build_same_period_view(host)，
    由 TAB/history.py 放进「在线开奖」页内部的视图堆栈（index 1）。

职责：
    1. 顶部筛选：年份 + 年内期号区间（默认整年）；
    2. 表格：同年同期号并排「在线库 / 本地历史」，差异单元格按状态标色；
    3. 空态：库不存在 / 库为空 / 库损坏 / 该年无记录 / 筛选无结果；
    4. 只读：本视图只读在线库与内存中的本地历史，不写任何数据库或文件。

数据来源：
    - 在线：lib/online_store.py 的只读查询（mode=ro，库不存在不会创建文件）；
    - 本地：host.historical_data（主窗口已加载的 JSON 数据，不写盘）。
    - 对齐：lib/same_period.py（按开奖日期对齐，期号取在线 source_period）。

性能：
    默认只渲染单年（≤366 期）；表格用整表委托绘制号码球，不创建任何子控件。
============================================================================
"""

from UI import (
    QAbstractItemView, QColor, QComboBox, QEvent, QFont, QHBoxLayout, QHeaderView,
    QLabel, QObject, QPainter, QPen, QPushButton, QRect, QSpinBox, QStackedWidget,
    QStyle, QStyledItemDelegate, QTableWidget, QTableWidgetItem, QTimer, QVBoxLayout,
    QWidget, Qt,
)
from lib import online_store
from lib.data_process import LotteryConfig
from lib.same_period import (
    STATUS_DIFF, STATUS_LOCAL_ONLY, STATUS_ONLINE_ONLY, STATUS_SAME,
    build_year_rows, filter_records, normalize_local_record, normalize_online_record,
    summarize_rows, year_stats,
)
from TAB.widgets import spin_style_qss

# 同期对照表头：期号/日期 + 在线 7 球 + 本地 7 球 + 状态
SAME_PERIOD_HEADERS = ['期号', '日期', '在线正码', '在线特别', '本地正码', '本地特别', '状态']
SAME_PERIOD_COL_WIDTHS = [100, 110, 190, 80, 190, 80, 110]
SAME_PERIOD_ROW_HEIGHT = 40

# 四类状态配色：亮/暗两套。正文与底色对比度 ≥4.5:1，边框沿用前景色（≥4.5:1）
STATUS_COLORS = {
    'light': {
        STATUS_SAME: {'bg': '#E8F5E9', 'fg': '#166534'},
        STATUS_ONLINE_ONLY: {'bg': '#E3F2FD', 'fg': '#0D47A1'},
        STATUS_LOCAL_ONLY: {'bg': '#FFF3E0', 'fg': '#8A5200'},
        STATUS_DIFF: {'bg': '#FFEBEE', 'fg': '#B71C1C'},
        'text': '#222233',
        'grid': '#8A8A8A',
        'muted': '#555555',
    },
    'dark': {
        STATUS_SAME: {'bg': '#1E3A2A', 'fg': '#81C995'},
        STATUS_ONLINE_ONLY: {'bg': '#1B2E4A', 'fg': '#8AB4F8'},
        STATUS_LOCAL_ONLY: {'bg': '#3A2A14', 'fg': '#FFB74D'},
        STATUS_DIFF: {'bg': '#3A1E1E', 'fg': '#FF8A80'},
        'text': '#E6E9F2',
        'grid': '#6E7A94',
        'muted': '#AAB2C8',
    },
}


def _tokens(host):
    """按当前主题返回颜色令牌"""
    return STATUS_COLORS['dark' if getattr(host, 'is_dark_mode', False) else 'light']


def _register_theme(host, widget, light_qss, dark_qss):
    """登记本视图需要随主题切换的内联样式（与历史页同一机制，独立命名空间）"""
    registry = getattr(host, '_same_period_theme_widgets', None)
    if registry is None:
        registry = []
        host._same_period_theme_widgets = registry
        host._same_period_theme_filter = _SamePeriodThemeSync(host)
        host.installEventFilter(host._same_period_theme_filter)
    registry.append((widget, light_qss, dark_qss))
    widget.setStyleSheet(dark_qss if getattr(host, 'is_dark_mode', False) else light_qss)


def _apply_theme(host):
    """主题切换后重新套用本视图控件样式并重绘表格"""
    for widget, light_qss, dark_qss in getattr(host, '_same_period_theme_widgets', ()):
        try:
            widget.setStyleSheet(dark_qss if getattr(host, 'is_dark_mode', False) else light_qss)
        except RuntimeError:
            pass
    table = getattr(host, 'same_period_table', None)
    if table is not None:
        try:
            table.viewport().update()
        except RuntimeError:
            pass


class _SamePeriodThemeSync(QObject):
    """监听主窗口 StyleChange（主题切换/字号重建）并回套本视图样式"""

    def __init__(self, host):
        super().__init__(host)
        self._host = host

    def eventFilter(self, obj, event):
        """只在宿主窗口 StyleChange 时动作，其他事件原样放行"""
        if obj is self._host and event.type() == QEvent.Type.StyleChange:
            QTimer.singleShot(0, lambda: _apply_theme(self._host))
        return False


class SamePeriodDelegate(QStyledItemDelegate):
    """同期对照整表委托：按行状态铺底色、绘制在线/本地号码球与状态徽标

    约束:
        不创建任何 QWidget；行数据统一存放在第 0 列的 UserRole。
    """

    BALL_SIZE = 22
    BALL_GAP = 4

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self._host = host

    def _row_data(self, index):
        """从第 0 列取整行数据（其余列不重复存）"""
        return index.model().index(index.row(), 0).data(Qt.ItemDataRole.UserRole) or {}

    def paint(self, painter, option, index):
        """按列类型绘制：0/1 文本，2–5 号码球，6 状态徽标"""
        row = self._row_data(index)
        if not row:
            super().paint(painter, option, index)
            return
        tokens = _tokens(self._host)
        status = row.get('status') or STATUS_ONLINE_ONLY
        status_token = tokens.get(status) or tokens[STATUS_ONLINE_ONLY]
        rect = QRect(option.rect)
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        if selected:
            background = option.palette.highlight().color()
            foreground = option.palette.highlightedText().color()
        else:
            background = QColor(status_token['bg'])
            foreground = QColor(tokens['text'])

        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.fillRect(rect, background)
        painter.setPen(QPen(QColor(tokens['grid']), 1))
        painter.drawRect(rect.adjusted(0, 0, -1, -1))

        column = index.column()
        if column in (2, 3):
            side = row.get('online')
            self._paint_numbers(painter, rect, side, only_special=(column == 3),
                                foreground=foreground)
        elif column in (4, 5):
            side = row.get('local')
            self._paint_numbers(painter, rect, side, only_special=(column == 5),
                                foreground=foreground)
        elif column == 6:
            self._paint_badge(painter, rect, row.get('label') or '', status_token, foreground)
        else:
            if column == 0:
                online = row.get('online')
                if online:
                    text = str(online.get('period') or row.get('seq_text') or '—')
                else:
                    text = '本地 #%s' % ((row.get('local') or {}).get('period') or '—')
            else:
                text = str(row.get('date') or '—')
            font = QFont(option.font)
            font.setPixelSize(15)
            painter.setFont(font)
            painter.setPen(QPen(foreground))
            painter.drawText(rect.adjusted(4, 0, -4, 0),
                             Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, text)
        painter.restore()

    def _paint_numbers(self, painter, rect, side, only_special, foreground):
        """绘制一侧的 7 个号码；该侧缺失时画居中破折号"""
        if not side:
            font = QFont()
            font.setPixelSize(15)
            painter.setFont(font)
            painter.setPen(QPen(foreground))
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, '—')
            return
        numbers = [int(side['special'])] if only_special else list(side['numbers'])
        count = len(numbers)
        total_width = count * self.BALL_SIZE + (count - 1) * self.BALL_GAP
        start_x = rect.x() + max(0, (rect.width() - total_width) // 2)
        top_y = rect.y() + (rect.height() - self.BALL_SIZE) // 2
        font = QFont()
        font.setBold(True)
        font.setPixelSize(14)
        painter.setFont(font)
        for offset, number in enumerate(numbers):
            colors = LotteryConfig.get_number_color(number)
            ball = QRect(start_x + offset * (self.BALL_SIZE + self.BALL_GAP),
                         top_y, self.BALL_SIZE, self.BALL_SIZE)
            painter.setPen(QPen(QColor(colors['border'])))
            painter.setBrush(QColor(colors['bg']))
            painter.drawEllipse(ball)
            painter.setPen(QPen(QColor(colors['text'])))
            painter.drawText(ball, Qt.AlignmentFlag.AlignCenter, str(number).zfill(2))

    def _paint_badge(self, painter, rect, label, status_token, foreground):
        """状态徽标：居中固定宽度圆角描边 + 加粗文字"""
        width = min(max(rect.width() - 20, 60), 88)
        badge = QRect(rect.x() + (rect.width() - width) // 2, rect.y() + 7, width, rect.height() - 14)
        painter.setPen(QPen(QColor(status_token['fg']), 1))
        painter.setBrush(QColor(status_token['bg']))
        painter.drawRoundedRect(badge, 6, 6)
        font = QFont()
        font.setBold(True)
        font.setPixelSize(15)
        painter.setFont(font)
        painter.setPen(QPen(QColor(status_token['fg'])))
        painter.drawText(badge, Qt.AlignmentFlag.AlignCenter, label)


def build_same_period_view(host):
    """构建「同期对照」视图页（不读库；首次切到该视图才载入数据）

    参数:
        host: 主窗口实例；控件挂到 host.same_period_* / _same_period_* 属性。

    返回:
        QWidget: 同期对照页控件。
    """
    page = QWidget()
    layout = QVBoxLayout(page)
    layout.setSpacing(4)
    layout.setContentsMargins(5, 2, 5, 2)

    # ---- 筛选行：年份 + 年内期号区间 + 刷新 + 汇总 ----
    toolbar = QHBoxLayout()
    toolbar.setSpacing(6)

    year_label = QLabel('年份:')
    _register_theme(host, year_label, 'color: #555555; font-size: 15px; font-weight: bold;',
                    'color: #AAB2C8; font-size: 15px; font-weight: bold;')
    toolbar.addWidget(year_label)

    host.same_period_year_combo = QComboBox()
    host.same_period_year_combo.setFixedWidth(100)
    host.same_period_year_combo.setStyleSheet('QComboBox { font-size: 15px; padding: 2px 6px; }')
    host.same_period_year_combo.setToolTip('选择要并排对照的年份')
    toolbar.addWidget(host.same_period_year_combo)

    seq_label = QLabel('期号:')
    _register_theme(host, seq_label, 'color: #555555; font-size: 15px; font-weight: bold;',
                    'color: #AAB2C8; font-size: 15px; font-weight: bold;')
    toolbar.addWidget(seq_label)

    host.same_period_seq_from = QSpinBox()
    host.same_period_seq_from.setRange(1, 9999)
    host.same_period_seq_from.setValue(1)
    host.same_period_seq_from.setFixedWidth(86)
    _register_theme(
        host, host.same_period_seq_from,
        spin_style_qss('QSpinBox', border_color='#90CAF9', bg='#FFFFFF', fg='#222233', height=30),
        spin_style_qss('QSpinBox', border_color='#2C3A5A', bg='#121722', fg='#E6E9F2', height=30))
    toolbar.addWidget(host.same_period_seq_from)

    dash = QLabel('–')
    _register_theme(host, dash, 'color: #555555; font-size: 15px;',
                    'color: #AAB2C8; font-size: 15px;')
    toolbar.addWidget(dash)

    host.same_period_seq_to = QSpinBox()
    host.same_period_seq_to.setRange(1, 9999)
    host.same_period_seq_to.setValue(366)
    host.same_period_seq_to.setFixedWidth(86)
    _register_theme(
        host, host.same_period_seq_to,
        spin_style_qss('QSpinBox', border_color='#90CAF9', bg='#FFFFFF', fg='#222233', height=30),
        spin_style_qss('QSpinBox', border_color='#2C3A5A', bg='#121722', fg='#E6E9F2', height=30))
    toolbar.addWidget(host.same_period_seq_to)

    host.same_period_refresh_btn = QPushButton('刷新')
    host.same_period_refresh_btn.setFixedSize(70, 28)
    _register_theme(
        host, host.same_period_refresh_btn,
        'QPushButton { background-color: #E3F2FD; color: #1565C0; border: 1px solid #90CAF9; '
        'border-radius: 6px; font-weight: bold; } QPushButton:hover { background-color: #BBDEFB; }',
        'QPushButton { background-color: #1B2233; color: #8AB4F8; border: 1px solid #2C3A5A; '
        'border-radius: 6px; font-weight: bold; } QPushButton:hover { background-color: #24304A; }')
    toolbar.addWidget(host.same_period_refresh_btn)

    toolbar.addStretch()

    host.same_period_summary_label = QLabel('尚未载入')
    _register_theme(host, host.same_period_summary_label,
                    'color: #555555; font-size: 15px;',
                    'color: #AAB2C8; font-size: 15px;')
    toolbar.addWidget(host.same_period_summary_label)
    layout.addLayout(toolbar)

    # ---- 表格 / 空态堆栈 ----
    host.same_period_stack = QStackedWidget()

    host.same_period_table = QTableWidget()
    host.same_period_table.setObjectName('SamePeriodTable')
    host.same_period_table.setColumnCount(len(SAME_PERIOD_HEADERS))
    host.same_period_table.setHorizontalHeaderLabels(SAME_PERIOD_HEADERS)
    host.same_period_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    host.same_period_table.horizontalHeader().setStretchLastSection(True)
    for index, width in enumerate(SAME_PERIOD_COL_WIDTHS):
        host.same_period_table.setColumnWidth(index, width)
    host.same_period_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    host.same_period_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    host.same_period_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    host.same_period_table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    host.same_period_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    host.same_period_table.verticalHeader().setVisible(False)
    host.same_period_table.verticalHeader().setDefaultSectionSize(SAME_PERIOD_ROW_HEIGHT)
    host.same_period_table.setWordWrap(False)
    host.same_period_table.setShowGrid(False)
    host.same_period_table.setItemDelegate(SamePeriodDelegate(host, host.same_period_table))
    _register_theme(host, host.same_period_table,
                    'QHeaderView { font-size: 15px; } QHeaderView::section { background-color: #FFFFFF; '
                    'color: #222233; border: 1px solid #8A8A8A; font-size: 15px; font-weight: bold; }',
                    'QHeaderView { font-size: 15px; } QHeaderView::section { background-color: #161C28; '
                    'color: #E6E9F2; border: 1px solid #6E7A94; font-size: 15px; font-weight: bold; }')
    host.same_period_stack.addWidget(host.same_period_table)

    empty_page = QWidget()
    empty_layout = QVBoxLayout(empty_page)
    empty_layout.addStretch()
    host.same_period_empty_label = QLabel('尚未载入')
    host.same_period_empty_label.setWordWrap(True)
    host.same_period_empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    _register_theme(host, host.same_period_empty_label,
                    'color: #555555; font-size: 16px; padding: 24px;',
                    'color: #AAB2C8; font-size: 16px; padding: 24px;')
    empty_layout.addWidget(host.same_period_empty_label)
    empty_layout.addStretch()
    host.same_period_stack.addWidget(empty_page)
    layout.addWidget(host.same_period_stack, 1)

    # ---- 图例 / 口径说明：明确“只读、不写” ----
    host.same_period_legend_label = QLabel(
        '状态标色：一致（绿）· 仅在线有（蓝）· 仅本地有（橙）· 值不同（红）。'
        '本视图只读在线库与本地历史，不写入任何数据库或文件。')
    host.same_period_legend_label.setWordWrap(True)
    _register_theme(host, host.same_period_legend_label,
                    'color: #555555; font-size: 15px;',
                    'color: #AAB2C8; font-size: 15px;')
    layout.addWidget(host.same_period_legend_label)

    host.same_period_note_label = QLabel(
        '对齐口径：按开奖日期对齐；本地 period 不是源站期号，同期号取在线记录的「年份 + 年内序号」。')
    host.same_period_note_label.setWordWrap(True)
    _register_theme(host, host.same_period_note_label,
                    'color: #555555; font-size: 15px;',
                    'color: #AAB2C8; font-size: 15px;')
    layout.addWidget(host.same_period_note_label)

    # ---- 状态与信号 ----
    host._same_period_loaded = False
    host._same_period_filter_timer = QTimer(host)
    host._same_period_filter_timer.setSingleShot(True)
    host._same_period_filter_timer.timeout.connect(lambda: load_same_period(host))
    host.same_period_year_combo.currentIndexChanged.connect(
        lambda index: load_same_period(host) if index >= 0 else None)
    host.same_period_seq_from.valueChanged.connect(lambda value: host._same_period_filter_timer.start(300))
    host.same_period_seq_to.valueChanged.connect(lambda value: host._same_period_filter_timer.start(300))
    host.same_period_refresh_btn.clicked.connect(lambda: load_same_period(host))
    return page


def ensure_same_period_loaded(host):
    """首次切到同期对照视图时载入；已载入则不重复读库"""
    if not getattr(host, '_same_period_loaded', False):
        load_same_period(host)


def _set_empty(host, text):
    """显示空态文案并切到空态页"""
    label = getattr(host, 'same_period_empty_label', None)
    stack = getattr(host, 'same_period_stack', None)
    if label is not None:
        label.setText(text)
    if stack is not None:
        stack.setCurrentIndex(1)


def _set_summary(host, text):
    """更新顶部汇总文案"""
    label = getattr(host, 'same_period_summary_label', None)
    if label is not None:
        label.setText(text)


def _fill_years(host, years):
    """把年份列表写入下拉框（阻塞信号，避免载入过程中递归触发）"""
    combo = getattr(host, 'same_period_year_combo', None)
    if combo is None:
        return
    current = combo.currentData()
    combo.blockSignals(True)
    combo.clear()
    for year in years:
        combo.addItem(str(year), int(year))
    if current is not None and current in years:
        combo.setCurrentIndex(years.index(current))
    elif years:
        combo.setCurrentIndex(0)
    combo.blockSignals(False)


def load_same_period(host):
    """读取在线数据（内存会话优先，其次只读在线库）+ 本地历史并重建同期对照表

    参数:
        host: 主窗口实例。

    返回:
        dict: {'ok': bool, 'rows': int, 'elapsed_ms': float, 'state': str}。
            state 取值：db_missing / db_broken / db_empty / no_rows / ok。

    说明:
        自动抓取按零写入口径只把结果放内存（_online_mode == 'session'），
        此时同期对照直接使用这批会话记录，因此“抓取后切到同期对照”能看到新行；
        会话记录为空时才回落到只读在线库。
    """
    import time
    started = time.perf_counter()
    first_load = not getattr(host, '_same_period_loaded', False)

    session_records = list(getattr(host, '_online_records_session', None) or [])
    use_session = bool(session_records) and getattr(host, '_online_mode', '') == 'session'
    if use_session:
        online_years = sorted({int(record['year'])
                               for record in filter_records(session_records, normalize_online_record)[0]},
                              reverse=True)
    else:
        probe = online_store.probe_store()
        if not probe['exists']:
            _set_summary(host, '库不存在')
            _set_empty(host, '在线开奖库不存在。请先在「在线列表」抓取一次数据，或使用历史数据回填工具。')
            return {'ok': False, 'rows': 0, 'elapsed_ms': (time.perf_counter() - started) * 1000.0,
                    'state': 'db_missing'}
        if not probe['ok']:
            _set_summary(host, '读取失败')
            _set_empty(host, '读取在线库失败：%s。本页不会写入或修复数据库。' % (probe['error'] or '未知原因'))
            return {'ok': False, 'rows': 0, 'elapsed_ms': (time.perf_counter() - started) * 1000.0,
                    'state': 'db_broken'}
        if probe['count'] <= 0:
            _set_summary(host, '库为空')
            _set_empty(host, '在线库为空（0 期）。同期对照至少需要今年 1 期 + 任意 1 个历史年。')
            return {'ok': False, 'rows': 0, 'elapsed_ms': (time.perf_counter() - started) * 1000.0,
                    'state': 'db_empty'}
        online_years = [int(item['year']) for item in online_store.fetch_years()]

    local_valid, local_anomalies = filter_records(
        getattr(host, 'historical_data', []) or [], normalize_local_record)
    combo = getattr(host, 'same_period_year_combo', None)
    online_years = [int(item['year']) for item in online_store.fetch_years()]
    year_list = sorted(set(online_years) | {int(record['date'][:4]) for record in local_valid},
                       reverse=True)
    if not year_list:
        _set_summary(host, '无年份')
        _set_empty(host, '在线库没有可识别的年份记录，请重新抓取或检查库内容。')
        return {'ok': False, 'rows': 0, 'elapsed_ms': (time.perf_counter() - started) * 1000.0,
                'state': 'no_rows'}
    _fill_years(host, year_list)
    if first_load and combo is not None:
        combo.blockSignals(True)
        combo.setCurrentIndex(0)
        combo.blockSignals(False)
    year = int(combo.currentData()) if combo is not None and combo.currentData() is not None \
        else year_list[0]

    if use_session:
        online_raw = [row for row in session_records
                      if str((row or {}).get('draw_date') or '')[:4] == str(year)]
    else:
        online_raw = online_store.fetch_year_records(year)
    online_valid, online_anomalies = filter_records(online_raw, normalize_online_record)
    online_valid = [record for record in online_valid if record['year'] == year]
    stats = year_stats(online_valid, year)

    year_changed = getattr(host, '_same_period_year', None) != year
    host._same_period_year = year
    spin_from = host.same_period_seq_from
    spin_to = host.same_period_seq_to
    if stats['min_seq'] is not None and (year_changed or first_load):
        low, high = stats['min_seq'], stats['max_seq']
        for spin in (spin_from, spin_to):
            spin.blockSignals(True)
            spin.setRange(1, max(high, 1))
        spin_from.setValue(low)
        spin_to.setValue(high)
        for spin in (spin_from, spin_to):
            spin.blockSignals(False)
        from_index, to_index = low, high
    else:
        from_index, to_index = spin_from.value(), spin_to.value()

    rows = build_year_rows(online_valid, local_valid, year, from_index, to_index)

    anomalies = len([a for a in online_anomalies if 'prefix year' in str(a.get('reason'))])
    anomaly_text = '；已隔离 %d 条异常记录（期号年份与开奖日期不一致）' % anomalies if anomalies else ''
    local_text = '本地历史 %d 条' % len(local_valid)
    local_anomaly_text = ('；本地异常 %d 条（日期/期号/号码不合法，未参与对照）'
                          % len(local_anomalies)) if local_anomalies else ''
    if not rows:
        _set_summary(host, '无匹配记录')
        if stats['count'] == 0 and not local_valid:
            _set_empty(host, '在线库中没有 %d 年记录，本地历史也没有该年数据。请切换年份，或先在「在线列表」抓取。'
                       % year + local_anomaly_text)
        else:
            _set_empty(host, '该年份在所选期号区间（%d–%d）内没有可对照的记录。请放宽区间或点「刷新」。'
                       % (from_index, to_index) + local_anomaly_text)
        return {'ok': False, 'rows': 0, 'elapsed_ms': (time.perf_counter() - started) * 1000.0,
                'state': 'no_rows'}

    render_same_period_rows(host, rows)
    counts = summarize_rows(rows)
    summary = '共 %d 行：一致 %d · 仅在线有 %d · 仅本地有 %d · 值不同 %d · %s%s%s' % (
        counts['total'], counts[STATUS_SAME], counts[STATUS_ONLINE_ONLY],
        counts[STATUS_LOCAL_ONLY], counts[STATUS_DIFF], local_text, anomaly_text,
        local_anomaly_text)
    _set_summary(host, summary)
    host.same_period_stack.setCurrentIndex(0)
    # 只有成功渲染出表格才记为“已载入”；库缺失/为空时下次切回本视图会重新尝试
    host._same_period_loaded = True
    return {'ok': True, 'rows': len(rows),
            'elapsed_ms': (time.perf_counter() - started) * 1000.0, 'state': 'ok'}


def render_same_period_rows(host, rows):
    """把同期对照行渲染进表格（整表委托，不创建子控件）

    参数:
        host: 主窗口实例；
        rows (list[dict]): build_year_rows 的返回值。
    """
    table = getattr(host, 'same_period_table', None)
    if table is None:
        return
    table.setUpdatesEnabled(False)
    try:
        table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column in range(len(SAME_PERIOD_HEADERS)):
                item = QTableWidgetItem('')
                if column == 0:
                    item.setData(Qt.ItemDataRole.UserRole, row)
                table.setItem(row_index, column, item)
    finally:
        table.setUpdatesEnabled(True)
