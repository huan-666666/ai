# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/widgets.py - 选项卡共享 UI 控件库（非页面模块）
===========================================================================
模块职责：
    集中实现多个选项卡页面复用的 Qt 控件与字体工具，避免各页面重复实现号码按钮、
    号码面板、统计图表与表格代理。本文件只负责展示与交互，不包含任何业务算法，
    也不直接读写开奖数据。

在架构中的位置：
    位于界面层 TAB/ 的公共底座：
        - 向上被 TAB/ 各页面与 plugins/彩票预测.py 复用；
        - 向下只依赖 UI/UI.py 统一导出的 Qt 控件（QWidget/QColor/QFont/...）、
          lib/data_process.LotteryConfig（号码颜色与字号/按钮尺寸上限）、
          lib/math_algo（numpy 与 scipy.stats 懒加载）、
          lib/plot_draw（matplotlib Figure/Canvas/pyplot 与 seaborn 模块访问器）。
    数据流位置：各页面从 lib 取到开奖数据 → 创建本文件控件并填充号码/生肖/五行
    → 控件展示并收集交互 → 通过 pyqtSignal 或回调把结果回抛给页面处理。

为什么不会被当作选项卡加载：
    TAB/__init__.py 的 iter_tab_pages() 明确跳过文件名为 widgets 的公共模块，
    本文件因此不声明 TAB_INFO，也不导出 install(host)/build(host)。

包含对象：
    FontUtils                      字体族探测缓存与 QFont 构造（含 15px 字号下限）
    CORNER_* 常量与 make_corner_*  各页右上角「数字/文字/尺寸」控件组的统一规格（v0.0.36）
    NumberButton                   号码球形按钮（按号码颜色着色、可勾选）
    NumberBallWithZodiac           号码球 + 生肖 + 五行标签的组合控件
    NumberPanel                    7×7 数字选择面板，发出 number_selected(list)
    ElementGridPanel               7×7 数字 + 五行文字面板
    ZodiacNumberPanel              7×7 数字 + 生肖文字面板，发出 number_clicked(int)
    AttributeMatrixPanel           12×5 属性矩阵（号码 + 生肖/五行胶囊），发出 number_clicked(int)
    ZodiacHighlightBar             矩阵上方的 12 生肖高亮条，发出 zodiac_selected(str)
    StatisticsChart                matplotlib 统计图表控件
    PreserveColorDelegate          表格项委托：选中行时保留彩色前景色

被复用位置：
    TAB/number_selection.py（NumberPanel 与角控件组）、TAB/prediction.py
    （NumberBallWithZodiac/NumberButton/角控件组/PreserveColorDelegate）、
    TAB/zodiac.py（ZodiacNumberPanel/角控件组/PreserveColorDelegate）、
    TAB/element.py（ElementGridPanel/角控件组）、TAB/statistics_chart.py
    （StatisticsChart）、TAB/history.py、TAB/backtest.py、TAB/prediction_history.py
    （PreserveColorDelegate）、TAB/bigdata_analysis.py（NumberBallWithZodiac）
    以及 plugins/彩票预测.py（FontUtils/NumberButton）。

约束：
    - Qt 类统一从 UI/UI.py 导入，禁止直接 import PyQt；
    - 禁止直接 import numpy/scipy/matplotlib，统一经 lib 的访问器获取；
    - 样式表中字号不得低于 15px，按钮与角控件高度不得突破 CORNER_HEIGHT 约定。
===========================================================================
"""

import os as _os_boot  # 作用说明：启动阶段用最短依赖定位项目根目录，把根目录插入 sys.path 以支持直接运行本文件调试
import sys as _sys_boot  # 作用说明：配合 os 别名导入，仅在直接运行本文件时把项目根目录加入模块搜索路径

# 允许「直接运行本文件」调试：把项目根目录加入模块搜索路径。
# 用 _os_boot/_sys_boot 别名导入，避免污染本模块命名空间（本文件已有同名 os/sys 语义需求）。
# 正常作为 TAB.widgets 被页面导入时，项目根目录已在 sys.path，此分支不会执行。
_ROOT = _os_boot.path.dirname(_os_boot.path.dirname(_os_boot.path.abspath(__file__)))
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)
from UI import (QApplication, QBrush, QColor, QDialog, QEvent, QFont, QFontDatabase, QFontMetrics, QGridLayout, QHBoxLayout, QLabel, QPainter, QPalette, QPen, QPushButton, QRect, QScrollArea, QSize, QSizePolicy, QSpinBox, QStyle, QStyleOptionFocusRect, QStyledItemDelegate, QVBoxLayout, QWidget, Qt, pyqtSignal)  # 作用说明：统一从 UI/UI.py 导入 Qt 控件、布局、事件类与 pyqtSignal，避免本包直接依赖 PyQt6（QScrollArea 用于卡区纵向滚动、表头保持固定；QEvent 供 H54 暗色标签随主题切换刷新）
from lib.data_process import LotteryConfig  # 作用说明：读取号码颜色、字号档位、按钮/角控件尺寸上限与生肖五行默认绑定等全局展示配置
from lib.math_algo import _get_scipy_stats, get_numpy  # 作用说明：懒加载 numpy 并取 scipy.stats 模块，供统计图表的矩阵运算与正态拟合使用
from lib.plot_draw import _get_mpl, get_figure_module, get_canvas_class, get_pyplot_module, get_seaborn_module  # 作用说明：matplotlib/seaborn 懒加载入口，为 StatisticsChart 提供 Figure、Canvas 与绘图模块
# 生肖页统一版表头需要渐变、圆角路径与浮点几何；本轮 UI/UI.py 属受保护文件不可改，
# 因此仅在本文件局部补充这几个绘图类（其余 Qt 类仍统一从 UI 导入）。
from PyQt6.QtGui import QLinearGradient, QPainterPath, QPixmap, QPolygon  # 作用说明：表头渐变/圆角路径，以及字号数字框箭头图标（QPixmap/QPolygon 运行时生成）
from PyQt6.QtCore import QRectF, QPointF, QPoint, QRect  # 作用说明：浮点矩形、绘制锚点与箭头多边形顶点
from PyQt6.QtWidgets import QToolTip  # 作用说明：表头悬停显示生肖号码提示

# FontUtils
class FontUtils:
    """
    字体工具类 - 全局字体族探测与 QFont 构造

    职责：
        - 按 FONT_FAMILIES 的优先级，从系统已安装字体中挑出第一个可用字体族；
        - 按 LotteryConfig.FONT_SIZES 的字号档位（如 '二号'）构造 QFont，
          并强制套用全局最小 15px、最大 TEXT_MAX_PX 的约束。

    关键属性：
        FONT_FAMILIES       类级常量，字体优先级列表（中文优先微软雅黑/黑体/苹方，
                            再回退 Segoe UI/Arial 等西文字体）
        _cached_font_family 类级缓存，首次探测后写死结果，避免各控件反复查询
                            QFontDatabase.families()（该调用在 Windows 上较慢）

    生命周期：
        纯类方法，调用方无需实例化；缓存在进程内一直有效，运行期间即使安装新字体
        也不会重新探测，需重启程序才生效。

    约束：
        本类不涉及 Qt 控件创建，只返回 QFont 对象，调用方负责把它 setFont 到控件。

    【可改】如需添加新字体，在 FONT_FAMILIES 列表中按优先级添加
    """
    
    # v0.0.48：按要求改为 Windows 自带字体栈，不引入任何需下载的字体文件。
    # 顺序：微软雅黑 → 黑体 → 宋体；最后用 Arial 兜底（所有 Windows 版本均自带）。
    FONT_FAMILIES = ['Microsoft YaHei', 'SimHei', 'SimSun', 'Arial']

    # 字体族检测结果缓存：避免窗口缩放时 resizeEvent 反复查询系统字体库
    _cached_font_family = None

    @classmethod
    def get_default_font_family(cls):
        """获取系统可用的首选字体族（带进程级缓存）

        功能:
            获取系统可用的首选字体族（带进程级缓存）

        参数:
            无

        返回:
            str: FONT_FAMILIES 中第一个系统已安装的字体族名；全部不可用时返回 'Arial'。

        副作用:
            首次调用写入 cls._cached_font_family，后续调用直接命中缓存，
            不再查询系统字体库。缓存对 FontUtils 的所有子类/调用方共享。

        说明:
            PyQt6 6.x 中 QFontDatabase 为静态类，禁止实例化，直接调用静态方法 families()；
            若实例化会触发运行时告警或异常。
        """
        if cls._cached_font_family is not None:
            return cls._cached_font_family
        available_families = QFontDatabase.families()
        for family in cls.FONT_FAMILIES:
            if family in available_families:
                cls._cached_font_family = family
                return family
        cls._cached_font_family = 'Arial'
        return 'Arial'
    
    @classmethod
    def create_font(cls, size_key='二号', bold=False, italic=False):
        """创建配置好的 QFont 对象

        功能:
            创建配置好的 QFont 对象

        参数:
            size_key (str): LotteryConfig.FONT_SIZES 的字号档位键（如 '二号'、'小四'）；
                键不存在时回退 TEXT_DEFAULT_PX。
            bold (bool): 是否加粗。
            italic (bool): 是否斜体。

        返回:
            QFont: 已设置字体族、字号（15px 下限与 TEXT_MAX_PX 上限）、粗体/斜体属性的字体。

        副作用:
            首次调用会触发字体族探测并写入 FontUtils._cached_font_family。
        """
        font_family = cls.get_default_font_family()
        # 先按档位查表并钳到全局最大字号，避免配置里出现超大字号撑破控件
        font_size = min(LotteryConfig.FONT_SIZES.get(size_key, LotteryConfig.TEXT_DEFAULT_PX),
                        LotteryConfig.TEXT_MAX_PX)
        # v0.0.36 硬性下限：所有文字最小 15px，防止过小看不清
        font_size = max(15, font_size)
        font = QFont(font_family, font_size)
        # v0.0.48：正文至少 Medium 字重，标题/号码等由调用方传 bold=True 走 Bold；
        # Qt 的 QFont 字重必须显式设置，只改 QSS 的 font-weight 对 setFont 不生效。
        # 注意：非粗体时不能调用 setBold(False)，它会把字重重置回 Normal(400)。
        if bold:
            font.setWeight(QFont.Weight.Bold)
            font.setBold(True)
        else:
            font.setWeight(QFont.Weight.Medium)
        font.setItalic(italic)
        return font


# 选项卡右上角「数字 / 文字 / 尺寸」控件组（v0.0.36 统一规格）
# 四个页面（数字与生肖、数字与五行、数字选择、预测与抽取）共用同一套尺寸与样式：
#   - 控件高度统一 40px，全部按 AlignVCenter 加入容器，保证同一条水平基线；
#   - 组内间距 6px，数字/文字两组之间留 12px，容器右侧留 8px，避免贴边拥挤；
#   - 字号统一 15px（满足全局最小字号要求）。
CORNER_HEIGHT = 40          # 控件统一高度（px），标签 / 数字框 / 按钮同高
CORNER_SPACING = 6          # 组内相邻控件间距（px）
CORNER_SECTION_GAP = 12     # 「数字」组与「文字」组之间的留白（px）
CORNER_RIGHT_MARGIN = 8     # 控件组距选项卡右边缘的留白（px），避免贴边
CORNER_SPIN_WIDTH = 80      # 数字框宽度（px），可显示「150 px」
CORNER_BUTTON_WIDTH = 68    # 「尺寸」按钮宽度（px），可容纳两个中文字

# 字号数字框统一规格（v0.0.49）
# 所有字号/尺寸类 QSpinBox（角控件组、面板尺寸弹窗、显示设置抽屉、暗色输入框）
# 都从这里取同一套 padding / 高度 / 上下按钮定位，禁止各页面再各写一份 QSS。
# 数值全部取 4 的倍数：100% 为整数，125% 与 150% 时也不会落到半像素上。
SPIN_HEIGHT = 40            # 控件高度（px）；40 → 125% 为 50、150% 为 60
SPIN_PADDING_LEFT = 8       # 数字距左边框（px），≥6 的要求
SPIN_PADDING_RIGHT = 24     # 右侧留给上下按钮（18px）后再留 6px，数字不压箭头
SPIN_ARROW_WIDTH = 18       # 上下按钮宽（px）
SPIN_ARROW_HEIGHT = 18      # 单个箭头按钮高（px）；18+18=36 ≤ 内容净高 38
SPIN_FONT_PX = 15           # 数字框字号（px），项目硬约束 ≥15
SPIN_RADIUS = 4             # 圆角（px）

# 箭头图标缓存：{颜色: (up_path, down_path)}，同一主题色只生成一次
_SPIN_ARROW_CACHE = {}


def _spin_arrow_paths(color):
    """按颜色生成上下三角箭头 PNG（缓存到系统临时目录）

    功能:
        QSS 的 image:url 只能引用文件；Qt 内置箭头只有黑色，暗色主题下对比度低。
        这里用 QPainter 按实际主题色画 12×12 的三角箭头并写入临时目录，供亮/暗
        两套主题共用，避免往项目里新增图片资源。
    参数:
        color (str): 箭头颜色，形如 '#333333' / '#CDD6F4'。
    返回:
        tuple[str, str]: (上箭头路径, 下箭头路径)；生成失败时返回 ('', '')。
    """
    if QApplication.instance() is None:
        # 模块导入期（早于 QApplication）不得创建 QPixmap，退回内置黑色箭头
        return ('', '')
    if color in _SPIN_ARROW_CACHE:
        return _SPIN_ARROW_CACHE[color]
    import tempfile  # 作用说明：图标写到系统临时目录，不污染项目与数据目录
    safe = ''.join(ch for ch in color if ch.isalnum() or ch in '#') or 'default'
    base = _os_boot.path.join(tempfile.gettempdir(), 'lhc_ui_arrows')
    up_path = _os_boot.path.join(base, 'up_' + safe + '.png')
    down_path = _os_boot.path.join(base, 'dn_' + safe + '.png')
    try:
        _os_boot.makedirs(base, exist_ok=True)
        # 上箭头：顶点朝上；下箭头：顶点朝下。留 1px 边距，避免贴边被裁。
        polys = {
            up_path: [QPoint(1, 9), QPoint(11, 9), QPoint(6, 2)],
            down_path: [QPoint(1, 3), QPoint(11, 3), QPoint(6, 10)],
        }
        for path, pts in polys.items():
            pm = QPixmap(12, 12)
            pm.fill(Qt.GlobalColor.transparent)
            p = QPainter(pm)
            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(QColor(color)))
            p.drawPolygon(QPolygon(pts))
            p.end()
            if not pm.save(path):
                return ('', '')
        _SPIN_ARROW_CACHE[color] = (up_path, down_path)
        return _SPIN_ARROW_CACHE[color]
    except Exception:
        return ('', '')


def spin_style_qss(selector='QSpinBox', border_color='#90CAF9', bg='#FFFFFF',
                   fg='#333333', height=None, radius=SPIN_RADIUS,
                   font_px=SPIN_FONT_PX, arrow_color=None, focus_border=None,
                   arrow_w=None, arrow_h=None):
    """生成字号数字框的统一 QSS（唯一来源）

    功能:
        统一「内边距 ≥6px、右侧给箭头留位、上下按钮分别定位、箭头按主题取色、
        高度按字体行高 + 上下留白」的 QSS，供所有字号/尺寸类数字框复用。
    参数:
        selector (str): QSS 选择器，默认 'QSpinBox'；抽屉里传
            '#DisplayDrawerFrame QSpinBox' 以并入全局样式表。
        border_color (str): 边框颜色。
        bg (str): 背景色；抽屉里传 'transparent' 以透出卡片底色。
        fg (str): 文字颜色。
        height (int | None): 控件高度；None 用 SPIN_HEIGHT（40）。调用方须保证
            height ≥ QFontMetrics.height() + 上下留白 4px。
        radius (int): 圆角。
        font_px (int): 字号（px），不得低于 15。
        arrow_color (str | None): 箭头颜色，None 时跟随 fg。
        focus_border (str | None): 聚焦边框色，None 时用 border_color。
    返回:
        str: 可直接 setStyleSheet 的样式串。
    """
    h = int(height or SPIN_HEIGHT)
    aw = int(arrow_w or SPIN_ARROW_WIDTH)
    ah = int(arrow_h or SPIN_ARROW_HEIGHT)
    if ah * 2 > h - 2:
        # 控件变矮时按内容高度自动收窄按钮，保证上下两个箭头永远不叠置
        ah = max(10, (h - 2) // 2)
    content_h = max(1, h - 2)  # QSS 的 height 是内容盒高，1px 边框在外侧；实际控件高 = h
    arrow = arrow_color or fg or '#333333'
    up_img, dn_img = _spin_arrow_paths(arrow)
    if up_img:
        up_url = up_img.replace('\\', '/')
        dn_url = dn_img.replace('\\', '/')
    else:
        # 临时目录不可写时退回 Qt 内置黑色箭头，至少保证能看到、能点
        up_url = ':/qt-project.org/styles/commonstyle/images/arrow-up-16.png'
        dn_url = ':/qt-project.org/styles/commonstyle/images/arrow-down-16.png'
    focus = focus_border or border_color
    return (
        "%s { background-color: %s; color: %s; border: 1px solid %s; border-radius: %dpx;"
        " padding: 0px %dpx 0px %dpx; min-height: %dpx; max-height: %dpx; font-size: %dpx; }"
        "%s:focus { border-color: %s; }"
        "%s::up-button { subcontrol-origin: border; subcontrol-position: top right;"
        " width: %dpx; height: %dpx; background: transparent; border: none;"
        " border-left: 1px solid %s; }"
        "%s::down-button { subcontrol-origin: border; subcontrol-position: bottom right;"
        " width: %dpx; height: %dpx; background: transparent; border: none;"
        " border-left: 1px solid %s; border-top: 1px solid %s; }"
        "%s::up-arrow { image: url(%s); width: 12px; height: 12px; }"
        "%s::down-arrow { image: url(%s); width: 12px; height: 12px; }"
    ) % (
        selector, bg, fg, border_color, radius,
        SPIN_PADDING_RIGHT, SPIN_PADDING_LEFT, content_h, content_h, font_px,
        selector, focus,
        selector, aw, ah, border_color,
        selector, aw, ah, border_color, border_color,
        selector, up_url,
        selector, dn_url,
    )


def apply_spin_style(spin, border_color='#90CAF9', bg='#FFFFFF', fg='#333333',
                     height=None, font_px=SPIN_FONT_PX, arrow_color=None,
                     focus_border=None, fixed_width=None, arrow_w=None, arrow_h=None):
    """把统一数字框样式与几何一次性套到 QSpinBox

    功能:
        统一设置上下箭头模式、固定高度（4 的倍数）、内边距与箭头定位；
        避免各页面「只写宽高导致上下按钮叠置」的老问题复发。
    参数:
        spin (QSpinBox): 目标数字框。
        border_color / bg / fg / height / font_px / arrow_color / focus_border:
            同 spin_style_qss()。
        fixed_width (int | None): 需要固定宽度时传入（调用方保证 4 的倍数）。
    返回:
        QSpinBox: 原对象，便于链式调用。
    """
    spin.setButtonSymbols(QSpinBox.ButtonSymbols.UpDownArrows)
    spin.setFixedHeight(int(height or SPIN_HEIGHT))
    if fixed_width:
        spin.setFixedWidth(int(fixed_width))
    spin.setStyleSheet(spin_style_qss('QSpinBox', border_color=border_color, bg=bg,
                                      fg=fg, height=height, font_px=font_px,
                                      arrow_color=arrow_color, focus_border=focus_border,
                                      arrow_w=arrow_w, arrow_h=arrow_h))
    return spin


def make_corner_container():
    """创建右上角控件组容器：固定 40px 高，右侧留 8px，内部垂直居中对齐

    功能:
        创建右上角控件组容器：固定 40px 高，右侧留 8px，内部垂直居中对齐

    参数:
        无。

    调用方:
        各选项卡在 install(host)/build(host) 中创建标题行时调用，随后用
        add_corner_widget() 依次放入标签、数字框与「尺寸」按钮。

    返回:
        tuple[QWidget, QHBoxLayout]:
            [0] 容器控件（已被设置为该布局的父控件）
            [1] 水平布局（调用方继续 addWidget/addStretch）

    副作用:
        无全局状态修改；仅创建 Qt 对象。容器高度被固定，父布局不会再把它拉伸。
    """
    box = QWidget()
    box.setFixedHeight(CORNER_HEIGHT)  # 固定组高：四个页面按钮基线一致
    layout = QHBoxLayout(box)
    layout.setContentsMargins(0, 0, CORNER_RIGHT_MARGIN, 0)  # 右侧 8px：不贴选项卡边缘
    layout.setSpacing(CORNER_SPACING)                         # 组内间距 6px：紧凑但不拥挤
    return box, layout


def make_corner_label(text, color):
    """创建控件组标签（「数字:」「文字:」），15px 加粗、垂直居中

    功能:
        创建控件组标签（「数字:」「文字:」），15px 加粗、垂直居中

    参数:
        text (str): 标签文字，通常为「数字:」或「文字:」。
        color (str): 文字颜色，形如 '#1565C0'；沿用各页现有主题色，用于区分两组控件。

    返回:
        QLabel: 固定 40px 高、垂直居中的标签，已内置 15px 加粗样式。

    副作用:
        仅设置新建 QLabel 的自身属性与样式表，不影响全局样式。
    """
    label = QLabel(text)
    label.setFixedHeight(CORNER_HEIGHT)  # 与数字框、按钮同高，避免基线错位
    label.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
    label.setStyleSheet(
        "QLabel {"
        "font-size: 15px; /* 字号：15px，满足最小字号要求 */"
        "color: %s; /* 文字颜色：本组主题色，区分数字/文字两组 */"
        "font-weight: bold; /* 文字加粗：与输入框内容区分 */"
        "background: transparent; /* 背景透明：融入标题行，不遮挡卡片底色 */"
        "}" % color
    )
    return label


def style_corner_spin(spin, border_color):
    """统一样式化字号输入框：80×40、15px 字、内容不贴边

    功能:
        统一样式化字号输入框：80×40、15px 字、内容不贴边

    参数:
        spin (QSpinBox): 已由页面创建的输入框实例；取值范围、当前值与 valueChanged
            信号由各页自行设置，本函数只负责外观。
        border_color (str): 边框颜色，形如 '#1565C0'；数字组用蓝色、文字组用紫色，
            沿用各页主题色。

    返回:
        QSpinBox: 原样返回传入的 spin，便于链式使用。

    副作用:
        固定控件尺寸为 80×40，并覆盖其样式表（会丢弃此前设置的其他样式）。
    """
    # 统一规格：40px 高（40 → 125% 为 50、150% 为 60，不落半像素），
    # 左内边距 8px、右侧 24px 给上下箭头留位；上下按钮分别定位，禁止叠置。
    apply_spin_style(spin, border_color=border_color, bg='#FFFFFF', fg='#333333',
                     height=CORNER_HEIGHT, font_px=SPIN_FONT_PX,
                     arrow_color='#333333', fixed_width=CORNER_SPIN_WIDTH)
    return spin


def make_corner_size_button(callback, tooltip):
    """创建统一样式的「尺寸」按钮：68×40、紫色主题、文字不贴边

    功能:
        创建统一样式的「尺寸」按钮：68×40、紫色主题、文字不贴边

    参数:
        callback (callable): 无参点击回调，各页传入打开尺寸设置对话框的方法。
        tooltip (str): 悬停提示文字，说明该按钮会调整哪些控件尺寸。

    返回:
        QPushButton: 固定尺寸的「尺寸」按钮，clicked 信号已连接到 callback。

    副作用:
        建立信号连接；按钮被点击时会执行 callback，通常进而修改页面控件的
        宽高/字号并触发重绘。
    """
    btn = QPushButton("尺寸")
    btn.setToolTip(tooltip)
    btn.setFixedSize(CORNER_BUTTON_WIDTH, CORNER_HEIGHT)  # 68×40：与其他控件同一基线
    # 手型光标是跨平台的可点击性提示；四个页面统一使用，避免某些页像静态文字
    btn.setCursor(Qt.CursorShape.PointingHandCursor)      # 悬停显示手型，提示可点击
    btn.setStyleSheet(
        "QPushButton {"
        "background-color: #F3E5F5; /* 默认背景：淡紫色，表示配置类操作 */"
        "color: #6A1B9A; /* 默认文字：深紫色 */"
        "border: 1px solid #CE93D8; /* 边框：1px 实线浅紫色 */"
        "border-radius: 6px; /* 圆角：6px */"
        "font-weight: bold; /* 文字加粗 */"
        "font-size: 15px; /* 字号：15px，满足最小字号要求 */"
        "padding: 0px 10px; /* 内边距：上下 0px、左右 10px，拉开文字与边框距离 */"
        "min-height: 38px; /* 内容最小高 38px：加上下 1px 边框后实际 40px */"
        "max-height: 38px; /* 内容最大高 38px：锁定实际 40px，避免全局 min-height:30px 撑高 */"
        "}"
        "QPushButton:hover {"
        "background-color: #E1BEE7; /* 悬停背景：比默认稍深的淡紫 */"
        "}"
        "QPushButton:pressed {"
        "background-color: #CE93D8; /* 按下背景：与边框同色，反馈更明显 */"
        "}"
    )
    btn.clicked.connect(callback)
    return btn


def add_corner_widget(layout, widget):
    """把控件按垂直居中方式加入控件组，保证同排基线完全一致

    功能:
        把控件按垂直居中方式加入控件组，保证同排基线完全一致

    参数:
        layout (QHBoxLayout): make_corner_container() 返回的水平布局。
        widget (QWidget): 待加入的标签、数字框或按钮。

    返回:
        None

    副作用:
        修改传入布局的控件顺序；控件自身尺寸/样式不变。

    说明:
        统一用 AlignVCenter（而不是依赖各自 height），即使某个控件未来高度变化，
        也不会与 40px 的同伴出现顶端/底端错位。
    """
    layout.addWidget(widget, 0, Qt.AlignmentFlag.AlignVCenter)

# NumberButton
class NumberButton(QPushButton):
    """号码球形按钮（按号码波色着色的可勾选按钮）

    职责:
        展示单个号码并按 LotteryConfig 中的红/蓝/绿配色渲染；支持勾选态，
        由 NumberPanel 组网成数字选择面板，也被 NumberBallWithZodiac 用作号码球。

    关键属性:
        number (int): 按钮代表的号码（1~49）。
        is_selected (bool): 与 QPushButton 的 checked 状态同步的镜像标记，
            供不便于读取 Qt 状态的调用方使用；二者由 set_selected() 保持一致。

    生命周期:
        通常由面板在初始化时批量创建并长期复用；号码固定，颜色不会在运行期变化。

    约束:
        只负责外观与勾选，不发出业务事件（clicked 由外层面板/页面自行连接）。
    """
    
    def __init__(self, number, parent=None):
        """初始化号码按钮

        功能:
            初始化号码按钮

        参数:
            number (int): 号码值，用于显示文本与取色。
            parent (QWidget | None): Qt 父控件，交给父布局管理时传 None 即可。

        返回:
            None

        副作用:
            创建内部状态并调用 _setup_ui() 设置文本、最小尺寸、可勾选与样式。
        """
        super().__init__(parent)
        self.number = number
        self.is_selected = False
        self._setup_ui()
    
    def _setup_ui(self):
        """应用号码按钮的基础属性

        功能:
            应用号码按钮的基础属性

        参数:
            无。

        返回:
            None

        副作用:
            设置按钮文本为号码字符串、最小尺寸 50×50、开启可勾选，
            并调用 _apply_color() 覆盖样式表。

        说明:
            最小尺寸 50×50 是号码球在面板中的默认占位；实际显示尺寸可被
            setFixedSize() 调整（如面板缩放或预测结果尺寸设置）。
        """
        self.setText(str(self.number))
        self.setMinimumSize(50, 50)
        self.setCheckable(True)
        self._apply_color()
    
    def _apply_color(self):
        """按号码波色刷新三态样式表

        功能:
            按号码波色刷新三态样式表

        参数:
            无

        返回:
            None

        副作用:
            通过 LotteryConfig.get_number_color() 读取该号码的 text/border 颜色，
            并整体替换按钮样式表（常态/悬停/选中三态）。

        说明:
            样式表会覆盖 _setup_ui 中的默认外观；选中态用号码色填充、白色文字，
            保证与未选中白底彩字形成明显对比。
        """
        colors = LotteryConfig.get_number_color(self.number)
        # 号码球按钮样式 - 三态（常态/悬停/选中）
        #   QPushButton {       按钮常态样式
        #     background-color: #FFFFFF;  背景色：白色（未选中）
        #     color: colors[text];        文字颜色：号码对应颜色（红/蓝/绿）
        #     border: 2px solid colors[border];  边框：2px 对应颜色实线
        #     border-radius: 24px;        圆角：24px（圆形按钮效果）
        #     font-weight: bold;          字体：粗体
        #     font-size: 18px;            字体大小：18px
        #     min-width: 48px;            最小宽度：48px
        #     min-height: 48px;           最小高度：48px
        #   }
        #   QPushButton:hover {  按钮悬停样式
        #     background-color: #F8F9FA;  悬停背景色：浅灰白
        #   }
        #   QPushButton:checked {  按钮选中状态样式
        #     background-color: colors[text];  选中背景色：号码对应颜色（填充）
        #     color: #FFFFFF;                  选中文字颜色：白色（反色）
        #     border: 2px solid colors[border];  边框保持不变
        #   }
        self.setStyleSheet(
            "QPushButton { background-color: #FFFFFF; color: " + colors['text'] + "; border: 2px solid " + colors['border'] + "; border-radius: 24px; font-weight: bold; font-size: 18px; min-width: 48px; min-height: 48px; }"
            "QPushButton:hover { background-color: #F8F9FA; }"
            "QPushButton:checked { background-color: " + colors['text'] + "; color: #FFFFFF; border: 2px solid " + colors['border'] + "; }"
        )
    
    def set_selected(self, selected):
        """设置选中状态（同步勾选外观与镜像标记）

        功能:
            设置选中状态（同步勾选外观与镜像标记）

        参数:
            selected (bool): True 表示选中（号码色填充），False 表示未选中。

        返回:
            None

        副作用:
            修改 self.is_selected 并调用 setChecked() 触发按钮重绘。
            注意 setChecked 不会发出 clicked 信号，因此程序化批量设置不会引起重复回调。
        """
        self.is_selected = selected
        self.setChecked(selected)
    
    def get_number(self):
        """获取按钮代表的号码

        功能:
            获取按钮代表的号码

        参数:
            无。

        返回:
            int: 创建时传入的号码值。

        副作用:
            无。
        """
        return self.number

# NumberBallWithZodiac
class NumberBallWithZodiac(QWidget):
    """号码球 + 生肖 + 五行标签的组合控件（用于预测结果展示）

    职责:
        把预测结果中的一个号码连同其生肖、五行归属纵向排布成一个可缩放的
        「球 + 两个胶囊标签」单元；号码球复用 NumberButton，并按 is_special
        区分特别码（彩色填充 + 橙色边框）。

    关键属性:
        number (int)          号码值
        zodiac (str)         生肖文字，空字符串表示无生肖数据（标签显示灰色占位）
        element (str)        五行文字，空字符串表示未提供五行标签（此时不创建 element_label）
        font_size (int)      生肖/五行标签字号（默认 15，由页面尺寸设置调整）
        _label_width/_label_height (int) 标签固定宽高，0 表示自适应
        number_btn (NumberButton)           号码球实例
        zodiac_label (QLabel)               生肖标签，始终存在
        element_label (QLabel | None)       五行标签，仅当 element 非空时创建
        ELEMENT_COLORS / ELEMENT_BG         五行文字色与浅色背景映射

    布局:
        使用 QVBoxLayout，号码球与生肖/五行标签的 stretch 比例为 3:1:1，
        即号码球占主要空间，标签只占一行文字高度。

    生命周期:
        一次性创建、不动态替换内部标签；尺寸与字号通过 set_ball_size()/
        set_label_size()/set_font_size() 原地调整。
    约束:
        整个控件 Fixed 尺寸策略，禁止父布局拉伸（见 __init__ 内说明）；
        不发出任何信号。
    """
    
    # 五行配色
    ELEMENT_COLORS = {
        "金": "#F1C40F", "木": "#27AE60", "水": "#3498DB", "火": "#E74C3C", "土": "#E67E22"
    }
    # 五行背景色（浅色版）
    ELEMENT_BG = {
        "金": "#FFF8E1", "木": "#E8F5E9", "水": "#E3F2FD", "火": "#FFEBEE", "土": "#FFF3E0"
    }
    # 暗色主题标签配色（H54）：不新造色板，背景统一用卡片底 #313244，
    # 文字复用项目既有暗色语义色，均满足对 #313244 的文字对比度 ≥4.5:1。
    DARK_LABEL_BG = '#313244'
    ZODIAC_DARK_TEXT = '#89B4FA'
    ELEMENT_DARK_COLORS = {
        "金": "#F5F5F5", "木": "#A6E3A1", "水": "#89B4FA", "火": "#FF8A8A", "土": "#A6ADC8"
    }
    ELEMENT_DARK_FALLBACK = '#F5F5F5'
    
    def __init__(self, number, zodiac="", element="", is_special=False, font_size=15, parent=None):
        """构造号码球与生肖/五行标签的组合控件

        功能:
            构造号码球与生肖/五行标签的组合控件

        参数:
            number (int): 号码值。
            zodiac (str): 生肖文字；空字符串时标签保持空文本并显示灰色占位样式。
            element (str): 五行文字（金/木/水/火/土）；为空则不创建五行标签。
            is_special (bool): True 表示特别码，号码球改用彩色填充 + 橙色边框。
            font_size (int): 标签字号（px），默认 15（全局文字下限）。
            parent (QWidget | None): Qt 父控件。

        返回:
            None

        副作用:
            创建并持有多名子控件（number_btn/zodiac_label/element_label），
            立即应用样式；若 is_special 会替换号码球样式表。

        说明:
            号码球默认勾选（set_selected(True)），以选中态的彩色填充显示号码，
            避免与面板里可点选的未选中按钮混淆。
        """
        super().__init__(parent)
        self.number = number
        self.zodiac = zodiac
        self.element = element
        self.font_size = font_size
        self._label_width = 0  # 生肖/五行标签固定宽度（0=自适应）
        self._label_height = 0  # 生肖/五行标签固定高度（0=自适应）
        # 号码球尺寸由「尺寸设置」明确控制（内部按钮 setFixedSize），外层布局不得再拉伸：
        # 否则预测结果会随窗口变宽被越撑越大，入场动画结束时还会把拉伸后的宽度锁成
        # 固定尺寸（widget.setFixedSize），窗口缩小时内容就溢出可视区域。
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(2)
        layout.setContentsMargins(2, 2, 2, 2)
        
        # 号码球
        btn = NumberButton(number)
        btn.set_selected(True)
        if is_special:
            colors = LotteryConfig.get_number_color(number)
            # 特别码：彩色背景 + 橙色边框，与正码区分且保留颜色属性
                # 特别码号码球样式 - 彩色填充+橙色边框（与正码区分）
                #   QPushButton {       按钮常态样式
                #     background-color: colors[text];  背景色：号码颜色填充
                #     color: #FFFFFF;                  文字颜色：白色
                #     border: 3px solid #F39C12;       边框：3px 橙色实线（特别码标识）
                #     border-radius: 24px;             圆角：24px
                #     font-weight: bold;               字体：粗体
                #     font-size: 18px;                 字体大小：18px
                #     min-width: 48px;                 最小宽度：48px
                #     min-height: 48px;                最小高度：48px
                #   }
                #   QPushButton:hover {  按钮悬停样式
                #     background-color: colors[border];  悬停背景色：边框色
                #   }
            btn.setStyleSheet(
                "QPushButton { background-color: " + colors['text'] + "; color: #FFFFFF; "
                "border: 3px solid #F39C12; border-radius: 24px; font-weight: bold; "
                "font-size: 18px; min-width: 48px; min-height: 48px; }"
                "QPushButton:hover { background-color: " + colors['border'] + "; }"
            )
        self.number_btn = btn
        # stretch=3：号码球占 3 份高度，生肖/五行各 1 份，保证球体是视觉主体
        layout.addWidget(btn, 3)
        
        # 生肖标签
        self.zodiac_label = QLabel(zodiac if zodiac else "")
        self.zodiac_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._update_zodiac_style()
        layout.addWidget(self.zodiac_label, 1)
        
        # 五行标签
        self.element_label = None
        if element:
            self.element_label = QLabel(element)
            self.element_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self._update_element_style()
            layout.addWidget(self.element_label, 1)
        self._theme_window = None  # 已监听主题切换的顶层窗口（H54）

    def _is_dark_theme(self):
        """判断所在顶层窗口当前是否处于暗色主题

        功能:
            读取主窗口的 is_dark_mode 开关；控件尚未挂到窗口或属性缺失时按亮色处理。

        参数:
            无。

        返回:
            bool: True 表示暗色主题。

        副作用:
            无（只读）。
        """
        window = self.window()
        return bool(getattr(window, 'is_dark_mode', False))

    def showEvent(self, event):
        """首次显示时把本控件挂为顶层窗口的样式变更监听者（H54）

        功能:
            主题切换只改主窗口全局样式表，本控件的生肖/五行标签是内联样式，
            不会自动跟随；因此在显示时对顶层窗口安装事件过滤器，收到
            StyleChange 后重刷两个标签颜色。

        参数:
            event (QShowEvent): Qt 显示事件。

        返回:
            None。

        副作用:
            对顶层窗口 installEventFilter；窗口变化时解除旧窗口的过滤器。
        """
        super().showEvent(event)
        window = self.window()
        if window is not None and window is not self._theme_window:
            if self._theme_window is not None:
                self._theme_window.removeEventFilter(self)
            window.installEventFilter(self)
            self._theme_window = window
        # 构造时可能尚未挂到主窗口（无 is_dark_mode），显示后按真实主题重刷标签
        self._update_zodiac_style()
        self._update_element_style()

    def eventFilter(self, obj, event):
        """监听顶层窗口 StyleChange，按新主题重刷标签颜色

        功能:
            主窗口切换亮/暗主题时重建全局样式表并发出 StyleChange；此处同步
            重新套用生肖/五行标签的内联样式，无需重启或重建号码球。

        参数:
            obj: 被监听对象（顶层窗口）。
            event (QEvent): 事件对象。

        返回:
            bool: 始终 False，不拦截事件。
        """
        if obj is self._theme_window and event.type() == QEvent.Type.StyleChange:
            self._update_zodiac_style()
            self._update_element_style()
        return False
    
    def get_number(self):
        """获取该控件的号码

        功能:
            获取该控件的号码

        参数:
            无。

        返回:
            int: 构造时传入的号码值。

        副作用:
            无。
        """
        return self.number
    
    def set_font_size(self, font_size):
        """设置生肖与五行标签的字号（不改变号码球字号）

        功能:
            设置生肖与五行标签的字号（不改变号码球字号）

        参数:
            font_size (int): 标签字号（px）。

        返回:
            None

        副作用:
            写入 self.font_size，并重新应用生肖、五行两个标签的样式表（触发重绘）。
            本方法不做 15px 下限钳制，调用方需自行保证字号满足全局要求。
        """
        self.font_size = font_size
        self._update_zodiac_style()
        self._update_element_style()
    
    def set_label_size(self, width=None, height=None):
        """设置生肖/五行标签背景的固定宽高

        功能:
            设置生肖/五行标签背景的固定宽高

        参数:
            width (int | None): 标签宽度（px）；None 表示不修改该维度，0 表示取消固定、
                恢复自适应。
            height (int | None): 标签高度（px），语义同上。

        返回:
            None

        副作用:
            更新 _label_width/_label_height，并对 zodiac_label 与（若存在）
            element_label 应用 fixed/min/max 尺寸约束。

        说明:
            取消固定时把 max 恢复为 16777215（Qt 的 QWIDGETSIZE_MAX），
            否则 setFixed* 留下的上限会阻止标签重新自适应。
        """
        if width is not None:
            self._label_width = width
        if height is not None:
            self._label_height = height
        # 应用到生肖标签
        if hasattr(self, 'zodiac_label') and self.zodiac_label:
            if getattr(self, '_label_width', 0) > 0:
                self.zodiac_label.setFixedWidth(self._label_width)
            else:
                self.zodiac_label.setMinimumWidth(0)
                self.zodiac_label.setMaximumWidth(16777215)
            if getattr(self, '_label_height', 0) > 0:
                self.zodiac_label.setFixedHeight(self._label_height)
            else:
                self.zodiac_label.setMinimumHeight(0)
                self.zodiac_label.setMaximumHeight(16777215)
        # 应用到五行标签
        if hasattr(self, 'element_label') and self.element_label:
            if getattr(self, '_label_width', 0) > 0:
                self.element_label.setFixedWidth(self._label_width)
            else:
                self.element_label.setMinimumWidth(0)
                self.element_label.setMaximumWidth(16777215)
            if getattr(self, '_label_height', 0) > 0:
                self.element_label.setFixedHeight(self._label_height)
            else:
                self.element_label.setMinimumHeight(0)
                self.element_label.setMaximumHeight(16777215)
    
    def set_ball_size(self, width=None, height=None, font_size=None):
        """设置号码球的尺寸和字体大小

        功能:
            设置号码球的尺寸和字体大小

        参数:
            width (int | None): 号码球宽度（px）；None 表示不修改。
            height (int | None): 号码球高度（px）；None 表示不修改。
            font_size (int | None): 号码球字号（px）；None 表示保留原字号。

        返回:
            None

        副作用:
            对 number_btn 调用 setFixedSize/setFixedWidth/setFixedHeight（互斥优先级：
            宽高都有时用 setFixedSize），并可能整体回写其样式表。

        说明:
            字号通过正则只替换样式表中的 font-size 数值，而不用整段字符串重拼，
            这样特别码的橙色边框、圆角与颜色等属性都能原样保留。
        """
        if hasattr(self, 'number_btn') and self.number_btn:
            current_style = self.number_btn.styleSheet()
            import re  # 作用说明：仅在号码球字号调节时用正则替换样式表中的 font-size，避免整段 QSS 字符串重拼
            if font_size is not None:
                # 用正则替换现有样式表中的 font-size 值，保留其余样式属性不变
                current_style = re.sub(r'font-size:\s*\d+px', f'font-size: {font_size}px', current_style)
            # 将修改后的样式表重新应用到号码球按钮（仅更新字号，其他属性保持原样）
            self.number_btn.setStyleSheet(current_style)
            
            # 设置固定大小（比min-size更可靠）：父布局 Fixed 策略下 fixed 尺寸才不会被拉伸
            if width is not None and height is not None:
                self.number_btn.setFixedSize(width, height)
            elif width is not None:
                self.number_btn.setFixedWidth(width)
            elif height is not None:
                self.number_btn.setFixedHeight(height)
    
    def _update_zodiac_style(self):
        """按当前 zodiac 是否有值刷新生肖标签样式

        功能:
            按当前 zodiac 是否有值刷新生肖标签样式

        参数:
            无

        返回:
            None

        副作用:
            覆盖 zodiac_label 的样式表：有生肖时紫色胶囊，无生肖时灰色占位。
            self.font_size 原样写入，不会自动套用 15px 下限。
        """
        if self.zodiac_label:
            if self.zodiac:
                if self._is_dark_theme():
                    # 暗色主题（H54）：卡片底 + 既有 accent 文字，替换原浅紫底胶囊
                    self.zodiac_label.setStyleSheet(
                        "font-size: " + str(self.font_size) + "px; font-weight: bold; color: "
                        + self.ZODIAC_DARK_TEXT + "; background-color: " + self.DARK_LABEL_BG
                        + "; border-radius: 20px; padding: 2px 6px;"
                    )
                else:
                    # 生肖标签样式（有生肖数据时）- 紫色系（生肖用紫色主题）
                    #   font-size: font_size px;     字体大小：动态设置
                    #   font-weight: bold;           字体：粗体
                    #   color: #9B59B6;              文字颜色：紫色
                    #   background-color: #F3E5F5;   背景色：浅紫
                    #   border-radius: 20px;         圆角：20px（圆形/胶囊形）
                    #   padding: 2px 6px;            内边距：上下2px，左右6px
                    self.zodiac_label.setStyleSheet(
                        "font-size: " + str(self.font_size) + "px; font-weight: bold; color: #9B59B6; "
                        "background-color: #F3E5F5; border-radius: 20px; padding: 2px 6px;"
                    )
            else:
                if self._is_dark_theme():
                    # 暗色主题（H54）：无生肖占位改用次要文字色，避免 #AAAAAA 在暗底发虚
                    self.zodiac_label.setStyleSheet(
                        "font-size: " + str(self.font_size) + "px; font-weight: bold; color: #A6ADC8; "
                        "border-radius: 20px; padding: 2px 6px;"
                    )
                else:
                    # 生肖标签样式（无生肖数据时）- 灰色占位
                    #   font-size: font_size px;     字体大小：动态设置
                    #   font-weight: bold;           字体：粗体
                    #   color: #AAAAAA;              文字颜色：浅灰（占位/空状态）
                    #   border-radius: 20px;         圆角：20px（圆形/胶囊形）
                    #   padding: 2px 6px;            内边距：上下2px，左右6px
                    self.zodiac_label.setStyleSheet(
                        "font-size: " + str(self.font_size) + "px; font-weight: bold; color: #AAAAAA; "
                        "border-radius: 20px; padding: 2px 6px;"
                    )
    
    def _update_element_style(self):
        """按当前 element 刷新五行标签样式

        功能:
            按当前 element 刷新五行标签样式

        参数:
            无

        返回:
            None

        副作用:
            若 element_label 存在且 element 非空，则覆盖其样式表：文字取
            ELEMENT_COLORS、背景取 ELEMENT_BG，未收录的五行回退深灰/浅灰。
            控件创建时 element 为空，element_label 为 None，本方法为空操作。
        """
        if self.element_label and self.element:
            if self._is_dark_theme():
                # 暗色主题（H54）：卡片底 + 既有语义色文字，替换原浅色系背景
                dcolor = self.ELEMENT_DARK_COLORS.get(self.element, self.ELEMENT_DARK_FALLBACK)
                self.element_label.setStyleSheet(
                    "font-size: " + str(self.font_size) + "px; font-weight: bold; color: " + dcolor + "; "
                    "background-color: " + self.DARK_LABEL_BG + "; border-radius: 20px; padding: 2px 6px;"
                )
                return
            ecolor = self.ELEMENT_COLORS.get(self.element, "#555555")
            ebgcolor = self.ELEMENT_BG.get(self.element, "#F5F5F5")
            # 五行标签样式 - 各五行对应颜色
            #   font-size: font_size px;     字体大小：动态设置
            #   font-weight: bold;           字体：粗体
            #   color: ecolor;               文字颜色：对应五行颜色
            #   background-color: ebgcolor;  背景色：对应五行浅色背景
            #   border-radius: 20px;         圆角：20px（圆形/胶囊形）
            #   padding: 2px 6px;            内边距：上下2px，左右6px
            self.element_label.setStyleSheet(
                "font-size: " + str(self.font_size) + "px; font-weight: bold; color: " + ecolor + "; "
                "background-color: " + ebgcolor + "; border-radius: 20px; padding: 2px 6px;"
            )

# NumberPanel
class NumberPanel(QWidget):
    """7×7 数字选择面板（1~49，多选）

    职责:
        以 QGridLayout 排列 49 个 NumberButton，维护用户已选号码列表，
        并在每次选择变化时通过 number_selected 通知宿主页面。

    关键属性:
        selected_numbers (list[int]): 已选号码，按用户勾选顺序排列；
            get_selected_numbers() 返回副本，避免调用方直接改动内部状态。
        number_buttons (dict[int, NumberButton]): 号码 → 按钮映射，供批量设置选中态。

    信号:
        number_selected(list): 选择变化时发出，携带当前 selected_numbers 列表本身。
            注意：发出的是内部列表而非副本，接收方若修改该列表会影响面板状态。

    生命周期:
        页面初始化时创建一次，之后通过 set_selected_numbers()/clear_selection()
        与外部数据同步；按钮尺寸可经 set_button_size() 批量调整。

    约束:
        判断选中与否以按钮的 checked 状态为准，selected_numbers 只是派生缓存。
    """
    number_selected = pyqtSignal(list)
    
    def __init__(self, parent=None):
        """初始化空选择面板并构建 49 个号码按钮

        功能:
            初始化空选择面板并构建 49 个号码按钮

        参数:
            parent (QWidget | None): Qt 父控件。

        返回:
            None

        副作用:
            创建 49 个 NumberButton 并建立 clicked → _on_button_clicked 连接；
            初始化 selected_numbers 与 number_buttons。
        """
        super().__init__(parent)
        self.selected_numbers = []
        self.number_buttons = {}
        self._init_ui()
    
    def _init_ui(self):
        """构建 7×7 号码网格

        功能:
            构建 7×7 号码网格

        参数:
            无。

        返回:
            None

        副作用:
            填充 self.number_buttons，并把按钮逐个加入面板网格布局（间距 5px）。

        说明:
            lambda 使用 `n=num` 默认参数在创建时捕获当前号码，
            否则所有回调会共享循环结束后的 num，点击任意按钮都变成同一个号码。
        """
        layout = QGridLayout(self)
        layout.setSpacing(5)
        layout.setContentsMargins(5, 5, 5, 5)
        for num in range(1, 50):
            btn = NumberButton(num, self)
            # n=num 以默认参数绑定当前值，规避 Python 闭包延迟绑定问题
            btn.clicked.connect(lambda checked, n=num: self._on_button_clicked(n))
            self.number_buttons[num] = btn
            row = (num - 1) // 7
            col = (num - 1) % 7
            layout.addWidget(btn, row, col)
        self.setLayout(layout)
    
    def _on_button_clicked(self, number):
        """处理单个号码按钮的勾选/取消勾选

        功能:
            处理单个号码按钮的勾选/取消勾选

        参数:
            number (int): 被点击的号码。

        返回:
            None

        副作用:
            依据按钮当前的 checked 状态增删 self.selected_numbers，
            然后发出 number_selected 信号。

        说明:
            本方法不主动修改按钮状态，勾选切换由 QPushButton 自身完成。
        """
        btn = self.number_buttons[number]
        if btn.isChecked():
            if number not in self.selected_numbers:
                self.selected_numbers.append(number)
        else:
            if number in self.selected_numbers:
                self.selected_numbers.remove(number)
        self.number_selected.emit(self.selected_numbers)
    
    def get_selected_numbers(self):
        """获取当前已选号码列表的副本

        功能:
            获取当前已选号码列表的副本

        参数:
            无。

        返回:
            list[int]: 已选号码副本；调用方修改它不会影响面板内部状态。

        副作用:
            无。
        """
        return self.selected_numbers.copy()
    
    def set_selected_numbers(self, numbers):
        """用给定号码列表重置整个面板的选中状态

        功能:
            用给定号码列表重置整个面板的选中状态

        参数:
            numbers (Iterable[int]): 期望选中的号码；不在 1~49 范围内的项会被忽略。

        返回:
            None

        副作用:
            先把所有按钮置为未选中并清空 selected_numbers，再逐项勾选，
            最后发出 number_selected（即使最终状态与原来相同也会发出）。
        """
        for btn in self.number_buttons.values():
            btn.set_selected(False)
        self.selected_numbers = []
        for num in numbers:
            if num in self.number_buttons:
                self.number_buttons[num].set_selected(True)
                self.selected_numbers.append(num)
        self.number_selected.emit(self.selected_numbers)
    
    def clear_selection(self):
        """清除所有号码选择（等价于 set_selected_numbers([])）

        功能:
            清除所有号码选择（等价于 set_selected_numbers([])）

        参数:
            无。

        返回:
            None

        副作用:
            重置全部按钮并发出一次 number_selected（空列表）。
        """
        self.set_selected_numbers([])
    
    
    def set_button_size(self, scale=1.0, width=None, height=None, font_size=None):
        """批量调整面板内全部号码按钮的尺寸与字号

        功能:
            批量调整面板内全部号码按钮的尺寸与字号

        参数:
            scale (float): 等比缩放系数，仅在对应 width/height/font_size 为 None 时生效；
                1.0 为原始大小（50×50、18px）。
            width (int | None): 按钮宽度（px），None 表示按 base_width*scale 计算。
            height (int | None): 按钮高度（px），None 表示按 base_height*scale 计算。
            font_size (int | None): 按钮字号（px），None 表示按 base_font*scale 计算。

        返回:
            None

        副作用:
            覆盖每个按钮的样式表并调用 setFixedSize(width, height)；
            随后 invalidate() 布局并 update() 触发重绘。

        约束:
            宽高分别钳制到 [30, LotteryConfig.BUTTON_MAX_WIDTH/HEIGHT]，
            字号钳制到 [15, LotteryConfig.TEXT_MAX_PX]，防止极端缩放破坏布局。
        """
        base_width = 50
        base_height = 50
        base_font = 18
        
        if width is None:
            width = int(base_width * scale)
        if height is None:
            height = int(base_height * scale)
        if font_size is None:
            font_size = int(base_font * scale)
        
        # 尺寸双端钳制：下限 30px 保证可点击，上限取配置值避免撑爆面板
        width = max(30, min(LotteryConfig.BUTTON_MAX_WIDTH, width))
        height = max(30, min(LotteryConfig.BUTTON_MAX_HEIGHT, height))
        # 字号下限 15px 与全局最小字号一致，上限复用 TEXT_MAX_PX
        font_size = max(15, min(LotteryConfig.TEXT_MAX_PX, font_size))
        
        for btn in self.number_buttons.values():
            colors = LotteryConfig.get_number_color(btn.number)
            # 五行面板数字按钮样式 - 三态（常态/悬停/选中）
            #   QPushButton {       按钮常态样式
            #     background-color: #FFFFFF;  背景色：白色
            #     color: colors[text];        文字颜色：号码对应颜色
            #     border: 2px solid colors[border];  边框：2px 对应颜色
            #     border-radius: 8px;         圆角：8px
            #     font-weight: bold;          字体：粗体
            #     font-size: font_size px;    字体大小：动态 font_size（下限 15px）
            #     （样式表未声明 min-width/min-height，尺寸由下方 setFixedSize(width, height) 控制）
            #   }
            #   QPushButton:hover {  按钮悬停样式
            #     background-color: #F0F0F0;  悬停背景色：浅灰
            #   }
            #   QPushButton:checked {  按钮选中状态样式
            #     background-color: colors[text];  选中背景色：号码颜色填充
            #     color: #FFFFFF;                  选中文字颜色：白色
            #     border: 2px solid colors[border];  边框保持不变
            #   }
            btn.setStyleSheet(
                "QPushButton { background-color: #FFFFFF; color: " + colors['text'] + "; border: 2px solid " + colors['border'] + "; border-radius: 8px; font-weight: bold; font-size: " + str(font_size) + "px; }"
                "QPushButton:hover { background-color: #F8F9FA; }"
                "QPushButton:checked { background-color: " + colors['text'] + "; color: #FFFFFF; border: 2px solid " + colors['border'] + "; }"
            )
            btn.setFixedSize(width, height)
        
        # 强制刷新布局：setFixedSize 改了 sizeHint，但父布局不会立即重排，
        # invalidate() 清空缓存，下一次事件循环再按新尺寸布局
        self.layout().invalidate()
        self.update()


# ElementGridPanel
class ElementGridPanel(QWidget):
    """五行号码面板（v0.0.28 恢复）：按钮上方是数字、下方是五行文字

    职责:
        用 7×7 网格展示 1~49 号码及其五行归属；每个格子是「数字按钮 + 五行标签」
        的纵向组合，供「数字与五行」页绑定/展示五行。

    关键属性:
        number_widgets (dict[int, dict]): 每号码对应
            {'widget': 外层 QWidget, 'button': QPushButton, 'label': QLabel}。
        _elements (dict[int, str]): 号码 → 五行名称缓存，样式重算时复用。
        _width/_height (int): 数字按钮宽高（默认 54×38）。
        _btn_font/_label_font (int): 数字按钮/五行标签字号（默认 16/15）。
        ELEMENT_COLORS / ELEMENT_BG: 五行文字色与浅色背景映射。

    生命周期:
        由 TAB/element.py 创建一次，随后通过 update_all_elements() 整体刷新，
        或 update_element() 单点刷新；尺寸经 set_font_size() 批量调整。

    约束:
        本面板不发出信号，数字按钮不参与勾选（仅展示与提示），
        五行数据的来源与解释由页面负责。
    """

    ELEMENT_COLORS = {
        "金": "#F1C40F", "木": "#27AE60", "水": "#3498DB", "火": "#E74C3C", "土": "#E67E22"
    }
    ELEMENT_BG = {
        "金": "#FFF8E1", "木": "#E8F5E9", "水": "#E3F2FD", "火": "#FFEBEE", "土": "#FFF3E0"
    }

    def __init__(self, parent=None):
        """初始化五行号码面板（默认 7 列 × 7 行，49 个号码）

        功能:
            初始化五行号码面板（默认 7 列 × 7 行，49 个号码）

        参数:
            parent (QWidget | None): Qt 父控件。

        返回:
            None

        副作用:
            初始化尺寸/字号默认值与缓存字典，并调用 _init_ui() 创建 49 个格子。

        说明:
            _label_font 默认 15（全局字号下限），首次渲染的五行标签即满足可读要求；
            页面调用 set_font_size() 会再次钳制到 >=15px。
        """
        super().__init__(parent)
        self.number_widgets = {}
        self._elements = {}
        self._width = 54
        self._height = 38
        self._btn_font = 16
        self._label_font = 15
        self._init_ui()

    def _init_ui(self):
        """构建 7×7 号码格子（上数字、下五行）

        功能:
            构建 7×7 号码格子（上数字、下五行）

        参数:
            无。

        返回:
            None

        副作用:
            创建 49 组 cell/button/label，写入 self.number_widgets，
            并逐个调用 _style_button() 与 update_element(num, '') 初始化空状态。

        说明:
            cell_layout 以 stretch 3:1 分配按钮与标签，使按钮占主体高度；
            标签行高随当前字号取 字号×1.4（15px 时为 21px），避免文字被裁切；
            大字号（如页面默认 20px）下由外层滚动区承载，不压缩文字。
        """
        layout = QGridLayout(self)
        layout.setSpacing(2)
        layout.setContentsMargins(6, 6, 6, 6)

        for num in range(1, 50):
            cell = QWidget()
            cell_layout = QVBoxLayout(cell)
            cell_layout.setSpacing(0)
            cell_layout.setContentsMargins(1, 0, 1, 0)

            btn = QPushButton(str(num).zfill(2))
            btn.setFixedSize(self._width, self._height)
            btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            btn.setToolTip("号码 " + str(num).zfill(2) + " 的五行归属")

            label = QLabel("")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setFixedHeight(21)  # 五行文字固定行高（15px 字号 × 1.4），防止文字被裁切

            cell_layout.addWidget(btn, 3)
            cell_layout.addWidget(label, 1)
            layout.addWidget(cell, (num - 1) // 7, (num - 1) % 7)

            self.number_widgets[num] = {'widget': cell, 'button': btn, 'label': label}
            self._style_button(num)
            self.update_element(num, "")

        self.setLayout(layout)

    def _style_button(self, num):
        """按号码颜色刷新单个数字按钮的样式

        功能:
            按号码颜色刷新单个数字按钮的样式

        参数:
            num (int): 号码 1~49，同时作为 number_widgets 的键。

        返回:
            None

        副作用:
            覆盖 self.number_widgets[num]['button'] 的样式表（常态 + 悬停两态）；
            字号取当前 self._btn_font，因此 set_font_size() 后需重新调用本方法。

        说明:
            五行面板的按钮不参与勾选，因此没有 :checked 分支；
            号码颜色（红/蓝/绿）沿用 LotteryConfig，与其它面板保持一致。
        """
        colors = LotteryConfig.get_number_color(num)
        btn = self.number_widgets[num]['button']
        # 五行面板数字按钮样式 - 两态（常态/悬停）
        #   QPushButton {       按钮常态样式
        #     background-color: #FFFFFF;  背景色：白色
        #     color: colors[text];        文字颜色：号码对应波色
        #     border: 2px solid colors[border];  边框：2px 对应波色，与文字同色系
        #     border-radius: 8px;         圆角：8px
        #     font-weight: bold;          字体：粗体
        #     font-size: btn_font px;     字体大小：当前 self._btn_font（默认 16px）
        #   }
        #   QPushButton:hover {  按钮悬停样式
        #     background-color: #F8F9FA;  悬停背景色：浅灰白
        #   }
        btn.setStyleSheet(
            "QPushButton { background-color: #FFFFFF; color: " + colors['text'] + "; border: 2px solid "
            + colors['border'] + "; border-radius: 8px; font-weight: bold; font-size: " + str(self._btn_font) + "px; }"
            "QPushButton:hover { background-color: #F8F9FA; }"
        )

    def update_element(self, num, element):
        """更新单个号码下方的五行文字

        功能:
            更新单个号码下方的五行文字

        参数:
            num (int): 号码 1~49；不存在时直接返回。
            element (str): 五行名称（金/木/水/火/土）；空字符串表示未绑定/清除。

        返回:
            None

        副作用:
            写入 self._elements[num]；设置 label 文本与样式表（会触发重绘）。

        说明:
            未收录的五行名称回退为深灰文字 + 浅灰背景，不会报错；
            字号取 self._label_font，默认 15px（全局字号下限）。
        """
        info = self.number_widgets.get(num)
        if not info:
            return
        self._elements[num] = element
        label = info['label']
        if element:
            color = self.ELEMENT_COLORS.get(element, "#555555")
            bg = self.ELEMENT_BG.get(element, "#F5F5F5")
            label.setText(element)
            # 五行标签样式（有数据时）
            #   font-size: label_font px;     字体大小：当前 self._label_font（默认 15px）
            #   font-weight: bold;           字体：粗体
            #   color: color;                文字颜色：对应五行色（未知五行回退 #555555）
            #   background-color: bg;        背景色：对应五行浅色（未知回退 #F5F5F5）
            #   border-radius: 4px;          圆角：4px
            #   padding: 1px 3px;            内边距：上下 1px、左右 3px
            label.setStyleSheet(
                "font-size: " + str(self._label_font) + "px; font-weight: bold; color: " + color + "; "
                "background-color: " + bg + "; border-radius: 4px; padding: 1px 3px;"
            )
        else:
            label.setText("")
            # 五行标签样式（无数据时）- 灰色占位
            #   font-size: label_font px;     字体大小：当前 self._label_font（默认 15px）
            #   font-weight: bold;           字体：粗体
            #   color: #AAAAAA;              文字颜色：浅灰（空状态）
            #   border-radius: 4px;          圆角：4px
            #   padding: 1px 3px;            内边距：上下 1px、左右 3px
            label.setStyleSheet(
                "font-size: " + str(self._label_font) + "px; font-weight: bold; color: #AAAAAA; "
                "border-radius: 4px; padding: 1px 3px;"
            )

    def update_all_elements(self, elements_dict):
        """批量更新全部号码的五行文字

        功能:
            批量更新全部号码的五行文字

        参数:
            elements_dict (dict[int, str]): 号码 → 五行名称映射；缺失的号码按空字符串
                处理，即清空为灰色占位。

        返回:
            None

        副作用:
            逐个调用 update_element()，共 49 次标签文本/样式刷新。
        """
        for num in range(1, 50):
            self.update_element(num, elements_dict.get(num, ""))

    def set_font_size(self, scale=1.0, width=None, height=None, btn_font=None, label_font=None):
        """调整按钮宽高与数字/五行文字字号（未传的项保持当前值，带上下限钳制）

        功能:
            调整按钮宽高与数字/五行文字字号（未传的项保持当前值，带上下限钳制）

        参数:
            scale (float): 兼容参数；本方法未使用，仅保留各面板统一的调用签名。
            width (int | None): 数字按钮宽度（px）；None 表示保持当前 self._width。
            height (int | None): 数字按钮高度（px）；None 表示保持当前 self._height。
            btn_font (int | None): 数字按钮字号（px）；None 表示保持当前 self._btn_font。
            label_font (int | None): 五行标签字号（px）；None 表示保持当前 self._label_font。

        返回:
            None

        副作用:
            更新 _width/_height/_btn_font/_label_font，并对全部按钮 setFixedSize、
            对标签重设固定行高、重刷按钮与标签样式，最后 invalidate()+update()。

        约束:
            宽度钳制到 [30, BUTTON_MAX_WIDTH]，高度钳制到 [26, BUTTON_MAX_HEIGHT]，
            两种字号均钳制到 [15, TEXT_MAX_PX]。

        说明:
            scale 参数在本次实现中未参与计算，等尺寸由调用方直接传入。
        """
        if width is None:
            width = self._width
        if height is None:
            height = self._height
        if btn_font is None:
            btn_font = self._btn_font
        if label_font is None:
            label_font = self._label_font

        self._width = max(30, min(LotteryConfig.BUTTON_MAX_WIDTH, width))
        self._height = max(26, min(LotteryConfig.BUTTON_MAX_HEIGHT, height))
        self._btn_font = max(15, min(LotteryConfig.TEXT_MAX_PX, btn_font))
        self._label_font = max(15, min(LotteryConfig.TEXT_MAX_PX, label_font))

        for num, info in self.number_widgets.items():
            info['button'].setFixedSize(self._width, self._height)
            # 标签行高按字号 1.4 倍估算（含上下留白），并保底 14px，
            # 防止小字号时文字被裁切
            info['label'].setFixedHeight(max(14, int(self._label_font * 1.4)))
            self._style_button(num)
            self.update_element(num, self._elements.get(num, ""))
        # 尺寸变化后清空布局缓存并请求重绘，否则标签仍按旧行高排版
        self.layout().invalidate()
        self.update()


# ZodiacNumberPanel
# 预留：生肖号码面板（旧版界面组件，当前未接入主流程）
class ZodiacNumberPanel(QWidget):
    """数字与生肖面板：7×7 号码按钮 + 生肖文字标签

    职责:
        展示 1~49 号码与各自生肖；与 NumberPanel 不同，本面板不做多选，
        点击号码只发信号，由主窗口弹出十二生肖菜单让用户选择归属。

    关键属性:
        number_widgets (dict[int, dict]): 每号码对应
            {'widget': 外层 QWidget, 'button': QPushButton, 'zodiac_label': QLabel}。
        _zodiacs (dict[int, str]): 号码 → 生肖名称缓存，供字号调整后恢复标签内容。
        _current_label_font (int): 当前生肖标签字号；初始 15（全局字号下限），
            调用 set_font_size() 后仍钳制在 >=15。
        ZODIAC_COLORS (dict[str, str]): 十二生肖 → 标签文字颜色。

    信号:
        number_clicked(int): 号码按钮被点击时发出，参数为号码值；
            面板自身不修改任何选中状态，菜单选择与数据更新由页面完成。

    生命周期:
        由 TAB/zodiac.py 创建一次，生肖数据通过 update_all_zodiacs() 整体刷新。

    约束:
        点击按钮不改变按钮外观，也不维护选中列表。
    """
    # 号码被点击 → 通知主窗口弹出十二生肖菜单（选中即时生效，不再多选）
    number_clicked = pyqtSignal(int)
    
    ZODIAC_COLORS = {
        "鼠": "#3498DB", "牛": "#27AE60", "虎": "#E74C3C", "兔": "#F39C12",
        "龙": "#9B59B6", "蛇": "#1ABC9C", "马": "#E67E22", "羊": "#2ECC71",
        "猴": "#3498DB", "鸡": "#F1C40F", "狗": "#95A5A6", "猪": "#E91E63"
    }
    
    def __init__(self, parent=None):
        """初始化生肖号码面板

        功能:
            初始化生肖号码面板

        参数:
            parent (QWidget | None): Qt 父控件。

        返回:
            None

        副作用:
            初始化缓存字典与标签字号，并调用 _init_ui() 创建 49 组控件。

        说明:
            _current_label_font 初始为 15（全局字号下限）；若页面在调用
            set_font_size() 之前就 update_zodiac()，标签也不会低于 15px。
        """
        super().__init__(parent)
        self.number_widgets = {}
        self._zodiacs = {}  # num -> zodiac_name
        self._current_label_font = 15  # 当前标签字体大小（初始即取全局下限）
        self._init_ui()
    
    def _init_ui(self):
        """构建 7×7 号码 + 生肖标签网格

        功能:
            构建 7×7 号码 + 生肖标签网格

        参数:
            无。

        返回:
            None

        副作用:
            创建 49 组 number_widgets，并为每个号码按钮连接
            clicked → _on_button_clicked，标签初始为灰色空状态。

        说明:
            lambda 的 `n=num` 默认参数用于在创建时捕获对应号码，
            外层 widget 以 stretch 3:1 分配按钮与标签高度。
        """
        layout = QGridLayout(self)
        layout.setSpacing(4)
        layout.setContentsMargins(5, 5, 5, 5)
        
        for num in range(1, 50):
            w = QWidget()
            w_layout = QVBoxLayout(w)
            w_layout.setSpacing(1)
            w_layout.setContentsMargins(1, 1, 1, 1)
            
            # 数字按钮
            btn = QPushButton(str(num).zfill(2))
            colors = LotteryConfig.get_number_color(num)
            # 生肖面板数字按钮样式 - 三态（常态/悬停/点击反馈）
            #   QPushButton {       按钮常态样式
            #     background-color: #FFFFFF;  背景色：白色
            #     color: colors[text];        文字颜色：号码对应颜色
            #     border: 2px solid colors[border];  边框：2px 对应颜色
            #     border-radius: 8px;         圆角：8px
            #     font-weight: bold;          字体：粗体
            #     font-size: 16px;            字体大小：16px
            #     min-width: 44px;            最小宽度：44px
            #     min-height: 40px;           最小高度：40px
            #   }
            #   QPushButton:hover {  按钮悬停样式
            #     background-color: #F0F0F0;  悬停背景色：浅灰
            #   }
            btn.setStyleSheet(
                "QPushButton { background-color: #FFFFFF; color: " + colors['text'] + "; border: 2px solid " + colors['border'] + "; border-radius: 8px; font-weight: bold; font-size: 16px; min-width: 44px; min-height: 40px; }"
                "QPushButton:hover { background-color: #F0F0F0; }"
            )
            # n=num 在创建时绑定当前号码，避免闭包延迟绑定导致所有按钮都发同一个号码
            btn.clicked.connect(lambda checked, n=num: self._on_button_clicked(n))
            # stretch=3：数字按钮占 3 份，生肖标签占 1 份，保持按钮为视觉主体
            w_layout.addWidget(btn, 3)
            
            # 生肖标签
            zodiac_label = QLabel("")
            zodiac_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            # 生肖标签初始样式（空状态）- 灰色占位
            #   font-size: 15px;       字体大小：15px（全局字号下限）
            #   font-weight: bold;     字体：粗体
            #   color: #AAAAAA;        文字颜色：浅灰（空状态）
            #   border-radius: 4px;    圆角：4px
            #   padding: 1px 3px;      内边距：上下1px，左右3px
            # 初始样式与 _current_label_font 的初值保持一致，均为 15px
            zodiac_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #AAAAAA; border-radius: 4px; padding: 1px 3px;")
            w_layout.addWidget(zodiac_label, 1)
            
            row = (num - 1) // 7
            col = (num - 1) % 7
            layout.addWidget(w, row, col)
            
            self.number_widgets[num] = {
                'widget': w,
                'button': btn,
                'zodiac_label': zodiac_label
            }
        
        self.setLayout(layout)
    
    def _on_button_clicked(self, number):
        """号码按钮点击 → 抛给主窗口弹出十二生肖菜单（选中即时生效）

        功能:
            号码按钮点击 → 抛给主窗口弹出十二生肖菜单（选中即时生效）

        参数:
            number (int): 被点击的号码。

        返回:
            None

        副作用:
            发出 number_clicked(int) 信号；本方法不修改按钮或标签状态。
        """
        self.number_clicked.emit(number)

    def update_zodiac(self, num, zodiac):
        """更新某个号码的生肖标签

        功能:
            更新某个号码的生肖标签

        参数:
            num (int): 号码 1~49；不在面板中时仅写缓存、不更新界面。
            zodiac (str): 生肖名称（十二生肖之一）；空字符串表示清除为灰色占位。

        返回:
            None

        副作用:
            写入 self._zodiacs[num]，并设置对应标签文本与样式表（触发重绘）。
            字号取 self._current_label_font（初始 15，set_font_size 后仍 >=15）。

        说明:
            未知生肖名回退为 #555555 文字色；背景固定浅紫 #F8F0FF。
        """
        self._zodiacs[num] = zodiac
        info = self.number_widgets.get(num)
        if info:
            label = info['zodiac_label']
            if zodiac:
                color = self.ZODIAC_COLORS.get(zodiac, "#555555")
                label.setText(zodiac)
                # 生肖标签样式（有生肖数据时）- 紫色系（生肖用紫色主题）
                #   font-size: label_font px;    字体大小：动态设置
                #   font-weight: bold;           字体：粗体
                #   color: color;                文字颜色：对应生肖颜色
                #   background-color: #F8F0FF;   背景色：浅紫
                #   border-radius: 4px;          圆角：4px
                #   padding: 1px 3px;            内边距：上下1px，左右3px
                label.setStyleSheet(
                    "font-size: " + str(self._current_label_font) + "px; font-weight: bold; color: " + color + "; "
                    "background-color: #F8F0FF; border-radius: 4px; padding: 1px 3px;"
                )
            else:
                label.setText("")
                # 生肖标签样式（无生肖数据时）- 灰色占位
                #   font-size: label_font px;    字体大小：动态设置
                #   font-weight: bold;           字体：粗体
                #   color: #AAAAAA;              文字颜色：浅灰（空状态）
                #   border-radius: 4px;          圆角：4px
                #   padding: 1px 3px;            内边距：上下1px，左右3px
                label.setStyleSheet(
                    "font-size: " + str(self._current_label_font) + "px; font-weight: bold; color: #AAAAAA; border-radius: 4px; padding: 1px 3px;"
                )
    
    def update_all_zodiacs(self, zodiacs_dict):
        """批量更新 1~49 全部号码的生肖标签

        功能:
            批量更新 1~49 全部号码的生肖标签

        参数:
            zodiacs_dict (dict[int, str]): 号码 → 生肖名称映射；缺失号码按空字符串
                处理（清为灰色占位）。

        返回:
            None

        副作用:
            用 dict() 拷贝传入字典覆盖 self._zodiacs（防止外部后续修改影响面板），
            并逐个调用 update_zodiac() 刷新 49 个标签。

        说明:
            拷贝后循环里仍从原字典取值，二者内容一致；拷贝主要用于后续
            set_font_size() 重建样式时能取到完整映射。
        """
        self._zodiacs = dict(zodiacs_dict)
        for num in range(1, 50):
            zodiac = zodiacs_dict.get(num, "")
            self.update_zodiac(num, zodiac)
    
    def set_font_size(self, scale=1.0, width=None, height=None, btn_font=None, label_font=None):
        """调整数字按钮和生肖标签的大小与字体

        功能:
            调整数字按钮和生肖标签的大小与字体

        参数:
            scale (float): 等比缩放系数；仅在 width/height/btn_font/label_font 为 None
                时用于按基准值（44×40、16px、15px）计算。
            width (int | None): 按钮宽度（px），None 表示 base_width*scale。
            height (int | None): 按钮高度（px），None 表示 base_height*scale。
            btn_font (int | None): 按钮字号（px），None 表示 base_btn_font*scale。
            label_font (int | None): 生肖标签字号（px），None 表示 base_label_font*scale。

        返回:
            None

        副作用:
            更新 _current_label_font，重设全部按钮尺寸与样式、标签样式、
            外层 widget 最小宽高，最后 invalidate()+update() 触发重排重绘。

        约束:
            宽/高钳制到 [30, BUTTON_MAX_WIDTH/HEIGHT]；两种字号钳制到
            [15, TEXT_MAX_PX]（因此 base_label_font=15 经任意 scale 也被钳制到 >=15）。
        """
        base_width = 44
        base_height = 40
        base_btn_font = 16
        base_label_font = 15
        
        if width is None:
            width = int(base_width * scale)
        if height is None:
            height = int(base_height * scale)
        if btn_font is None:
            btn_font = int(base_btn_font * scale)
        if label_font is None:
            label_font = int(base_label_font * scale)
        
        # 尺寸双端钳制：下限 30px 保证可点击，上限取配置值避免撑破 7 列网格
        width = max(30, min(LotteryConfig.BUTTON_MAX_WIDTH, width))
        height = max(30, min(LotteryConfig.BUTTON_MAX_HEIGHT, height))
        # 字号下限 15px 与全局最小字号一致
        btn_font = max(15, min(LotteryConfig.TEXT_MAX_PX, btn_font))
        label_font = max(15, min(LotteryConfig.TEXT_MAX_PX, label_font))
        
        # 计算整体widget高度（按钮 + 标签 + 间距）
        # 8 = 上下内容边距 1px×2 + 布局 spacing 1px + 余量，避免外层 widget 高度不足裁掉标签
        total_height = height + label_font + 8
        
        # 保存当前标签字体大小
        self._current_label_font = label_font
        
        for num, info in self.number_widgets.items():
            btn = info['button']
            label = info['zodiac_label']
            widget = info['widget']
            colors = LotteryConfig.get_number_color(num)
            
            # 生肖面板数字按钮样式（字体调整后）- 三态
            #   QPushButton {       按钮常态样式
            #     background-color: #FFFFFF;  背景色：白色
            #     color: colors[text];        文字颜色：号码对应颜色
            #     border: 2px solid colors[border];  边框：2px 对应颜色
            #     border-radius: 8px;         圆角：8px
            #     font-weight: bold;          字体：粗体
            #     font-size: btn_font px;     字体大小：动态设置
            #   }
            #   QPushButton:hover {  按钮悬停样式
            #     background-color: #F0F0F0;  悬停背景色：浅灰
            #   }
            btn.setStyleSheet(
                "QPushButton { background-color: #FFFFFF; color: " + colors['text'] + "; border: 2px solid " + colors['border'] + "; border-radius: 8px; font-weight: bold; font-size: " + str(btn_font) + "px; }"
                "QPushButton:hover { background-color: #F0F0F0; }"
            )
            btn.setFixedSize(width, height)
            
            # 设置外层widget最小宽度，确保布局撑开
            widget.setMinimumWidth(width)
            widget.setMinimumHeight(total_height)
            
            # 更新标签字体，保持原有颜色和背景
            zodiac = self._zodiacs.get(num, "")
            if zodiac:
                color = self.ZODIAC_COLORS.get(zodiac, "#555555")
                # 生肖标签样式（有数据时，字体调整后）
                #   font-size: label_font px;    字体大小：动态设置
                #   font-weight: bold;           字体：粗体
                #   color: color;                文字颜色：对应生肖颜色
                #   background-color: #F8F0FF;   背景色：浅紫
                #   border-radius: 4px;          圆角：4px
                #   padding: 1px 3px;            内边距：上下1px，左右3px
                label.setStyleSheet(
                    "font-size: " + str(label_font) + "px; font-weight: bold; color: " + color + "; "
                    "background-color: #F8F0FF; border-radius: 4px; padding: 1px 3px;"
                )
            else:
                # 生肖标签样式（无数据时，字体调整后）- 灰色占位
                #   font-size: label_font px;    字体大小：动态设置
                #   font-weight: bold;           字体：粗体
                #   color: #AAAAAA;              文字颜色：浅灰（空状态）
                #   border-radius: 4px;          圆角：4px
                #   padding: 1px 3px;            内边距：上下1px，左右3px
                label.setStyleSheet(
                    "font-size: " + str(label_font) + "px; font-weight: bold; color: #AAAAAA; border-radius: 4px; padding: 1px 3px;"
                )
        
        # 强制刷新布局：批量改 fixed/min 尺寸后需清空布局缓存，否则下一次
        # 事件循环前仍按旧尺寸绘制
        self.layout().invalidate()
        self.update()

# AttributeMatrixPanel（生肖页统一版：圆形号码牌 + 固定 12 生肖表头）
# 设计依据：docs/设计稿/生肖页统一版/设计方案.md（变体一）
#   §4.2 卡 = 圆角底板 + 圆形号码指示器 + 五行单字，卡内不再出现生肖
#   §4.3 表头 = 12 生肖固定条（135° 渐变，起始色压暗为 #5566D6）
#   §4.4 几何：列距/卡宽/圆径/字号随可用宽度反算，表头与卡片共用列轴
#   §4.5 选中态：2px 强调描边 + 极轻填充；高亮态只加强整卡填充、不加描边
#   §4.6 亮/暗令牌（对比度实测见文档）
MATRIX_ROWS = 5          # 5 排（01-12 / 13-24 / 25-36 / 37-48 / 49）
MATRIX_COLS = 12         # 12 列（一排 12 个，直至 49）
MATRIX_TOTAL = 49        # 号码 1-49
MATRIX_EMPTY_SLOTS = MATRIX_ROWS * MATRIX_COLS - MATRIX_TOTAL  # 末排 11 个空槽

# 两档几何参数（以设计稿 1180 档 56×88 / D44 / 28/15/54、1600 档 80×127 / D60 为目标，
# 实际卡宽再由「当前可用宽度 - 12 列 - 11 个列距」反算，允许小于设计稿的 56/80）。
_MATRIX_PROFILE_COMPACT = {
    'gap': 6,          # 列距（设计稿 1180 档 62-56=6）
    'row_gap': 8,      # 行距
    'header_h': 54,    # 表头高
    'head_gap': 8,     # 表头与卡区间距
    'num_px': 28,      # 号码字号
    'attr_px': 15,     # 五行字号
    'head_px': 15,     # 表头字号
    'pad': 8,          # 卡上下留白（对称，且 ≥8px）
    'elem_gap': 6,     # 圆与五行行之间距
    'line_h': 22,      # 五行行高
    'radius': 10,      # 卡圆角
    'd_ratio': 0.786,  # 圆径 ≈ 44/56，保持设计稿的圆/卡比例
    'card_w_min': 30,
}
_MATRIX_PROFILE_WIDE = {
    'gap': 8,
    'row_gap': 10,
    'header_h': 64,
    'head_gap': 10,
    'num_px': 34,
    'attr_px': 17,
    'head_px': 17,
    'pad': 12,
    'elem_gap': 8,
    'line_h': 25,
    'radius': 12,
    'd_ratio': 0.75,   # 圆径 ≈ 60/80
    'card_w_min': 30,
}
_MATRIX_WIDE_MIN_WIDTH = 960  # 面板宽 ≥960 走宽档（1180 档约 890，1600 档约 1024）
_MATRIX_PANEL_MIN_WIDTH = 880  # 12×73+4：保证 1180 档左栏仍有约 890px 可用宽

# 卡区纵向滚动条宽度口径（唯一来源，保证任何机器/主题下几何可复现）：
# 主窗口全局 QSS 把垂直滚动条固定为 width:12px（plugins/彩票预测.py 的
# _update_stylesheet），而 QStyle.PM_ScrollBarExtent 返回的是未套 QSS 的原生
# 度量（本机 17px）。若按 17px 预留，会从 12px 的真实槽位里多扣 5px，导致
# 1180 档算成 65×71（文档旧值）而不是 66×72；因此这里统一按真实渲染宽度
# 12px 预留，不读 PM_ScrollBarExtent。QSS 若改动滚动条宽度，只需同步本常量。
_MATRIX_SCROLLBAR_W = 12

# 12 生肖顺时针顺序（与「一键应用」同源：01 对应的生肖 → 顺时针 12 位）
_MATRIX_CLOCKWISE = tuple(LotteryConfig.ZODIAC_CLOCKWISE)
# 用于 set_highlight_zodiac 的合法性校验（顺序固定，仅作成员集合使用）
MATRIX_ZODIAC_ORDER = ('鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪')

# 表头令牌（设计稿 §4.3/§4.5，亮暗主题共用）
_MATRIX_HEADER_TOKENS = {
    'grad_from': '#5566D6',   # 起始色压暗（原 #667EEA 配白字仅 3.5:1）
    'grad_to': '#764BA2',
    'separator': '#5A67D8',   # 2px 单元格边框 / 表头底边
    'selected_bg': '#4A3391',
    'selected_border': '#A5B4FC',
    'text': '#FFFFFF',
    'hover_line': '#C7CFF8',
}

# 面板与卡片令牌（设计稿 §5.2/§5.3 亮暗两套）
_MATRIX_THEMES = {
    False: {
        'container_bg': '#F5F2FA',
        'container_border': '#DCD6EC',
        'grid': '#D8D2E8',
        'card_bg': '#FFFFFF',
        'card_border': '#E2DDEC',
        'card_dim_bg': '#FCFCFE',
        'card_dim_border': '#EFEBF6',
        'card_emph_bg': '#EFE9FF',
        # 选中态：2px 强调描边 + 极轻填充（描边为主，填充只作辅助）。
        # 三个 ratio 对应 display_state，允许「选中 + 高亮 / 选中 + 淡出」正交叠加。
        # emphasis 上不再叠填充：底色已加深，再叠会让 15px 五行文字跌破 4.5:1。
        'card_sel_border': '#5A67D8',
        'card_sel_fill_ratio': 0.05,
        'card_sel_fill_ratio_emph': 0.0,
        'card_sel_fill_ratio_dim': 0.03,
        # 空槽：虚线相对底色的对比度压到 1.33:1（区间 1.3–1.8），'-' 降到 2.01:1，
        # 仍可辨认「这里是空位」，但不再与真实号码卡等重。
        'empty_line': '#D7D2E3',
        'empty_text': '#B0ABBE',
        'dim_element': '#6E6E7A',
        'shadow_alpha': 14,
    },
    True: {
        'container_bg': '#151B2A',
        'container_border': '#2B3547',
        'grid': '#2A3350',
        'card_bg': '#1F2739',
        'card_border': '#2E3A4F',
        'card_dim_bg': '#1A2130',
        'card_dim_border': '#28303F',
        'card_emph_bg': '#313A61',
        'card_sel_border': '#A5B4FC',
        'card_sel_fill_ratio': 0.06,
        'card_sel_fill_ratio_emph': 0.06,
        'card_sel_fill_ratio_dim': 0.03,
        # 空槽虚线对比度 1.54:1（区间 1.3–1.8），'-' 由 6.22:1 降到 2.83:1
        'empty_line': '#333B4E',
        'empty_text': '#59627A',
        'dim_element': '#A6A6B8',
        'shadow_alpha': 40,
    },
}

# 五行文字色（亮/暗两套；设计稿 §5.2/§5.3，15px 下对卡底对比度 ≥4.5:1）
_MATRIX_ELEMENT_COLORS = {
    False: {'金': '#79590E', '木': '#1C7240', '水': '#145FA8', '火': '#B4332A', '土': '#7B5230'},
    True: {'金': '#E9C46A', '木': '#A6E3A1', '水': '#89B4FA', '火': '#FF9A8B', '土': '#D7B28C'},
}


def _matrix_hex_to_rgb(value):
    """#RRGGBB → (r, g, b)；解析失败返回黑色，保证绘制不抛异常"""
    text = str(value or '').strip().lstrip('#')
    if len(text) != 6:
        return (0, 0, 0)
    try:
        return (int(text[0:2], 16), int(text[2:4], 16), int(text[4:6], 16))
    except ValueError:
        return (0, 0, 0)


def _matrix_blend(identity, base, ratio):
    """按 ratio 把 identity 混到 base 上，返回 #RRGGBB 字符串"""
    ratio = max(0.0, min(1.0, float(ratio)))
    r1, g1, b1 = _matrix_hex_to_rgb(identity)
    r2, g2, b2 = _matrix_hex_to_rgb(base)
    return '#%02X%02X%02X' % (
        int(round(r1 * ratio + r2 * (1 - ratio))),
        int(round(g1 * ratio + g2 * (1 - ratio))),
        int(round(b1 * ratio + b2 * (1 - ratio))),
    )


def _matrix_header_order(binding):
    """按 01 号绑定的生肖旋转顺时针序列，得到表头 12 格顺序"""
    base = list(_MATRIX_CLOCKWISE)
    start = (binding or {}).get(1)
    if start in base:
        index = base.index(start)
        return base[index:] + base[:index]
    return base


def _matrix_rounded_cell_path(rect, radius_tl, radius_tr):
    """构造只在上方两角带圆角的矩形路径（表头首/末格与容器内沿共角）"""
    path = QPainterPath()
    left, top, right, bottom = rect.left(), rect.top(), rect.right(), rect.bottom()
    tl = max(0, int(radius_tl))
    tr = max(0, int(radius_tr))
    path.moveTo(left + tl, top)
    path.lineTo(right - tr, top)
    if tr:
        path.quadTo(right, top, right, top + tr)
    path.lineTo(right, bottom)
    path.lineTo(left, bottom)
    if tl:
        path.quadTo(left, top, left + tl, top)
    else:
        path.lineTo(left, top)
    return path


class _MatrixBody(QWidget):
    """卡区滚动内容（只承载 49 张卡与空槽，表头不在其中）

    由 AttributeMatrixPanel 放进 QScrollArea：表头固定在上方，本控件随纵向
    滚动移动。自绘 1px 弱列网格线与末排虚线空槽，保证列轴贯通到末排。
    """

    def __init__(self, panel, parent=None):
        super().__init__(parent)
        self._panel = panel
        self.setAutoFillBackground(False)
        self.setStyleSheet("background: transparent;")

    def paintEvent(self, event):
        self._panel._paint_body(self)
        super().paintEvent(event)


class _AttributeMatrixCard(QWidget):
    """属性矩阵的单张号码卡（统一版变体一）

    卡面 = 圆角底板 + 圆形号码指示器 + 五行单字；生肖不再出现在卡内，
    由上方固定 12 生肖表头承担。号码在圆内按 boundingRect 墨迹居中，
    避免 QLabel 默认 advance 居中导致左偏。
    """

    clicked = pyqtSignal(int)
    right_clicked = pyqtSignal(int)
    # 双击号码卡时发出号码（属性矩阵页用于在鼠标位置弹出「改生肖」菜单）
    double_clicked = pyqtSignal(int)

    def __init__(self, number, parent=None):
        super().__init__(parent)
        self.number = int(number)
        self.zodiac = ''
        self._element = ''
        self._text_color = '#FF0000'
        self._dark_mode = False
        self._display_state = 'normal'
        self._selected = False
        self._card_w = 56
        self._card_h = 88
        self._radius = 10
        self._circle_d = 44
        self._pad = 8
        self._elem_gap = 6
        self._line_h = 22
        self._num_font = QFont(FontUtils.get_default_font_family())
        self._num_font.setPixelSize(28)
        self._num_font.setBold(True)
        self._num_font.setWeight(QFont.Weight.Bold)
        self._elem_font = QFont(FontUtils.get_default_font_family())
        self._elem_font.setPixelSize(15)
        self._elem_font.setBold(True)
        self._elem_font.setWeight(QFont.Weight.Bold)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self._update_tooltip()

    def apply_geometry(self, card_w, card_h, circle_d, pad, elem_gap, line_h,
                       radius, num_px, attr_px):
        """下发几何参数（面板宽度变化/字号变化时调用）"""
        self._card_w = int(card_w)
        self._card_h = int(card_h)
        self._circle_d = int(circle_d)
        self._pad = int(pad)
        self._elem_gap = int(elem_gap)
        self._line_h = int(line_h)
        self._radius = int(radius)
        self._num_font.setPixelSize(max(15, int(num_px)))
        self._elem_font.setPixelSize(max(15, int(attr_px)))
        self.setFixedSize(self._card_w, self._card_h)
        self.update()

    def _theme(self):
        return _MATRIX_THEMES[bool(self._dark_mode)]

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        theme = self._theme()
        state = self._display_state

        if state == 'emphasis':
            # 高亮：只加强整卡填充，不再额外描边（描边由选中态独占）
            bg, border, width = theme['card_emph_bg'], theme['card_border'], 1
        elif state == 'dimmed':
            bg, border, width = theme['card_dim_bg'], theme['card_dim_border'], 1
        else:
            bg, border, width = theme['card_bg'], theme['card_border'], 1

        # 选中：2px 强调描边 + 极轻填充，与 normal/emphasis/dimmed 正交叠加。
        # 填充比例按 display_state 分别取值（emphasis 取 0，避免叠深后 15px 文字
        # 对比度跌破 4.5:1），因此「选中 + 高亮」「选中 + 淡出」不会互相打架。
        if self._selected:
            ratio = {
                'normal': theme['card_sel_fill_ratio'],
                'emphasis': theme['card_sel_fill_ratio_emph'],
                'dimmed': theme['card_sel_fill_ratio_dim'],
            }[state]
            if ratio > 0:
                bg = _matrix_blend(theme['card_sel_border'], bg, ratio)
            border, width = theme['card_sel_border'], 2

        # 卡面：描边落在内圈，避免右/下边被裁掉半像素
        painter.setPen(QPen(QColor(border), width))
        painter.setBrush(QColor(bg))
        painter.drawRoundedRect(self.rect().adjusted(0, 0, -1, -1),
                                self._radius, self._radius)

        diameter = self._circle_d
        cx = self._card_w // 2
        top = self._pad
        circle = QRectF(cx - diameter / 2.0, top, diameter, diameter)

        # 圆形指示器：三层极轻投影 + 波色填充（淡出态向卡底混合）
        wave = self._text_color
        if state == 'dimmed':
            fill = _matrix_blend(wave, bg, 0.43 if not self._dark_mode else 0.48)
            number_color = _matrix_blend(
                wave, '#000000' if not self._dark_mode else '#FFFFFF',
                0.45 if not self._dark_mode else 0.55)
        else:
            fill = wave
            number_color = '#FFFFFF'

        shadow_alpha = theme['shadow_alpha']
        painter.setPen(Qt.PenStyle.NoPen)
        for offset, scale in ((3, 1.0), (2, 0.6), (1, 0.35)):
            painter.setBrush(QColor(0, 0, 0, int(shadow_alpha * scale)))
            painter.drawEllipse(circle.translated(0, offset))
        painter.setBrush(QColor(fill))
        painter.drawEllipse(circle)

        # 号码：按 tightBoundingRect 墨迹居中（目标偏差 ≤1px）
        painter.setFont(self._num_font)
        painter.setPen(QColor(number_color))
        text = str(self.number).zfill(2)
        ink = QFontMetrics(self._num_font).tightBoundingRect(text)
        baseline = circle.center().y() - (ink.top() + ink.bottom()) / 2.0
        painter.drawText(QPointF(cx - ink.left() - ink.width() / 2.0, baseline), text)

        # 五行单字：在固定行高内同样按墨迹居中
        element = self._element or ''
        if element:
            element_colors = _MATRIX_ELEMENT_COLORS[bool(self._dark_mode)]
            color = element_colors.get(element)
            if color is None:
                color = theme['dim_element']
            if state == 'dimmed':
                color = theme['dim_element']
            painter.setFont(self._elem_font)
            painter.setPen(QColor(color))
            box_top = top + diameter + self._elem_gap
            box_center = box_top + self._line_h / 2.0
            ink = QFontMetrics(self._elem_font).tightBoundingRect(element)
            baseline = box_center - (ink.top() + ink.bottom()) / 2.0
            painter.drawText(QPointF(cx - ink.left() - ink.width() / 2.0, baseline), element)

        painter.end()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(int(self.number))
        elif event.button() == Qt.MouseButton.RightButton:
            self.right_clicked.emit(int(self.number))
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        # 不能调用 super()：QWidget 默认实现会把双击再转成一次 mousePressEvent，
        # 导致 clicked 再发一次、把刚刚选中的号码取消掉。
        if event.button() == Qt.MouseButton.LeftButton:
            self.double_clicked.emit(int(self.number))
        event.accept()

    def set_selected(self, selected):
        """选中态（与高亮态正交：2px 强调描边 + 极轻填充，不改卡片几何）"""
        selected = bool(selected)
        if selected != self._selected:
            self._selected = selected
            self.update()

    def set_zodiac(self, zodiac):
        """设置卡片生肖文字并刷新悬浮提示（不重建几何、不触发信号）。

        参数: zodiac (str|None): 生肖名；None/空串按“未绑定”显示为“-”。
        副作用: 仅改写 self.zodiac 与 tooltip 文本，属卡片自身状态。
        """
        self.zodiac = zodiac or ''
        self._update_tooltip()

    def set_element(self, element):
        """设置卡片五行单字并刷新悬浮提示与重绘（不触发信号）。

        参数: element (str|None): 五行名；None/空串按“-”显示。
        副作用: 写 self._element、更新 tooltip 并调用 update()；状态归卡片自身。
        """
        self._element = element or ''
        self._update_tooltip()
        self.update()

    def set_number_color(self, text_color):
        """设置号码文字颜色并请求重绘（不触发信号）。

        参数: text_color (str|None): 颜色字符串；None 时回退 #FF0000。
        副作用: 写 self._text_color 并调用 update()。
        """
        self._text_color = text_color or '#FF0000'
        self.update()

    def set_dark_mode(self, dark_mode):
        """切换卡片暗色配色并请求重绘（不触发信号）。

        参数: dark_mode (bool): True 为暗色主题。
        副作用: 写 self._dark_mode 并调用 update()。
        """
        self._dark_mode = bool(dark_mode)
        self.update()

    def set_display_state(self, state):
        """设置显示状态（normal/emphasis/dimmed），非法值回落 normal 且不重绘。

        参数: state (str): 目标状态；仅在状态变化时写 self._display_state 并 update()。
        副作用: 可能触发一次重绘，不触发信号。
        """
        if state not in ('normal', 'emphasis', 'dimmed'):
            state = 'normal'
        if state != self._display_state:
            self._display_state = state
            self.update()

    def _update_tooltip(self):
        self.setToolTip('号码 ' + str(self.number).zfill(2) +
                        ' ｜ 生肖：' + (self.zodiac or '-') +
                        ' ｜ 五行：' + (self._element or '-'))


class AttributeMatrixPanel(QWidget):
    """生肖页正文矩阵（统一版变体一）：固定 12 生肖表头 + 5×12 圆形号码卡

    结构:
        - 自绘圆角容器（15px 圆角 + 2px 边框）包住表头与卡区；
        - 表头是子控件 ZodiacHighlightBar，12 格宽度 = 列距 P，不随卡区滚动；
        - 49 张卡按「列距 P」手动定位，卡宽 = P - 列距，左右各内缩列距/2，
          因此表头第 N 格中心与第 N 列卡片中心严格共轴；
        - 末排 11 格画虚线空槽，不补位、不可点。

    关键属性:
        number_cards (dict[int, _AttributeMatrixCard]): 号码 → 卡片
        highlight_bar (ZodiacHighlightBar): 固定生肖表头
        number_clicked (pyqtSignal(int)): 单击号码卡时发出号码
    """

    ROWS = MATRIX_ROWS
    COLS = MATRIX_COLS

    number_clicked = pyqtSignal(int)
    # 右键号码卡时发出号码（右键改生肖入口已下线，当前无消费者，保留待恢复）
    number_right_clicked = pyqtSignal(int)
    # 双击号码卡时发出号码（属性矩阵页用于在鼠标位置弹出「改生肖」菜单）
    double_clicked = pyqtSignal(int)
    # 选中集合变化时发出已选号码的有序列表
    selection_changed = pyqtSignal(list)
    # 档位切换导致自动字号变化时发出（profile, 号码 px, 五行 px），
    # 供页面把「号码 PX / 文字 PX」两个角控件同步为实际渲染值（阻塞信号，不反写配置）。
    profile_fonts_changed = pyqtSignal(str, int, int)

    def __init__(self, zodiac_binding=None, elements=None, start_zodiac='龙',
                 dark_mode=False, num_px=None, attr_px=None, parent=None):
        super().__init__(parent)
        self._dark_mode = bool(dark_mode)
        if zodiac_binding is None:
            zodiac_binding = LotteryConfig.generate_zodiac_binding(start_zodiac)
        self._zodiac_binding = dict(zodiac_binding)
        if elements is None:
            elements = LotteryConfig.NUMBER_ELEMENTS
        self._elements = dict(elements)

        base = _MATRIX_PROFILE_COMPACT
        self._num_font = int(num_px) if num_px is not None else base['num_px']
        self._attr_font = int(attr_px) if attr_px is not None else base['attr_px']
        self._custom_fonts = num_px is not None or attr_px is not None
        # 分维度定制标记：拆键后「文字」「号码」可各自独立回到档位默认字号
        self._num_custom = self._custom_fonts
        self._attr_custom = self._custom_fonts
        self._number_colors = None
        self._profile = 'compact'
        self._card_size_override = None
        self._last_profile_fonts = None
        self._highlight_zodiac = None
        self._selected_numbers = set()
        self._metrics = {}
        self._header = None
        self._scroll = None
        self._body = None
        self.number_cards = {}

        self.setMinimumWidth(_MATRIX_PANEL_MIN_WIDTH)
        # 面板占满左栏剩余高度：表头固定，卡区在内部 QScrollArea 里滚动
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._build_ui()
        self._apply_metrics()

    # 构建与几何
    def _build_ui(self):
        """创建固定表头、卡区滚动容器与 49 张卡片；末排空槽由卡区自绘"""
        self._header = ZodiacHighlightBar(
            zodiac_binding=self._zodiac_binding,
            dark_mode=self._dark_mode,
            parent=self,
        )
        self._header.zodiac_selected.connect(self._on_header_selected)

        # 卡区：无边框、透明底，纵向滚动；表头独立于滚动容器，保持固定
        self._scroll = QScrollArea(self)
        self._scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self._scroll.setWidgetResizable(False)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }"
            "QScrollArea > QWidget > QWidget { background: transparent; }"
        )
        self._scroll.viewport().setAutoFillBackground(False)
        self._body = _MatrixBody(self)
        self._scroll.setWidget(self._body)

        for num in range(1, MATRIX_TOTAL + 1):
            card = _AttributeMatrixCard(num, self._body)
            card.set_zodiac(self._zodiac_binding.get(num, ''))
            card.set_element(self._elements.get(num, ''))
            card.clicked.connect(self._on_card_clicked)
            card.right_clicked.connect(self._on_card_right_clicked)
            card.double_clicked.connect(self._on_card_double_clicked)
            self.number_cards[num] = card

    @property
    def highlight_bar(self):
        """固定生肖表头（页面层通过 host.zodiac_highlight_bar 引用）"""
        return self._header

    def _on_header_selected(self, text):
        """表头点击：高亮该生肖号码卡；再次点击同一格恢复全部"""
        self.set_highlight_zodiac(text or None)

    def _on_card_clicked(self, number):
        """单击号码卡：切换选中态并先后发出 number_clicked / selection_changed"""
        number = int(number)
        if number in self._selected_numbers:
            self._selected_numbers.discard(number)
        else:
            self._selected_numbers.add(number)
        card = self.number_cards.get(number)
        if card is not None:
            card.set_selected(number in self._selected_numbers)
        self.number_clicked.emit(number)
        self.selection_changed.emit(self.get_selected_numbers())

    def _on_card_right_clicked(self, number):
        """右键号码卡：透传给页面弹「改生肖」菜单（右键入口已下线，当前无消费者）"""
        self.number_right_clicked.emit(int(number))

    def _on_card_double_clicked(self, number):
        """双击号码卡：先保证该号码处于选中态，再透传给页面弹「改生肖」菜单

        说明:
            Qt 双击事件的顺序是 press→release→dblclick，双击前必然先收到一次
            单击。若该号码本来已选中，这次单击会把它取消；这里补回选中，
            保证「先选中再弹菜单」。选中先于菜单完成，弹菜单失败也不会吞掉选中。
        """
        number = int(number)
        if number not in self._selected_numbers:
            self._selected_numbers.add(number)
            card = self.number_cards.get(number)
            if card is not None:
                card.set_selected(True)
            self.selection_changed.emit(self.get_selected_numbers())
        self.double_clicked.emit(number)

    # 选中集合（与 NumberPanel 同名的跨页 API，供预测页/主窗口直接调用）
    def get_selected_numbers(self):
        """返回当前选中号码（升序列表）"""
        return sorted(self._selected_numbers)

    @property
    def selected_numbers(self):
        """兼容 prediction.py 直接读取的 `number_panel.selected_numbers`（返回副本）"""
        return sorted(self._selected_numbers)

    def set_selected_numbers(self, numbers):
        """整组替换选中号码（1-49 之外的值忽略；不阻断信号）"""
        valid = set()
        for value in (numbers or []):
            try:
                number = int(value)
            except (TypeError, ValueError):
                continue
            if 1 <= number <= MATRIX_TOTAL:
                valid.add(number)
        changed = valid != self._selected_numbers
        self._selected_numbers = valid
        for number, card in self.number_cards.items():
            card.set_selected(number in valid)
        if changed:
            self.selection_changed.emit(self.get_selected_numbers())

    def select_numbers(self, numbers):
        """别名：与 NumberPanel.select_numbers 行为一致（整组替换）"""
        self.set_selected_numbers(numbers)

    def clear_selection(self):
        """清空选中集合"""
        self.set_selected_numbers([])

    def set_button_size(self, scale=1.0, width=None, height=None, font_size=None):
        """兼容旧 NumberPanel.set_button_size 调用（主窗口恢复面板尺寸时使用）

        面板几何由宽度/高度与档位共同决定，这里只把字号透传给 set_font_size，
        不额外落盘，避免启动期产生新的配置写入。
        """
        self.set_font_size(1.0, width, height, font_size, self._attr_font)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self.number_cards:
            self._apply_metrics()

    def sizeHint(self):
        """首选宽高：只提示「表头 + 两排卡」的偏好高度

        本页外层总是套 QScrollArea，若 sizeHint 按完整 5 排卡返回，主窗口会把
        页面撑得比选项卡视口更高，从而出现「整页滚动」，表头也会跟着滚出屏幕。
        这里返回一个较小的偏好高度，让页面收缩到视口内、由面板内部的卡区
        QScrollArea 承担纵向滚动，表头保持固定。
        """
        base = _MATRIX_PROFILE_COMPACT
        pitch = max(base['card_w_min'] + base['gap'],
                    (_MATRIX_PANEL_MIN_WIDTH - 4) // MATRIX_COLS)
        card_w = max(base['card_w_min'], pitch - base['gap'])
        circle = self._even_up(max(1.2 * base['num_px'], base['d_ratio'] * card_w))
        circle = min(circle, self._even_floor(0.8 * card_w))
        line_h = max(base['line_h'], int(round(base['attr_px'] * 1.47)))
        card_h = base['pad'] * 2 + circle + base['elem_gap'] + line_h
        height = 4 + base['header_h'] + base['head_gap'] + \
            2 * card_h + base['row_gap']
        return QSize(_MATRIX_PANEL_MIN_WIDTH, height)

    def minimumSizeHint(self):
        """最小高度只保证「表头 + 一排卡」，其余高度由卡区内部滚动承担"""
        base = _MATRIX_PROFILE_COMPACT
        pitch = max(base['card_w_min'] + base['gap'],
                    (_MATRIX_PANEL_MIN_WIDTH - 4) // MATRIX_COLS)
        card_w = max(base['card_w_min'], pitch - base['gap'])
        circle = self._even_up(max(1.2 * base['num_px'], base['d_ratio'] * card_w))
        circle = min(circle, self._even_floor(0.8 * card_w))
        line_h = max(base['line_h'], int(round(base['attr_px'] * 1.47)))
        card_h = base['pad'] * 2 + circle + base['elem_gap'] + line_h
        height = 4 + base['header_h'] + base['head_gap'] + card_h
        return QSize(_MATRIX_PANEL_MIN_WIDTH, height)

    @staticmethod
    def _even_up(value):
        """向上取到偶数（圆径必须为偶，保证正圆且数字居中）"""
        integer = int(value)
        return integer if integer % 2 == 0 else integer + 1

    @staticmethod
    def _even_floor(value):
        """向下取到偶数"""
        integer = int(value)
        return integer if integer % 2 == 0 else integer - 1

    def _geometry_for_width(self, width, reserve=0):
        """按给定可用宽度试算全部几何（纯计算，不移动控件、不改状态）

        参数:
            width (int): 面板宽度（含 2px 外框）。
            reserve (int): 纵向滚动条预留宽度（0 表示不需要滚动条；
                需要时固定传 _MATRIX_SCROLLBAR_W=12，与 QSS 实际宽度一致）。
        返回:
            (dict, int): 几何字典与卡区内容总高（5 排卡 + 行距）。
        说明:
            卡宽始终由「可用宽度 - 4px 外框 - 预留滚动条」反算，再按列距扣除
            列间距；表头格宽恒等于列距，保证 12 列列轴逐像素对齐。
        """
        profile = 'wide' if width >= _MATRIX_WIDE_MIN_WIDTH else 'compact'
        base = _MATRIX_PROFILE_WIDE if profile == 'wide' else _MATRIX_PROFILE_COMPACT
        gap = int(base['gap'])
        pitch = max(int(base['card_w_min']) + gap,
                    (int(width) - 4 - int(reserve)) // MATRIX_COLS)
        card_w = max(int(base['card_w_min']), pitch - gap)
        # 「尺寸」弹窗的宽度只作为上限参与：卡片不得因用户设成更大而横向溢出
        # 宽度位为 None 表示「卡宽纯自动」，不设上限（auto_width 口径）
        if self._card_size_override is not None and self._card_size_override[0] is not None:
            limit = max(int(base['card_w_min']), int(self._card_size_override[0]))
            card_w = min(card_w, limit)

        num_font = max(15, min(LotteryConfig.TEXT_MAX_PX, int(self._num_font)))
        attr_font = max(15, min(LotteryConfig.TEXT_MAX_PX, int(self._attr_font)))
        # 未显式改过字号时，字号跟随档位（1180 档 28/15，1600 档 34/17）；
        # 用户在「数字/文字 PX」里改过则始终以用户值为准。拆键后按维度分别判断：
        # 某一维度回到 1.0 时，仅该维度回落档位默认值，另一维度保持不变。
        if not self._custom_fonts:
            num_font = int(base['num_px'])
            attr_font = int(base['attr_px'])
        else:
            if not self._num_custom:
                num_font = int(base['num_px'])
            if not self._attr_custom:
                attr_font = int(base['attr_px'])
        line_h = max(int(base['line_h']), int(round(attr_font * 1.47)))
        # 圆径系数：设计稿 §4.4 表格值与 §4.8 的 0.6×卡宽公式互相矛盾
        # （0.6 只得 34/48，做不出 44/60）。这里以定稿表格与参考图为准，
        # 按 44/56、60/80 的实际比例取 0.786/0.75，仍满足「≤0.8×卡宽」上限。
        circle = self._even_up(max(1.2 * num_font, base['d_ratio'] * card_w))
        circle = min(circle, self._even_floor(0.8 * card_w))
        circle = max(2, circle)

        # 卡高 = 上下留白（严格对称）+ 圆径 + 圆字间距 + 五行行高；
        # 高度弹窗作为目标卡高，留白按对称公式分摊，绝不压扁圆。
        pad = int(base['pad'])
        if self._card_size_override is not None and self._card_size_override[1] is not None:
            desired = int(self._card_size_override[1])
            pad = max(pad, (desired - circle - int(base['elem_gap']) - line_h) // 2)
        elem_gap = int(base['elem_gap'])
        card_h = pad * 2 + circle + elem_gap + line_h

        header_h = int(base['header_h'])
        # 需要内部纵向滚动时，容器右侧留出滚动条槽位（表头渐变也覆盖该槽位），
        # 这样滚动条落在容器内、且卡区不被横向裁切。
        table_w = pitch * MATRIX_COLS + 4 + int(reserve)
        body_h = MATRIX_ROWS * card_h + (MATRIX_ROWS - 1) * int(base['row_gap'])
        table_h = 4 + header_h + int(base['head_gap']) + body_h
        metrics = {
            'profile': profile,
            'page_margin': 0,
            'col_gap': gap,
            'row_gap': int(base['row_gap']),
            'card_w': card_w,
            'card_h': card_h,
            'num_band': circle,
            'cap_h': line_h,
            'num_px': num_font,
            'attr_px': attr_font,
            'content_gap': elem_gap,
            'capsule_gap': 0,
            'zodiac_w': card_w,
            'element_w': card_w,
            'pitch': pitch,
            'circle_d': circle,
            'header_h': header_h,
            'head_px': int(base['head_px']),
            'head_gap': int(base['head_gap']),
            'pad': pad,
            'radius': int(base['radius']),
            'table_x': max(0, (int(width) - table_w) // 2),
            'table_y': 0,
            'table_w': table_w,
            'table_h': table_h,
            'inset_x': (pitch - card_w) // 2,
            'body_h': body_h,
            'scrollbar_reserve': int(reserve),
        }
        return metrics, body_h

    def _apply_metrics(self):
        """按当前面板宽高反算列距/卡宽/圆径/字号，并重新定位表头与卡区"""
        width = max(1, self.width())
        height = max(1, self.height())

        metrics, body_h = self._geometry_for_width(width)
        header_h = int(metrics['header_h'])
        head_gap = int(metrics['head_gap'])
        body_top = 2 + header_h + head_gap
        viewport_h = max(1, height - body_top - 2)

        # 卡区高于可视区时只加纵向滚动条，绝不压缩圆径：先按固定 12px 槽位
        # （_MATRIX_SCROLLBAR_W，与全局 QSS 实际宽度一致）预留，再按变窄后的
        # 宽度重算列距/卡宽，保证表头与卡区仍然同轴，且不同机器结果一致。
        reserve = 0
        if body_h > viewport_h:
            reserve = _MATRIX_SCROLLBAR_W
            metrics, body_h = self._geometry_for_width(width, reserve)

        self._profile = metrics['profile']
        self._num_font = int(metrics['num_px'])
        self._attr_font = int(metrics['attr_px'])
        self._metrics = metrics

        pitch = int(metrics['pitch'])
        card_w = int(metrics['card_w'])
        card_h = int(metrics['card_h'])
        circle = int(metrics['circle_d'])
        pad = int(metrics['pad'])
        elem_gap = int(metrics['content_gap'])
        line_h = int(metrics['cap_h'])
        row_gap = int(metrics['row_gap'])
        table_x = int(metrics['table_x'])
        radius = int(metrics['radius'])
        num_font = int(metrics['num_px'])
        attr_font = int(metrics['attr_px'])
        head_px = int(metrics['head_px'])
        inset = int(metrics['inset_x'])

        self._header.apply_geometry(pitch, header_h, head_px)
        self._header.setGeometry(table_x + 2, 2, pitch * MATRIX_COLS + reserve, header_h)

        scroll_x = table_x + 2
        scroll_w = min(pitch * MATRIX_COLS + reserve, max(1, width - scroll_x - 2))
        self._scroll.setGeometry(scroll_x, body_top, max(1, scroll_w),
                                 max(1, height - body_top - 2))
        self._body.setFixedSize(pitch * MATRIX_COLS, body_h)
        self._body.move(0, 0)

        step_y = card_h + row_gap
        for num, card in self.number_cards.items():
            row = (num - 1) // MATRIX_COLS
            col = (num - 1) % MATRIX_COLS
            card.set_dark_mode(self._dark_mode)
            card.apply_geometry(card_w, card_h, circle, pad, elem_gap, line_h,
                                radius, num_font, attr_font)
            card.move(col * pitch + inset, row * step_y)

        self._restyle_numbers()
        signature = (self._profile, int(metrics['num_px']), int(metrics['attr_px']))
        if signature != self._last_profile_fonts:
            self._last_profile_fonts = signature
            self.profile_fonts_changed.emit(*signature)
        self.update()
        if self._body is not None:
            self._body.update()

    # 数据同步
    def _resolve_number_color(self, number):
        """号码波色：自定义覆盖优先，否则读全局 LotteryConfig"""
        if self._number_colors is not None:
            colors = self._number_colors.get(number, {'text': '#FF0000'})
        else:
            colors = LotteryConfig.get_number_color(number)
        return colors.get('text', '#FF0000')

    def _restyle_numbers(self):
        for number, card in self.number_cards.items():
            card.set_number_color(self._resolve_number_color(number))

    def refresh_number_colors(self, colors=None):
        """应用自定义号码颜色（与全窗口改色链路一致）"""
        self._number_colors = dict(colors) if colors is not None else None
        self._restyle_numbers()

    def set_dark_mode(self, dark_mode):
        """切换矩阵面板暗色主题：同步全部卡片与表头并重绘。

        参数: dark_mode (bool): True 为暗色主题。
        副作用: 写 self._dark_mode、逐卡/表头 set_dark_mode、重新计算号码色并 update()；不发信号。
        """
        self._dark_mode = bool(dark_mode)
        for card in self.number_cards.values():
            card.set_dark_mode(self._dark_mode)
        if self._header is not None:
            self._header.set_dark_mode(self._dark_mode)
        self._restyle_numbers()
        self.update()

    def set_font_size(self, scale=1.0, width=None, height=None,
                      btn_font=None, label_font=None,
                      custom_fonts=None, auto_width=False,
                      num_custom=None, attr_custom=None):
        """设置卡片尺寸与号码/五行字号（签名与旧面板保持一致）

        width 只作为卡片宽度上限（防止横向溢出），height 作为目标卡高
        （留白按上下对称分摊）。传入紧凑档默认值 90×98/28/15 视为未定制。
        custom_fonts 由页面显式传入「用户是否改过字号」：True 时严格按传入
        字号渲染，不再被宽档默认值（34/17）顶替；None 时退回旧式数值推断。
        auto_width=True 表示卡宽永远按可用宽度反算（12 列共轴），override
        只保存高度，避免把当前实测宽写死成上限。
        """
        base = _MATRIX_PROFILE_COMPACT
        target_btn = base['num_px'] if btn_font is None else int(btn_font)
        target_attr = base['attr_px'] if label_font is None else int(label_font)
        self._num_font = target_btn
        self._attr_font = target_attr
        if auto_width:
            target_h = None if height is None else max(70, min(300, int(height)))
            self._card_size_override = (
                None if (target_h is None or target_h == 98) else (None, target_h))
        elif width is not None or height is not None:
            current = self._card_size_override or (
                self._metrics.get('card_w', base['card_w_min']),
                self._metrics.get('card_h', 88))
            current_w = (int(current[0]) if current[0]
                         else int(self._metrics.get('card_w', base['card_w_min'])))
            current_h = (int(current[1]) if current[1]
                         else int(self._metrics.get('card_h', 88)))
            target_w = max(30, min(220, int(width) if width is not None else current_w))
            target_h = max(70, min(300, int(height) if height is not None else current_h))
            if (target_w, target_h) == (90, 98):
                self._card_size_override = None
            else:
                self._card_size_override = (target_w, target_h)
        if custom_fonts is None:
            self._custom_fonts = (
                target_btn != base['num_px'] or target_attr != base['attr_px']
            )
        else:
            self._custom_fonts = bool(custom_fonts)
        # 分维度定制标记：None 时与整体标记一致，保持旧调用点行为不变；
        # 显式传入时允许「文字 1.0 / 号码 1.5」这类单维度定制。
        if num_custom is None:
            self._num_custom = self._custom_fonts
        else:
            self._num_custom = bool(num_custom)
        if attr_custom is None:
            self._attr_custom = self._custom_fonts
        else:
            self._attr_custom = bool(attr_custom)
        self._apply_metrics()

    def set_zodiac_binding(self, zodiac_binding):
        """整体替换号码→生肖绑定并同步卡片、表头与高亮状态。

        参数: zodiac_binding (dict[int,str]): 号码→生肖映射；内部复制一份，不持有外部引用。
        副作用: 写 self._zodiac_binding，逐卡 set_zodiac、表头 refresh_binding，并重算高亮；不发信号。
        """
        self._zodiac_binding = dict(zodiac_binding)
        for number, card in self.number_cards.items():
            card.set_zodiac(self._zodiac_binding.get(number, ''))
        if self._header is not None:
            self._header.refresh_binding(self._zodiac_binding)
        self._apply_highlight_states()

    def update_all_zodiacs(self, zodiacs_dict):
        """批量更新全部号码生肖（兼容旧调用名的薄封装）。

        参数: zodiacs_dict (dict[int,str]): 号码→生肖映射。
        副作用: 等价于 set_zodiac_binding，会同步卡片/表头/高亮。
        """
        self.set_zodiac_binding(zodiacs_dict)

    def update_zodiac(self, num, zodiac):
        """更新单个号码的生肖并同步表头与高亮；号码越界时静默返回。

        参数: num (int): 号码 1..49；zodiac (str|None): 新生肖。
        副作用: 写 self._zodiac_binding[num]、单卡 set_zodiac、表头刷新与高亮重算。
        """
        number = int(num)
        if number not in self.number_cards:
            return
        self._zodiac_binding[number] = zodiac or ''
        self.number_cards[number].set_zodiac(zodiac)
        if self._header is not None:
            self._header.refresh_binding(self._zodiac_binding)
        self._apply_highlight_states()

    def set_elements(self, elements):
        """整体替换号码→五行映射并同步全部卡片文字。

        参数: elements (dict[int,str]): 号码→五行映射；内部复制。
        副作用: 写 self._elements 并逐卡 set_element；不发信号。
        """
        self._elements = dict(elements)
        for number, card in self.number_cards.items():
            card.set_element(self._elements.get(number, ''))

    def update_all_elements(self, elements_dict):
        """批量更新全部号码五行（兼容旧调用名的薄封装）。

        参数: elements_dict (dict[int,str]): 号码→五行映射。
        副作用: 等价于 set_elements。
        """
        self.set_elements(elements_dict)

    def get_legend_colors(self):
        """底栏波色图例的文字色（仅文字；圆形波色填充仍用原红 #FF0000）

        红波原 #FF0000 作文字在白底仅 4.0:1，这里换成亮色 #C62828（5.62:1）与
        暗色 #F87171（5.93:1），保证 15px 文字满足 ≥4.5:1。
        """
        if self._dark_mode:
            return {'红': '#F87171', '蓝': '#89B4FA', '绿': '#A6E3A1'}
        return {'红': '#C62828', '蓝': '#0000FF', '绿': '#008000'}

    def set_highlight_zodiac(self, zodiac=None):
        """设置被强调的生肖（None 取消强调），并同步表头高亮与卡片明暗。

        参数: zodiac (str|None): 生肖名；不在 MATRIX_ZODIAC_ORDER 内按 None 处理。
        副作用: 写 self._highlight_zodiac、必要时更新表头 active 状态并重算卡片显示态。
        """
        target = zodiac if zodiac in MATRIX_ZODIAC_ORDER else None
        self._highlight_zodiac = target
        if self._header is not None and self._header.active_zodiac() != target:
            self._header.set_active_zodiac(target)
        self._apply_highlight_states()

    def _apply_highlight_states(self):
        target = self._highlight_zodiac
        for card in self.number_cards.values():
            if target is None:
                state = 'normal'
            elif card.zodiac == target:
                state = 'emphasis'
            else:
                state = 'dimmed'
            card.set_display_state(state)

    # 自绘：容器 / 列网格 / 末排空槽
    def paintEvent(self, event):
        """只画表格外框、底板与投影；卡区内容由 _MatrixBody 负责"""
        metrics = self._metrics
        if not metrics:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        theme = _MATRIX_THEMES[bool(self._dark_mode)]
        x = int(metrics['table_x'])
        y = int(metrics['table_y'])
        w = int(metrics['table_w'])
        h = max(2, self.height())

        # 表格投影：三层轻投影，避免与容器边框形成硬边
        painter.setPen(Qt.PenStyle.NoPen)
        for offset, alpha in ((3, 8), (2, 10), (1, 12)):
            painter.setBrush(QColor(0, 0, 0, alpha))
            painter.drawRoundedRect(QRectF(x, y + offset, w, h - 2), 15, 15)

        # 容器底板与 2px 边框（表头与卡区共用同一外框）
        painter.setBrush(QColor(theme['container_bg']))
        painter.setPen(QPen(QColor(theme['container_border']), 2))
        painter.drawRoundedRect(QRectF(x + 1, y + 1, w - 2, h - 2), 15, 15)
        painter.end()

    def _paint_body(self, body):
        """卡区自绘：1px 弱列网格线 + 末排 11 个虚线空槽（随卡区一起滚动）

        坐标以卡区左上角为原点；列网格线画在 x = n × 列距，恰好落在第 n 列
        与第 n+1 列卡片的间隙中轴，与表头 2px 分隔线同轴。
        """
        metrics = self._metrics
        if not metrics:
            return
        painter = QPainter(body)
        theme = _MATRIX_THEMES[bool(self._dark_mode)]
        pitch = int(metrics['pitch'])
        card_w = int(metrics['card_w'])
        card_h = int(metrics['card_h'])
        row_gap = int(metrics['row_gap'])
        inset = int(metrics['inset_x'])
        body_h = int(metrics['body_h'])
        radius = int(metrics['radius'])

        # 1px 弱列网格线：贯通卡区到末排，强化 12 列列轴
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(theme['grid']))
        for index in range(1, MATRIX_COLS):
            painter.fillRect(index * pitch, 0, 1, body_h, QColor(theme['grid']))

        # 末排 11 个虚线空槽（不补位、不可点）
        empty_pen = QPen(QColor(theme['empty_line']), 1, Qt.PenStyle.DashLine)
        empty_font = QFont(FontUtils.get_default_font_family())
        empty_font.setPixelSize(15)
        empty_font.setBold(True)
        last_row_top = (MATRIX_ROWS - 1) * (card_h + row_gap)
        for col in range(1, MATRIX_COLS):
            slot = QRect(col * pitch + inset, last_row_top, card_w, card_h)
            painter.setPen(empty_pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(slot.adjusted(0, 0, -1, -1), radius, radius)
            painter.setFont(empty_font)
            painter.setPen(QColor(theme['empty_text']))
            painter.drawText(slot, Qt.AlignmentFlag.AlignCenter, '-')
        painter.end()


class ZodiacHighlightBar(QWidget):
    """固定 12 生肖表头条（统一版变体一）

    135° 渐变（#5566D6 → #764BA2）+ 白字；2px #5A67D8 单元格边框；
    首末列顶角随容器圆角裁切。选中格为实心 #4A3391 + 2px #A5B4FC 描边。
    点击：选中该生肖；再次点击同一格取消。悬停显示「马 · 5 个号码：...」。
    """

    zodiac_selected = pyqtSignal(str)

    def __init__(self, zodiac_binding=None, dark_mode=False, parent=None):
        super().__init__(parent)
        self._bindings = dict(zodiac_binding or {})
        self._dark_mode = bool(dark_mode)
        self._active = None
        self._hover = -1
        self._order = _matrix_header_order(self._bindings)
        self._cell_w = 62
        self._header_h = 54
        self._font_px = 15
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.setFixedHeight(self._header_h)

    # 几何与数据
    def apply_geometry(self, cell_w, header_h, font_px):
        """面板下发列距（=表头格宽）、表头高与字号"""
        self._cell_w = max(1, int(cell_w))
        self._header_h = max(1, int(header_h))
        self._font_px = max(15, int(font_px))
        self.setFixedHeight(self._header_h)
        self.update()

    def refresh_binding(self, zodiac_binding):
        """更新号码→生肖绑定：重算表头顺序与悬停提示"""
        self._bindings = dict(zodiac_binding or {})
        order = _matrix_header_order(self._bindings)
        if order != self._order:
            self._order = order
        if self._active not in self._order:
            self._active = None
        self.update()

    def set_dark_mode(self, dark_mode):
        """切换表头暗色配色并请求重绘（不触发信号）。

        参数: dark_mode (bool): True 为暗色主题。
        副作用: 写 self._dark_mode 并 update()。
        """
        self._dark_mode = bool(dark_mode)
        self.update()

    def set_active_zodiac(self, zodiac=None):
        """设置表头当前高亮生肖（None 取消），仅在变化时重绘。

        参数: zodiac (str|None): 生肖名；不在当前顺序内按 None 处理。
        副作用: 可能写 self._active 并 update()。
        """
        target = zodiac if zodiac in self._order else None
        if target != self._active:
            self._active = target
            self.update()

    def active_zodiac(self):
        """返回表头当前高亮的生肖（只读，无副作用）。

        返回: str|None: 当前 active 生肖；无高亮时为 None。
        """
        return self._active

    def _numbers_of(self, zodiac):
        return [num for num in range(1, MATRIX_TOTAL + 1)
                if self._bindings.get(num) == zodiac]

    # 交互
    def _index_at(self, pos):
        if self._cell_w <= 0:
            return -1
        index = int(pos.x()) // self._cell_w
        return index if 0 <= index < len(self._order) else -1

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            index = self._index_at(event.position())
            if index >= 0:
                name = self._order[index]
                if self._active == name:
                    self._active = None
                    self.zodiac_selected.emit('')
                else:
                    self._active = name
                    self.zodiac_selected.emit(name)
                self.update()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        index = self._index_at(event.position())
        if index != self._hover:
            self._hover = index
            self.update()
        if index >= 0:
            name = self._order[index]
            numbers = self._numbers_of(name)
            text = name + ' · ' + str(len(numbers)) + ' 个号码'
            if numbers:
                text += '：' + ' '.join(str(num).zfill(2) for num in numbers)
            QToolTip.showText(event.globalPosition().toPoint(), text, self)
        super().mouseMoveEvent(event)

    def leaveEvent(self, event):
        self._hover = -1
        self.update()
        super().leaveEvent(event)

    # 自绘
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        tokens = _MATRIX_HEADER_TOKENS
        # 宽度取控件实际宽度：有内部滚动条时右侧会多出滚动条槽位，
        # 表头渐变覆盖该槽位，表头与容器右上角保持齐平。
        width = self.width()
        height = self._header_h

        # 用「渐变画刷 + 圆角矩形」代替裁剪路径：既得到同款 135° 渐变与
        # 首末列顶角圆角，也避开 QPainterPath 裁剪叠加文字时 Windows 字体引擎
        # 在部分宽度下的原生崩溃（实测边界问题）。
        gradient = QLinearGradient(0, 0, width, height)
        gradient.setColorAt(0.0, QColor(tokens['grad_from']))
        gradient.setColorAt(1.0, QColor(tokens['grad_to']))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(gradient))
        # 首末列顶角 10px 圆角（设计稿 §4.2/参考表 th 的 border-radius:10px）
        painter.drawRoundedRect(QRectF(0, 0, width, height), 10, 10)

        # 2px 单元格边框（贯穿到表头底边）
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(tokens['separator']))
        for index in range(1, len(self._order)):
            painter.fillRect(index * self._cell_w - 1, 0, 2, height,
                             QColor(tokens['separator']))
        painter.fillRect(0, height - 2, width, 2, QColor(tokens['separator']))

        # 悬停：格顶 1px 亮线
        if 0 <= self._hover < len(self._order):
            painter.fillRect(self._hover * self._cell_w + 1, 0,
                             self._cell_w - 2, 1, QColor(tokens['hover_line']))

        # 选中态：实心底 + 2px 描边；首/末格与容器内沿共用圆角
        if self._active in self._order:
            index = self._order.index(self._active)
            selected = QRectF(index * self._cell_w, 0,
                              self._cell_w, height).adjusted(1, 1, -1, -3)
            radius = 9 if index == 0 else 0
            radius_right = 9 if index == len(self._order) - 1 else 0
            path = _matrix_rounded_cell_path(selected, radius, radius_right)
            painter.setBrush(QColor(tokens['selected_bg']))
            painter.setPen(QPen(QColor(tokens['selected_border']), 2))
            painter.drawPath(path)

        painter.setClipping(False)

        font = QFont(FontUtils.get_default_font_family())
        font.setPixelSize(self._font_px)
        font.setBold(True)
        font.setWeight(QFont.Weight.Bold)
        painter.setFont(font)
        painter.setPen(QColor(tokens['text']))
        for index, name in enumerate(self._order):
            painter.drawText(QRect(index * self._cell_w, 0,
                                   self._cell_w, height),
                             Qt.AlignmentFlag.AlignCenter, name)
        painter.end()


# StatisticsChart
class StatisticsChart(QWidget):
    """基于 matplotlib 的统计图表控件（单 Figure 复用）

    职责:
        承载一张 8×6 英寸的 Figure 与可嵌入 Qt 的 FigureCanvas，向页面提供
        频率、遗漏、饼图、走势、热力图、间隔、连号概率、和值分布等绘图方法。
        每个 plot_xxx() 都会先 figure.clear() 再重绘，始终复用同一个画布。
        其中共现热力图（sns.heatmap）与和值直方图（sns.histplot）优先走
        seaborn，seaborn 缺失时自动回退原 matplotlib 实现。

    关键属性:
        figure (Figure | None): matplotlib Figure；matplotlib 未安装时为 None。
        canvas (FigureCanvasQTAgg | None): Qt 画布控件；与 figure 同时为 None
            或同时非 None，页面需按 None 判空跳过绘图。

    信号:
        无；本控件只负责绘制，不做交互。

    生命周期:
        页面创建一次，多次调用不同 plot_xxx() 切换图表内容；不主动销毁 Figure。

    约束:
        - matplotlib 只能经 lib.plot_draw 访问器获取，禁止直接 import；
        - 绘图方法不抛异常给页面（matplotlib 缺失时静默返回/绘制“暂无数据”）；
        - 字号统一 15px，与全局最小字号保持一致。
    """
    
    def __init__(self, parent=None):
        """初始化 Figure/Canvas 并放入垂直布局

        功能:
            初始化 Figure/Canvas 并放入垂直布局

        参数:
            parent (QWidget | None): Qt 父控件。

        返回:
            None

        副作用:
            触发 lib.plot_draw 的 matplotlib 懒加载；成功时创建
            Figure(figsize=(8, 6)) 与 FigureCanvas 子控件，失败时两个属性均为 None。

        说明:
            通过 get_figure_module()/get_canvas_class() 拿类而不是直接 import，
            保证与 lib 中已初始化的 QtAgg 后端共用同一实例，也便于缺失时降级。
        """
        super().__init__(parent)
        _get_mpl()
        # 【规范】matplotlib对象经lib.plot_draw访问器函数获取，无需global声明
        if get_figure_module() is not None and get_canvas_class() is not None:
            self.figure = get_figure_module()(figsize=(8, 6))
            self.canvas = get_canvas_class()(self.figure)
        else:
            self.figure = None
            self.canvas = None
        layout = QVBoxLayout(self)
        if self.canvas is not None:
            layout.addWidget(self.canvas)
        self.setLayout(layout)
    
    # ── H54 暗色主题：Figure/Axes 配色随主题切换 ──────────────────────────
    def _is_dark_theme(self):
        """按宿主窗口的 is_dark_mode 判断当前主题（未挂载时按亮色）"""
        window = self.window()
        return bool(getattr(window, 'is_dark_mode', False))

    def apply_theme(self, dark=None):
        """把 Figure/Axes 的底、刻度、标签、网格、标题颜色回套到当前主题

        功能:
            暗色主题下把 matplotlib 画布从白底改为 #1E1E2E 底 / #F5F5F5 字 /
            #7F849C 轴 / #45475A 网格；亮色主题恢复 matplotlib 默认白底黑字。

        参数:
            dark (bool | None): 显式指定主题；None 时读宿主窗口 is_dark_mode。

        返回:
            None。

        说明:
            亮色分支写入的都是 matplotlib 默认值（白底、黑字、#B0B0B0 网格），
            因此亮色渲染结果与修复前逐像素一致；本方法不重建 Figure、不重算数据。
        """
        if self.figure is None:
            return
        if dark is None:
            dark = self._is_dark_theme()
        if dark:
            fig_bg, ax_bg, fg = '#1E1E2E', '#1E1E2E', '#F5F5F5'
            spine_color, grid_color = '#7F849C', '#45475A'
        else:
            fig_bg, ax_bg, fg = 'white', 'white', 'black'
            spine_color, grid_color = 'black', '#B0B0B0'
        self.figure.set_facecolor(fig_bg)
        for ax in self.figure.get_axes():
            ax.set_facecolor(ax_bg)
            ax.tick_params(axis='both', which='both', colors=fg)
            for spine in ax.spines.values():
                spine.set_color(spine_color)
            if ax.title is not None:
                ax.title.set_color(fg)
            ax.xaxis.label.set_color(fg)
            ax.yaxis.label.set_color(fg)
            for text in ax.texts:
                text.set_color(fg)
            legend = ax.get_legend()
            if legend is not None:
                for text in legend.get_texts():
                    text.set_color(fg)
            for line in ax.get_xgridlines() + ax.get_ygridlines():
                line.set_color(grid_color)

    def redraw(self):
        """先回套当前主题配色，再刷新画布"""
        if self.canvas is None:
            return
        self.apply_theme()
        self.canvas.draw()

    def plot_frequency(self, frequency, title="数字出现频率"):
        """绘制各号码出现次数柱状图

        功能:
            绘制各号码出现次数柱状图

        参数:
            frequency (dict[int, int]): 号码 → 出现次数；键会排序后作为 x 轴。
            title (str): 图表标题。

        返回:
            None

        副作用:
            清空并重绘 figure；柱色按 LotteryConfig 的红/蓝/绿波色区分，
            柱顶标注具体次数，最后调用 canvas.draw() 刷新界面。

        异常:
            matplotlib 缺失（self.figure 为 None）时直接返回，不抛出。
        """
        if self.figure is None:
            return
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        numbers = sorted(frequency.keys())
        counts = [frequency[n] for n in numbers]
        colors = []
        for num in numbers:
            if LotteryConfig.is_red(num):
                colors.append('#FF0000')
            elif LotteryConfig.is_blue(num):
                colors.append('#0000FF')
            else:
                colors.append('#008000')
        bars = ax.bar(numbers, counts, color=colors, edgecolor='white', linewidth=0.5)
        ax.set_xlabel('数字', fontsize=15)
        ax.set_ylabel('出现次数', fontsize=15)
        ax.set_title(title, fontsize=15, fontweight='bold')
        ax.set_xticks(numbers)
        ax.grid(axis='y', alpha=0.3)
        for bar, count in zip(bars, counts):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2., height, str(int(height)), ha='center', va='bottom', fontsize=15)
        self.redraw()
    
    def plot_missing(self, missing, title="数字遗漏值"):
        """绘制各号码遗漏期数柱状图

        功能:
            绘制各号码遗漏期数柱状图

        参数:
            missing (dict[int, int]): 号码 → 遗漏期数；键会排序后作为 x 轴。
            title (str): 图表标题。

        返回:
            None

        副作用:
            清空并重绘 figure；颜色用 RdYlGn_r 色图按遗漏值高低映射
            （遗漏越久颜色越暖），色图不可用时退回单色 #3498db，
            最后 canvas.draw() 刷新。

        异常:
            matplotlib 缺失时直接返回；TODO(待确认): missing 为空字典时
            min(values)/max(values) 会抛 ValueError，调用方需保证至少一个号码。
        """
        if self.figure is None:
            return
        _get_mpl()
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        numbers = sorted(missing.keys())
        values = [missing[n] for n in numbers]
        if get_pyplot_module() is not None:
            cmap = get_pyplot_module().cm.RdYlGn_r
            norm = get_pyplot_module().Normalize(vmin=min(values), vmax=max(values))
        else:
            cmap = None
            norm = None
        if cmap is not None and norm is not None:
            colors = [cmap(norm(v)) for v in values]
        else:
            colors = '#3498db'
        ax.bar(numbers, values, color=colors, edgecolor='white', linewidth=0.5)
        ax.set_xlabel('数字', fontsize=15)
        ax.set_ylabel('遗漏期数', fontsize=15)
        ax.set_title(title, fontsize=15, fontweight='bold')
        ax.set_xticks(numbers)
        ax.grid(axis='y', alpha=0.3)
        self.redraw()
    
    def plot_distribution(self, data, title="分布统计"):
        """绘制饼图分布统计 —— 展示各分类（如波色/单双/大小）的占比分布

        功能:
            绘制饼图分布统计 —— 展示各分类（如波色/单双/大小）的占比分布

        参数:
            data (dict[str, int|float]): 分类名称 → 计数值；饼图按比例显示占比。
            title (str): 图表标题。

        返回:
            None

        副作用:
            清空并重绘 figure；分类文字与百分比文字统一 15px，百分比为白色粗体，
            最后 canvas.draw() 刷新界面。
        """
        # 【修复空值bug】matplotlib加载失败时figure为None，直接clear会AttributeError
        if self.figure is None or self.canvas is None:
            return
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        labels = list(data.keys())
        values = list(data.values())
        colors = ['#FF0000', '#0000FF', '#008000', '#F39C12', '#9B59B6']
        wedges, texts, autotexts = ax.pie(values, labels=labels, colors=colors[:len(labels)], autopct='%1.1f%%', startangle=90)
        for text in texts:
            text.set_fontsize(15)
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
        ax.set_title(title, fontsize=15, fontweight='bold')
        self.redraw()
    
    def plot_trend(self, data, title="综合走势图"):
        """绘制趋势散点图 —— 展示每期号码分布走势，红/蓝/绿三色区分波色

        功能:
            绘制趋势散点图 —— 展示每期号码分布走势，红/蓝/绿三色区分波色

        参数:
            data (list[tuple[int|str, list[int]]]): 每项为 (期号, 该期号码列表)；
                仅取前 50 期绘制，避免点数过多导致卡顿。
            title (str): 图表标题。

        返回:
            None

        副作用:
            清空并重绘 figure；x 轴为列表下标（不是期号），y 轴为号码值，
            每 5 期显示一个期号标签并旋转 45°，最后 canvas.draw() 刷新。
        """
        # 【修复空值bug】matplotlib加载失败时figure为None，直接clear会AttributeError
        if self.figure is None or self.canvas is None:
            return
        self.figure.clear()
        fig = self.figure
        if len(data) > 0:
            periods = [item[0] for item in data[:50]]
            numbers_list = [item[1] for item in data[:50]]
            ax = fig.add_subplot(111)
            for i, numbers in enumerate(numbers_list):
                for num in numbers:
                    color = '#FF0000'
                    if LotteryConfig.is_blue(num):
                        color = '#0000FF'
                    elif LotteryConfig.is_green(num):
                        color = '#008000'
                    ax.plot(i, num, 'o', color=color, markersize=6)
            ax.set_xlabel('期数', fontsize=15)
            ax.set_ylabel('号码', fontsize=15)
            ax.set_title(title, fontsize=15, fontweight='bold')
            ax.set_ylim(0, 50)
            ax.set_xticks(range(0, len(periods), 5))
            ax.set_xticklabels([periods[i] for i in range(0, len(periods), 5)], rotation=45)
            ax.grid(True, alpha=0.3)
        fig.tight_layout()
        self.redraw()
    
    def plot_correlation_heatmap(self, data, title="号码相关性热力图"):
        """绘制 49×49 号码共现矩阵热力图

        功能:
            绘制 49×49 号码共现矩阵热力图

        参数:
            data (numpy.ndarray | None): 已由 lib.data_process.cooccurrence_to_matrix
                构造好的共现矩阵；None/空矩阵绘制“暂无数据”占位。
            title (str): 图表标题。

        返回:
            None

        副作用:
            清空并重绘 figure；添加颜色条（共现次数），刻度每 5 个号码显示一次，
            最后 tight_layout() + canvas.draw() 刷新。

        异常:
            无；matplotlib 缺失（figure/canvas 为 None）时直接返回。

        说明:
            字典→矩阵的转换已下沉到 lib/data_process.py，本控件不再保留第二套实现。
        """
        # matplotlib 缺失时 figure/canvas 为 None，直接降级返回
        if self.figure is None or self.canvas is None:
            return
        np = get_numpy()  # 界面层不直接导入 numpy，统一从 lib 导出
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        # data 已是 49x49 的 numpy 共现矩阵
        if data is not None and isinstance(data, np.ndarray) and data.shape[0] > 0:
            sns = get_seaborn_module()
            if sns is not None:
                # seaborn 分支：同一 49×49 矩阵、同一 YlOrRd 色阶与 0.8 颜色条。
                # 不调用 sns.set_theme / sns.set_style，避免覆盖全局中文字体与白底画布。
                sns.heatmap(
                    data, ax=ax, cmap='YlOrRd', linewidths=0,
                    cbar_kws={'shrink': 0.8},
                )
                # 颜色条标签字号统一回到全局 15px（seaborn 默认 10px）
                if len(self.figure.axes) > 1:
                    self.figure.axes[-1].set_ylabel('共现次数', fontsize=15)
            else:
                # 降级分支（HAS_SNS=False）：保持接入前的 matplotlib imshow 写法
                im = ax.imshow(data, cmap='YlOrRd', aspect='auto')
                # 添加颜色条
                cbar = self.figure.colorbar(im, ax=ax, shrink=0.8)
                cbar.set_label('共现次数', fontsize=15)
            # 两种分支共用：刻度标签每 5 个号码显示一次（seaborn 默认会显示 1..49 全部）
            # rotation=0 恢复接入前水平刻度：seaborn 会按标签密度自动旋转 45°/90°
            tick_positions = list(range(0, 49, 5))
            tick_labels = [str(i+1) for i in tick_positions]
            ax.set_xticks(tick_positions)
            ax.set_xticklabels(tick_labels, rotation=0)
            ax.set_yticks(tick_positions)
            ax.set_yticklabels(tick_labels, rotation=0)
            ax.set_xlabel('号码', fontsize=15)
            ax.set_ylabel('号码', fontsize=15)
            ax.set_title(title, fontsize=15, fontweight='bold')
        else:
            ax.text(0.5, 0.5, '暂无数据', ha='center', va='center', fontsize=15)
            ax.set_title(title, fontsize=15, fontweight='bold')
        self.figure.tight_layout()
        self.redraw()
    
    def plot_interval_analysis(self, data, title="号码间隔分析图"):
        """绘制高频号码出现间隔分布的箱线图

        功能:
            绘制高频号码出现间隔分布的箱线图

        参数:
            data (list[tuple[int, list[int]]]): 号码 → 历次出现间隔列表，
                已由 lib.data_process.select_top_interval_samples 按样本数降序
                取前 15 个号码；本控件只按该顺序绘图。
            title (str): 图表标题。

        返回:
            None

        副作用:
            清空并重绘 figure；箱体使用柔和配色（5 色循环）并设置 0.7 透明度；
            x 轴标签旋转 45°；数据为空时绘制“暂无数据”提示，
            最后 tight_layout() + canvas.draw() 刷新。

        说明:
            matplotlib 3.9+ 的 boxplot 参数由 labels 改名为 tick_labels，
            因此先试新名，TypeError 时回退旧名，兼容不同版本。
            Top15 选取已下沉到 lib/data_process.py，本控件不再重复排序。
        """
        if self.figure is None:
            return
        _get_mpl()
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        # data 格式: [(号码, [间隔列表]), ...]，顺序由 lib 决定
        if data:
            numbers = [str(item[0]) for item in data]
            intervals = [item[1] for item in data]
            
            # matplotlib 3.9+ 将 boxplot 的 labels 参数改名为 tick_labels，旧版本仍用 labels
            try:
                bp = ax.boxplot(intervals, tick_labels=numbers, patch_artist=True)
            except TypeError:
                bp = ax.boxplot(intervals, labels=numbers, patch_artist=True)
            # 设置箱线图颜色
            colors = ['#FFB6C1', '#87CEEB', '#98FB98', '#DDA0DD', '#F0E68C'] * 3
            for patch, color in zip(bp['boxes'], colors):
                patch.set_facecolor(color)
                patch.set_alpha(0.7)
            
            ax.set_xlabel('高频号码', fontsize=15)
            ax.set_ylabel('间隔期数', fontsize=15)
            ax.set_title(title, fontsize=15, fontweight='bold')
            ax.grid(axis='y', alpha=0.3)
            # 旋转x轴标签
            if get_pyplot_module() is not None:
                get_pyplot_module().setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
        else:
            ax.text(0.5, 0.5, '暂无数据（需要至少20期历史数据）', ha='center', va='center', fontsize=15)
            ax.set_title(title, fontsize=15, fontweight='bold')
        self.figure.tight_layout()
        self.redraw()
    
    def plot_consecutive_probability(self, data, title="连号邻号概率图"):
        """绘制连号 / 邻号 / 同尾数出现概率柱状图

        功能:
            绘制连号 / 邻号 / 同尾数出现概率柱状图

        参数:
            data (dict[str, dict]): 可含 'consecutive'、'adjacent'、'same_tail' 三个键，
                每个值为 {'avg_prob': float, ...}；avg_prob 会换算成百分比。
            title (str): 图表标题。

        返回:
            None

        副作用:
            清空并重绘 figure；柱顶标注一位小数的百分比；数据缺失时绘制
            “暂无数据”占位，最后 tight_layout() + canvas.draw() 刷新。
        """
        # 【修复空值bug】matplotlib加载失败时figure为None，直接clear会AttributeError
        if self.figure is None or self.canvas is None:
            return
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        # data格式: {'consecutive': {'pairs': [[n1,n2]: count, ...], 'avg_prob': float}, 'adjacent': {...}}
        if data and isinstance(data, dict):
            categories = []
            probabilities = []
            colors = []
            
            # 连号数据
            if 'consecutive' in data:
                consecutive_data = data['consecutive']
                avg_prob = consecutive_data.get('avg_prob', 0)
                categories.append('连号')
                probabilities.append(avg_prob * 100)
                colors.append('#FF6B6B')
            
            # 邻号数据
            if 'adjacent' in data:
                adjacent_data = data['adjacent']
                avg_prob = adjacent_data.get('avg_prob', 0)
                categories.append('邻号')
                probabilities.append(avg_prob * 100)
                colors.append('#4ECDC4')
            
            # 同尾数数据
            if 'same_tail' in data:
                tail_data = data['same_tail']
                avg_prob = tail_data.get('avg_prob', 0)
                categories.append('同尾数')
                probabilities.append(avg_prob * 100)
                colors.append('#45B7D1')
            
            if categories:
                x_pos = range(len(categories))
                bars = ax.bar(x_pos, probabilities, color=colors, edgecolor='white', linewidth=1.5)
                ax.set_xticks(x_pos)
                ax.set_xticklabels(categories, fontsize=15)
                ax.set_ylabel('出现概率 (%)', fontsize=15)
                ax.set_title(title, fontsize=15, fontweight='bold')
                ax.grid(axis='y', alpha=0.3)
                
                # 添加数值标签
                for bar, prob in zip(bars, probabilities):
                    height = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width()/2., height, f'{prob:.1f}%',
                            ha='center', va='bottom', fontsize=15, fontweight='bold')
            else:
                ax.text(0.5, 0.5, '暂无数据', ha='center', va='center', fontsize=15)
        else:
            ax.text(0.5, 0.5, '暂无数据（需要至少50期历史数据）', ha='center', va='center', fontsize=15)
            ax.set_title(title, fontsize=15, fontweight='bold')
        self.figure.tight_layout()
        self.redraw()
    
    def plot_sum_distribution(self, data, title="和值分布图"):
        """绘制和值直方图并叠加正态拟合曲线

        功能:
            绘制和值直方图并叠加正态拟合曲线

        参数:
            data (list[int|float] | dict): 和值列表；若为字典则读取 data['sums']。
                少于 5 个样本时只绘制“数据不足”提示。
            title (str): 图表标题。

        返回:
            None

        副作用:
            清空并重绘 figure；直方图 20 个分箱且 density=True（纵轴为概率密度），
            同时绘制正态拟合曲线与均值虚线；最后 tight_layout() + canvas.draw()。

        说明:
            scipy.stats 经 lib.math_algo 懒加载；不可用或缺少 norm 时跳过拟合曲线，
            仅保留直方图与均值线。
        """
        if self.figure is None:
            return
        np = get_numpy()  # 界面层不直接导入 numpy，统一从 lib 导出
        _get_mpl()
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        # data格式: [和值列表] 或 {'sums': [sum1, sum2, ...], 'mean': m, 'std': s}
        if data:
            if isinstance(data, dict):
                sums = data.get('sums', [])
            else:
                sums = data
            
            if len(sums) >= 5:
                sums_array = np.array(sums)
                mean_val = np.mean(sums_array)
                std_val = np.std(sums_array)
                
                # 绘制直方图：seaborn 只替换直方图本体，分箱数/密度口径/配色保持不变。
                # 不调用 sns.set_theme / sns.set_style，避免覆盖全局字体与白底画布。
                sns = get_seaborn_module()
                if sns is not None:
                    # seaborn 分支：stat='density' 等价于原 density=True，bins=20 不变
                    sns.histplot(
                        sums, bins=20, stat='density', element='bars',
                        alpha=0.7, color='#3498db', edgecolor='white',
                        linewidth=0.5, ax=ax, legend=False,
                    )
                else:
                    # 降级分支（HAS_SNS=False）：保持接入前的 matplotlib hist 调用
                    n, bins, patches = ax.hist(sums, bins=20, density=True, alpha=0.7,
                                              color='#3498db', edgecolor='white', linewidth=0.5)
                
                # 正态分布拟合曲线
                x_range = np.linspace(min(sums), max(sums), 100)
                scipy_st = _get_scipy_stats()
                if scipy_st is not None and hasattr(scipy_st, 'norm'):
                    y_normal = scipy_st.norm.pdf(x_range, mean_val, std_val)
                    ax.plot(x_range, y_normal, 'r-', linewidth=2, label=f'正态拟合 (μ={mean_val:.1f}, σ={std_val:.1f})')
                
                # 标记均值线
                ax.axvline(mean_val, color='red', linestyle='--', linewidth=1.5, label=f'均值={mean_val:.1f}')
                
                ax.set_xlabel('号码和值', fontsize=15)
                ax.set_ylabel('概率密度', fontsize=15)
                ax.set_title(title, fontsize=15, fontweight='bold')
                ax.legend(loc='upper right', fontsize=15)
                ax.grid(True, alpha=0.3)
            else:
                ax.text(0.5, 0.5, f'数据不足（需要至少5期数据，当前{len(sums)}期）', 
                       ha='center', va='center', fontsize=15)
        else:
            ax.text(0.5, 0.5, '暂无数据', ha='center', va='center', fontsize=15)
        ax.set_title(title, fontsize=15, fontweight='bold')
        self.figure.tight_layout()
        self.redraw()

# PreserveColorDelegate
class PreserveColorDelegate(QStyledItemDelegate):
    """表格项委托：选中行时保留原始前景色，只改变背景色

    职责:
        QTableView 的选中态默认会用系统高亮色覆盖文字颜色，导致按号码波色着色的
        文字在选中后失色。本委托同时重写 initStyleOption() 与 paint()，
        在选中时保持彩色文字、只替换背景为浅蓝。

    行为约定:
        - item 设置了 ForegroundRole（彩色文字）：选中后保留该颜色；
        - 未设置 ForegroundRole：选中后用深灰 #333333 文字，保证浅蓝背景上可读；
        - 选中背景固定浅蓝 #D6EAF8；
        - 未选中行按奇偶交替 #F8F9FA / #FFFFFF。

    使用位置:
        TAB/history.py、TAB/backtest.py、TAB/prediction_history.py、
        TAB/prediction.py、TAB/zodiac.py 中给历史/回测表格 setItemDelegate。

    约束:
        paint() 完全自行绘制背景、网格线、文字与焦点框，不调用父类 paint，
        因此委托内的样式与 QSS 背景设置不会生效（这是刻意绕过 QSS 的限制）。
    """
    def initStyleOption(self, option, index):
        """在标准样式选项基础上覆写选中态调色板

        功能:
            在标准样式选项基础上覆写选中态调色板

        参数:
            option (QStyleOptionViewItem): 由视图传入并会被本方法就地修改的样式选项。
            index (QModelIndex): 当前单元格索引，用于读取 ForegroundRole。

        返回:
            None

        副作用:
            修改 option.palette 的 Highlight/Text/HighlightedText 颜色；
            仅当单元格处于选中状态时生效。

        说明:
            同时设置 Text 与 HighlightedText，是因为不同风格/平台绘制文字时
            读取的角色可能不同，两者都设可避免某一端仍显示默认高亮文字。
        """
        super().initStyleOption(option, index)
        if option.state & QStyle.StateFlag.State_Selected:
            # 选中背景色设为浅蓝
            option.palette.setColor(QPalette.ColorRole.Highlight, QColor("#D6EAF8"))
            fg = index.data(Qt.ItemDataRole.ForegroundRole)
            if fg and hasattr(fg, 'color'):
                # 有自定义前景色，保留原始颜色
                option.palette.setColor(QPalette.ColorRole.Text, fg.color())
                option.palette.setColor(QPalette.ColorRole.HighlightedText, fg.color())
            else:
                # 没有自定义前景色，选中时用黑色文字（浅蓝背景上清晰）
                option.palette.setColor(QPalette.ColorRole.HighlightedText, QColor("#333333"))
    
    def paint(self, painter, option, index):
        """完全自行绘制单元格（背景、网格线、文字、焦点框）

        功能:
            完全自行绘制单元格（背景、网格线、文字、焦点框）

        参数:
            painter (QPainter): 视图提供的绘制器。
            option (QStyleOptionViewItem): 单元格几何信息（option.rect）与状态。
            index (QModelIndex): 单元格数据索引。

        返回:
            None

        副作用:
            在 painter 上直接绘制；通过 save()/restore() 保证不污染视图后续绘制。

        说明:
            不调用 super().paint()，以绕过 QSS 对选中文字颜色的覆盖；
            背景色、奇偶行、网格线都在这里显式绘制，因此使用本委托的表格
            不应再依赖样式表设置单元格背景。
        """
        # save/restore 成对出现：本方法会改画笔颜色、字体等状态，
        # 必须还原，否则同一 painter 后续绘制其它单元格会串色
        painter.save()
        
        # 获取原始前景色：未设置 ForegroundRole 时用深灰，
        # 比纯黑在浅蓝选中背景上更柔和，也避免与彩色文字差距过大
        fg = index.data(Qt.ItemDataRole.ForegroundRole)
        text_color = QColor("#333333")
        if fg and hasattr(fg, 'color'):
            text_color = fg.color()
        
        # 选中状态处理
        is_selected = bool(option.state & QStyle.StateFlag.State_Selected)
        
        # 绘制背景
        if is_selected:
            painter.fillRect(option.rect, QColor("#D6EAF8"))
        else:
            # 交替行颜色
            if index.row() % 2 == 1:
                painter.fillRect(option.rect, QColor("#F8F9FA"))
            else:
                painter.fillRect(option.rect, QColor("#FFFFFF"))
        
        # 绘制网格线（右侧和底部）
        painter.setPen(QColor("#EEEEEE"))
        painter.drawLine(option.rect.right(), option.rect.top(), option.rect.right(), option.rect.bottom())
        painter.drawLine(option.rect.left(), option.rect.bottom(), option.rect.right(), option.rect.bottom())
        
        # 绘制文字
        painter.setPen(text_color)
        font = index.data(Qt.ItemDataRole.FontRole)
        if font:
            painter.setFont(font)
        else:
            painter.setFont(option.font)
        
        text = index.data(Qt.ItemDataRole.DisplayRole)
        if text:
            alignment = index.data(Qt.ItemDataRole.TextAlignmentRole)
            if not alignment:
                alignment = int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            # 左右各内缩 5px 模拟单元格 padding，避免文字紧贴网格线
            painter.drawText(option.rect.adjusted(5, 0, -5, 0), int(alignment), str(text))
        
        # 绘制焦点框
        if option.state & QStyle.StateFlag.State_HasFocus:
            style = option.widget.style() if option.widget else QApplication.style()
            focus_option = QStyleOptionFocusRect()
            focus_option.rect = option.rect
            focus_option.state = option.state
            style.drawPrimitive(QStyle.PrimitiveElement.PE_FrameFocusRect, focus_option, painter, option.widget)
        
        painter.restore()


def open_panel_size_dialog(host, heading, current, on_apply,
                           show_label_size=False, show_plus_size=False,
                           auto_width=False):
    """通用「面板尺寸设置」对话框（尺寸弹窗的公共部分）

    功能:
        原主窗口 `_show_panel_settings_dialog` 的四条分支共用同一套对话框
        骨架，本函数把公共部分（窗口标题、样式、宽高三组输入、恢复默认、
        取消/确定、保存 INI、状态栏提示）抽到 widgets 层；各页面只传入
        当前尺寸与「确定后如何应用」的回调，避免把 Qt 弹窗拆成四份重复代码。

    参数:
        host: 主窗口实例。用于承载对话框父窗口、调用 host._save_ini_config()
            与 host.statusBar().showMessage()。
        heading (str): 对话框内标题文本（如「数字选择面板尺寸」）。
        current (dict): 当前尺寸，键 width/height；可选 label_width/
            label_height/plus_size，布尔开关决定是否展示对应行。
        on_apply (Callable[[dict], None]): 点击「确定」后回调，参数为
            {'width','height','label_width','label_height','plus_size'}；
            由调用页面在此更新自身尺寸配置并重绘控件。
        show_label_size (bool): 是否显示「标签宽/高」两行（仅预测页）。
        show_plus_size (bool): 是否显示「加号大小」一行（仅预测页）。
        auto_width (bool): 卡宽改为只读并标注「自动」（仅属性矩阵页；
            卡宽由可用宽度反算，手工值只会被覆盖）。

    返回:
        dict | None: 用户点「确定」时返回输入值；取消/关闭返回 None。
            无论确认与否，函数结束前都会再保存一次 INI（保留原实现的双保存时序）。

    注意:
        模态对话框会阻塞调用方事件循环；确认后执行 on_apply 并保存 INI（末尾再保存一次为原实现时序），取消返回 None 且不应用。

    降级:
        host 没有 statusBar 时跳过提示，不影响尺寸应用；
        所有数值均来自 QSpinBox，天然为 int，无需额外容错。

    说明:
        默认值与原实现逐字一致：宽 80、高 60；标签宽/高 0；加号 24。
        恢复默认只改本次对话框内的数字，点「确定」才写回 host 配置，
        与原实现的交互顺序一致。
    """
    dialog = QDialog(host)
    dialog.setWindowTitle("面板尺寸设置")
    dialog.setModal(True)
    dialog.setFixedWidth(360)
    # 弹窗固定浅色卡片：暗色主题下全局 QSS 会把 QDialog 背景压暗、并给 QLabel
    # 铺深色底，而本弹窗标题/标签沿用深灰文字（#333/#555）。这里统一铺白底、
    # 标签透明、按钮深字，避免出现「深底深字」看不清。
    dialog.setStyleSheet(
        "QDialog { background-color: #FFFFFF; }"
        "QLabel { background: transparent; color: #333333; }"
        "QPushButton { color: #333333; }")

    layout = QVBoxLayout(dialog)
    layout.setSpacing(12)
    layout.setContentsMargins(20, 20, 20, 20)

    def _style_dialog_spin(spin):
        """弹窗内数字框统一走共享样式：40px 高、左 8px 右 24px、箭头分开定位。"""
        apply_spin_style(spin, border_color='#CCCCCC', bg='#FFFFFF', fg='#333333',
                         height=SPIN_HEIGHT, font_px=15, fixed_width=120)

    title_label = QLabel(heading)
    # 标题样式与原弹窗一致：16px、加粗、深灰；min-height 28 给字体上下留白 ≥4px
    title_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #333; min-height: 28px;")
    layout.addWidget(title_label)

    width_row = QHBoxLayout()
    width_label = QLabel("按钮宽度（px）:")
    # 表单标签样式：15px、中灰；min-height 28 防止文字贴边/被裁
    width_label.setStyleSheet("font-size: 15px; color: #555; min-height: 28px;")
    width_spin = QSpinBox()
    width_spin.setRange(30, LotteryConfig.BUTTON_MAX_WIDTH)
    width_spin.setValue(current.get('width', LotteryConfig.BUTTON_DEFAULT_WIDTH))
    _style_dialog_spin(width_spin)
    if auto_width:
        # 卡宽按可用宽度反算（12 列共轴），这里只显示实测值：
        # 改成只读并去掉上下箭头，避免留一个「看似能调、实际被覆盖」的旋钮。
        width_label.setText("卡宽（自动，按可用宽度）:")
        width_spin.setReadOnly(True)
        try:
            width_spin.setButtonSymbols(QSpinBox.ButtonSymbols.NoButtons)
        except Exception:
            pass
        width_spin.setToolTip("卡宽由面板可用宽度反算，保证 12 列共轴，不可手工指定")
    width_row.addWidget(width_label)
    width_row.addStretch()
    width_row.addWidget(width_spin)
    layout.addLayout(width_row)

    height_row = QHBoxLayout()
    height_label = QLabel("按钮高度（px）:")
    height_label.setStyleSheet("font-size: 15px; color: #555; min-height: 28px;")
    height_spin = QSpinBox()
    height_spin.setRange(30, LotteryConfig.BUTTON_MAX_HEIGHT)
    height_spin.setValue(current.get('height', LotteryConfig.BUTTON_DEFAULT_HEIGHT))
    _style_dialog_spin(height_spin)
    height_row.addWidget(height_label)
    height_row.addStretch()
    height_row.addWidget(height_spin)
    layout.addLayout(height_row)

    label_width_spin = None
    label_height_spin = None
    if show_label_size:
        label_width_row = QHBoxLayout()
        label_width_label = QLabel("标签宽度（px，0=自适应）:")
        label_width_label.setStyleSheet("font-size: 15px; color: #555; min-height: 28px;")
        label_width_spin = QSpinBox()
        label_width_spin.setRange(0, LotteryConfig.BUTTON_MAX_WIDTH)
        label_width_spin.setValue(current.get('label_width', 0))
        _style_dialog_spin(label_width_spin)
        label_width_row.addWidget(label_width_label)
        label_width_row.addStretch()
        label_width_row.addWidget(label_width_spin)
        layout.addLayout(label_width_row)

        label_height_row = QHBoxLayout()
        label_height_label = QLabel("标签高度（px，0=自适应）:")
        label_height_label.setStyleSheet("font-size: 15px; color: #555; min-height: 28px;")
        label_height_spin = QSpinBox()
        label_height_spin.setRange(0, LotteryConfig.BUTTON_MAX_HEIGHT)
        label_height_spin.setValue(current.get('label_height', 0))
        _style_dialog_spin(label_height_spin)
        label_height_row.addWidget(label_height_label)
        label_height_row.addStretch()
        label_height_row.addWidget(label_height_spin)
        layout.addLayout(label_height_row)

    plus_size_spin = None
    if show_plus_size:
        plus_size_row = QHBoxLayout()
        plus_size_label = QLabel("加号字体大小（px）:")
        plus_size_label.setStyleSheet("font-size: 15px; color: #555; min-height: 28px;")
        plus_size_spin = QSpinBox()
        plus_size_spin.setRange(12, 100)
        plus_size_spin.setValue(current.get('plus_size', 24))
        _style_dialog_spin(plus_size_spin)
        plus_size_row.addWidget(plus_size_label)
        plus_size_row.addStretch()
        plus_size_row.addWidget(plus_size_spin)
        layout.addLayout(plus_size_row)

    layout.addSpacing(8)

    btn_row = QHBoxLayout()
    reset_btn = QPushButton("恢复默认")
    # 次要操作（恢复默认/取消）统一灰色系
    reset_btn.setStyleSheet("QPushButton { background-color: #F5F5F5; color: #666; border: 1px solid #DDD; border-radius: 6px; padding: 8px 16px; font-weight: bold; } QPushButton:hover { background-color: #EEEEEE; }")
    btn_row.addWidget(reset_btn)
    btn_row.addStretch()

    cancel_btn = QPushButton("取消")
    cancel_btn.setStyleSheet("QPushButton { background-color: #F5F5F5; color: #666; border: 1px solid #DDD; border-radius: 6px; padding: 8px 16px; font-weight: bold; } QPushButton:hover { background-color: #EEEEEE; }")
    cancel_btn.clicked.connect(dialog.reject)
    btn_row.addWidget(cancel_btn)

    ok_btn = QPushButton("应用")
    # 主操作按钮用绿色，保持原弹窗视觉
    ok_btn.setStyleSheet("QPushButton { background-color: #2ECC71; color: #FFFFFF; border: none; border-radius: 6px; padding: 8px 20px; font-weight: bold; } QPushButton:hover { background-color: #27AE60; }")
    ok_btn.clicked.connect(dialog.accept)
    btn_row.addWidget(ok_btn)
    layout.addLayout(btn_row)

    def _reset_defaults():
        """恢复出厂尺寸：仅预测页会同时重置标签与加号，其余只重置宽高

        功能:
            恢复出厂尺寸：仅预测页会同时重置标签与加号，其余只重置宽高

        参数:
            无。

        返回:
            无。

        注意:
            只改对话框内的控件数值，不保存配置；点「确定」后才写回 host。
        """
        width_spin.setValue(80)
        height_spin.setValue(60)
        if show_label_size:
            label_width_spin.setValue(0)
            label_height_spin.setValue(0)
        if show_plus_size:
            plus_size_spin.setValue(24)

    reset_btn.clicked.connect(_reset_defaults)

    result = None
    if dialog.exec() == QDialog.DialogCode.Accepted:
        result = {
            'width': width_spin.value(),
            'height': height_spin.value(),
            'label_width': label_width_spin.value() if label_width_spin else 0,
            'label_height': label_height_spin.value() if label_height_spin else 0,
            'plus_size': plus_size_spin.value() if plus_size_spin else 0,
        }
        if on_apply is not None:
            on_apply(result)
        # 原实现：应用后立即保存一次，再在末尾兜底保存一次
        host._save_ini_config()
        if hasattr(host, 'statusBar'):
            host.statusBar().showMessage("面板尺寸已更新")
    host._save_ini_config()
    return result

