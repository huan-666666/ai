# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/number_sort.py - 「数字排序」选项卡页面构建模块
===========================================================================
功能说明：
    构建主窗口「数字排序」选项卡的全部界面控件，并挂载到主窗口实例上。

TAB_INFO（供 TAB/__init__.py 自动发现）：
    title   = "数字排序"
    order   = 13（数字工具类页面，排在收藏之后、数字选尾之前）
    enabled = True

依赖：
    - UI/UI.py：QWidget/QVBoxLayout/QHBoxLayout/QLabel/QPushButton/QTextEdit/QComboBox
    - lib.data_process.LotteryConfig.RESULT_SEPARATORS：15 种结果分隔符
      （显示文字, 实际连接符）的唯一数据源，本页不另行硬编码分隔符表

数据流：
    输入框文本 → DataUtils.parse_numbers_text(dedupe=False, limit_range=False)
    （lib 统一解析，兼容中英文标点，统计用途保留重复与越界值）
    → sorted(set(nums)) 去重升序 → 按选定分隔符拼接写入 sort_result_edit；
    同时统计出现次数写 sort_count_edit、1-49 缺失号码写 sort_missing_edit。
    分隔符切换只重算显示，不改变输入数据。

职责边界：
    - 本模块只负责界面构建（布局、控件、初始样式）
    - 事件处理函数保留在主窗口 LotteryPredictionWindow 中，通过信号连接
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import os as _os_boot  # 作用说明：提供 dirname/abspath/exists/join 等路径能力，用于向上定位项目根目录
import sys as _sys_boot  # 作用说明：提供 sys.path 访问，用于把项目根目录加入模块搜索路径以支持直接运行本文件

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QComboBox, QHBoxLayout, QLabel, QPushButton, QTextEdit, QVBoxLayout, QWidget)  # 作用说明：统一获取本页所需的 Qt 控件（下拉框/布局/标签/按钮/文本框），避免直接 import PyQt6
from lib.data_process import LotteryConfig, DataUtils  # 作用说明：提供分隔符选项表（RESULT_SEPARATORS）与号码文本解析，本页不另行硬编码分隔符或解析规则


# ╔══════════════════════════════════════════════════════════════════╗
# ║  [数字排序：去重排序、分隔符切换、清空、字号调节]
# ╚══════════════════════════════════════════════════════════════════╝

def on_do_number_sort(host):
    """执行数字排序（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        解析输入文本中的所有数字，输出去重升序结果、出现次数统计和 1-49
        缺失号码，并按当前选定的分隔符拼接显示。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。读取：
            host.sort_input_edit        —— 输入 QTextEdit；
            host._get_result_separator  —— 读取分隔符下拉框的当前连接符；
            host.sort_sep_combo         —— 分隔符下拉框（按控件名取索引）。
        写入：
            host.sort_stats_label / host.sort_result_edit /
            host.sort_count_edit / host.sort_missing_edit。

    返回:
        无。

    调用方:
        install(host) 绑定为 host._on_do_number_sort；
        「开始排序」按钮 clicked、分隔符切换回调 on_sort_sep_changed 会触发。

    副作用:
        1) 覆盖写三个结果框与统计标签；
        2) 输入中没有有效数字时把三个结果框清空并提示“未识别到有效数字”；
        3) 不修改输入框内容，也不写配置/文件。

    说明:
        号码统一 zfill(2) 显示（如 5→05），与其它页面的两位号码规范一致；
        “缺失数字”按 1-49 全集合差集计算，因为本工具面向 49 号制彩票。
    """
    text = host.sort_input_edit.toPlainText()
    nums = DataUtils.parse_numbers_text(text, dedupe=False, limit_range=False)

    if not nums:
        host.sort_stats_label.setText("未识别到有效数字")
        host.sort_result_edit.setPlainText("")
        host.sort_count_edit.setPlainText("")
        host.sort_missing_edit.setPlainText("")
        return

    # 去重排序
    # set 去重后 sorted 升序：排序工具需要“从 01 开始”的稳定顺序，重复号码只保留一个
    unique_sorted = sorted(set(nums))
    total_count = len(nums)
    unique_count = len(unique_sorted)

    # 更新统计
    host.sort_stats_label.setText(f"共 {total_count} 个数字，去重后 {unique_count} 个")

    # 结果分隔符（15 种：空格/英文逗号/顿号/分号/减号/正斜杠/竖线/换行/中文逗号/中文句号/
    # 英文句号/加号/反斜杠/波浪号/井号，统一取自 LotteryConfig.RESULT_SEPARATORS，可切换并记忆）
    sep = host._get_result_separator('sort_sep_combo')

    # 去重排序结果
    host.sort_result_edit.setPlainText(sep.join(str(n).zfill(2) for n in unique_sorted))

    # 出现次数统计
    count_dict = {}
    for n in nums:
        count_dict[n] = count_dict.get(n, 0) + 1
    count_text = ""
    for n in sorted(count_dict.keys()):
        count = count_dict[n]
        count_text += f"{str(n).zfill(2)}: {count}次    "
    host.sort_count_edit.setPlainText(count_text.strip())

    # 缺少的数字（1-49范围）
    # 使用 1-49 全集合做差集：本工具服务于 49 号制彩票，固定全集才能判断“缺号”，
    # 若只按输入最大值取范围，末尾未出现的号码会被漏报
    full_set = set(range(1, 50))
    input_set = set(nums)
    missing = sorted(full_set - input_set)
    if missing:
        host.sort_missing_edit.setPlainText(sep.join(str(n).zfill(2) for n in missing))
    else:
        host.sort_missing_edit.setPlainText("1-49的数字都齐了！")


def on_sort_sep_changed(host, index):
    """结果分隔符切换时即时刷新排序结果（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        用户切换结果分隔符后，若输入框已有内容就复用 on_do_number_sort
        重算并刷新排序、统计与缺失号码三个结果框。

    参数:
        host: 主窗口实例。读取 host.sort_input_edit；刷新时复用
            host._on_do_number_sort。
        index: int，下拉框当前索引（Qt 信号参数，本函数未使用；分隔符由
            host._get_result_separator 从控件当前项读取，故无需 index）。

    返回:
        无。

    调用方:
        build(host) 中 sort_sep_combo.currentIndexChanged 连接到
        host._on_sort_sep_changed。

    副作用:
        仅当输入框有非空文本时才触发一次完整排序刷新；输入为空则什么都不做，
        避免清空状态下反复刷出提示。
    """
    if host.sort_input_edit.toPlainText().strip():
        host._on_do_number_sort()


def on_clear_sort(host):
    """清空排序输入和结果（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        清空输入框与三个结果框，并把统计标签复位为「共 0 个数字，去重后 0 个」。

    参数:
        host: 主窗口实例。清空 host.sort_input_edit / sort_result_edit /
            sort_count_edit / sort_missing_edit，并把 sort_stats_label 复位为 0。
    返回:
        无。
    调用方:
        install(host) 绑定为 host._on_clear_sort；「清空」按钮 clicked 时触发。
    副作用:
        只清本页控件文本，不清除分隔符选择（用户的格式偏好保留），
        也不写入任何配置或文件。
    """
    host.sort_input_edit.clear()
    host.sort_result_edit.clear()
    host.sort_count_edit.clear()
    host.sort_missing_edit.clear()
    host.sort_stats_label.setText("共 0 个数字，去重后 0 个")


def change_sort_font(host, direction):
    """调节排序结果区域字体大小（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        按 direction 以 2px 为一档增减结果区字号，钳制在 15~28px 后重设
        排序、统计与缺失号码三个结果框的样式表。

    参数:
        host: 主窗口实例。读写 host._sort_font_size（首次缺失时初始化为 14），
            并改写 host.sort_result_edit / sort_count_edit / sort_missing_edit
            三个结果框的样式表。
        direction: int，1=放大一档（+2px），-1=缩小一档（-2px）。

    返回:
        无。

    调用方:
        install(host) 绑定为 host._change_sort_font；
        build 中「A-」「A+」按钮 clicked 分别传入 -1 / 1。

    副作用:
        1) 更新 host._sort_font_size 并重设三个结果框样式表；
        2) 只改变字号，底色/边框/文字颜色与初始样式保持一致；
        3) 字号钳制在 [15, 28] px：15px 是 v0.0.36 的字号下限（更小会难以辨认），
           28px 是上限（再大结果框单行放不下、容易横向溢出）。

    说明:
        三个结果框共用同一个字号值，保证同一页面的结果文本视觉一致；
        _sort_font_size 挂在 host 上而非模块全局，避免多窗口实例互相影响。
    """
    if not hasattr(host, '_sort_font_size'):
        # 初始基准 15px 与 build() 中结果框初始字号一致，首次点击 A- 才会出现可见变化
        # （旧值 14 会让 14-2=12 被下限钳回 15，用户误以为按钮失效）
        host._sort_font_size = 15

    new_size = host._sort_font_size + direction * 2
    # 15px 下限（v0.0.36 规范，防止缩小后不可读）与 28px 上限（防止结果区内容溢出）
    new_size = max(15, min(28, new_size))
    host._sort_font_size = new_size

    # 排序/统计结果框字体调节样式 - 浅灰底系（动态字号，保持与初始样式一致）
    #   background-color: #F8F9FA;  浅灰背景（与 build 的初始样式一致）
    #   border: 1px solid #DDDDDD;  浅灰边框
    #   border-radius: 6px;         6px 圆角
    #   padding: 8px;               内边距 8px
    #   font-size: {new_size}px;    字号：随调节档位变化（15~28px）
    font_style = f"""
        QTextEdit {{ background-color: #F8F9FA; border: 1px solid #DDDDDD; border-radius: 6px; 
            padding: 8px; font-size: {new_size}px; }}
    """
    host.sort_result_edit.setStyleSheet(font_style)  # 排序结果框应用新字号
    host.sort_count_edit.setStyleSheet(font_style)   # 统计结果框应用新字号

    # 缺失数字框字体调节样式 - 红色系（动态字号，保持警示风格一致）
    #   background-color: #FFF5F5;  浅红背景（警示底色）
    #   border: 1px solid #F5B7B1;  浅红边框
    #   border-radius: 6px;         6px 圆角
    #   padding: 8px;               内边距 8px
    #   font-size: {new_size}px;    字号：与排序/统计框同步
    #   color: #C0392B;             深红文字（突出“缺失”）
    missing_style = f"""
        QTextEdit {{ background-color: #FFF5F5; border: 1px solid #F5B7B1; border-radius: 6px; 
            padding: 8px; font-size: {new_size}px; color: #C0392B; }}
    """
    host.sort_missing_edit.setStyleSheet(missing_style)  # 缺失数字框应用新字号


def install(host):
    """安装「数字排序」选项卡：绑定 4 个事件回调后构建界面（v0.0.28 起页面自包含）

    功能:
        在 host 上挂好排序、分隔符切换、清空与字号调节四个 lambda 回调，
        再调用 build(host) 创建并返回页面控件。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。
    返回:
        QWidget: 构建完成的页面（build 的返回值），供 addTab 使用。
    调用方:
        TAB/__init__.py 的 iter_tab_pages() 自动发现本页后由主窗口调用。
    副作用:
        在 host 上写入 4 个回调，build 中对应控件在创建时立即连接：
            host._on_do_number_sort  ← sort_btn.clicked（🔍 开始排序）
            host._on_sort_sep_changed ← sort_sep_combo.currentIndexChanged
            host._on_clear_sort       ← clear_btn.clicked（🧹 清空）
            host._change_sort_font    ← font_minus_btn / font_plus_btn.clicked（A- / A+）
        必须先绑定再 build，否则 build 连接信号时属性不存在会抛 AttributeError。
    """
    host._on_do_number_sort = lambda: on_do_number_sort(host)
    host._on_sort_sep_changed = lambda index: on_sort_sep_changed(host, index)
    host._on_clear_sort = lambda: on_clear_sort(host)
    host._change_sort_font = lambda direction: change_sort_font(host, direction)
    return build(host)


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "数字排序",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 13,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """构建「数字排序」选项卡页面

    功能:
        创建标题、输入提示、输入框、按钮行（排序/清空/分隔符/字体调节）、
        统计标签与三个只读结果框（排序结果/出现次数/缺失号码）。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。本函数写入：
            host.sort_input_edit   —— 输入 QTextEdit；
            host.sort_sep_combo    —— 分隔符 QComboBox（选项来自 RESULT_SEPARATORS）；
            host.sort_stats_label / host.sort_result_edit /
            host.sort_count_edit / host.sort_missing_edit —— 统计与三个结果框。
        读取 _ini_sort_sep_index（上次分隔符索引）与 host 上的 4 个事件回调。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        1) 在 host 上挂载上述 7 个控件；
        2) 连接排序/清空/分隔符/A± 信号；
        3) 恢复上次分隔符索引（越界时保持默认索引 0=空格），并加 tooltip 说明 15 种格式；
        4) 三个结果框均设为只读，防止用户误改输出；
        5) 本页不读取历史数据、不做持久化（分隔符索引由主窗口统一保存到 INI）。

    说明:
        分隔符下拉框用 AdjustToContents + 最小宽 150px，避免大字体下
        “中文句号（。）”这类长选项被截断；恢复索引必须放在 connect 之前，
        否则启动恢复索引会触发一次无意义的即时刷新。
    """
    widget = QWidget()
    # 主垂直布局
    layout = QVBoxLayout(widget)
    layout.setSpacing(10)
    layout.setContentsMargins(10, 10, 10, 10)

    # 标题
    title = QLabel("数字排序工具")
    # 标题样式 - 深色系（页面主标题，突出功能名称）
    #   font-size: 18px;        字号：18px（大标题醒目）
    #   font-weight: bold;      加粗
    #   color: #2C3E50;         深灰蓝色文字
    title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2C3E50;")
    layout.addWidget(title)

    # 输入区域
    input_label = QLabel("输入数字（自动识别多种分隔符，可混合使用）：")
    # 输入提示标签样式 - 灰色系（引导用户输入）
    #   font-size: 15px;        字号：15px
    #   font-weight: bold;      加粗
    #   color: #555555;         深灰色文字
    input_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555;")
    layout.addWidget(input_label)

    host.sort_input_edit = QTextEdit()
    host.sort_input_edit.setPlaceholderText("请输入一堆数字，例如：\n5, 12, 3, 45, 12, 7, 23, 5, 33\n或：5 12 3 45 12 7 23 5 33\n或：5/12/3/45-12-7-23-5-33\n或：5，12。3、45；12|7#23~5=33（中英文标点均可）")
    # 排序输入框样式 - 白底灰边系（普通输入区域）
    #   QTextEdit {
    #     background-color: #FFFFFF;  白色背景
    #     border: 1px solid #DDDDDD;  浅灰色边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px;               内边距
    #     font-size: 15px;            字号14px
    #   }
    host.sort_input_edit.setStyleSheet("""
        QTextEdit { background-color: #FFFFFF; border: 1px solid #DDDDDD; border-radius: 6px; 
            padding: 8px; font-size: 15px; }
    """)
    host.sort_input_edit.setMaximumHeight(120)
    layout.addWidget(host.sort_input_edit)

    # 按钮行
    btn_layout = QHBoxLayout()

    sort_btn = QPushButton("🔍 开始排序")
    # 排序按钮样式 - 绿色系（主操作按钮，引导用户执行排序）
    #   QPushButton {
    #     background-color: #2ECC71;  绿色背景（确认/执行色）
    #     color: white;               白色文字
    #     border: none;               无边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px 24px;          内边距
    #     font-weight: bold;          加粗
    #     font-size: 15px;            字号14px
    #   }
    #   QPushButton:hover {
    #     background-color: #27AE60;  悬停深绿色
    #   }
    sort_btn.setStyleSheet("""
        QPushButton { background-color: #2ECC71; color: white; border: none; 
            border-radius: 6px; padding: 8px 24px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #27AE60; }
    """)
    # 信号连接：点击开始排序按钮执行数字排序
    sort_btn.clicked.connect(host._on_do_number_sort)
    btn_layout.addWidget(sort_btn)

    # 清空按钮：清除排序输入和结果
    clear_btn = QPushButton("🧹 清空")
    # 清空按钮样式 - 灰色系（次要操作，不抢视觉焦点）
    #   QPushButton {
    #     background-color: #95A5A6;  灰色背景（中性/次要色）
    #     color: white;               白色文字
    #     border: none;               无边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px 20px;          内边距
    #     font-weight: bold;          加粗
    #     font-size: 15px;            字号14px
    #   }
    #   QPushButton:hover {
    #     background-color: #7F8C8D;  悬停深灰色
    #   }
    clear_btn.setStyleSheet("""
        QPushButton { background-color: #95A5A6; color: white; border: none; 
            border-radius: 6px; padding: 8px 20px; font-weight: bold; font-size: 15px; }
        QPushButton:hover { background-color: #7F8C8D; }
    """)
    # 信号连接：点击清空按钮清除所有排序输入和结果
    clear_btn.clicked.connect(host._on_clear_sort)
    btn_layout.addWidget(clear_btn)

    # 结果分隔符选择：控制排序结果/缺失数字的显示连接方式（默认空格）
    sep_label = QLabel("分隔符：")
    # 分隔符标签样式：灰色文字（与“字体：”标签一致，作为按钮行内的说明文字）
    sep_label.setStyleSheet("color: #666666;")
    btn_layout.addWidget(sep_label)

    host.sort_sep_combo = QComboBox()
    # 多格式分隔符选项：统一取自 LotteryConfig.RESULT_SEPARATORS（显示文字, 实际连接符）
    for sep_text, sep_value in LotteryConfig.RESULT_SEPARATORS:
        host.sort_sep_combo.addItem(sep_text, sep_value)
    # 宽度随最长选项文字自适应（大字体下固定宽度会截断"中文句号（。）"等长选项）
    host.sort_sep_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
    host.sort_sep_combo.setMinimumWidth(150)
    host.sort_sep_combo.setToolTip(
        "设置排序结果的显示分隔符：空格 / 英文逗号 / 顿号 / 分号 / 减号 / 正斜杠 / 竖线 / 换行 /"
        " 中文逗号 / 中文句号 / 英文句号 / 加号 / 反斜杠 / 波浪号 / 井号")
    # 恢复上次选择的分隔符（主窗口从 配置.ini 读取，缺失时默认索引0=空格）
    saved_sep_index = getattr(host, '_ini_sort_sep_index', 0)
    if 0 <= saved_sep_index < host.sort_sep_combo.count():
        host.sort_sep_combo.setCurrentIndex(saved_sep_index)
    # 分隔符切换信号：即时刷新排序结果显示（放在恢复索引之后，避免启动时无谓刷新）
    host.sort_sep_combo.currentIndexChanged.connect(host._on_sort_sep_changed)
    btn_layout.addWidget(host.sort_sep_combo)

    # 字体调节
    btn_layout.addStretch()
    font_label = QLabel("字体：")
    # 字体标签样式：灰色文字，无额外装饰
    font_label.setStyleSheet("color: #666666;")
    btn_layout.addWidget(font_label)

    font_minus_btn = QPushButton("A-")
    # 字体缩小按钮样式 - 浅灰系（辅助调节按钮，低调不抢眼）
    #   QPushButton {
    #     background-color: #ECF0F1;  浅灰背景
    #     color: #333333;             深灰文字
    #     border: 1px solid #BDC3C7;  灰色边框
    #     border-radius: 4px;         4px圆角
    #     padding: 4px 10px;          内边距（紧凑）
    #     font-weight: bold;          加粗
    #   }
    #   QPushButton:hover {
    #     background-color: #BDC3C7;  悬停加深
    #   }
    font_minus_btn.setStyleSheet("""
        QPushButton { background-color: #ECF0F1; color: #333333; border: 1px solid #BDC3C7;
            border-radius: 4px; padding: 4px 10px; font-weight: bold; }
        QPushButton:hover { background-color: #BDC3C7; }
    """)
    # 信号连接：点击A-按钮缩小排序结果字体
    font_minus_btn.clicked.connect(lambda: host._change_sort_font(-1))
    btn_layout.addWidget(font_minus_btn)

    font_plus_btn = QPushButton("A+")
    # 字体放大按钮样式 - 浅灰系（与缩小按钮保持一致风格）
    #   QPushButton {
    #     background-color: #ECF0F1;  浅灰背景
    #     color: #333333;             深灰文字
    #     border: 1px solid #BDC3C7;  灰色边框
    #     border-radius: 4px;         4px圆角
    #     padding: 4px 10px;          内边距（紧凑）
    #     font-weight: bold;          加粗
    #   }
    #   QPushButton:hover {
    #     background-color: #BDC3C7;  悬停加深
    #   }
    font_plus_btn.setStyleSheet("""
        QPushButton { background-color: #ECF0F1; color: #333333; border: 1px solid #BDC3C7;
            border-radius: 4px; padding: 4px 10px; font-weight: bold; }
        QPushButton:hover { background-color: #BDC3C7; }
    """)
    # 信号连接：点击A+按钮放大排序结果字体
    font_plus_btn.clicked.connect(lambda: host._change_sort_font(1))
    btn_layout.addWidget(font_plus_btn)

    layout.addLayout(btn_layout)

    # 统计信息
    # 统计标签：显示总数和去重后数量
    host.sort_stats_label = QLabel("共 0 个数字，去重后 0 个")
    # 统计标签样式：13px字号，灰色文字，带内边距
    host.sort_stats_label.setStyleSheet("font-size: 15px; color: #666666; padding: 4px;")
    layout.addWidget(host.sort_stats_label)

    # 结果区域 - 去重排序
    result_title = QLabel("去重后排序（从小到大）：")
    # 结果区域标题样式 - 灰色系（小节标题，加粗突出）
    #   font-size: 15px;        字号14px
    #   font-weight: bold;      加粗
    #   color: #555555;         深灰色文字
    #   margin-top: 5px;        上边距5px
    result_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555; margin-top: 5px;")
    layout.addWidget(result_title)

    # 排序结果展示框：只读，显示去重后排序的数字
    host.sort_result_edit = QTextEdit()
    host.sort_result_edit.setReadOnly(True)
    # 排序结果框样式 - 浅灰底系（只读结果展示区）
    #   QTextEdit {
    #     background-color: #F8F9FA;  浅灰背景（区分可编辑区域）
    #     border: 1px solid #DDDDDD;  浅灰边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px;               内边距
    #     font-size: 15px;            字号14px
    #   }
    host.sort_result_edit.setStyleSheet("""
        QTextEdit { background-color: #F8F9FA; border: 1px solid #DDDDDD; border-radius: 6px; 
            padding: 8px; font-size: 15px; }
    """)
    host.sort_result_edit.setMaximumHeight(80)
    layout.addWidget(host.sort_result_edit)

    # 出现次数
    count_title = QLabel("出现次数统计：")
    # 次数统计标题样式 - 灰色系（小节标题，与结果标题风格一致）
    #   font-size: 15px;        字号14px
    #   font-weight: bold;      加粗
    #   color: #555555;         深灰色文字
    #   margin-top: 5px;        上边距5px
    count_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555; margin-top: 5px;")
    layout.addWidget(count_title)

    # 出现次数统计展示框：只读，显示每个数字的出现次数
    host.sort_count_edit = QTextEdit()
    host.sort_count_edit.setReadOnly(True)
    # 次数统计框样式 - 浅灰底系（只读结果展示区，与排序结果框一致）
    #   QTextEdit {
    #     background-color: #F8F9FA;  浅灰背景
    #     border: 1px solid #DDDDDD;  浅灰边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px;               内边距
    #     font-size: 15px;            字号14px
    #   }
    host.sort_count_edit.setStyleSheet("""
        QTextEdit { background-color: #F8F9FA; border: 1px solid #DDDDDD; border-radius: 6px; 
            padding: 8px; font-size: 15px; }
    """)
    host.sort_count_edit.setMaximumHeight(100)
    layout.addWidget(host.sort_count_edit)

    # 缺少的数字
    missing_title = QLabel("1-49中缺少的数字：")
    # 缺少数字标题样式 - 灰色系（小节标题，与上方标题风格一致）
    #   font-size: 15px;        字号14px
    #   font-weight: bold;      加粗
    #   color: #555555;         深灰色文字
    #   margin-top: 5px;        上边距5px
    missing_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555; margin-top: 5px;")
    layout.addWidget(missing_title)

    # 缺少数字展示框：只读，红色警示框，显示1-49中未出现的数字
    host.sort_missing_edit = QTextEdit()
    host.sort_missing_edit.setReadOnly(True)
    # 缺少数字框样式 - 红色系（警示色，突出"缺少"的异常状态）
    #   QTextEdit {
    #     background-color: #FFF5F5;  浅红背景（警示底色）
    #     border: 1px solid #F5B7B1;  浅红边框
    #     border-radius: 6px;         6px圆角
    #     padding: 8px;               内边距
    #     font-size: 15px;            字号14px
    #     color: #C0392B;             深红色文字（醒目警告）
    #   }
    host.sort_missing_edit.setStyleSheet("""
        QTextEdit { background-color: #FFF5F5; border: 1px solid #F5B7B1; border-radius: 6px; 
            padding: 8px; font-size: 15px; color: #C0392B; }
    """)
    host.sort_missing_edit.setMaximumHeight(80)
    layout.addWidget(host.sort_missing_edit)

    layout.addStretch()
    return widget
