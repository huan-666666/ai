# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/number_selection.py - 「数字选择」选项卡页面构建模块
===========================================================================
模块职责：
    1. 构建「数字选择」选项卡（标题行 + 角控件组 + 49 个号码球面板 +
       颜色图例 + 已选数字栏），并把控件与事件回调挂到 host；
    2. 提供红/蓝/绿三色分组设置对话框：解析任意分隔符号码 → 校验重复 →
       重建 NUMBER_COLORS / RED_NUMBERS / BLUE_NUMBERS / GREEN_NUMBERS →
       全局刷新并写入 INI；
    3. 维护面板数字字号（「数字 px」）、颜色图例字号（A-/A+）与已选号码显示。

依赖：
    - UI/UI.py 统一导出的 Qt 控件（禁止在本页直接 import PyQt6）
    - lib/data_process.LotteryConfig：RED_NUMBERS / BLUE_NUMBERS / GREEN_NUMBERS
      （三色分组名单）、NUMBER_COLORS（号码→{bg,text,border} 色表）、
      get_number_color()（读取当前颜色，用于把未填写号码归入原分组）
    - lib/data_process.DataUtils.parse_numbers_text()：颜色分组输入统一解析
      （选号用途：dedupe=True, limit_range=True，去重并限定 01~49）
    - TAB/widgets.py：NumberPanel（49 个号码球）与 v0.0.36 角控件共用逻辑
      （CORNER_HEIGHT / CORNER_SECTION_GAP / make_corner_* / style_corner_spin）
    - host（LotteryPredictionWindow）提供 _apply_custom_number_colors /
      _save_custom_number_colors / _change_legend_font / _save_ini_config /
      _show_panel_settings_dialog 等基础设施

在架构中的位置：
    位于 TAB/ 选项卡界面层，属于“界面构建 + 页面事件”自包含模块（v0.0.28 起）；
    颜色分组直接改写 lib 的类属性常量，从而让所有页面的号码配色即时联动，
    但写盘仍统一走主窗口的 INI 保存逻辑。

数据流：
    NumberPanel 选中 → number_selected 信号 → _on_selected() 更新“已选数字”
    颜色对话框（红/蓝/绿输入框）→ DataUtils.parse_numbers_text(
        dedupe=True, limit_range=True) 解析去重
        → _apply_color_groups() 校验重复并按旧色补齐 1~49
        → 重建 LotteryConfig.NUMBER_COLORS
        → apply_custom_number_colors(host) 全局刷新
        → host._save_custom_number_colors() 写 INI
        → 同步颜色图例文本
    字号：num_panel_font_spin → _on_font_changed() → NumberPanel.set_button_size
    图例字号：A-/A+ → host._change_legend_font() → 主窗口 _apply_legend_font_size()

导出对象：
    TAB_INFO                 选项卡元信息（title / order / enabled）
    install(host)            唯一安装入口：构建界面 + 绑定本页事件
    build(host)              仅构建页面（由 install 内部调用）
    _apply_color_groups / _on_*   内部事件与工具函数

功能说明：
    构建主窗口「数字选择」选项卡的全部界面控件，并挂载到主窗口实例上。

职责边界（v0.0.28 起本页自包含）：
    - 本模块负责界面构建（布局、控件、初始样式）与本页事件（含颜色分组应用）
    - 主窗口 LotteryPredictionWindow 的同名方法仅作兼容转发
    - Qt控件统一从 UI/UI.py 导入，禁止直接 from PyQt6 import xxx
    - 禁止直接 import numpy/pandas/matplotlib 等重型库，只调用 lib 导出函数
===========================================================================
"""

import os as _os_boot  # 作用说明：提供 dirname/abspath/exists 等路径能力，用于向上定位项目根目录
import sys as _sys_boot  # 作用说明：提供 sys.path 访问，用于把项目根目录加入模块搜索路径以支持直接运行本文件

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QDialog, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea, QSpinBox, QVBoxLayout, QWidget, Qt)  # 作用说明：统一获取本页所需的 Qt 控件（对话框/布局/标签/输入框/按钮/滚动区/数值框）及 Qt 枚举命名空间，避免直接 import PyQt6
from lib.data_process import LotteryConfig, DataUtils  # 作用说明：提供三色分组常量/号码色表/取色函数与号码文本统一解析，避免在本页重复实现业务规则
from TAB.widgets import (CORNER_HEIGHT, CORNER_SECTION_GAP, NumberPanel,  # 作用说明：提供 49 个号码球面板 NumberPanel，以及角控件的尺寸常量、容器/标签/按钮构造与样式辅助
                         add_corner_widget, make_corner_container, make_corner_label,
                         make_corner_size_button, open_panel_size_dialog, style_corner_spin)


def _legend_numbers_text(numbers):
    """把三色分组号码渲染成图例文本（两位数、升序、空格分隔）

    功能:
        把一组号码排序后统一补零到两位，再用空格连接，生成颜色图例号码行文本。

    参数:
        numbers (Iterable[int]): 待渲染的号码集合，可为 list/set 等任意可迭代对象，
            元素取值为 1~49 的整数。

    返回:
        str: 升序、补零、单空格分隔的号码文本；集合为空时返回空字符串。

    注意:
        排序在补零之前按数值比较，保证 9 排在 10 之前；本函数只做文本渲染，
        不读取也不修改 LotteryConfig。
    """
    return ' '.join(str(n).zfill(2) for n in sorted(numbers))


def _apply_color_groups(host, red, blue, green, status_label):
    """应用红/蓝/绿三组号码：全局改色 + 自动保存（无需重启）

    功能:
        校验三组号码互不重复后，把未填写的号码按原颜色归入对应分组，重建
        号码色表与三色名单，并刷新所有页面、写 INI、同步图例文本。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        red (list[int]): 红色组号码（来自输入框解析）。
        blue (list[int]): 蓝色组号码。
        green (list[int]): 绿色组号码。
        status_label (QLabel): 对话框内的状态提示标签，用于显示失败原因或结果。

    返回:
        None

    副作用:
        校验失败时只改 status_label 文本/样式并提前返回；
        成功时原地改写 LotteryConfig.RED_NUMBERS / BLUE_NUMBERS / GREEN_NUMBERS
        （已 sorted(set(...)），整体替换 LotteryConfig.NUMBER_COLORS；
        调用 apply_custom_number_colors(host) 全局重绘、host._save_custom_number_colors()
        写 INI；若 host 已建图例则同步六个 QLabel 的号码文本；最后改 status_label。

    说明:
        为什么要把未填写的号码按旧色补齐：颜色分组必须覆盖 1~49，否则未列出的
        号码会退回默认色，导致面板出现第四种颜色。旧色通过 get_number_color()
        在重建 NUMBER_COLORS 之前读取，因此拿到的是本次修改前的有效分组。
        重复检查只针对用户显式填写的三组，不包含自动补齐部分，避免误报。
        颜色写死为红/蓝/绿三套 bg/text/border，与 lib 的默认波色定义一致。
    """
    overlaps = (set(red) & set(blue)) | (set(red) & set(green)) | (set(blue) & set(green))
    if overlaps:
        status_label.setText("号码重复：" + ' '.join(str(n).zfill(2) for n in sorted(overlaps)) + "，请去掉后再应用")
        status_label.setStyleSheet("font-size: 20px; color: #E74C3C; font-weight: bold;")
        return

    # 未填写的号码沿用原颜色并归入对应分组，保证 1-49 全覆盖
    for num in range(1, 50):
        if num in red or num in blue or num in green:
            continue
        text_color = LotteryConfig.get_number_color(num).get('text', '#008000')
        if text_color.upper() == '#FF0000':
            red.append(num)
        elif text_color.upper() == '#0000FF':
            blue.append(num)
        else:
            green.append(num)

    LotteryConfig.RED_NUMBERS = sorted(set(red))
    LotteryConfig.BLUE_NUMBERS = sorted(set(blue))
    LotteryConfig.GREEN_NUMBERS = sorted(set(green))
    LotteryConfig.NUMBER_COLORS = {}
    for num in LotteryConfig.RED_NUMBERS:
        LotteryConfig.NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": "#FF0000", "border": "#FF0000"}
    for num in LotteryConfig.BLUE_NUMBERS:
        LotteryConfig.NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": "#0000FF", "border": "#0000FF"}
    for num in LotteryConfig.GREEN_NUMBERS:
        LotteryConfig.NUMBER_COLORS[num] = {"bg": "#FFFFFF", "text": "#008000", "border": "#008000"}

    # 全局刷新（本页实现，内部再刷新其他页面） + 记忆到 INI
    apply_custom_number_colors(host)
    host._save_custom_number_colors()
    if hasattr(host, '_legend_labels'):
        groups_text = [
            ' '.join(str(n).zfill(2) for n in LotteryConfig.RED_NUMBERS),
            ' '.join(str(n).zfill(2) for n in LotteryConfig.BLUE_NUMBERS),
            ' '.join(str(n).zfill(2) for n in LotteryConfig.GREEN_NUMBERS),
        ]
        for label, text in zip(host._legend_labels.get('nums', []), groups_text):
            if label:
                label.setText(text)
    status_label.setText("已应用并保存：红 " + str(len(LotteryConfig.RED_NUMBERS)) + " 个 / 蓝 "
                         + str(len(LotteryConfig.BLUE_NUMBERS)) + " 个 / 绿 " + str(len(LotteryConfig.GREEN_NUMBERS)) + " 个")
    status_label.setStyleSheet("font-size: 20px; color: #2ECC71; font-weight: bold;")


def _build_color_tab(host):
    """构建颜色设置对话框的内容页（红/蓝/绿输入框 + 应用/恢复默认）

    功能:
        创建三行“彩色标签 + 号码输入框”，底部为「应用」「恢复默认」按钮与状态提示。

    参数:
        host (LotteryPredictionWindow): 主窗口实例；三个输入框与状态标签会挂到
            host（color_red_edit / color_blue_edit / color_green_edit /
            color_status_label）。

    返回:
        QWidget: 可直接放进 QDialog 的内容页。

    副作用:
        在 host 上创建上述四个控件，并用当前 LotteryConfig 三色名单填充输入框；
        连接「应用」到 _apply_color_groups、「恢复默认」到 _reset_color_edits。
        本函数不显示对话框，显示由 _open_color_dialog 负责。

    说明:
        为什么三行输入框用同一套高度/字号：避免红蓝绿行出现高低差；标签固定
        40px 宽让三行输入框左边缘对齐，便于逐行核对。按钮的 min/max-height
        写成“内容高 + padding + border = 40px”，是为了与同排角控件保持等高基线。
    """
    page = QWidget()
    page_layout = QVBoxLayout(page)
    page_layout.setContentsMargins(16, 14, 16, 14)  # 左右 16px、上下 14px：内容不贴对话框边缘
    page_layout.setSpacing(12)                       # 行间距 12px：三行输入框与按钮区不拥挤

    grid = QGridLayout()
    grid.setHorizontalSpacing(12)  # 列间距 12px：「红/蓝/绿」标签与输入框之间留白
    grid.setVerticalSpacing(10)    # 行间距 10px：红/蓝/绿三行之间留白

    host.color_red_edit = QLineEdit()
    host.color_blue_edit = QLineEdit()
    host.color_green_edit = QLineEdit()
    edits = [
        ("红", host.color_red_edit, "#FF0000", LotteryConfig.RED_NUMBERS),
        ("蓝", host.color_blue_edit, "#0000FF", LotteryConfig.BLUE_NUMBERS),
        ("绿", host.color_green_edit, "#008000", LotteryConfig.GREEN_NUMBERS),
    ]
    for row, (name, edit, color, numbers) in enumerate(edits):
        label = QLabel(name)
        label.setFixedWidth(40)  # 固定 40px 宽：三行标签左对齐一致，输入框起止位置齐平
        label.setStyleSheet("font-size: 20px; /* 字号：20px，清晰可读 */"
                            "font-weight: bold; /* 文字加粗 */"
                            "color: " + color + "; /* 文字颜色：与所属分组同色（红/蓝/绿） */")
        edit.setText(' '.join(str(n).zfill(2) for n in numbers))
        edit.setPlaceholderText("例如 01 02 07，支持空格/逗号/顿号/换行")
        edit.setMinimumHeight(40)  # 最小高 40px：15px 以上字号下文字不被裁切
        edit.setStyleSheet("QLineEdit { background-color: #FFFFFF; /* 背景：纯白，便于看清号码 */"
                           "border: 1px solid " + color + "; /* 边框：1px 本组颜色（红/蓝/绿） */"
                           "border-radius: 6px; /* 圆角：6px */"
                           "padding: 6px 10px; /* 内边距：上下 6px、左右 10px，文字不贴边 */"
                           "font-size: 20px; /* 字号：20px，清晰可读 */ }")
        grid.addWidget(label, row, 0)
        grid.addWidget(edit, row, 1)
    page_layout.addLayout(grid)

    host.color_status_label = QLabel("修改后可点「应用」，立即全局生效并记住")
    host.color_status_label.setWordWrap(True)
    host.color_status_label.setStyleSheet("font-size: 20px; /* 字号：20px，清晰可读 */"
                                          "color: #888888; /* 文字颜色：灰色，弱化提示文字 */")
    page_layout.addWidget(host.color_status_label)
    # 弹性留白：窗口高度富余时由这里吸收，避免提示文字被纵向拉成大片空白、按钮区被顶到中间
    page_layout.addStretch(1)

    btn_row = QHBoxLayout()
    btn_row.setSpacing(8)  # 按钮间距 8px：「应用」与「恢复默认」不贴在一起
    apply_btn = QPushButton("应用")
    apply_btn.setMinimumHeight(40)  # 最小高 40px：与应用区角按钮高度一致
    apply_btn.setStyleSheet(
        "QPushButton { background-color: #FFFFFF; /* 默认背景：白色 */"
        "color: #2ECC71; /* 默认文字：绿色（确认/应用） */"
        "border: 2px solid #2ECC71; /* 边框：2px 实线绿色 */"
        "border-radius: 6px; /* 圆角：6px */"
        "font-weight: bold; /* 文字加粗 */"
        "font-size: 20px; /* 字号：20px，清晰可读 */"
        "padding: 4px 24px; /* 内边距：上下 4px、左右 24px，文字与边框留足距离 */"
        "min-height: 28px; /* 内容最小高 28px：加 8px 内边距与 4px 边框后实际 40px，与「恢复默认」等高 */"
        "max-height: 28px; /* 内容最大高 28px：锁定实际 40px，两按钮等高同基线 */ }"
        "QPushButton:hover { background-color: #2ECC71; /* 悬停背景：绿色填充 */"
        "color: #FFFFFF; /* 悬停文字：白色 */ }"
    )
    apply_btn.clicked.connect(lambda: _apply_color_groups(
        host, DataUtils.parse_numbers_text(host.color_red_edit.text(), dedupe=True, limit_range=True),
        DataUtils.parse_numbers_text(host.color_blue_edit.text(), dedupe=True, limit_range=True),
        DataUtils.parse_numbers_text(host.color_green_edit.text(), dedupe=True, limit_range=True),
        host.color_status_label))
    btn_row.addWidget(apply_btn)

    reset_btn = QPushButton("恢复默认")
    reset_btn.setMinimumHeight(40)  # 最小高 40px：与应用按钮齐平
    reset_btn.setStyleSheet(
        "QPushButton { background-color: #FFFFFF; /* 默认背景：白色 */"
        "color: #E74C3C; /* 默认文字：红色（重置/危险操作） */"
        "border: 1px solid #E74C3C; /* 边框：1px 实线红色 */"
        "border-radius: 6px; /* 圆角：6px */"
        "font-weight: bold; /* 文字加粗 */"
        "font-size: 20px; /* 字号：20px，清晰可读 */"
        "padding: 4px 16px; /* 内边距：上下 4px、左右 16px，文字不贴边 */"
        "min-height: 30px; /* 内容最小高 30px：加 8px 内边距与 2px 边框后实际 40px，与「应用」等高 */"
        "max-height: 30px; /* 内容最大高 30px：锁定实际 40px，两按钮等高同基线 */ }"
        "QPushButton:hover { background-color: #E74C3C; /* 悬停背景：红色填充 */"
        "color: #FFFFFF; /* 悬停文字：白色 */ }"
    )
    reset_btn.clicked.connect(lambda: _reset_color_edits(host))
    btn_row.addWidget(reset_btn)
    btn_row.addStretch()
    page_layout.addLayout(btn_row)
    return page


def _open_color_dialog(host):
    """点击「颜色设置」后显示颜色设置对话框（关闭后再次点击可重新打开）

    功能:
        每次打开前用当前生效的三色名单重填输入框，然后以非模态方式显示对话框。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备
            color_settings_dialog 与三个输入框。

    返回:
        None

    副作用:
        覆盖 host.color_red_edit / color_blue_edit / color_green_edit 的文本；
        重置 host.color_status_label 的提示文字与样式；
        对对话框执行 show() / raise_() / activateWindow()（不阻塞主界面）。

    说明:
        每次打开都重填是为了避免显示上次未应用就被关闭的旧内容；非模态
        （setModal(False)）让用户能同时观察主面板的号码颜色变化。
        若对话框尚未构建（dialog 为 None）则静默返回，防止在 build 之前误调用。
    """
    dialog = getattr(host, 'color_settings_dialog', None)
    if dialog is None:
        return
    # 打开时同步当前生效的分组，避免显示旧内容
    host.color_red_edit.setText(' '.join(str(n).zfill(2) for n in LotteryConfig.RED_NUMBERS))
    host.color_blue_edit.setText(' '.join(str(n).zfill(2) for n in LotteryConfig.BLUE_NUMBERS))
    host.color_green_edit.setText(' '.join(str(n).zfill(2) for n in LotteryConfig.GREEN_NUMBERS))
    host.color_status_label.setText("修改后点「应用」，立即全局生效并记住")
    host.color_status_label.setStyleSheet("font-size: 20px; color: #888888;")
    dialog.show()
    dialog.raise_()
    dialog.activateWindow()


def _reset_color_edits(host):
    """把三个输入框恢复为当前生效的分组（不改变全局颜色）

    功能:
        放弃用户在对话框里尚未应用的修改，重新用 LotteryConfig 的三色名单填充。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None

    副作用:
        覆盖三个输入框文本与状态标签样式；不修改任何全局颜色与配置。

    说明:
        「恢复默认」按钮的语义是“撤销本次编辑”，不是 lib 的出厂默认分组；
        真正恢复出厂色需要用户手动填入默认名单再点「应用」，避免误触就丢掉
        用户长期维护的分组。
    """
    host.color_red_edit.setText(' '.join(str(n).zfill(2) for n in LotteryConfig.RED_NUMBERS))
    host.color_blue_edit.setText(' '.join(str(n).zfill(2) for n in LotteryConfig.BLUE_NUMBERS))
    host.color_green_edit.setText(' '.join(str(n).zfill(2) for n in LotteryConfig.GREEN_NUMBERS))
    host.color_status_label.setText("已恢复为当前生效的分组")
    host.color_status_label.setStyleSheet("font-size: 20px; color: #888888;")


def apply_custom_number_colors(host):
    """把 LotteryConfig.NUMBER_COLORS 应用到全部页面的号码控件

    功能:
        原主窗口 `_apply_custom_number_colors` 原样迁入数字选择页。颜色本身
        全局共享（LotteryConfig.NUMBER_COLORS），但触发入口与编辑界面属于本页；
        迁入后仍会刷新其他页面的显示，保证一处改色全窗口一致。

    参数:
        host: 主窗口实例。读取各页面已挂载的控件与尺寸配置，任一控件缺失时
            用 hasattr 跳过，不抛异常。

    返回:
        None

    副作用:
        重绘数字选择面板/生肖面板/五行面板/预测号码球/历史表格。
        不修改 LotteryConfig 颜色值本身，也不写 INI（保存由调用方负责）。

    降级:
        - 页面尚未构建或控件为空：对应分支静默跳过；
        - 跨页刷新通过函数内延迟导入 TAB 模块完成，避免顶部循环导入，
          与主窗口原实现调用同一批函数，行为完全一致。

    说明:
        颜色图例文字颜色不随号码颜色变化，因此不刷新图例（与原实现一致）。
    """
    # 延迟导入：避免 TAB 页面间顶层循环依赖；调用时所有页面模块已加载
    from TAB import element as _tab_element  # 作用说明：延迟导入五行页模块，用于复用其 refresh_stats 刷新五行统计与号码面板
    from TAB import history as _tab_history  # 作用说明：延迟导入历史页模块，用于复用其 update_history_table 刷新历史表格配色
    from TAB import prediction as _tab_prediction  # 作用说明：延迟导入预测页模块，用于复用其 apply_prediction_ball_size 重排预测号码球

    # 1. 数字选择面板
    if hasattr(host, 'number_panel') and host.number_panel:
        for btn in host.number_panel.number_buttons.values():
            btn._apply_color()
        host.number_panel.layout().invalidate()

    # 2. 生肖面板
    if hasattr(host, 'zodiac_panel') and host.zodiac_panel:
        w = host._zodiac_panel_size.get('width', 44)
        h = host._zodiac_panel_size.get('height', 40)
        bf = host._zodiac_panel_size.get('btn_font', 16)
        lf = host._zodiac_panel_size.get('label_font', 10)
        host.zodiac_panel.set_font_size(width=w, height=h, btn_font=bf, label_font=lf)

    # 3. 五行：分组条 + 下部号码面板
    if hasattr(host, 'elem_num_font_spin'):
        _tab_element.refresh_stats(host)
    if hasattr(host, 'element_grid_panel') and host.element_grid_panel:
        host.element_grid_panel.update_all_elements(host.zodiac_elements)
        host.element_grid_panel.set_font_size(
            btn_font=int(host._element_panel_size.get('btn_font', 16)),
            label_font=int(host._element_panel_size.get('label_font', 12)))

    # 4. 预测结果号码球
    if hasattr(host, 'prediction_number_layout'):
        _tab_prediction.apply_prediction_ball_size(host)

    # 5. 颜色图例（图例文字颜色不随号码颜色变化，无需刷新）

    # 6. 刷新历史表格
    if hasattr(host, 'history_table'):
        _tab_history.update_history_table(host)


def show_panel_settings_dialog(host):
    """打开「数字选择面板尺寸」设置弹窗

    功能:
        由主窗口 `_show_panel_settings_dialog` 的 'number' 分支迁入。弹窗骨架
        在 TAB.widgets.open_panel_size_dialog，本函数只负责本页的尺寸应用与
        字号 spinbox 同步。

    参数:
        host: 主窗口实例。

    返回:
        None

    副作用:
        用户点「应用」后写 host._number_panel_size、host._area_font_scales，
        重设 number_panel 按钮尺寸并同步 num_panel_font_spin（阻断信号避免递归）。

    降级:
        控件缺失时通过 hasattr 跳过，字号保持原值（默认 18）。
    """
    current = getattr(host, '_number_panel_size', {'width': 80, 'height': 60, 'font': 20})

    def _apply(values):
        """把面板尺寸弹窗返回的宽高写回配置并立即应用到号码面板

        功能:
            记录用户确认的宽高（字号沿用当前值），重设 NumberPanel 按钮尺寸，
            同步字号缩放比并回填字号 spinbox。

        参数:
            values (dict): 弹窗回调数据，需含 'width' 与 'height'（单位 px，
                均为 int），字号不在此弹窗内编辑。

        返回:
            无。

        注意:
            写 host._number_panel_size 与 host._area_font_scales；
            回填 spinbox 时先后调用 blockSignals(True/False)，避免 setValue
            触发 valueChanged 造成重复保存或递归；控件缺失时用 hasattr 跳过。
        """
        width = values['width']
        height = values['height']
        # 字号不在此弹窗内编辑，沿用现有值；原实现默认回退 18
        font = host._number_panel_size.get('font', 18)
        host._number_panel_size = {'width': width, 'height': height, 'font': font}
        if hasattr(host, 'number_panel'):
            host.number_panel.set_button_size(width=width, height=height, font_size=font)
        host._area_font_scales['number_panel'] = font / 18.0
        if hasattr(host, 'num_panel_font_spin'):
            host.num_panel_font_spin.blockSignals(True)
            host.num_panel_font_spin.setValue(font)
            host.num_panel_font_spin.blockSignals(False)

    open_panel_size_dialog(host, "数字选择面板尺寸", current, _apply)


def install(host):
    """安装「数字选择」选项卡：构建界面 + 绑定本页事件（v0.0.28 起统一入口）

    功能:
        先构建页面（控件创建与信号连接），再把本页事件接到模块级处理函数。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        QWidget: 构建完成的页面。

    副作用:
        build() 在 host 上创建 num_panel_font_spin、color_settings_dialog、
        number_panel、selected_numbers_label、clear_selection_btn、_legend_labels
        等控件/状态；随后追加连接 valueChanged / number_selected / clicked 三个信号。

    说明:
        颜色设置按钮的 clicked 在 build 内直接连到 _open_color_dialog；
        其余三个信号必须等控件创建完成后再连，因此放在 build 之后。
        用 lambda 而非直接传函数，是为了把 host 固定进闭包，保持主窗口接口不变。
    """
    page = build(host)
    # 本页事件全部由模块内函数处理，主窗口不再保留对应方法
    host.num_panel_font_spin.valueChanged.connect(lambda size: _on_font_changed(host, size))
    host.number_panel.number_selected.connect(lambda nums: _on_selected(host, nums))
    host.clear_selection_btn.clicked.connect(lambda: _on_clear(host))
    return page


def _on_font_changed(host, size):
    """数字字号变更：调整面板字号 + 记忆

    功能:
        记录号码球字号，立即应用到 NumberPanel，并保存 INI。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        size (int): 新字号（px），控件范围 15~150。

    返回:
        None

    副作用:
        写 host._number_panel_size['font']；调用 number_panel.set_button_size()
        重排 49 个号码球；更新 host._area_font_scales['number_panel'] = size / 18.0；
        调用 host._save_ini_config() 写 INI。

    说明:
        set_button_size 需要宽/高/字号三项，字号变化时从配置补全宽高，
        避免按钮尺寸被重置为类默认值。缩放比以默认字号 18px 为基准，
        与主窗口面板设置对话框的算法一致。
    """
    host._number_panel_size['font'] = size
    host.number_panel.set_button_size(
        width=host._number_panel_size.get('width', 50),
        height=host._number_panel_size.get('height', 50),
        font_size=size)
    host._area_font_scales['number_panel'] = size / 18.0
    host._save_ini_config()


def _on_selected(host, numbers):
    """号码选中变化：更新「已选数字」显示

    功能:
        把 NumberPanel 当前选中的号码集合转成逗号分隔文本显示。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        numbers (set[int] | list[int] | None): 当前选中的号码集合。

    返回:
        None

    副作用:
        覆盖 host.selected_numbers_label 文本；空集合显示“无”。

    说明:
        显示前排序，保证同一组选中号码的展示顺序稳定；用 2 位补零会与面板
        的 01~49 显示不一致，因此这里直接输出原始数字（如 1, 5, 9）。
    """
    if numbers:
        host.selected_numbers_label.setText(', '.join(str(n) for n in sorted(numbers)))
    else:
        host.selected_numbers_label.setText("无")


def _on_clear(host):
    """清除号码选择

    功能:
        清空 NumberPanel 中全部选中状态，并把“已选数字”显示复位。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None

    副作用:
        调用 number_panel.clear_selection()（会逐个取消按钮选中态，可能触发
        number_selected 信号，从而也刷新一次标签）；再显式把标签设为“无”。

    说明:
        显式设置“无”是兜底：若 clear_selection 内部批量屏蔽信号，标签就不会
        收到回调，这里保证 UI 与面板状态一致。
    """
    host.number_panel.clear_selection()
    host.selected_numbers_label.setText("无")


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "数字选择",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 4,  # 显示顺序，数字小的排前面
    "enabled": False,  # 三页合并：本页已由「号码属性表」替代，保留文件便于一键回滚
}


def build(host):
    """构建「数字选择」选项卡页面

    功能:
        创建本页完整控件树：标题行（含角控件组与颜色设置按钮）、可滚动号码面板、
        颜色图例（带字号调节）、已选数字栏；并创建隐藏的颜色设置对话框。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已具备 spacing、margin_*、
            _number_panel_size、_legend_font_size 等状态。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用:
        在 host 上创建 num_panel_font_spin、color_settings_dialog、
        number_panel、selected_numbers_label、clear_selection_btn、
        _legend_labels（图例 QLabel 引用，供颜色应用后更新文本）；
        连接颜色设置按钮与图例字号按钮；读取面板字号并初始化号码球。

    说明:
        颜色设置对话框在构建后只创建不显示，用户点「颜色设置」才弹出；
        图例初始文本是 lib 默认的 17/16/16 个号码，应用新分组后由
        _apply_color_groups 覆盖。setStretch(1, 4) 让弹性空白偏右，
        使标题靠左、角控件组贴右端（与生肖页的贴左策略相反）。
    """
    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)

    # 标题行：标题 +（最右端）「数字 px / 尺寸 / 颜色设置」控件组
    top_row = QHBoxLayout()
    top_row.setSpacing(8)
    title = QLabel("数字选择面板（49个数字）")
    title.setObjectName("PanelTitle")
    top_row.addWidget(title)
    top_row.addStretch(1)  # 弹性拉伸：把角控件组推到最右端（四个页面位置一致）

    # 右上角控件组容器：统一 40px 高、间距 6px、距右边缘 8px
    corner_box, corner_layout = make_corner_container()

    # 数字字号标签 + 输入框（蓝色主题）
    add_corner_widget(corner_layout, make_corner_label("数字:", "#1565C0"))

    host.num_panel_font_spin = QSpinBox()
    host.num_panel_font_spin.setRange(15, 150)  # 下限 15px：与全局最小字号一致
    host.num_panel_font_spin.setValue(host._number_panel_size.get('font', 20))  # 默认20px
    host.num_panel_font_spin.setSuffix(" px")
    host.num_panel_font_spin.setToolTip("调整数字选择面板数字字体大小")
    style_corner_spin(host.num_panel_font_spin, "#90CAF9")
    add_corner_widget(corner_layout, host.num_panel_font_spin)

    # 「尺寸」按钮：68×40，与同排标签/输入框同一水平基线
    add_corner_widget(corner_layout, make_corner_size_button(
        lambda: show_panel_settings_dialog(host), "调整面板尺寸设置"))

    corner_layout.addSpacing(CORNER_SECTION_GAP)  # 「尺寸」与「颜色设置」之间留 12px，避免拥挤

    # 颜色设置：默认隐藏，点击按钮才弹出对话框
    color_btn = QPushButton("颜色设置")
    color_btn.setToolTip("打开红 / 蓝 / 绿号码分组设置（应用后全局生效并记忆）")
    color_btn.setFixedSize(96, CORNER_HEIGHT)  # 96×40：与同排控件等高，基线完全一致
    color_btn.setCursor(Qt.CursorShape.PointingHandCursor)  # 悬停显示手型，提示可点击
    color_btn.setStyleSheet(
        "QPushButton {"
        "background-color: #FFFFFF; /* 默认背景：白色，与角控件组其他按钮区分 */"
        "color: #C62828; /* 默认文字：深红色，呼应红/蓝/绿分组的主色 */"
        "border: 2px solid #C62828; /* 边框：2px 实线深红 */"
        "border-radius: 6px; /* 圆角：6px */"
        "font-weight: bold; /* 文字加粗 */"
        "font-size: 15px; /* 字号：15px，满足最小字号要求 */"
        "padding: 0px 12px; /* 内边距：上下 0px、左右 12px，文字不贴边 */"
        "min-height: 36px; /* 内容最小高 36px：加上下 2px 边框后实际 40px */"
        "max-height: 36px; /* 内容最大高 36px：锁定实际 40px，避免全局 min-height:30px 撑高 */"
        "}"
        "QPushButton:hover {"
        "background-color: #C62828; /* 悬停背景：深红填充 */"
        "color: #FFFFFF; /* 悬停文字：白色，保证对比度 */"
        "}"
    )
    color_btn.clicked.connect(lambda: _open_color_dialog(host))
    add_corner_widget(corner_layout, color_btn)

    top_row.addWidget(corner_box)

    # 颜色设置对话框（构建后隐藏，点击「颜色设置」才显示）
    host.color_settings_dialog = QDialog(host)
    host.color_settings_dialog.setWindowTitle("颜色设置")
    host.color_settings_dialog.setModal(False)
    # v0.0.36：由 setFixedSize 改为「最小尺寸 + 初始尺寸」，字号抬到 15px 后窗口可随内容自适应
    host.color_settings_dialog.setMinimumSize(760, 340)  # 最小 760×340：三行输入框与按钮不被裁切
    host.color_settings_dialog.resize(820, 380)          # 初始 820×380：内容上下各留 14px，不贴边也不留大片空白
    color_dialog_layout = QVBoxLayout(host.color_settings_dialog)
    color_dialog_layout.setContentsMargins(16, 12, 16, 12)  # 左右 16px、上下 12px：内容不贴对话框边缘
    color_dialog_layout.addWidget(_build_color_tab(host))

    layout.addLayout(top_row)

    scroll = QScrollArea()
    scroll.setObjectName("NumberScroll")
    scroll.setWidgetResizable(True)
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

    host.number_panel = NumberPanel()
    scroll.setWidget(host.number_panel)

    layout.addWidget(scroll, 1)

    # 颜色图例（带字体大小调节）
    legend_title_layout = QHBoxLayout()
    legend_title = QLabel("颜色图例")
    # 颜色图例标题样式
    #   font-size: 15px;        字体大小：15px
    #   font-weight: bold;      字体：粗体
    #   color: #555;            文字颜色：深灰
    legend_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #555;")
    legend_title_layout.addWidget(legend_title)
    legend_title_layout.addStretch()

    # 图例字号 A-/A+：按钮只发送 ±1 的步进方向，实际范围由主窗口
    # _change_legend_font 统一钳制（标签 15~24px、号码 15~22px）。
    # 15px 是项目全局最小可读字号；号码行下限已与标签统一为 15px，
    # 且 TAB/prediction.py 的 apply_legend_font_size 会把历史 INI 中的
    # 9px 抬到 15px，保证启动首帧就不会出现小字号。
    # 字体缩小按钮
    legend_font_minus = QPushButton("A-")
    legend_font_minus.setToolTip("缩小图例字体")
    legend_font_minus.setFixedSize(70, 24)
    # 图例字体缩小按钮样式 - 紫色系（图例区域用紫色主题）
    #   QPushButton {       按钮常态样式
    #     background-color: #F3E5F5;  背景色：浅紫
    #     color: #6A1B9A;             文字颜色：深紫
    #     border: 1px solid #CE93D8;  边框：1px 紫色实线
    #     border-radius: 5px;         圆角：5px（较小按钮用小圆角）
    #     font-weight: bold;          字体：粗体
    #     font-size: 15px;            字体大小：15px（满足最小字号要求）
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #E1BEE7;  悬停背景色：稍深的浅紫
    #   }
    legend_font_minus.setStyleSheet("QPushButton { background-color: #F3E5F5; color: #6A1B9A; border: 1px solid #CE93D8; border-radius: 5px; font-weight: bold; font-size: 15px; } QPushButton:hover { background-color: #E1BEE7; }")
    # 图例字体减小按钮点击信号：缩小图例字体1px

    legend_font_minus.clicked.connect(lambda: host._change_legend_font(-1))
    legend_title_layout.addWidget(legend_font_minus)

    # 字体放大按钮
    legend_font_plus = QPushButton("A+")
    legend_font_plus.setToolTip("放大图例字体")
    legend_font_plus.setFixedSize(70, 24)
    # 图例字体放大按钮样式 - 绿色系（放大用绿色表示"扩展"）
    #   QPushButton {       按钮常态样式
    #     background-color: #E8F5E9;  背景色：浅绿
    #     color: #2E7D32;             文字颜色：深绿
    #     border: 1px solid #A5D6A7;  边框：1px 绿色实线
    #     border-radius: 5px;         圆角：5px（较小按钮用小圆角）
    #     font-weight: bold;          字体：粗体
    #     font-size: 15px;            字体大小：15px（满足最小字号要求）
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #C8E6C9;  悬停背景色：稍深的浅绿
    #   }
    legend_font_plus.setStyleSheet("QPushButton { background-color: #E8F5E9; color: #2E7D32; border: 1px solid #A5D6A7; border-radius: 5px; font-weight: bold; font-size: 15px; } QPushButton:hover { background-color: #C8E6C9; }")
    # 图例字体增大按钮点击信号：放大图例字体1px

    legend_font_plus.clicked.connect(lambda: host._change_legend_font(1))
    legend_title_layout.addWidget(legend_font_plus)

    layout.addLayout(legend_title_layout)

    legend_widget = QWidget()
    legend_layout = QHBoxLayout(legend_widget)
    legend_layout.setSpacing(15)
    legend_layout.setContentsMargins(5, 2, 5, 2)

    # 暗色主题使用同色系亮色变体，保证在 #1E1E2E 暗底上对比度 ≥4.5:1；
    # 亮色主题保持原有纯红/纯蓝/纯绿，红/蓝/绿波色语义不变。
    if getattr(host, 'is_dark_mode', False):
        legend_red, legend_blue, legend_green = '#FF6B6B', '#89B4FA', '#A6E3A1'
    else:
        legend_red, legend_blue, legend_green = '#FF0000', '#0000FF', '#008000'

    # 缺省回退值统一取 15px（全局字号下限），并强制下限：
    # 任何来源（含历史 INI=9）都不得低于 15px
    label_size = max(15, int(host._legend_font_size.get('label', 15)))
    nums_size = max(15, int(host._legend_font_size.get('nums', 15)))

    # 图例号码必须跟随当前三色分组，不能写死默认分组
    red_label = QLabel("纯红色")
    # 图例标签样式：红系文字（亮色 #FF0000 / 暗色 #FF6B6B），动态字号(label_size)，粗体
    red_label.setStyleSheet(f"color: {legend_red}; /* 文字色：红系（暗色用亮珊瑚） */ font-size: {label_size}px; /* 字号：图例标签字号（A-/A+ 调整） */ font-weight: bold; /* 加粗：与号码行区分 */")
    red_nums = QLabel(_legend_numbers_text(LotteryConfig.RED_NUMBERS))
    # 图例数字样式：红系文字，动态字号(nums_size)
    red_nums.setStyleSheet(f"color: {legend_red}; /* 文字色：红系（暗色用亮珊瑚） */ font-size: {nums_size}px; /* 字号：号码行字号（A-/A+ 调整） */")
    red_nums.setWordWrap(True)
    legend_layout.addWidget(red_label)
    legend_layout.addWidget(red_nums, 1)

    blue_label = QLabel("纯蓝色")
    # 图例标签样式：蓝系文字（亮色 #0000FF / 暗色 #89B4FA），动态字号(label_size)，粗体
    blue_label.setStyleSheet(f"color: {legend_blue}; /* 文字色：蓝系（暗色用亮蓝） */ font-size: {label_size}px; /* 字号：图例标签字号（A-/A+ 调整） */ font-weight: bold; /* 加粗：与号码行区分 */")
    blue_nums = QLabel(_legend_numbers_text(LotteryConfig.BLUE_NUMBERS))
    # 图例数字样式：蓝系文字，动态字号(nums_size)
    blue_nums.setStyleSheet(f"color: {legend_blue}; /* 文字色：蓝系（暗色用亮蓝） */ font-size: {nums_size}px; /* 字号：号码行字号（A-/A+ 调整） */")
    blue_nums.setWordWrap(True)
    legend_layout.addWidget(blue_label)
    legend_layout.addWidget(blue_nums, 1)

    green_label = QLabel("深绿色")
    # 图例标签样式：绿系文字（亮色 #008000 / 暗色 #A6E3A1），动态字号(label_size)，粗体
    green_label.setStyleSheet(f"color: {legend_green}; /* 文字色：绿系（暗色用亮绿） */ font-size: {label_size}px; /* 字号：图例标签字号（A-/A+ 调整） */ font-weight: bold; /* 加粗：与号码行区分 */")
    green_nums = QLabel(_legend_numbers_text(LotteryConfig.GREEN_NUMBERS))
    # 图例数字样式：绿系文字，动态字号(nums_size)
    green_nums.setStyleSheet(f"color: {legend_green}; /* 文字色：绿系（暗色用亮绿） */ font-size: {nums_size}px; /* 字号：号码行字号（A-/A+ 调整） */")
    green_nums.setWordWrap(True)
    legend_layout.addWidget(green_label)
    legend_layout.addWidget(green_nums, 1)

    layout.addWidget(legend_widget)

    # 保存图例标签引用，便于后续更新
    host._legend_labels = {
        'labels': [red_label, blue_label, green_label],
        'nums': [red_nums, blue_nums, green_nums]
    }

    # 已选数字
    selected_layout = QHBoxLayout()
    selected_label = QLabel("已选数字:")
    selected_layout.addWidget(selected_label)
    host.selected_numbers_label = QLabel("无")
    host.selected_numbers_label.setObjectName("SelectedNumbersLabel")
    selected_layout.addWidget(host.selected_numbers_label)
    selected_layout.addStretch()
    clear_btn = QPushButton("清除")
    host.clear_selection_btn = clear_btn
    selected_layout.addWidget(clear_btn)
    layout.addLayout(selected_layout)

    # 控件组保持偏右（原「控件位置」功能已删除，默认右对齐）
    top_row.setStretch(1, 4)

    return widget
