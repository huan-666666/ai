# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/__init__.py - 选项卡页面包（自动发现入口）
===========================================================================
模块职责：
    1. 声明 TAB 为 Python 包；
    2. 作为「页面自动发现入口」：扫描本包内的页面模块，筛出合格页面并按
       显示顺序汇总成列表，主窗口拿到列表后一次性装载全部选项卡。

在架构中的位置：
    run.py 只负责创建 QApplication 与主窗口；主窗口
    LotteryPredictionWindow（位于 plugins/彩票预测.py）在初始化时调用
    iter_tab_pages() 取得页面清单，再逐页调用 install(host) / build(host)
    并用 QTabWidget.addTab 挂到选项卡栏。因此 TAB/ 属于界面层，
    页面只允许从 UI/UI.py 导入 Qt 控件，计算逻辑下沉到 lib/。

调用方：
    - plugins/彩票预测.py（主窗口初始化时的选项卡装配区域）
    - 需要枚举全部选项卡的辅助脚本（如文档索引生成）

约定（每个选项卡文件必须遵守）：
    1. 导出 build(host) -> QWidget；host 为主窗口实例（LotteryPredictionWindow）
       优先导出 install(host) -> QWidget：构建界面 + 绑定本页事件（v0.0.28 起推荐）
       自动发现时优先调用 install，没有时才回退 build。
       两种函数都必须返回 QWidget；install 之所以是首选，是因为它能在构建
       界面前把 host._on_xxx 回调就位，而 build 里的按钮会直接连接这些属性。
    2. 模块级声明 TAB_INFO：
           TAB_INFO = {"title": "选项卡标题", "order": 1, "enabled": True}
       title   —— 必填，显示在顶部选项卡栏的文字
       order   —— 显示顺序，数字小的排前面（相同则按标题排序；缺省按 999）
       enabled —— 可选，False 表示临时隐藏本页（不必改主窗口）
       本函数把 TAB_INFO 视为“页面注册表”：没有声明、enabled 为 False、
       或既没有 install 也没有 build 的模块一律跳过。
    3. 文件名以 _ 开头、或名为 widgets 的公共模块不会被当作页面加载
       （widgets.py 是共享控件库，不是选项卡，因此只能靠文件名规则排除）
===========================================================================
"""
import importlib  # 作用说明：提供按模块名动态导入的能力，自动发现时无需预先写死页面清单
import pkgutil  # 作用说明：提供遍历包内子模块的能力，用于扫描 TAB/ 目录下的候选选项卡文件


def iter_tab_pages():
    """自动发现 TAB/ 下的选项卡页面

    功能:
        扫描 TAB/ 包内除下划线开头与 widgets 之外的模块，导入并读取其
        TAB_INFO，筛出启用且实现 install/build 的页面，汇总为有序清单。

    参数:
        无（页面清单由本包目录结构与各模块的 TAB_INFO 决定）

    返回:
        list[tuple[int, str, module]]: 按 (order, title) 升序排列的
        (显示顺序, 选项卡标题, 页面模块)，供主窗口按序 addTab。

    副作用:
        1) 对每个候选文件执行 importlib.import_module：模块顶层代码只执行一次，
           之后进入 sys.modules 缓存，重复调用本函数不会重复执行页面顶层代码；
        2) 首次导入页面模块会连带导入其依赖（UI/、lib/），并可能触发
           页面模块的初始化副作用（例如建立常量、读取配置），但本页面的
           界面控件不会因导入而创建（构建只发生在 install/build 中）。

    异常:
        页面模块在导入期抛异常时异常会向上传播（本函数不捕获），
        以便启动阶段立即暴露坏掉的页面，而不是静默少一个选项卡。

    说明：
        只导入声明了 TAB_INFO 且 enabled 为 True、并实现 install(host) 或 build(host) 的模块；
        新增页面只需新建 TAB/xxx.py 并声明 TAB_INFO，主窗口无需改动。
    """
    pages = []
    for module_info in pkgutil.iter_modules(__path__):
        name = module_info.name
        # 下划线开头视为停用页；widgets 是公共控件库，不是页面
        if name.startswith('_') or name == 'widgets':
            continue
        module = importlib.import_module('%s.%s' % (__name__, name))
        meta = getattr(module, 'TAB_INFO', None)
        if not meta or not meta.get('enabled', True):
            continue
        if not hasattr(module, 'install') and not hasattr(module, 'build'):
            continue
        # order 缺省 999：未声明顺序的页面统一排到最后，避免插队到已有的有序页面中间
        pages.append((meta.get('order', 999), meta.get('title', name), module))
    # 先按 order 再按标题：order 相同的页面有确定顺序，不依赖文件系统的遍历顺序
    pages.sort(key=lambda item: (item[0], item[1]))
    return pages
