# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/data_storage.py - 「数据存储」选项卡页面构建模块
===========================================================================
模块职责：
    [15] 数据存储页的全部界面构建与业务封装：
        1) 存储目录/索引定位（程序目录/系统v7.5/数据存储/index.json）
        2) 索引读写与磁盘扫描同步（把用户手工放进目录的文件补进索引）
        3) 图片 / 笔记 / 数据文件的导入（按钮、拖拽、Ctrl+V 三种入口）
        4) 分类 / 标签 / 关键词筛选与六种排序
        5) 卡片网格与紧凑列表双视图、单个/批量删除、重命名
        6) 整目录 ZIP 一键备份

在架构中的位置：
    TAB/ 界面层的一个页面。run.py 按 TAB_INFO（order=15）调用 install(host)；
    install 把本模块函数逐个以 lambda 绑定到主窗口 LotteryPredictionWindow
    的 host._xxx 属性（host 即主窗口），build(host) 再返回页面 QWidget。
    数据流：磁盘 images/notes/files ←→ index.json（主存储）
            ←→ SQLite storage_items 表（index.json 丢失时的恢复镜像）
            → 界面表格/卡片（只读展示，不做回写）。

依赖：
    - lib.db_helper.get_db() 产物 host._db（SQLite 业务库），初始化失败时
      host._db 为 None，本页自动降级为纯文件模式（只用 index.json）
    - UI/UI.py 统一导出的 Qt 控件（禁止直接 from PyQt6 import xxx）
    - 仅标准库 os/sys/json/datetime/shutil/zipfile/subprocess，
      禁止引入 numpy/pandas/matplotlib 等重型库

导出对象：
    TAB_INFO            —— 选项卡声明（title=数据存储, order=15, enabled=True）
    install(host)       —— 绑定 host._xxx 事件入口，返回 build 的页面控件
    build(host)         —— 构建页面控件（顶部拖拽条 + 左侧导航 + 右侧双视图）
    其余模块级函数均为页面内部实现，只经 host._xxx 属性被信号/回调调用。

约束：
    - 所有函数都是“自由函数 + host 显式传参”，不使用类 self，便于页面搬迁
    - 磁盘/数据库异常一律降级（打印或弹框），不允许中断界面主流程
    - v0.0.28 起页面自包含（原实现位于主窗口类，已迁回本模块）
===========================================================================
"""

import os as _os_boot  # 作用说明：启动引导专用的 os 别名，在导入 UI/本项目模块之前先用它定位项目根目录（避开后续正式 import os 的命名冲突）
import sys as _sys_boot  # 作用说明：启动引导专用的 sys 别名，把上一步算出的项目根目录插入 sys.path，使直接运行本文件时也能 import UI

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

import datetime  # 作用说明：生成 created_at/updated_at 时间戳与备份文件默认名（strftime 格式化）
import json  # 作用说明：读写 index.json 索引以及 notes/*.json 单篇笔记正文（load/dump）
import os  # 作用说明：路径拼接与存在性判断、建目录（makedirs）、遍历/统计磁盘文件（walk/listdir/stat）
import sys  # 作用说明：读取 sys.platform 区分 darwin/其他平台，用于选择打开文件夹的系统命令

from UI import (QApplication, QComboBox, QDialog, QFileDialog, QFrame, QGridLayout, QHBoxLayout,  # 作用说明：Qt 控件与枚举的统一出口（项目分层规则：TAB 层禁止直接 from PyQt6 import xxx，全部经 UI 包导出）
                QIcon, QInputDialog, QKeySequence, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                QMainWindow, QMenu, QMessageBox, QPixmap, QPushButton, QScrollArea, QShortcut,
                QSplitter, QStackedWidget, QTextEdit, QVBoxLayout, QWidget, Qt)


# [数据存储：索引/筛选/卡片/笔记/文件/备份/拖拽上传]

def get_storage_btn_style(host, color):
    """生成数据存储页工具栏按钮的 QSS 样式（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        统一“上传图片/新建笔记/导入文件”等主操作按钮的白字圆角外观，
        只把背景色作为变量，其它尺寸与字号固定，保证工具栏四种按钮视觉一致。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。本函数当前不读取 host 的任何属性，
            保留该参数只为与 install 中 `host._get_storage_btn_style = lambda color: ...`
            的统一“handler(host, ...)”签名保持一致。
        color (str): 按钮背景色，十六进制字符串（如 "#27AE60"/"#3498DB"/"#F39C12"）。

    返回:
        str: QSS 样式字符串，可直接传给 QPushButton.setStyleSheet。

    副作用/异常:
        纯字符串拼接，无副作用、不抛异常。
    【可改】修改按钮的内边距、圆角、字体大小等
    """
    return f"""
        QPushButton {{
            padding: 8px 16px;       /* 【可改】按钮内边距（上下 左右）*/
            border: none;
            border-radius: 6px;      /* 【可改】圆角大小 */
            font-size: 15px;         /* 【可改】字体大小 */
            font-weight: 500;        /* 【可改】字体粗细 */
            color: white;
            background-color: {color};
        }}
        QPushButton:hover {{
            background-color: {color};
            opacity: 0.9;            /* 【可改】悬停时透明度，值越小越透明 */
        }}
        QPushButton:pressed {{
            background-color: {color};
        }}
    """

def get_storage_dir(host):
    """获取数据存储根目录路径（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        把本页所有文件收敛到「程序目录/系统v7.5/数据存储」一个目录，
        exe 打包后随程序目录整体搬迁/备份，避免散落在用户目录。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读取 host._data_dir
            （主窗口 __init__ 中赋值为 程序目录/系统v7.5）。

    返回:
        str: 存储根目录绝对路径（不保证目录已存在，创建由 ensure_storage_dirs 负责）。

    副作用/异常:
        只做字符串拼接，不创建目录、不抛异常。
    【可改】修改"数据存储"为其他文件夹名称
    """
    # 与历史数据、数据库、配置共用 host._data_dir，保证“一个目录即全部数据”
    storage_dir = os.path.join(host._data_dir, "数据存储")  # 【可改】文件夹名称
    return storage_dir

def ensure_storage_dirs(host):
    """确保存储子目录存在，不存在则创建（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        建立固定三类子目录，供后续导入按类型落盘：
        images（图片）、notes（笔记 JSON）、files（其它数据文件）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，经 host._get_storage_dir()
            取存储根目录。

    返回:
        None。

    副作用:
        在磁盘上创建目录（已存在则跳过）；权限不足时 os.makedirs 的异常
        不在这里捕获，由各导入函数的 try/except 统一转成弹框提示。

    异常:
        OSError（目录不可写、路径被同名文件占用等）向外抛出。
    【可改】增删子目录，如添加"videos"、"documents"等
    """
    base_dir = host._get_storage_dir()
    # 【可改】子目录列表，可根据需要添加新分类
    dirs = [
        os.path.join(base_dir, "images"),  # 图片存储目录
        os.path.join(base_dir, "notes"),   # 笔记存储目录
        os.path.join(base_dir, "files"),   # 其他文件目录
    ]
    for d in dirs:
        if not os.path.exists(d):
            os.makedirs(d)

def init_storage_data(host):
    """初始化数据存储页的目录、内存状态与索引（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        1. 确保 images/notes/files 三个子目录存在
        2. 在 host 上挂载存储页所需的全部状态属性（见下）
        3. 从 index.json（缺失时回退 SQLite 镜像）加载索引
        4. 扫描磁盘补齐索引中缺失的文件，并刷新标签列表

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    副作用（写入的 host 属性）:
        _storage_index_path (str)   —— index.json 绝对路径
        _storage_items (list[dict]) —— 全部存储项（id/type/title/content/
                                        file_path/tags/created_at/updated_at/size）
        _storage_tags (set[str])    —— 全部标签（去重）
        _current_storage_category / _current_storage_search / _current_storage_tag
                                    —— 当前筛选条件
        _storage_sort_mode (str)    —— 排序模式，默认 time_desc
        _category_collapsed / _tag_collapsed (bool) —— 左侧面板折叠状态

    返回:
        None。

    调用方:
        build(host) 末尾在控件全部创建完成后调用一次；
        外部刷新时由 host._init_storage_data 触发。

    异常:
        内部各步骤自行吞掉文件/数据库异常，本函数不向外抛。
    【可改】修改默认排序方式、默认分类等
    """
    host._ensure_storage_dirs()
    # 索引固定放在存储根目录，随目录一起被一键备份打包
    host._storage_index_path = os.path.join(host._get_storage_dir(), "index.json")  # 索引文件路径
    host._storage_items = []      # 所有存储项列表，每项是一个字典
    host._storage_tags = set()    # 所有标签的集合（去重）
    # 已由 _load_ini_config 恢复的值必须保留，只有属性不存在时才用默认值
    # （搜索词/标签筛选不持久化，仍按空值初始化）
    host._current_storage_category = getattr(host, '_current_storage_category', "all")
    host._current_storage_search = ""        # 当前搜索关键词
    host._current_storage_tag = ""           # 当前选中的标签筛选
    host._storage_sort_mode = getattr(host, '_storage_sort_mode', "time_desc")
    
    # 左侧面板折叠状态同样保留 INI 已恢复的值
    host._category_collapsed = getattr(host, '_category_collapsed', False)
    host._tag_collapsed = getattr(host, '_tag_collapsed', False)
    
    # 加载索引（从JSON文件读取元数据）
    host._load_storage_index()
    # 扫描文件系统，确保索引与实际文件同步
    host._sync_storage_files()
    # 更新标签列表
    host._update_tag_list()

def load_storage_index(host):
    """从 index.json 加载存储索引，失败时回退 SQLite 镜像（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        读取索引文件并填充 host._storage_items / host._storage_tags；
        JSON 缺失、损坏或 items 为空时，尝试用 SQLite storage_items 表恢复，
        保证“文件丢了索引仍在”的场景下用户数据可见。

    索引文件结构:
        {
            "items": [...],      // 所有存储项列表
            "tags": [...],       // 所有标签列表
            "version": "1.0"     // 版本号
        }
    每个存储项的字段:
        id / type(image|note|file) / title / content（仅笔记） / file_path /
        tags / created_at / updated_at / size（字节）

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已有 _storage_index_path 与
            可选的 _db（SQLite 封装，None 表示未启用数据库）。

    返回:
        None。

    副作用:
        覆盖 host._storage_items 与 host._storage_tags；
        从数据库恢复成功时额外打印恢复条数。不写回任何文件。

    异常:
        所有异常内部捕获并打印，最终保证两个属性至少为空列表/空集合。
    """
    try:
        if os.path.exists(host._storage_index_path):
            with open(host._storage_index_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                host._storage_items = data.get('items', [])
                host._storage_tags = set(data.get('tags', []))
    except Exception as e:
        print("加载存储索引失败:", str(e))
        # 加载失败时重置为空，避免程序崩溃
        host._storage_items = []
        host._storage_tags = set()

    # JSON 索引为空时，尝试从 SQLite 镜像恢复（数据库异常不影响主流程）
    if not host._storage_items and getattr(host, '_db', None) is not None:
        try:
            items, tags = host._db.load_storage_items()
            if items:
                host._storage_items = items
                host._storage_tags = set(tags)
                print("存储索引已从数据库恢复 " + str(len(items)) + " 条")
        except Exception as e:
            print("从数据库恢复存储索引失败:", str(e))

def make_unique_storage_identity(host, id_prefix, name_prefix, ext, subdir):
    """生成不会撞车的存储项 ID、文件名与目标路径（v0.0.42 新增）

    功能:
        旧实现只精确到秒，同一秒内连续导入/新建会得到相同 ID 与文件名，
        后一条覆盖前一条；本函数改用时戳 + 微秒，并在与现有索引 ID 或磁盘文件
        重名时追加递增序号，保证 ID 与磁盘文件一一对应。

    参数:
        host: 主窗口实例，读取 _get_storage_dir() 与 _storage_items。
        id_prefix (str): ID 前缀（img_ / file_ / note_）。
        name_prefix (str): 文件名前缀（保留原文件名时形如 "原名_"；笔记传空串）。
        ext (str): 文件扩展名（含点，如 ".png"；笔记为 ".json"）。
        subdir (str): 存储根下的子目录（images / files / notes）。

    返回:
        tuple[str, str, str]: (item_id, file_name, file_path)。

    副作用:
        无（只做存在性检查，不创建文件）。
    """
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    suffix = 0
    while True:
        tail = f"_{suffix}" if suffix else ""
        file_name = f"{name_prefix}{stamp}{tail}{ext}"
        item_id = f"{id_prefix}{stamp}{tail}"
        file_path = os.path.join(host._get_storage_dir(), subdir, file_name)
        if not os.path.exists(file_path) and not any(
                i.get('id') == item_id for i in host._storage_items):
            return item_id, file_name, file_path
        suffix += 1


def save_storage_index(host):
    """把存储索引写入 index.json，并镜像到 SQLite（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        每次数据变更（导入/删除/重命名/改标签/同步扫描）后持久化：
        先整体覆盖写 JSON（主存储），成功后再覆盖 SQLite storage_items 表（镜像）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读取 _storage_index_path /
            _storage_items / _storage_tags / _db。

    返回:
        bool: JSON 主存储写盘是否成功。False 表示索引未落盘，
        调用方必须提示失败，不能继续宣称“保存成功”。

    副作用:
        覆盖写磁盘 index.json（ensure_ascii=False + indent=2，便于人工查看）；
        数据库存在时写 SQLite（DELETE 全表 + 批量 INSERT，整体覆盖语义）。

    异常:
        JSON 写盘异常被捕获并打印，同时返回 False；数据库镜像异常单独捕获打印，
        不影响 JSON 写盘结果（SQLite 只是镜像，JSON 才是主存储）。
    """
    ok = True
    try:
        data = {
            'items': host._storage_items,
            'tags': list(host._storage_tags),  # set转list才能序列化
            'version': '1.0'  # 【可改】索引版本号，用于未来升级兼容
        }
        with open(host._storage_index_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)  # indent=2美化输出
        # JSON 写盘成功后镜像到 SQLite，数据库异常不影响 JSON 保存
        if getattr(host, '_db', None) is not None:
            try:
                host._db.save_storage_items(host._storage_items, list(host._storage_tags))
            except Exception as e:
                print("存储索引镜像到数据库失败:", str(e))
    except Exception as e:
        print("保存存储索引失败:", str(e))
        ok = False
    return ok


def notify_if_index_save_failed(host):
    """保存索引并在失败时弹窗告知用户（v0.0.42 新增）

    功能:
        封装「保存索引 + 失败提示」的公共收尾动作：调用 host._save_storage_index() 写盘，
        失败时弹 QMessageBox.warning 告诉用户本次变更可能无法持久化，
        成功时静默返回；供导入、删除、重命名等写操作统一复用，避免各处重复写弹窗逻辑。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。需已由 install 绑定
            host._save_storage_index（无参回调，返回 bool），本函数把它当父窗口传给弹窗。

    返回:
        bool: 是否成功写入 index.json。False 时已弹出警告，调用方不应再提示成功。

    注意:
        弹窗是模态的，会阻塞调用方直到用户点击「确定」；
        _save_storage_index 内部已吞掉写盘异常并返回 False，故本函数不会向外抛异常。
    """
    saved = getattr(host, "_save_storage_index")()
    if not saved:
        QMessageBox.warning(
            host, "保存失败",
            "索引写入磁盘失败，本次变更可能无法持久化，请检查磁盘权限或剩余空间。"
        )
    return saved

def sync_storage_files(host):
    """扫描磁盘目录，把新增文件增量补进索引（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        防止用户手工往 images/notes/files 里放文件后界面看不到：
        按 ID 前缀（img_/note_/file_ + 文件名去扩展名）判重，只追加新文件；
        不删除“索引里有、磁盘上已消失”的条目（避免误删用户记录）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读取 _storage_items 与
            _get_storage_dir()。

    返回:
        None。

    副作用:
        追加 host._storage_items（图片/文件取 st_ctime/st_mtime，笔记读 JSON 元数据）；
        笔记标签并入 host._storage_tags；末尾**仅在确有变化**时调用
        _save_storage_index 写盘（判定条件见函数末尾注释）。
        单个文件 stat/读取失败只打印，不中断整轮扫描。

    异常:
        目录不存在时跳过对应分类；os.listdir/os.stat 的异常未在循环内统一捕获，
        极端情况下（目录被删除）会以 OSError 形式传播到调用方。
    【可改】支持的图片格式、笔记格式等
    """
    base_dir = host._get_storage_dir()
    # 扫描前条目数：扫描只会「追加新文件」，因此条目数增加即代表索引内容确有变化；
    # 若扫描后条目数不变，说明本次没有新增文件，索引无需重写。
    item_count_before = len(host._storage_items)
    existing_ids = {item['id'] for item in host._storage_items}  # 已有ID集合，用于去重
    
    # 扫描图片目录
    images_dir = os.path.join(base_dir, "images")
    if os.path.exists(images_dir):
        # 【可改】支持的图片格式列表
        image_extensions = ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp')
        for fname in os.listdir(images_dir):
            fpath = os.path.join(images_dir, fname)
            if os.path.isfile(fpath) and fname.lower().endswith(image_extensions):
                # ID 前缀带类型，保证同名文件落在不同子目录时不会撞 ID
                file_id = f"img_{os.path.splitext(fname)[0]}"  # ID格式：img_文件名
                if file_id not in existing_ids:  # 仅添加新增的
                    stat = os.stat(fpath)
                    host._storage_items.append({
                        'id': file_id,
                        'type': 'image',
                        'title': fname,
                        'file_path': fpath,
                        'tags': [],
                        'created_at': datetime.datetime.fromtimestamp(stat.st_ctime).strftime('%Y-%m-%d %H:%M:%S'),
                        'updated_at': datetime.datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
                        'size': stat.st_size,
                    })
    
    # 扫描笔记目录
    notes_dir = os.path.join(base_dir, "notes")
    if os.path.exists(notes_dir):
        for fname in os.listdir(notes_dir):
            fpath = os.path.join(notes_dir, fname)
            if os.path.isfile(fpath) and fname.endswith('.json'):  # 笔记以.json格式存储
                note_id = f"note_{os.path.splitext(fname)[0]}"  # ID格式：note_文件名
                if note_id not in existing_ids:
                    try:
                        with open(fpath, 'r', encoding='utf-8') as f:
                            note_data = json.load(f)
                        host._storage_items.append({
                            'id': note_id,
                            'type': 'note',
                            'title': note_data.get('title', '未命名笔记'),
                            'content': note_data.get('content', ''),
                            'file_path': fpath,
                            'tags': note_data.get('tags', []),
                            'created_at': note_data.get('created_at', ''),
                            'updated_at': note_data.get('updated_at', ''),
                            'size': os.path.getsize(fpath),
                        })
                        # 收集标签
                        for tag in note_data.get('tags', []):
                            host._storage_tags.add(tag)
                    except Exception as e:
                        print(f"读取笔记 {fname} 失败:", str(e))
    
    # 扫描其他文件目录
    files_dir = os.path.join(base_dir, "files")
    if os.path.exists(files_dir):
        for fname in os.listdir(files_dir):
            fpath = os.path.join(files_dir, fname)
            if os.path.isfile(fpath):
                file_id = f"file_{os.path.splitext(fname)[0]}"  # ID格式：file_文件名
                if file_id not in existing_ids:
                    stat = os.stat(fpath)
                    host._storage_items.append({
                        'id': file_id,
                        'type': 'file',
                        'title': fname,
                        'file_path': fpath,
                        'tags': [],
                        'created_at': datetime.datetime.fromtimestamp(stat.st_ctime).strftime('%Y-%m-%d %H:%M:%S'),
                        'updated_at': datetime.datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
                        'size': stat.st_size,
                    })
    
    # 同步后条件保存索引（为什么不能无条件保存）
    # 旧实现无论扫描结果如何都调用 _save_storage_index：即使「索引为空、磁盘也没有
    # 新文件」，也会整体重写 index.json（刷新 mtime，内容逐字节相同），并镜像执行
    # SQLite 的 DELETE FROM storage_items（空表→空表同样产生 WAL 帧）。
    # 启动链路 init_storage_data → sync_storage_files 每次启动都会走到这里，
    # 于是产生「启动即写库、写索引」的纯浪费 I/O，且没有任何业务变化。
    # 现在只有下面这几种「确实需要保存」的情况才写盘，缺一不可：
    #   ① 本次扫描新增了条目：与函数开头记录的条目数比较，条目变多说明磁盘多出
    #      了用户手工放入的文件，必须写进索引，否则界面上永远看不到它们；
    #   ② index.json 不存在：下次启动的加载链路无文件可读，必须立即补建；
    #   ③ index.json 存在但读不出/结构无效：load_storage_index 遇到损坏文件会退回
    #      SQLite 镜像恢复，若此处不重写，损坏文件会一直残留，后续每次启动都只能
    #      走兜底恢复——所以不能只判断「文件是否存在」，还要校验能否读出 items 列表。
    #   ④ 结构有效但 items 为空、内存里却有条目：说明本次条目是由 SQLite 镜像兜底
    #      恢复的，不写回会让 index.json 永远空着、每次启动都再兜底一次
    #      （本机 storage_items 为空时该条件不成立，不影响「启动零写入」）。
    # 以上情况之外（文件存在、结构有效、条目无新增）直接跳过，启动保持只读。
    should_save = len(host._storage_items) > item_count_before
    index_path = getattr(host, '_storage_index_path', None)
    index_usable = False
    index_items_empty = True
    if index_path and os.path.exists(index_path):
        try:
            with open(index_path, 'r', encoding='utf-8') as f:
                index_data = json.load(f)
            # 结构口径必须与 load_storage_index 一致：顶层是对象且 items 是列表，
            # 否则按「结构无效」处理（顶层为 list、items 为 null 等都无法正常加载）
            index_usable = isinstance(index_data, dict) and isinstance(index_data.get('items'), list)
            if index_usable:
                index_items_empty = not index_data.get('items')
        except Exception as e:
            # 读不出（编码错误/JSON 语法错误/权限不足）一律视为不可用，需要重写
            print("存储索引校验失败，将重新生成:", str(e))
    recovered_from_db = index_usable and index_items_empty and bool(host._storage_items)
    if should_save or not index_usable or recovered_from_db:
        notify_if_index_save_failed(host)

def update_tag_list(host):
    """刷新左侧标签列表面板（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        清空标签列表，先插入「全部标签」（UserRole 为空串表示不筛选），
        再按字母顺序插入 host._storage_tags 中的每个标签，最后选中第一项。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已有 _storage_tag_list 控件。

    返回:
        None。

    副作用:
        重建列表项；setCurrentRow(0) 会触发 currentRowChanged → on_storage_tag_changed
        → 整页刷新，因此标签变化后无需再单独刷新显示。

    异常:
        控件缺失时 AttributeError 会向外抛出（正常流程下 build 先建控件再调用）。
    """
    host._storage_tag_list.clear()
    # 第一项：全部标签
    all_item = QListWidgetItem("🏷️ 全部标签")
    all_item.setData(Qt.ItemDataRole.UserRole, "")
    host._storage_tag_list.addItem(all_item)
    
    # 按字母顺序排列标签
    for tag in sorted(host._storage_tags):
        item = QListWidgetItem(f"  {tag}")  # 前面加空格缩进
        item.setData(Qt.ItemDataRole.UserRole, tag)
        host._storage_tag_list.addItem(item)
    
    # 默认选中第一项
    host._storage_tag_list.setCurrentRow(0)

def toggle_category_panel(host):
    """切换分类面板的展开/折叠状态（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        点击「分类 ▼/▶」标题时反转 _category_collapsed，隐藏/显示分类列表，
        并同步标题箭头方向（▼=展开，▶=折叠）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读写 _category_collapsed /
            _storage_category_list / _storage_cat_title。

    返回:
        None。

    副作用:
        改变控件可见性与标题文字；调用 _save_ini_config() 把折叠状态写入
        配置.ini 的 [Display]（键 storage_category_collapsed / storage_tag_collapsed）。
        下次启动时 _load_ini_config 读回，init_storage_data 会保留已恢复的值。

    异常:
        无（控件均为本页构建期创建）。
    """
    host._category_collapsed = not host._category_collapsed
    host._storage_category_list.setVisible(not host._category_collapsed)
    if host._category_collapsed:
        host._storage_cat_title.setText("分类 ▶")
    else:
        host._storage_cat_title.setText("分类 ▼")
    # 保存配置
    host._save_ini_config()

def toggle_tag_panel(host):
    """切换标签面板的展开/折叠状态（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        点击「标签 ▼/▶」标题时反转 _tag_collapsed，隐藏/显示标签列表并同步箭头。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读写 _tag_collapsed /
            _storage_tag_list / _storage_tag_title。

    返回:
        None。

    副作用:
        改变控件可见性与标题文字；调用 _save_ini_config() 持久化折叠状态。

    异常:
        无。
    """
    host._tag_collapsed = not host._tag_collapsed
    host._storage_tag_list.setVisible(not host._tag_collapsed)
    if host._tag_collapsed:
        host._storage_tag_title.setText("标签 ▶")  # 折叠状态符号
    else:
        host._storage_tag_title.setText("标签 ▼")  # 展开状态符号
    # 保存配置
    host._save_ini_config()

def get_filtered_items(host):
    """按「分类 → 搜索 → 标签 → 排序」四级条件筛选存储项（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        从 host._storage_items 复制一份列表后逐级过滤，返回可直接渲染的新列表，
        不修改原索引数据。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读取 _current_storage_category /
            _current_storage_search / _current_storage_tag / _storage_sort_mode。

    返回:
        list[dict]: 筛选并排序后的存储项列表（浅拷贝，元素仍与原列表共享字典）。

    筛选规则:
        1) 分类: all/images/notes/files 对应 type=image/note/file
        2) 搜索: 不区分大小写，命中 title 或 content 或任一 tag
        3) 标签: 当前标签必须在该项 tags 中
        4) 排序: created_at 字符串（固定 %Y-%m-%d %H:%M:%S 格式，可直接字典序比较）
           / title 小写 / size 数值，六种模式对应下拉框的六项

    副作用:
        仅排序调用方传入的副本，无写库/写盘；不抛异常。
    """
    items = host._storage_items.copy()
    
    # 1. 按分类筛选
    if host._current_storage_category == "images":
        items = [i for i in items if i['type'] == 'image']
    elif host._current_storage_category == "notes":
        items = [i for i in items if i['type'] == 'note']
    elif host._current_storage_category == "files":
        items = [i for i in items if i['type'] == 'file']
    
    # 2. 按搜索关键词筛选（匹配标题、内容、标签）
    if host._current_storage_search:
        keyword = host._current_storage_search.lower()  # 不区分大小写
        items = [i for i in items if 
                 keyword in i.get('title', '').lower() or           # 标题匹配
                 keyword in i.get('content', '').lower() or         # 内容匹配
                 any(keyword in tag.lower() for tag in i.get('tags', []))]  # 标签匹配
    
    # 3. 按标签筛选
    if host._current_storage_tag:
        items = [i for i in items if host._current_storage_tag in i.get('tags', [])]
    
    # 4. 排序
    sort_mode = getattr(host, '_storage_sort_mode', 'time_desc')
    if sort_mode == 'time_desc':
        items.sort(key=lambda x: x.get('created_at', ''), reverse=True)  # 最新优先
    elif sort_mode == 'time_asc':
        items.sort(key=lambda x: x.get('created_at', ''), reverse=False)  # 最早优先
    elif sort_mode == 'name_asc':
        items.sort(key=lambda x: x.get('title', '').lower())  # 名称升序
    elif sort_mode == 'name_desc':
        items.sort(key=lambda x: x.get('title', '').lower(), reverse=True)  # 名称降序
    elif sort_mode == 'size_desc':
        items.sort(key=lambda x: x.get('size', 0), reverse=True)  # 大文件优先
    elif sort_mode == 'size_asc':
        items.sort(key=lambda x: x.get('size', 0), reverse=False)  # 小文件优先
    
    return items

def refresh_storage_display(host):
    """刷新整页存储展示（计数、统计、网格、列表）（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        任何数据变化（导入/删除/改名/筛选/排序/标签更新）后的统一刷新入口：
        先按当前条件取列表，再更新底部计数、左侧统计与两种视图。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None。

    副作用:
        改写 _storage_status_label 文本；触发 _update_storage_stats、
        _refresh_grid_view、_refresh_list_view（会重建卡片与列表项）。
        仅读内存索引，不写盘。

    调用方:
        分类/搜索/排序/标签切换、导入、删除、批量删除、粘贴、重命名、
        笔记保存/更新以及 build 末尾。
    """
    items = host._get_filtered_items()
    
    # 更新状态栏显示的项目数量
    host._storage_status_label.setText(f"共 {len(items)} 个项目")
    # 更新顶部统计信息（图片/笔记/文件数量与总大小）
    host._update_storage_stats()
    
    # 刷新网格视图（卡片）
    host._refresh_grid_view(items)
    
    # 刷新列表视图
    host._refresh_list_view(items)

def refresh_grid_view(host, items):
    """重建网格视图的卡片（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        先清空 QGridLayout 中已有控件，再按每行 4 列重新创建卡片；
        列表为空时放置一条居中的空状态提示。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已有 _storage_grid_layout。
        items (list[dict]): 已经筛选并排序的项目列表。

    返回:
        None。

    副作用:
        从布局中 takeAt 摘下旧控件并 deleteLater（延迟到事件循环空闲再销毁，
        避免在信号回调中立即删除自身导致崩溃）；新建卡片由 host._create_storage_card 完成。

    异常:
        无（卡片创建失败的异常会向上抛出，由触发刷新的操作处理）。
    【可改】列数、空状态提示文字等
    """
    # 清空现有所有卡片
    while host._storage_grid_layout.count():
        item = host._storage_grid_layout.takeAt(0)
        if item.widget():
            item.widget().deleteLater()
    
    # 空状态显示
    if not items:
        empty_label = QLabel("暂无内容\n\n点击上方按钮添加图片、笔记或文件")
        empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # 空状态标签样式：灰色文字，15px字号（不低于全局字号下限），40px 内边距让提示居中
        empty_label.setStyleSheet("color: #999; font-size: 15px; padding: 40px;")
        host._storage_grid_layout.addWidget(empty_label, 0, 0)
        return
    
    # 【可改】每行显示的卡片数量，当前4列
    # 固定 4 列：卡片宽 190px，四列加上间距恰好填满右侧内容区常见宽度，
    # 窗口更宽时由布局均分剩余空间，不随窗口宽度动态增列（避免卡片换列抖动）
    cols = 4
    for idx, item_data in enumerate(items):
        row = idx // cols  # 行号
        col = idx % cols   # 列号
        card = host._create_storage_card(item_data)
        host._storage_grid_layout.addWidget(card, row, col)

def create_storage_card(host, item_data):
    """创建单个存储项目的卡片控件（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        按项目类型组装 190×210 的固定卡片：图标/缩略图区、标题（超 15 字截断）、
        日期+大小、查看/删除按钮、最多 3 个标签（多余显示 +N）。
        按钮回调通过 lambda 把 item_data 传给 host._on_storage_view_item /
        host._on_storage_delete_item。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，用于 _format_file_size 与事件入口。
        item_data (dict): 存储项，至少含 type/title/file_path/size/created_at；
            image 需 QPixmap 可读的 file_path，note 额外用 content。

    返回:
        QFrame: 已完成布局与信号连接的卡片控件。

    副作用:
        读取图片文件生成缩略图（大图会占用内存，但已按 160×80 缩放到显示尺寸）；
        不修改索引、不写盘。

    异常:
        图片读取失败不抛错（pixmap.isNull() 时降级为 emoji 图标）。
    【可改】卡片尺寸、边框样式、内边距等
    """
    card = QFrame()
    card.setFixedSize(190, 210)  # 【可改】卡片固定尺寸（宽×高）
    # 卡片容器样式 - 白底灰边系（圆角卡片，悬停时蓝色边框高亮）
    #   QFrame {
    #     background-color: white;        白色背景
    #     border: 1px solid #E0E0E0;      浅灰边框
    #     border-radius: 8px;             8px圆角
    #   }
    #   QFrame:hover {
    #     border-color: #3498DB;          悬停蓝色边框
    #   }
    card.setStyleSheet("""
        QFrame {
            background-color: white;
            border: 1px solid #E0E0E0;  /* 【可改】边框颜色 */
            border-radius: 8px;           /* 【可改】圆角大小 */
        }
        QFrame:hover {
            border-color: #3498DB;  /* 【可改】悬停时边框颜色（蓝色）*/
        }
    """)
    
    layout = QVBoxLayout(card)
    layout.setContentsMargins(10, 10, 10, 10)  # 【可改】卡片内边距
    layout.setSpacing(8)  # 【可改】卡片内部元素间距
    
    # 图标/缩略图区域
    icon_area = QFrame()
    icon_area.setFixedHeight(90)  # 【可改】图标区域高度
    # 图标区域样式 - 浅灰底系（卡片顶部缩略图/图标背景区）
    icon_area.setStyleSheet("background-color: #F8F9FA; border-radius: 6px;")  # 【可改】背景色和圆角
    icon_layout = QVBoxLayout(icon_area)
    icon_layout.setContentsMargins(0, 0, 0, 0)
    
    if item_data['type'] == 'image':
        # 图片类型：显示缩略图
        pixmap = QPixmap(item_data['file_path'])
        if not pixmap.isNull():
            # 按比例缩放，保持宽高比
            pixmap = pixmap.scaled(160, 80, Qt.AspectRatioMode.KeepAspectRatio, 
                                  Qt.TransformationMode.SmoothTransformation)
            icon_label = QLabel()
            icon_label.setPixmap(pixmap)
            icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            icon_layout.addWidget(icon_label)
        else:
            # 图片加载失败时显示图标
            icon_label = QLabel("🖼️")
            icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            # 图片加载失败图标样式：36px大字号emoji居中
            icon_label.setStyleSheet("font-size: 36px;")
            icon_layout.addWidget(icon_label)
    elif item_data['type'] == 'note':
        # 笔记类型：显示图标 + 内容预览
        icon_label = QLabel("📝")
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # 笔记图标样式：32px大字号emoji居中
        icon_label.setStyleSheet("font-size: 32px;")
        icon_layout.addWidget(icon_label)
        
        # 预览内容（前50个字符）
        content = item_data.get('content', '')[:50]  # 【可改】预览字数
        preview_label = QLabel(content)
        preview_label.setWordWrap(True)
        # 笔记预览文字样式：12px小字号，深灰色，左右8px内边距
        preview_label.setStyleSheet("font-size: 15px; color: #555; padding: 0 8px;")
        preview_label.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        icon_layout.addWidget(preview_label)
    else:
        # 文件类型：显示通用文件图标
        icon_label = QLabel("📄")
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # 文件图标样式：36px大字号emoji居中
        icon_label.setStyleSheet("font-size: 36px;")
        icon_layout.addWidget(icon_label)
    
    layout.addWidget(icon_area)
    
    # 标题（超过15字符截断加省略号）
    title = item_data.get('title', '未命名')
    if len(title) > 15:  # 【可改】标题最大显示字符数
        title = title[:15] + "..."
    title_label = QLabel(title)
    # 卡片标题样式：14px加粗，深灰色文字
    title_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #333;")
    title_label.setWordWrap(True)
    layout.addWidget(title_label)
    
    # 时间和大小信息
    size_str = host._format_file_size(item_data.get('size', 0))
    date_str = item_data.get('created_at', '')[:10]  # 只显示日期部分
    info_label = QLabel(f"{date_str} · {size_str}")
    info_label.setStyleSheet("font-size: 15px; color: #666;")  # 【可改】信息文字样式
    layout.addWidget(info_label)
    
    # 操作按钮区
    btn_layout = QHBoxLayout()
    btn_layout.setSpacing(6)  # 【可改】按钮间距
    
    btn_view = QPushButton("👁 查看")
    btn_view.setFixedHeight(30)  # 【可改】按钮高度
    # 卡片查看按钮样式 - 白底灰边系（中性操作按钮）
    #   QPushButton { font-size: 15px; padding: 4px 12px; border: 1px solid #DDD; border-radius: 5px; background: white; color: #333; }
    #   QPushButton:hover { background: #F0F0F0; }  悬停浅灰背景
    btn_view.setStyleSheet("""
        QPushButton { font-size: 15px; padding: 4px 12px; border: 1px solid #DDD; 
                     border-radius: 5px; background: white; color: #333; }
        QPushButton:hover { background: #F0F0F0; }
    """)
    btn_view.clicked.connect(lambda: host._on_storage_view_item(item_data))
    btn_layout.addWidget(btn_view)
    
    btn_delete = QPushButton("🗑 删除")
    btn_delete.setFixedHeight(30)
    # 卡片删除按钮样式 - 红色轮廓系（白底红边红字，危险操作警示）
    #   QPushButton { font-size: 15px; padding: 4px 12px; border: 1px solid #E74C3C; border-radius: 5px; background: white; color: #E74C3C; }
    #   QPushButton:hover { background: #FADBD8; }  悬停浅红背景
    btn_delete.setStyleSheet("""
        QPushButton { font-size: 15px; padding: 4px 12px; border: 1px solid #E74C3C; 
                     border-radius: 5px; background: white; color: #E74C3C; }
        QPushButton:hover { background: #FADBD8; }
    """)
    btn_delete.clicked.connect(lambda: host._on_storage_delete_item(item_data))
    btn_layout.addWidget(btn_delete)
    
    layout.addLayout(btn_layout)
    
    # 标签显示（最多显示3个，超出显示+N）
    tags = item_data.get('tags', [])
    if tags:
        tag_text = "  ".join(f"#{t}" for t in tags[:3])  # 【可改】最多显示标签数
        if len(tags) > 3:
            tag_text += f"  +{len(tags)-3}"
        tag_label = QLabel(tag_text)
        tag_label.setStyleSheet("font-size: 15px; color: #9B59B6;")  # 【可改】标签颜色（紫色）
        tag_label.setWordWrap(True)
        layout.addWidget(tag_label)
    
    return card

def refresh_list_view(host, items):
    """重建列表视图的项目条目（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        清空 QListWidget 后逐项插入「图标 + 标题 + 日期 + 大小（+ 换行标签）」文本，
        并把完整 item_data 存入 UserRole，供双击/右键/批量删除取回原始字典。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已有 _storage_list_widget。
        items (list[dict]): 已筛选排序的项目列表。

    返回:
        None。

    副作用:
        重建列表项；不写盘、不刷新其它区域。
        列表项显示的是格式化文本，真正的数据来源始终是 UserRole 中的字典。
    """
    host._storage_list_widget.clear()
    
    for item_data in items:
        item = QListWidgetItem()
        
        # 图标
        if item_data['type'] == 'image':
            icon_text = "🖼️"
        elif item_data['type'] == 'note':
            icon_text = "📝"
        else:
            icon_text = "📄"
        
        # 显示文本
        title = item_data.get('title', '未命名')
        date = item_data.get('created_at', '')
        size = host._format_file_size(item_data.get('size', 0))
        tags = " ".join(f"[{t}]" for t in item_data.get('tags', []))
        
        display_text = f"{icon_text}  {title}    {date}    {size}"
        if tags:
            display_text += f"\n     {tags}"
        
        item.setText(display_text)
        # 完整数据挂到 UserRole，避免从显示文本反解析（标题可能含空格/换行）
        item.setData(Qt.ItemDataRole.UserRole, item_data)
        host._storage_list_widget.addItem(item)

def on_storage_category_changed(host, row):
    """分类切换事件处理（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        响应左侧分类列表的 currentRowChanged 信号：
        从行号对应 QListWidgetItem 的 UserRole 取出分类 ID（all/images/notes/files），
        写入 _current_storage_category 后整页刷新。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        row (int): 被选中的分类行号；-1 表示列表被清空（此时 item 为 None，直接忽略）。

    返回:
        None。

    副作用:
        修改当前分类状态并触发 _refresh_storage_display（重建卡片/列表）。
        不写 INI（分类筛选属于临时视图状态，不跨会话保持）。

    异常:
        无。
    """
    item = host._storage_category_list.item(row)
    if item:
        host._current_storage_category = item.data(Qt.ItemDataRole.UserRole)
        host._refresh_storage_display()

def on_storage_search(host, text):
    """搜索框文本变化事件处理（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        响应搜索框 textChanged 信号，把关键词存入 _current_storage_search
        并立即刷新（实时搜索，无防抖）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        text (str): 当前搜索框全文（空串表示取消搜索）。

    返回:
        None。

    副作用:
        每次按键都触发一次整页重建（卡片 deleteLater + 重新创建）；
        条目很多时可能有轻微卡顿，但当前存储量级下可接受。

    异常:
        无。
    """
    host._current_storage_search = text
    host._refresh_storage_display()

def on_storage_sort_changed(host, index):
    """排序下拉框切换事件处理（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        从 currentData() 读取排序模式（time_desc/time_asc/name_asc/name_desc/
        size_desc/size_asc），更新 _storage_sort_mode 后刷新并持久化。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        index (int): 下拉框选中项索引（本函数不使用，改用 currentData 取值，
            避免界面顺序调整后索引与模式错位）。

    返回:
        None。

    副作用:
        刷新显示；调用 _save_ini_config() 把排序模式写入配置.ini 的 [Display]
        键 storage_sort_mode（启动时由 _load_ini_config 恢复，init_storage_data 会保留）。

    异常:
        无。
    """
    # 【修复None值bug】currentData()可能返回None（如未设置data或异常情况），
    # 需提供默认值'time_desc'避免后续排序逻辑出错
    host._storage_sort_mode = host._storage_sort_combo.currentData() or 'time_desc'
    host._refresh_storage_display()
    # 保存配置
    host._save_ini_config()

def format_file_size(host, size_bytes):
    """把字节数格式化为 B/KB/MB/GB 的可读字符串（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        按 1024 进制把字节数落到 B/KB/MB/GB 四档中最合适的一档：
        B 档输出整数，其余三档保留 1 位小数，供卡片、列表与详情窗口统一显示文件体积。

    参数:
        host (LotteryPredictionWindow): 主窗口实例（未使用，仅为统一 handler 签名）。
        size_bytes (int | float): 文件大小（字节）；负数会落入 B 分支原样输出。

    返回:
        str: 保留 1 位小数的可读大小，如 "1.5 KB"；小于 1024 时输出整数 B。

    副作用/异常:
        纯计算，无副作用、不抛异常。
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.1f} GB"

def update_storage_stats(host):
    """统计并刷新左上角「存储统计」四个标签（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        遍历全部索引项，按 type 统计图片/笔记/文件数量，并累加 size 得到总占用；
        结果写入 _storage_stats_images/notes/files/total 的文本。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None。

    副作用:
        改写四个 QLabel 文本（不写盘）。
        统计的是全部索引项而非当前筛选结果，因此筛选时统计数字保持不变，
        用户看到的是“库里一共有多少”，不会被搜索条件影响。

    异常:
        无；控件尚未创建时（hasattr 检查失败）直接返回。

    注意:
        - 若统计标签控件尚未创建则直接返回
        - 总大小通过 _format_file_size 格式化显示
    """
    if not hasattr(host, '_storage_stats_images'):
        return
    
    image_count = sum(1 for i in host._storage_items if i['type'] == 'image')
    note_count = sum(1 for i in host._storage_items if i['type'] == 'note')
    file_count = sum(1 for i in host._storage_items if i['type'] == 'file')
    total_size = sum(i.get('size', 0) for i in host._storage_items)
    
    host._storage_stats_images.setText(f"🖼️ 图片: {image_count}")
    host._storage_stats_notes.setText(f"📝 笔记: {note_count}")
    host._storage_stats_files.setText(f"📂 文件: {file_count}")
    host._storage_stats_total.setText(f"💾 总计: {host._format_file_size(total_size)}")

def on_storage_batch_delete(host):
    """批量删除列表视图中选中的项目（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        确认后逐一删除选中项的磁盘文件并从 _storage_items 中移除，
        最后保存索引、刷新显示并在状态栏给出成功条数。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读取 _storage_list_widget
            的 selectedItems。

    返回:
        None。

    副作用:
        删除磁盘文件（失败仅 pass）；整体替换 host._storage_items；
        写 index.json 与 SQLite 镜像；刷新两种视图；状态栏提示。

    异常:
        外层 try 捕获后弹 QMessageBox.critical，内存索引可能已部分修改。
        单个文件删除失败的项目会保留索引，并在完成后统一弹窗列出；
        索引写盘失败时状态栏不再宣称删除成功。

    注意:
        - 索引保存后才刷新显示，保证数据一致性
    """
    selected_items = host._storage_list_widget.selectedItems()
    if not selected_items:
        QMessageBox.information(host, "提示", "请先选择要删除的项目")
        return
    
    count = len(selected_items)
    reply = QMessageBox.question(
        host, "确认批量删除",
        f"确定要删除选中的 {count} 个项目吗？\n此操作不可恢复。",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
    )
    if reply != QMessageBox.StandardButton.Yes:
        return
    
    try:
        deleted_count = 0
        failed_items = []
        for item in selected_items:
            item_data = item.data(Qt.ItemDataRole.UserRole)
            if item_data:
                # 删除磁盘文件：失败时保留索引项，避免出现“索引无记录但文件仍在”的孤儿
                file_path = item_data.get('file_path', '')
                if file_path and os.path.exists(file_path):
                    try:
                        os.remove(file_path)
                    except Exception as e:
                        failed_items.append(f"{item_data.get('title', '')}: {e}")
                        continue

                # 从列表移除（仅磁盘删除成功或文件本就不存在时）
                host._storage_items = [i for i in host._storage_items if i['id'] != item_data['id']]
                deleted_count += 1

        saved = notify_if_index_save_failed(host)
        host._refresh_storage_display()
        if failed_items:
            # 失败项已保留在索引中，如实告知用户，不能只报“全部成功”
            QMessageBox.warning(
                host, "部分删除失败",
                "以下项目文件删除失败，索引已保留：\n" + "\n".join(failed_items)
            )
        if saved:
            if deleted_count:
                host.statusBar().showMessage(f"已删除 {deleted_count} 个项目")
        else:
            host.statusBar().showMessage("索引保存失败，删除结果未持久化")

    except Exception as e:
        QMessageBox.critical(host, "错误", f"批量删除失败:\n{str(e)}")

def on_storage_select_all(host):
    """全选 / 取消全选切换（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        先确保当前处于列表视图（stack index=1，卡片视图不支持多选），
        再比较“已选数量”与“总数量”：已全选则清空选择，否则全选。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读取 _storage_stack /
            _storage_list_widget。

    返回:
        None。

    副作用:
        可能切换视图索引（0=网格，1=列表）；改变列表选中状态；
        状态栏提示操作结果。

    异常:
        无。
    """
    if host._storage_stack.currentIndex() != 1:  # 切换到列表视图
        host._storage_stack.setCurrentIndex(1)
    
    # 检查是否已全部选中
    total = host._storage_list_widget.count()
    selected = len(host._storage_list_widget.selectedItems())
    
    if selected == total and total > 0:
        # 取消全选
        host._storage_list_widget.clearSelection()
        host.statusBar().showMessage("已取消全选")
    else:
        # 全选
        for i in range(host._storage_list_widget.count()):
            item = host._storage_list_widget.item(i)
            item.setSelected(True)
        host.statusBar().showMessage(f"已选中 {total} 个项目")

def on_storage_tag_changed(host, row):
    """标签筛选事件处理（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        响应标签列表 currentRowChanged：从 UserRole 取标签名
        （第一项「全部标签」的 UserRole 是空串，等价于不筛选），
        写入 _current_storage_tag 后整页刷新。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        row (int): 被选中的标签行号；-1 时 item 为 None，直接忽略。

    返回:
        None。

    副作用:
        修改当前标签筛选并触发 _refresh_storage_display；不写 INI
        （标签筛选与分类筛选一样属于临时视图状态）。

    异常:
        无。
    """
    item = host._storage_tag_list.item(row)
    if item:
        host._current_storage_tag = item.data(Qt.ItemDataRole.UserRole)
        host._refresh_storage_display()

def on_storage_upload_image(host):
    """选择并导入图片文件（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        弹出系统文件选择框（过滤 png/jpg/jpeg/gif/bmp/webp），
        用户确认后委托 import_image_file 复制入库；取消则什么都不做。

    参数:
        host (LotteryPredictionWindow): 主窗口实例（作为对话框父窗口与回调宿主）。

    返回:
        None。

    副作用:
        打开模态文件对话框；选择文件后触发一次导入（复制文件+写索引+刷新）。

    异常:
        导入异常由 import_image_file 内部弹框处理，本函数不抛出。
    """
    file_path, _ = QFileDialog.getOpenFileName(
        host, "选择图片", "", 
        "图片文件 (*.png *.jpg *.jpeg *.gif *.bmp *.webp);;所有文件 (*.*)"
    )
    if file_path:
        host._import_image_file(file_path)

def import_image_file(host, src_path):
    """把外部图片复制到 images/ 并登记到索引（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        生成「原名_微秒时间戳.扩展名」的唯一文件名（避免同名覆盖），
        用 shutil.copy2 复制（保留原文件时间戳），再把元数据追加到索引。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        src_path (str): 源图片绝对路径（由文件对话框或拖拽/粘贴提供）。

    返回:
        bool: 是否导入成功（供批量导入统计真实成功数）；失败时已弹 critical 并返回 False。

    副作用:
        在 images/ 下新建文件；追加 host._storage_items；
        调用 _save_storage_index 写盘并 _refresh_storage_display 重建视图；
        状态栏提示成功。

    异常:
        任意异常（源文件不存在、目录不可写、磁盘满）被捕获后弹 critical，
        索引保持不变。
        v0.0.42 起 ID/文件名改为「微秒时间戳 + 冲突序号」，卡片标题取落盘文件名，
        保证标题与磁盘文件一致。
    """
    try:
        host._ensure_storage_dirs()
        base_name = os.path.basename(src_path)
        name, ext = os.path.splitext(base_name)
        file_id, new_name, dest_path = make_unique_storage_identity(
            host, "img_", f"{name}_", ext, "images")

        # 复制文件
        import shutil  # 作用说明：文件复制工具，用 copy2 把用户选中的图片拷进 images/（同时保留原文件时间戳与权限）
        shutil.copy2(src_path, dest_path)

        # 添加到索引
        stat = os.stat(dest_path)
        new_item = {
            'id': file_id,
            'type': 'image',
            'title': new_name,  # 与磁盘文件名一致，避免同名原图在多张卡片上无法区分
            'file_path': dest_path,
            'tags': [],
            'created_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'size': stat.st_size,
        }
        host._storage_items.append(new_item)
        saved = notify_if_index_save_failed(host)
        host._refresh_storage_display()

        if saved:
            host.statusBar().showMessage(f"图片已保存: {new_name}")
        else:
            host.statusBar().showMessage("图片已复制，但索引保存失败，重启后可能不可见")
        return True
    except Exception as e:
        QMessageBox.critical(host, "错误", f"上传图片失败:\n{str(e)}")
        return False

def on_storage_new_note(host):
    """打开「新建笔记」模态对话框（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        组装标题 QLineEdit、标签 QLineEdit（空格分隔）、内容 QTextEdit 与
        取消/保存按钮；保存时校验后调用 host._save_new_note 落盘。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，同时作为对话框父窗口。

    返回:
        None（对话框以 exec() 阻塞执行，返回后即完成或取消）。

    副作用:
        打开模态窗口；点「保存」时触发一次笔记落盘（写 JSON+写索引+刷新视图）。
        关闭对话框不会修改任何数据。

    异常:
        保存异常由 save_new_note 内部弹框处理；对话框本身不抛。

    说明:
        标题留空时默认「未命名笔记」；标签按空白字符切分，连续空格不会产生空标签。
    """
    dialog = QDialog(host)
    dialog.setWindowTitle("新建笔记")
    dialog.setMinimumSize(500, 400)
    
    layout = QVBoxLayout(dialog)
    
    # 标题输入
    title_label = QLabel("标题:")
    layout.addWidget(title_label)
    title_edit = QLineEdit()
    title_edit.setPlaceholderText("输入笔记标题...")
    layout.addWidget(title_edit)
    
    # 标签输入
    tag_label = QLabel("标签 (用空格分隔):")
    layout.addWidget(tag_label)
    tag_edit = QLineEdit()
    tag_edit.setPlaceholderText("例如: 分析 选号 走势")
    layout.addWidget(tag_edit)
    
    # 内容输入
    content_label = QLabel("内容:")
    layout.addWidget(content_label)
    content_edit = QTextEdit()
    content_edit.setPlaceholderText("输入笔记内容...\n\n支持粘贴图片和文字")
    layout.addWidget(content_edit, 1)
    
    # 按钮
    btn_layout = QHBoxLayout()
    btn_layout.addStretch()
    
    btn_cancel = QPushButton("取消")
    btn_cancel.clicked.connect(dialog.reject)
    btn_layout.addWidget(btn_cancel)
    
    btn_save = QPushButton("保存")
    # 新建笔记保存按钮样式 - 蓝色系（主操作按钮，蓝色背景白色文字）
    btn_save.setStyleSheet("QPushButton { padding: 8px 20px; background: #3498DB; color: white; border-radius: 6px; }")
    
    def save_note():
        """读取对话框输入并保存笔记，然后关闭对话框（局部回调）

        功能:
            把「新建笔记」对话框里标题/内容/标签三个控件的输入整理成落盘参数，
            交给 host._save_new_note 写入 notes/*.json 并登记索引，随后关闭对话框。

        参数: 无（直接读取外层的 title_edit/content_edit/tag_edit）。
        返回: None。
        副作用: 调用 host._save_new_note 写盘并刷新页面；dialog.accept() 关闭窗口。
        """
        title = title_edit.text().strip() or "未命名笔记"
        content = content_edit.toPlainText()
        tags = [t.strip() for t in tag_edit.text().split() if t.strip()]
        
        host._save_new_note(title, content, tags)
        dialog.accept()
    
    btn_save.clicked.connect(save_note)
    btn_layout.addWidget(btn_save)
    
    layout.addLayout(btn_layout)
    
    dialog.exec()

def save_new_note(host, title, content, tags):
    """新建笔记：写 notes/*.json 并登记索引（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        以「微秒时间戳.json」命名落盘（JSON 内含 id/title/content/tags/时间），
        再把同样内容投影成索引项，更新标签库并刷新界面。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        title (str): 笔记标题（调用方已保证非空，空则用「未命名笔记」）。
        content (str): 笔记正文（纯文本，可含换行）。
        tags (list[str]): 标签列表，会并入全局标签集合。

    返回:
        bool: 是否成功落盘并登记索引；失败时已弹 critical 并返回 False。

    副作用:
        新建 notes/{微秒时间戳}.json；追加 _storage_items；
        标签并入 _storage_tags 并调用 _update_tag_list（会重置标签选中项）；
        写 index.json 与 SQLite 镜像；刷新视图；状态栏提示。

    异常:
        任意异常被捕获后弹 critical，已写文件可能残留但索引未更新。
        v0.0.42 起 ID/文件名加入微秒与冲突序号，同一秒连续新建不再互相覆盖。

    注意:
        - 笔记真实存储格式是 JSON（v0.0.28 后的实现），不是纯文本 .txt
        - 项目 ID 格式: note_{时间戳}，与文件名去扩展名一致
    """
    try:
        host._ensure_storage_dirs()
        note_id, filename, filepath = make_unique_storage_identity(
            host, "note_", "", ".json", "notes")

        note_data = {
            'id': note_id,
            'title': title,
            'content': content,
            'tags': tags,
            'created_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        }

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(note_data, f, ensure_ascii=False, indent=2)

        # 添加到索引
        new_item = {
            'id': note_id,
            'type': 'note',
            'title': title,
            'content': content,
            'file_path': filepath,
            'tags': tags,
            'created_at': note_data['created_at'],
            'updated_at': note_data['updated_at'],
            'size': os.path.getsize(filepath),
        }
        host._storage_items.append(new_item)

        # 更新标签
        for tag in tags:
            host._storage_tags.add(tag)
        host._update_tag_list()

        saved = notify_if_index_save_failed(host)
        host._refresh_storage_display()

        if saved:
            host.statusBar().showMessage(f"笔记已保存: {title}")
        else:
            host.statusBar().showMessage("笔记文件已写入，但索引保存失败，重启后可能不可见")
        return True
    except Exception as e:
        QMessageBox.critical(host, "错误", f"保存笔记失败:\n{str(e)}")
        return False

def on_storage_import_file(host):
    """选择并导入数据文件（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        弹出系统文件选择框（默认「所有文件」，并给出 CSV/JSON/TXT 快捷过滤），
        选择后委托 import_data_file 复制入 files/。

    参数:
        host (LotteryPredictionWindow): 主窗口实例（对话框父窗口与回调宿主）。

    返回:
        None。

    副作用:
        打开模态文件对话框；确认后触发一次文件导入（复制+写索引+刷新）。

    异常:
        导入异常由 import_data_file 内部弹框处理，本函数不抛出。
    """
    file_path, _ = QFileDialog.getOpenFileName(
        host, "选择文件", "", 
        "所有文件 (*.*);;CSV文件 (*.csv);;JSON文件 (*.json);;文本文件 (*.txt)"
    )
    if file_path:
        host._import_data_file(file_path)

def import_data_file(host, src_path):
    """把外部数据文件复制到 files/ 并登记索引（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        与图片导入同构：生成带时间戳的唯一名，shutil.copy2 复制到 files/，
        再以 file_ 前缀生成 ID 并追加索引。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        src_path (str): 源文件绝对路径（任意类型，不做内容解析）。

    返回:
        bool: 是否导入成功（供批量导入统计真实成功数）；失败时已弹 critical 并返回 False。

    副作用:
        在 files/ 下新建副本；追加 host._storage_items；写索引并刷新视图；
        状态栏提示成功。页面只保存文件、不解析其中的开奖数据
        （数据导入请使用 [1] 数据导入页）。

    异常:
        任意异常被捕获后弹 critical，索引不变。
        v0.0.42 起 ID/文件名改为「微秒时间戳 + 冲突序号」，卡片标题取落盘文件名。
    """
    try:
        host._ensure_storage_dirs()
        base_name = os.path.basename(src_path)
        name, ext = os.path.splitext(base_name)
        file_id, new_name, dest_path = make_unique_storage_identity(
            host, "file_", f"{name}_", ext, "files")

        import shutil  # 作用说明：文件复制工具，用 copy2 把导入的数据文件拷进 files/（保留原时间戳，便于按时间排序展示）
        shutil.copy2(src_path, dest_path)

        stat = os.stat(dest_path)
        new_item = {
            'id': file_id,
            'type': 'file',
            'title': new_name,  # 与磁盘文件名一致
            'file_path': dest_path,
            'tags': [],
            'created_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'size': stat.st_size,
        }
        host._storage_items.append(new_item)
        saved = notify_if_index_save_failed(host)
        host._refresh_storage_display()

        if saved:
            host.statusBar().showMessage(f"文件已保存: {new_name}")
        else:
            host.statusBar().showMessage("文件已复制，但索引保存失败，重启后可能不可见")
        return True
    except Exception as e:
        QMessageBox.critical(host, "错误", f"导入文件失败:\n{str(e)}")
        return False

def on_storage_view_item(host, item_data):
    """按类型分发“查看/打开”操作（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        image → host._view_image（大图预览窗口）
        note  → host._view_or_edit_note（可编辑笔记窗口）
        file  → host._open_file（信息确认后打开所在文件夹）
        未知 type 不做任何处理。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        item_data (dict): 存储项字典，至少含 type；后续按类型使用 file_path 等字段。

    返回:
        None。

    副作用:
        打开相应模态对话框，可能触发删除/保存（由子对话框内的按钮决定）；
        本函数自身不写库。

    异常:
        子函数内部的异常各自处理，本函数不抛出。
    """
    item_type = item_data.get('type', '')
    
    if item_type == 'image':
        host._view_image(item_data)
    elif item_type == 'note':
        host._view_or_edit_note(item_data)
    elif item_type == 'file':
        host._open_file(item_data)

def on_storage_item_double_clicked(host, item):
    """列表视图双击项目时打开详情（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        把列表视图的双击事件转成详情查看：先取列表项 UserRole 里存的 item_data，
        再统一委托给 host._on_storage_view_item，由其按 type 分派到看图/编辑笔记/打开文件。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        item (QListWidgetItem): 被双击的列表项，其 UserRole 存有完整 item_data。

    返回:
        None。

    副作用:
        委托 _on_storage_view_item 打开预览/编辑窗口；UserRole 为空时忽略。

    异常:
        无。
    """
    item_data = item.data(Qt.ItemDataRole.UserRole)
    if item_data:
        host._on_storage_view_item(item_data)

def view_image(host, item_data):
    """在新窗口中查看图片大图（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        用 QScrollArea 承载原始尺寸 QPixmap（可滚动查看细节），
        底部显示大小与创建时间，关闭按钮退出。

    参数:
        host (LotteryPredictionWindow): 主窗口实例（父窗口 + _format_file_size）。
        item_data (dict): 图片项，需含 file_path，可选 title/size/created_at。

    返回:
        None（exec() 关闭后返回）。

    副作用:
        读取图片文件到内存；不修改索引。

    异常:
        图片损坏/路径失效时 pixmap.isNull()，窗口内显示「无法加载图片」。
    """
    dialog = QDialog(host)
    dialog.setWindowTitle(item_data.get('title', '图片'))
    dialog.setMinimumSize(600, 500)
    
    layout = QVBoxLayout(dialog)
    
    # 图片显示
    scroll_area = QScrollArea()
    scroll_area.setWidgetResizable(True)
    
    pixmap = QPixmap(item_data['file_path'])
    if not pixmap.isNull():
        label = QLabel()
        label.setPixmap(pixmap)
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        scroll_area.setWidget(label)
    else:
        scroll_area.setWidget(QLabel("无法加载图片"))
    
    layout.addWidget(scroll_area, 1)
    
    # 信息
    info = f"大小: {host._format_file_size(item_data.get('size', 0))}    创建时间: {item_data.get('created_at', '')}"
    info_label = QLabel(info)
    # 图片信息标签样式：12px字号，灰色文字，5px内边距
    info_label.setStyleSheet("font-size: 15px; color: #666; padding: 5px;")
    layout.addWidget(info_label)
    
    # 按钮
    btn_layout = QHBoxLayout()
    btn_layout.addStretch()
    
    btn_close = QPushButton("关闭")
    btn_close.clicked.connect(dialog.accept)
    btn_layout.addWidget(btn_close)
    
    layout.addLayout(btn_layout)
    
    dialog.exec()

def view_or_edit_note(host, item_data):
    """打开笔记查看/编辑窗口（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        用索引里的 title/content/tags 预填表单（不重新读磁盘 JSON，避免与索引
        不一致），用户可改标题/标签/正文；底部提供删除、取消、保存三个出口。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        item_data (dict): 笔记项，需含 id/file_path/title/tags/content/时间字段；
            保存时把 id 传给 host._update_note，删除时把整项传给
            host._on_storage_delete_item。

    返回:
        None（exec() 关闭后返回）。

    副作用:
        点「保存」→ 改写 notes 下 JSON 并刷新索引/视图；
        点「删除笔记」→ 二次确认后删除磁盘文件与索引项。

    异常:
        子操作异常由 update_note / on_storage_delete_item 内部弹框处理。

    说明:
        编辑框里的内容取自索引快照，若磁盘 JSON 被外部改动，保存时会以界面内容覆盖。
    """
    dialog = QDialog(host)
    dialog.setWindowTitle("编辑笔记")
    dialog.setMinimumSize(550, 450)
    
    layout = QVBoxLayout(dialog)
    
    # 标题
    title_label = QLabel("标题:")
    layout.addWidget(title_label)
    title_edit = QLineEdit(item_data.get('title', ''))
    layout.addWidget(title_edit)
    
    # 标签
    tag_label = QLabel("标签 (用空格分隔):")
    layout.addWidget(tag_label)
    tags_text = " ".join(item_data.get('tags', []))
    tag_edit = QLineEdit(tags_text)
    layout.addWidget(tag_edit)
    
    # 内容
    content_label = QLabel("内容:")
    layout.addWidget(content_label)
    content_edit = QTextEdit()
    content_edit.setPlainText(item_data.get('content', ''))
    layout.addWidget(content_edit, 1)
    
    # 时间信息
    time_info = f"创建: {item_data.get('created_at', '')}    更新: {item_data.get('updated_at', '')}"
    time_label = QLabel(time_info)
    # 时间信息标签样式：11px小字号，浅灰色文字（不抢视觉焦点）
    time_label.setStyleSheet("font-size: 15px; color: #999;")
    layout.addWidget(time_label)
    
    # 按钮
    btn_layout = QHBoxLayout()
    
    btn_delete = QPushButton("删除笔记")
    # 删除笔记按钮样式 - 红色轮廓系（白底红边红字，危险操作警示）
    btn_delete.setStyleSheet("QPushButton { padding: 8px 16px; color: #E74C3C; border: 1px solid #E74C3C; border-radius: 6px; }")
    
    def delete_note():
        """确认后删除当前笔记并关闭对话框（局部回调）

        功能:
            先弹「确认删除」问答框做二次确认，用户选「是」才真正删除这篇笔记
            （磁盘 JSON 与索引一并移除），并在删除后关闭编辑窗口。

        参数: 无（使用外层 item_data）。
        返回: None。
        副作用: 用户选 Yes 时调用 host._on_storage_delete_item（删文件+删索引+刷新），
                随后 dialog.accept() 关闭编辑窗口。
        """
        reply = QMessageBox.question(host, "确认删除", "确定要删除这篇笔记吗？", 
                                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            host._on_storage_delete_item(item_data)
            dialog.accept()
    
    btn_delete.clicked.connect(delete_note)
    btn_layout.addWidget(btn_delete)
    
    btn_layout.addStretch()
    
    btn_cancel = QPushButton("取消")
    btn_cancel.clicked.connect(dialog.reject)
    btn_layout.addWidget(btn_cancel)
    
    btn_save = QPushButton("保存")
    # 编辑笔记保存按钮样式 - 蓝色系（主操作按钮，蓝色背景白色文字）
    btn_save.setStyleSheet("QPushButton { padding: 8px 20px; background: #3498DB; color: white; border-radius: 6px; }")
    
    def save_note():
        """把编辑结果写回笔记并关闭对话框（局部回调）

        功能:
            把编辑窗口里标题/内容/标签的最新输入整理后交给 host._update_note 写回
            当前笔记（覆盖磁盘 JSON、更新索引与界面），成功即关闭编辑窗口。

        参数: 无（读取 title_edit/content_edit/tag_edit）。
        返回: None。
        副作用: 调用 host._update_note(note_id, ...) 覆盖磁盘 JSON、更新索引与视图。
        """
        title = title_edit.text().strip() or "未命名笔记"
        content = content_edit.toPlainText()
        tags = [t.strip() for t in tag_edit.text().split() if t.strip()]
        
        host._update_note(item_data['id'], title, content, tags)
        dialog.accept()
    
    btn_save.clicked.connect(save_note)
    btn_layout.addWidget(btn_save)
    
    layout.addLayout(btn_layout)
    
    dialog.exec()

def update_note(host, note_id, title, content, tags):
    """更新已有笔记的索引记录与磁盘 JSON（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        按 id 在 _storage_items 中定位笔记，覆盖 title/content/tags/updated_at，
        同步重写 notes 下的 JSON 文件（保留原 created_at），并回填 size。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        note_id (str): 笔记唯一 ID（note_时间戳）。
        title (str): 新标题。
        content (str): 新正文。
        tags (list[str]): 新标签列表（会并入全局标签库，旧标签不删除）。

    返回:
        bool: 是否真正更新到目标笔记；未找到 note_id 时弹提示并返回 False。

    副作用:
        覆盖磁盘笔记 JSON；修改内存索引项；_storage_tags.update(tags)
        + _update_tag_list()（重置标签选中项）；写 index.json 与 SQLite；刷新视图。

    异常:
        任意异常弹 critical；先写磁盘再更新内存，写失败时内存索引保持不变。
        v0.0.42 起未找到 note_id 会提示“笔记不存在”并跳过标签/索引写入。
    """
    try:
        found = False
        for item in host._storage_items:
            if item['id'] == note_id:
                found = True
                updated_at = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                # 先写文件，成功后再更新内存，避免写盘失败时索引与磁盘不一致
                note_data = {
                    'id': note_id,
                    'title': title,
                    'content': content,
                    'tags': tags,
                    'created_at': item['created_at'],
                    'updated_at': updated_at,
                }
                with open(item['file_path'], 'w', encoding='utf-8') as f:
                    json.dump(note_data, f, ensure_ascii=False, indent=2)

                item['title'] = title
                item['content'] = content
                item['tags'] = tags
                item['updated_at'] = updated_at
                item['size'] = os.path.getsize(item['file_path'])
                break

        if not found:
            QMessageBox.warning(host, "提示", "笔记不存在，可能已被删除，请刷新后重试")
            return False

        # 更新标签库
        host._storage_tags.update(tags)
        host._update_tag_list()

        saved = notify_if_index_save_failed(host)
        host._refresh_storage_display()

        if saved:
            host.statusBar().showMessage("笔记已更新")
        else:
            host.statusBar().showMessage("笔记文件已更新，但索引保存失败")
        return True
    except Exception as e:
        QMessageBox.critical(host, "错误", f"更新笔记失败:\n{str(e)}")
        return False

def open_file(host, item_data):
    """查看数据文件信息并打开所在文件夹（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        先弹出文件名/大小/路径信息并询问是否打开文件夹；确认后按平台调用：
        Windows 用 os.startfile，macOS 用 open，Linux 用 xdg-open。

    参数:
        host (LotteryPredictionWindow): 主窗口实例（对话框父窗口）。
        item_data (dict): 文件项，需含 file_path，可选 title/size。

    返回:
        None。

    副作用:
        打开系统文件管理器（外部进程）；文件不存在则只弹警告。

    异常:
        os.startfile/subprocess.Popen 失败不在本函数捕获，会直接抛到 Qt 信号槽，
        由 Qt 打印异常（不会中断程序）。
        v0.0.42 起改用 QMessageBox.question，Yes/No 询问语义与图标一致。
    """
    file_path = item_data.get('file_path', '')
    if file_path and os.path.exists(file_path):
        reply = QMessageBox.question(
            host, "文件信息",
            f"文件名: {item_data.get('title', '')}\n"
            f"大小: {host._format_file_size(item_data.get('size', 0))}\n"
            f"路径: {file_path}\n\n"
            "是否在文件夹中打开？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            import subprocess  # 作用说明：调用系统程序打开目录，非 Windows 分支用 Popen 起 open/xdg-open（Windows 分支走 os.startfile，不需要它）
            if os.name == 'nt':  # Windows
                os.startfile(os.path.dirname(file_path))
            elif os.name == 'posix':  # macOS/Linux
                subprocess.Popen(['open' if sys.platform == 'darwin' else 'xdg-open', os.path.dirname(file_path)])
    else:
        QMessageBox.warning(host, "提示", "文件不存在")

def on_storage_delete_item(host, item_data):
    """删除单个存储项目（文件 + 索引）（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        二次确认后先删磁盘文件、再从 _storage_items 移除对应 id，
        最后保存索引并刷新界面。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        item_data (dict): 待删除项，需含 id/file_path/title。

    返回:
        None。

    副作用:
        删除磁盘文件；重建索引列表；写 index.json/SQLite；刷新视图；状态栏提示。

    异常:
        任意异常弹 critical。os.remove 失败会直接进入 except，此时索引尚未移除，
        条目仍保留（与批量删除的“吞异常”行为不同）。
    """
    reply = QMessageBox.question(
        host, "确认删除", 
        f"确定要删除「{item_data.get('title', '')}」吗？\n此操作不可恢复。",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
    )
    if reply != QMessageBox.StandardButton.Yes:
        return
    
    try:
        # 删除文件
        file_path = item_data.get('file_path', '')
        if file_path and os.path.exists(file_path):
            os.remove(file_path)
        
        # 从索引中移除
        host._storage_items = [i for i in host._storage_items if i['id'] != item_data['id']]
        
        saved = notify_if_index_save_failed(host)
        host._refresh_storage_display()

        if saved:
            host.statusBar().showMessage("已删除")
        else:
            host.statusBar().showMessage("文件已删除，但索引保存失败，重启后可能仍显示该条目")
    except Exception as e:
        QMessageBox.critical(host, "错误", f"删除失败:\n{str(e)}")

def on_storage_backup(host):
    """把整个存储目录打包成 ZIP 备份（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        用 zipfile.ZIP_DEFLATED 递归压缩「系统v7.5/数据存储」下的全部文件
        （含 index.json 与三个子目录），压缩包内保持相对路径。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None（用户取消保存对话框时直接返回）。

    副作用:
        打开保存对话框；在用户指定路径生成 .zip 文件；状态栏与信息框提示结果。

    异常:
        任意异常弹 critical。
        v0.0.42 起压缩过程会跳过“备份文件自身”（当保存路径位于存储目录内时），
        避免边写边读导致压缩包体积异常膨胀。
    """
    try:
        import zipfile  # 作用说明：整目录 ZIP 备份，用 ZipFile + ZIP_DEFLATED 递归压缩「数据存储」下的全部文件
        
        storage_dir = host._get_storage_dir()
        if not os.path.exists(storage_dir):
            QMessageBox.information(host, "提示", "暂无数据可备份")
            return
        
        # 选择保存位置
        default_name = f"数据存储备份_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        save_path, _ = QFileDialog.getSaveFileName(
            host, "保存备份文件", default_name, "ZIP压缩文件 (*.zip)"
        )
        if not save_path:
            return
        
        # 创建压缩包
        # v0.0.42：若备份目标位于存储目录内，跳过目标文件自身，避免边写边压缩自己
        abs_save_path = os.path.abspath(save_path)
        with zipfile.ZipFile(save_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(storage_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    if os.path.abspath(file_path) == abs_save_path:
                        continue
                    # 用相对存储根的路径入包，解压后可直接还原成原目录结构
                    arcname = os.path.relpath(file_path, storage_dir)
                    zipf.write(file_path, arcname)
        
        host.statusBar().showMessage(f"备份成功，已保存到: {save_path}")
        QMessageBox.information(host, "备份成功", f"数据已备份到:\n{save_path}")
        
    except Exception as e:
        QMessageBox.critical(host, "错误", f"备份失败:\n{str(e)}")

def on_storage_list_context_menu(host, pos):
    """列表视图右键菜单（打开/重命名/删除）（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        响应 customContextMenuRequested：取点击位置的列表项，构建 QMenu，
        三个动作分别转调 host._on_storage_view_item / _on_storage_rename_item /
        _on_storage_delete_item，再在全局坐标显示菜单。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        pos (QPoint): 鼠标右键位置，坐标系为 _storage_list_widget 的局部坐标。

    返回:
        None。

    副作用:
        弹出模态菜单；点击动作后可能打开窗口、改名或删文件。

    异常:
        无（空白处右键直接返回，不弹菜单）。
    """
    item = host._storage_list_widget.itemAt(pos)
    if not item:
        return
    
    item_data = item.data(Qt.ItemDataRole.UserRole)
    if not item_data:
        return
    
    menu = QMenu(host)
    
    action_open = menu.addAction("📂 打开/查看")
    action_open.triggered.connect(lambda: host._on_storage_view_item(item_data))
    
    action_rename = menu.addAction("✏️ 重命名")
    action_rename.triggered.connect(lambda: host._on_storage_rename_item(item_data))
    
    menu.addSeparator()
    
    action_delete = menu.addAction("🗑️ 删除")
    action_delete.setIcon(QIcon())
    action_delete.triggered.connect(lambda: host._on_storage_delete_item(item_data))
    
    # 菜单必须在全局坐标弹出，否则会出现在窗口左上角
    menu.exec(host._storage_list_widget.mapToGlobal(pos))

def on_storage_rename_item(host, item_data):
    """重命名存储项（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        用 QInputDialog 预填当前标题并接收新名称；确认非空后更新索引 title 与
        updated_at；若为笔记，同步改写磁盘 JSON 内的 title。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        item_data (dict): 目标项，需含 id/type/file_path/title。

    返回:
        None。

    副作用:
        修改内存索引；笔记额外覆盖 notes JSON；保存索引并刷新视图；状态栏提示。

    异常:
        任意异常弹 critical；用户取消或输入空白不做事。
        v0.0.42 起图片/文件会同步重命名磁盘文件（保留扩展名），
        重命名失败则回滚内存标题，保证索引与磁盘一致。
    """
    old_title = item_data.get('title', '')
    new_title, ok = QInputDialog.getText(
        host, "重命名", "请输入新名称:", text=old_title
    )
    if ok and new_title.strip():
        new_title = new_title.strip()
        try:
            found = False
            for item in host._storage_items:
                if item['id'] == item_data['id']:
                    found = True
                    # 图片/文件：先把磁盘文件改成新标题（保留扩展名），成功后再改索引
                    if item['type'] in ('image', 'file') and os.path.exists(item['file_path']):
                        old_path = item['file_path']
                        ext = os.path.splitext(old_path)[1]
                        target_name = new_title if new_title.lower().endswith(ext.lower()) else new_title + ext
                        new_path = os.path.join(os.path.dirname(old_path), target_name)
                        if os.path.abspath(new_path) != os.path.abspath(old_path) and os.path.exists(new_path):
                            raise FileExistsError(f"目标文件名已存在: {target_name}")
                        os.rename(old_path, new_path)
                        item['file_path'] = new_path

                    item['title'] = new_title
                    item['updated_at'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                    # 如果是笔记，同时更新笔记文件内的标题
                    if item['type'] == 'note' and os.path.exists(item['file_path']):
                        with open(item['file_path'], 'r', encoding='utf-8') as f:
                            note_data = json.load(f)
                        note_data['title'] = new_title
                        note_data['updated_at'] = item['updated_at']
                        with open(item['file_path'], 'w', encoding='utf-8') as f:
                            json.dump(note_data, f, ensure_ascii=False, indent=2)

                    break

            if not found:
                QMessageBox.warning(host, "提示", "项目不存在，可能已被删除，请刷新后重试")
                return

            saved = notify_if_index_save_failed(host)
            host._refresh_storage_display()
            if saved:
                host.statusBar().showMessage("已重命名")
            else:
                host.statusBar().showMessage("重命名已生效，但索引保存失败")
        except Exception as e:
            QMessageBox.critical(host, "错误", f"重命名失败:\n{str(e)}")

def is_storage_tab_active(host):
    """判断当前是否停留在「数据存储」选项卡（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        供拖拽/粘贴事件做“只在本页生效”的门禁：主页面的每个选项卡都被包进
        QScrollArea，因此需要先取 currentWidget，再解包 .widget() 与真实页面比较。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，读取 tabs 与 _storage_main_widget。

    返回:
        bool: True 表示当前显示的就是本页；tabs 未创建或页面未构建时返回 False。

    副作用/异常:
        只读查询，无副作用、不抛异常。
    """
    if not hasattr(host, 'tabs') or not hasattr(host, '_storage_main_widget'):
        return False
    current = host.tabs.currentWidget()
    if isinstance(current, QScrollArea):
        current = current.widget()
    return current is host._storage_main_widget

def drag_enter_event(host, event):
    """拖拽进入主窗口事件（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        仅当拖入的是本地文件 URL 且当前在本页时接受拖拽并高亮提示条；
        其它情况交回 QMainWindow 默认处理（保证其它页面的拖拽逻辑不受影响）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        event (QDragEnterEvent): Qt 拖拽事件对象。

    返回:
        None。

    副作用:
        接受时调用 _highlight_drop_area(True) 切换提示条样式与文案。

    异常:
        无。
    """
    if event.mimeData().hasUrls():
        # 检查是否在数据存储选项卡
        if host._is_storage_tab_active():
            event.acceptProposedAction()
            host._highlight_drop_area(True)
            return
    # 其他情况交给父类处理
    QMainWindow.dragEnterEvent(host, event)

def drag_leave_event(host, event):
    """拖拽离开主窗口事件（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        取消拖拽提示条高亮，然后交回 QMainWindow 默认处理。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        event (QDragLeaveEvent): Qt 事件对象。

    返回:
        None。

    副作用:
        恢复提示条为灰色虚线样式（_storage_drop_hint 不存在时跳过，兼容构建早期）。

    异常:
        无。
    """
    if hasattr(host, '_storage_drop_hint'):
        host._highlight_drop_area(False)
    QMainWindow.dragLeaveEvent(host, event)

def drop_event(host, event):
    """文件放下事件：把本地文件路由到对应导入函数（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        仅在本页且拖入含本地 URL 时，取全部本地文件路径交给
        _handle_dropped_files（按扩展名分派图片/笔记/文件），随后取消高亮；
        否则交回 QMainWindow 默认处理。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        event (QDropEvent): Qt 放下事件。

    返回:
        None。

    副作用:
        触发一批导入（复制文件、写索引、刷新视图），每个文件的状态都由
        handle_dropped_files 汇总到状态栏。

    异常:
        无（导入失败由 handle_dropped_files 内部计数并打印）。
    """
    if event.mimeData().hasUrls():
        if host._is_storage_tab_active():
            urls = event.mimeData().urls()
            files = [url.toLocalFile() for url in urls if url.isLocalFile()]
            if files:
                host._handle_dropped_files(files)
                event.acceptProposedAction()
            host._highlight_drop_area(False)
            return
    
    QMainWindow.dropEvent(host, event)

def highlight_drop_area(host, highlight):
    """切换拖拽提示条的高亮/常态样式（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        高亮态：蓝色实线边框 + 浅蓝背景 + “松开鼠标即可上传”文案；
        常态：灰色虚线边框 + 浅灰背景 + 常规拖拽说明。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，操作 _storage_drop_hint。
        highlight (bool): True=拖拽进入，False=拖拽离开/放下后恢复。

    返回:
        None。

    副作用:
        重设 QLabel 的样式表与文本；控件不存在时静默跳过。

    异常:
        无。

    【可改】高亮颜色: #3498DB（蓝色边框）
    【可改】正常颜色: #CCCCCC（灰色边框）
    【可改】边框宽度: 2px
    """
    if hasattr(host, '_storage_drop_hint'):
        if highlight:
            # 拖拽高亮样式 - 蓝色系（文件拖入时高亮提示，蓝色实线边框+浅蓝背景）
            #   QLabel {
            #     padding: 12px;                    内边距
            #     border: 2px solid #3498DB;        蓝色实线边框（高亮）
            #     border-radius: 8px;               8px圆角
            #     color: #2980B9;                   深蓝色文字
            #     font-size: 15px;                  字号13px
            #     background-color: #EBF5FB;        浅蓝背景
            #     font-weight: bold;                加粗
            #   }
            host._storage_drop_hint.setStyleSheet("""
                QLabel {
                    padding: 12px;
                    border: 2px solid #3498DB;
                    border-radius: 8px;
                    color: #2980B9;
                    font-size: 15px;
                    background-color: #EBF5FB;
                    font-weight: bold;
                }
            """)
            host._storage_drop_hint.setText("📥 松开鼠标即可上传文件")
        else:
            # 拖拽恢复样式 - 灰色虚线系（恢复正常状态，灰色虚线边框+浅灰背景）
            #   QLabel {
            #     padding: 12px;                    内边距
            #     border: 2px dashed #BDC3C7;       灰色虚线边框（正常态）
            #     border-radius: 8px;               8px圆角
            #     color: #7F8C8D;                   灰色文字
            #     font-size: 15px;                  字号13px
            #     background-color: #F8F9FA;        浅灰背景
            #   }
            host._storage_drop_hint.setStyleSheet("""
                QLabel {
                    padding: 12px;
                    border: 2px dashed #BDC3C7;
                    border-radius: 8px;
                    color: #7F8C8D;
                    font-size: 15px;
                    background-color: #F8F9FA;
                }
            """)
            host._storage_drop_hint.setText("📂 将文件拖拽到此处即可上传（支持图片、文档、数据文件）")

def handle_dropped_files(host, file_paths):
    """按扩展名分派拖拽/粘贴进来的文件（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        图片扩展名 → import_image_file；
        文本扩展名（txt/md/rtf）→ import_text_file_as_note（作为笔记）；
        其它 → import_data_file（作为普通文件）；
        逐个导入并统计成功/失败数量，最后在状态栏汇总。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        file_paths (list[str]): 本地文件绝对路径列表（非文件路径会被跳过）。

    返回:
        None。

    副作用:
        每个文件都会触发一次写盘+写索引+刷新视图；状态栏输出
        “已导入: 图片 N 张、笔记 N 篇、文件 N 个、失败 N 个”。

    异常:
        单个文件的异常被捕获并打印，同时 error_count+1，不影响其余文件。
        v0.0.42 起导入函数返回 bool，只有真正成功（含索引写盘成功）才计入对应计数，
        “弹框失败的导入”不再被统计为成功。
    """
    image_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.ico', '.svg'}
    note_extensions = {'.txt', '.md', '.rtf'}
    
    image_count = 0
    note_count = 0
    file_count = 0
    error_count = 0
    
    for file_path in file_paths:
        try:
            if not os.path.isfile(file_path):
                continue
            
            ext = os.path.splitext(file_path)[1].lower()
            
            if ext in image_extensions:
                ok = host._import_image_file(file_path)
                if ok:
                    image_count += 1
                else:
                    error_count += 1
            elif ext in note_extensions:
                # 文本文件导入为笔记
                ok = host._import_text_file_as_note(file_path)
                if ok is not False:
                    note_count += 1
                else:
                    error_count += 1
            else:
                ok = host._import_data_file(file_path)
                if ok:
                    file_count += 1
                else:
                    error_count += 1
                
        except Exception as e:
            print(f"导入文件 {file_path} 失败: {str(e)}")
            error_count += 1
    
    msg_parts = []
    if image_count > 0:
        msg_parts.append(f"图片 {image_count} 张")
    if note_count > 0:
        msg_parts.append(f"笔记 {note_count} 篇")
    if file_count > 0:
        msg_parts.append(f"文件 {file_count} 个")
    if error_count > 0:
        msg_parts.append(f"失败 {error_count} 个")
    
    if msg_parts:
        host.statusBar().showMessage("已导入: " + "、".join(msg_parts))

def import_text_file_as_note(host, file_path):
    """把外部文本文件读成笔记（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        以 UTF-8 读取全文，文件名（去扩展名）作为笔记标题，调用 _save_new_note
        以 JSON 笔记形式重新入库；UTF-8 解码失败时回退 GBK（兼容旧版 Windows 文本）。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。
        file_path (str): 源文本文件绝对路径。

    返回:
        bool: 是否成功保存为笔记（save_new_note 的返回值）。

    副作用:
        源文件本身不被复制/移动，只把内容写入新的 notes JSON；
        随后写索引、刷新视图。

    异常:
        GBK 仍失败时把异常原样 raise 给 handle_dropped_files 记录失败；
        UnicodeDecodeError 之外的 OSError 不在本函数捕获。
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        base_name = os.path.basename(file_path)
        name, _ = os.path.splitext(base_name)
        
        return host._save_new_note(name, content, [])
        
    except UnicodeDecodeError:
        # 如果utf-8读不了，试试gbk
        try:
            with open(file_path, 'r', encoding='gbk') as f:
                content = f.read()
            base_name = os.path.basename(file_path)
            name, _ = os.path.splitext(base_name)
            return host._save_new_note(name, content, [])
        except Exception as e:
            raise e

def on_storage_paste(host):
    """Ctrl+V 粘贴：按剪贴板内容导入文件/图片/文字笔记（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        仅在本页生效，按优先级处理剪贴板：
        1) 有本地文件 URL → 交给 handle_dropped_files（等同拖拽）
        2) 有图片 → 存为 images/粘贴图片_{时间戳}.png 并打「剪贴板」标签
        3) 有文本 → 询问是否保存为笔记（首行前 30 字作标题）
        4) 其它忽略

    参数:
        host (LotteryPredictionWindow): 主窗口实例。

    返回:
        None。

    副作用:
        可能新建图片/笔记文件；更新标签集合；写索引；刷新视图；状态栏提示。
        文本分支会弹出 Yes/No 确认框。

    异常:
        图片分支的异常只打印（不打断用户）；文本分支的落盘失败由 save_new_note 弹框。
        v0.0.42 起粘贴图片的 ID/文件名改用微秒时间戳 + 冲突序号，连续粘贴不再撞 ID。
    """
    clipboard = QApplication.clipboard()
    mime_data = clipboard.mimeData()
    
    # 检查是否在数据存储选项卡
    if not host._is_storage_tab_active():
        return
    
    # 1. 检查是否有文件
    if mime_data.hasUrls():
        files = [url.toLocalFile() for url in mime_data.urls() if url.isLocalFile()]
        if files:
            host._handle_dropped_files(files)
            return
    
    # 2. 检查是否有图片
    if mime_data.hasImage():
        try:
            pixmap = QPixmap(mime_data.imageData())
            if not pixmap.isNull():
                host._ensure_storage_dirs()
                file_id, filename, filepath = make_unique_storage_identity(
                    host, "img_", "粘贴图片_", ".png", "images")
                pixmap.save(filepath, "PNG")

                new_item = {
                    'id': file_id,
                    'type': 'image',
                    'title': filename,
                    'file_path': filepath,
                    'tags': ['剪贴板'],
                    'created_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'updated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'size': os.path.getsize(filepath),
                }
                host._storage_items.append(new_item)
                host._storage_tags.add('剪贴板')
                host._update_tag_list()
                saved = notify_if_index_save_failed(host)
                host._refresh_storage_display()
                if saved:
                    host.statusBar().showMessage("已从剪贴板粘贴图片")
                else:
                    host.statusBar().showMessage("图片已保存，但索引保存失败")
                return
        except Exception as e:
            print("粘贴图片失败:", str(e))
    
    # 3. 检查是否有文字
    if mime_data.hasText():
        text = mime_data.text()
        if text.strip():
            # 询问是否创建笔记
            reply = QMessageBox.question(
                host, "粘贴文字", 
                "检测到剪贴板中有文字，是否保存为笔记？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                # 取第一行作为标题
                lines = text.strip().split('\n')
                title = lines[0][:30] if lines else "未命名笔记"
                host._save_new_note(title, text, ['剪贴板'])
                host.statusBar().showMessage("已从剪贴板创建笔记")
            return


def apply_storage_config(host):
    """把持久化的排序模式回填到排序下拉框（v0.0.28 起实现已迁移自主窗口 LotteryPredictionWindow）

    功能:
        遍历下拉框各项的 itemData，找到与 _storage_sort_mode 相同的项并选中；
        找不到（旧配置里的模式已被删除）时保持当前选中项不变。

    参数:
        host (LotteryPredictionWindow): 主窗口实例，需已有 _storage_sort_combo。

    返回:
        None。

    副作用:
        可能改变下拉框 currentIndex；不触发刷新、不写配置。

    异常:
        无（控件缺失时静默返回）。

    说明:
        blockSignals(True/False) 包住 setCurrentIndex：否则会触发 currentIndexChanged
        → on_storage_sort_changed → _save_ini_config，在“恢复配置”阶段又写一遍 INI，
        既无意义又可能在恢复期覆盖其它尚未恢复的控件状态。
    """
    # 应用排序模式
    if hasattr(host, '_storage_sort_combo') and host._storage_sort_combo:
        sort_mode = getattr(host, '_storage_sort_mode', 'time_desc')
        for i in range(host._storage_sort_combo.count()):
            if host._storage_sort_combo.itemData(i) == sort_mode:
                host._storage_sort_combo.blockSignals(True)
                host._storage_sort_combo.setCurrentIndex(i)
                host._storage_sort_combo.blockSignals(False)
                break


def install(host):
    """安装「数据存储」选项卡：绑定事件入口并构建界面（v0.0.28 起页面自包含）

    功能:
        把本模块所有实现函数包装成“已绑定 host 的零参/少参 lambda”，
        挂到主窗口的 _xxx 属性上，使主窗口信号可以直接 connect；
        最后调用 build(host) 构建并返回页面控件。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。除安装方法外，还要求以下
            属性已由主窗口提供：_data_dir、_db（可为 None）、_save_ini_config()、
            _apply_splitter_sizes()、tabs、statusBar()。

    返回:
        QWidget: build(host) 构建完成的选项卡页面控件。

    副作用（挂到 host 的方法，按用途分组）:
        路径/索引: _get_storage_dir / _ensure_storage_dirs / _init_storage_data /
                   _load_storage_index / _save_storage_index / _sync_storage_files
        面板与视图: _update_tag_list / _toggle_category_panel / _toggle_tag_panel /
                   _get_filtered_items / _refresh_storage_display / _refresh_grid_view /
                   _create_storage_card / _refresh_list_view / _apply_storage_config
        筛选事件: _on_storage_category_changed / _on_storage_search /
                  _on_storage_sort_changed / _on_storage_tag_changed
        导入: _on_storage_upload_image / _import_image_file / _on_storage_new_note /
              _save_new_note / _on_storage_import_file / _import_data_file /
              _handle_dropped_files / _import_text_file_as_note / _on_storage_paste
        查看与管理: _on_storage_view_item / _on_storage_item_double_clicked /
                   _view_image / _view_or_edit_note / _update_note / _open_file /
                   _on_storage_delete_item / _on_storage_batch_delete /
                   _on_storage_select_all / _on_storage_rename_item /
                   _on_storage_list_context_menu / _on_storage_backup
        拖拽与判定: _is_storage_tab_active / _highlight_drop_area
        其它: _format_file_size / _update_storage_stats / _get_storage_btn_style

    异常:
        绑定阶段不抛异常；build 内部的控件创建/初始化异常会直接向外传播。

    调用方:
        run.py 的选项卡装配流程（按 TAB_INFO 的 order=15）。
    """
    host._apply_storage_config = lambda: apply_storage_config(host)
    host._get_storage_btn_style = lambda color: get_storage_btn_style(host, color)
    host._get_storage_dir = lambda: get_storage_dir(host)
    host._ensure_storage_dirs = lambda: ensure_storage_dirs(host)
    host._init_storage_data = lambda: init_storage_data(host)
    host._load_storage_index = lambda: load_storage_index(host)
    host._save_storage_index = lambda: save_storage_index(host)
    host._sync_storage_files = lambda: sync_storage_files(host)
    host._update_tag_list = lambda: update_tag_list(host)
    host._toggle_category_panel = lambda: toggle_category_panel(host)
    host._toggle_tag_panel = lambda: toggle_tag_panel(host)
    host._get_filtered_items = lambda: get_filtered_items(host)
    host._refresh_storage_display = lambda: refresh_storage_display(host)
    host._refresh_grid_view = lambda items: refresh_grid_view(host, items)
    host._create_storage_card = lambda item_data: create_storage_card(host, item_data)
    host._refresh_list_view = lambda items: refresh_list_view(host, items)
    host._on_storage_category_changed = lambda row: on_storage_category_changed(host, row)
    host._on_storage_search = lambda text: on_storage_search(host, text)
    host._on_storage_sort_changed = lambda index: on_storage_sort_changed(host, index)
    host._format_file_size = lambda size_bytes: format_file_size(host, size_bytes)
    host._update_storage_stats = lambda: update_storage_stats(host)
    host._on_storage_batch_delete = lambda: on_storage_batch_delete(host)
    host._on_storage_select_all = lambda: on_storage_select_all(host)
    host._on_storage_tag_changed = lambda row: on_storage_tag_changed(host, row)
    host._on_storage_upload_image = lambda: on_storage_upload_image(host)
    host._import_image_file = lambda src_path: import_image_file(host, src_path)
    host._on_storage_new_note = lambda: on_storage_new_note(host)
    host._save_new_note = lambda title, content, tags: save_new_note(host, title, content, tags)
    host._on_storage_import_file = lambda: on_storage_import_file(host)
    host._import_data_file = lambda src_path: import_data_file(host, src_path)
    host._on_storage_view_item = lambda item_data: on_storage_view_item(host, item_data)
    host._on_storage_item_double_clicked = lambda item: on_storage_item_double_clicked(host, item)
    host._view_image = lambda item_data: view_image(host, item_data)
    host._view_or_edit_note = lambda item_data: view_or_edit_note(host, item_data)
    host._update_note = lambda note_id, title, content, tags: update_note(host, note_id, title, content, tags)
    host._open_file = lambda item_data: open_file(host, item_data)
    host._on_storage_delete_item = lambda item_data: on_storage_delete_item(host, item_data)
    host._on_storage_backup = lambda: on_storage_backup(host)
    host._on_storage_list_context_menu = lambda pos: on_storage_list_context_menu(host, pos)
    host._on_storage_rename_item = lambda item_data: on_storage_rename_item(host, item_data)
    host._is_storage_tab_active = lambda: is_storage_tab_active(host)
    host._highlight_drop_area = lambda highlight: highlight_drop_area(host, highlight)
    host._handle_dropped_files = lambda file_paths: handle_dropped_files(host, file_paths)
    host._import_text_file_as_note = lambda file_path: import_text_file_as_note(host, file_path)
    host._on_storage_paste = lambda: on_storage_paste(host)
    return build(host)



# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "数据存储",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 15,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """构建「数据存储」选项卡页面控件

    功能:
        自上而下组装：拖拽提示条 → QSplitter（左侧导航/右侧内容）→
        右侧工具栏（搜索/排序/三个导入按钮）→ QStackedWidget（网格/列表双视图）
        → 底部状态栏（计数、全选、批量删除、视图切换）；
        最后初始化索引数据、恢复折叠/排序配置并首次刷新显示，注册 Ctrl+V 快捷键。

    参数:
        host (LotteryPredictionWindow): 主窗口实例。构建期会写入大量控件属性
            （_storage_drop_hint / _storage_cat_title / _storage_category_list /
            _storage_tag_title / _storage_tag_list / _storage_stats_* /
            _storage_search_edit / _storage_sort_combo / _storage_stack /
            _storage_grid_widget / _storage_grid_layout / _storage_list_widget /
            _storage_status_label / storage_splitter / _storage_main_widget），
            并依赖 install(host) 先完成事件入口绑定。

    返回:
        QWidget: 页面根控件（已 setAcceptDrops(True)，作为拖拽判定的比较基准）。

    副作用:
        创建大量子控件与信号连接；调用 _init_storage_data（建目录/读索引/扫描磁盘）、
        _apply_storage_config、_refresh_storage_display；读取并应用折叠状态。

    异常:
        若 install 未先执行，host._xxx 属性缺失会抛 AttributeError。

    布局要点:
        - 左侧滚动区宽度限制 150~360px，避免窄屏被压缩、宽屏被无限拉伸
        - 右侧 stack 索引固定：0=网格视图，1=列表视图（全选/切换按钮依赖该约定）
        - 分隔条初始 190:1000，随后由 _apply_splitter_sizes 用 INI 记忆值覆盖
    """
    widget = QWidget()
    widget.setAcceptDrops(True)  # 启用拖拽，支持文件拖入上传
    main_layout = QVBoxLayout(widget)
    main_layout.setContentsMargins(10, 10, 10, 10)  # 【可改】主布局上下左右边距
    main_layout.setSpacing(10)  # 【可改】各元素之间的间距

    # 顶部拖拽提示条
    # 提示用户可以拖拽文件到此处上传
    host._storage_drop_hint = QLabel("📂 将文件拖拽到此处即可上传（支持图片、笔记、数据文件）")
    host._storage_drop_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
    # 拖拽提示条样式 - 浅灰虚线边框系（低调提示，拖拽时由_highlight_drop_area切换高亮）
    #   QLabel {
    #     padding: 14px;                   内边距（越大提示条越高）
    #     border: 2px dashed #BDC3C7;      灰色虚线边框
    #     border-radius: 8px;              8px圆角
    #     color: #7F8C8D;                  灰色文字
    #     font-size: 15px;                 字号14px
    #     background-color: #F8F9FA;       浅灰背景
    #   }
    host._storage_drop_hint.setStyleSheet("""
        QLabel {
            padding: 14px;           /* 【可改】内边距，越大提示条越高 */
            border: 2px dashed #BDC3C7;  /* 【可改】边框样式：2px虚线+灰色 */
            border-radius: 8px;      /* 【可改】圆角半径 */
            color: #7F8C8D;          /* 【可改】文字颜色 */
            font-size: 15px;         /* 【可改】文字大小 */
            background-color: #F8F9FA;  /* 【可改】背景色 */
        }
    """)
    main_layout.addWidget(host._storage_drop_hint)

    # 主体区域（左侧分类 + 右侧内容）
    # 左右分栏使用 QSplitter：可拖动分隔条调整导航区与内容区宽度，位置记忆到 INI
    content_splitter = QSplitter(Qt.Orientation.Horizontal)
    content_splitter.setHandleWidth(3)
    content_splitter.setChildrenCollapsible(False)
    host.storage_splitter = content_splitter

    # 左侧分类面板（带滚动区域）
    left_scroll = QScrollArea()
    left_scroll.setMinimumWidth(150)  # 【可改】左侧面板最小宽度
    left_scroll.setMaximumWidth(360)  # 【可改】左侧面板最大宽度
    left_scroll.setWidgetResizable(True)
    left_scroll.setFrameShape(QFrame.Shape.NoFrame)
    left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)  # 隐藏水平滚动条

    left_panel = QWidget()
    left_layout = QVBoxLayout(left_panel)
    left_layout.setContentsMargins(0, 0, 5, 0)  # 【可改】左侧面板内边距（左/上/右/下）
    left_layout.setSpacing(5)  # 【可改】左侧各元素间距

    # 分类标题（可点击折叠/展开）
    host._storage_cat_title = QPushButton("分类 ▼")  # ▼展开 ▶折叠，可改符号
    # 分类标题按钮样式 - 透明背景系（可点击折叠/展开，悬停显示背景）
    #   QPushButton {
    #     font-size: 15px;          字号14px
    #     font-weight: bold;        加粗
    #     padding: 8px 10px;        内边距
    #     text-align: left;         左对齐
    #     border: none;             无边框
    #     background: transparent;  透明背景
    #     color: #333;              深灰文字
    #   }
    #   QPushButton:hover { background: #F0F0F0; border-radius: 4px; }  悬停浅灰背景
    host._storage_cat_title.setStyleSheet("""
        QPushButton {
            font-size: 15px;      /* 【可改】标题字体大小 */
            font-weight: bold;    /* 【可改】字体粗细 */
            padding: 8px 10px;    /* 【可改】内边距（上下 左右） */
            text-align: left;     /* 【可改】文字对齐方式 */
            border: none;
            background: transparent;
            color: #333;          /* 【可改】标题文字颜色 */
        }
        QPushButton:hover { background: #F0F0F0; border-radius: 4px; }  /* 【可改】悬停背景色 */
    """)
    # 信号连接：点击分类标题按钮折叠/展开分类面板
    host._storage_cat_title.clicked.connect(host._toggle_category_panel)
    left_layout.addWidget(host._storage_cat_title)

    # 分类列表
    host._storage_category_list = QListWidget()
    # 【可改】分类项目，格式：(显示名称, 分类ID)，可增删修改
    categories = [
        ("📁 全部内容", "all"),    # 显示全部
        ("🖼️ 图片库", "images"),   # 只显示图片
        ("📝 文本笔记", "notes"),   # 只显示笔记
        ("📊 数据文件", "files"),   # 只显示其他文件
    ]
    for name, cat_id in categories:
        item = QListWidgetItem(name)
        item.setData(Qt.ItemDataRole.UserRole, cat_id)  # 存储分类ID用于筛选
        host._storage_category_list.addItem(item)
    host._storage_category_list.setCurrentRow(0)  # 默认选中第一项
    # 信号连接：分类切换时刷新内容显示
    host._storage_category_list.currentRowChanged.connect(host._on_storage_category_changed)
    # 分类列表样式 - 白底蓝选中系（左侧导航列表，选中项蓝色高亮）
    #   QListWidget { border: 1px solid #DDD; border-radius: 6px; padding: 4px; font-size: 15px; }
    #   QListWidget::item { padding: 10px 12px; border-radius: 4px; }    列表项内边距
    #   QListWidget::item:selected { background-color: #D6EAF8; color: #2C3E50; }  选中项浅蓝背景+深蓝文字
    host._storage_category_list.setStyleSheet("""
        QListWidget { border: 1px solid #DDD; border-radius: 6px; padding: 4px; font-size: 15px; }
        QListWidget::item { padding: 10px 12px; border-radius: 4px; }  /* 【可改】列表项内边距 */
        QListWidget::item:selected { background-color: #D6EAF8; color: #2C3E50; }  /* 【可改】选中项颜色 */
    """)
    host._storage_category_list.setMinimumHeight(120)  # 【可改】分类列表最小高度
    left_layout.addWidget(host._storage_category_list)

    # 标签标题（可点击折叠/展开）
    host._storage_tag_title = QPushButton("标签 ▼")  # 【可改】标题文字和符号
    # 标签标题按钮样式 - 透明背景系（与分类标题按钮风格一致，可点击折叠/展开）
    #   QPushButton {
    #     font-size: 15px;          字号14px
    #     font-weight: bold;        加粗
    #     padding: 8px 10px;        内边距
    #     text-align: left;         左对齐
    #     border: none;             无边框
    #     background: transparent;  透明背景
    #     color: #333;              深灰文字
    #   }
    #   QPushButton:hover { background: #F0F0F0; border-radius: 4px; }  悬停浅灰背景
    host._storage_tag_title.setStyleSheet("""
        QPushButton {
            font-size: 15px;
            font-weight: bold;
            padding: 8px 10px;
            text-align: left;
            border: none;
            background: transparent;
            color: #333;
        }
        QPushButton:hover { background: #F0F0F0; border-radius: 4px; }
    """)
    # 信号连接：点击标签标题按钮折叠/展开标签面板
    host._storage_tag_title.clicked.connect(host._toggle_tag_panel)
    left_layout.addWidget(host._storage_tag_title)

    # 标签列表
    host._storage_tag_list = QListWidget()
    host._storage_tag_list.setMinimumHeight(100)  # 【可改】标签列表最小高度
    # 标签列表样式 - 白底绿选中系（左侧标签导航，选中项绿色高亮，区别于分类的蓝色）
    #   QListWidget { border: 1px solid #DDD; border-radius: 6px; padding: 4px; font-size: 15px; }
    #   QListWidget::item { padding: 8px 10px; border-radius: 4px; }    标签项内边距
    #   QListWidget::item:selected { background-color: #D5F5E3; color: #1E8449; }  选中项浅绿背景+深绿文字
    host._storage_tag_list.setStyleSheet("""
        QListWidget { border: 1px solid #DDD; border-radius: 6px; padding: 4px; font-size: 15px; }
        QListWidget::item { padding: 8px 10px; border-radius: 4px; }  /* 【可改】标签项内边距 */
        QListWidget::item:selected { background-color: #D5F5E3; color: #1E8449; }  /* 【可改】选中标签颜色 */
    """)
    # 信号连接：标签切换时刷新内容显示
    host._storage_tag_list.currentRowChanged.connect(host._on_storage_tag_changed)
    left_layout.addWidget(host._storage_tag_list)

    # 一键备份按钮
    btn_backup = QPushButton("📦 一键备份")
    # 信号连接：点击一键备份按钮触发数据备份
    btn_backup.clicked.connect(host._on_storage_backup)
    btn_backup.setFixedHeight(34)  # 【可改】按钮高度
    # 一键备份按钮样式 - 紫色轮廓系（白底紫边紫字，低调但可辨识）
    #   QPushButton {
    #     padding: 8px 12px;             内边距
    #     border: 1px solid #9B59B6;     紫色边框
    #     border-radius: 6px;            6px圆角
    #     font-size: 15px;               字号13px
    #     color: #9B59B6;                紫色文字
    #     background: white;             白色背景
    #   }
    #   QPushButton:hover { background: #F5EEF8; }  悬停浅紫背景
    btn_backup.setStyleSheet("""
        QPushButton {
            padding: 8px 12px;
            border: 1px solid #9B59B6;  /* 【可改】边框颜色（紫色）*/
            border-radius: 6px;         /* 【可改】圆角 */
            font-size: 15px;            /* 【可改】字体大小 */
            color: #9B59B6;             /* 【可改】文字颜色 */
            background: white;          /* 【可改】背景色 */
        }
        QPushButton:hover { background: #F5EEF8; }
    """)
    left_layout.addWidget(btn_backup)

    # 存储统计信息面板
    # 显示各类文件数量和总占用空间
    stats_group = QWidget()
    stats_layout = QVBoxLayout(stats_group)
    stats_layout.setContentsMargins(8, 8, 8, 8)  # 【可改】统计面板内边距
    stats_layout.setSpacing(4)  # 【可改】统计项之间的间距
    # 统计面板容器样式 - 浅灰底系（左侧统计信息卡片背景）
    #   QWidget {
    #     background-color: #F8F9FA;  浅灰背景
    #     border-radius: 6px;         6px圆角
    #     border: 1px solid #E9ECEF;  极浅灰边框
    #   }
    stats_group.setStyleSheet("""
        QWidget {
            background-color: #F8F9FA;  /* 【可改】背景色 */
            border-radius: 6px;            /* 【可改】圆角 */
            border: 1px solid #E9ECEF;   /* 【可改】边框颜色 */
        }
    """)

    stats_title = QLabel("📊 存储统计")
    # 统计标题样式：14px加粗，深色文字
    stats_title.setStyleSheet("font-size: 15px; font-weight: bold; color: #343a40;")
    stats_layout.addWidget(stats_title)

    host._storage_stats_images = QLabel("🖼️ 图片: 0")
    # 图片统计标签样式：13px字号，中灰色文字
    host._storage_stats_images.setStyleSheet("font-size: 15px; color: #495057;")
    stats_layout.addWidget(host._storage_stats_images)

    host._storage_stats_notes = QLabel("📝 笔记: 0")
    # 笔记统计标签样式：13px字号，中灰色文字（与图片统计一致）
    host._storage_stats_notes.setStyleSheet("font-size: 15px; color: #495057;")
    stats_layout.addWidget(host._storage_stats_notes)

    host._storage_stats_files = QLabel("📂 文件: 0")
    # 文件统计标签样式：13px字号，中灰色文字（与图片统计一致）
    host._storage_stats_files.setStyleSheet("font-size: 15px; color: #495057;")
    stats_layout.addWidget(host._storage_stats_files)

    host._storage_stats_total = QLabel("💾 总计: 0 B")
    host._storage_stats_total.setStyleSheet("font-size: 15px; color: #28A745; font-weight: bold;")  # 【可改】总计文字颜色（绿色）
    stats_layout.addWidget(host._storage_stats_total)

    left_layout.addWidget(stats_group)

    left_layout.addStretch()  # 弹性空间，把内容往上推
    left_scroll.setWidget(left_panel)
    content_splitter.addWidget(left_scroll)

    # 右侧主内容区
    right_panel = QWidget()
    right_layout = QVBoxLayout(right_panel)
    right_layout.setContentsMargins(0, 0, 0, 0)
    right_layout.setSpacing(8)  # 【可改】右侧内容区各元素间距

    # 顶部工具栏
    toolbar = QWidget()
    toolbar_layout = QHBoxLayout(toolbar)
    toolbar_layout.setContentsMargins(0, 0, 0, 0)

    # 搜索框
    host._storage_search_edit = QLineEdit()
    host._storage_search_edit.setPlaceholderText("🔍 搜索笔记、图片备注、文件名...")  # 【可改】占位提示文字
    # 信号连接：搜索文本变化时过滤显示内容
    host._storage_search_edit.textChanged.connect(host._on_storage_search)
    host._storage_search_edit.setFixedHeight(34)  # 【可改】搜索框高度
    # 搜索框样式 - 白底灰边系（获取焦点时蓝色边框高亮）
    #   QLineEdit { padding: 8px 12px; border: 1px solid #DDD; border-radius: 6px; font-size: 15px; }
    #   QLineEdit:focus { border-color: #3498DB; }  聚焦时蓝色边框
    host._storage_search_edit.setStyleSheet("""
        QLineEdit { padding: 8px 12px; border: 1px solid #DDD; border-radius: 6px; font-size: 15px; }
        QLineEdit:focus { border-color: #3498DB; }  /* 【可改】获取焦点时边框颜色（蓝色）*/
    """)
    toolbar_layout.addWidget(host._storage_search_edit, 1)  # 1表示拉伸因子，占据剩余空间

    # 排序下拉框
    host._storage_sort_combo = QComboBox()
    # 【可改】排序选项，格式：(显示文字, 排序标识)，可增删修改
    sort_options = [
        ("⏰ 最新优先", "time_desc"),   # 按创建时间倒序（新→旧）
        ("⏳ 最早优先", "time_asc"),    # 按创建时间正序（旧→新）
        ("名称升序", "name_asc"),     # 按名称字母A→Z
        ("🔡 名称降序", "name_desc"),    # 按名称字母Z→A
        ("📦 大文件优先", "size_desc"),  # 按文件大小大→小
        ("📦 小文件优先", "size_asc"),   # 按文件大小小→大
    ]
    for text, value in sort_options:
        host._storage_sort_combo.addItem(text, value)
    host._storage_sort_combo.setCurrentIndex(0)  # 默认选中第1项
    # 信号连接：排序方式变更时重新排序并刷新显示
    host._storage_sort_combo.currentIndexChanged.connect(host._on_storage_sort_changed)
    host._storage_sort_combo.setMinimumHeight(34)  # 【可改】下拉框最小高度
    # 排序下拉框样式 - 白底灰边系（悬停时蓝色边框，下拉列表13px字号）
    #   QComboBox { padding: 6px 10px; border: 1px solid #DDD; border-radius: 6px; font-size: 15px; }
    #   QComboBox:hover { border-color: #3498DB; }                          悬停蓝色边框
    #   QComboBox QAbstractItemView { padding: 4px; font-size: 15px; }      下拉列表样式
    host._storage_sort_combo.setStyleSheet("""
        QComboBox { padding: 6px 10px; border: 1px solid #DDD; border-radius: 6px; font-size: 15px; }
        QComboBox:hover { border-color: #3498DB; }  /* 【可改】悬停边框颜色 */
        QComboBox QAbstractItemView { padding: 4px; font-size: 15px; }
    """)
    toolbar_layout.addWidget(host._storage_sort_combo)

    # 上传图片按钮（绿色）
    btn_upload_img = QPushButton("📷 上传图片")
    # 信号连接：点击上传图片按钮弹出文件选择对话框
    btn_upload_img.clicked.connect(host._on_storage_upload_image)
    btn_upload_img.setFixedHeight(34)
    btn_upload_img.setStyleSheet(host._get_storage_btn_style("#27AE60"))  # 【可改】按钮颜色
    toolbar_layout.addWidget(btn_upload_img)

    # 新建笔记按钮（蓝色）
    btn_new_note = QPushButton("📝 新建笔记")
    # 信号连接：点击新建笔记按钮创建新笔记
    btn_new_note.clicked.connect(host._on_storage_new_note)
    btn_new_note.setFixedHeight(34)
    btn_new_note.setStyleSheet(host._get_storage_btn_style("#3498DB"))  # 【可改】按钮颜色（蓝色）
    toolbar_layout.addWidget(btn_new_note)

    # 导入文件按钮（橙色）
    btn_import = QPushButton("📂 导入文件")
    # 信号连接：点击导入文件按钮导入数据文件
    btn_import.clicked.connect(host._on_storage_import_file)
    btn_import.setFixedHeight(34)
    btn_import.setStyleSheet(host._get_storage_btn_style("#F39C12"))  # 【可改】按钮颜色（橙色）
    toolbar_layout.addWidget(btn_import)

    right_layout.addWidget(toolbar)

    # 内容显示区（堆叠布局，切换网格/列表视图）
    host._storage_stack = QStackedWidget()  # 堆叠布局，同一时间只显示一个子控件

    # 网格视图（卡片式布局）
    host._storage_grid_widget = QWidget()
    host._storage_grid_widget.setAcceptDrops(True)  # 支持拖拽上传
    grid_scroll = QScrollArea()  # 滚动区域
    grid_scroll.setWidgetResizable(True)
    grid_scroll.setWidget(host._storage_grid_widget)
    host._storage_grid_layout = QGridLayout(host._storage_grid_widget)
    host._storage_grid_layout.setSpacing(10)  # 【可改】卡片之间的间距
    host._storage_grid_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)  # 左上对齐
    host._storage_stack.addWidget(grid_scroll)  # 索引0：网格视图

    # 列表视图（紧凑列表）
    host._storage_list_widget = QListWidget()
    host._storage_list_widget.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)  # 支持Ctrl/Shift多选
    # 信号连接：双击列表项打开/查看对应文件
    host._storage_list_widget.itemDoubleClicked.connect(host._on_storage_item_double_clicked)  # 双击打开
    host._storage_list_widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)  # 启用右键菜单
    # 信号连接：右键点击触发上下文菜单
    host._storage_list_widget.customContextMenuRequested.connect(host._on_storage_list_context_menu)
    # 列表视图样式 - 白底蓝选中系（右侧列表视图，选中项蓝色高亮，与分类列表风格一致）
    #   QListWidget { border: 1px solid #DDD; border-radius: 6px; padding: 4px; font-size: 15px; }
    #   QListWidget::item { padding: 10px 12px; border-radius: 4px; }    列表项内边距（控制行高）
    #   QListWidget::item:selected { background-color: #D6EAF8; color: #2C3E50; }  选中项浅蓝背景+深蓝文字
    host._storage_list_widget.setStyleSheet("""
        QListWidget { border: 1px solid #DDD; border-radius: 6px; padding: 4px; font-size: 15px; }
        QListWidget::item { padding: 10px 12px; border-radius: 4px; }  /* 【可改】列表项高度（通过内边距控制）*/
        QListWidget::item:selected { background-color: #D6EAF8; color: #2C3E50; }  /* 【可改】选中项背景色和文字色 */
    """)
    host._storage_stack.addWidget(host._storage_list_widget)  # 索引1：列表视图

    right_layout.addWidget(host._storage_stack, 1)  # 1表示拉伸因子，占据剩余空间

    # 底部状态栏
    status_bar = QWidget()
    status_layout = QHBoxLayout(status_bar)
    status_layout.setContentsMargins(5, 0, 5, 0)  # 【可改】状态栏内边距

    # 项目数量统计
    host._storage_status_label = QLabel("共 0 个项目")
    host._storage_status_label.setStyleSheet("font-size: 15px; color: #666;")  # 【可改】状态栏文字样式
    status_layout.addWidget(host._storage_status_label)

    status_layout.addStretch()  # 弹性空间，把按钮推到右边

    # 全选按钮
    btn_select_all = QPushButton("☑ 全选")
    btn_select_all.setFixedSize(90, 36)  # 【可改】按钮尺寸（宽×高）
    # 全选按钮样式 - 白底灰边系（底部状态栏辅助按钮，低调中性）
    #   QPushButton {
    #     font-size: 15px;             字号14px
    #     border: 1px solid #DDD;      浅灰边框
    #     border-radius: 6px;          6px圆角
    #     background: white;           白色背景
    #     color: #333;                 深灰文字
    #   }
    #   QPushButton:hover { background: #F0F0F0; }  悬停浅灰背景
    btn_select_all.setStyleSheet("""
        QPushButton {
            font-size: 15px;    /* 【可改】字体大小 */
            border: 1px solid #DDD;  /* 【可改】边框颜色 */
            border-radius: 6px;      /* 【可改】圆角 */
            background: white;       /* 【可改】背景色 */
            color: #333;             /* 【可改】文字颜色 */
        }
        QPushButton:hover { background: #F0F0F0; }  /* 【可改】悬停背景色 */
    """)
    # 信号连接：点击全选按钮选中所有显示的项目
    btn_select_all.clicked.connect(host._on_storage_select_all)
    btn_select_all.setToolTip("全选所有显示的项目")
    status_layout.addWidget(btn_select_all)

    # 批量删除按钮
    btn_batch_delete = QPushButton("🗑 删除选中")
    btn_batch_delete.setFixedSize(110, 36)  # 【可改】按钮尺寸
    # 批量删除按钮样式 - 红色轮廓系（白底红边红字，危险操作醒目警示）
    #   QPushButton {
    #     font-size: 15px;              字号14px
    #     border: 1px solid #E74C3C;    红色边框（警示色）
    #     border-radius: 6px;           6px圆角
    #     background: white;            白色背景
    #     color: #E74C3C;               红色文字（警示色）
    #   }
    #   QPushButton:hover { background: #FADBD8; }  悬停浅红背景
    btn_batch_delete.setStyleSheet("""
        QPushButton {
            font-size: 15px;
            border: 1px solid #E74C3C;  /* 【可改】边框颜色（红色）*/
            border-radius: 6px;
            background: white;
            color: #E74C3C;             /* 【可改】文字颜色（红色）*/
        }
        QPushButton:hover { background: #FADBD8; }  /* 【可改】悬停背景色（浅红）*/
    """)
    # 信号连接：点击批量删除按钮删除所有选中的项目
    btn_batch_delete.clicked.connect(host._on_storage_batch_delete)
    btn_batch_delete.setToolTip("删除所有选中的项目（不可恢复）")
    status_layout.addWidget(btn_batch_delete)

    # 网格视图切换按钮
    btn_grid_view = QPushButton("▦ 网格")
    btn_grid_view.setFixedSize(75, 36)  # 【可改】按钮尺寸
    # 网格视图切换按钮样式 - 白底灰边系（视图切换按钮，与列表切换按钮风格一致）
    #   QPushButton {
    #     font-size: 15px;         字号14px
    #     border: 1px solid #DDD;  浅灰边框
    #     border-radius: 6px;      6px圆角
    #     background: white;       白色背景
    #     color: #333;             深灰文字
    #   }
    #   QPushButton:hover { background: #F0F0F0; }  悬停浅灰背景
    btn_grid_view.setStyleSheet("""
        QPushButton {
            font-size: 15px;
            border: 1px solid #DDD;
            border-radius: 6px;
            background: white;
            color: #333;
        }
        QPushButton:hover { background: #F0F0F0; }
    """)
    # 信号连接：点击网格按钮切换到网格视图（索引0）
    btn_grid_view.clicked.connect(lambda: host._storage_stack.setCurrentIndex(0))
    btn_grid_view.setToolTip("网格视图")
    status_layout.addWidget(btn_grid_view)

    btn_list_view = QPushButton("☰ 列表")
    btn_list_view.setFixedSize(75, 36)
    # 列表视图切换按钮样式 - 白底灰边系（与网格切换按钮风格一致）
    #   QPushButton {
    #     font-size: 15px;         字号14px
    #     border: 1px solid #DDD;  浅灰边框
    #     border-radius: 6px;      6px圆角
    #     background: white;       白色背景
    #     color: #333;             深灰文字
    #   }
    #   QPushButton:hover { background: #F0F0F0; }  悬停浅灰背景
    btn_list_view.setStyleSheet("""
        QPushButton {
            font-size: 15px;
            border: 1px solid #DDD;
            border-radius: 6px;
            background: white;
            color: #333;
        }
        QPushButton:hover { background: #F0F0F0; }
    """)
    # 信号连接：点击列表按钮切换到列表视图（索引1）
    btn_list_view.clicked.connect(lambda: host._storage_stack.setCurrentIndex(1))
    btn_list_view.setToolTip("列表视图")
    status_layout.addWidget(btn_list_view)

    right_layout.addWidget(status_bar)

    content_splitter.addWidget(right_panel)
    # 拉伸因子：左栏固定不吸收多余宽度，右栏吸收全部剩余空间，
    # 否则窗口放大时左侧导航会被一起拉宽，浪费内容区
    content_splitter.setStretchFactor(0, 0)
    content_splitter.setStretchFactor(1, 1)
    # 首次显示的兜底尺寸（左 190px / 右 1000px），仅在没有可用 INI 记忆时生效
    content_splitter.setSizes([190, 1000])
    # 用 INI 记忆覆盖上面的默认值：_apply_splitter_sizes 只有在“保存的栏数 ==
    # 当前栏数（2）且每栏 >= 30px”时才恢复（见 plugins/彩票预测.py），
    # 条件不满足（旧配置栏数不符或某栏被拖到 30px 以下）则保留 [190,1000] 兜底
    host._apply_splitter_sizes(content_splitter, 'storage_splitter')
    main_layout.addWidget(content_splitter, 1)

    # 保存 widget 引用：拖拽落点判定（is_storage_tab_active）与显示/隐藏都以它为基准
    host._storage_main_widget = widget

    # 初始化数据（目录、索引、标签，均在控件建好后才执行，回调里才能安全刷新界面）
    host._init_storage_data()
    # 回填排序下拉框（内部已 blockSignals，恢复期不会反向写 INI）
    host._apply_storage_config()
    # 折叠状态由 init_storage_data 保留（或填默认值）后据此套用；
    # 该类状态同时写进 INI，启动时已由 _load_ini_config 恢复
    if getattr(host, '_category_collapsed', False):
        host._storage_category_list.setVisible(False)
        host._storage_cat_title.setText("分类 ▶")
    if getattr(host, '_tag_collapsed', False):
        host._storage_tag_list.setVisible(False)
        host._storage_tag_title.setText("标签 ▶")
    host._refresh_storage_display()

    # 添加粘贴快捷键（绑定到页面 widget 而非主窗口，保证焦点在本页时 Ctrl+V 才生效）
    paste_shortcut = QShortcut(QKeySequence.StandardKey.Paste, widget)
    # 信号连接：Ctrl+V粘贴时触发剪贴板内容导入
    paste_shortcut.activated.connect(host._on_storage_paste)

    return widget
