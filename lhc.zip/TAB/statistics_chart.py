# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/statistics_chart.py - 「统计分析图表」选项卡页面构建模块
===========================================================================
模块职责：
    1. 构建「统计分析图表」页：左侧 13 个图表类型按钮，右侧标题 + 可滚动
       matplotlib 画布（StatisticsChart）
    2. 实现各图表的数据统计与绘制入口：show_xxx 设置标题后转交 draw_chart，
       draw_chart 从历史记录计算频次/遗漏/单双/大小/颜色/区间/尾数等数据，
       再调用 StatisticsChart 的 plot_xxx 绘制
    3. v0.0.28 起页面自包含：install 把 14 个回调挂到 host，build 构建界面

在架构中的位置：
    界面层 TAB/ 的页面模块，由主窗口创建选项卡时调用 install(host)；
    历史数据经主窗口 _analysis_records() 获取（优先 DuckDB，失败回退内存），
    本页不直接读取 JSON 文件。

依赖：
    - UI：Qt 控件统一从 UI/UI.py 导入（禁止直接 from PyQt6 import ...）
    - lib.data_process.LotteryConfig：红蓝绿分组、区间定义、尾数等只读配置
    - lib.plot_draw：_get_mpl（触发懒加载并缓存 QtAgg 后端）、
      get_line2d_class（图例用的 Line2D 类）
    - TAB.widgets.StatisticsChart：封装 Figure/Canvas 与全部 plot_xxx 绘图方法；
      构造函数内部调用 _get_mpl()，matplotlib 缺失时 figure/canvas 为 None
    - 本模块不直接 import matplotlib/numpy；matplotlib 仅在首次需要画布时懒加载

数据流：
    host.historical_data --(_analysis_records)--> records（约定最新在前）
    -> draw_chart 按 chart_type 统计出 dict/list 数据
    -> StatisticsChart.plot_xxx 清空 Figure、重绘子图、canvas.draw()
    -> 绘图对象生命周期挂在本页 host.main_chart_widget 上，整页存活期间复用同一
       Figure/Canvas，切图只 clear 不重建；matplotlib 不可用时构造函数降级为
       figure=None，各 plot_xxx 内部判空后直接返回（本页 draw_chart 需保证不越界访问）

导出对象：
    TAB_INFO（title=统计分析图表，order=6）
    install(host)：绑定 14 个 host._show_xxx / _draw_chart 回调并构建页面
    build(host)：纯界面构建，返回页面 QWidget
===========================================================================
"""

import os as _os_boot  # 作用说明：提供 dirname/abspath/exists/join 等路径能力，用于向上定位项目根目录
import sys as _sys_boot  # 作用说明：提供 sys.path 访问，用于把项目根目录加入模块搜索路径以支持直接运行本文件

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QEvent, QLabel, QObject, QPushButton, QScrollArea, QSplitter, QTimer, QVBoxLayout, QWidget, Qt)  # 作用说明：统一获取本页所需的 Qt 控件（标签/按钮/滚动区/分割器/布局）及 Qt 枚举，避免直接 import PyQt6；QEvent/QObject/QTimer 供 H54 主题切换后重绘画布
# 统计计算统一由 lib/data_process.py 的 D1–D4 函数提供（本页只负责取数与绘图）
from lib.data_process import (  # 作用说明：引入频率/遗漏/单双/大小/颜色/区间/尾数分布、走势、共现、间隔、连号与和值等统计函数，本页只取数与调度绘图
    LotteryConfig, compute_frequency, compute_missing,
    compute_odd_even_distribution, compute_size_distribution,
    compute_color_distribution, compute_range_distribution,
    compute_tail_distribution, build_trend_data, build_cooccurrence_matrix,
    cooccurrence_to_matrix, build_interval_data, select_top_interval_samples,
    compute_consecutive_probability, compute_sum_values,
)
from lib.plot_draw import _get_mpl, get_line2d_class  # 作用说明：提供 matplotlib 的惰性加载与图例 Line2D 获取，避免本页直接 import matplotlib，缺失时统一降级
from TAB.widgets import (StatisticsChart)  # 作用说明：提供封装 Figure/Canvas 与各 plot_xxx 绘图方法的图表控件，本页复用它承载画布



# ╔══════════════════════════════════════════════════════════════════╗
# ║  [统计分析图表：频率/遗漏/分布/走势/热力图/间隔/连号/和值]
# ╚══════════════════════════════════════════════════════════════════╝

def show_frequency_chart(host):
    """切换到「频率分布图」：更新标题并触发绘制

    功能:
        统计正码与特别码在历史记录中的出现次数，绘制按号码着色的柱状图。

    参数:
        host: 主窗口实例，需已构建 chart_title_label 与 main_chart_widget。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("frequency") 清空并重绘画布。
    """
    host.chart_title_label.setText("频率分布图")
    host._draw_chart("frequency")


def show_missing_chart(host):
    """切换到「遗漏值分析图」：更新标题并触发绘制

    功能:
        按“距最近一次出现的期数”统计每个号码的遗漏值，绘制柱状图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("missing") 清空并重绘画布。
    """
    host.chart_title_label.setText("遗漏值分析图")
    host._draw_chart("missing")


def show_odd_even_chart(host):
    """切换到「单双分布图」：更新标题并触发绘制

    功能:
        统计正码中奇数与偶数的总个数，绘制饼图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("odd_even") 清空并重绘画布。
    """
    host.chart_title_label.setText("单双分布图")
    host._draw_chart("odd_even")


def show_size_chart(host):
    """切换到「大小分布图」：更新标题并触发绘制

    功能:
        以 24 为界统计正码大号(25-49)/小号(1-24)的总个数，绘制饼图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("size") 清空并重绘画布。
    """
    host.chart_title_label.setText("大小分布图")
    host._draw_chart("size")


def show_color_chart(host):
    """切换到「颜色分布图」：更新标题并触发绘制

    功能:
        按 LotteryConfig 的红/蓝/绿分组统计正码个数，绘制饼图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("color") 清空并重绘画布。
    """
    host.chart_title_label.setText("颜色分布图")
    host._draw_chart("color")


def show_range_chart(host):
    """切换到「区间分布图」：更新标题并触发绘制

    功能:
        按 LotteryConfig.RANGES 的五个区间（1-10/11-20/21-30/31-40/41-49）
        统计正码个数，绘制饼图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("range") 清空并重绘画布。
    """
    host.chart_title_label.setText("区间分布图")
    host._draw_chart("range")


def show_tail_chart(host):
    """切换到「尾数分布图」：更新标题并触发绘制

    功能:
        统计正码个位数字 0~9 的出现次数，绘制饼图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("tail") 清空并重绘画布。
    """
    host.chart_title_label.setText("尾数分布图")
    host._draw_chart("tail")


def show_comprehensive_chart(host):
    """切换到「综合走势图」：更新标题并触发绘制

    功能:
        取最近 50 期，逐期按红/蓝/绿散点展示号码分布，绘制综合走势图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("comprehensive") 清空并重绘画布。
    """
    host.chart_title_label.setText("综合走势图")
    host._draw_chart("comprehensive")


def draw_chart(host, chart_type):
    """按图表类型统计历史数据并调用 StatisticsChart 绘制

    功能:
        支持 12 种类型：
        frequency 数字频次柱状图；missing 遗漏期数柱状图；odd_even 单双饼图；
        size 大小饼图；color 波色饼图；range 区间饼图；tail 尾数饼图；
        comprehensive 最近 50 期综合走势；correlation_heatmap 49x49 共现矩阵；
        interval_analysis 高频号码出现间隔箱线图；consecutive_probability
        连号/邻号/同尾数概率；sum_distribution 和值直方图（含正态拟合）。
        无历史数据时在画布中央绘制“暂无数据”占位。

    参数:
        host: 主窗口实例。读取 host.historical_data，调用
            host._analysis_records()（DuckDB 优先、失败回退内存），
            通过 host.main_chart_widget 访问 Figure/Canvas 与 plot_xxx 方法；
        chart_type: str，图表类型标识（取值见上）。

    返回:
        None。

    副作用:
        - 触发 _analysis_records()：必要时同步历史数据到 DuckDB；
        - StatisticsChart 内部执行 figure.clear()、add_subplot、canvas.draw()；
        - 无数据/空统计结果时只重绘占位文本，不写 host 状态。

    异常:
        未捕获异常；matplotlib 缺失（figure/canvas 为 None）时本函数的
        clear/add_subplot 会抛 AttributeError（见下方 TODO）。
        未知 chart_type 不绘图、也不报错。

    TODO(待确认): 无数据分支直接调用 host.main_chart_widget.figure.clear()，
        matplotlib 懒加载失败时 StatisticsChart.figure 为 None，会抛
        AttributeError；应先判空再降级为纯文本提示（show_number_trend_chart 同）。
    """
    if not host.historical_data:
        host.main_chart_widget.figure.clear()
        ax = host.main_chart_widget.figure.add_subplot(111)
        ax.text(0.5, 0.5, '暂无数据', ha='center', va='center', fontsize=16)
        ax.set_title('请先导入数据', fontsize=15)
        host.main_chart_widget.redraw()
        return
    records = host._analysis_records()[0]
    if chart_type == "frequency":
        frequency = compute_frequency(records)
        if frequency:
            host.main_chart_widget.plot_frequency(frequency, "数字出现频率分布")
    elif chart_type == "missing":
        host.main_chart_widget.plot_missing(compute_missing(records), "数字遗漏期数")
    elif chart_type == "odd_even":
        host.main_chart_widget.plot_distribution(
            compute_odd_even_distribution(records), "单双分布统计")
    elif chart_type == "size":
        host.main_chart_widget.plot_distribution(
            compute_size_distribution(records), "大小分布统计")
    elif chart_type == "color":
        host.main_chart_widget.plot_distribution(
            compute_color_distribution(records), "颜色分布统计")
    elif chart_type == "range":
        host.main_chart_widget.plot_distribution(
            compute_range_distribution(records), "区间分布统计")
    elif chart_type == "tail":
        host.main_chart_widget.plot_distribution(
            compute_tail_distribution(records), "尾数分布统计")
    elif chart_type == "comprehensive":
        host.main_chart_widget.plot_trend(
            build_trend_data(records, 50), "综合走势图（最近50期）")
    elif chart_type == "correlation_heatmap":
        # 功能9：相关性热力图 - 49x49 共现计数由 lib 构造，本页只做矩阵格式转换
        matrix = cooccurrence_to_matrix(build_cooccurrence_matrix(records))
        host.main_chart_widget.plot_correlation_heatmap(
            matrix, "号码相关性热力图（共现矩阵）")
    elif chart_type == "interval_analysis":
        # 功能9：间隔分析图 - lib 负责统计间隔与 Top15 选取，控件只绘图
        host.main_chart_widget.plot_interval_analysis(
            select_top_interval_samples(build_interval_data(records), 15),
            "号码间隔分析图（箱线图）")
    elif chart_type == "consecutive_probability":
        # 功能9：连号邻号概率图 - 连号/邻号/同尾数统计全部在 lib 完成
        host.main_chart_widget.plot_consecutive_probability(
            compute_consecutive_probability(records), "连号邻号概率分析")
    elif chart_type == "sum_distribution":
        # 功能9：和值分布图 - lib 提取每期正码和值，控件负责直方图与拟合
        host.main_chart_widget.plot_sum_distribution(
            compute_sum_values(records), "和值分布图（含正态拟合）")


def show_number_trend_chart(host):
    """绘制最近 20 期号码走势图（正码圆点 + 特别码星形）

    功能:
        不走 draw_chart：号码走势需要跨期连线与特别码标注，本函数单独取数、
        构建 Figure。每期正码按红/蓝/绿画圆点，同色之间用低透明度细线连接
        以显示延续趋势；特别码用橙色星形标注；X 轴为期号（旋转 45°）。

    参数:
        host: 主窗口实例。读取 host.historical_data，经
            host._analysis_records() 取数，使用 host.main_chart_widget
            （StatisticsChart）的 Figure/Canvas。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 清空并重建 host.main_chart_widget.figure 的唯一子图，调用
          canvas.draw()，tight_layout() 调整边距；
        - 通过 lib.plot_draw.get_line2d_class() 构建图例（Line2D 缺失时跳过图例）。

    异常:
        未捕获异常；matplotlib 缺失时 figure 为 None，无数据/正常绘制分支都会
        抛 AttributeError（见 draw_chart 的 TODO）。

    说明:
        records 约定“最新在前”，recent 先取前 20 条再 reversed，使 X 轴从左到右
        为由旧到新；图例/字体下限 15px 与全局约定一致。
    """
    host.chart_title_label.setText("号码走势图")
    if not host.historical_data:
        host.main_chart_widget.figure.clear()
        ax = host.main_chart_widget.figure.add_subplot(111)
        ax.text(0.5, 0.5, '暂无数据', ha='center', va='center', fontsize=16)
        ax.set_title('请先导入数据', fontsize=15)
        host.main_chart_widget.redraw()
        return

    # 号码走势图不在 _draw_chart 内，单独走 DuckDB 取数（失败自动回退内存）
    records = host._analysis_records()[0]
    recent = list(reversed(records[-20:]))
    host.main_chart_widget.figure.clear()
    ax = host.main_chart_widget.figure.add_subplot(111)

    red_pts = {x: [] for x in range(len(recent))}
    blue_pts = {x: [] for x in range(len(recent))}
    green_pts = {x: [] for x in range(len(recent))}
    special_pts = {x: [] for x in range(len(recent))}

    for i, record in enumerate(recent):
        numbers = record.get('numbers', [])
        special = record.get('special', 0)
        for n in numbers:
            if LotteryConfig.is_red(n):
                red_pts[i].append(n)
            elif LotteryConfig.is_blue(n):
                blue_pts[i].append(n)
            else:
                green_pts[i].append(n)
        special_pts[i] = special

    # 同色连线
    for color_pts, color, label in [
        (red_pts, '#FF0000', '红'),
        (blue_pts, '#0000FF', '蓝'),
        (green_pts, '#008000', '绿')
    ]:
        prev_x, prev_y = None, None
        for i in range(len(recent)):
            for n in color_pts[i]:
                ax.plot(i, n, 'o', color=color, markersize=6, zorder=3)
                if prev_x is not None:
                    ax.plot([prev_x, i], [prev_y, n], '-', color=color, alpha=0.3, linewidth=0.8)
                prev_x, prev_y = i, n

    # 特别码星形标注
    for i in range(len(recent)):
        sp = special_pts[i]
        if sp:
            ax.plot(i, sp, '*', color='#F39C12', markersize=12, zorder=4, markeredgecolor='#E67E22')

    periods = [str(r.get('period', '?')) for r in recent]
    ax.set_xticks(range(len(recent)))
    ax.set_xticklabels(periods, rotation=45, fontsize=15)
    ax.set_ylim(0, 50)
    ax.set_ylabel('号码', fontsize=15)
    ax.set_title('号码走势图（最近20期）', fontsize=15, fontweight='bold')
    ax.grid(True, alpha=0.3)

    # 图例
    _get_mpl()
    # Line2D 可以直接从 matplotlib.lines 导入，不需要太复杂
    # 【规范】matplotlib统一由lib.plot_draw导出
    Line2D = get_line2d_class()
    if Line2D is not None:
        legend_elements = [
            Line2D([0], [0], marker='o', color='w', markerfacecolor='#FF0000', markersize=8, label='红球'),
            Line2D([0], [0], marker='o', color='w', markerfacecolor='#0000FF', markersize=8, label='蓝球'),
            Line2D([0], [0], marker='o', color='w', markerfacecolor='#008000', markersize=8, label='绿球'),
            Line2D([0], [0], marker='*', color='w', markerfacecolor='#F39C12', markersize=12, label='特别码'),
        ]
        ax.legend(handles=legend_elements, loc='upper right', fontsize=15)

    host.main_chart_widget.figure.tight_layout()
    host.main_chart_widget.redraw()


def show_correlation_heatmap(host):
    """切换到「相关性热力图」：更新标题并触发绘制

    功能:
        统计 1~49 号两两在同一期出现的共现次数，绘制 49x49 热力图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("correlation_heatmap") 清空并重绘画布。
    """
    host.chart_title_label.setText("相关性热力图")
    host._draw_chart("correlation_heatmap")


def show_interval_analysis(host):
    """切换到「间隔分析图」：更新标题并触发绘制

    功能:
        统计出现次数≥3 的号码相邻出现间隔，取最高频的 15 个号码绘制箱线图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("interval_analysis") 清空并重绘画布。
    """
    host.chart_title_label.setText("间隔分析图")
    host._draw_chart("interval_analysis")


def show_consecutive_probability(host):
    """切换到「连号邻号概率图」：更新标题并触发绘制

    功能:
        逐期统计连号（差 1）、邻号（差 2）与同尾数成对出现次数，换算为
        每期平均出现概率，绘制柱状图。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("consecutive_probability") 清空并重绘画布。
    """
    host.chart_title_label.setText("连号邻号概率图")
    host._draw_chart("consecutive_probability")


def show_sum_distribution(host):
    """切换到「和值分布图」：更新标题并触发绘制

    功能:
        统计每期正码和值，绘制直方图并叠加正态拟合曲线与均值线（数据≥5 期）。

    参数:
        host: 主窗口实例，需已构建图表标题与画布控件。

    返回:
        None。

    副作用:
        - 改写 host.chart_title_label 文本；
        - 调用 host._draw_chart("sum_distribution") 清空并重绘画布。
    """
    host.chart_title_label.setText("和值分布图")
    host._draw_chart("sum_distribution")


class _ChartThemeSync(QObject):
    """监听主窗口 StyleChange（主题/字号重建样式表），回套画布配色并重绘"""

    def __init__(self, host):
        super().__init__(host)
        self._host = host

    def eventFilter(self, obj, event):
        if obj is self._host and event.type() == QEvent.Type.StyleChange:
            QTimer.singleShot(0, self._refresh)
        return False

    def _refresh(self):
        chart = getattr(self._host, 'main_chart_widget', None)
        if chart is not None and getattr(chart, 'canvas', None) is not None:
            chart.redraw()


def install(host):
    """安装「统计分析图表」选项卡：先绑定事件，再构建界面（v0.0.28）

    功能:
        由主窗口创建选项卡时调用；把 14 个图表入口以 lambda 绑定到 host，
        使 build 内的按钮信号与外部菜单都能调用到本模块实现，最后返回页面。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。

    返回:
        QWidget: build(host) 构建完成的页面控件。

    副作用（挂载的 host 属性）:
        - _show_frequency_chart / _show_missing_chart / _show_odd_even_chart /
          _show_size_chart / _show_color_chart / _show_range_chart /
          _show_tail_chart / _show_comprehensive_chart：8 种基础分布图；
        - _draw_chart：按类型字符串统一绘制（供 show_xxx 内部调用）；
        - _show_number_trend_chart：最近 20 期号码走势；
        - _show_correlation_heatmap / _show_interval_analysis /
          _show_consecutive_probability / _show_sum_distribution：4 种进阶分析。

    说明:
        v0.0.28 起页面自包含，主窗口不再保留同名实现（仅 build 内使用回调）。
    """
    host._show_frequency_chart = lambda: show_frequency_chart(host)
    host._show_missing_chart = lambda: show_missing_chart(host)
    host._show_odd_even_chart = lambda: show_odd_even_chart(host)
    host._show_size_chart = lambda: show_size_chart(host)
    host._show_color_chart = lambda: show_color_chart(host)
    host._show_range_chart = lambda: show_range_chart(host)
    host._show_tail_chart = lambda: show_tail_chart(host)
    host._show_comprehensive_chart = lambda: show_comprehensive_chart(host)
    host._draw_chart = lambda chart_type: draw_chart(host, chart_type)
    host._show_number_trend_chart = lambda: show_number_trend_chart(host)
    host._show_correlation_heatmap = lambda: show_correlation_heatmap(host)
    host._show_interval_analysis = lambda: show_interval_analysis(host)
    host._show_consecutive_probability = lambda: show_consecutive_probability(host)
    host._show_sum_distribution = lambda: show_sum_distribution(host)
    return build(host)


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "统计分析图表",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 6,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """构建「统计分析图表」选项卡页面（纯界面，不执行业务逻辑）

    功能:
        创建水平 QSplitter：左侧为标题 + 13 个图表类型按钮（顺序：
        频率/遗漏/单双/大小/颜色/区间/尾数/综合走势/号码走势/相关性热力图/
        间隔分析/连号邻号概率/和值分布），右侧为标题标签 + 可滚动
        StatisticsChart 画布。按钮按列表顺序生成，新增图表追加到 chart_types 末尾。

    参数:
        host: 主窗口实例（LotteryPredictionWindow），控件与状态挂载在此对象上。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用（挂载的 host 属性与绘图生命周期）:
        - host.stats_splitter：水平分隔条，交给 _apply_splitter_sizes 记忆位置；
        - host.chart_title_label：右侧图表标题；
        - host.main_chart_widget：StatisticsChart 实例，构造时调用 _get_mpl()
          懒加载 matplotlib；figure/canvas 在整页存活期间复用，切图只 clear；
          matplotlib 缺失时 figure/canvas 为 None，plot_xxx 内部判空后跳过；
        - 外层布局边距/间距取 host.margin_* 与 host.spacing。

    说明:
        左右拉伸比 1:3，画布放入 QScrollArea 并 setWidgetResizable(True)，
        窗口较小时可滚动查看完整图表。
    """
    widget = QWidget()
    splitter = QSplitter(Qt.Orientation.Horizontal)
    splitter.setHandleWidth(2)
    host.stats_splitter = splitter  # 挂到主窗口，分隔条位置可记忆

    left_panel = QWidget()
    left_layout = QVBoxLayout(left_panel)
    left_layout.setSpacing(10)
    left_layout.setContentsMargins(10, 10, 10, 10)

    title = QLabel("统计分析图表")
    title.setObjectName("PanelTitle")
    left_layout.addWidget(title)

    chart_types = [
        ("频率分布图", host._show_frequency_chart),
        ("遗漏值分析图", host._show_missing_chart),
        ("单双分布图", host._show_odd_even_chart),
        ("大小分布图", host._show_size_chart),
        ("颜色分布图", host._show_color_chart),
        ("区间分布图", host._show_range_chart),
        ("尾数分布图", host._show_tail_chart),
        ("综合走势图", host._show_comprehensive_chart),
        ("号码走势图", host._show_number_trend_chart),
        ("相关性热力图", host._show_correlation_heatmap),
        ("间隔分析图", host._show_interval_analysis),
        ("连号邻号概率", host._show_consecutive_probability),
        ("和值分布图", host._show_sum_distribution),
    ]

    for name, callback in chart_types:
        btn = QPushButton(name)
        # 图表按钮点击信号：连接对应的图表生成回调函数

        btn.clicked.connect(callback)
        left_layout.addWidget(btn)

    left_layout.addStretch()

    splitter.addWidget(left_panel)

    right_panel = QWidget()
    right_layout = QVBoxLayout(right_panel)
    right_layout.setContentsMargins(10, 10, 10, 10)

    host.chart_title_label = QLabel("选择左侧图表类型查看分析结果")
    host.chart_title_label.setObjectName("ChartTitleLabel")
    right_layout.addWidget(host.chart_title_label)

    chart_scroll = QScrollArea()
    chart_scroll.setWidgetResizable(True)

    host.main_chart_widget = StatisticsChart()
    # H54：画布创建后立即按当前主题上色（暗色不再白底），并监听主窗口
    # StyleChange；主题切换时回套配色并重绘已有 Figure，无需重启。
    host.main_chart_widget.apply_theme(bool(getattr(host, 'is_dark_mode', False)))
    if host.main_chart_widget.canvas is not None:
        host.main_chart_widget.canvas.draw()
    host._chart_theme_filter = _ChartThemeSync(host)
    host.installEventFilter(host._chart_theme_filter)
    chart_scroll.setWidget(host.main_chart_widget)

    right_layout.addWidget(chart_scroll, 1)

    splitter.addWidget(right_panel)
    splitter.setStretchFactor(0, 1)
    splitter.setStretchFactor(1, 3)
    host._apply_splitter_sizes(splitter, 'stats_splitter')

    layout = QVBoxLayout(widget)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)
    layout.setSpacing(host.spacing)
    layout.addWidget(splitter)

    return widget
