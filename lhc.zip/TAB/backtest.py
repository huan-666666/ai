# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/backtest.py - 「回测分析」选项卡页面构建模块
===========================================================================
模块职责：
    1. 构建「回测分析」页：算法选择 + 回测期数控制行、结果表格、统计摘要
    2. 实现三种回测交互：单算法回测、全部算法对比（弹窗柱状图）、
       命中率累计趋势（弹窗折线图）
    3. v0.0.28 起页面自包含：实现全部在本模块，install 绑定 3 个回调

回测流程（单算法）：
    host.historical_data --(_analysis_records，DuckDB 优先/失败回退内存)-->
    records（约定“最新在前”）
    -> 对测试期 i（0..n_periods-1）：实际记录 = records[i]；
       训练数据 = records[i+1:]（只用更早的期，避免未来数据泄漏）
    -> PredictionAlgorithms(train_data, _light_mode=True) 构造预测器：
       轻量模式不初始化 TensorFlow/PyTorch，规避 0xC0000409 栈溢出
    -> host._get_prediction_by_index(predictor, algo_index) 取得预测号
       （常规算法 6 个 / 特别码算法 1 个，数量来自算法注册表）
    -> 命中口径由 lib.data_process 按算法编号统一判定：
       常规算法：命中数 = |预测正码 ∩ 当期实际正码|，分母 = 期数 × 6；
       特别码算法：命中数 = 预测特别号是否等于当期实际特别码，
                   分母 = 期数 × 1（“特别码对特别码”）
    -> 结果写入 host._last_backtest_results 与 _last_backtest_algo_index
       （仅内存），再填充表格与摘要；
       「算法对比」「命中趋势」分别用 matplotlib 弹窗绘制柱状图/折线图

依赖：
    - UI：Qt 控件统一从 UI/UI.py 导入（禁止直接 from PyQt6 import ...）
    - lib.algorithms：算法注册表（唯一算法定义来源，下拉框名称与编号遍历均取自此处）
    - lib.math_algo.PredictionAlgorithms（回测预测器）、get_numpy（柱状图配色采样）
    - lib.plot_draw：_get_mpl / get_canvas_class / get_figure_module /
      get_pyplot_module（matplotlib 懒加载后的 QtAgg 图表对象）
    - TAB.widgets.PreserveColorDelegate：表格选中时保留命中数的红/橙/绿前景色

导出对象：
    TAB_INFO（title=回测分析，order=7）
    install(host)：绑定 _on_compare_all_algorithms / _on_show_hit_trend /
                   _on_start_backtest 并构建页面
    build(host)：纯界面构建，返回页面 QWidget

约束：
    - 回测为同步执行，不创建线程/定时器（见 on_start_backtest 的 TODO）
    - 不直接 import numpy/matplotlib，统一经 lib 导出
===========================================================================
"""

import os as _os_boot  # 作用说明：提供路径拼接/存在性判断/绝对路径解析能力，用于向上查找 run.py 所在的项目根目录
import sys as _sys_boot  # 作用说明：提供 sys.path 列表操作能力，把项目根目录插入模块搜索路径，使 UI/lib/TAB 包可直接导入

# 允许「直接运行本文件」调试：向上查找含 run.py 的项目根目录并加入模块搜索路径
_ROOT = _os_boot.path.dirname(_os_boot.path.abspath(__file__))
while not _os_boot.path.exists(_os_boot.path.join(_ROOT, 'run.py')):
    _parent = _os_boot.path.dirname(_ROOT)
    if _parent == _ROOT:
        break
    _ROOT = _parent
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QApplication, QColor, QComboBox, QDialog, QHBoxLayout, QHeaderView, QLabel, QMessageBox, QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget, Qt)  # 作用说明：Qt 控件的唯一导入来源（事件泵、颜色、下拉框/数字框、对话框、布局、表格及表头、标签/按钮、文本项与对齐枚举），禁止直接 from PyQt6 import
from lib.algorithms import ALGORITHM_COUNT, get_algorithm, iter_algorithms  # 作用说明：提供算法注册表访问能力（算法总数、按编号取定义、遍历全部定义），供下拉框填充与逐算法回测
from lib.math_algo import PredictionAlgorithms, get_numpy  # 作用说明：提供回测预测器（_light_mode 轻量构造，避免 TF/PyTorch 初始化）与 numpy 取用入口（柱状图配色采样），不直接导入重型库
from lib.plot_draw import _get_mpl, get_canvas_class, get_figure_module, get_pyplot_module  # 作用说明：提供 matplotlib 懒加载入口与 Figure/Canvas/pyplot 访问器，用于弹窗绘制柱状图、折线图
# 命中数、命中率汇总与累计命中率口径统一由 lib/data_process.py 提供
# （常规算法对照正码/分母 6；特别码算法对照特别码/分母 1，页面不做特判）
from lib.data_process import (compute_hits, summarize_backtest,  # 作用说明：提供统一命中口径计算能力（单期命中数、回测汇总、累计命中率、实际号码参考列），常规与特别码差异在 lib 内处理
                              compute_cumulative_rates, get_backtest_reference)
from TAB.widgets import (PreserveColorDelegate)  # 作用说明：提供表格项代理，使命中数的红/橙/绿前景色在行被选中时仍然保留


# ╔══════════════════════════════════════════════════════════════════╗
# ║  [回测分析：算法对比、命中趋势、单算法回测]
# ╚══════════════════════════════════════════════════════════════════╝

def on_compare_all_algorithms(host):
    """对全部算法执行统一回测，并用弹窗柱状图对比命中率

    功能:
        历史数据不足 30 条时直接提示返回；否则取最近 min(10, 可训练期数)
        期做样本，逐算法回测（训练集为测试期之后更早的数据），计算平均命中
        个数与命中率，按命中率从高到低排序后绘制柱状图（截取算法名前 6 字符
        作 X 轴标签）。单个算法抛异常时跳过该算法，不影响其它算法。

    参数:
        host: 主窗口实例。读取 host.historical_data，调用
            host._analysis_records() 与 host._get_prediction_by_index()，
            使用 host.statusBar() 显示进度。

    返回:
        None。

    副作用:
        - 每个算法开始前更新状态栏并 QApplication.processEvents()，防止同步
          长循环导致窗口假死；
        - 创建并 exec 一个 1000x600 的算法对比对话框；若 matplotlib 不可用，
          弹警告并关闭对话框；
        - 图表 Figure/Canvas 挂在对话框生命周期内，dialog.finished 时调用
          fig.clf() 释放绘图资源，避免内存泄漏；
        - 完成后状态栏提示“算法对比完成”。

    异常:
        每个算法的回测异常被 try/except 吞掉并 continue（不记录原因）；
        matplotlib 对象缺失时提前返回；其余异常未捕获。
    """
    if len(host.historical_data) < 30:
        QMessageBox.warning(host, "数据不足", "算法对比需要至少30条历史数据")
        return

    records = host._analysis_records()[0]
    n_periods = min(10, len(records) - 5)
    host.statusBar().showMessage("正在对" + str(n_periods) + "期数据进行算法对比...")

    # 对每个算法进行回测
    algo_results = []
    total_algo = ALGORITHM_COUNT
    for algo_idx in range(total_algo):
        algo_def = get_algorithm(algo_idx)
        # 每个算法开始前刷新界面，避免长循环期间窗口无响应（假死）
        host.statusBar().showMessage("算法对比中：%d/%d %s" % (
            algo_idx + 1, total_algo, algo_def.name))
        QApplication.processEvents()
        try:
            hits_list = []
            for i in range(n_periods):
                actual_record = records[i]
                train_data = records[i + 1:]

                if len(train_data) < 5:
                    continue

                # 【修复0xC0000409】回测中使用轻量模式，避免TF/PyTorch初始化
                predictor = PredictionAlgorithms(train_data, _light_mode=True)
                predicted = host._get_prediction_by_index(predictor, algo_idx)
                # 口径由 lib 按算法编号自动选择：常规比正码，特别码比特别码
                hits = compute_hits(predicted, actual_record, algo_idx)
                hits_list.append(hits)

            if hits_list:
                # 分母同样由 lib 按算法编号推导（常规 6 / 特别码 1）
                stats = summarize_backtest(hits_list, algo_index=algo_idx)
                avg_hit = stats['avg_hit']
                hit_rate = stats['hit_rate']
                algo_results.append({
                    'name': algo_def.name,
                    'avg_hit': avg_hit,
                    'hit_rate': hit_rate
                })
        except Exception:
            continue

    if not algo_results:
        QMessageBox.warning(host, "对比失败", "无法完成算法对比")
        return

    # 创建对话框显示对比图表
    dialog = QDialog(host)
    dialog.setWindowTitle("算法对比分析")
    dialog.setFixedSize(1000, 600)

    layout = QVBoxLayout(dialog)

    _get_mpl()
    # 【规范】matplotlib对象经lib.plot_draw访问器函数获取，无需global声明
    if get_figure_module() is None or get_canvas_class() is None:
        QMessageBox.warning(host, "错误", "无法加载matplotlib库")
        dialog.close()
        return

    fig = get_figure_module()(figsize=(12, 6))
    canvas = get_canvas_class()(fig)
    ax = fig.add_subplot(111)

    names = [r['name'][:6] for r in algo_results]  # 截取前6个字符
    hit_rates = [r['hit_rate'] for r in algo_results]

    # 按命中率排序
    sorted_data = sorted(zip(names, hit_rates), key=lambda x: x[1], reverse=True)
    names, hit_rates = zip(*sorted_data)

    if get_pyplot_module() is not None:
        # 用 RdYlGn 色带按命中率高低着色（绿=高、红=低），只需 0.3~0.9 区间
        # 以避免最暗/最亮的端点导致柱体与背景对比度不足
        colors = get_pyplot_module().cm.RdYlGn(get_numpy().linspace(0.3, 0.9, len(names)))
    else:
        colors = '#3498db'
    bars = ax.bar(range(len(names)), hit_rates, color=colors, edgecolor='white', linewidth=0.5)

    ax.set_xlabel('算法', fontsize=15)
    ax.set_ylabel('命中率 (%)', fontsize=15)
    ax.set_title('算法命中率对比（回测' + str(n_periods) + '期）', fontsize=15, fontweight='bold')
    ax.set_xticks(range(len(names)))
    ax.set_xticklabels(names, rotation=45, ha='right', fontsize=15)
    ax.grid(axis='y', alpha=0.3)

    # 添加数值标签
    for bar, rate in zip(bars, hit_rates):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2., height, "{:.1f}%".format(rate), ha='center', va='bottom', fontsize=15)

    fig.tight_layout()
    canvas.draw()

    layout.addWidget(canvas)

    close_btn = QPushButton("关闭")
    # 关闭按钮点击信号：关闭当前对话框

    close_btn.clicked.connect(dialog.accept)
    layout.addWidget(close_btn)

    # 【修复资源泄漏bug】对话框关闭时释放matplotlib图表资源
    dialog.finished.connect(lambda: fig.clf())

    dialog.exec()
    host.statusBar().showMessage("算法对比完成")


def on_show_hit_trend(host):
    """用最近一次回测结果绘制累计命中率趋势图（弹窗）

    功能:
        读取 host._last_backtest_results（由 on_start_backtest 写入），按回测
        顺序累加命中数与可用总数（分母按算法口径：常规每期 6、特别码每期 1），
        生成累计命中率曲线；末点用红色虚线水平标出，并在右侧标注最终百分比。

    参数:
        host: 主窗口实例。读取 host._last_backtest_results（list[dict]，
            每项含 period/hits）与 host._last_backtest_algo_index（本次算法
            编号，用于 lib 推导分母）；使用 host 之外的 Qt 对话框。

    返回:
        None。

    副作用:
        - 无回测结果时弹提示并返回；
        - 创建并 exec 900x500 的趋势对话框；matplotlib 不可用时弹警告并关闭；
        - dialog.finished 时调用 fig.clf() 释放绘图资源；
        - X 轴每 3 期显示一个期号标签，Y 轴固定 0~100。

    异常:
        未捕获绘图异常；数据点不足时通过 max(0, ...) / min(..., 95) 修正
        标注坐标，避免文字越出图表边界。
    """
    if not hasattr(host, '_last_backtest_results') or not host._last_backtest_results:
        QMessageBox.information(host, "提示", "请先执行回测，然后查看命中趋势")
        return

    results = host._last_backtest_results

    # 创建对话框显示趋势图
    dialog = QDialog(host)
    dialog.setWindowTitle("命中趋势分析")
    dialog.setFixedSize(900, 500)

    layout = QVBoxLayout(dialog)

    _get_mpl()
    # 【规范】matplotlib对象经lib.plot_draw访问器函数获取，无需global声明
    if get_figure_module() is None or get_canvas_class() is None:
        QMessageBox.warning(host, "错误", "无法加载matplotlib库")
        dialog.close()
        return

    fig = get_figure_module()(figsize=(12, 5))
    canvas = get_canvas_class()(fig)
    ax = fig.add_subplot(111)

    periods = [str(r['period']) for r in results]
    hits = [r['hits'] for r in results]

    # 计算累计命中率：每期分母按算法口径累加（常规 6 / 特别码 1），
    # 算法编号由 on_start_backtest 保存在 host 上，口径仍由 lib 统一实现
    algo_index = getattr(host, '_last_backtest_algo_index', None)
    cumulative_rates = compute_cumulative_rates(hits, algo_index=algo_index)

    x = range(len(results))
    ax.plot(x, cumulative_rates, 'o-', color='#3498DB', markersize=6, linewidth=2)
    # 用红色虚线水平标出最终累计命中率，作为整体水平的参考基准
    ax.axhline(y=cumulative_rates[-1] if cumulative_rates else 0, color='#E74C3C', linestyle='--', linewidth=1.5, alpha=0.7)

    ax.set_xlabel('期数', fontsize=15)
    ax.set_ylabel('累计命中率 (%)', fontsize=15)
    ax.set_title('命中率趋势线（累计）', fontsize=15, fontweight='bold')
    ax.set_xticks(x[::3])
    ax.set_xticklabels([periods[i] for i in range(0, len(periods), 3)], rotation=45)
    ax.grid(True, alpha=0.3)
    ax.set_ylim(0, 100)

    # 添加最终命中率标注
    if cumulative_rates:
        final_rate = cumulative_rates[-1]
        # 【修复负坐标bug】当数据点少于5个时，len(cumulative_rates)-5为负数，
        # 会导致标注文字超出图表左边界，使用max确保x坐标不小于0
        text_x = max(0, len(cumulative_rates) - 5)
        # 同时确保y坐标不超过图表上界(100)
        text_y = min(final_rate + 5, 95)
        ax.annotate('最终: {:.1f}%'.format(final_rate), xy=(len(cumulative_rates)-1, final_rate),
                   xytext=(text_x, text_y),
                   arrowprops=dict(arrowstyle='->', color='gray'),
                   fontsize=15, color='#E74C3C')

    fig.tight_layout()
    canvas.draw()

    layout.addWidget(canvas)

    close_btn = QPushButton("关闭")
    close_btn.clicked.connect(dialog.accept)
    layout.addWidget(close_btn)

    # 【修复资源泄漏bug】对话框关闭时释放matplotlib图表资源
    dialog.finished.connect(lambda: fig.clf())

    dialog.exec()


def on_start_backtest(host):
    """按所选算法与期数执行单算法回测，填充表格与统计摘要

    功能:
        历史数据至少 15 条才允许回测。读取下拉框算法索引与期数输入框，
        期数超过“可训练期数”（len(records)-5）时自动下调并回写 SpinBox；
        对每个测试期用其后更早的数据训练预测器，记录预测号、实际号与命中数。
        完成后把结果写入 host._last_backtest_results，并记录算法编号
        host._last_backtest_algo_index，供「命中趋势」按同一口径计算分母。

    参数:
        host: 主窗口实例。读取 host.historical_data、host.backtest_algo_combo
            （QComboBox）、host.backtest_period_spin（QSpinBox）、
            host.is_dark_mode；写入 host._last_backtest_results、
            host._last_backtest_algo_index、host.backtest_table、
            host.backtest_summary_label。

    返回:
        None。

    副作用:
        - 可能修改 host.backtest_period_spin 的值（期数下调）；
        - 覆盖 host._last_backtest_results 与 host._last_backtest_algo_index
          （仅内存，不写 JSON/INI）；
        - 重建 4 列表格：期号/预测号码/实际号码/命中数（两列号码 zfill(2)
          并以两空格分隔）；命中数按 ≥3 绿、≥1 橙、0 红着色；
          特别码算法的“实际号码”列显示当期特别码（与命中口径一致）；
        - 有结果时写入统计摘要标签（回测期数、总命中、平均命中率、最佳/最差期）；
        - 状态栏提示“回测完成”。

    异常:
        - 单个预测器构造/预测异常被捕获，predicted 置空列表继续统计（该期记 0 命中）；
        - 表格/摘要异常未捕获。

    TODO(待确认): 回测循环在 GUI 线程同步执行，未像 on_compare_all_algorithms
        那样调用 QApplication.processEvents()；期数较多（最大 50）时界面会无响应。
        v0.0.42 已加 _backtest_running 重入保护 + 每 5 期 processEvents + 进度提示，
        但 processEvents 期间仍允许用户操作其它控件；彻底无卡顿需改后台线程。

    """
    # 重入保护：避免 processEvents 期间用户再次点击“开始回测”导致结果错乱
    if getattr(host, '_backtest_running', False):
        return
    host._backtest_running = True

    try:
        if len(host.historical_data) < 15:
            QMessageBox.warning(host, "数据不足", "历史数据不足15条，无法回测")
            return

        records = host._analysis_records()[0]
        algo_index = host.backtest_algo_combo.currentIndex()
        n_periods = host.backtest_period_spin.value()

        if n_periods > len(records) - 5:
            n_periods = len(records) - 5
            host.backtest_period_spin.setValue(n_periods)

        results = []

        for i in range(n_periods):
            actual_record = records[i]

            # 用 i+1 之后的数据预测
            train_data = records[i + 1:]
            if len(train_data) < 5:
                continue

            try:
                # 【修复0xC0000409】回测中使用轻量模式，避免TF/PyTorch初始化
                predictor = PredictionAlgorithms(train_data, _light_mode=True)
                # 使用统一的预测方法
                predicted = host._get_prediction_by_index(predictor, algo_index)
            except Exception:
                predicted = []

            # 口径由 lib 统一选择：常规算法比正码，特别码算法比当期特别码
            hits = compute_hits(predicted, actual_record, algo_index)
            # 表格“实际号码”列与命中口径保持一致（特别码算法只显示当期特别码）
            _reference, actual_display, _per_period = get_backtest_reference(
                actual_record, algo_index)

            results.append({
                'period': actual_record.get('period', '?'),
                'predicted': sorted(predicted),
                'actual': actual_display,
                'hits': hits
            })

            # v0.0.42：每 5 期刷新一次界面并更新进度，避免长回测期间窗口完全无响应
            if (i + 1) % 5 == 0 or i == n_periods - 1:
                host.statusBar().showMessage(f"回测中... {i + 1}/{n_periods}")
                QApplication.processEvents()

        # 保存回测结果以便后续查看趋势
        host._last_backtest_results = results
        # 记录本次算法编号：趋势图据此取得每期分母（常规 6 / 特别码 1）
        host._last_backtest_algo_index = algo_index

        # 填充表格
        # 深色模式下用浅灰蓝 #CDD6F4 作普通文字色，保证在深底上可读；
        # 浅色模式用纯黑 #000000。命中数单独按等级着色，不跟随该默认色
        fg_color = "#CDD6F4" if host.is_dark_mode else "#000000"
        host.backtest_table.setRowCount(len(results))
        for i, r in enumerate(results):
            p_item = QTableWidgetItem(str(r['period']))
            p_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            p_item.setForeground(QColor(fg_color))
            host.backtest_table.setItem(i, 0, p_item)

            pred_str = '  '.join(str(n).zfill(2) for n in r['predicted'])
            pred_item = QTableWidgetItem(pred_str)
            pred_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            pred_item.setForeground(QColor(fg_color))
            host.backtest_table.setItem(i, 1, pred_item)

            act_str = '  '.join(str(n).zfill(2) for n in r['actual'])
            act_item = QTableWidgetItem(act_str)
            act_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            act_item.setForeground(QColor(fg_color))
            host.backtest_table.setItem(i, 2, act_item)

            hit_item = QTableWidgetItem(str(r['hits']))
            hit_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            # 命中数着色规则：≥3 个绿色（表现良好）、≥1 个橙色（部分命中）、
            # 0 个红色（完全未中），便于快速浏览每期结果
            if r['hits'] >= 3:
                hit_item.setForeground(QColor("#2ECC71"))
            elif r['hits'] >= 1:
                hit_item.setForeground(QColor("#F39C12"))
            else:
                hit_item.setForeground(QColor("#E74C3C"))
            host.backtest_table.setItem(i, 3, hit_item)

        # 统计摘要（总命中/命中率/最佳最差期口径由 lib 统一计算）
        if results:
            stats = summarize_backtest([r['hits'] for r in results],
                                       algo_index=algo_index)
            total_hits = stats['total_hits']
            avg_hit = stats['avg_hit']
            best_idx = stats['best_index']
            worst_idx = stats['worst_index']
            hit_rate = stats['hit_rate']

            summary = "回测统计摘要\n"
            summary += "=" * 40 + "\n"
            summary += "回测期数: " + str(stats['periods']) + " 期\n"
            # 分母直接取 lib 返回的 total_possible（常规=期数×6，特别码=期数×1）
            summary += "总命中次数: " + str(total_hits) + " / " + str(stats['total_possible']) + "\n"
            summary += "平均命中率: " + "{:.1f}".format(hit_rate) + "%\n"
            summary += "平均每期命中: " + "{:.2f}".format(avg_hit) + " 个\n"
            summary += "最佳期: 第" + str(results[best_idx]['period']) + "期 命中" + str(results[best_idx]['hits']) + "个\n"
            summary += "最差期: 第" + str(results[worst_idx]['period']) + "期 命中" + str(results[worst_idx]['hits']) + "个"
            host.backtest_summary_label.setText(summary)

        host.statusBar().showMessage("回测完成")
    finally:
        host._backtest_running = False


def install(host):
    """安装「回测分析」选项卡：先绑定事件，再构建界面（v0.0.28）

    功能:
        由主窗口创建选项卡时调用；把 3 个回测入口以 lambda 绑定到 host，
        供 build 内的按钮信号调用，最后返回页面。

    参数:
        host: 主窗口实例（LotteryPredictionWindow）。

    返回:
        QWidget: build(host) 构建完成的页面控件。

    副作用（挂载的 host 属性）:
        - _on_compare_all_algorithms：全部算法对比；
        - _on_show_hit_trend：累计命中率趋势；
        - _on_start_backtest：单算法回测。

    说明:
        v0.0.28 起页面自包含，本页事件实现全部在本模块内；历史数据、预测分发
        （_analysis_records / _get_prediction_by_index）仍由主窗口提供。
    """
    host._on_compare_all_algorithms = lambda: on_compare_all_algorithms(host)
    host._on_show_hit_trend = lambda: on_show_hit_trend(host)
    host._on_start_backtest = lambda: on_start_backtest(host)
    return build(host)


# 选项卡声明：标题与显示顺序（新增页面时复制本段，只改 title / order）
TAB_INFO = {
    "title": "回测分析",  # 选项卡标题（显示在顶部选项卡栏）
    "order": 7,  # 显示顺序，数字小的排前面
    "enabled": True,  # 改为 False 可临时隐藏本页，无需改主窗口
}


def build(host):
    """构建「回测分析」选项卡页面（纯界面，不执行业务逻辑）

    功能:
        按“标题 → 控制行（算法下拉框 + 期数 SpinBox + 开始回测/算法对比/
        命中趋势 三个按钮）→ 回测结果表格 → 统计摘要标签”的顺序创建控件。

    参数:
        host: 主窗口实例（LotteryPredictionWindow），控件与状态挂载在此对象上。

    返回:
        QWidget: 构建完成的选项卡页面控件。

    副作用（挂载的 host 属性）:
        - host.backtest_algo_combo：算法下拉框，选项来自 lib.algorithms 注册表，
          默认第 0 项；currentIndexChanged 连接 lambda 保存 INI；
        - host.backtest_period_spin：回测期数，范围 5~50、默认 10；
          valueChanged 连接 lambda 保存 INI（便于重启保留用户设置）；
        - host.backtest_table：4 列结果表（期号/预测号码/实际号码/命中数），
          Stretch 模式等分列宽，配合 PreserveColorDelegate 保留命中数配色；
        - host.backtest_summary_label：多行统计摘要，开启自动换行。

    说明:
        三个按钮分别连接 install 挂载的 _on_start_backtest /
        _on_compare_all_algorithms / _on_show_hit_trend；
        布局边距取 host.margin_* 与 host.spacing，与其它选项卡保持一致。
    """
    widget = QWidget()
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    layout.setContentsMargins(host.margin_left, host.margin_top, host.margin_right, host.margin_bottom)

    title = QLabel("回测分析")
    title.setObjectName("PanelTitle")
    layout.addWidget(title)

    # ======================================================================== #
    # 功能5：回测结果可视化增强 - 控制面板
    # ======================================================================== #
    ctrl_layout = QHBoxLayout()

    ctrl_layout.addWidget(QLabel("选择算法:"))
    host.backtest_algo_combo = QComboBox()
    for algo_def in iter_algorithms():
        host.backtest_algo_combo.addItem(algo_def.name)
    ctrl_layout.addWidget(host.backtest_algo_combo)

    ctrl_layout.addWidget(QLabel("回测期数:"))
    host.backtest_period_spin = QSpinBox()
    # 范围 5~50：少于 5 期样本无统计意义，超过 50 期同步回测耗时过长；默认 10 期
    host.backtest_period_spin.setRange(5, 50)
    host.backtest_period_spin.setValue(10)
    ctrl_layout.addWidget(host.backtest_period_spin)

    # 连接回测设置改变信号，用于保存记忆
    host.backtest_algo_combo.currentIndexChanged.connect(lambda: host._save_ini_config())
    # 回测期数变化信号：保存回测期数设置到INI配置文件

    host.backtest_period_spin.valueChanged.connect(lambda: host._save_ini_config())

    start_btn = QPushButton("开始回测")
    # 开始回测按钮样式 - 绿色系（"开始"操作用绿色表示"执行/确认"）
    #   QPushButton {       按钮常态样式
    #     background-color: #2ECC71;  背景色：绿色（执行操作主题色）
    #     color: white;               文字颜色：白色
    #     border: none;               边框：无边框（现代扁平风格）
    #     border-radius: 6px;         圆角：6px
    #     padding: 8px 16px;          内边距：上下8px，左右16px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #27AE60;  悬停背景色：深绿（交互反馈）
    #   }
    start_btn.setStyleSheet("QPushButton { background-color: #2ECC71; color: white; border: none; border-radius: 6px; padding: 8px 16px; font-weight: bold; } QPushButton:hover { background-color: #27AE60; }")
    # 开始回测按钮点击信号：启动回测分析

    start_btn.clicked.connect(host._on_start_backtest)
    ctrl_layout.addWidget(start_btn)

    # ======================================================================== #
    # 功能5：新增算法对比和命中趋势按钮
    # ======================================================================== #
    compare_btn = QPushButton("算法对比")
    # 算法对比按钮样式 - 蓝色系（"对比"功能用蓝色表示"数据/比较"）
    #   QPushButton {       按钮常态样式
    #     background-color: #3498DB;  背景色：蓝色（数据对比主题色）
    #     color: white;               文字颜色：白色
    #     border: none;               边框：无边框（现代扁平风格）
    #     border-radius: 6px;         圆角：6px
    #     padding: 8px 16px;          内边距：上下8px，左右16px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #2980B9;  悬停背景色：深蓝（交互反馈）
    #   }
    compare_btn.setStyleSheet("QPushButton { background-color: #3498DB; color: white; border: none; border-radius: 6px; padding: 8px 16px; font-weight: bold; } QPushButton:hover { background-color: #2980B9; }")
    # 对比所有算法按钮点击信号：运行所有算法并对比结果

    compare_btn.clicked.connect(host._on_compare_all_algorithms)
    ctrl_layout.addWidget(compare_btn)

    trend_btn = QPushButton("命中趋势")
    # 命中趋势按钮样式 - 紫色系（"趋势"功能用紫色表示"分析/洞察"）
    #   QPushButton {       按钮常态样式
    #     background-color: #9B59B6;  背景色：紫色（趋势分析主题色）
    #     color: white;               文字颜色：白色
    #     border: none;               边框：无边框（现代扁平风格）
    #     border-radius: 6px;         圆角：6px
    #     padding: 8px 16px;          内边距：上下8px，左右16px
    #     font-weight: bold;          字体：粗体
    #   }
    #   QPushButton:hover {  按钮悬停样式
    #     background-color: #8E44AD;  悬停背景色：深紫（交互反馈）
    #   }
    trend_btn.setStyleSheet("QPushButton { background-color: #9B59B6; color: white; border: none; border-radius: 6px; padding: 8px 16px; font-weight: bold; } QPushButton:hover { background-color: #8E44AD; }")
    # 命中趋势按钮点击信号：显示命中率趋势图表

    trend_btn.clicked.connect(host._on_show_hit_trend)
    ctrl_layout.addWidget(trend_btn)

    ctrl_layout.addStretch()
    layout.addLayout(ctrl_layout)

    # 回测结果表格：4 列，列序与 on_start_backtest 的 setItem 索引一一对应
    host.backtest_table = QTableWidget()
    host.backtest_table.setColumnCount(4)
    host.backtest_table.setHorizontalHeaderLabels(["期号", "预测号码", "实际号码", "命中数"])
    # Stretch：四列等分可用宽度，号码以两空格分隔后仍能完整显示，无需横向滚动
    host.backtest_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    # 保留命中数（绿/橙/红）与号码的前景色，选中行只换浅蓝背景
    host.backtest_table.setItemDelegate(PreserveColorDelegate(host.backtest_table))
    layout.addWidget(host.backtest_table, 1)

    # 统计摘要
    host.backtest_summary_label = QLabel("选择算法和期数后点击「开始回测」")
    host.backtest_summary_label.setWordWrap(True)
    # 回测统计摘要标签样式
    #   padding: 8px;      内边距：8px（多行摘要不贴边）
    #   font-size: 15px;   字体大小：15px（遵循 15px 字号下限）
    host.backtest_summary_label.setStyleSheet("padding: 8px; font-size: 15px;")
    layout.addWidget(host.backtest_summary_label)

    return widget
