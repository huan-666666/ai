# -*- coding: utf-8 -*-
"""
===========================================================================
TAB/number_attributes.py - 「号码属性表」选项卡页面构建模块（三页合并版）
===========================================================================
模块职责：
    1. 把《数字选择》《数字与生肖》《数字与五行》三页合并为一页，正文以已落地的
       属性矩阵（AttributeMatrixPanel，12 列 × 5 排 / 49 卡 + 11 虚线空槽）为核心；
    2. 承载号码点选（左键多选）、生肖整组应用（顶部起始生肖）、五行应用（弹窗）、
       波色改色（弹窗）四类交互；单号改生肖走双击号码卡弹菜单（右键入口保持下线）；
    3. 右栏只保留「五行分布」与「选中详情」两块，底栏为波色图例与已选号码。

依赖：
    - UI/UI.py 统一导出的 Qt 控件（禁止直接 import PyQt6）
    - lib/data_process.LotteryConfig / DataUtils（生肖顺序、默认映射、号码颜色、号码文本解析）
    - TAB/widgets.py（AttributeMatrixPanel / ZodiacHighlightBar / 角控件统一规格）

跨页约定（本页是旧三页的合并替代，必须保持以下接口不断）：
    host.zodiac_panel           属性矩阵面板（同时实现 get/set/select_numbers）
    host.zodiac_highlight_bar   矩阵顶部 12 生肖固定高亮条
    host.number_panel           与 zodiac_panel 指向同一对象（预测页直接调用选中 API）
    host.zodiac_binding         1~49 → 生肖（主窗口持有并落盘）
    host.zodiac_elements        1~49 → 五行（同上）

状态键：
    [Display] attr_panel_* / attr_h_splitter_sizes 为本次合并的新键；
    首次启动由 migrate_state() 从旧 zodiac_panel_* / zodiac_h_splitter_sizes 复制，
    并写 attr_merge_v1=1 防重复迁移；旧键保留只读，便于回滚旧页面。
===========================================================================
"""

import os as _os_boot  # 作用说明：仅用于「直接运行本文件」调试时定位项目根
import sys as _sys_boot  # 作用说明：配合 os 别名把项目根插入模块搜索路径

_ROOT = _os_boot.path.dirname(_os_boot.path.dirname(_os_boot.path.abspath(__file__)))
if _ROOT not in _sys_boot.path:
    _sys_boot.path.insert(0, _ROOT)

from UI import (QColor, QComboBox, QCursor, QDialog, QFont, QHBoxLayout, QLabel,  # 作用说明：统一从 UI/UI.py 取 Qt 控件与枚举，本页不直接 import PyQt6
                QLineEdit, QMenu, QMessageBox, QPainter, QPen, QPushButton, QSpinBox,
                QSplitter, QTextEdit, QVBoxLayout, QWidget, Qt)
from PyQt6.QtGui import QPainterPath  # 作用说明：五行分布自绘需要圆角裁剪路径，UI/UI.py 未导出
from PyQt6.QtCore import QRect, QRectF  # 作用说明：圆角边框与整/浮点矩形，UI/UI.py 未导出
from lib.data_process import DataUtils, LotteryConfig  # 作用说明：生肖/五行默认映射、号码波色与号码文本解析
from TAB.widgets import (AttributeMatrixPanel, CORNER_SECTION_GAP, FontUtils, ZodiacHighlightBar,  # 作用说明：属性矩阵、12 生肖高亮条与 v0.0.36 角控件统一规格
                         _MATRIX_ELEMENT_COLORS, _matrix_blend, add_corner_widget, make_corner_container,
                         make_corner_label, make_corner_size_button, open_panel_size_dialog,
                         spin_style_qss, style_corner_spin)  # 作用说明：五行分布直接复用矩阵的五行色令牌，避免两套色值

TAB_INFO = {
    "title": "号码属性",
    "order": 4,
    "enabled": True,
}

# 五行顺序与配色：与 TAB/element.py 保持同源（合并后五行页停用，这里是唯一展示口径）
ELEMENT_LIST = ["金", "木", "水", "火", "土"]
ELEMENT_COLORS = {
    "金": "#B8860B", "木": "#1E8449", "水": "#1565C0", "火": "#C0392B", "土": "#B9770E",
}

# 出厂波色分组（与 lib/data_process.LotteryConfig 的类属性初始值一致）。
# 只用于「恢复默认」按钮，不参与运行期颜色计算，避免误改全局共享的 NUMBER_COLORS。
FACTORY_RED = [1, 2, 7, 8, 12, 13, 18, 19, 23, 24, 29, 30, 34, 35, 40, 45, 46]
FACTORY_BLUE = [3, 4, 9, 10, 14, 15, 20, 25, 26, 31, 36, 37, 41, 42, 47, 48]
FACTORY_GREEN = [5, 6, 11, 16, 17, 21, 22, 27, 28, 32, 33, 38, 39, 43, 44, 49]

DEFAULT_PANEL_SIZE = {'width': 90, 'height': 98, 'btn_font': 28, 'label_font': 15,
                      'fonts_custom': False}

ATTR_INI_SECTION = 'Display'
ATTR_MERGE_MARKER = 'attr_merge_v1'
# 五行分布（自绘）：右栏默认宽 216（1600 档 282），最小宽 198 只兜住旧 INI 记忆，
# 绝不设置 maximumWidth（那是上一轮分割条拖不动的根因）。
# 窄档：内容宽 206 = 边框 2 + 五行列 70 + 2px 分隔 + 号码列 132（分隔 1px 叠进号码列），
# 等价于 2 + 70 + 1 + 133；宽档：内容宽 272 = 2 + 84 + 1 + 185。
# 整表 5×行高 + 4 条行线 + 2px 边框：窄档 5×58+4+2=296，宽档 5×78+4+2=396。
STATS_MIN_WIDTH = 198
STATS_DEFAULT_W_NARROW = 216  # 1180 档右栏初始宽
STATS_DEFAULT_W_WIDE = 282    # 1600 档右栏初始宽；1180→1600 之间按窗口宽度线性过渡
STATS_WINDOW_NARROW = 1180
STATS_WINDOW_WIDE = 1600
STATS_ELEM_W_NARROW = 70
STATS_ELEM_W_WIDE = 84
STATS_ROW_H_NARROW = 58
STATS_ROW_H_WIDE = 78
STATS_TABLE_H_NARROW = 296  # 5×58 + 4 + 2
STATS_TABLE_H_WIDE = 396    # 5×78 + 4 + 2
STATS_WIDE_MIN_INNER = 256  # 内容宽 ≥ 256 才切宽档；1180 整条拖拽区间（188~256）恒落窄档，1600/1920 默认 270 仍为宽档
STATS_BAR_W = 6
STATS_SEP_W = 2
STATS_TAG_W = 36
STATS_TAG_H = 26
STATS_TAG_FILL_LIGHT = 0.08   # 小签底 = 五行色 8% 混行底色（亮）
STATS_TAG_FILL_DARK = 0.12    # 小签底 = 五行色 12% 混行底色（暗）
STATS_TAG_EDGE = 0.45         # 小签 1px 描边 = 五行色 45% 混行底色
STATS_ELEM_FONT_PX = 20
STATS_ELEM_FONT_PX_WIDE = 21
STATS_NUM_FONT_PX = 16
STATS_SLOT_W = 23   # 16px 下「01 」实测 23px，作为固定格槽
STATS_LINE_H = 21
STATS_WIDE_MAX_PER_ROW = 7
STATS_NARROW_MAX_PER_ROW = 5
STATS_THEMES = {
    False: {'container_bg': '#F5F2FA', 'border': '#DCD6EC', 'grid': '#D8D2E8',
            'row_odd': '#FFFFFF', 'row_even': '#FCFCFE', 'number': '#333333', 'radius': 10},
    True: {'container_bg': '#151B2A', 'border': '#2B3547', 'grid': '#2A3350',
           'row_odd': '#1F2739', 'row_even': '#1A2130', 'number': '#CDD6F4', 'radius': 12},
}


def migrate_state(host):
    """把旧三页的展示类状态键迁移到 attr_* 命名（只改内存，不直接写盘）

    功能:
        1) 面板尺寸：旧 zodiac_panel_width/height/btn_font/label_font → _attr_panel_size；
        2) 控件状态：旧 s_zodiac_num_font_spin / s_zodiac_text_font_spin 等 → s_attr_*；
        3) 选项卡索引：旧 9/10 → 3，旧 11~15 → 减 2（0~8 不变）；
        4) 写入 attr_merge_v1=1 标记，防止下次启动重复迁移。

    参数:
        host: 主窗口实例（需已具备 _ini）。
    返回:
        bool: True=本次执行了迁移；False=已有标记或缺少 INI。
    注意:
        旧键一律保留只读不删，便于把三个旧页面 enabled 改回 True 后仍能恢复原布局；
        本函数不写文件，写盘仍走主窗口 _save_ini_config 的统一闸门。
    """
    ini = getattr(host, '_ini', None)
    if ini is None:
        return False
    try:
        if str(ini.get(ATTR_INI_SECTION, ATTR_MERGE_MARKER, fallback='')).strip() == '1':
            return False
    except Exception:
        return False

    size = getattr(host, '_attr_panel_size', None)
    if not isinstance(size, dict):
        size = dict(DEFAULT_PANEL_SIZE)
        host._attr_panel_size = size
    # 1) 面板尺寸（缺项保留新默认值）
    for old_key, new_key in (('zodiac_panel_width', 'width'),
                             ('zodiac_panel_height', 'height'),
                             ('zodiac_panel_btn_font', 'btn_font'),
                             ('zodiac_panel_label_font', 'label_font')):
        try:
            raw = ini.get(ATTR_INI_SECTION, old_key, fallback='')
            if raw:
                size[new_key] = max(15, int(raw)) if new_key in ('btn_font', 'label_font') else int(raw)
        except (ValueError, TypeError):
            pass

    # 2) 控件状态键（只在目标键缺失时复制，避免覆盖用户在新页里调过的值）
    try:
        if ini.has_section('WidgetState'):
            for old_key, new_key in (('s_zodiac_num_font_spin', 's_attr_num_font_spin'),
                                     ('s_zodiac_text_font_spin', 's_attr_text_font_spin'),
                                     ('s_zodiac_start_combo', 's_attr_start_combo')):
                if not ini.has_option('WidgetState', new_key) and ini.has_option('WidgetState', old_key):
                    ini.set('WidgetState', new_key, ini.get('WidgetState', old_key))
    except Exception:
        pass

    # 3) 选项卡索引映射（页数 16 → 14 后，旧索引必须换算，否则用户会以为页面丢了）
    try:
        idx = int(ini.get(ATTR_INI_SECTION, 'current_tab_index', fallback='-1'))
        if idx >= 11:
            idx -= 2
        elif idx in (9, 10):
            idx = 3
        if idx >= 0 and str(idx) != ini.get(ATTR_INI_SECTION, 'current_tab_index', fallback=''):
            ini.set(ATTR_INI_SECTION, 'current_tab_index', str(idx))
    except (ValueError, TypeError):
        pass

    # 4) 分隔条：旧 3:2 不照搬像素，按比例换算后写入新键（旧键只读保留）
    #    新页面是「矩阵 84% / 右栏 16%」（生肖统计删除后右栏只需容下五行 5 行 + 详情），
    #    因此旧比例 clamp 到 0.75~0.92，避免把旧 60% 直接搬过来导致矩阵被最小值钳制。
    try:
        if not ini.has_option(ATTR_INI_SECTION, 'attr_h_splitter_sizes'):
            old_raw = ini.get(ATTR_INI_SECTION, 'zodiac_h_splitter_sizes', fallback='')
            if old_raw:
                parts = [int(s) for s in old_raw.split(',') if s.strip()]
                if len(parts) == 2 and sum(parts) > 0:
                    ratio = parts[0] / float(sum(parts))
                    ratio = max(0.75, min(0.92, ratio))
                    total = 1152  # 1180 档内容宽：968（矩阵）+ 3（手柄）+ 187（右栏）
                    ini.set(ATTR_INI_SECTION, 'attr_h_splitter_sizes',
                            '%d,%d' % (int(total * ratio), int(total * (1 - ratio))))
    except (ValueError, TypeError):
        pass

    try:
        if not ini.has_section(ATTR_INI_SECTION):
            ini.add_section(ATTR_INI_SECTION)
        ini.set(ATTR_INI_SECTION, ATTR_MERGE_MARKER, '1')
    except Exception:
        pass
    print("号码属性表状态键迁移完成（内存）：面板尺寸 / 控件状态 / 选项卡索引 / 分隔条")
    return True


def load_binding(host):
    """加载生肖/五行绑定（优先 INI，缺失时回退「生肖绑定.json」）

    参数:
        host: 主窗口实例，需具备 zodiac_file，可选 _ini / start_zodiac_combo。
    返回:
        None
    说明:
        与原 zodiac.py 的同名函数行为一致；主窗口启动阶段在页面构建前调用，
        因此只依赖数据属性，不要求任何控件已创建。
    """
    import copy  # 作用说明：深拷贝出厂五行表，避免把类属性引用直接赋给 host 后被原地改动
    ini_loaded = hasattr(host, '_ini') and host._ini.has_section('Zodiac')
    if ini_loaded:
        if hasattr(host, 'start_zodiac_combo') and hasattr(host, '_ini_start_zodiac'):
            host.start_zodiac_combo.setCurrentText(host._ini_start_zodiac)
        return
    host.zodiac_binding = LotteryConfig.generate_zodiac_binding("龙")
    host.zodiac_elements = copy.deepcopy(LotteryConfig.NUMBER_ELEMENTS)
    try:
        if _os_boot.path.exists(host.zodiac_file):
            import json  # 作用说明：仅在回退分支读取绑定备份文件
            with open(host.zodiac_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if 'names' in data:
                    host.zodiac_binding = {int(k): v for k, v in data['names'].items()}
                if 'elements' in data:
                    host.zodiac_elements = {int(k): v for k, v in data['elements'].items()}
                if hasattr(host, 'start_zodiac_combo') and 'start_zodiac' in data:
                    host.start_zodiac_combo.setCurrentText(data['start_zodiac'])
    except Exception as e:
        print("加载生肖绑定失败: " + str(e))


# 页面根控件（主题与数据同步）
class _NumberAttributesPage(QWidget):
    """号码属性表根控件：随主窗口亮/暗主题切换、切回本页时同步数据"""

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self._host = host
        self._last_dark = bool(getattr(host, 'is_dark_mode', False))
        self._theme_inited = False

    def showEvent(self, event):
        super().showEvent(event)
        _sync_theme(self._host, self)
        _sync_data(self._host)
        _sync_selection_label(self._host)

    def changeEvent(self, event):
        from UI import QEvent  # 作用说明：只在事件处理内取枚举，避免顶部导入冗余
        if event.type() == QEvent.Type.StyleChange:
            _sync_theme(self._host, self)
        super().changeEvent(event)


def _sync_data(host):
    """把 host 上的生肖/五行绑定灌入矩阵与高亮条（不写盘）"""
    panel = getattr(host, 'zodiac_panel', None)
    bar = getattr(host, 'zodiac_highlight_bar', None)
    if isinstance(panel, AttributeMatrixPanel):
        panel.set_zodiac_binding(getattr(host, 'zodiac_binding', {}) or {})
        panel.set_elements(getattr(host, 'zodiac_elements', {}) or {})
        active = bar.active_zodiac() if isinstance(bar, ZodiacHighlightBar) else None
        panel.set_highlight_zodiac(active)
    if isinstance(bar, ZodiacHighlightBar):
        bar.refresh_binding(getattr(host, 'zodiac_binding', {}) or {})


def _default_right_width(host):
    """右栏初始宽度：按窗口宽度在 216（≤1180 档）与 282（≥1600 档）之间线性过渡

    只用于构造期/无记忆值时给出初始宽度，不再作为运行期宽度上限：
    上一版在这里对右栏 setMaximumWidth，1180 档上限恰好等于最小宽 187，
    右栏被夹成固定宽，左右分隔条完全拖不动。现在只算初始值，用户拖动得到的
    宽度由 splitterMoved 写入 INI，重启按记忆值恢复，不会被本函数弹回。
    """
    width = int(host.width())
    ratio = (width - STATS_WINDOW_NARROW) / float(STATS_WINDOW_WIDE - STATS_WINDOW_NARROW)
    ratio = max(0.0, min(1.0, ratio))
    return int(round(STATS_DEFAULT_W_NARROW
                     + (STATS_DEFAULT_W_WIDE - STATS_DEFAULT_W_NARROW) * ratio))


# 顶部输入控件（起始生肖下拉、数字/文字字号框）的亮/暗两套样式：
# 这些控件在 build() 里写死了白底 inline 样式，主窗口暗色 QSS 无法覆盖，
# 暗色下会变成「白底空白块」。这里给出暗色专用 QSS，亮色恢复原有 inline 样式。
# 暗色配色与主窗口暗色令牌一致：底 #313244 / 字 #F5F5F5 / 边框 #7F849C /
# 占位符 #A6ADC8 / 箭头 #CDD6F4；实测对比度 字 11.53:1、占位符 5.65:1、
# 边框 3.40:1（均相对输入框底色 #313244）。

INPUT_LIGHT_COMBO_QSS = (
    "QComboBox { background-color: #FFFFFF; color: #9B59B6; border: 2px solid #9B59B6;"
    " border-radius: 5px; padding: 3px 8px; font-weight: bold; font-size: 15px; min-width: 56px; }"
    "QComboBox::drop-down { border: none; width: 20px; }"
    "QComboBox QAbstractItemView { background-color: #FFFFFF; selection-background-color: #9B59B6;"
    " font-size: 15px; }"
)

INPUT_DARK_COMBO_QSS = (
    "QComboBox { background-color: #313244; color: #F5F5F5; border: 1px solid #7F849C;"
    " border-radius: 5px; padding: 3px 8px; font-weight: bold; font-size: 15px; min-width: 56px; }"
    "QComboBox:hover { border-color: #89B4FA; }"
    "QComboBox::drop-down { border: none; width: 20px; }"
    "QComboBox::down-arrow { image: none; width: 0px; height: 0px;"
    " border-left: 4px solid transparent; border-right: 4px solid transparent;"
    " border-top: 6px solid #CDD6F4; }"
    "QComboBox QAbstractItemView { background-color: #313244; color: #F5F5F5;"
    " selection-background-color: #45475A; selection-color: #F5F5F5;"
    " border: 1px solid #7F849C; font-size: 15px; }"
)

def input_dark_spin_qss():
    """暗色输入框 QSS：延迟到运行时生成（QApplication 已存在，箭头可按主题色绘制）"""
    return spin_style_qss(
        "QSpinBox", border_color="#7F849C", bg="#313244", fg="#F5F5F5",
        height=40, font_px=15, arrow_color="#CDD6F4", focus_border="#89B4FA")

# 页面级补充：本页目前没有常驻 QLineEdit，但保留暗色输入样式，
# 供以后在页面内新增文本输入时直接生效（不参与亮色外观）。
PAGE_DARK_LINEEDIT_QSS = (
    "QLineEdit { background-color: #313244; color: #F5F5F5; border: 1px solid #7F849C;"
    " border-radius: 4px; placeholder-text-color: #A6ADC8; }"
)


def _apply_input_theme(host, dark, page=None):
    """切换本页输入控件的亮/暗样式（只改样式，不写盘、不改几何与取值）

    参数:
        host: 主窗口（取 start_zodiac_combo / attr_num_font_spin / attr_text_font_spin）
        dark: True=应用暗色输入样式；False=恢复 build() 时的亮色 inline 样式
        page: 页面根控件；暗色时附加 QLineEdit 规则，亮色时清空该规则
    """
    combo = getattr(host, 'start_zodiac_combo', None)
    if isinstance(combo, QComboBox):
        combo.setStyleSheet(INPUT_DARK_COMBO_QSS if dark else INPUT_LIGHT_COMBO_QSS)
    for attr, light_border in (('attr_num_font_spin', '#90CAF9'),
                               ('attr_text_font_spin', '#CE93D8')):
        spin = getattr(host, attr, None)
        if isinstance(spin, QSpinBox):
            if dark:
                spin.setStyleSheet(input_dark_spin_qss())
            else:
                style_corner_spin(spin, light_border)
    if page is not None:
        page.setStyleSheet(PAGE_DARK_LINEEDIT_QSS if dark else "")


def _sync_theme(host, page):
    """把当前亮/暗主题下发给矩阵、右栏与底栏（只改样式，不写盘）"""
    dark = bool(getattr(host, 'is_dark_mode', False))
    if getattr(page, '_last_dark', None) == dark and getattr(page, '_theme_inited', False):
        return
    page._last_dark = dark
    page._theme_inited = True
    _apply_input_theme(host, dark, page)
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(panel, AttributeMatrixPanel):
        panel.set_dark_mode(dark)
    bar = getattr(host, 'zodiac_highlight_bar', None)
    if isinstance(bar, ZodiacHighlightBar):
        bar.set_dark_mode(dark)

    stats = getattr(host, 'attr_element_table', None)
    if isinstance(stats, ElementDistributionTable):
        stats.set_dark(dark)

    # 右栏两个标题：旧 #2ECC71（白底 2.1:1）/ #555555（暗底 2.2:1）改为主题中性色
    for name in ('attr_element_title', 'attr_detail_title'):
        label = getattr(host, name, None)
        if isinstance(label, QLabel):
            label.setStyleSheet("font-size: 16px; font-weight: bold; color: %s; padding: 2px;"
                                % ('#F5F5F5' if dark else '#333333'))

    detail = getattr(host, 'zodiac_detail_label', None)
    if isinstance(detail, QLabel):
        detail.setStyleSheet(
            "font-size: 15px; color: %s; padding: 8px; background-color: %s; border-radius: 5px;"
            % (('#CDD6F4', '#252535') if dark else ('#555555', '#F8F9FA')))

    legend = getattr(host, 'attr_legend_labels', None)
    if isinstance(legend, dict):
        palette = (panel.get_legend_colors() if isinstance(panel, AttributeMatrixPanel)
                   else {'红': '#FF6B6B', '蓝': '#89B4FA', '绿': '#A6E3A1'})
        for name, label in legend.items():
            if isinstance(label, QLabel):
                label.setStyleSheet("font-size: 15px; font-weight: bold; color: %s;"
                                    % palette.get(name, '#333333'))

    hint = getattr(host, 'attr_hint_label', None)
    if isinstance(hint, QLabel):
        hint.setStyleSheet("font-size: 15px; color: %s;" % ('#A6ADC8' if dark else '#6B6B7A'))
    selected = getattr(host, 'attr_selected_label', None)
    if isinstance(selected, QLabel):
        selected.setStyleSheet("font-size: 15px; color: %s;" % ('#CDD6F4' if dark else '#333333'))


# 右栏：五行分布 + 选中详情
class ElementDistributionTable(QWidget):
    """右栏「五行分布」自绘表：5 行 ×（4px 五行色条 + 五行字 + 号码），无表头、无滚动

    尺寸口径：
        窄档（内容宽 < 256）：五行列 70 + 2px 分隔 + 号码列，行高 58，整表 296，
                              每行最多 5 个号码、最多 2 行；
        宽档（内容宽 ≥ 256）：五行列 84 + 2px 分隔 + 号码列，行高 78，整表 396，
                              每行最多 7 个号码、最多 2 行（切档处号码列 171 ≥ 7×23，留 5px 余量）。
    颜色：
        五行字与色条直接取 TAB/widgets.py 的 _MATRIX_ELEMENT_COLORS（亮/暗两套），
        容器/行底/网格/号码色与属性矩阵主题令牌同源，不再使用旧的 ELEMENT_COLORS。
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._dark = False
        self._groups = {element: [] for element in ELEMENT_LIST}
        family = FontUtils.get_default_font_family()
        self._elem_font = QFont(family)
        self._elem_font.setPixelSize(STATS_ELEM_FONT_PX)
        self._elem_font.setWeight(QFont.Weight.Bold)
        self._num_font = QFont(family)
        self._num_font.setPixelSize(STATS_NUM_FONT_PX)
        self._num_font.setWeight(QFont.Weight.Bold)
        self._sync_height()

    def _is_wide(self):
        """内容宽 ≥ 256 判为宽档（1600/1920 档内容宽 272；1180 档 188~256 恒为窄档）"""
        return self.width() - 2 >= STATS_WIDE_MIN_INNER

    def _metrics(self):
        """按当前宽度算出列宽、行高与每行号码数，绘制与验证共用同一口径"""
        inner_w = max(60, self.width() - 2)
        wide = inner_w >= STATS_WIDE_MIN_INNER
        elem_w = STATS_ELEM_W_WIDE if wide else STATS_ELEM_W_NARROW
        return {
            'elem_w': elem_w,
            'num_w': max(40, inner_w - elem_w - 1),
            'row_h': STATS_ROW_H_WIDE if wide else STATS_ROW_H_NARROW,
            'per_row': STATS_WIDE_MAX_PER_ROW if wide else STATS_NARROW_MAX_PER_ROW,
        }

    def _sync_height(self):
        """整表高度随档位固定，避免布局把表格拉伸成空白区"""
        target = STATS_TABLE_H_WIDE if self._is_wide() else STATS_TABLE_H_NARROW
        if self.minimumHeight() != target or self.maximumHeight() != target:
            self.setFixedHeight(target)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._sync_height()

    def set_dark(self, dark):
        """切换亮/暗档（只重绘，不写盘）"""
        self._dark = bool(dark)
        self.update()

    def set_groups(self, groups):
        """灌入 五行 → 号码列表（号码按升序），并重绘"""
        self._groups = {element: list((groups or {}).get(element, [])) for element in ELEMENT_LIST}
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        self._draw(painter)
        painter.end()

    def _draw(self, painter):
        """自绘主体：五行色条、五行字、号码、网格与外框"""
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        theme = STATS_THEMES[bool(self._dark)]
        metrics = self._metrics()
        width = int(self.width())
        height = int(self.height())
        radius = int(theme['radius'])
        clip = QPainterPath()
        clip.addRoundedRect(QRectF(0.5, 0.5, width - 1.0, height - 1.0), radius, radius)
        painter.setClipPath(clip)
        painter.fillPath(clip, QColor(theme['container_bg']))

        elem_w = int(metrics['elem_w'])
        num_x = 1 + elem_w + 1
        num_w = int(metrics['num_w'])
        row_h = int(metrics['row_h'])
        per_row = int(metrics['per_row'])
        elem_colors = _MATRIX_ELEMENT_COLORS[bool(self._dark)]
        # 字号按档位取：窄档 20 / 宽档 21，均为 Bold
        self._elem_font.setPixelSize(STATS_ELEM_FONT_PX_WIDE if elem_w == STATS_ELEM_W_WIDE
                                     else STATS_ELEM_FONT_PX)

        for index, element in enumerate(ELEMENT_LIST):
            row_y = 1 + index * (row_h + 1)
            row_bg = theme['row_odd'] if index % 2 == 0 else theme['row_even']
            painter.fillRect(QRect(1, row_y, width - 2, row_h), QColor(row_bg))
            color = elem_colors.get(element, theme['number'])
            # 行首 6px 五行色竖条：颜色取五行令牌原值，不做渐变
            painter.fillRect(QRect(1, row_y, STATS_BAR_W, row_h), QColor(color))
            # 五行字外套 36×26 小签：底色是五行色 8%/12% 混行底色，1px 描边 45% 混行底色
            tag_x = 1 + STATS_BAR_W + int((elem_w - STATS_BAR_W - STATS_TAG_W) / 2.0)
            tag_y = row_y + int((row_h - STATS_TAG_H) / 2.0)
            fill_ratio = STATS_TAG_FILL_DARK if self._dark else STATS_TAG_FILL_LIGHT
            painter.setPen(QPen(QColor(_matrix_blend(color, row_bg, STATS_TAG_EDGE)), 1))
            painter.setBrush(QColor(_matrix_blend(color, row_bg, fill_ratio)))
            painter.drawRoundedRect(QRectF(tag_x + 0.5, tag_y + 0.5,
                                           STATS_TAG_W - 1.0, STATS_TAG_H - 1.0), 4, 4)
            painter.setFont(self._elem_font)
            painter.setPen(QColor(color))
            painter.drawText(QRect(tag_x, tag_y, STATS_TAG_W, STATS_TAG_H),
                             Qt.AlignmentFlag.AlignCenter, element)

            numbers = self._groups.get(element, [])
            # 每行固定格槽，最多 2 行；10 个号码窄档 5+5、宽档 7+3，9 个号码 5+4 / 7+2
            lines = [numbers[i:i + per_row] for i in range(0, len(numbers), per_row)][:2]
            if not lines:
                continue
            painter.setFont(self._num_font)
            painter.setPen(QColor(theme['number']))
            block_top = row_y + int((row_h - len(lines) * STATS_LINE_H) / 2.0)
            # 整块在号码列内水平居中；两行共用同一格槽起点，短行不漂移
            start_x = num_x + int((num_w - per_row * STATS_SLOT_W) / 2.0)
            for line_index, line in enumerate(lines):
                line_y = block_top + line_index * STATS_LINE_H
                for slot, number in enumerate(line):
                    painter.drawText(QRect(start_x + slot * STATS_SLOT_W, line_y,
                                           STATS_SLOT_W, STATS_LINE_H),
                                     Qt.AlignmentFlag.AlignCenter, "%02d" % int(number))

        painter.setPen(QPen(QColor(theme['grid']), 1))
        for index in range(1, len(ELEMENT_LIST)):
            grid_y = 1 + index * (row_h + 1) - 1
            painter.drawLine(1, grid_y, width - 2, grid_y)
        # 五行列与号码列之间 2px 中性分隔：从边界起画 2px，其中 1px 叠进号码列
        painter.fillRect(QRect(1 + elem_w, 1, STATS_SEP_W, height - 2),
                         QColor(theme['grid']))

        painter.setClipping(False)
        painter.setPen(QPen(QColor(theme['border']), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(QRectF(0.5, 0.5, width - 1.0, height - 1.0), radius, radius)


def refresh_stats(host):
    """刷新右栏「五行分布」：五行 → 归属号码（只读，不写盘）"""
    table = getattr(host, 'attr_element_table', None)
    if not isinstance(table, ElementDistributionTable):
        return
    groups = {e: [] for e in ELEMENT_LIST}
    for num in range(1, 50):
        element = (getattr(host, 'zodiac_elements', {}) or {}).get(num, '')
        if element in groups:
            groups[element].append(num)

    table.set_dark(bool(getattr(host, 'is_dark_mode', False)))
    table.set_groups(groups)


def update_detail(host, num=None):
    """更新「选中详情」：号码 → 生肖 / 五行 / 波色（不写盘）"""
    label = getattr(host, 'zodiac_detail_label', None)
    if not isinstance(label, QLabel):
        return
    if num is None:
        selected = getattr(host, 'zodiac_panel', None)
        nums = selected.get_selected_numbers() if isinstance(selected, AttributeMatrixPanel) else []
        num = nums[-1] if nums else None
    if num is None:
        label.setText("单击矩阵卡片选号；生肖改绑已下线，可用顶部「起始生肖 + 应用」整组设置")
        return
    num = int(num)
    zodiac = (getattr(host, 'zodiac_binding', {}) or {}).get(num, '')
    element = (getattr(host, 'zodiac_elements', {}) or {}).get(num, '')
    colors = LotteryConfig.get_number_color(num)
    color_name = "红波" if colors['text'] == '#FF0000' else ("蓝波" if colors['text'] == '#0000FF' else "绿波")
    label.setText("%02d ｜ 生肖 %s ｜ 五行 %s ｜ %s" % (num, zodiac or '-', element or '-', color_name))


def _sync_selection_label(host):
    """刷新底栏「已选」文本与详情（选中集合变化时调用）"""
    label = getattr(host, 'attr_selected_label', None)
    panel = getattr(host, 'zodiac_panel', None)
    nums = panel.get_selected_numbers() if isinstance(panel, AttributeMatrixPanel) else []
    if isinstance(label, QLabel):
        text = "  ".join(str(n).zfill(2) for n in nums) if nums else "未选"
        label.setText("已选 " + str(len(nums)) + " 个： " + text)
    update_detail(host)


def _on_selection_changed(host, numbers):
    """矩阵选中集合变化：刷新底栏与详情（不写盘）"""
    _sync_selection_label(host)


# 生肖改绑（双击号码卡弹菜单；右键入口保持下线）
def on_number_double_clicked(host, num):
    """双击号码卡改生肖（在鼠标位置弹出原右键那套生肖菜单）

    说明:
        入口由 build() 把 zodiac_panel.double_clicked 接到本函数；右键仍然无响应，
        number_right_clicked 保持不接线。
        菜单顺序取 LotteryConfig.ZODIAC_CLOCKWISE，与「一键应用」同源；
        末尾追加「恢复默认生肖」，只重置生肖、不动五行。
        弹菜单前矩阵已先保证该号码选中（见 AttributeMatrixPanel._on_card_double_clicked），
        因此菜单弹出失败也不会吞掉选中。
    """
    menu = QMenu(host)
    current = (getattr(host, 'zodiac_binding', {}) or {}).get(num, "")
    header = menu.addAction("%02d 号改生肖" % int(num))
    header.setEnabled(False)
    menu.addSeparator()
    for zodiac in LotteryConfig.ZODIAC_CLOCKWISE:
        action = menu.addAction(("✓ " if zodiac == current else "") + zodiac)
        action.triggered.connect(lambda checked=False, z=zodiac: set_zodiac(host, num, z))
    menu.addSeparator()
    reset_action = menu.addAction("恢复默认生肖")
    reset_action.triggered.connect(lambda: on_reset(host, confirm=True))
    menu.exec(QCursor.pos())


def set_zodiac(host, num, zodiac):
    """把单个号码设为指定生肖，立即全局生效并保存"""
    host.zodiac_binding[int(num)] = zodiac
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(panel, AttributeMatrixPanel):
        panel.update_zodiac(int(num), zodiac)
    bar = getattr(host, 'zodiac_highlight_bar', None)
    if isinstance(bar, ZodiacHighlightBar):
        bar.refresh_binding(host.zodiac_binding)
    refresh_stats(host)
    update_detail(host, int(num))
    LotteryConfig.NUMBER_NAMES.update(host.zodiac_binding)
    host._persist_bindings()


def _commit_binding(host, binding, detail_text):
    """整组替换生肖绑定：刷新矩阵/高亮条/统计/详情并落盘"""
    host.zodiac_binding = dict(binding)
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(panel, AttributeMatrixPanel):
        panel.set_zodiac_binding(host.zodiac_binding)
    bar = getattr(host, 'zodiac_highlight_bar', None)
    if isinstance(bar, ZodiacHighlightBar):
        bar.refresh_binding(host.zodiac_binding)
    LotteryConfig.NUMBER_NAMES.update(host.zodiac_binding)
    refresh_stats(host)
    label = getattr(host, 'zodiac_detail_label', None)
    if isinstance(label, QLabel):
        label.setText(detail_text)
    host._persist_bindings()


def on_apply_start(host):
    """按「起始生肖」一键应用全部生肖绑定"""
    start = host.start_zodiac_combo.currentText() if hasattr(host, 'start_zodiac_combo') else '龙'
    binding = LotteryConfig.generate_zodiac_binding(start)
    _commit_binding(host, binding,
                    "已应用：%s={01,13,25,37,49}，其余按顺时针排列（已自动保存）" % start)


def on_reset(host, confirm=True):
    """恢复默认生肖绑定（龙=01,13,25,37,49），不改动五行"""
    if confirm:
        reply = QMessageBox.question(
            host, "确认",
            "确定恢复默认的生肖绑定吗？\n（仅重置生肖，不会改动五行绑定）",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes:
            return
    if hasattr(host, 'start_zodiac_combo'):
        host.start_zodiac_combo.blockSignals(True)
        host.start_zodiac_combo.setCurrentText("龙")
        host.start_zodiac_combo.blockSignals(False)
    _commit_binding(host, LotteryConfig.generate_zodiac_binding("龙"),
                    "已恢复默认生肖绑定（龙=01,13,25,37,49）")


# 字号与尺寸
def _panel_size(host):
    size = getattr(host, '_attr_panel_size', None)
    if not isinstance(size, dict):
        size = dict(DEFAULT_PANEL_SIZE)
        host._attr_panel_size = size
    return size


def _apply_panel_fonts(host):
    """把 _attr_panel_size 应用到矩阵面板（含档位自动字号上限）

    字号口径：fonts_custom=True（用户改过数字/文字 PX）时严格使用配置值，
    不再被宽档默认 34/17 顶替；False 时才跟随档位默认。卡宽恒按可用宽度
    反算（auto_width），弹窗只控高度。
    """
    panel = getattr(host, 'zodiac_panel', None)
    size = _panel_size(host)
    if isinstance(panel, AttributeMatrixPanel):
        panel.set_font_size(width=None, height=size.get('height', 98),
                            btn_font=size.get('btn_font', 28), label_font=size.get('label_font', 15),
                            custom_fonts=bool(size.get('fonts_custom', False)),
                            auto_width=True)


def on_num_font_changed(host, size):
    """「数字」字号框变化：更新号码字号并保存（几何不动）

    首次改字号前先把面板「当前实际渲染」的另一档字号写回配置，避免只改
    一个时另一个被档位默认值（1600 档 34/17）跳变。
    """
    size_dict = _panel_size(host)
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(panel, AttributeMatrixPanel) and not size_dict.get('fonts_custom'):
        size_dict['btn_font'] = int(getattr(panel, '_num_font', size_dict.get('btn_font', 28)))
        size_dict['label_font'] = int(getattr(panel, '_attr_font', size_dict.get('label_font', 15)))
    size_dict['btn_font'] = max(15, int(size))
    size_dict['fonts_custom'] = True
    _apply_panel_fonts(host)
    _sync_matrix_scale_keys(host, 'num', size_dict['btn_font'])
    host._save_ini_config()


def on_text_font_changed(host, size):
    """「文字」字号框变化：更新五行字号并保存（几何不动）

    同 on_num_font_changed：首个改动发生时以实测渲染值固化另一档，保证
    「数字 PX」与「文字 PX」互不影响。
    """
    size_dict = _panel_size(host)
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(panel, AttributeMatrixPanel) and not size_dict.get('fonts_custom'):
        size_dict['btn_font'] = int(getattr(panel, '_num_font', size_dict.get('btn_font', 28)))
        size_dict['label_font'] = int(getattr(panel, '_attr_font', size_dict.get('label_font', 15)))
    size_dict['label_font'] = max(15, int(size))
    size_dict['fonts_custom'] = True
    _apply_panel_fonts(host)
    _sync_matrix_scale_keys(host, 'text', size_dict['label_font'])
    host._save_ini_config()


def show_panel_settings_dialog(host):
    """「尺寸」按钮：打开面板尺寸弹窗（复用 widgets.open_panel_size_dialog）

    卡宽由可用宽度反算（12 列共轴），弹窗中宽度为只读「自动」；高度可调。
    """
    current = _panel_size(host)
    panel = getattr(host, 'zodiac_panel', None)
    metrics = getattr(panel, '_metrics', {}) or {}
    display = {'width': int(metrics.get('card_w', current.get('width', 90)) or 90),
               'height': current.get('height', 98)}

    def _apply(values):
        # 宽度不写回：它只是反算结果，写死会变成 resize 后的上限
        current['height'] = values['height']
        _apply_panel_fonts(host)
        for attr, value in (('attr_num_font_spin', current.get('btn_font', 28)),
                            ('attr_text_font_spin', current.get('label_font', 15))):
            spin = getattr(host, attr, None)
            if spin is not None:
                spin.blockSignals(True)
                spin.setValue(int(value))
                spin.blockSignals(False)

    open_panel_size_dialog(host, "号码属性面板尺寸", display, _apply, auto_width=True)


def _sync_font_spins(host, profile, num_px, attr_px):
    """档位自动字号（28/15、34/17）同步到两个角控件（阻塞信号，不反写配置）"""
    for attr, value in (('attr_num_font_spin', num_px), ('attr_text_font_spin', attr_px)):
        spin = getattr(host, attr, None)
        if spin is not None and int(spin.value()) != int(value):
            spin.blockSignals(True)
            spin.setValue(int(value))
            spin.blockSignals(False)


def _sync_matrix_scale_keys(host, dimension, px):
    """PX 权威：把 8 个缩放键中该维度的 4 个区域键同步为 px 对应的比例

    参数:
        host: 主窗口实例（需具备 _area_font_scales）。
        dimension (str): 'num' 或 'text'，决定同步哪 4 个键。
        px (int): 当前生效字号（像素），由 PX 框写入。

    说明:
        四区域（数字/生肖/五行/属性）在合并版里共用同一块矩阵面板，同一维度
        只能有一个真实字号；因此四个区域键必须同值，否则之后按 A± 会按
        硬编码基准 28/15 重算，出现「PX 40 → A+ 变 30」的跳变。
        比例被 0.5~2.0 的既有范围钳制；只改内存，落盘由调用方负责。
    """
    scales = getattr(host, '_area_font_scales', None)
    if not isinstance(scales, dict):
        return
    base = 28.0 if dimension == 'num' else 15.0
    scale = max(0.5, min(2.0, float(px) / base))
    for area in ('number_panel', 'zodiac_panel', 'element_panel', 'attr_panel'):
        scales[area + '_' + dimension] = round(scale, 3)
    refresh = getattr(host, '_refresh_drawer_area_labels', None)
    if callable(refresh):
        refresh()


# 颜色设置（波色）
def apply_custom_number_colors(host):
    """把 LotteryConfig.NUMBER_COLORS 应用到矩阵与跨页控件（不写盘）"""
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(panel, AttributeMatrixPanel):
        panel.refresh_number_colors(LotteryConfig.NUMBER_COLORS)
    # 预测结果号码球与历史表格共用同一份颜色，延迟导入避免页面间循环依赖
    if hasattr(host, 'prediction_number_layout'):
        try:
            from TAB import prediction as _tab_prediction
            _tab_prediction.apply_prediction_ball_size(host)
        except Exception:
            pass
    if hasattr(host, 'history_table'):
        try:
            from TAB import history as _tab_history
            _tab_history.update_history_table(host)
        except Exception:
            pass


def _apply_color_groups(host, red, blue, green, status_label):
    """校验三组波色号码并全局应用（未填写号码按原色归组，保证 1~49 全覆盖）"""
    overlaps = (set(red) & set(blue)) | (set(red) & set(green)) | (set(blue) & set(green))
    if overlaps:
        status_label.setText("号码重复：" + ' '.join(str(n).zfill(2) for n in sorted(overlaps)) + "，请去掉后再应用")
        status_label.setStyleSheet("font-size: 15px; color: #E74C3C; font-weight: bold;")
        return
    for num in range(1, 50):
        if num in red or num in blue or num in green:
            continue
        text_color = LotteryConfig.get_number_color(num).get('text', '#008000')
        if text_color.upper() == '#FF0000':
            red.append(num)
        elif text_color.upper() == '#0000FF':
            blue.append(num)
        else:
            green.append(num)

    LotteryConfig.RED_NUMBERS = sorted(set(red))
    LotteryConfig.BLUE_NUMBERS = sorted(set(blue))
    LotteryConfig.GREEN_NUMBERS = sorted(set(green))
    colors = {}
    for group, (text, border) in (("RED", ('#FF0000', '#FF0000')), ("BLUE", ('#0000FF', '#0000FF')),
                                  ("GREEN", ('#008000', '#008000'))):
        for num in getattr(LotteryConfig, group + '_NUMBERS'):
            colors[num] = {"bg": "#FFFFFF", "text": text, "border": border}
    LotteryConfig.NUMBER_COLORS = colors

    apply_custom_number_colors(host)
    host._save_custom_number_colors()
    _refresh_legend(host)
    status_label.setText("已应用并保存：红 " + str(len(LotteryConfig.RED_NUMBERS)) + " 个 / 蓝 "
                         + str(len(LotteryConfig.BLUE_NUMBERS)) + " 个 / 绿 "
                         + str(len(LotteryConfig.GREEN_NUMBERS)) + " 个")
    status_label.setStyleSheet("font-size: 15px; color: #2ECC71; font-weight: bold;")


def _refresh_legend(host):
    """刷新底栏三色图例里的号码数量文本"""
    labels = getattr(host, 'attr_legend_labels', None)
    if not isinstance(labels, dict):
        return
    for name, group in (("红", LotteryConfig.RED_NUMBERS), ("蓝", LotteryConfig.BLUE_NUMBERS),
                        ("绿", LotteryConfig.GREEN_NUMBERS)):
        label = labels.get(name)
        if isinstance(label, QLabel):
            label.setText(name + "波 " + str(len(group)) + " 个")


def _numbers_text(numbers):
    return ' '.join(str(n).zfill(2) for n in numbers)


def _parse_numbers(text):
    """解析号码文本（兼容逗号/顿号/空格等分隔符），只取 1~49 且去重"""
    try:
        return sorted(set(DataUtils.parse_numbers_text(text, dedupe=True, limit_range=True)))
    except Exception:
        return []


def _open_color_dialog(host):
    """「颜色设置」弹窗：三组号码 + 应用 / 恢复默认 / 原始数据"""
    dialog = QDialog(host)
    dialog.setWindowTitle("颜色设置")
    dialog.setMinimumWidth(520)
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(16, 12, 16, 12)
    layout.setSpacing(8)

    edits = {}
    for key, title, color in (("red", "红波号码:", "#E74C3C"), ("blue", "蓝波号码:", "#1565C0"),
                              ("green", "绿波号码:", "#1E8449")):
        row = QHBoxLayout()
        label = QLabel(title)
        label.setFixedWidth(80)
        label.setStyleSheet("font-size: 15px; font-weight: bold; color: %s;" % color)
        edit = QLineEdit()
        # 颜色设置弹窗是独立 QDialog：暗色下显式补底/字/边框，避免主窗口 QSS 未覆盖到弹窗
        edit.setStyleSheet(
            "font-size: 15px; padding: 4px;"
            + (" background-color: #313244; color: #F5F5F5; border: 1px solid #7F849C;"
               " placeholder-text-color: #A6ADC8;" if getattr(host, 'is_dark_mode', False) else ""))
        edits[key] = edit
        row.addWidget(label)
        row.addWidget(edit, 1)
        layout.addLayout(row)

    status = QLabel("号码用空格/逗号/顿号分隔；未填写的号码保持原波色")
    status.setStyleSheet("font-size: 15px; color: #888888;")
    status.setWordWrap(True)
    layout.addWidget(status)

    buttons = QHBoxLayout()
    apply_btn = QPushButton("应用")
    reset_btn = QPushButton("恢复默认")
    origin_btn = QPushButton("原始数据")
    close_btn = QPushButton("关闭")
    for btn in (apply_btn, reset_btn, origin_btn, close_btn):
        btn.setFixedHeight(32)
        btn.setStyleSheet("font-size: 15px; padding: 2px 14px;")
        buttons.addWidget(btn)
    buttons.addStretch(1)
    layout.addLayout(buttons)

    def _fill(red, blue, green, message):
        edits['red'].setText(_numbers_text(red))
        edits['blue'].setText(_numbers_text(blue))
        edits['green'].setText(_numbers_text(green))
        status.setText(message)
        status.setStyleSheet("font-size: 15px; color: #888888;")

    _fill(LotteryConfig.RED_NUMBERS, LotteryConfig.BLUE_NUMBERS, LotteryConfig.GREEN_NUMBERS,
          "已载入当前生效的三组号码，修改后点「应用」")
    apply_btn.clicked.connect(lambda: _apply_color_groups(
        host, _parse_numbers(edits['red'].text()), _parse_numbers(edits['blue'].text()),
        _parse_numbers(edits['green'].text()), status))
    reset_btn.clicked.connect(lambda: _fill(FACTORY_RED, FACTORY_BLUE, FACTORY_GREEN,
                                           "已填入出厂分组，点「应用」才会生效"))
    origin_btn.clicked.connect(lambda: _fill(
        LotteryConfig.RED_NUMBERS, LotteryConfig.BLUE_NUMBERS, LotteryConfig.GREEN_NUMBERS,
        "已恢复为当前生效的分组"))
    close_btn.clicked.connect(dialog.accept)
    dialog.exec()


# 五行应用（弹窗）
def _apply_elements(host, element, numbers, status_label):
    """把指定号码的五行设为 element，刷新矩阵/右栏并保存"""
    if not numbers:
        status_label.setText("请先填写号码（1~49，空格/逗号分隔）")
        status_label.setStyleSheet("font-size: 15px; color: #E74C3C; font-weight: bold;")
        return
    for num in numbers:
        if 1 <= num <= 49:
            host.zodiac_elements[num] = element
    panel = getattr(host, 'zodiac_panel', None)
    if isinstance(panel, AttributeMatrixPanel):
        panel.set_elements(host.zodiac_elements)
    refresh_stats(host)
    update_detail(host)
    try:
        LotteryConfig.NUMBER_ELEMENTS.update(host.zodiac_elements)
    except Exception:
        pass
    host._persist_bindings()
    status_label.setText("已应用：" + element + " ← " + _numbers_text(numbers) + "（已自动保存）")
    status_label.setStyleSheet("font-size: 15px; color: #2ECC71; font-weight: bold;")


def _open_element_dialog(host):
    """「五行应用」弹窗：五行分组条 + 号码粘贴框 + 应用 / 恢复默认 / 原始数据"""
    dialog = QDialog(host)
    dialog.setWindowTitle("五行应用")
    dialog.setMinimumWidth(560)
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(16, 12, 16, 12)
    layout.setSpacing(8)

    group_row = QHBoxLayout()
    group_row.setSpacing(6)
    group_label = QLabel("五行:")
    group_label.setFixedWidth(52)
    group_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555;")
    group_row.addWidget(group_label)
    group_buttons = {}
    for element in ELEMENT_LIST:
        btn = QPushButton(element)
        btn.setCheckable(True)
        btn.setFixedSize(64, 32)
        btn.setStyleSheet(
            "QPushButton { font-size: 15px; font-weight: bold; color: %s; background: #FFFFFF;"
            " border: 2px solid %s; border-radius: 5px; }"
            "QPushButton:checked { background: %s; color: #FFFFFF; }"
            % (ELEMENT_COLORS[element], ELEMENT_COLORS[element], ELEMENT_COLORS[element]))
        group_buttons[element] = btn
        group_row.addWidget(btn)
    group_row.addStretch(1)
    layout.addLayout(group_row)

    paste = QTextEdit()
    paste.setFixedHeight(96)
    paste.setStyleSheet("font-size: 15px; padding: 4px;")
    paste.setPlaceholderText("输入号码，如：01 06 11 16 21 26 31 36 41 46")
    layout.addWidget(paste)

    status = QLabel("先选五行，再填号码，点「应用」；未列出的号码保持原五行")
    status.setStyleSheet("font-size: 15px; color: #888888;")
    status.setWordWrap(True)
    layout.addWidget(status)

    buttons = QHBoxLayout()
    apply_btn = QPushButton("应用")
    reset_btn = QPushButton("恢复默认")
    origin_btn = QPushButton("原始数据")
    close_btn = QPushButton("关闭")
    for btn in (apply_btn, reset_btn, origin_btn, close_btn):
        btn.setFixedHeight(32)
        btn.setStyleSheet("font-size: 15px; padding: 2px 14px;")
        buttons.addWidget(btn)
    buttons.addStretch(1)
    layout.addLayout(buttons)

    def _current_element():
        for element, btn in group_buttons.items():
            if btn.isChecked():
                return element
        return None

    def _select(element):
        for name, btn in group_buttons.items():
            btn.setChecked(name == element)

    def _fill_for(element):
        if element is None:
            return []
        return [num for num in range(1, 50)
                if (getattr(host, 'zodiac_elements', {}) or {}).get(num) == element]

    def _on_group_clicked(element):
        """点分组：切换选中，并把该组当前号码载入粘贴框"""
        _select(element)
        paste.setPlainText(_numbers_text(_fill_for(element)))
        status.setText("已载入「" + element + "」当前号码，可增删后点「应用」")
        status.setStyleSheet("font-size: 15px; color: #888888;")

    for element, btn in group_buttons.items():
        btn.clicked.connect(lambda checked=False, e=element: _on_group_clicked(e))

    _select("金")
    paste.setPlainText(_numbers_text(_fill_for("金")))

    apply_btn.clicked.connect(lambda: _apply_elements(
        host, _current_element(), _parse_numbers(paste.toPlainText()), status))
    reset_btn.clicked.connect(lambda: _fill_defaults())
    origin_btn.clicked.connect(lambda: _fill_origin())
    close_btn.clicked.connect(dialog.accept)

    def _fill_defaults():
        element = _current_element()
        if element is None:
            status.setText("请先选择五行")
            return
        defaults = [num for num, value in (LotteryConfig.DEFAULT_NUMBER_ELEMENTS or {}).items()
                    if value == element]
        paste.setPlainText(_numbers_text(defaults))
        status.setText("已载入出厂「" + element + "」分组，点「应用」才会生效")
        status.setStyleSheet("font-size: 15px; color: #888888;")

    def _fill_origin():
        element = _current_element()
        if element is None:
            status.setText("请先选择五行")
            return
        paste.setPlainText(_numbers_text(_fill_for(element)))
        status.setText("已恢复为当前生效的「" + element + "」号码")
        status.setStyleSheet("font-size: 15px; color: #888888;")

    dialog.exec()


# 页面构建
def _build_font_controls(host, layout):
    """右上角「数字 px / 文字 px / 尺寸」控件组（v0.0.36 统一规格）"""
    box, box_layout = make_corner_container()
    add_corner_widget(box_layout, make_corner_label("数字:", "#1565C0"))
    host.attr_num_font_spin = QSpinBox()
    host.attr_num_font_spin.setObjectName('attr_num_font_spin')
    host.attr_num_font_spin.setRange(15, 150)
    host.attr_num_font_spin.setSingleStep(1)
    host.attr_num_font_spin.setButtonSymbols(QSpinBox.ButtonSymbols.UpDownArrows)
    host.attr_num_font_spin.setValue(_panel_size(host).get('btn_font', 28))
    host.attr_num_font_spin.setSuffix(" px")
    host.attr_num_font_spin.setToolTip("调整属性矩阵卡片号码字体大小（独立控制，不影响五行字号）")
    style_corner_spin(host.attr_num_font_spin, "#90CAF9")
    host.attr_num_font_spin.valueChanged.connect(lambda value: on_num_font_changed(host, value))
    add_corner_widget(box_layout, host.attr_num_font_spin)

    box_layout.addSpacing(CORNER_SECTION_GAP)

    add_corner_widget(box_layout, make_corner_label("文字:", "#7B1FA2"))
    host.attr_text_font_spin = QSpinBox()
    host.attr_text_font_spin.setObjectName('attr_text_font_spin')
    host.attr_text_font_spin.setRange(15, 150)
    host.attr_text_font_spin.setSingleStep(1)
    host.attr_text_font_spin.setButtonSymbols(QSpinBox.ButtonSymbols.UpDownArrows)
    host.attr_text_font_spin.setValue(_panel_size(host).get('label_font', 15))
    host.attr_text_font_spin.setSuffix(" px")
    host.attr_text_font_spin.setToolTip("调整属性矩阵五行文字大小（独立控制，不影响号码）")
    style_corner_spin(host.attr_text_font_spin, "#CE93D8")
    host.attr_text_font_spin.valueChanged.connect(lambda value: on_text_font_changed(host, value))
    add_corner_widget(box_layout, host.attr_text_font_spin)

    add_corner_widget(box_layout, make_corner_size_button(
        lambda: show_panel_settings_dialog(host), "调整属性矩阵面板尺寸"))
    layout.addWidget(box)


def _build_right_column(host, splitter):
    """右栏：五行分布（自绘 5 行，窄档 1180/宽档 1600 自动换档）+ 选中详情"""
    right = QWidget()
    right.setMinimumWidth(STATS_MIN_WIDTH)
    host.attr_right_column = right
    right_layout = QVBoxLayout(right)
    right_layout.setContentsMargins(5, 5, 5, 5)
    right_layout.setSpacing(6)

    title = QLabel("五行分布")
    title.setStyleSheet("font-size: 16px; font-weight: bold; color: #333333; padding: 2px;")
    host.attr_element_title = title
    right_layout.addWidget(title)

    # 自绘表：无表头、无内部滚动，高度按档位固定（296 / 366），不再用 addWidget 拉伸
    host.attr_element_table = ElementDistributionTable()
    right_layout.addWidget(host.attr_element_table)

    detail_title = QLabel("选中详情")
    detail_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #333333; padding: 2px;")
    host.attr_detail_title = detail_title
    right_layout.addWidget(detail_title)

    host.zodiac_detail_label = QLabel("单击矩阵卡片选号；生肖改绑已下线，可用顶部「起始生肖 + 应用」整组设置")
    host.zodiac_detail_label.setWordWrap(True)
    host.zodiac_detail_label.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
    host.zodiac_detail_label.setMinimumHeight(64)
    right_layout.addWidget(host.zodiac_detail_label)
    # 余量全部落到栏底，详情块保持原有位置与内容，不被拉伸或挤占
    right_layout.addStretch(1)

    splitter.addWidget(right)
    return right


def _build_bottom_bar(host, layout):
    """底栏：波色图例 + 已选号码 + 清空"""
    bar = QHBoxLayout()
    bar.setSpacing(10)
    host.attr_legend_labels = {}
    for name in ("红", "蓝", "绿"):
        label = QLabel()
        host.attr_legend_labels[name] = label
        bar.addWidget(label)
    separator = QLabel("|")
    separator.setStyleSheet("color: #CCCCCC; font-size: 16px;")
    bar.addWidget(separator)
    host.attr_selected_label = QLabel("已选 0 个： 未选")
    bar.addWidget(host.attr_selected_label, 1)
    clear_btn = QPushButton("清空选中")
    clear_btn.setFixedHeight(26)
    clear_btn.setStyleSheet("font-size: 15px; padding: 1px 10px;")
    clear_btn.clicked.connect(lambda: host.zodiac_panel.clear_selection())
    bar.addWidget(clear_btn)
    host.attr_hint_label = QLabel("左键选号 ｜ 生肖按顶部起始生肖整组应用")
    bar.addWidget(host.attr_hint_label)
    _refresh_legend(host)
    layout.addLayout(bar)


def build(host):
    """构建「号码属性表」页面并挂到 host

    参数:
        host: 主窗口实例（需已具备 spacing / margin_* / _attr_panel_size /
              zodiac_binding / zodiac_elements）。
    返回:
        QWidget: 页面根控件。
    副作用:
        在 host 上创建 attr_h_splitter / zodiac_panel / zodiac_highlight_bar /
        number_panel / attr_element_table / zodiac_detail_label / attr_* 角控件；
        恢复分隔条记忆尺寸；初始化右栏统计与选中提示。
    """
    widget = _NumberAttributesPage(host)
    layout = QVBoxLayout(widget)
    layout.setSpacing(host.spacing)
    # 本页左右外边距各收 4px（只影响本页，不回写 host/INI）：给 1180 档分割条多 8px 行程
    _page_ml = max(0, int(host.margin_left) - 4)
    _page_mr = max(0, int(host.margin_right) - 4)
    layout.setContentsMargins(_page_ml, host.margin_top, _page_mr, host.margin_bottom)

    # 顶部工具条：标题 + 起始生肖 + 一键应用 + 颜色设置 + 五行应用 + 角控件组
    top = QHBoxLayout()
    top.setSpacing(8)
    title = QLabel("号码属性")
    title.setObjectName("PanelTitle")
    top.addWidget(title)
    top.addStretch(1)

    for _ in range(1):
        sep = QLabel("|")
        sep.setStyleSheet("color: #CCCCCC; font-size: 16px;")
        top.addWidget(sep)

    start_label = QLabel("起始生肖:")
    start_label.setStyleSheet("font-size: 15px; font-weight: bold; color: #555555;")
    top.addWidget(start_label)

    host.start_zodiac_combo = QComboBox()
    host.start_zodiac_combo.setObjectName('attr_start_combo')
    host.start_zodiac_combo.addItems(LotteryConfig.ZODIAC_CLOCKWISE)
    host.start_zodiac_combo.setCurrentText(getattr(host, '_ini_start_zodiac', '龙') or '龙')
    # 亮色样式集中为常量，_apply_input_theme 切回亮色时复用同一份
    host.start_zodiac_combo.setStyleSheet(INPUT_LIGHT_COMBO_QSS)
    host.start_zodiac_combo.currentTextChanged.connect(lambda text: host._save_ini_config())
    top.addWidget(host.start_zodiac_combo)

    apply_btn = QPushButton("应用")
    apply_btn.setFixedHeight(30)
    apply_btn.setStyleSheet(
        "QPushButton { background-color: #FFFFFF; color: #3498DB; border: 2px solid #3498DB;"
        " border-radius: 5px; font-weight: bold; font-size: 15px; padding: 2px 10px; }"
        "QPushButton:hover { background-color: #3498DB; color: #FFFFFF; }")
    apply_btn.clicked.connect(lambda: on_apply_start(host))
    top.addWidget(apply_btn)

    sep2 = QLabel("|")
    sep2.setStyleSheet("color: #CCCCCC; font-size: 16px;")
    top.addWidget(sep2)

    color_btn = QPushButton("颜色设置")
    color_btn.setFixedHeight(30)
    color_btn.setStyleSheet(
        "QPushButton { background-color: #FFFFFF; color: #E74C3C; border: 2px solid #E74C3C;"
        " border-radius: 5px; font-weight: bold; font-size: 15px; padding: 2px 10px; }"
        "QPushButton:hover { background-color: #E74C3C; color: #FFFFFF; }")
    color_btn.clicked.connect(lambda: _open_color_dialog(host))
    top.addWidget(color_btn)

    sep3 = QLabel("|")
    sep3.setStyleSheet("color: #CCCCCC; font-size: 16px;")
    top.addWidget(sep3)

    element_btn = QPushButton("五行应用")
    element_btn.setFixedHeight(30)
    element_btn.setStyleSheet(
        "QPushButton { background-color: #FFFFFF; color: #D68910; border: 2px solid #D68910;"
        " border-radius: 5px; font-weight: bold; font-size: 15px; padding: 2px 10px; }"
        "QPushButton:hover { background-color: #D68910; color: #FFFFFF; }")
    element_btn.clicked.connect(lambda: _open_element_dialog(host))
    top.addWidget(element_btn)

    top.addSpacing(12)
    _build_font_controls(host, top)
    top.setStretch(1, 0)
    layout.addLayout(top)

    # 内容区：矩阵 84% / 右栏 16%（生肖统计删除后右栏只需容下五行 5 行 + 详情，
    # 腾出的宽度全部给矩阵；1180 档默认 968:187，矩阵面板 958 仍走 compact 档）。
    # 右栏只设最小宽 187、不设最大宽，分隔条可自由拖动；初始宽度按窗口计算。
    host.attr_h_splitter = QSplitter(Qt.Orientation.Horizontal)
    host.attr_h_splitter.setHandleWidth(6)
    host.attr_h_splitter.setChildrenCollapsible(False)

    left = QWidget()
    left_layout = QVBoxLayout(left)
    left_layout.setContentsMargins(5, 5, 5, 5)
    left_layout.setSpacing(6)

    host.zodiac_panel = AttributeMatrixPanel(
        zodiac_binding=host.zodiac_binding,
        elements=host.zodiac_elements,
        start_zodiac=(host.start_zodiac_combo.currentText()
                      if hasattr(host, 'start_zodiac_combo') else '龙'),
        dark_mode=bool(getattr(host, 'is_dark_mode', False)))
    _apply_panel_fonts(host)
    host.zodiac_highlight_bar = host.zodiac_panel.highlight_bar
    host.zodiac_panel.selection_changed.connect(
        lambda nums: _on_selection_changed(host, nums))
    # 单号改生肖走双击号码卡：在鼠标位置弹出原右键菜单（右键仍然无响应，
    # number_right_clicked 保持不接线）。
    host.zodiac_panel.double_clicked.connect(
        lambda num: on_number_double_clicked(host, num))
    host.zodiac_panel.profile_fonts_changed.connect(
        lambda profile, num_px, attr_px: _sync_font_spins(host, profile, num_px, attr_px))
    # 跨页 API：预测页与主窗口直接使用 host.number_panel 的选中三方法
    host.number_panel = host.zodiac_panel

    left_layout.addWidget(host.zodiac_panel, 1)
    left.setMinimumWidth(host.zodiac_panel.sizeHint().width() + 12)
    host.attr_h_splitter.addWidget(left)

    _build_right_column(host, host.attr_h_splitter)
    host.attr_h_splitter.setStretchFactor(0, 84)
    host.attr_h_splitter.setStretchFactor(1, 16)
    # 无记忆值时按当前窗口宽度给初始宽度：1180→右栏 187，1600→右栏 255；
    # 有记忆值时 _apply_splitter_sizes 优先恢复用户拖拽结果，不做二次夹紧。
    _right_default = _default_right_width(host)
    _avail = max(600, int(host.width()) - _page_ml - _page_mr)
    host._apply_splitter_sizes(host.attr_h_splitter, 'attr_h_splitter',
                               [max(320, _avail - 6 - _right_default), _right_default])
    layout.addWidget(host.attr_h_splitter, 1)

    _build_bottom_bar(host, layout)
    refresh_stats(host)
    _sync_selection_label(host)
    return widget


def install(host):
    """安装「号码属性表」选项卡：先迁移状态键、挂回调，再构建页面"""
    migrate_state(host)
    host._refresh_attr_stats = lambda: refresh_stats(host)
    host._on_attr_num_font_changed = lambda size: on_num_font_changed(host, size)
    host._on_attr_text_font_changed = lambda size: on_text_font_changed(host, size)
    host._on_attr_apply_start = lambda: on_apply_start(host)
    host._on_attr_reset = lambda: on_reset(host)
    return build(host)
